# Task 1 fix round 1 / 5

Fix base: 8f033e25ffad9ef114bf3c603cbd7ad2089673b3.

Important R1 [P2], fresh review: knowledge_coordinate_input.rs295..310 wraps COORD_SCHEMA/2 from strict parse and held.exact323 into COORD_SOURCE_REVIEW/3. A saved bundle with an extra file actually producedexit3 `COORD_SOURCE_REVIEW：a: COORD_SCHEMA：unexpected case/bundle inventory`. Preserve COORD_SCHEMA and its exit2 alongside other structural/path/fingerprint errors. Keep valid-type semantic mismatch and full candidate/IR/oldreport/binding forgery rejection as COORD_SOURCE_REVIEW/3.

Write ordinary CLI tests BEFORE production fix: saved nine-file bundle extra file, malformed/unknown/duplicate JSON keys, missing required nullable field, invalid field type. Re-pin affected actual file plus manifest where needed so failure is real schema rather than old SHA. Existing full semantic repinned forgery regressions must staysource_review/3. Observe and keep actual RED (expected2 vs current3), then minimal production match-branch fix, GREEN, affected targets and appropriate Rustfmt/check/workspace once before commit. No output-limit change: Artifact::create existing8MiB cap was proven by actual CLIprobe.

Minor R2 DTOsingle-line readability is recorded deferred and is not this fix loop's blocking requirement. No arbitrary source/style refactor or frozen author modifications.

Spec clarification: structure/version/type/extra inventory =>COORD_SCHEMA/2; path=>COORD_INPUT_PATH/2; fingerprints=>COORD_FINGERPRINT/2; identities=>COORD_IDENTITY/2; inputlimits=>COORD_INPUT_LIMIT/2. Semantically invalid otherwise typed SourceReview remainsCOORD_SOURCE_REVIEW/3. Existing output artifactlimit=>EXTRACT_SAVE_LIMIT/3.

Append fix report and exact commands/receipts/TDD/source fingerprints to task-1-report.md, commit only task1source/tests, returnshort DONE/commits/tests/concerns. No helpers/subagents/reviewers, no push/ledger completion, preserve current docs deletions and all earlier test/replay/probe evidence. Source/header/file shape remains the same; reference archivegolden response stays a valid earlier ordinaryCLI sample.
