# Global Constraints

- 当前唯一产品任务为 B05-T01；不启动 B05-T02/T03，不引入 GUI、模型调用、凭据读取、生产 Vault、完整实体图或冲突裁决。
- 普通入口为 `noetome knowledge coordinate <project> <coordination-case> <new-output>`，动词后可加 `--`；参数解析不读写文件。
- case 是同项目 2 至 3 份真实 extract verify 成功依据；严格 JSON schema_version=1，九文件精确清单、manifest 指纹、旧 IR/报告/源资源均需重新核验。
- manifest/映射各 64 KiB，映射数组各 1024 项，source_review 原限额保持，全部输入合计 96 MiB，总体 30000 ms；输入 ID、文件名、UUID 和文本规则按 Spec 原值。
- 完整同键才重复，键是 `[object_id,property_id,normalized_value,normalized_unit,sorted_normalized_conditions,sorted_normalized_exceptions]`；移除 Unicode 空白，不换算、不数值化、不删条件/例外。
- fact_id=`fact-`+紧凑 UTF-8 JSON 键 SHA256；occurrence_id=`occ-`+`[project_id,source_id,version_id,parse_id,unit_id,start_byte,end_byte,original_atom_id]` 紧凑 JSON SHA256。
- 名称与输入顺序不参与身份。每份原 IR 的概念、原子、支持证据、实际 binding 和 UTF8 定位保留；复制同一实际来源单位不能成为第二个独立来源。
- 不支持的同对象/属性语义差异或同来源不同版本/parse 身份为 needs_review/COORD_UNHANDLED_DIFFERENCE；canonical_facts=null，原组与证据保留，退出3且无协调IR。
- 知识 pending、published=false、科学 not_run、研究 not_requested、network_calls=paid_calls=0。作者样例不能证明真实教材或科学正确率。
- 新输出 root 独占、不得重叠；守卫贯穿保存之后，只撤去当前捕获的三个结果文件，不递归清理、不覆盖/删除未知内容。
- author gold/expected/map/source 在候选之前冻结；先普通 CLI 行为 RED，再生产代码；独立验证器先观察真实伪报告被错误接受的 RED，再实现检查。
- 任务小步提交，保留两项用户 docs 删除；普通推送已授权，检查通过后核对远端。任何失败原日志只追加、不抹去。


### Task 1: 正常 Rust 协调 CLI、来源依据重验和保护

**Files:** 新建上表四个 knowledge_* Rust模块和普通CLI集成测试；只修改 extraction_verify/extraction_output/lib/main 的必要接口。作者 fixture 文件在控制器已冻结，读而不改。测试辅助文件只写新 target/compiler-temp 根；必要新增测试专用 hook 在本模块 cfg(test) 内，不创建 CLI/env 绕过入口。

**Interfaces:**

```rust
// knowledge_coordinate.rs，main 的唯一调用点
pub struct CoordinationOutput { pub json: String, pub failed: bool }
pub fn run(project: &Path, case: &Path, output: &Path)
    -> Result<CoordinationOutput, ProjectError>;

// knowledge_coordinate_input.rs
pub(crate) struct CaseInputs {
    pub(crate) config: CoordinationCase,
    pub(crate) map: IdentityMap,
    // 私有根能力、两个原字节和原目录清单，不能丢弃守卫
}
impl CaseInputs {
    pub(crate) fn open(path: &Path, control: &Control) -> Result<Self, ProjectError>;
    pub(crate) fn root(&self) -> &Path;
    pub(crate) fn original_bytes(&self) -> (&[u8], &[u8]);
    pub(crate) fn verify(&self, control: &Control) -> Result<(), ProjectError>;
}
pub(crate) struct VerifiedReview {
    pub(crate) input: InputSpec,
    pub(crate) source: SourceSession,
    pub(crate) review: Review,
    pub(crate) gold: Gold,
    pub(crate) candidate: SavedCandidate,
    pub(crate) checks: Vec<Check>,
    pub(crate) files: BTreeMap<String, Vec<u8>>,
    // 私有依据目录/文件守卫贯穿最终保存
}
impl VerifiedReview {
    pub(crate) fn open(project: &Path, input: &InputSpec, case: &Path,
        control: &Control, cancel: &Arc<AtomicBool>) -> Result<Self, ProjectError>;
    pub(crate) fn verify(&self, control: &Control) -> Result<(), ProjectError>;
}

// knowledge_coordinate_facts.rs
pub(crate) fn coordinate(map: &IdentityMap, reviews: &[VerifiedReview])
    -> Result<CoordinatedFacts, ProjectError>;
// CoordinatedFacts 包含 canonical_concepts/inputs/occurrences/facts/relations/
// totals/status，类型字段严格按 Spec 第6节，供 run 写 report 和 IR。

// extraction_verify.rs，小范围复用现有 fn report 的精确构造
pub(crate) fn report_from_fingerprints(r: &Review, s: &SourceSession,
    a: &Assessment, c: Option<&SavedCandidate>,
    inputs: BTreeMap<String, Fingerprint>, artifacts: BTreeMap<String, Fingerprint>)
    -> Result<ReviewReport, ProjectError>;
pub(crate) fn review_markdown(report: &ReviewReport) -> Result<String, ProjectError>;
pub(crate) fn recover_unambiguous_json(bytes: &[u8]) -> Result<Value, serde_json::Error>;

// extraction_output.rs，沿用原身份/字节守卫
impl OutputRoot {
    pub(crate) fn create_coordination(path: &Path, request_id: &str)
        -> Result<Self, ProjectError>;
    pub(crate) fn discard_coordination_result(&mut self) -> Result<(), ProjectError>;
}
```

共享的新 DTO 名称为 `CoordinationCase,InputSpec,IdentityMap,CanonicalConcept,ConceptMapping,AtomMapping,CoordinatedFacts,CoordinationInput,Occurrence,Fact,Relation,CoordinationTotals,CoordinationReport,CoordinationIr`。加载层另使用私有 `Owner` DTO，仅核对 Spec 第4节原 source_review owner 的四个严格字段；不为此扩大旧 output 接口。PreparedCase 源码辅助单独放置 `crates/noetome-cli/tests/support/coordination_case.rs`，职责仅普通CLI准备、作者冻结、变异和保护证据；生产数据和测试临时产物仍只写新根。字段及固定值逐项按 Spec 第2/3/6节，不添加宽松 Value 元数据容器；SourceBinding/RequestUnit/CandidateAtom/Concept/Evidence/Check/Fingerprint沿用原严格类型。用于固定 String 或 1 的 serde deserialize_with 与已有 DTO 保持同一形式。

- [ ] **Step 1: 写普通 CLI 首个行为测试并实际观察 RED。** 辅助 `PreparedCase` 保存 root/project/case/output/作者原字节和保护指纹，`PreparedCase::baseline()` 先读取 fixture 的原文、三个gold、map、expected并记录其SHA，再用普通 project init、source import、extract verify 准备九文件依据；所有 CLI stdout/stderr/exit 保存到 root。按实际 import 返回构建 SourceBinding；候选 request_id 为 `synthetic-coordination-<input_id>`，两个concept ID为 `<id>-subject`、`<id>-property`，原子/证据 ID按冻结map/expected；全文支持quote采用真实 UTF8开始/结束和SHA，decision included、单atom。review subject=样例 A、property为速度/质量、allowed_contexts=[]、timing=before_synthetic_response。每份 extract verify 必须退出0，再冻结 manifest 九指纹。

```rust
#[test]
fn ordinary_cli_coalesces_duplicate_preserving_three_sources() {
    let f = PreparedCase::baseline();
    let result = f.coordinate(); // std::process::Command 调 CARGO_BIN_EXE_noetome
    f.save_cli("first-coordinate", &result);
    assert_eq!(result.status.code(), Some(0), "{}", String::from_utf8_lossy(&result.stderr));
    let report: Value = serde_json::from_slice(&result.stdout).unwrap();
    assert_eq!(report["totals"]["canonical_facts"], 2);
    assert_eq!(report["totals"]["source_occurrences"], 3);
    assert_eq!(report["totals"]["independent_sources"], 3);
    assert_eq!(report["totals"]["evidence_links"], 3);
    let velocity = report["facts"].as_array().unwrap().iter()
        .find(|x| x["value"] == "10" && x["unit"] == "m/s").unwrap();
    assert_eq!(velocity["occurrence_ids"].as_array().unwrap().len(), 2);
    f.assert_protected(); // 原source project/IR/gold/map/作者文件与外部哨兵逐字节
}
```

现有 source import 按内容 SHA 复用来源。B 输入先导入独特种子短文取得独立既有 source_id，再导入冻结的、与 A 逐字节相同的 source-b.txt，显式使用 `--source-id <B 的真实ID>`。种子版本不进入协调inputs。准备完必须断言 A/B/C 有3个不同 source_id 且 A/B 的 content_sha256 相同，再调用coordinate。

运行 `& scripts/cargo_local.ps1 test -p noetome-cli --test knowledge_coordinate ordinary_cli_coalesces_duplicate_preserving_three_sources '--' --test-threads=1`。记录真实 CLI缺失行为的失败（预期CLI_INVALID_ARGUMENT/2）；编译/路径错误不能算 RED。此时不改生产解析/协调逻辑。首次准备若只有两个来源 ID，应保留原 RED、随后正确的重复输入拒绝，并将修正的测试复制到一个独占新目录内的 `git archive` 实现前源码快照，核对旧生产字节后重放 ordinary CLI RED；该重放在发现后执行，不能记成最初准备已正确。

- [ ] **Step 2: 实现严格模型与保存依据重验。** CaseInputs先捕获根/父目录/manifest/map，严格unique JSON+DTO，再核对单层清单和声明限额。VerifiedReview依次capture九文件、复查指纹、解析owner+四原输入，SourceSession按manifest绑定import/原review selection重开；控制检查每阶段执行。旧报告 helper 从原 report 构造提取，原 run 继续调用同 helper，原source_reviewMarkdown字符串逐字节保持。完整 assess/IR/snapshot/report/MD重建不读取 passed 作为oracle。

```rust
let assessment = extraction_review::assess(&review, &gold, &decision,
    Some(&candidate), &source.units[0], &source.binding, None, None);
if !assessment.passed || candidate.payload.atoms.len() != 1 {
    return Err(ProjectError::new("COORD_SOURCE_REVIEW", 3, "single passed atom required"));
}
// 调 assess 前须 validate_gold/validate_candidates、完整绑定、timing、included、
// candidate/entity/string限额全部检查；这段不替代这些具体契约。
let expected = report_from_fingerprints(&review, &source, &assessment,
    Some(&candidate), original_role_fingerprints, saved_artifact_fingerprints)?;
if serde_json::to_value(&saved_report)? != serde_json::to_value(&expected)?
    || saved_markdown != review_markdown(&expected)?.as_bytes() {
    return Err(ProjectError::new("COORD_SOURCE_REVIEW", 3, "saved source review differs"));
}
```

在调用coordinate前，按实际 source单位元组拒绝重复；保留 input_id 与原错误原因。所有 helper需要的原角色指纹按review原文件名取得（不是copy文件名），artifact七指纹按原report正式文件名取得。JSON错误转换为 ProjectError，不 panic。

- [ ] **Step 3: 实现映射和事实组、双报告与正常CLI。** 完整核对每份概念/原子映射恰好一次和对应主体/属性组件，不按canonical显示名猜角色。构建每个 occurrence后先排序，事实键和ID按以下完整纯算法实现，source单位元组和所有出处另保留。

```rust
fn fact_key(o: &Occurrence) -> Value {
    let sorted = |items: &[String]| {
        let mut values: Vec<String> = items.iter().map(|x| extraction_review::normalized(x)).collect();
        values.sort();
        values
    };
    json!([o.object_id, o.property_id, extraction_review::normalized(&o.value),
        extraction_review::normalized(&o.unit_value), sorted(&o.conditions), sorted(&o.exceptions)])
}
fn stable_id(prefix: &str, key: &Value) -> String {
    format!("{prefix}{}", text::sha256(serde_json::to_vec(key).unwrap().as_slice()))
}
```

值都是经过验证的 JSON字符串/数组，生产错误处理不可引入不可信JSON unwrap。每对出现按同source不同版本/parse优先 needs_review，再按不同对象 separate_object、不同属性 complement、同键duplicate、其余needs_review。全部关系ID有序且恰好一次，标记相关事实/出现needs_review。

真实分母从实际 vector/partition/unique source_id重算，needs_review的canonical_facts=None。保存新的OutputRoot owner、两原输入、每份九文件copy，成功IR与完整JSON/MD，并重读类型/内容核对。最後保持所有input/source/output guard直到返回，失败只discard当前三结果。main退出值按输出failed决定0/3，ProjectError原exit；帮助清楚说明此有界范围和未发布。

- [ ] **Step 4: 实际运行失败和保护集成。** 新测试覆盖以下具体输入，并保存真实root/CLI日志：

| 输入 | 必须观察到 |
| --- | --- |
| 基线a/b同SHA且不同source | 2facts/3positions/3sources/3supports，a/b并组，c互补 |
| 反向input、mapping数组；改显示名 | canonical/occurrence/fact IDs及关系完全相同，原名称未改 |
| 只保留a/b的合法two-source case与映射 | 1fact/2positions/2sources，非三项硬编码 |
| manifest的b binding偷换a，字节SHA仍相同 | 非零COORD_SOURCE_REVIEW，无成功IR |
| 同步改b原IR或candidate内容/测量/第二证据，并重算全九指纹/旧报告指纹 | 重验真实来源或完整旧report拒绝，不靠pin碰巧失败 |
| b旧报告原candidate计数null/0/错误值；MD同步 | 拒绝假原分母，无成功IR |
| 复制a九文件成b，改input/map并重算指纹 | COORD_DUPLICATE_INPUT/2，不多计独立来源 |
| 新作者b短文/gold在候选前冻结，条件20→30或单位m/s→km/s | 来源依据真实通过，协调needs_review/3、canonical=null、3原事实/出处仍保留且没有协调IR |
| 同source-id普通import的新真实版本，加其成功依据 | needs_review，真实独立source计数减少，不编造时间 |
| map缺项/错角色/未知ID/重复项，extra/duplicate JSON键/缺nullable | COORD_IDENTITY或COORD_SCHEMA/2，原输入哨兵不变 |
| 已有输出/祖先或子路径重叠，链接/硬链接/文件别名，原目录或字节在results_saved阶段变动 | 拒绝且保留未知内容；已捕获的三个成功结果撤去 |

适当加 cfg(test) stage hook `inputs_held`、`results_saved` 复用已有真实guard模式；通过自造新目录验证，不让生产CLI接受hook。测试命令结束后汇总实际passed/failed/ignored和原指纹；首次失败与修复记录不抹去。

- [ ] **Step 5: 检查、提交和自审。** 先聚焦新knowledge_coordinate和受影响extraction_verify targets，然后一次 Rust workspace fmt/check/test（Cargo锁定离线，literal分隔符，NOETOME_TEST_PYTHON/NOETOME_PDF_PYTHON选定解释器）。把命令argv、CLI SHA、源码指纹前后、真实stdout/stderr/exit保存到本计划SDD目录。git diff --check，审查只stage授权代码/测试，不包含用户docs删除/target/SDD。可两步提交测试RED与实现GREEN，但最终对外报告必须说明所有已知失败是否解除。写task-1-report.md完整报告和正例root，短答DONE/commits/实际测试/concerns。控制器安排新鲜spec+quality审查。


