# Task 1 implementation report

Status: DONE for Rust Task 1; fresh controller review and parent-level Python/packaging/final gates still remain. Product B05-T01 is not marked complete by this worker.

Commits: `91d9b23` (first ordinary behavior RED test), `8f033e2` (strict coordination CLI, source-backed reconstruction, explicit mapping/grouping and test coverage). Only Task 1 Rust source/tests were staged. Existing user deletions `docs/Noetome-PRD-v1.0.md` and `.html` remain unstaged, as do parent-owned documentation edits. No push, ledger completion, model calls, credentials or production Vault access.

## Actual TDD and failure history

1. `task1-red-01` compiled normally, project init/source imports/all three extract verify preparation calls exited 0, then ordinary knowledge coordinate failed with CLI_INVALID_ARGUMENT/2 as expected. Its original root is `target/compiler-temp/coordinate-cd7e9993-75b9-487b-9387-1434f3ba6fd5`; all raw CLI calls remain there. Later inspection showed a/b reused the same actual source unit under the existing import hash reuse behavior. This original RED proves absent CLI behavior, but DOES NOT prove three independent sources.
2. First production `task1-green-01` therefore correctly rejected b as COORD_DUPLICATE_INPUT/2. This failure and root `coordinate-c8836dd0-9748-4d86-a3b2-dcdb16f430ab` remain; no source.rs behavior was changed.
3. Parent ruled to prepare a unique ordinary B seed import, then import frozen actual B bytes with that existing source_id explicitly. Test now asserts three actual source_ids before coordinate. Parent also required an outside-root sentinel; existing inside-root sentinel was retained and a unique compiler-temp-parent sentinel added.
4. Parent authorized replay in a new plan-local `git archive 91d9b23` tree, leaving live production work intact. Two initial archive setup attempts failed byte comparison because repository archive eol rules converted LF blobs to CRLF. Their partial archive directories, worker tool transcript tracebacks and `task1-corrected-red-replay`/`-02` command receipts remain. These were SETUP errors, never behavioral RED. The controller subprocess raw streams in those receipts capture the consequent failed path command; the preceding setup traceback is in the worker tool transcript.
5. Replay03 restored archived lib/main from raw git blobs and observed corrected ordinary CLI_INVALID_ARGUMENT/2 after actual successful three-source preparation. Replay04 additionally restored and verified all 73 archived Rust/Cargo/toolchain/script files against exact raw `git show 91d9b23:path` blobs, with corrected test SHA recorded separately, then again observed the same legitimate three-source behavior RED. Archive tree is `red-replay-6cd7c43a`; `verified-source-pins.json` records all verified files, `replay-provenance.json` records old revision and corrected test SHA, and `actual-cli-fingerprint.json` records the actual archived CLI. The generic controller's replay cli field refers to the live executable, so use this separate archived executable fingerprint for replay provenance. Original replay test/compiler/CLI roots and all failures remain.
6. Corrected live `task1-green-02` passed the initial 12 integration cases. Affected focused regression then passed source_review24 plus coordination14. Final workspace includes the added coherent all-fingerprints forgery case and all guards, and passes completely.

## Implementation and source-backed checks

Four new coordination modules plus strict versioned model: `knowledge_coordinate.rs`, `knowledge_coordinate_input.rs`, `knowledge_coordinate_facts.rs`, `knowledge_coordination_model.rs`. Ordinary parser/main dispatch is file-free, accepts optional literal -- after coordinate, rejects malformed arguments, and has matching knowledge help entries.

Case and mapping have unique-key JSON parsing, strict DTO fields, exact single-layer inventories, safe filenames and IDs, real UUIDs, bounded byte/entity/text limits, and held parent/root/file identities plus original bytes/timestamps/inventories. Each nine-file saved source_review bundle is fingerprinted and re-parsed, owner/four raw inputs/full actual binding/single included atom/timing are validated, actual SourceSession reopens the selected source's SQLite/registered version/resource/UTF8 unit, and existing validate_gold/validate_candidates/assess are called. Full snapshot, IR, original role fingerprints, seven saved artifact fingerprints, report fields/checks/denominators and exact old Markdown reconstruction must match. SourceReview's report constructor and Markdown formatter were factored minimally; old run still uses the same recipe, and old24 integration tests plus its guard tests passed.

Mapping covers every original concept and unique atom exactly once, checks explicit subject/property component roles against the source review, and rejects missing/duplicate/unknown/wrong-role/unused identities. IDs use the prescribed compact UTF8 JSON complete key hashes. Source unit identity preflight rejects copied actual units before they can count twice. Names/input order do not affect identity, grouping or provenance. Each occurrence retains full actual binding/unit/original concepts/atom/all support evidence. Every pair has one sorted relationship. Complete same-key groups duplicate; different objects separate; different properties complement; unsupported same-property or same-source different-version/parse differences needs_review. Unknown coordinated count is null, full original groups/occurrences remain, and no success IR is saved.

OutputRoot creates knowledge_coordination owner, original case/map and all nine-file copies, reports and only successful IR in a new root. Control checks and all input/source/output guards continue through results_saved and final return. Failure discards only the three captured coordination result pathnames; unknown content, copies and owner remain. No recursive cleanup.

## Actual behavior and guards

- Baseline true3-source same-SHA a/b:2 facts,3 occurrences,3 source_ids,3 support links,1 duplicate occurrence; velocity has both independent positions and mass remains complementary.
- Reversed input/mapping arrays and changed display names preserve complete occurrences/facts/relations/totals/inputs. Legal two-source case has1 fact/2 sources/2 occurrences.
- Wrong same-SHA binding, re-pinned modified IR/candidate value/extra evidence, coherent candidate+IR value/content forgery with all seven report artifact fingerprints/four role fingerprints/Markdown/nine manifest fingerprints refreshed, and null/0/incorrect old candidate denominator all reject with COORD_SOURCE_REVIEW/3.
- Copied actual A package relabeled B rejects with COORD_DUPLICATE_INPUT/2. Gold/source condition20→30 or unit m/s→km/s is authored before candidates and source reviews genuinely pass, then coordination returns needs_review/3,3 groups/3 positions/canonical_facts=null/no IR. Ordinary source-id A's new true version returns needs_review with2 actual independent source_ids.
- Missing/unknown/duplicate/wrong-role maps reject COORD_IDENTITY/2; extra/duplicate-key/missing nullable/inventory schema reject COORD_SCHEMA/2. Existing output/manual content, embedded target, actual map hardlink, real Windows case junction and linked output parent all reject and preserve inputs.
- cfg(test) stages exercise actual held-input/source/result concurrent write and delete denial on Windows; results_saved case/source/output inventory additions fail and remove only captured results; actual result hardlink is denied or invalidates without deleting the newly created alias.

## Receipts and final validation

Every following receipt has raw stdout/stderr/exit, argv, selected Python/external TEMP, live CLI SHA and before/after source fingerprints. Format mutation is explicitly recorded as source changed. Compiler TEMP is the existing cargo_local project-local setting; receipt environment TEMP/TMP remains external. All original evidence is retained.

| Receipt label | Exit | Source unchanged | Actual command |
| --- | --- | --- | --- |
| `task1-red-01` | 1 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate ordinary_cli_coalesces_duplicate_preserving_three_sources '--' --test-threads=1 --nocapture` |
| `task1-green-01` | 1 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate '--' --test-threads=1 --nocapture` |
| `task1-corrected-red-replay` | 1 | True | `& '/scripts/cargo_local.ps1' test -p noetome-cli --locked --offline --test knowledge_coordinate ordinary_cli_coalesces_duplicate_preserving_three_sources '--' --test-threads=1 --nocapture` |
| `task1-corrected-red-replay-02` | 1 | True | `& '/scripts/cargo_local.ps1' test -p noetome-cli --locked --offline --test knowledge_coordinate ordinary_cli_coalesces_duplicate_preserving_three_sources '--' --test-threads=1 --nocapture` |
| `task1-corrected-red-replay-03` | 1 | True | `& 'D:\Noetome\.superpowers\sdd\B05-T01_COORDINATION_PLAN\red-replay-6cd7c43a/scripts/cargo_local.ps1' test -p noetome-cli --locked --offline --test knowledge_coordinate ordinary_cli_coalesces_duplicate_preserving_three_sources '--' --test-threads=1 --nocapture` |
| `task1-corrected-red-replay-04` | 1 | True | `& 'D:\Noetome\.superpowers\sdd\B05-T01_COORDINATION_PLAN\red-replay-6cd7c43a/scripts/cargo_local.ps1' test -p noetome-cli --locked --offline --test knowledge_coordinate ordinary_cli_coalesces_duplicate_preserving_three_sources '--' --test-threads=1 --nocapture` |
| `task1-green-02` | 0 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate '--' --test-threads=1 --nocapture` |
| `task1-focused-guards-01` | 0 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --lib knowledge_coordinate '--' --test-threads=1 --nocapture` |
| `task1-focused-regression-01` | 0 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate --test extraction_verify '--' --test-threads=4 --nocapture` |
| `task1-format-apply` | 0 | False | `./scripts/cargo_local.ps1 fmt --all` |
| `task1-rust-fmt` | 0 | True | `./scripts/cargo_local.ps1 fmt --all --check` |
| `task1-rust-check` | 0 | True | `./scripts/cargo_local.ps1 check --workspace --locked --offline` |
| `task1-rust-workspace` | 0 | True | `./scripts/cargo_local.ps1 test --workspace --locked --offline '--' --test-threads=4 --nocapture` |
| `task1-diff-check` | 0 | True | `git diff --check` |

Final actual aggregate: **551 passed, 0 failed, 0 ignored** (CLI/library/integration/desktop/doc test suites; coordination15 and cfg(test)guards4 included). Full fmt/check/workspace tests and git diff --check exited0. Full workspace source fingerprints were unchanged throughout. Selected interpreter was `C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8`; NOETOME_TEST_PYTHON and NOETOME_PDF_PYTHON were supplied by controller.

Positive root: `\\?\D:\Noetome\target\compiler-temp\coordinate-bb868387-443e-4150-aca8-4cc847274ad3`. Report totals: `{"input_bundles": 3, "validated_input_bundles": 3, "input_atoms": 3, "retained_fact_groups": 2, "canonical_facts": 2, "source_occurrences": 3, "evidence_links": 3, "independent_sources": 3, "duplicate_occurrences": 1, "passed": 3, "failed": 0, "needs_review": 0, "unprocessed": 0}`. Actual final CLI SHA256: `72935e28ac7cc112f8e6275ed6e1ed9c4ebaff90f04a334d2c422224c13dd20b`. `protection-before.json` and `protection-after.json` match for50 files, including frozen author inputs, source project/resources, case original gold/IR/map and outside-root sentinel `\\?\D:\Noetome\target\compiler-temp\coordination-external-sentinel-6b616ccc-f359-4cab-8d76-360c8edc3de3.txt`. Its location is outside PreparedCase.root. `task1-results-summary.json` contains machine-readable aggregation/provenance. Each failure fixture stores original ordinary CLI stdout/stderr/exit and protection fingerprints in its own unique root.

## Concerns and handoff

No known unresolved Rust test failure. Fresh spec/quality review remains parent responsibility, along with independent Python implementation and final packaging/product ledger/push. Only v1 author-engineering sources were exercised; no claims of real textbook/scientific accuracy, general entity merging, time inference, conflict adjudication, model/OCR, production Vault, compatibility/performance certification or B05-T02/T03 completion. Private strict Owner DTO and shared test support helper were approved by parent clarification. Archive setup failures are disclosed above and remain distinct from genuine behavior RED.


## Task 1 fix round 1 / 5 — R1 schema error routing

Fix base: `8f033e25ffad9ef114bf3c603cbd7ad2089673b3`. Fix commit: `fd8036e8904fc184ed00476cea97824b2aaa26d1`. R1 is implemented; controller-owned fresh scoped review remains. The prior report's historical551 aggregate is retained; this round's actual total is558.

Read `task1-fix1-findings.md` and complete fresh review `task1-review.md`, then verified the actual wrapper code omitted COORD_SCHEMA. Applied receiving-code-review skill and real TDD. Root's specific classification ruling preserves structural/version/type/extra-inventory COORD_SCHEMA/2, while valid-type source binding/content/assessment/report mismatches stay COORD_SOURCE_REVIEW/3. This round changes only the preserved-code match entry and tests; no output-limit change (existing Artifact::create8MiB enforcement was already proven), no DTO readability refactor or other production behavior change.

Before production code, added seven ordinary CLI saved-bundle regressions: extra inventory file; malformed owner JSON; unknown gold field; duplicate nested candidate payload key; missing required nullable binding.parse_id; invalid snapshot.units integer; unsupported IR schema_version2. Each uses genuine successful project/source/source_review preparation, modifies the saved bundle, re-pins the actual nine-file manifest fingerprints, and expects COORD_SCHEMA/2. `task1-fix1-red` compiled normally and actually failed all7 assertions: expected2, observed3 with outer COORD_SOURCE_REVIEW and inner COORD_SCHEMA. Its raw stdout/stderr includes seven distinct roots and exact underlying reasons; source was unchanged during command. This is behavior RED, not setup/compile failure.

Minimal production GREEN: add `"COORD_SCHEMA"` to VerifiedReview::open's existing preserved error-code branch. No semantic assessment or reconstruction code changed. `task1-fix1-green` passed source_review24 and knowledge_coordinate22, including all7 new structural cases and unchanged same-SHA wrong binding/complete semantic candidate+IR+report fingerprint forgery/incorrect old count rejection as source_review3. All authored source/gold/map bytes remain frozen. The original earlier reference zip/sample was not modified.

RED assertion failure occurred before the existing reject helper's final protection assertion; this is explicit. After RED, independently read-only rechecked all seven roots' protection-before.json entries against actual source/project/case/frozen-author/sentinel bytes and saved `fix1-red-protection-rechecked-after.json` in each root. All matched. `task1-fix1-red-protection-recheck.json` records the roots/counts and states this verification occurred after assertion failure, not within the failing test path. GREEN/full runs invoke normal protection assertions and save their actual before/after receipts.

| Receipt | Exit | Source unchanged | Actual command |
| --- | --- | --- | --- |
| `task1-fix1-red` | 1 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate saved_bundle_ '--' --test-threads=4 --nocapture` |
| `task1-fix1-green` | 0 | True | `./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate --test extraction_verify '--' --test-threads=4 --nocapture` |
| `task1-fix1-format-apply` | 0 | False | `./scripts/cargo_local.ps1 fmt --all` |
| `task1-fix1-fmt` | 0 | True | `./scripts/cargo_local.ps1 fmt --all --check` |
| `task1-fix1-check` | 0 | True | `./scripts/cargo_local.ps1 check --workspace --locked --offline` |
| `task1-fix1-workspace` | 0 | True | `./scripts/cargo_local.ps1 test --workspace --locked --offline '--' --test-threads=4 --nocapture` |
| `task1-fix1-diff-check` | 0 | True | `git diff --check` |

All receipt files retain actual raw stdout/stderr/exit, argv, CLI SHA, selected Python/runtime/external TEMP and source fingerprints; the intentional fmt mutation is correctly marked changed. Final full Rust workspace aggregate: **558 passed, 0 failed, 0 ignored**, across16 suites; source_review24, coordination22 and all4 coordination guard tests included. Fmt/check/diff-check exit0. No compiler/test warning in the successful Rust gates. `task1-fix1-results.json` is the machine-readable aggregate. Full gate ran once in this fix round and source hashes stayed unchanged during each validation command.

New final positive root: `\\?\D:\Noetome\target\compiler-temp\coordinate-9fbd9adf-2545-4f14-9fe1-dfefc03b5533`; baseline report is still2 facts/3 positions/3 independent sources/3 support links/1 duplicate. Original protection-before and protection-after are identical. Final actual CLI SHA256: `97ebd64ec0a2fe84e08a64e5a126f5b61e81adb24deb43b65de7be7aef809203`.

Git staged only `crates/noetome-cli/src/knowledge_coordinate_input.rs` and `crates/noetome-cli/tests/knowledge_coordinate.rs`. Existing docs deletions, parent-owned spec/plan/validation edits and all scratch/replay/probe evidence remain intact. No push, ledger completion, subagents/helpers/reviewers or post-T01 product work. MinorR2 remains explicitly deferred by controller; output-limit concern remains disproved. R1 has no known remaining regression failure; fresh scoped re-review and parent product gates remain outstanding.
