# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

显式身份重复／互补范围；完整来源、原对象、证据与分母见以下事实，与 coordination.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "67dda026-d2b0-4572-af65-07b2d4f93c86",
  "scope": "explicit_identity_duplicate_complement_v1",
  "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "display_name": "速度"
    },
    {
      "canonical_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "display_name": "质量"
    },
    {
      "canonical_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "display_name": "样例 A"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
        "import_id": "307fb317-7158-4e6d-a11f-bf308125e6e7",
        "source_id": "170424f0-ee09-463a-a0a0-44e8c58aeebb",
        "version_id": "60c77125-ceb4-496b-802e-6cc5aa8450f9",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "307fb317-7158-4e6d-a11f-bf308125e6e7",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
              "source_id": "170424f0-ee09-463a-a0a0-44e8c58aeebb",
              "version_id": "60c77125-ceb4-496b-802e-6cc5aa8450f9"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "307fb317-7158-4e6d-a11f-bf308125e6e7",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
              "source_id": "170424f0-ee09-463a-a0a0-44e8c58aeebb",
              "version_id": "60c77125-ceb4-496b-802e-6cc5aa8450f9"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "2b0e3031955c08e416712dc39e2fd1482d4701746640f480219728936e7e9a2c",
          "byte_length": 2978
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
          "byte_length": 726
        },
        "knowledge-ir.json": {
          "sha256": "bf2bfa6c7f96d40b869e254ead38296f39aa984338e810e7276c186535314295",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "c1b9d3786a78c1e365e7fb098e6e64647a2fa292052aad26040164d1ea19a4ac",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "fb209428c8aab206ca720b4e87704767446eccf7b0e2aefe5aa77bdcab036657",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "610a85764d9924f662e4cd5146940fc02830f9034d8c6b3a5222eecfbb63c7be",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
        "import_id": "114746b8-689d-49b4-b47d-e94b1b30203d",
        "source_id": "cbe450fd-388d-4bf4-834d-05434c719b54",
        "version_id": "b7cb8a4f-509a-4df3-bc48-547f87e909c0",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "114746b8-689d-49b4-b47d-e94b1b30203d",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
              "source_id": "cbe450fd-388d-4bf4-834d-05434c719b54",
              "version_id": "b7cb8a4f-509a-4df3-bc48-547f87e909c0"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "114746b8-689d-49b4-b47d-e94b1b30203d",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
              "source_id": "cbe450fd-388d-4bf4-834d-05434c719b54",
              "version_id": "b7cb8a4f-509a-4df3-bc48-547f87e909c0"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "0306ab29b6fa362bd33770bc263afa1729a66906629402c956a1ba8aca9712b3",
          "byte_length": 2978
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
          "byte_length": 726
        },
        "knowledge-ir.json": {
          "sha256": "fc97ff8887a623d80d891c6193864823138e37060ffd7d18c22f2fad224dd00e",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "610a30a14122a2a78dbbce283e150d5c49486dc3c70c0f4f1cd42df76f2a227f",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "93ec206250cca1f760a5d95223e0ba9b51457290561a52292f5a149690056577",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "71f771a70c88686069bde548a45e441547b889f6f71db1c1fd0c4700fd412d92",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
        "import_id": "8a6cad4c-6aa7-414d-a12b-9968e2b6c1b3",
        "source_id": "2ff5ab6f-69c1-4577-99db-81c110f34029",
        "version_id": "9857af14-d154-40f4-b0d0-4840bc5a3b0d",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "8a6cad4c-6aa7-414d-a12b-9968e2b6c1b3",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
              "source_id": "2ff5ab6f-69c1-4577-99db-81c110f34029",
              "version_id": "9857af14-d154-40f4-b0d0-4840bc5a3b0d"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "8a6cad4c-6aa7-414d-a12b-9968e2b6c1b3",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
              "source_id": "2ff5ab6f-69c1-4577-99db-81c110f34029",
              "version_id": "9857af14-d154-40f4-b0d0-4840bc5a3b0d"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 104,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 105,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 104,
            "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 104,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 104,
              "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "11839e3a6455f5584ae61e8f59f48780bcffc384c8fc3be5aae01878fdbf5390",
          "byte_length": 2970
        },
        "decision-original.json": {
          "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
          "byte_length": 139
        },
        "gold-original.json": {
          "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
          "byte_length": 720
        },
        "knowledge-ir.json": {
          "sha256": "f6ca521244d7845a924a8db9de210d57a7b5c72928bbbbc50966542c6fb0f05d",
          "byte_length": 12036
        },
        "review-original.json": {
          "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "5b83f714fd951b094d454e02480967794b6683ee48a2b0d93618684b8bbbf826",
          "byte_length": 994
        },
        "verification.json": {
          "sha256": "59ef289c7e69354bf930734bd8108bb464b54a66abc85f2e5deb63ea8f43d4aa",
          "byte_length": 16533
        },
        "verification.md": {
          "sha256": "2f222f8bca468205bcb13a52ba9a64c82754e4c99989b6412d5c851f9bb77314",
          "byte_length": 16967
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "occurrence_id": "occ-81a3aaa0c5d4002f3439ff374bf549fcb4a89dee7fb81c7a896539f6c7be9fb4",
      "input_id": "a",
      "binding": {
        "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
        "import_id": "307fb317-7158-4e6d-a11f-bf308125e6e7",
        "source_id": "170424f0-ee09-463a-a0a0-44e8c58aeebb",
        "version_id": "60c77125-ceb4-496b-802e-6cc5aa8450f9",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "d73db4ef-dcf6-4557-b285-28e6eeb8adc4",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-9481c1365b8beccff525da71ad1657e7eea813507b40a2305b05a148c4ca2935",
      "input_id": "b",
      "binding": {
        "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
        "import_id": "114746b8-689d-49b4-b47d-e94b1b30203d",
        "source_id": "cbe450fd-388d-4bf4-834d-05434c719b54",
        "version_id": "b7cb8a4f-509a-4df3-bc48-547f87e909c0",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "1cfd529a-8ab1-4326-9b03-eb3e2c7a49a4",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-993edc4ed2fcb816aac5a76a901d8d2838acde26b4ebbdbd2dc20bd3b7fac5b7",
      "input_id": "c",
      "binding": {
        "project_id": "7c11497b-e7ce-44b9-b62e-20ad718458d5",
        "import_id": "8a6cad4c-6aa7-414d-a12b-9968e2b6c1b3",
        "source_id": "2ff5ab6f-69c1-4577-99db-81c110f34029",
        "version_id": "9857af14-d154-40f4-b0d0-4840bc5a3b0d",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a561a8e3-ada0-4324-92d1-6071d557348f",
          "ordinal": 0,
          "resource_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 105,
        "text": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 104,
          "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
          "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "51fa59a0-255f-4867-836c-aa39bdc01906",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "fact_id": "fact-2176d0ef755e6f1de61cf485f79a5805b933ddc9487e83fcd12064c305a175a4",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-81a3aaa0c5d4002f3439ff374bf549fcb4a89dee7fb81c7a896539f6c7be9fb4",
        "occ-9481c1365b8beccff525da71ad1657e7eea813507b40a2305b05a148c4ca2935"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "fact_id": "fact-6bc62067e5e15c97430ccb915d046434ef2b5edab41254cf60e7ef28f896d03b",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-993edc4ed2fcb816aac5a76a901d8d2838acde26b4ebbdbd2dc20bd3b7fac5b7"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "left_occurrence_id": "occ-81a3aaa0c5d4002f3439ff374bf549fcb4a89dee7fb81c7a896539f6c7be9fb4",
      "right_occurrence_id": "occ-9481c1365b8beccff525da71ad1657e7eea813507b40a2305b05a148c4ca2935",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-81a3aaa0c5d4002f3439ff374bf549fcb4a89dee7fb81c7a896539f6c7be9fb4",
      "right_occurrence_id": "occ-993edc4ed2fcb816aac5a76a901d8d2838acde26b4ebbdbd2dc20bd3b7fac5b7",
      "relation": "complement",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-9481c1365b8beccff525da71ad1657e7eea813507b40a2305b05a148c4ca2935",
      "right_occurrence_id": "occ-993edc4ed2fcb816aac5a76a901d8d2838acde26b4ebbdbd2dc20bd3b7fac5b7",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "totals": {
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "16bea4f1987f7bef20bad8f6fd0103c1f527f6c2bbefcbcdbd0795647497743f",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "68af89e3c75e9a38dfc1adb65aa55f19c279b2afa5246569907a5b8c121384da",
      "byte_length": 55919
    },
    "coordination-original.json": {
      "sha256": "edae3d401654da37f4eb659552717a466165d227a15d97ba15e84f25ba9f7984",
      "byte_length": 6403
    },
    "identity-original.json": {
      "sha256": "419d4155e834d9774b862516ffddc125a381c2c6cf36f35cc02cc1992d492048",
      "byte_length": 1616
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "2b0e3031955c08e416712dc39e2fd1482d4701746640f480219728936e7e9a2c",
      "byte_length": 2978
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
      "byte_length": 726
    },
    "input-a--knowledge-ir.json": {
      "sha256": "bf2bfa6c7f96d40b869e254ead38296f39aa984338e810e7276c186535314295",
      "byte_length": 12081
    },
    "input-a--review-original.json": {
      "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "c1b9d3786a78c1e365e7fb098e6e64647a2fa292052aad26040164d1ea19a4ac",
      "byte_length": 996
    },
    "input-a--verification.json": {
      "sha256": "fb209428c8aab206ca720b4e87704767446eccf7b0e2aefe5aa77bdcab036657",
      "byte_length": 16573
    },
    "input-a--verification.md": {
      "sha256": "610a85764d9924f662e4cd5146940fc02830f9034d8c6b3a5222eecfbb63c7be",
      "byte_length": 17007
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "0306ab29b6fa362bd33770bc263afa1729a66906629402c956a1ba8aca9712b3",
      "byte_length": 2978
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
      "byte_length": 726
    },
    "input-b--knowledge-ir.json": {
      "sha256": "fc97ff8887a623d80d891c6193864823138e37060ffd7d18c22f2fad224dd00e",
      "byte_length": 12081
    },
    "input-b--review-original.json": {
      "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "610a30a14122a2a78dbbce283e150d5c49486dc3c70c0f4f1cd42df76f2a227f",
      "byte_length": 996
    },
    "input-b--verification.json": {
      "sha256": "93ec206250cca1f760a5d95223e0ba9b51457290561a52292f5a149690056577",
      "byte_length": 16573
    },
    "input-b--verification.md": {
      "sha256": "71f771a70c88686069bde548a45e441547b889f6f71db1c1fd0c4700fd412d92",
      "byte_length": 17007
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "11839e3a6455f5584ae61e8f59f48780bcffc384c8fc3be5aae01878fdbf5390",
      "byte_length": 2970
    },
    "input-c--decision-original.json": {
      "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
      "byte_length": 139
    },
    "input-c--gold-original.json": {
      "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
      "byte_length": 720
    },
    "input-c--knowledge-ir.json": {
      "sha256": "f6ca521244d7845a924a8db9de210d57a7b5c72928bbbbc50966542c6fb0f05d",
      "byte_length": 12036
    },
    "input-c--review-original.json": {
      "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
      "byte_length": 509
    },
    "input-c--source-snapshot.json": {
      "sha256": "5b83f714fd951b094d454e02480967794b6683ee48a2b0d93618684b8bbbf826",
      "byte_length": 994
    },
    "input-c--verification.json": {
      "sha256": "59ef289c7e69354bf930734bd8108bb464b54a66abc85f2e5deb63ea8f43d4aa",
      "byte_length": 16533
    },
    "input-c--verification.md": {
      "sha256": "2f222f8bca468205bcb13a52ba9a64c82754e4c99989b6412d5c851f9bb77314",
      "byte_length": 16967
    }
  }
}
```
