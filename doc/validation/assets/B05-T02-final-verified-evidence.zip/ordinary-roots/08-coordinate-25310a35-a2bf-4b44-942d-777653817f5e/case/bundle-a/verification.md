# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "c8a6911a-1369-428d-a5e8-50870732ace8",
      "import_id": "e61c29ad-ef17-408e-87ec-e753562ef5d3",
      "source_id": "8c9ad488-115a-4dd2-ae1f-e23969452c22",
      "version_id": "04e848aa-6a76-4ebe-9557-af4d5fed23ae",
      "content_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
      "normalized_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "d89e753e-5e69-4a75-b389-79cf51ac2ee3",
          "ordinal": 0,
          "resource_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 112,
        "text": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "c8a6911a-1369-428d-a5e8-50870732ace8",
    "import_id": "e61c29ad-ef17-408e-87ec-e753562ef5d3",
    "source_id": "8c9ad488-115a-4dd2-ae1f-e23969452c22",
    "version_id": "04e848aa-6a76-4ebe-9557-af4d5fed23ae",
    "content_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
    "normalized_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "3c3a1df74ed8b52330e17cfdd80eb9cee12d65dab0aa941ed91ad0760398abbc",
        "byte_length": 2999
      },
      "decision.json": {
        "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
        "byte_length": 743
      },
      "review.json": {
        "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
        "byte_length": 509
      }
    },
    "gold_sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
          "import_id": "e61c29ad-ef17-408e-87ec-e753562ef5d3",
          "manifest_sha256": null,
          "normalized_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
          "parse_id": null,
          "project_id": "c8a6911a-1369-428d-a5e8-50870732ace8",
          "source_id": "8c9ad488-115a-4dd2-ae1f-e23969452c22",
          "version_id": "04e848aa-6a76-4ebe-9557-af4d5fed23ae"
        },
        "request_id": "synthetic-coordination-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
          "import_id": "e61c29ad-ef17-408e-87ec-e753562ef5d3",
          "manifest_sha256": null,
          "normalized_sha256": "666f67302e26c0495baac4a600a25c5acf3371cfafd3a93daaf72b344befdfa1",
          "parse_id": null,
          "project_id": "c8a6911a-1369-428d-a5e8-50870732ace8",
          "source_id": "8c9ad488-115a-4dd2-ae1f-e23969452c22",
          "version_id": "04e848aa-6a76-4ebe-9557-af4d5fed23ae"
        },
        "request_id": "synthetic-coordination-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 111,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 112,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 111,
        "excerpt_sha256": "4b8e4e561f0e394ea27a4baa84bd2ef530e1002b3c6509a2c54505809fe65d28",
        "excerpt_start_byte": 0,
        "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 111,
        "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 111,
          "excerpt_sha256": "4b8e4e561f0e394ea27a4baa84bd2ef530e1002b3c6509a2c54505809fe65d28",
          "excerpt_start_byte": 0,
          "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "8",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "8",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 112,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "3c3a1df74ed8b52330e17cfdd80eb9cee12d65dab0aa941ed91ad0760398abbc",
      "byte_length": 2999
    },
    "decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "knowledge-ir.json": {
      "sha256": "417c8e51cf9cab15875abe6b538534ff6a3e8a56702eff63362e12bc6a7a936e",
      "byte_length": 12220
    },
    "review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "7d562d9ad0d41374fc6cbf0ecb0701baa8580e4b203b1966c7647c3b05890fff",
      "byte_length": 1001
    }
  }
}
```
