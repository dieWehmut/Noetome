# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：1。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "81178086-b6be-4d1c-ace4-04bcef90a009",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
        "import_id": "4c3549ea-58fa-4828-8b52-6369a5f1f2be",
        "source_id": "a52dc713-91d5-4c76-b485-01d365fd44a9",
        "version_id": "3c3e8532-9518-4dee-90dd-ec3aae13798f",
        "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "import_id": "4c3549ea-58fa-4828-8b52-6369a5f1f2be",
              "manifest_sha256": null,
              "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "parse_id": null,
              "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
              "source_id": "a52dc713-91d5-4c76-b485-01d365fd44a9",
              "version_id": "3c3e8532-9518-4dee-90dd-ec3aae13798f"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "import_id": "4c3549ea-58fa-4828-8b52-6369a5f1f2be",
              "manifest_sha256": null,
              "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "parse_id": null,
              "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
              "source_id": "a52dc713-91d5-4c76-b485-01d365fd44a9",
              "version_id": "3c3e8532-9518-4dee-90dd-ec3aae13798f"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "58d69ad11c7da88e35a3c2e1c319e12b7bc8204022095fcd18016a45af088ef2",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 history_day/a。\n适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 92
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "58d69ad11c7da88e35a3c2e1c319e12b7bc8204022095fcd18016a45af088ef2",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 history_day/a。\n适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "4f55b3413e2f43218929e9c443ae47c9d0685e96309a1b70b5de9050ca1488ed",
          "byte_length": 3173
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
          "byte_length": 743
        },
        "knowledge-ir.json": {
          "sha256": "088702fe5b6f609c17afe12a855ea896f06739275e28bcdad607b6681514b782",
          "byte_length": 12743
        },
        "review-original.json": {
          "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "b2e237e60999d62217dbd95136f3e9d6b5bff2211085943d7499341a0bca1ae8",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "e0169bcf525531e1d4e4552b4e4e1bec56721364011c17ed0dc39f7506d5fcae",
          "byte_length": 17220
        },
        "verification.md": {
          "sha256": "f2618042b8a5743ff4b76fc29f55d788f5b7ece946fc30d96823e0a96067572d",
          "byte_length": 17654
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
        "import_id": "ce4b1514-c708-4bd5-b733-d6b9fb494690",
        "source_id": "fd69ff41-7a87-474b-883d-cffe48b045af",
        "version_id": "6097123a-61b8-40d2-a0db-bed36ea43b86",
        "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "import_id": "ce4b1514-c708-4bd5-b733-d6b9fb494690",
              "manifest_sha256": null,
              "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "parse_id": null,
              "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
              "source_id": "fd69ff41-7a87-474b-883d-cffe48b045af",
              "version_id": "6097123a-61b8-40d2-a0db-bed36ea43b86"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "import_id": "ce4b1514-c708-4bd5-b733-d6b9fb494690",
              "manifest_sha256": null,
              "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "parse_id": null,
              "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
              "source_id": "fd69ff41-7a87-474b-883d-cffe48b045af",
              "version_id": "6097123a-61b8-40d2-a0db-bed36ea43b86"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 284,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 283,
            "excerpt_sha256": "b072c6973b710bceb5edd07e3a0d17ee9547186e61fe350802681c64c2038b1d",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 history_day/b。\n适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 204,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 92
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 283,
              "excerpt_sha256": "b072c6973b710bceb5edd07e3a0d17ee9547186e61fe350802681c64c2038b1d",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 history_day/b。\n适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "1e3279fb6a843b75c215e1ef153966e3367360e9ac90d96ed5959b692e4b6db1",
          "byte_length": 3176
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "a0101ee576543f32fc4831a1d91703368d2b9481778661cf18625f6bda868734",
          "byte_length": 12754
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "965fdc3d45f6c5f105f5465e04eb7f9d9d01b30b713d098c8d47750035024706",
          "byte_length": 1176
        },
        "verification.json": {
          "sha256": "7b7782724354d247bf6964771a95ff11e0cacd2eb307aea0b7e3d94cc25551d2",
          "byte_length": 17229
        },
        "verification.md": {
          "sha256": "e7aa4f5a1b3ee9fa12164f1e72f467f4dc810d6633913c6bb8bf5a05d801a44a",
          "byte_length": 17663
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "day",
          "value": "2020-02-29"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b"
      },
      "occurrence_id": "occ-692c448c44c26d3bb63f477887610b1c14d91514c8554906deb0b855e70986e4",
      "input_id": "a",
      "binding": {
        "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
        "import_id": "4c3549ea-58fa-4828-8b52-6369a5f1f2be",
        "source_id": "a52dc713-91d5-4c76-b485-01d365fd44a9",
        "version_id": "3c3e8532-9518-4dee-90dd-ec3aae13798f",
        "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "35170bc5-f439-4925-985d-4a142070fd4b",
          "ordinal": 0,
          "resource_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 history_day/a。\n适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "58d69ad11c7da88e35a3c2e1c319e12b7bc8204022095fcd18016a45af088ef2",
          "quote": "公开自造资料 history_day/a。\n适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "day",
          "value": "2021-03-01"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 204,
        "quote": "适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "e0f58b7cf2d5799bea0bd74cc1c2ed6f659bcf5a4ae7e0d3c9966d10450a922e"
      },
      "occurrence_id": "occ-c7f204a572c886c83ed427267b94643ef6cfcdbea189f4393c32106a4ef30114",
      "input_id": "b",
      "binding": {
        "project_id": "791acecc-b7c0-4fd5-8167-e6c56a6aa31f",
        "import_id": "ce4b1514-c708-4bd5-b733-d6b9fb494690",
        "source_id": "fd69ff41-7a87-474b-883d-cffe48b045af",
        "version_id": "6097123a-61b8-40d2-a0db-bed36ea43b86",
        "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "7ce2482c-ddaf-475f-a5cd-83d964884313",
          "ordinal": 0,
          "resource_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 284,
        "text": "公开自造资料 history_day/b。\n适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 283,
          "excerpt_sha256": "b072c6973b710bceb5edd07e3a0d17ee9547186e61fe350802681c64c2038b1d",
          "quote": "公开自造资料 history_day/b。\n适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "day",
        "value": "2021-03-01"
      },
      "fact_id": "fact-v2-f33d043cd3c17059f036b14656b66ca72da724b38df13e7c1a7e3c960fb9e39e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-c7f204a572c886c83ed427267b94643ef6cfcdbea189f4393c32106a4ef30114"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "day",
        "value": "2020-02-29"
      },
      "fact_id": "fact-v2-fb0ac5504b823990db44b646e73c5e6dda2c3305677f280783ea1a2914136ae3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-692c448c44c26d3bb63f477887610b1c14d91514c8554906deb0b855e70986e4"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": "occ-692c448c44c26d3bb63f477887610b1c14d91514c8554906deb0b855e70986e4",
      "later_occurrence_id": "occ-c7f204a572c886c83ed427267b94643ef6cfcdbea189f4393c32106a4ef30114",
      "left_occurrence_id": "occ-692c448c44c26d3bb63f477887610b1c14d91514c8554906deb0b855e70986e4",
      "right_occurrence_id": "occ-c7f204a572c886c83ed427267b94643ef6cfcdbea189f4393c32106a4ef30114",
      "relation": "historical_evolution",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 1,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "705b01f7909cfa65573af40484e5f8c0d8dddedc290ead628e22394fff064daf",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "1a4d8924c3e363f3191e0f558b380ea8d1c3fb1e2124de2c66334b96db748312",
      "byte_length": 41381
    },
    "coordination-original.json": {
      "sha256": "9980011562b25d3e12769469df689d32404baa720fe751e3fa4cecb2024904aa",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "840160ee1a807eb0f043adbc23340877307c34d2cfbc963ac8cf166e79ddafe5",
      "byte_length": 1918
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "4f55b3413e2f43218929e9c443ae47c9d0685e96309a1b70b5de9050ca1488ed",
      "byte_length": 3173
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "input-a--knowledge-ir.json": {
      "sha256": "088702fe5b6f609c17afe12a855ea896f06739275e28bcdad607b6681514b782",
      "byte_length": 12743
    },
    "input-a--review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "b2e237e60999d62217dbd95136f3e9d6b5bff2211085943d7499341a0bca1ae8",
      "byte_length": 1175
    },
    "input-a--verification.json": {
      "sha256": "e0169bcf525531e1d4e4552b4e4e1bec56721364011c17ed0dc39f7506d5fcae",
      "byte_length": 17220
    },
    "input-a--verification.md": {
      "sha256": "f2618042b8a5743ff4b76fc29f55d788f5b7ece946fc30d96823e0a96067572d",
      "byte_length": 17654
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "1e3279fb6a843b75c215e1ef153966e3367360e9ac90d96ed5959b692e4b6db1",
      "byte_length": 3176
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a0101ee576543f32fc4831a1d91703368d2b9481778661cf18625f6bda868734",
      "byte_length": 12754
    },
    "input-b--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "965fdc3d45f6c5f105f5465e04eb7f9d9d01b30b713d098c8d47750035024706",
      "byte_length": 1176
    },
    "input-b--verification.json": {
      "sha256": "7b7782724354d247bf6964771a95ff11e0cacd2eb307aea0b7e3d94cc25551d2",
      "byte_length": 17229
    },
    "input-b--verification.md": {
      "sha256": "e7aa4f5a1b3ee9fa12164f1e72f467f4dc810d6633913c6bb8bf5a05d801a44a",
      "byte_length": 17663
    }
  }
}
```
