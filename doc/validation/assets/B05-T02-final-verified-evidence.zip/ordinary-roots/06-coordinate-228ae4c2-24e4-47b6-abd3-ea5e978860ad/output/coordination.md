# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：1；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "9c8b8e49-d8b2-4d34-8e54-8eaef9004d69",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
        "import_id": "e85e60e5-4b66-4931-bf1b-baf62e333ead",
        "source_id": "fefb4c34-190f-4fdc-a195-3836baf47bac",
        "version_id": "dc1206d6-a3ed-41f1-bd45-6e569a24f62d",
        "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "import_id": "e85e60e5-4b66-4931-bf1b-baf62e333ead",
              "manifest_sha256": null,
              "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "parse_id": null,
              "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
              "source_id": "fefb4c34-190f-4fdc-a195-3836baf47bac",
              "version_id": "dc1206d6-a3ed-41f1-bd45-6e569a24f62d"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "import_id": "e85e60e5-4b66-4931-bf1b-baf62e333ead",
              "manifest_sha256": null,
              "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "parse_id": null,
              "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
              "source_id": "fefb4c34-190f-4fdc-a195-3836baf47bac",
              "version_id": "dc1206d6-a3ed-41f1-bd45-6e569a24f62d"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 292,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 291,
            "excerpt_sha256": "3a377d0c0047e61517140a9e9d81a22d0109226858c9c6ddff7c6ccf12635769",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 212,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 100
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 291,
              "excerpt_sha256": "3a377d0c0047e61517140a9e9d81a22d0109226858c9c6ddff7c6ccf12635769",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "41d77be5348237719467a5c2a83883f173934301823965e07b6c7920714ee9e9",
          "byte_length": 3184
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "fce32fae293e342ea885b3e7631aed08b679d983f825af337cf20a5012c806bf",
          "byte_length": 12779
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "309e581dbd6a7fc93b671ab0c7757fe854e173bbde9d2b3071a0708717c491ae",
          "byte_length": 1184
        },
        "verification.json": {
          "sha256": "793156a4dde7baa7a17cc550e0129ddd27888ab7fb6c6562ed0f465a76734f9b",
          "byte_length": 17254
        },
        "verification.md": {
          "sha256": "2dc81221c56aab2acab165dfb00fb4f513885e666d729130f2710480a8a302c7",
          "byte_length": 17688
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
        "import_id": "46723334-bee3-49f0-84a6-440a98c77699",
        "source_id": "7e3e1550-c4f0-42fa-9e06-72a6be420c33",
        "version_id": "30ca2ee2-292f-466c-9aab-a33eabcd09a5",
        "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "import_id": "46723334-bee3-49f0-84a6-440a98c77699",
              "manifest_sha256": null,
              "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "parse_id": null,
              "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
              "source_id": "7e3e1550-c4f0-42fa-9e06-72a6be420c33",
              "version_id": "30ca2ee2-292f-466c-9aab-a33eabcd09a5"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "import_id": "46723334-bee3-49f0-84a6-440a98c77699",
              "manifest_sha256": null,
              "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "parse_id": null,
              "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
              "source_id": "7e3e1550-c4f0-42fa-9e06-72a6be420c33",
              "version_id": "30ca2ee2-292f-466c-9aab-a33eabcd09a5"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 294,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 295,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 294,
            "excerpt_sha256": "9e245f4dd2db8acf71a8f7b80bfcf356e8ce941df42a4c82be669c1d376eb45c",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 215,
            "quote": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
            "start_byte": 100
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 294,
              "excerpt_sha256": "9e245f4dd2db8acf71a8f7b80bfcf356e8ce941df42a4c82be669c1d376eb45c",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "11",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "11",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "幼年样本不适用",
          "actual": {
            "body": [
              "幼年样本不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": [
            "幼年样本不适用"
          ],
          "actual": [
            "幼年样本不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "幼年样本不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "幼年样本不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "4e015de57138a9495b1ae7aa7448e67e6a39f4b4476cf3cd9dc2c363d3394e94",
          "byte_length": 3193
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "952f1d39f3ed1444ab44b74d5b66839b713e2685264b6bc10fb538e022a7c1c1",
          "byte_length": 755
        },
        "knowledge-ir.json": {
          "sha256": "ec847c2d97b7b874dfd3567835539265728e9858cf90365858432324cec146c8",
          "byte_length": 12836
        },
        "review-original.json": {
          "sha256": "0ef7ce30c38760beb99e57b534681b1454dfbef8d0b4303c7776a8b3753f5c0f",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "1f49b809724b579684044187ce57b15713a9daf5afe70a4df7f0fa7735e5eb7d",
          "byte_length": 1187
        },
        "verification.json": {
          "sha256": "219cc66e6e84504089e6e14d11dc8fec281bf2cd05ae3e6e87c240608c7f7395",
          "byte_length": 17305
        },
        "verification.md": {
          "sha256": "f1198dc5814b4ec35fdf950100425e91c2245fe0adb3af749cc9bcc20680668b",
          "byte_length": 17739
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 45,
        "end_byte": 212,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-5844c3bdad758f21bdb72adf541fa0d308fdb918c4f8bd6fc0c817ee8247532a",
      "input_id": "a",
      "binding": {
        "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
        "import_id": "e85e60e5-4b66-4931-bf1b-baf62e333ead",
        "source_id": "fefb4c34-190f-4fdc-a195-3836baf47bac",
        "version_id": "dc1206d6-a3ed-41f1-bd45-6e569a24f62d",
        "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "41b0c9ee-e73c-4b7c-93d8-73301abaa7f6",
          "ordinal": 0,
          "resource_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 292,
        "text": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 291,
          "excerpt_sha256": "3a377d0c0047e61517140a9e9d81a22d0109226858c9c6ddff7c6ccf12635769",
          "quote": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 45,
        "end_byte": 215,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
        "sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8"
      },
      "occurrence_id": "occ-8d8f69beac4fa99e9cd0a2e23d73d4374bee4190e69735815b2b4d6e5df8f0bf",
      "input_id": "b",
      "binding": {
        "project_id": "16dd4806-790f-44d5-9bde-f84a92f9a40d",
        "import_id": "46723334-bee3-49f0-84a6-440a98c77699",
        "source_id": "7e3e1550-c4f0-42fa-9e06-72a6be420c33",
        "version_id": "30ca2ee2-292f-466c-9aab-a33eabcd09a5",
        "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f58b7d03-91d7-4754-8b5c-86f13d948f32",
          "ordinal": 0,
          "resource_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 295,
        "text": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "幼年样本不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "11",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 294,
          "excerpt_sha256": "9e245f4dd2db8acf71a8f7b80bfcf356e8ce941df42a4c82be669c1d376eb45c",
          "quote": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "11",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "幼年样本不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-3d9b6cb1be4c6856351dcef0e60f859de01fed6d6985d4845f0b5a0425d50b6a",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "11",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "幼年样本不适用"
      ],
      "occurrence_ids": [
        "occ-8d8f69beac4fa99e9cd0a2e23d73d4374bee4190e69735815b2b4d6e5df8f0bf"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-5844c3bdad758f21bdb72adf541fa0d308fdb918c4f8bd6fc0c817ee8247532a"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-5844c3bdad758f21bdb72adf541fa0d308fdb918c4f8bd6fc0c817ee8247532a",
      "right_occurrence_id": "occ-8d8f69beac4fa99e9cd0a2e23d73d4374bee4190e69735815b2b4d6e5df8f0bf",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 1,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c2c579fc6e7869167ebbd7b5027964c61836495b549234856d350ad53e571bbd",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "05df880ef0747e7d45af19e1f35c526b1ad21ee8ab1b0ab7b2de6b40609cc4e7",
      "byte_length": 41366
    },
    "coordination-original.json": {
      "sha256": "670ed13c53cc5259e47119a389a9d486ba9ed8e98548b3b2c1d41bb3d84836ca",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "6a9c406cd047139f73a34d3145d78466d685c02f672df19627b08179b91762fc",
      "byte_length": 1904
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "41d77be5348237719467a5c2a83883f173934301823965e07b6c7920714ee9e9",
      "byte_length": 3184
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-a--knowledge-ir.json": {
      "sha256": "fce32fae293e342ea885b3e7631aed08b679d983f825af337cf20a5012c806bf",
      "byte_length": 12779
    },
    "input-a--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "309e581dbd6a7fc93b671ab0c7757fe854e173bbde9d2b3071a0708717c491ae",
      "byte_length": 1184
    },
    "input-a--verification.json": {
      "sha256": "793156a4dde7baa7a17cc550e0129ddd27888ab7fb6c6562ed0f465a76734f9b",
      "byte_length": 17254
    },
    "input-a--verification.md": {
      "sha256": "2dc81221c56aab2acab165dfb00fb4f513885e666d729130f2710480a8a302c7",
      "byte_length": 17688
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "4e015de57138a9495b1ae7aa7448e67e6a39f4b4476cf3cd9dc2c363d3394e94",
      "byte_length": 3193
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "952f1d39f3ed1444ab44b74d5b66839b713e2685264b6bc10fb538e022a7c1c1",
      "byte_length": 755
    },
    "input-b--knowledge-ir.json": {
      "sha256": "ec847c2d97b7b874dfd3567835539265728e9858cf90365858432324cec146c8",
      "byte_length": 12836
    },
    "input-b--review-original.json": {
      "sha256": "0ef7ce30c38760beb99e57b534681b1454dfbef8d0b4303c7776a8b3753f5c0f",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "1f49b809724b579684044187ce57b15713a9daf5afe70a4df7f0fa7735e5eb7d",
      "byte_length": 1187
    },
    "input-b--verification.json": {
      "sha256": "219cc66e6e84504089e6e14d11dc8fec281bf2cd05ae3e6e87c240608c7f7395",
      "byte_length": 17305
    },
    "input-b--verification.md": {
      "sha256": "f1198dc5814b4ec35fdf950100425e91c2245fe0adb3af749cc9bcc20680668b",
      "byte_length": 17739
    }
  }
}
```
