# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：1；条件不适用：1；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "6d459818-1fbe-48a4-9c6b-6ef39214a013",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
        "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
        "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
        "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5",
        "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
              "manifest_sha256": null,
              "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "parse_id": null,
              "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
              "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
              "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
              "manifest_sha256": null,
              "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "parse_id": null,
              "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
              "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
              "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 201,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 202,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 201,
            "excerpt_sha256": "cc518f1d6e90535db7430d8befe8f1a61ba7fbf81eeceec14ba324121b8aef67",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 122,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 201,
              "excerpt_sha256": "cc518f1d6e90535db7430d8befe8f1a61ba7fbf81eeceec14ba324121b8aef67",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "d8874f110b79980b743a11851fe9148b73393ee9dbc10a325e278b3e55e4e368",
          "byte_length": 2833
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
          "byte_length": 502
        },
        "knowledge-ir.json": {
          "sha256": "7ca1aec053fb26735f2dd7584a55bf43a8ca5e016aa23110a933613ccda54826",
          "byte_length": 9629
        },
        "review-original.json": {
          "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "e99cac28276c9b256bbec94f1f61b593c32f0141cede08cd5961c63c99ebef3b",
          "byte_length": 1094
        },
        "verification.json": {
          "sha256": "468bb284a42c286f1c4c9c4ec8570969d877d31ae91f1243f80106bd77d4bc69",
          "byte_length": 14368
        },
        "verification.md": {
          "sha256": "d090e4732244880d529ad12eea45e611f21d46db60c1f9596c0a5619b3d6076c",
          "byte_length": 14802
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
        "import_id": "b1e6f7b2-e143-4616-9c55-787de8888c5f",
        "source_id": "1203f30d-3d0c-431e-bd37-16387872c2b5",
        "version_id": "beac3f26-b4d2-40e7-8cca-e52d4f23dbca",
        "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "import_id": "b1e6f7b2-e143-4616-9c55-787de8888c5f",
              "manifest_sha256": null,
              "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "parse_id": null,
              "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
              "source_id": "1203f30d-3d0c-431e-bd37-16387872c2b5",
              "version_id": "beac3f26-b4d2-40e7-8cca-e52d4f23dbca"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "import_id": "b1e6f7b2-e143-4616-9c55-787de8888c5f",
              "manifest_sha256": null,
              "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "parse_id": null,
              "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
              "source_id": "1203f30d-3d0c-431e-bd37-16387872c2b5",
              "version_id": "beac3f26-b4d2-40e7-8cca-e52d4f23dbca"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 201,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 202,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 201,
            "excerpt_sha256": "53db8a672319916c8c7de649d8e798d19963b66bf09a9ff5bdb719b566aa8f35",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 mixed_state/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 122,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 201,
              "excerpt_sha256": "53db8a672319916c8c7de649d8e798d19963b66bf09a9ff5bdb719b566aa8f35",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 mixed_state/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "cfc089cf374e5608b95e08f356ec646114a1c0845d2434ccf78d5a09a9c38958",
          "byte_length": 2833
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
          "byte_length": 502
        },
        "knowledge-ir.json": {
          "sha256": "a3b2266fc12262e24c05c4f12c7e420d734af93c4e62d631e1670dbfeae803c7",
          "byte_length": 9629
        },
        "review-original.json": {
          "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "af90f90bd23e4534f1c2dc51df5b72ef873ba787ae90cf939bb9403dee8120f0",
          "byte_length": 1094
        },
        "verification.json": {
          "sha256": "ecf05585a2bcdec7b76aa5e728e479f0e0c92277fd2cda8e0831832475f8950c",
          "byte_length": 14368
        },
        "verification.md": {
          "sha256": "7410a63ab657db74268c68419e86e9a12fbbd957db9de9fbddf195292fad9ff4",
          "byte_length": 14802
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 122,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf"
      },
      "occurrence_id": "occ-425837d3376c27f6f3f2c500fa69d3ce78e0fc10bfccab4c2c1a4524a0717004",
      "input_id": "b",
      "binding": {
        "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
        "import_id": "b1e6f7b2-e143-4616-9c55-787de8888c5f",
        "source_id": "1203f30d-3d0c-431e-bd37-16387872c2b5",
        "version_id": "beac3f26-b4d2-40e7-8cca-e52d4f23dbca",
        "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "178b0c57-4358-4dcf-a3d3-30b6877d401a",
          "ordinal": 0,
          "resource_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 202,
        "text": "公开自造资料 mixed_state/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 201,
          "excerpt_sha256": "53db8a672319916c8c7de649d8e798d19963b66bf09a9ff5bdb719b566aa8f35",
          "quote": "公开自造资料 mixed_state/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 122,
        "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c"
      },
      "occurrence_id": "occ-f0cfa27a9e5b4c4bbb0f6176a49e3a7761c5d7f9a70731d91b98fa8280ad2501",
      "input_id": "a",
      "binding": {
        "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
        "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
        "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
        "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5",
        "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "1f84585a-1d5f-45d0-86aa-84714063b97a",
          "ordinal": 0,
          "resource_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 202,
        "text": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 201,
          "excerpt_sha256": "cc518f1d6e90535db7430d8befe8f1a61ba7fbf81eeceec14ba324121b8aef67",
          "quote": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-1da6d05004f6bd481c6bb96052d871827dae806e88b506031ed6e8ce82b887f3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-425837d3376c27f6f3f2c500fa69d3ce78e0fc10bfccab4c2c1a4524a0717004"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-6ab0eaafb311279a433a705cf045860ad2f1a4a03140314f197488570ea28c98",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-f0cfa27a9e5b4c4bbb0f6176a49e3a7761c5d7f9a70731d91b98fa8280ad2501"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-425837d3376c27f6f3f2c500fa69d3ce78e0fc10bfccab4c2c1a4524a0717004",
      "right_occurrence_id": "occ-f0cfa27a9e5b4c4bbb0f6176a49e3a7761c5d7f9a70731d91b98fa8280ad2501",
      "relation": "needs_review",
      "issue_code": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d6bc308201972e98a6960aa8a3eacdf34d576064d7cbe14f83e344f09d762f03",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "452c6dca3c5ca5d4000f5b5f50d0b3b972174af34a826267a6b2a042498027ed",
      "byte_length": 4326
    },
    "identity-original.json": {
      "sha256": "7ae48bb312713fd0f4d3c08b2aeaf11a61d910bb658fbfdd90b0561aa80d8cab",
      "byte_length": 1915
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "d8874f110b79980b743a11851fe9148b73393ee9dbc10a325e278b3e55e4e368",
      "byte_length": 2833
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
      "byte_length": 502
    },
    "input-a--knowledge-ir.json": {
      "sha256": "7ca1aec053fb26735f2dd7584a55bf43a8ca5e016aa23110a933613ccda54826",
      "byte_length": 9629
    },
    "input-a--review-original.json": {
      "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "e99cac28276c9b256bbec94f1f61b593c32f0141cede08cd5961c63c99ebef3b",
      "byte_length": 1094
    },
    "input-a--verification.json": {
      "sha256": "468bb284a42c286f1c4c9c4ec8570969d877d31ae91f1243f80106bd77d4bc69",
      "byte_length": 14368
    },
    "input-a--verification.md": {
      "sha256": "d090e4732244880d529ad12eea45e611f21d46db60c1f9596c0a5619b3d6076c",
      "byte_length": 14802
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "cfc089cf374e5608b95e08f356ec646114a1c0845d2434ccf78d5a09a9c38958",
      "byte_length": 2833
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
      "byte_length": 502
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a3b2266fc12262e24c05c4f12c7e420d734af93c4e62d631e1670dbfeae803c7",
      "byte_length": 9629
    },
    "input-b--review-original.json": {
      "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "af90f90bd23e4534f1c2dc51df5b72ef873ba787ae90cf939bb9403dee8120f0",
      "byte_length": 1094
    },
    "input-b--verification.json": {
      "sha256": "ecf05585a2bcdec7b76aa5e728e479f0e0c92277fd2cda8e0831832475f8950c",
      "byte_length": 14368
    },
    "input-b--verification.md": {
      "sha256": "7410a63ab657db74268c68419e86e9a12fbbd957db9de9fbddf195292fad9ff4",
      "byte_length": 14802
    }
  }
}
```
