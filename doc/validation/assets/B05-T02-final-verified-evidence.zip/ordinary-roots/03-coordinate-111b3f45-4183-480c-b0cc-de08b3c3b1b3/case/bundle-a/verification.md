# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
      "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
      "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
      "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5",
      "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
      "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "1f84585a-1d5f-45d0-86aa-84714063b97a",
          "ordinal": 0,
          "resource_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 202,
        "text": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
    "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
    "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
    "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5",
    "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
    "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "d8874f110b79980b743a11851fe9148b73393ee9dbc10a325e278b3e55e4e368",
        "byte_length": 2833
      },
      "decision.json": {
        "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
        "byte_length": 502
      },
      "review.json": {
        "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
        "byte_length": 509
      }
    },
    "gold_sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
          "manifest_sha256": null,
          "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "parse_id": null,
          "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
          "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
          "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5"
        },
        "request_id": "synthetic-coordination-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "import_id": "75afb58b-803a-491c-82e8-e799cbb27abf",
          "manifest_sha256": null,
          "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "parse_id": null,
          "project_id": "df87fde2-6e8a-4abb-811d-eee7ff39ee18",
          "source_id": "04ad851a-4383-4d02-87f4-674d6e57dac7",
          "version_id": "004ddef1-6152-484a-9b01-cb423a2f8fa5"
        },
        "request_id": "synthetic-coordination-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 201,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 202,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 201,
        "excerpt_sha256": "cc518f1d6e90535db7430d8befe8f1a61ba7fbf81eeceec14ba324121b8aef67",
        "excerpt_start_byte": 0,
        "quote": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 122,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 91
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 201,
          "excerpt_sha256": "cc518f1d6e90535db7430d8befe8f1a61ba7fbf81eeceec14ba324121b8aef67",
          "excerpt_start_byte": 0,
          "quote": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "d8874f110b79980b743a11851fe9148b73393ee9dbc10a325e278b3e55e4e368",
      "byte_length": 2833
    },
    "decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
      "byte_length": 502
    },
    "knowledge-ir.json": {
      "sha256": "7ca1aec053fb26735f2dd7584a55bf43a8ca5e016aa23110a933613ccda54826",
      "byte_length": 9629
    },
    "review-original.json": {
      "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "e99cac28276c9b256bbec94f1f61b593c32f0141cede08cd5961c63c99ebef3b",
      "byte_length": 1094
    }
  }
}
```
