# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 2
      }
    ],
    "binding": {
      "project_id": "706e4458-0de9-4cce-97b0-c6ce619c3f10",
      "import_id": "6028a28f-b0d7-40d5-9906-6456b549b7c0",
      "source_id": "4f2070bd-2a6c-4e90-b40b-6fac76d8831d",
      "version_id": "21af0819-714e-4b35-b834-f4d88c04d440",
      "content_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
      "normalized_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a90a4de5-12a9-4909-b1c3-afca33f11c39",
          "ordinal": 2,
          "resource_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de"
        },
        "source_status": "parsed",
        "start_byte": 25,
        "end_byte": 302,
        "text": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "706e4458-0de9-4cce-97b0-c6ce619c3f10",
    "import_id": "6028a28f-b0d7-40d5-9906-6456b549b7c0",
    "source_id": "4f2070bd-2a6c-4e90-b40b-6fac76d8831d",
    "version_id": "21af0819-714e-4b35-b834-f4d88c04d440",
    "content_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
    "normalized_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "38d03b5940c01d1fd06572235c090d927fc0c490aa4c0042e9f3ceb60539639e",
        "byte_length": 3004
      },
      "decision.json": {
        "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
        "byte_length": 746
      },
      "review.json": {
        "sha256": "5d16d444187cf4365ed14eb84e8508319b3c173e519f448e6570ca55449cf592",
        "byte_length": 509
      }
    },
    "gold_sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
          "import_id": "6028a28f-b0d7-40d5-9906-6456b549b7c0",
          "manifest_sha256": null,
          "normalized_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
          "parse_id": null,
          "project_id": "706e4458-0de9-4cce-97b0-c6ce619c3f10",
          "source_id": "4f2070bd-2a6c-4e90-b40b-6fac76d8831d",
          "version_id": "21af0819-714e-4b35-b834-f4d88c04d440"
        },
        "request_id": "synthetic-coordination-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
          "import_id": "6028a28f-b0d7-40d5-9906-6456b549b7c0",
          "manifest_sha256": null,
          "normalized_sha256": "f840d98ae043b31d2070beb7d684b8e277da369a35c81ef87bdf9352a0b3e5de",
          "parse_id": null,
          "project_id": "706e4458-0de9-4cce-97b0-c6ce619c3f10",
          "source_id": "4f2070bd-2a6c-4e90-b40b-6fac76d8831d",
          "version_id": "21af0819-714e-4b35-b834-f4d88c04d440"
        },
        "request_id": "synthetic-coordination-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 110,
      "end_byte": 222,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 302,
        "start_byte": 25,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 222,
        "excerpt_sha256": "808c5fb64755e66a77964b090f53d391dc669e1aedba9830766bc82e87c685ce",
        "excerpt_start_byte": 110,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 222,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 110
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 222,
          "excerpt_sha256": "808c5fb64755e66a77964b090f53d391dc669e1aedba9830766bc82e87c685ce",
          "excerpt_start_byte": 110,
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 302,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "38d03b5940c01d1fd06572235c090d927fc0c490aa4c0042e9f3ceb60539639e",
      "byte_length": 3004
    },
    "decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "knowledge-ir.json": {
      "sha256": "eb7bd7fb914ca24fe4f24b641aa1b104f39b000981729d9382a421b125fe892e",
      "byte_length": 12259
    },
    "review-original.json": {
      "sha256": "5d16d444187cf4365ed14eb84e8508319b3c173e519f448e6570ca55449cf592",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "62137dc234b3ba750a09ecb4c47181a8c8c158dd39b07187bf536f56b2ce9b91",
      "byte_length": 1170
    }
  }
}
```
