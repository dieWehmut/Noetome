# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "2e1e5e23-260a-4850-8dd5-bb5b44ecc427",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
        "import_id": "9b9524ad-d997-417c-8d56-c8ebfb8dae0f",
        "source_id": "ca4e2e54-8b5e-470c-88ff-f4e01cea3c1a",
        "version_id": "d9c29487-9630-44bd-8451-3604e295af7d",
        "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "import_id": "9b9524ad-d997-417c-8d56-c8ebfb8dae0f",
              "manifest_sha256": null,
              "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "parse_id": null,
              "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
              "source_id": "ca4e2e54-8b5e-470c-88ff-f4e01cea3c1a",
              "version_id": "d9c29487-9630-44bd-8451-3604e295af7d"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "import_id": "9b9524ad-d997-417c-8d56-c8ebfb8dae0f",
              "manifest_sha256": null,
              "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "parse_id": null,
              "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
              "source_id": "ca4e2e54-8b5e-470c-88ff-f4e01cea3c1a",
              "version_id": "d9c29487-9630-44bd-8451-3604e295af7d"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 285,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 284,
            "excerpt_sha256": "54761e4eff6c1fb8c9a8451284be20e11859aa94c729660278911adb33928b58",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 overlapping_time/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 284,
              "excerpt_sha256": "54761e4eff6c1fb8c9a8451284be20e11859aa94c729660278911adb33928b58",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 overlapping_time/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "b741b2594af1e6757d62e3c3a54f2d6ca8aac4087475e2cd41d31e429b156406",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
          "byte_length": 743
        },
        "knowledge-ir.json": {
          "sha256": "cb2497860859550f96ab4dc064237200a5c52921a80e0b91c6107ab25208d9e6",
          "byte_length": 12749
        },
        "review-original.json": {
          "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "2e2f2c60cc47e02bdc58c65519498bba928f7e8e099fb7a15400234d01884c63",
          "byte_length": 1177
        },
        "verification.json": {
          "sha256": "60cad9765a3b3397ce9081d1880e97e93c7ebf8d25085f654982898d051646ad",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "b41ac9d8e53934069f6acf3b73b1ed708cb77dbb3e9a268c72832f1966339dd6",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
        "import_id": "d187162c-b8f0-4255-889e-ca268033632a",
        "source_id": "008a329e-579a-4965-a1f5-0bfd1be1de93",
        "version_id": "c4a0e87d-80ba-4eca-a2bc-13c332089f73",
        "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "import_id": "d187162c-b8f0-4255-889e-ca268033632a",
              "manifest_sha256": null,
              "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "parse_id": null,
              "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
              "source_id": "008a329e-579a-4965-a1f5-0bfd1be1de93",
              "version_id": "c4a0e87d-80ba-4eca-a2bc-13c332089f73"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "import_id": "d187162c-b8f0-4255-889e-ca268033632a",
              "manifest_sha256": null,
              "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "parse_id": null,
              "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
              "source_id": "008a329e-579a-4965-a1f5-0bfd1be1de93",
              "version_id": "c4a0e87d-80ba-4eca-a2bc-13c332089f73"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 289,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 288,
            "excerpt_sha256": "a0973b2b13a972032b1fc68a3c155b8e616d879ce705292ad59472fff07abf01",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 overlapping_time/b。\n适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 209,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 97
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 288,
              "excerpt_sha256": "a0973b2b13a972032b1fc68a3c155b8e616d879ce705292ad59472fff07abf01",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 overlapping_time/b。\n适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "50cd5298a024df6393e7f53bdc44fee0c4549399ceb9d611b5206f5c0d85c698",
          "byte_length": 3181
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "a8de828011f7f2c1c3c2b18617e8cf5408207a47bee1cf368c4db5d45923019e",
          "byte_length": 12769
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "7011980dd3956df79e56d7486bd4a11847d7451d9e563954d90eb77aa6ee061f",
          "byte_length": 1181
        },
        "verification.json": {
          "sha256": "f42d23b3fb7be0ef57114c1b9cf24dce6061e9088a0bc451a5c2a23c43329dbb",
          "byte_length": 17244
        },
        "verification.md": {
          "sha256": "96a19b1890a975a9f9a54d4ccf2fcb145fdfbb787a7065cd1ac2866b54fa2098",
          "byte_length": 17678
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "day",
          "value": "2020-12-01"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 209,
        "quote": "适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "ca4f28e3b10d58599852553d33adadf8c9fdd441bf02819ba893fd3412ef7b8e"
      },
      "occurrence_id": "occ-3bdf2a985d94b80ae423da18650001bf6c2e38b673af5c206a49b5212d6e50c2",
      "input_id": "b",
      "binding": {
        "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
        "import_id": "d187162c-b8f0-4255-889e-ca268033632a",
        "source_id": "008a329e-579a-4965-a1f5-0bfd1be1de93",
        "version_id": "c4a0e87d-80ba-4eca-a2bc-13c332089f73",
        "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "dfc7c928-f782-49e7-afcf-97e8d42b964a",
          "ordinal": 0,
          "resource_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 289,
        "text": "公开自造资料 overlapping_time/b。\n适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 288,
          "excerpt_sha256": "a0973b2b13a972032b1fc68a3c155b8e616d879ce705292ad59472fff07abf01",
          "quote": "公开自造资料 overlapping_time/b。\n适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-a019e527354d68cb4373f14d1f441ee7cf838776d612a6755154c556732a4165",
      "input_id": "a",
      "binding": {
        "project_id": "0c349c6f-a057-42ba-94fb-0f0302d6f4bb",
        "import_id": "9b9524ad-d997-417c-8d56-c8ebfb8dae0f",
        "source_id": "ca4e2e54-8b5e-470c-88ff-f4e01cea3c1a",
        "version_id": "d9c29487-9630-44bd-8451-3604e295af7d",
        "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "d82af30d-eaf0-433c-937f-d30b7d6753c1",
          "ordinal": 0,
          "resource_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 285,
        "text": "公开自造资料 overlapping_time/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 284,
          "excerpt_sha256": "54761e4eff6c1fb8c9a8451284be20e11859aa94c729660278911adb33928b58",
          "quote": "公开自造资料 overlapping_time/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "day",
        "value": "2020-12-01"
      },
      "fact_id": "fact-v2-686527072ebe4f9ab78283f0506fb4c6bcfb0eb6b3015aa82ed120defa1f9784",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-3bdf2a985d94b80ae423da18650001bf6c2e38b673af5c206a49b5212d6e50c2"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-a019e527354d68cb4373f14d1f441ee7cf838776d612a6755154c556732a4165"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-3bdf2a985d94b80ae423da18650001bf6c2e38b673af5c206a49b5212d6e50c2",
      "right_occurrence_id": "occ-a019e527354d68cb4373f14d1f441ee7cf838776d612a6755154c556732a4165",
      "relation": "needs_review",
      "issue_code": "COORD_TIME_NOT_COMPARABLE"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "a18982e3bc8093d53a3a7ec686c871cd13627e0411a564e7a5c6bebc49bf60a0",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "519cd0c10b0667793c27904647b38362c8961886ce83f31d86090847978ac14d",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "ebd7d11608edc659ca81c5561fc77e879c6be26003072c34f41ea3fcd7ca676a",
      "byte_length": 1913
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "b741b2594af1e6757d62e3c3a54f2d6ca8aac4087475e2cd41d31e429b156406",
      "byte_length": 3175
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "input-a--knowledge-ir.json": {
      "sha256": "cb2497860859550f96ab4dc064237200a5c52921a80e0b91c6107ab25208d9e6",
      "byte_length": 12749
    },
    "input-a--review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "2e2f2c60cc47e02bdc58c65519498bba928f7e8e099fb7a15400234d01884c63",
      "byte_length": 1177
    },
    "input-a--verification.json": {
      "sha256": "60cad9765a3b3397ce9081d1880e97e93c7ebf8d25085f654982898d051646ad",
      "byte_length": 17226
    },
    "input-a--verification.md": {
      "sha256": "b41ac9d8e53934069f6acf3b73b1ed708cb77dbb3e9a268c72832f1966339dd6",
      "byte_length": 17660
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "50cd5298a024df6393e7f53bdc44fee0c4549399ceb9d611b5206f5c0d85c698",
      "byte_length": 3181
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a8de828011f7f2c1c3c2b18617e8cf5408207a47bee1cf368c4db5d45923019e",
      "byte_length": 12769
    },
    "input-b--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "7011980dd3956df79e56d7486bd4a11847d7451d9e563954d90eb77aa6ee061f",
      "byte_length": 1181
    },
    "input-b--verification.json": {
      "sha256": "f42d23b3fb7be0ef57114c1b9cf24dce6061e9088a0bc451a5c2a23c43329dbb",
      "byte_length": 17244
    },
    "input-b--verification.md": {
      "sha256": "96a19b1890a975a9f9a54d4ccf2fcb145fdfbb787a7065cd1ac2866b54fa2098",
      "byte_length": 17678
    }
  }
}
```
