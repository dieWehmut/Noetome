# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：1。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "ee93ebac-3d14-4e65-9775-75c6c97496fa",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
        "import_id": "e0e95949-72ab-4f63-a2f0-8b04e5e2ac7d",
        "source_id": "91198242-4ef0-4170-acd1-ebfeb53252d5",
        "version_id": "e924a7fb-e5f3-4c13-8f35-20a3bb9b6fb5",
        "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "import_id": "e0e95949-72ab-4f63-a2f0-8b04e5e2ac7d",
              "manifest_sha256": null,
              "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "parse_id": null,
              "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
              "source_id": "91198242-4ef0-4170-acd1-ebfeb53252d5",
              "version_id": "e924a7fb-e5f3-4c13-8f35-20a3bb9b6fb5"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "import_id": "e0e95949-72ab-4f63-a2f0-8b04e5e2ac7d",
              "manifest_sha256": null,
              "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "parse_id": null,
              "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
              "source_id": "91198242-4ef0-4170-acd1-ebfeb53252d5",
              "version_id": "e924a7fb-e5f3-4c13-8f35-20a3bb9b6fb5"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 275,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 276,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 275,
            "excerpt_sha256": "830b3266cbe04a521fc58d6c6e0260b9fb1e369940eb75fe11abf0fe17fdbc6b",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 196,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 85
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 275,
              "excerpt_sha256": "830b3266cbe04a521fc58d6c6e0260b9fb1e369940eb75fe11abf0fe17fdbc6b",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "22a185e82915e1e77ede8480169e051a288e77b05690aa8f60fea8fa571f7ae5",
          "byte_length": 3166
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
          "byte_length": 743
        },
        "knowledge-ir.json": {
          "sha256": "757d90c27ab429e34d837e2abdf2518546eb2e57578752345528f8aec6b719d8",
          "byte_length": 12722
        },
        "review-original.json": {
          "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "405baeb5347d92b39d998c0f04476ca39eebdadc7af4f0eaa4c9f35553e1133f",
          "byte_length": 1168
        },
        "verification.json": {
          "sha256": "e6a8d4dfd26b3c9286c5b457e7d96e7458cb4df2c709aa8cb019e28b3da30efc",
          "byte_length": 17199
        },
        "verification.md": {
          "sha256": "36685c7ad69ff4d80d9c3438e325a247b6a35d4884f64cd4ccfaa855ee063b01",
          "byte_length": 17633
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
        "import_id": "1b43e82a-0ce1-4011-bbfd-009a638ea217",
        "source_id": "ca193d8b-545b-4633-9063-771399c0a0a8",
        "version_id": "e68c4822-339c-4948-b9c9-e3dac9f1c33d",
        "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "import_id": "1b43e82a-0ce1-4011-bbfd-009a638ea217",
              "manifest_sha256": null,
              "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "parse_id": null,
              "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
              "source_id": "ca193d8b-545b-4633-9063-771399c0a0a8",
              "version_id": "e68c4822-339c-4948-b9c9-e3dac9f1c33d"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "import_id": "1b43e82a-0ce1-4011-bbfd-009a638ea217",
              "manifest_sha256": null,
              "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "parse_id": null,
              "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
              "source_id": "ca193d8b-545b-4633-9063-771399c0a0a8",
              "version_id": "e68c4822-339c-4948-b9c9-e3dac9f1c33d"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 277,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 276,
            "excerpt_sha256": "839f7bf75f7a23164b97d31d933c0f329a1e404c27803ea147f03712b3ef004e",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 197,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 85
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 276,
              "excerpt_sha256": "839f7bf75f7a23164b97d31d933c0f329a1e404c27803ea147f03712b3ef004e",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "2952606ec248931d5f5964d5527641478429d57617b22be369d29faa1338aba0",
          "byte_length": 3169
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "c9cafae315a58fef1192696b84895b45689eaf2436ba79ba48704f4cf7235cb4",
          "byte_length": 12733
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "2dcc8579ba2b98d03d0ffee07eaf694989c578019f5e95632c3d985c0907cf53",
          "byte_length": 1169
        },
        "verification.json": {
          "sha256": "a217a36391cdc0149db2a7593a5118726f8673001d3155e667bd193cc9b8e1c9",
          "byte_length": 17208
        },
        "verification.md": {
          "sha256": "c15525b8edb3f0c57a024dc9acca925342118cf5d8e29f3892eb5aa81045e5d1",
          "byte_length": 17642
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2024"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 32,
        "end_byte": 197,
        "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96"
      },
      "occurrence_id": "occ-13ac385dc05c866e6b448744beb6187d15b36d9b0e5a20c97ccd5dbfaaaa27eb",
      "input_id": "b",
      "binding": {
        "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
        "import_id": "1b43e82a-0ce1-4011-bbfd-009a638ea217",
        "source_id": "ca193d8b-545b-4633-9063-771399c0a0a8",
        "version_id": "e68c4822-339c-4948-b9c9-e3dac9f1c33d",
        "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "57396549-e11f-4178-9680-dcbadf030ddd",
          "ordinal": 0,
          "resource_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 277,
        "text": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 276,
          "excerpt_sha256": "839f7bf75f7a23164b97d31d933c0f329a1e404c27803ea147f03712b3ef004e",
          "quote": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 32,
        "end_byte": 196,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-ced94b9b652d0c86429950e296e0dc294ca93ebd2158217d57fadc07d98da155",
      "input_id": "a",
      "binding": {
        "project_id": "41966594-996d-498b-8a93-a3745031ad7d",
        "import_id": "e0e95949-72ab-4f63-a2f0-8b04e5e2ac7d",
        "source_id": "91198242-4ef0-4170-acd1-ebfeb53252d5",
        "version_id": "e924a7fb-e5f3-4c13-8f35-20a3bb9b6fb5",
        "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4b0ece60-9c35-45af-a79f-2f8368551062",
          "ordinal": 0,
          "resource_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 276,
        "text": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 275,
          "excerpt_sha256": "830b3266cbe04a521fc58d6c6e0260b9fb1e369940eb75fe11abf0fe17fdbc6b",
          "quote": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2024"
      },
      "fact_id": "fact-v2-54940b4aa46cc077b253f0197434c586029bbcdd699ddf5bbb60d32c8c20f632",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-13ac385dc05c866e6b448744beb6187d15b36d9b0e5a20c97ccd5dbfaaaa27eb"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-ced94b9b652d0c86429950e296e0dc294ca93ebd2158217d57fadc07d98da155"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": "occ-ced94b9b652d0c86429950e296e0dc294ca93ebd2158217d57fadc07d98da155",
      "later_occurrence_id": "occ-13ac385dc05c866e6b448744beb6187d15b36d9b0e5a20c97ccd5dbfaaaa27eb",
      "left_occurrence_id": "occ-13ac385dc05c866e6b448744beb6187d15b36d9b0e5a20c97ccd5dbfaaaa27eb",
      "right_occurrence_id": "occ-ced94b9b652d0c86429950e296e0dc294ca93ebd2158217d57fadc07d98da155",
      "relation": "historical_evolution",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 1,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "f3b189841226561b38f0f2252a351587ef0db390f0800749666b6024f9761d78",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "4550f3455816073ec388da2f01e094f16e6898d47057d2decd59f15f2ae085fa",
      "byte_length": 41299
    },
    "coordination-original.json": {
      "sha256": "788b696c078587f435d0c83fe2e8c0cdf8755807ccbbf15068b4ef779be55c6f",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "895a85645a1d0b1a27d10ca2ba23c33ee6228603c58a716335f847e2299294c6",
      "byte_length": 1908
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "22a185e82915e1e77ede8480169e051a288e77b05690aa8f60fea8fa571f7ae5",
      "byte_length": 3166
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "input-a--knowledge-ir.json": {
      "sha256": "757d90c27ab429e34d837e2abdf2518546eb2e57578752345528f8aec6b719d8",
      "byte_length": 12722
    },
    "input-a--review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "405baeb5347d92b39d998c0f04476ca39eebdadc7af4f0eaa4c9f35553e1133f",
      "byte_length": 1168
    },
    "input-a--verification.json": {
      "sha256": "e6a8d4dfd26b3c9286c5b457e7d96e7458cb4df2c709aa8cb019e28b3da30efc",
      "byte_length": 17199
    },
    "input-a--verification.md": {
      "sha256": "36685c7ad69ff4d80d9c3438e325a247b6a35d4884f64cd4ccfaa855ee063b01",
      "byte_length": 17633
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "2952606ec248931d5f5964d5527641478429d57617b22be369d29faa1338aba0",
      "byte_length": 3169
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "c9cafae315a58fef1192696b84895b45689eaf2436ba79ba48704f4cf7235cb4",
      "byte_length": 12733
    },
    "input-b--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "2dcc8579ba2b98d03d0ffee07eaf694989c578019f5e95632c3d985c0907cf53",
      "byte_length": 1169
    },
    "input-b--verification.json": {
      "sha256": "a217a36391cdc0149db2a7593a5118726f8673001d3155e667bd193cc9b8e1c9",
      "byte_length": 17208
    },
    "input-b--verification.md": {
      "sha256": "c15525b8edb3f0c57a024dc9acca925342118cf5d8e29f3892eb5aa81045e5d1",
      "byte_length": 17642
    }
  }
}
```
