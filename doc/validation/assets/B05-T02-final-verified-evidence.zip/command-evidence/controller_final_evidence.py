"""Independently inspect final original streams/pins and archive all gates."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import stat
import subprocess
import zipfile

REPO = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
ASSETS = REPO / 'doc/validation/assets'
TARGET = ASSETS / 'B05-T02-final-verified-evidence.zip'
MANIFEST = ASSETS / 'B05-T02-final-verified-evidence.json'
assert not TARGET.exists() and not MANIFEST.exists()


def pin(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))


def load(path):
    return json.loads(path.read_bytes())


def checked(path, expected):
    path = Path(path)
    assert pin(path.read_bytes()) == {k: expected[k] for k in ('sha256', 'byte_length')}, path


def ordinary_spelling(path):
    path = Path(path).resolve()
    if str(path).startswith('\\\\?\\'):
        candidate = Path(str(path)[4:])
        assert candidate.samefile(path), path
        path = candidate
    return path


stable = load(WORK / 'final-fix-stable-final-verification.json')
assert stable['before'] == stable['after']
for path, expected in stable['after'].items():
    checked(path, expected)
for path, expected in stable['binaries_after'].items():
    checked(path, expected)
assert [r['exit_code'] for r in stable['commands']] == [0, 0, 0]
for command in stable['commands']:
    for stream in ('stdout', 'stderr'):
        checked(command[stream]['path'], command[stream])
raw = Path(stable['commands'][-1]['stdout']['path']).read_text(encoding='utf8')
results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', raw)
assert len(results) == 17 and tuple(sum(int(r[i]) for r in results) for i in range(3)) == (591, 0, 0)
rust_roots = set()
for mode in ('red-preparation', 'red', 'green', 'stable-final'):
    record = load(WORK / ('final-fix-' + mode + '-verification.json'))
    for command in record['commands']:
        for stream in ('stdout', 'stderr'):
            # Preparation records keep old stream paths; the preserved relocation
            # receipt maps them without rewriting historical receipt content.
            p = Path(command[stream]['path'])
            if mode == 'red-preparation':
                suffix = '.stdout.txt' if stream == 'stdout' else '.stderr.txt'
                p = WORK / ('final-fix-red-preparation-focused' + suffix)
            checked(p, command[stream])
    for root in record.get('roots', []):
        actual = Path(root['root'])
        assert ordinary_spelling(actual).is_relative_to(ordinary_spelling(REPO / 'target')), actual
        rust_roots.add(actual)
        for path, expected in root['protected'].items():
            checked(path, expected)
        for path, expected in root.get('receipts', {}).items():
            checked(path, expected)

independent = WORK / 'final-independent'
summary = load(independent / 'summary.json')
assert summary['python_tests'] == 157
cli = pin((REPO / 'target/debug/noetome.exe').read_bytes())
assert summary['cli'] == cli
python = load(independent / 'python-workspace.json')
assert python['exit_code'] == 0 and python['before'] == python['after']
for path, expected in python['after'].items():
    checked(path, expected)
for gate in ('python-workspace', 'audit-v2', 'audit-v1', 'devlog', 'git-diff'):
    record = load(independent / (gate + '.json'))
    assert record['exit_code'] == 0 and record['before'] == record['after'], gate
    for stream in ('stdout', 'stderr'):
        checked(record[stream]['path'], record[stream])
audit_checks = {}
for name, counts in (('audit-v2', (42, 126)), ('audit-v1', (33, 56))):
    audit = load(independent / name / 'audit.json')
    assert (audit['scenario_count'], audit['command_count']) == counts
    assert audit['protected_before'] == audit['protected_after']
    assert audit['cli_fingerprint'] == cli
    for call in audit['calls']:
        assert call['exit_code'] == call['expected_exit']
        for stream in ('stdout', 'stderr'):
            checked(call[stream]['path'], call[stream])
        if 'cli_before' in call:
            assert call['cli_before'] == call['cli_after'] == cli
    audit_checks[name] = dict(scenarios=counts[0], commands=counts[1], protected_groups=len(audit['protected_after']))
green = load(WORK / 'final-fix-offset-green/evidence.json')
assert green['actual_exit'] == green['expected_exit'] == 0 and len(green['calls']) == 7
assert all(c['exit_code'] == 0 for c in green['calls'])
assert green['source_case_unchanged'] and green['protected_originals_unchanged']
for call in green['calls']:
    for stream in ('stdout', 'stderr'):
        checked(call[stream]['path'], call[stream])

review = (WORK / 'final-rereview.md').read_text(encoding='utf8')
assert 'ADDRESSED' in review and 'NOT ADDRESSED' not in review
assert 'R1' in review and 'R2' in review
fix_head = subprocess.check_output(['git', 'rev-parse', '01742df'], cwd=REPO).decode().strip()
for name in ('knowledge_coordinate_context.rs', 'knowledge_coordination_v2_model.rs'):
    relative = 'crates/noetome-cli/src/' + name
    blob = subprocess.check_output(['git', 'show', fix_head + ':' + relative], cwd=REPO)
    assert pin(blob) == pin((REPO / relative).read_bytes()), relative
selected = {p for p in WORK.glob('final-fix*') if p.is_file()}
selected.update(p for p in WORK.glob('final-rereview*') if p.is_file())
selected.update(WORK / n for n in ('progress.md', 'review-b3a31ea..01742df.diff',
    'controller_final_independent.py', 'controller_final_documents.py', 'controller_final_evidence.py'))
roots = [*sorted(rust_roots), independent, WORK / 'final-fix-offset-green']
python_output = Path(python['stdout']['path']).read_text(encoding='utf8')
match = re.search(r'Retained actual v2 test root: (.+)', python_output)
assert match
roots.append(Path(match[1].strip()))
omitted, reparse = [], []


def files(root):
    actual = ordinary_spelling(root)
    assert actual.is_relative_to(ordinary_spelling(WORK)) or actual.is_relative_to(ordinary_spelling(REPO / 'target')), root
    pending = [root]
    while pending:
        directory = pending.pop()
        for entry in sorted(os.scandir(directory), key=lambda e: e.name):
            path = Path(entry.path)
            info = path.lstat()
            if getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                reparse.append(str(path))
            elif entry.is_dir(follow_symlinks=False):
                pending.append(path)
            elif entry.is_file(follow_symlinks=False):
                if re.fullmatch(r'audit-\d+\.json', path.name):
                    omitted.append(dict(path=str(path), **pin(path.read_bytes())))
                else:
                    yield path
            else:
                raise AssertionError(str(path))


members = {}
with zipfile.ZipFile(TARGET, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    def add(path, name):
        assert name not in members
        raw = path.read_bytes()
        members[name] = pin(raw)
        archive.writestr(name, raw)
    for path in sorted(selected):
        add(path, 'command-evidence/' + path.name)
    for index, root in enumerate(roots):
        for path in files(root):
            add(path, f'ordinary-roots/{index:02d}-{root.name}/' + path.relative_to(root).as_posix())
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members)
    for name, expected in members.items():
        assert pin(archive.read(name)) == expected
result = dict(checked_at=datetime.now(timezone.utc).isoformat(), cli=cli,
    rust=dict(suites=17, passed=591, failed=0, ignored=0, sources=len(stable['after']),
        binaries=len(stable['binaries_after']), protected_variants_roots=len(stable['roots'])),
    python=dict(passed=157, failed=0, ignored=0, source_pins=len(python['after'])),
    audits=audit_checks, nonzero_offset_independent_commands=7,
    green_provenance=dict(original_receipt_base_label=green['base'], original_receipt_head_label=green['head'],
        label_semantics='Inherited original-probe constants, not a sampled execution Git HEAD. The original receipt is preserved unchanged.',
        accepted_fix_head=fix_head, actual_executed_cli=cli,
        actual_source_and_cli_pins_rechecked=True,
        clarification='Final GREEN behavior is tied to its raw command CLI/source fingerprints and the same committed fix source. Original e1c3e08/b3a31ea labels do not assert that the old binary passed.'),
    archive=pin(TARGET.read_bytes()), members=members, all_crc_and_member_bytes_checked=True,
    omitted_progress_snapshots=omitted, skipped_reparse_paths=reparse,
    timestamp_note='Controller independent command started_at fields are receipt capture timestamps after the subprocess, not process-start timestamps. Raw streams/exit and monotonic outer elapsed values are preserved.',
    limitations='Full original test and audit results with selected synthetic author/source inputs. No scientific, arbitrary semantics, conversion, production Vault, cross-platform, or scale benchmark acceptance inferred.')
MANIFEST.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(archive=str(TARGET), members=len(members), bytes=TARGET.stat().st_size,
    rust=591, python=157, audits=audit_checks, omitted_snapshots=len(omitted), reparse_skipped=len(reparse)), ensure_ascii=False))
