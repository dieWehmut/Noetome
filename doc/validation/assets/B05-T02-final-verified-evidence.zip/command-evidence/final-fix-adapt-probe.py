from pathlib import Path
work=Path('D:/Noetome/.superpowers/sdd/B05-T02_VARIANTS_PLAN')
source=(work/'final-review-offset-probe.py').read_text(encoding='utf8')
source=source.replace("ROOT = WORK / 'final-review-offset-probe'", "ROOT = WORK / 'final-fix-offset-green'")
source=source.replace('ROOT.mkdir()', '''pins_before.update({str(p):fingerprint(p.read_bytes()) for p in [WORK/'final-review-offset-probe.py', *list((WORK/'final-review-offset-probe').rglob('*'))] if p.is_file()})
ROOT.mkdir()''')
source=source.replace('def call(label, args, expected=0):', 'def call(label, args, expected=0, program=CLI):')
source=source.replace('argv=[str(CLI), *map(str,args)]', 'argv=[str(program), *map(str,args)]')
source=source.replace('after=[inventory(p) for p in (project,case)]', '''assert author['expected']['expected_status']=='passed' and run.returncode==0
check_before=[inventory(p) for p in (project,case,ROOT/'output')]
checked=call('05-independent-check',[REPO/'scripts/verify_knowledge_coordination.py','check',project,case,ROOT/'output',ROOT/'expected.json'],program=Path(sys.executable))
assert checked.returncode==0
independent=strict_json(checked.stdout)
assert independent['independently_verified'] is True
assert independent['status']==author['expected']['expected_status']
assert independent['totals']==author['expected']['totals']
assert sorted(independent['inputs'])==sorted(i['input_id'] for i in author['inputs'])
check_after=[inventory(p) for p in (project,case,ROOT/'output')]
assert check_before==check_after
after=[inventory(p) for p in (project,case)]''')
source=source.replace("actual_exit=run.returncode,stderr=run.stderr.decode('utf8'),output_exists=", "independent_check=independent, independent_check_before=check_before, independent_check_after=check_after, actual_exit=run.returncode,stderr=run.stderr.decode('utf8'),output_exists=")
source=source.replace("scope='Single ordinary CLI nonzero-source-unit-offset probe; no suite/audit rerun'", "scope='Independent GREEN replay of original nonzero-offset counterexample plus ordinary full-author check; original probe untouched'")
(work/'final-fix-offset-green.py').write_text(source,encoding='utf8',newline='\n')
print('Created separate GREEN script; original probe/root preserved.')
