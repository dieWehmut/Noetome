"""Local final-fix receipts, preserving raw commands and dependency snapshots."""
from pathlib import Path
import hashlib, json, os, re, subprocess, sys, time

REPO = Path('D:/Noetome')
WORK = REPO / '.superpowers/sdd/B05-T02_VARIANTS_PLAN'
PYTHON = sys.executable
env = os.environ.copy()
env.update(NOETOME_TEST_PYTHON=PYTHON, NOETOME_PDF_PYTHON=PYTHON)
mode = sys.argv[1]
commands = [('focused', "& './scripts/cargo_local.ps1' test -p noetome-cli --locked --offline --test knowledge_variants nonzero_source_unit '--' --test-threads=4 --nocapture")]
if mode.startswith('stable'):
    commands = [('fmt', "& './scripts/cargo_local.ps1' fmt --all --check"),
                ('check', "& './scripts/cargo_local.ps1' check --workspace --locked --offline"),
                ('workspace', "& './scripts/cargo_local.ps1' test --workspace --locked --offline '--' --test-threads=4 --nocapture")]

def pin(path):
    raw = Path(path).read_bytes()
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))

paths = subprocess.check_output(['git', 'ls-files', '-z', 'crates', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo', 'scripts/cargo_local.ps1'], cwd=REPO).decode().split('\0')
sources = {REPO/p for p in paths if p}
sources.update((REPO/'crates').rglob('*.rs'))
sources.update((REPO/'scripts').glob('*.py'))
sources.update((REPO/'fixtures/knowledge-coordination-v2').iterdir())
def snapshot():
    return {str(p): pin(p) for p in sorted(sources) if p.is_file()}
def binaries():
    paths = [REPO/'target/debug/noetome.exe', *list((REPO/'target/debug/deps').glob('*.exe'))]
    return {str(p): pin(p) for p in paths if p.exists()}

result = dict(mode=mode, runner_argv=sys.argv, cwd=str(Path.cwd()), python=pin(PYTHON),
              environment={k:env.get(k) for k in ['NOETOME_TEST_PYTHON', 'NOETOME_PDF_PYTHON', 'PATH', 'TEMP', 'TMP', 'RUSTUP_HOME', 'CARGO_HOME']},
              before=snapshot(), binaries_before=binaries(), commands=[])
for label, command in commands:
    argv = ['powershell.exe', '-NoProfile', '-Command', command]
    stdout = WORK/f'final-fix-{mode}-{label}.stdout.txt'
    stderr = WORK/f'final-fix-{mode}-{label}.stderr.txt'
    started = time.time()
    cli_before = pin(REPO/'target/debug/noetome.exe')
    print('START', label, command, flush=True)
    with stdout.open('wb') as out, stderr.open('wb') as err:
        p = subprocess.run(argv, cwd=REPO, env=env, stdout=out, stderr=err)
    receipt = dict(argv=argv,cwd=str(REPO),start_unix=started,elapsed_seconds=time.time()-started,exit_code=p.returncode,
                   stdout=dict(path=str(stdout),**pin(stdout)),stderr=dict(path=str(stderr),**pin(stderr)),
                   cli_before=cli_before,cli_after=pin(REPO/'target/debug/noetome.exe'))
    result['commands'].append(receipt)
    (WORK/f'final-fix-{mode}-{label}.command.json').write_text(json.dumps(receipt, indent=2),encoding='utf8')
    print('END', label, p.returncode, receipt['elapsed_seconds'], flush=True)
    if p.returncode and mode != 'red':
        break
result.update(after=snapshot(), binaries_after=binaries())
result['sources_unchanged'] = result['before']==result['after']
result['roots']=[]
for receipt in result['commands']:
    log=Path(receipt['stdout']['path']).read_text(encoding='utf-8-sig')
    receipt['suites']=re.findall(r'test result: (.+)',log)
    for match in re.finditer(r'prepared_variants_root=(.+?) case=(\S+)',log):
        root=Path(match[1])
        before=json.loads((root/'protection-before.json').read_text(encoding='utf8'))
        after=json.loads((root/'protection-after.json').read_text(encoding='utf8'))
        assert before==after, root
        for path,expected in after.items(): assert pin(path)==expected, path
        result['roots'].append(dict(root=str(root),case=match[2],protected=after,
                                  cli_sha256=(root/'cli-sha256.txt').read_text(),
                                  receipts={str(p):pin(p) for p in root.glob('*-*.*') if p.suffix in ['.txt','.json']}))
(WORK/f'final-fix-{mode}-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
assert result['sources_unchanged']
print(json.dumps(dict(mode=mode,exit_codes=[r['exit_code'] for r in result['commands']],suites=[r['suites'] for r in result['commands']],root_count=len(result['roots'])),ensure_ascii=False),flush=True)
