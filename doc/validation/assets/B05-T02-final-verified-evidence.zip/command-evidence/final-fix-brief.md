# B05-T02 final review fix wave

Read this first. This is your complete fix scope in the existing D:/Noetome checkout at b3a31eaf87be8bbd4c119f4af19c92aefd958ca8. Product task B05-T02 remains in_progress. This is the single final fix wave; do not start B05-T03 or any other product task.

## Binding inputs

- Full final findings: `.superpowers/sdd/B05-T02_VARIANTS_PLAN/final-review.md` (R1 Important and R2 optional Minor).
- Strict contract: `doc/technical/KNOWLEDGE_VARIANTS_CONTRACT.md`, inherited `KNOWLEDGE_COORDINATION_CONTRACT.md` and original extraction evidence coordinate contract.
- Actual failing six-call source-backed counterexample and original receipts: `.superpowers/sdd/B05-T02_VARIANTS_PLAN/final-review-offset-probe.py` and `final-review-offset-probe/`. Both selected text units are ordinal 2, unit.start_byte=25; context/support absolute start=57. Both ordinary extract verify calls succeed; Python source_bundle/rebuild_context accept; coordinate rejects COORD_CONTEXT/3 versus frozen author0.

## Required changes

R1: `knowledge_coordinate_context.rs` uses local indices into u.text to compare absolute candidate evidence positions. Verify this root cause against extraction.rs and the original counterexample. Write an ordinary source-backed regression selecting a text unit with unit.start_byte > 0, preserving the frozen history author semantics, all supports and emitted absolute context ranges. Run it on the old production implementation and save a genuine failing RED (upstream reviews must succeed). Then compare coverage consistently in absolute source coordinates, correct the misleading comment, and run the regression GREEN. Keep the existing refusal of support that only covers the fact; include that protection at a nonzero unit offset if useful to demonstrate both sides of the gate. Do not edit original fixtures/gold/expected to accommodate the bug.

R2: After the behavior is GREEN, format the dense v2 DTO macro invocations with one field per line, retaining every field, order, nullable deserializer and wire rule. This is optional readability from both reviews; include it in this same wave as a separate small commit if it improves reviewability. No tests solely mirroring whitespace.

Production ownership: `crates/noetome-cli/src/knowledge_coordinate_context.rs` and (if R2) `knowledge_coordination_v2_model.rs`. Tests may extend `tests/knowledge_variants.rs` and `tests/support/coordination_variants_case.rs`. Do not change Python production, contracts, generated logs, original fixtures, other source behavior or user docs deletions. If anything larger is required, report the concrete finding to root before expanding scope.

## Verification and reports

- Use systematic-debugging, test-driven-development (including writing-good-tests.md), and verification-before-completion. No child subagents.
- The selected Python executable is `C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`. Supply it to the existing test environment through NOETOME_TEST_PYTHON. Do not hardcode it in repository programs.
- Use scripts/cargo_local.ps1 with explicit --locked --offline on check/test and explicit test threads=4. Save real argv/cwd/environment of selected test runtime, raw stdout/stderr, exit/elapsed time, whole Rust source/build/test fingerprints before/after stable tests and actual CLI fingerprints. No stdout summary can substitute for original command output.
- Run focused regression RED then GREEN; after final code, fmt --all --check, check --workspace --locked --offline, and test --workspace --locked --offline -- --test-threads=4 --nocapture once. Root will run the Python full suite and independent v1/v2 audits after the binary is stable; do not duplicate those complete matrices.
- For independent nonzero-offset GREEN, adapt the original probe to a separate new root; preserve the old failing root untouched. Assert all complete author expectations through ordinary independent check, not just exit0. Save full ordinary output and source protection before/after.
- Commit only your exact code/test files in meaningful small commits after verification. Do not touch index entries for the two user-deleted docs; do not push or transition tasks. No credentials/network/model/production Vault actions.
- Write complete report to `.superpowers/sdd/B05-T02_VARIANTS_PLAN/final-fix-report.md`: root cause, RED/GREEN paths, original author preservation, commits, full stable commands/counts/results, snapshot paths, self-review and all remaining concerns. Return only DONE/concerns, commits and one-line checks.

Root will inspect the changes and raw evidence, generate one fix-range package, dispatch one scoped re-review, then complete the remaining product gates.
