"""Check actual final document links, frozen authors, ledger and diff gates."""
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re
import subprocess
import sys

REPO = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
STAGE = sys.argv[1]
TARGET = REPO / 'doc/validation/assets' / ('B05-T02-' + STAGE + '-documents.json')
assert re.fullmatch('[a-z0-9-]+', STAGE) and not TARGET.exists()
FILES = [
    'doc/README.md', 'doc/execution/NEXT_STEPS.md', 'doc/execution/B05-T02_VARIANTS_PLAN.md',
    'doc/validation/B05-T02.md', 'doc/standards/DESIGN.md', 'doc/standards/TESTING.md',
    'doc/technical/ARCHITECTURE.md', 'doc/technical/DATA_CONTRACTS.md',
    'doc/technical/KNOWLEDGE_VARIANTS_CONTRACT.md', 'doc/technical/KNOWLEDGE_COORDINATION_CONTRACT.md',
    'fixtures/knowledge-coordination-v2/README.md',
]


def pin(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))


links = []
for name in FILES:
    path = REPO / name
    for label, target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', path.read_text(encoding='utf8')):
        target = target.strip('<>').split('#', 1)[0]
        if not target or re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target):
            continue
        actual = (path.parent / unquote(target)).resolve()
        assert actual.is_relative_to(REPO) and actual.exists(), (name, target)
        links.append(dict(file=name, target=target))
freeze = json.loads((REPO / 'fixtures/knowledge-coordination-v2/frozen-sha256.json').read_bytes())
for name, expected in freeze['files'].items():
    path = REPO / 'fixtures/knowledge-coordination-v2' / name
    assert pin(path.read_bytes()) == expected, name
    r = subprocess.run(['git', 'show', 'HEAD:' + path.relative_to(REPO).as_posix()], cwd=REPO, capture_output=True)
    assert r.returncode == 0 and pin(r.stdout) == expected, name
commands = []
for argv in ([sys.executable, '-X', 'utf8', 'scripts/devlog.py', 'check'], ['git', 'diff', '--check']):
    r = subprocess.run(argv, cwd=REPO, capture_output=True)
    commands.append(dict(argv=argv, cwd=str(REPO), exit_code=r.returncode,
        stdout=r.stdout.decode('utf8'), stderr=r.stderr.decode('utf8')))
    assert r.returncode == 0, commands[-1]
summary = dict(checked_at=datetime.now(timezone.utc).isoformat(), stage=STAGE,
    documents={name: pin((REPO / name).read_bytes()) for name in FILES}, local_links=links,
    frozen_author_files=len(freeze['files']), frozen_git_bytes_rechecked=True, commands=commands,
    limitations='Document/link/ledger integrity gates; not a substitute for behavior tests or remote push verification.')
TARGET.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(receipt=str(TARGET), documents=len(FILES), links=len(links), authors=len(freeze['files']),
    exits=[r['exit_code'] for r in commands]), ensure_ascii=False))
