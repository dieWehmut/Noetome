"""Fresh Python and ordinary audit gates after the final Rust fix is stable."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import sys
import time

REPO = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
OUT = WORK / 'final-independent'
assert not OUT.exists()
OUT.mkdir()
CLI = REPO / 'target/debug/noetome.exe'
OLD = json.loads((WORK / 'task-2-fix1-python.json').read_bytes())
PATHS = {Path(p) for p in OLD['after']}
PATHS.update(REPO.glob('crates/**/*.rs'))
PATHS.add(CLI)
ENV = dict(os.environ, NOETOME_TEST_PYTHON=sys.executable, PYTHONUTF8='1')


def pin(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))


def snapshot():
    return {str(p): pin(p.read_bytes()) for p in sorted(PATHS)}


receipts = []


def run(name, argv):
    before = snapshot()
    started = time.monotonic()
    error = None
    try:
        process = subprocess.run(argv, cwd=REPO, capture_output=True, env=ENV, timeout=480)
        code, stdout, stderr = process.returncode, process.stdout, process.stderr
    except subprocess.TimeoutExpired as exc:
        code, stdout, stderr, error = None, exc.stdout or b'', exc.stderr or b'', repr(exc)
    out, err = OUT / (name + '.stdout.log'), OUT / (name + '.stderr.log')
    out.write_bytes(stdout)
    err.write_bytes(stderr)
    after = snapshot()
    receipt = dict(name=name, argv=list(map(str, argv)), cwd=str(REPO), started_at=datetime.now(timezone.utc).isoformat(),
        exit_code=code, elapsed_seconds=time.monotonic() - started,
        test_environment={k: ENV[k] for k in ('NOETOME_TEST_PYTHON', 'PYTHONUTF8')},
        stdout=dict(path=str(out), **pin(stdout)), stderr=dict(path=str(err), **pin(stderr)),
        before=before, after=after, error=error)
    (OUT / (name + '.json')).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    receipts.append(receipt)
    assert before == after, name
    assert code == 0, (name, code, stderr[-3000:].decode('utf8', errors='replace'))
    return stdout, stderr


stdout, stderr = run('python-workspace', [sys.executable, '-X', 'utf8', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py'])
testmatch = re.search(rb'Ran (\d+) tests in ([\d.]+)s', stderr)
assert testmatch and stderr.rstrip().endswith(b'OK') and b'skipped=' not in stderr
print(json.dumps(dict(gate='python-workspace', tests=int(testmatch[1]), elapsed=receipts[-1]['elapsed_seconds'], exit=0)), flush=True)
for name, command, count in (('audit-v2', 'audit-v2', (42, 126)), ('audit-v1', 'audit', (33, 56))):
    auditroot = OUT / name
    out, err = run(name, [sys.executable, '-X', 'utf8', 'scripts/verify_knowledge_coordination.py', command, str(CLI), str(auditroot)])
    audit = json.loads((auditroot / 'audit.json').read_bytes())
    assert (audit['scenario_count'], audit['command_count']) == count
    assert audit['protected_before'] == audit['protected_after']
    assert all(c['exit_code'] == c['expected_exit'] for c in audit['calls'])
    assert audit['cli_fingerprint'] == pin(CLI.read_bytes())
    print(json.dumps(dict(gate=name, scenarios=audit['scenario_count'], commands=audit['command_count'],
        protected_groups=len(audit['protected_after']), elapsed=receipts[-1]['elapsed_seconds'], exit=0)), flush=True)
run('devlog', [sys.executable, '-X', 'utf8', 'scripts/devlog.py', 'check'])
run('git-diff', ['git', 'diff', '--check'])
summary = dict(verified_at=datetime.now(timezone.utc).isoformat(), python_tests=int(testmatch[1]),
    cli=pin(CLI.read_bytes()), source_pin_count=len(PATHS), gates=[dict(name=r['name'], exit_code=r['exit_code'],
        elapsed_seconds=r['elapsed_seconds']) for r in receipts], original_streams_preserved=True,
    limitations='Synthetic selected-source engineering validation; science not_run, research not_requested, published false.')
(OUT / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(summary=str(OUT / 'summary.json'), source_pins=len(PATHS), all_exits=0)), flush=True)
