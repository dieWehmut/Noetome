from pathlib import Path
import re
path=Path('D:/Noetome/crates/noetome-cli/src/knowledge_coordination_v2_model.rs')
old=path.read_text(encoding='utf8')
def format_dto(match):
    name,body=match.groups()
    fields=[]; start=0; depth=0
    for i,c in enumerate(body):
        if c=='<': depth+=1
        elif c=='>': depth-=1
        elif c==',' and depth==0:
            fields.append(body[start:i]); start=i+1
    fields.append(body[start:])
    lines=[]
    for field in fields:
        field=field.strip()
        attr=re.match(r'(#[^\n]+\])(.+)',field)
        if attr:
            lines.append('    '+attr[1].replace('deserialize_with=','deserialize_with = '))
            field=attr[2]
        field=field.replace(':', ': ', 1).replace('BTreeMap<String,Fingerprint>','BTreeMap<String, Fingerprint>')
        lines.append('    '+field+',')
    return 'dto!('+name+' {\n'+'\n'.join(lines)+'\n});'
new=re.sub(r'dto!\((\w+)\{([^\n]+)\}\);',format_dto,old)
assert re.sub(r'\s+','',old).replace(',}', '}')==re.sub(r'\s+','',new).replace(',}', '}')
path.write_text(new,encoding='utf8',newline='\n')
print('Formatted DTO invocations; all non-whitespace tokens and field order retained (added trailing commas).')
