from pathlib import Path
import hashlib,json,re,subprocess,time
R=Path('D:/Noetome'); W=R/'.superpowers/sdd/B05-T02_VARIANTS_PLAN'
BASE='b3a31eaf87be8bbd4c119f4af19c92aefd958ca8'; HEAD='01742df21296b8b744b90155dbedb67f938fd312'
O={'scope':'Read-only inspection of saved final-fix evidence; no behavior suite rerun','base':BASE,'head':HEAD,'started_unix':time.time()}
cache={}
def pin(p):
 p=Path(p); key=str(p.resolve())
 if key not in cache:
  b=p.read_bytes();cache[key]={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
 return cache[key]
def load(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def verify_map(m):
 for p,x in m.items(): assert pin(p)==x, p
 return len(m)
def stream(c):
 for k in ['stdout','stderr']:
  x=c[k];assert pin(x['path'])=={k:x[k] for k in ['sha256','byte_length']},x['path']
def tokens(b):
 t=re.findall(r'"(?:\\.|[^"\\])*"|[A-Za-z_][A-Za-z_0-9]*|\d+|\S',b.decode())
 return [v for i,v in enumerate(t) if not(v==',' and i+1<len(t) and t[i+1]=='}')]
def blob(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=R)
files=['crates/noetome-cli/src/knowledge_coordinate_context.rs','crates/noetome-cli/src/knowledge_coordination_v2_model.rs','crates/noetome-cli/tests/knowledge_variants.rs','crates/noetome-cli/tests/support/coordination_variants_case.rs']
O['changed_files']=[]
for f in files:
 b=blob(HEAD,f);actual=(R/f).read_bytes();assert actual.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n')
 O['changed_files'].append({'path':f,'working_pin':pin(R/f),'head_blob_sha256':hashlib.sha256(b).hexdigest(),'equals_head_after_line_ending_normalization':True})
f=files[1];old=blob(BASE,f);new=blob(HEAD,f);assert tokens(old)==tokens(new)
O['r2_token_comparison']={'tokens_equal_ignoring_whitespace_and_optional_field_trailing_commas':True,'normalized_token_count':len(tokens(new)),'dto_invocations':len(re.findall(rb'dto!\(',new))}
O['saved_runs']={}
author=next(c for c in load(R/'fixtures/knowledge-coordination-v2/authors.json')['cases'] if c['name']=='history')
for mode in ['red','green','stable-final']:
 p=W/f'final-fix-{mode}-verification.json'; d=load(p)
 assert d['before']==d['after'] and d['sources_unchanged']
 for c in d['commands']: stream(c)
 if mode=='stable-final':
  verify_map(d['after']);verify_map(d['binaries_after'])
  assert d['commands'][-1]['cli_after']==pin(R/'target/debug/noetome.exe')
  raw=Path(d['commands'][-1]['stdout']['path']).read_text(encoding='utf-8-sig')
  suites=re.findall(r'test result: (.+)',raw);assert suites==d['commands'][-1]['suites']
  sums=[list(map(int,re.search(r'(\d+) passed; (\d+) failed; (\d+) ignored',s).groups())) for s in suites]
  totals=[sum(row[i] for row in sums) for i in range(3)];assert len(suites)==17 and totals==[591,0,0]
  assert 'running 27 tests' in raw and 'test nonzero_source_unit_preserves_frozen_history_and_absolute_context ... ok' in raw
  O['workspace_raw']={'suites':len(suites),'passed_failed_ignored':totals,'knowledge_variants_tests':27}
 elif mode=='red':
  original=blob(BASE,files[0]);x=d['before'][str(R/files[0])]
  assert x['sha256'] in {hashlib.sha256(original).hexdigest(),hashlib.sha256(original.replace(b'\n',b'\r\n')).hexdigest()}
  O['red_context_source_matches_base_blob']=True
 rootcounts=[]
 for root in d['roots']:
  p=Path(root['root']); assert load(p/'protection-before.json')==load(p/'protection-after.json')==root['protected']
  pc=verify_map(root['protected']);rc=verify_map(root['receipts']);rootcounts.append({'root':str(p),'protected_files':pc,'raw_receipts':rc})
 O['saved_runs'][mode]={'verification_pin':pin(W/f'final-fix-{mode}-verification.json'),'exits':[c['exit_code'] for c in d['commands']],'commands':[{'argv':c['argv'],'cwd':c['cwd'],'exit_code':c['exit_code'],'elapsed_seconds':c['elapsed_seconds'],'stdout':c['stdout'],'stderr':c['stderr']} for c in d['commands']],'sources':len(d['after']),'source_snapshots_equal':True,'binaries':len(d['binaries_after']),'roots_verified':len(rootcounts),'root_file_counts':rootcounts}
# Read all four genuine RED/GREEN root ordinary call outputs and coordinates.
O['nonzero_regression_roots']=[]
for mode in ['red','green']:
 d=load(W/f'final-fix-{mode}-verification.json')
 for root in d['roots']:
  p=Path(root['root']); assert load(p/'frozen-author.json')==author; assert load(p/'expected.json')==author['expected']
  exit=int((p/'coordinate-exit.txt').read_text()); detail=[]
  for i in author['inputs']:
   id=i['input_id']; b=p/'case'/('bundle-'+id); rv=load(b/'review-original.json'); c=load(b/'candidates-original.json');gold=load(b/'gold-original.json'); snap=load(b/'source-snapshot.json')
   assert rv['selection']==[{'kind':'text','ordinal':2}] and gold==i['gold']; assert int((p/f'verify-{id}-exit.txt').read_text())==0
   upstream=load(p/f'verify-{id}-stdout.txt'); assert upstream['status']=='passed'
   ev=c['payload']['evidence'][0]; raw=(p/f'selected-{id}.txt').read_bytes();quote=ev['quote'].encode();assert raw[ev['excerpt_start_byte']:ev['excerpt_end_byte']]==quote
   assert raw==('# 独立资料前言 α\n\n'.encode()+(R/'fixtures/knowledge-coordination-v2'/i['source_file']).read_bytes())
   joint=quote==i['context_quote'].encode(); detail.append({'input':id,'selection':rv['selection'],'upstream_exit':0,'support_start':ev['excerpt_start_byte'],'support_end':ev['excerpt_end_byte'],'joint_context_supported':joint})
  positive=all(i['joint_context_supported'] for i in detail)
  assert exit==(0 if mode=='green' and positive else 3)
  if positive: assert all(i['support_start']==57 for i in detail)
  else: assert all(i['support_start']>57 for i in detail) and 'COORD_CONTEXT' in (p/'coordinate-stderr.txt').read_text(encoding='utf8')
  if exit==0:
   report=load(p/'coordinate-stdout.txt');assert report['totals']==author['expected']['totals'];assert all(o['unit']['start_byte']==25 and o['context']['start_byte']==57 for o in report['occurrences'])
  O['nonzero_regression_roots'].append({'mode':mode,'root':str(p),'positive':positive,'coordinate_exit':exit,'original_author_and_gold_equal':True,'inputs':detail})
# Independent existing GREEN proof: every raw stream, full author, source slices and saved representations.
p=W/'final-fix-offset-green';d=load(p/'evidence.json');verify_map(d['protected_originals_before']);assert d['protected_originals_before']==d['protected_originals_after']
assert d['independent_check_before']==d['independent_check_after']; assert d['source_case_unchanged'] and d['protected_originals_unchanged']
assert load(p/'original-author.json')==author and load(p/'expected.json')==author['expected']
for c in d['calls']:
 stream(c);assert c['exit_code']==0;assert c['cli_before']==c['cli_after']==pin(R/'target/debug/noetome.exe')
report=load(p/'04-coordinate.stdout.txt'); saved=load(p/'output/coordination.json');assert report==saved
md=(p/'output/coordination.md').read_text(encoding='utf8');assert json.loads(md.split('```json\n')[1].split('\n```')[0])==report
ir=load(p/'output/coordination-ir.json')
for k in ['occurrences','facts','relations','totals','canonical_concepts','inputs']:assert ir[k]==report[k]
checked=load(p/'05-independent-check.stdout.txt');assert checked==d['independent_check'];assert checked['independently_verified'] and checked['status']==author['expected']['expected_status'] and checked['totals']==author['expected']['totals'];assert checked['inputs']==['a','b']
for o in report['occurrences']:
 i=next(i for i in author['inputs'] if i['input_id']==o['input_id']); expected=next(e for e in author['expected']['occurrences'] if e['input_id']==o['input_id'])
 for k in ['value','conditions','exceptions','status','issue_codes']:assert o[k]==expected[k]
 assert o['unit_value']==expected['unit'];assert o['context']['quote']==expected['context_quote'] and o['context']['time']==expected['time'] and o['context']['applicability_status']==expected['applicability_status']
 assert o['unit']['start_byte']==25 and o['context']['start_byte']==57
 b=p/'case'/('bundle-'+o['input_id']); candidate=load(b/'candidates-original.json');assert o['original_concepts']==candidate['payload']['concepts'] and o['original_atom']==candidate['payload']['atoms'][0]
 supports=[next(e for e in candidate['payload']['evidence'] if e['evidence_id']==l['evidence_id']) for l in o['original_atom']['atom']['evidence_links'] if l['relation']=='supports'];assert supports==o['original_evidence']
 raw=(p/f"selected-{o['input_id']}.txt").read_bytes();ctx=o['context'];assert raw[ctx['start_byte']:ctx['end_byte']]==ctx['quote'].encode() and hashlib.sha256(ctx['quote'].encode()).hexdigest()==ctx['sha256']
O['independent_green']={'evidence_pin':pin(p/'evidence.json'),'calls':len(d['calls']),'cli_calls':6,'python_calls':1,'exits':[c['exit_code'] for c in d['calls']],'protected_pins':len(d['protected_originals_before']),'author_gold_expected_unchanged':True,'representation_equality':True,'complete_check':checked,'unit_starts':[o['unit']['start_byte'] for o in report['occurrences']],'context_starts':[o['context']['start_byte'] for o in report['occurrences']],'inherited_metadata_base':d['base'],'inherited_metadata_head':d['head']}
O['final_cli']=pin(R/'target/debug/noetome.exe')
O['unique_file_pins_verified']=len(cache);O['completed_unix']=time.time();O['inspection_result']='all assertions passed'
(W/'final-rereview-evidence.json').write_text(json.dumps(O,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:O[k] for k in ['scope','r2_token_comparison','red_context_source_matches_base_blob','workspace_raw','final_cli','unique_file_pins_verified','inspection_result']},ensure_ascii=False))
