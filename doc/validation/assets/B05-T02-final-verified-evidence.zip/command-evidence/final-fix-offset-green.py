"""Final-review probe: ordinary v2 on nonzero-offset real text units."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys
import time

REPO = Path('D:/Noetome')
WORK = REPO / '.superpowers/sdd/B05-T02_VARIANTS_PLAN'
ROOT = WORK / 'final-fix-offset-green'
sys.path.insert(0, str(REPO / 'scripts'))
from verify_knowledge_coordination import encoded, fingerprint, strict_json, source_bundle, FILES, inventory
from verify_extraction_knowledge import actual_source
from verify_knowledge_variants import rebuild_context

CLI = REPO / 'target/debug/noetome.exe'
fixture = REPO / 'fixtures/knowledge-coordination-v2'
pins_before = {str(p): fingerprint(p.read_bytes()) for p in [CLI, *fixture.iterdir(), REPO/'crates/noetome-cli/src/knowledge_coordinate_context.rs', REPO/'scripts/verify_knowledge_variants.py'] if p.is_file()}
pins_before.update({str(p):fingerprint(p.read_bytes()) for p in [WORK/'final-review-offset-probe.py', *list((WORK/'final-review-offset-probe').rglob('*'))] if p.is_file()})
ROOT.mkdir()
author = copy.deepcopy(next(c for c in strict_json((fixture/'authors.json').read_bytes())['cases'] if c['name']=='history'))
(ROOT/'original-author.json').write_bytes(encoded(author))
(ROOT/'expected.json').write_bytes(encoded(author['expected']))
calls=[]

def call(label, args, expected=0, program=CLI):
    argv=[str(program), *map(str,args)]
    before=fingerprint(CLI.read_bytes()); started=time.monotonic()
    p=subprocess.run(argv, cwd=REPO, capture_output=True, timeout=40)
    out=ROOT/(label+'.stdout.txt'); err=ROOT/(label+'.stderr.txt')
    out.write_bytes(p.stdout); err.write_bytes(p.stderr)
    receipt=dict(label=label,argv=argv,cwd=str(REPO),exit_code=p.returncode,spec_expected_exit=expected,
        elapsed_seconds=time.monotonic()-started,stdout=dict(path=str(out),**fingerprint(p.stdout)),
        stderr=dict(path=str(err),**fingerprint(p.stderr)),cli_before=before,cli_after=fingerprint(CLI.read_bytes()))
    (ROOT/(label+'.command.json')).write_bytes(encoded(receipt)); calls.append(receipt)
    assert receipt['cli_before']==receipt['cli_after']
    return p

project=ROOT/'project'; case=ROOT/'case'
# Only a separate heading/blank prefix changes the selected source location;
# the author gold, context text and expected fact/history semantics stay frozen.
for item in author['inputs']:
    raw=(fixture/item['source_file']).read_bytes()
    (ROOT/('selected-'+item['input_id']+'.txt')).write_bytes('# 独立资料前言 α\n\n'.encode()+raw)
assert call('01-init',['project','init',project]).returncode==0
case.mkdir(); (case/'identity.json').write_bytes(encoded(author['identity']))
inputs=[]; contexts=[]
for num,item in enumerate(author['inputs'],2):
    ident=item['input_id']; gold=item['gold']
    run=call(f'{num:02}-import-{ident}',['source','import',project,ROOT/('selected-'+ident+'.txt')])
    assert run.returncode==0
    imported=strict_json(run.stdout); selection=dict(kind='text',ordinal=2)
    source=actual_source(project, imported['import_id'],selection)
    bind=source['binding']; unit=source['units'][0]
    assert unit['start_byte']>0 and gold['quote'] in unit['text']
    review=ROOT/('review-'+ident); review.mkdir()
    gold_raw=encoded(gold); (review/'gold.json').write_bytes(gold_raw)
    candidate=strict_json((REPO/'fixtures/extraction-review-v1/candidates.json').read_bytes())
    candidate.update(binding=bind,request_id='synthetic-final-offset-'+ident)
    payload=candidate['payload']
    payload.update(binding=bind,request_id=candidate['request_id'],concepts=[
        dict(concept_id=ident+'-subject',revision=1,canonical_name=item['subject'],aliases=[],needs_full_explanation=True),
        dict(concept_id=ident+'-property',revision=1,canonical_name=item['property'],aliases=[],needs_full_explanation=True)])
    quote=item['context_quote']; start=unit['start_byte']+unit['text'].encode().index(quote.encode())
    ev=dict(evidence_id=ident+'-support',unit_id=unit['unit_id'],excerpt_start_byte=start,
        excerpt_end_byte=start+len(quote.encode()),excerpt_sha256=hashlib.sha256(quote.encode()).hexdigest(),quote=quote)
    payload['evidence']=[ev]; atom=payload['atoms'][0]
    atom['atom'].update(atom_id=item['original_atom_id'],concept_ids=[ident+'-subject',ident+'-property'],
        content=gold['atom_content'],qualifiers=[gold['unit'],*gold['conditions'],*gold['exceptions']],
        evidence_links=[dict(evidence_id=ev['evidence_id'],relation='supports')])
    atom['measurement']=dict(value_status='known',value=gold['value'],unit=gold['unit'],conditions=gold['conditions'])
    (review/'candidates.json').write_bytes(encoded(candidate))
    (review/'decision.json').write_bytes(encoded(dict(schema_version=1,unit_id=unit['unit_id'],disposition='included',atom_ids=[item['original_atom_id']],exclusion_reason=None)))
    (review/'review.json').write_bytes(encoded(dict(schema_version=1,purpose='single_measurement_source_review',candidate_file='candidates.json',gold_file='gold.json',decision_file='decision.json',gold_sha256=fingerprint(gold_raw)['sha256'],subject=item['subject'],property=item['property'],allowed_contexts=[],selection=[selection],reviewer='automated_source_review',interpretation_timing='before_synthetic_response')))
    bundle=case/('bundle-'+ident)
    assert call(f'{num:02}-verify-{ident}',['extract','verify',project,imported['import_id'],review,bundle]).returncode==0
    pin={n:fingerprint((bundle/n).read_bytes()) for n in FILES}
    raw,r,c,g,rv,src=source_bundle(project,bundle,pin,evidence_quote_lf=True)
    context=rebuild_context(item['context'],src,g,c['payload']['evidence'])
    contexts.append(dict(input_id=ident,upstream_status=r['status'],unit_start=unit['start_byte'],unit_end=unit['end_byte'],evidence=ev,independent_context=context))
    inputs.append(dict(input_id=ident,review_bundle=bundle.name,binding=bind,artifacts=pin))
(case/'coordination.json').write_bytes(encoded(dict(schema_version=2,purpose='explicit_identity_condition_time',project_id=inputs[0]['binding']['project_id'],identity_file='identity.json',inputs=inputs)))
before=[inventory(p) for p in (project,case)]
run=call('04-coordinate',['knowledge','coordinate','--',project,case,ROOT/'output'],expected=0)
assert author['expected']['expected_status']=='passed' and run.returncode==0
check_before=[inventory(p) for p in (project,case,ROOT/'output')]
checked=call('05-independent-check',[REPO/'scripts/verify_knowledge_coordination.py','check',project,case,ROOT/'output',ROOT/'expected.json'],program=Path(sys.executable))
assert checked.returncode==0
independent=strict_json(checked.stdout)
assert independent['independently_verified'] is True
assert independent['status']==author['expected']['expected_status']
assert independent['totals']==author['expected']['totals']
assert sorted(independent['inputs'])==sorted(i['input_id'] for i in author['inputs'])
check_after=[inventory(p) for p in (project,case,ROOT/'output')]
assert check_before==check_after
after=[inventory(p) for p in (project,case)]
pins_after={p:fingerprint(Path(p).read_bytes()) for p in pins_before}
summary=dict(scope='Independent GREEN replay of original nonzero-offset counterexample plus ordinary full-author check; original probe untouched',
    base='e1c3e0867304f3cbfab75e3d7fd2d579e777646a',head='b3a31eaf87be8bbd4c119f4af19c92aefd958ca8',
    argv=sys.argv,cwd=str(Path.cwd()),calls=calls,actual_contexts=contexts,expected_exit=0,
    independent_check=independent, independent_check_before=check_before, independent_check_after=check_after, actual_exit=run.returncode,stderr=run.stderr.decode('utf8'),output_exists=(ROOT/'output').exists(),
    source_case_unchanged=before==after,protected_originals_before=pins_before,protected_originals_after=pins_after,
    protected_originals_unchanged=pins_before==pins_after)
(ROOT/'evidence.json').write_bytes(encoded(summary))
assert before==after and pins_before==pins_after
print(json.dumps(dict(evidence=str(ROOT/'evidence.json'),actual_exit=run.returncode,spec_expected_exit=0,
    stderr=run.stderr.decode('utf8'),unit_starts=[c['unit_start'] for c in contexts],
    independent_context_starts=[c['independent_context']['start_byte'] for c in contexts],commands=len(calls)),ensure_ascii=False))
