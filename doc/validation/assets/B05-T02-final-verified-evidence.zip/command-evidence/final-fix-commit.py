from pathlib import Path
import hashlib,json,subprocess,time
repo=Path('D:/Noetome'); work=repo/'.superpowers/sdd/B05-T02_VARIANTS_PLAN'
receipts=[]
def call(label,args):
    started=time.time(); p=subprocess.run(args,cwd=repo,capture_output=True)
    stdout=work/(label+'.stdout.txt'); stderr=work/(label+'.stderr.txt')
    stdout.write_bytes(p.stdout); stderr.write_bytes(p.stderr)
    receipt=dict(argv=args,cwd=str(repo),start_unix=started,elapsed_seconds=time.time()-started,exit_code=p.returncode,
                 stdout=dict(path=str(stdout),sha256=hashlib.sha256(p.stdout).hexdigest(),byte_length=len(p.stdout)),
                 stderr=dict(path=str(stderr),sha256=hashlib.sha256(p.stderr).hexdigest(),byte_length=len(p.stderr)))
    receipts.append(receipt)
    (work/'final-fix-git-receipts.json').write_text(json.dumps(receipts,indent=2),encoding='utf8')
    assert p.returncode==0,(label,p.stderr)
    return p.stdout.decode().strip()
assert call('final-fix-initial-index',['git','diff','--cached','--name-only'])==''
call('final-fix-diff-check',['git','diff','--check'])
files=['crates/noetome-cli/src/knowledge_coordinate_context.rs','crates/noetome-cli/tests/knowledge_variants.rs','crates/noetome-cli/tests/support/coordination_variants_case.rs']
call('final-fix-stage-r1',['git','add','--',*files])
assert sorted(call('final-fix-r1-index',['git','diff','--cached','--name-only']).splitlines())==sorted(files)
call('final-fix-commit-r1',['git','commit','-m','fix(coordination): compare context coverage in source coordinates'])
r1=call('final-fix-r1-head',['git','rev-parse','HEAD'])
files=['crates/noetome-cli/src/knowledge_coordination_v2_model.rs']
call('final-fix-stage-r2',['git','add','--',*files])
assert call('final-fix-r2-index',['git','diff','--cached','--name-only']).splitlines()==files
call('final-fix-commit-r2',['git','commit','-m','style(coordination): expand strict v2 DTO fields'])
r2=call('final-fix-r2-head',['git','rev-parse','HEAD'])
call('final-fix-final-status',['git','status','--short'])
call('final-fix-final-diff-check',['git','diff','--check'])
(work/'final-fix-commits.json').write_text(json.dumps(dict(r1=r1,r2=r2),indent=2),encoding='utf8')
print(json.dumps(dict(r1=r1,r2=r2)))
