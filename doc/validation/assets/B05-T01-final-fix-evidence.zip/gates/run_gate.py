from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,subprocess,sys,time
REPO=Path(__file__).resolve().parents[4]
if not (REPO/'Cargo.toml').exists():
    REPO=Path.cwd()
ROOT=Path(__file__).resolve().parent
LABEL=sys.argv[1]
COMMANDS={
 'rust-red':['powershell.exe','-NoProfile','-Command',"& ./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate final_review_ '--' --test-threads=3"],
 'python-schema-red':[sys.executable,'-X','utf8','-m','unittest','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_project_schema_must_match_sql_and_user_version','-v'],
 'python-final-review-red':[sys.executable,'-X','utf8','-m','unittest','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_support_link_order_is_preserved','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_ambiguous_original_role_is_rejected','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_schema3_project_retains_text_input_support','-v'],
 'python-role-green':[sys.executable,'-X','utf8','-m','unittest','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_ambiguous_original_role_is_rejected','-v'],
 'python-support-green':[sys.executable,'-X','utf8','-m','unittest','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_support_link_order_is_preserved','-v'],
 'python-schema-green':[sys.executable,'-X','utf8','-m','unittest','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_schema3_project_retains_text_input_support','test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_project_schema_must_match_sql_and_user_version','-v'],
 'rust-owner-green':['powershell.exe','-NoProfile','-Command',"& ./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate final_review_saved_owner_version_is_schema_exit_two '--' --test-threads=1"],
 'rust-author-green':['powershell.exe','-NoProfile','-Command',"& ./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate final_review_original_gold_author '--' --test-threads=2"],
 'rust-fmt':['powershell.exe','-NoProfile','-Command',"& ./scripts/cargo_local.ps1 fmt --all --check"],
 'rust-check':['powershell.exe','-NoProfile','-Command',"& ./scripts/cargo_local.ps1 check --workspace --locked --offline"],
 'rust-workspace':['powershell.exe','-NoProfile','-Command',"& ./scripts/cargo_local.ps1 test --workspace --locked --offline '--' --test-threads=4"],
 'python-module':[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-p','test_knowledge_coordination_verifier.py','-v'],
 'python-full':[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-p','test_*.py'],
 'python-audit':[sys.executable,'-X','utf8',str(REPO/'scripts/verify_knowledge_coordination.py'),'audit',str(REPO/'target/debug/noetome.exe'),str(REPO/'target/compiler-temp'/('b05-t01-final-fixed-audit-'+ROOT.name))],
}
COMMANDS['rust-corrected-red']=COMMANDS['rust-red']
def fp(path):
 b=Path(path).read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
source_names=list(json.loads((REPO/'.superpowers/sdd/B05-T01_COORDINATION_PLAN/root-final-python-01-receipt.json').read_bytes())['source_files_before'])
before={name:fp(REPO/name) for name in source_names}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
record={'schema_version':1,'label':LABEL,'started_at_utc':datetime.now(timezone.utc).isoformat(),'argv':COMMANDS[LABEL],'cwd':str(REPO),'head_before':head,'source_files_before':before,'cli_before':fp(REPO/'target/debug/noetome.exe')}
environment=dict(os.environ,NOETOME_TEST_PYTHON=sys.executable,NOETOME_PDF_PYTHON=sys.executable,PYTHONPATH=str(REPO/'tests'))
record['runtime']={k:environment.get(k) for k in ('TEMP','TMP','NOETOME_TEST_PYTHON','NOETOME_PDF_PYTHON')}
print('START '+LABEL,flush=True)
started=time.monotonic()
run=subprocess.run(COMMANDS[LABEL],cwd=REPO,env=environment,capture_output=True,timeout=240)
record['elapsed_seconds']=time.monotonic()-started
record['exit_code']=run.returncode
for name,raw in [('stdout',run.stdout),('stderr',run.stderr)]:
 path=ROOT/(LABEL+'-'+name+'.txt')
 with path.open('xb') as stream:stream.write(raw)
 record[name]={'path':str(path),**fp(path)}
record['source_files_after']={name:fp(REPO/name) for name in source_names}
record['source_unchanged']=record['source_files_before']==record['source_files_after']
record['cli_after']=fp(REPO/'target/debug/noetome.exe')
record['head_after']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
path=ROOT/(LABEL+'-receipt.json')
with path.open('x',encoding='utf-8') as stream:json.dump(record,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(run.stdout.decode('utf-8','replace')[-9500:])
print(run.stderr.decode('utf-8','replace')[-6500:])
print(json.dumps({'receipt':str(path),'exit_code':run.returncode,'source_unchanged':record['source_unchanged'],'elapsed_seconds':record['elapsed_seconds']}))
assert record['source_unchanged']
raise SystemExit(run.returncode)
