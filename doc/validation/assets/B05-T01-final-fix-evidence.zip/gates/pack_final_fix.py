from pathlib import Path
from datetime import datetime, timezone
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, subprocess, sys

REPO = Path(__file__).resolve().parents[4]
ROOT = Path(__file__).resolve().parent
ASSETS = REPO / 'doc/validation/assets'
AUDIT = REPO / 'target/compiler-temp/b05-t01-final-fixed-audit-final-fix-13fb5f0be4ec46beabc94220b55c078d'

def fp(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

def write_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head == 'ae2858031f947ef22e28328af2b094b498106f32'
labels = ('rust-fmt', 'rust-check', 'rust-workspace', 'python-module', 'python-full', 'python-audit')
gates = {}
for label in labels:
    d = json.loads((ROOT / (label + '-receipt.json')).read_bytes())
    assert d['exit_code'] == 0 and d['source_unchanged']
    for name, pin in d['source_files_after'].items():
        assert fp((REPO / name).read_bytes()) == pin, name
    for role in ('stdout', 'stderr'):
        assert fp(Path(d[role]['path']).read_bytes()) == {k: d[role][k] for k in ('sha256', 'byte_length')}
    gates[label] = {k: d[k] for k in ('argv', 'exit_code', 'elapsed_seconds', 'source_unchanged', 'cli_before', 'cli_after', 'stdout', 'stderr', 'runtime')}
audit = json.loads((AUDIT / 'audit.json').read_bytes())
boundary = json.loads((ROOT / 'rust-boundary-root-inspection.json').read_bytes())
runtime = {'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(), 'product_head': head,
           'final_source_files': json.loads((ROOT / 'rust-workspace-receipt.json').read_bytes())['source_files_after'],
           'final_cli_fingerprint': fp((REPO / 'target/debug/noetome.exe').read_bytes()), 'gates': gates,
           'rust': {'suites': 16, 'passed': 561, 'failed': 0, 'ignored': 0},
           'python_module_tests': 34, 'python_full_tests': 142,
           'audit': {'scenarios': audit['scenario_count'], 'commands': audit['command_count'], 'protected_groups': len(audit['protected_after']), 'protection_passed': audit['protection_passed']},
           'rust_boundary_roots': len(boundary['roots']), 'rust_boundary_protected_items': sum(r['protected_items'] for r in boundary['roots']),
           'scope': 'One final-review fix wave. Original RED, initial preparation interference, scoped GREEN, full regression and fresh ordinary CLI audit. No scientific or new PDF coordination claim.',
           'concurrency': 'Full Python and Rust workspace ran concurrently. Cargo rebuilt the CLI; before/after CLI pins are retained without claiming an unchanged binary.',
           'rereview': 'Separate fresh bounded re-review remains pending at this packaging time.'}
write_new(ROOT / 'final-fix-runtime.json', runtime)
with (ASSETS / 'B05-T01-final-fix-runtime.json').open('xb') as stream:
    stream.write((ROOT / 'final-fix-runtime.json').read_bytes())

members, skipped = {}, []
def add(path, name):
    path = path.resolve()
    assert name not in members
    stat = path.stat()
    members[name] = {'source': str(path), **fp(path.read_bytes()),
                     'identity': [stat.st_dev, stat.st_ino], 'mtime_ns': stat.st_mtime_ns, 'link_count': stat.st_nlink}

def tree(path, prefix):
    for child in sorted(path.iterdir()):
        stat = child.lstat()
        if child.is_symlink() or getattr(stat, 'st_file_attributes', 0) & 0x400:
            skipped.append({'path': str(child), 'reason': 'Intentional test link/reparse entry: never followed during packaging.', 'identity': [stat.st_dev, stat.st_ino], 'mtime_ns': stat.st_mtime_ns})
        elif child.is_dir():
            tree(child, prefix + '/' + child.name)
        elif child.is_file():
            add(child, prefix + '/' + child.name)
        else:
            raise AssertionError('nonordinary selected artifact: ' + str(child))

tree(ROOT, 'gates')
tree(AUDIT, 'ordinary-audit')
for item in boundary['roots']:
    path = REPO / item['root']
    tree(path, 'rust-boundary/' + path.name)
external = set()
for path in audit['protected_after']:
    p = Path(path)
    if p.is_file() and 'sentinel' in p.name:
        external.add(p)
for item in boundary['roots']:
    before = json.loads((REPO / item['root'] / 'protection-before.json').read_bytes())
    for path in before:
        p = Path(path)
        if p.is_file() and p.parent == REPO / 'target/compiler-temp':
            external.add(p)
for path in sorted(external):
    add(path, 'external/' + path.name)
tree(REPO / 'fixtures/knowledge-coordination-v1', 'frozen-author-fixtures')

receipt = {'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(), 'product_head': head,
           'original_member_count': len(members), 'original_members': members, 'skipped_entries': skipped,
           'no_cli_or_model_calls_during_archive': True,
           'limits': 'ZIP preserves raw files, not filesystem identity or link objects. Original raw inventories and skipped intentional test links remain explicit.'}
receipt_path = ROOT / 'final-fix-package-receipt.json'
write_new(receipt_path, receipt)
add(receipt_path, 'gates/final-fix-package-receipt.json')
archive = ASSETS / 'B05-T01-final-fix-evidence.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zip_file:
    for name, pin in sorted(members.items()):
        raw = Path(pin['source']).read_bytes()
        assert fp(raw) == {k: pin[k] for k in ('sha256', 'byte_length')}
        zip_file.writestr(name, raw)
with ZipFile(archive) as zip_file:
    assert zip_file.testzip() is None and set(zip_file.namelist()) == set(members)
    for name, pin in members.items():
        assert fp(zip_file.read(name)) == {k: pin[k] for k in ('sha256', 'byte_length')}
        path = Path(pin['source']); stat = path.stat()
        assert fp(path.read_bytes()) == {k: pin[k] for k in ('sha256', 'byte_length')}
        assert [stat.st_dev, stat.st_ino] == pin['identity'] and stat.st_mtime_ns == pin['mtime_ns'] and stat.st_nlink == pin['link_count']
manifest = {'schema_version': 1, 'archive': archive.relative_to(REPO).as_posix(), **fp(archive.read_bytes()),
            'member_count': len(members), 'members': members, 'original_selected_files_unchanged': True,
            'no_cli_or_model_calls_during_archive': True, 'skipped_entries': skipped,
            'scope': runtime['scope']}
write_new(ASSETS / 'B05-T01-final-fix-evidence-manifest.json', manifest)
print(json.dumps({k: v for k, v in manifest.items() if k not in ('members', 'skipped_entries')}, ensure_ascii=False))
print('Skipped intentional test links:', len(skipped), '; external sentinel originals:', len(external))
