# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "artifacts": {
    ".owner.json": {
      "byte_length": 142,
      "sha256": "365c684a7e5422cd871a1e1fe768dcec354a4cebd95382351576d4a1bc894642"
    },
    "candidates-original.json": {
      "byte_length": 2978,
      "sha256": "6752eb7c59ffac885ec70a72dd1717ffb076b6b288c6927154e70ce49e28aecd"
    },
    "decision-original.json": {
      "byte_length": 140,
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d"
    },
    "gold-original.json": {
      "byte_length": 726,
      "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e"
    },
    "knowledge-ir.json": {
      "byte_length": 12081,
      "sha256": "dfa0c1ecbe0c7c906c49e842b1f9a66d64204457a6427a560af914269020f957"
    },
    "review-original.json": {
      "byte_length": 509,
      "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4"
    },
    "source-snapshot.json": {
      "byte_length": 996,
      "sha256": "df2db78a8725ef73b41bbaeada8e9cdf9269053fcb36bd2a5cba996a8d3046f5"
    }
  },
  "binding": {
    "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
    "import_id": "8bb6ed3d-9781-427b-ac43-9ac56f02bd3e",
    "manifest_sha256": null,
    "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
    "parse_id": null,
    "project_id": "ec28b8db-1663-437f-9a12-2c3fa763114b",
    "source_id": "3136638c-9b7b-4f41-95f2-f659ec465ea5",
    "version_id": "7b55c05b-e9f2-44ef-a690-ce17096e809d"
  },
  "candidate_results": [
    {
      "end_byte": 107,
      "issue_codes": [],
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    }
  ],
  "checks": [
    {
      "actual": null,
      "category": "schema",
      "code": null,
      "end_byte": 107,
      "expected": "strict_schema_1",
      "object_id": "expected-0",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": "parsed",
      "category": "source",
      "code": null,
      "end_byte": 107,
      "expected": "parsed",
      "object_id": "expected-0",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": "included",
      "category": "exclusion",
      "code": null,
      "end_byte": 107,
      "expected": "included",
      "object_id": "expected-0",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      },
      "category": "coverage",
      "code": null,
      "end_byte": 107,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "object_id": "expected-0",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "binding": {
          "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "import_id": "8bb6ed3d-9781-427b-ac43-9ac56f02bd3e",
          "manifest_sha256": null,
          "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "parse_id": null,
          "project_id": "ec28b8db-1663-437f-9a12-2c3fa763114b",
          "source_id": "3136638c-9b7b-4f41-95f2-f659ec465ea5",
          "version_id": "7b55c05b-e9f2-44ef-a690-ce17096e809d"
        },
        "request_id": "synthetic-coordination-b"
      },
      "category": "binding",
      "code": null,
      "end_byte": 107,
      "expected": {
        "binding": {
          "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "import_id": "8bb6ed3d-9781-427b-ac43-9ac56f02bd3e",
          "manifest_sha256": null,
          "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "parse_id": null,
          "project_id": "ec28b8db-1663-437f-9a12-2c3fa763114b",
          "source_id": "3136638c-9b7b-4f41-95f2-f659ec465ea5",
          "version_id": "7b55c05b-e9f2-44ef-a690-ce17096e809d"
        },
        "request_id": "synthetic-coordination-b"
      },
      "object_id": "expected-0",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "category": "duplicate",
      "code": null,
      "end_byte": 107,
      "expected": "unique_semantic_atom",
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 106,
        "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
        "excerpt_start_byte": 0,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      },
      "category": "evidence_identity",
      "code": null,
      "end_byte": 106,
      "expected": {
        "end_byte": 107,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "object_id": "b-support",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "excerpt_start_byte": 0,
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ],
      "category": "evidence",
      "code": null,
      "end_byte": 107,
      "expected": {
        "end_byte": 106,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      },
      "category": "concept",
      "code": null,
      "end_byte": 107,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "category": "content",
      "code": null,
      "end_byte": 107,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      },
      "category": "fact",
      "code": null,
      "end_byte": 107,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      },
      "category": "unit",
      "code": null,
      "end_byte": 107,
      "expected": "m/s",
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      },
      "category": "condition",
      "code": null,
      "end_byte": 107,
      "expected": "温度 20 ℃",
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      },
      "category": "condition",
      "code": null,
      "end_byte": 107,
      "expected": "仅适用样例 A",
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "category": "condition_set",
      "code": null,
      "end_byte": 107,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      },
      "category": "exception",
      "code": null,
      "end_byte": 107,
      "expected": "结冰时不适用",
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": [
        "结冰时不适用"
      ],
      "category": "exception_set",
      "code": null,
      "end_byte": 107,
      "expected": [
        "结冰时不适用"
      ],
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    },
    {
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ],
      "category": "qualifiers",
      "code": null,
      "end_byte": 107,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "object_id": "b-speed",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    }
  ],
  "expected_results": [
    {
      "end_byte": 107,
      "issue_codes": [],
      "object_id": "expected-0",
      "start_byte": 0,
      "status": "passed",
      "unit_id": "unit-0"
    }
  ],
  "knowledge_status": "pending",
  "network_calls": 0,
  "origin": {
    "gold_sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
    "input_fingerprints": {
      "candidates.json": {
        "byte_length": 2978,
        "sha256": "6752eb7c59ffac885ec70a72dd1717ffb076b6b288c6927154e70ce49e28aecd"
      },
      "decision.json": {
        "byte_length": 140,
        "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d"
      },
      "gold.json": {
        "byte_length": 726,
        "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e"
      },
      "review.json": {
        "byte_length": 509,
        "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4"
      }
    },
    "interpretation_timing": "before_synthetic_response",
    "producer": "api",
    "reviewer": "automated_source_review",
    "transport_mode": "local_http_test"
  },
  "paid_calls": 0,
  "producer": "source_review",
  "published": false,
  "quality": {
    "binding": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "concept": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "condition": {
      "expected": 2,
      "failed": 0,
      "needs_review": 0,
      "passed": 2,
      "status": "passed",
      "unprocessed": 0
    },
    "content": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "coverage": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "evidence": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "exception": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "exclusion": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "fact": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "schema": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "source": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    },
    "unit": {
      "expected": 1,
      "failed": 0,
      "needs_review": 0,
      "passed": 1,
      "status": "passed",
      "unprocessed": 0
    }
  },
  "report_kind": "source_knowledge_verification",
  "request_id": "synthetic-coordination-b",
  "research_status": "not_requested",
  "rules": {
    "allowed_contexts": [],
    "grammar": "controlled_measurement_zh_v1",
    "interpretation_timing": "before_synthetic_response",
    "property": "速度",
    "reviewer": "automated_source_review",
    "subject": "样例 A"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "scope": {
    "binding": {
      "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
      "import_id": "8bb6ed3d-9781-427b-ac43-9ac56f02bd3e",
      "manifest_sha256": null,
      "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
      "parse_id": null,
      "project_id": "ec28b8db-1663-437f-9a12-2c3fa763114b",
      "source_id": "3136638c-9b7b-4f41-95f2-f659ec465ea5",
      "version_id": "7b55c05b-e9f2-44ef-a690-ce17096e809d"
    },
    "expected_atoms": 1,
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "units": [
      {
        "end_byte": 107,
        "locator": {
          "kind": "text",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "span_id": "a6930079-91fc-4098-afad-6352242d619c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n",
        "unit_id": "unit-0"
      }
    ]
  },
  "status": "passed",
  "totals": {
    "additional_source_concepts": 0,
    "candidate_atoms": 1,
    "duplicate_atoms": 0,
    "expected_atoms": 1,
    "failed": 0,
    "needs_review": 0,
    "passed": 1,
    "required_concept_groups": 1,
    "unexpected_atoms": 0,
    "unprocessed": 0
  }
}
```
