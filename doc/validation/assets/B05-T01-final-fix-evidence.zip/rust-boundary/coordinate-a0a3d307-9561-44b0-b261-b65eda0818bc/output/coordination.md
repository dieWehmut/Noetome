# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

显式身份重复／互补范围；完整来源、原对象、证据与分母见以下事实，与 coordination.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "08c7a46f-f9de-4e50-acc2-acdfccbba913",
  "scope": "explicit_identity_duplicate_complement_v1",
  "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "display_name": "速度"
    },
    {
      "canonical_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "display_name": "质量"
    },
    {
      "canonical_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "display_name": "样例 A"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
        "import_id": "f8e862aa-6052-4630-839f-339c6c2485f9",
        "source_id": "3d0a7c06-4c2c-4480-81e9-c29618c6b0d4",
        "version_id": "d56a60ba-13eb-4f8a-8cf3-8b6046376ece",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "f8e862aa-6052-4630-839f-339c6c2485f9",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
              "source_id": "3d0a7c06-4c2c-4480-81e9-c29618c6b0d4",
              "version_id": "d56a60ba-13eb-4f8a-8cf3-8b6046376ece"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "f8e862aa-6052-4630-839f-339c6c2485f9",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
              "source_id": "3d0a7c06-4c2c-4480-81e9-c29618c6b0d4",
              "version_id": "d56a60ba-13eb-4f8a-8cf3-8b6046376ece"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "db9446180582c457c8f477f652621c096651db5c71dd51c6afcd126e8b0b7462",
          "byte_length": 2978
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
          "byte_length": 726
        },
        "knowledge-ir.json": {
          "sha256": "c54016c2555357ebb633ff1e4df0f1297329481b9627c305cb7a3f0ccd02fbb4",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "00965b5a61eb7a557f2fa4f21b15d75dd20c17d39bebd986110f3de0f0877336",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "aa037655e3ba3eb0c89477997efe88ce9f5aa7db9424d7e93a7a56987b55f382",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "8488ab30425f1d0fcc7e0a2e46eb2160090430b129add6a41c9afd26114672ff",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
        "import_id": "3fa51dbc-fc07-4f70-9ecd-98d2fec80632",
        "source_id": "46015f39-3c66-4e8e-8f62-8449daf60d0f",
        "version_id": "f4c1af4c-d173-44f3-8afc-7a0f13fd38cd",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "3fa51dbc-fc07-4f70-9ecd-98d2fec80632",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
              "source_id": "46015f39-3c66-4e8e-8f62-8449daf60d0f",
              "version_id": "f4c1af4c-d173-44f3-8afc-7a0f13fd38cd"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "3fa51dbc-fc07-4f70-9ecd-98d2fec80632",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
              "source_id": "46015f39-3c66-4e8e-8f62-8449daf60d0f",
              "version_id": "f4c1af4c-d173-44f3-8afc-7a0f13fd38cd"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "8b64283e436d51904cf1c65be9db6f40ec935408dbae69a2fed89d48a744ada1",
          "byte_length": 2978
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "151db9aadb63f9ff5e899ef585550c5df2773e33f1d0e5b438f4a3bbb1f894bc",
          "byte_length": 672
        },
        "knowledge-ir.json": {
          "sha256": "be7916f0bad25496e8f9ee9185b13af6030a508c64f980164b978a3b01cd0787",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "4478ac1581a3e2538063a25adb267eea7b41cfc1641a5e655cdb826e1cf70d74",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "d8b18429a31e82494d58863ee5ffbff29f6cc28c2edefaab024b83782e9bf316",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "011e09b0e127fe7f8f40eb177068f8b7ef92f306740b9ae567b4feea8d925dd4",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "52a709f0edee76a5716a89d9adf75e664773f4a9ae99504e83754d807fdd8cf2",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
        "import_id": "5a0991e5-dae1-4ea5-b78b-9519b1ef857c",
        "source_id": "ed9cfb0b-847c-4ad0-a1af-5d2f19d99a09",
        "version_id": "10632e7c-1c05-4b23-8c80-336d609e20af",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "5a0991e5-dae1-4ea5-b78b-9519b1ef857c",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
              "source_id": "ed9cfb0b-847c-4ad0-a1af-5d2f19d99a09",
              "version_id": "10632e7c-1c05-4b23-8c80-336d609e20af"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "5a0991e5-dae1-4ea5-b78b-9519b1ef857c",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
              "source_id": "ed9cfb0b-847c-4ad0-a1af-5d2f19d99a09",
              "version_id": "10632e7c-1c05-4b23-8c80-336d609e20af"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 104,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 105,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 104,
            "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 104,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 104,
              "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "4445c53929f3ada499034a7c1c59ce9ce27553370191dc26c7b4f9964d289ff7",
          "byte_length": 2970
        },
        "decision-original.json": {
          "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
          "byte_length": 139
        },
        "gold-original.json": {
          "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
          "byte_length": 720
        },
        "knowledge-ir.json": {
          "sha256": "a87a81bb8345e5ca02b7d2ae0335b0056434f2ee95df4fa4dd967407e92af373",
          "byte_length": 12036
        },
        "review-original.json": {
          "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "21f05a6391df2a0f8402dba654552e2c3e92cf05e44ab1edfed15b2623d4df47",
          "byte_length": 994
        },
        "verification.json": {
          "sha256": "2224f3862eea05eefad94b500a61f05b8ab45ac0e95c17ec909bce2a03e9d72d",
          "byte_length": 16533
        },
        "verification.md": {
          "sha256": "1bf19ff504c9ad07765c812bdab46e6645057ba7bf2abc97803e7fbf86e3fa30",
          "byte_length": 16967
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "occurrence_id": "occ-45b8d3aefdc5c571a612da47f35de2af23905cbdbe6c8dfdc6abd6e536b2d799",
      "input_id": "b",
      "binding": {
        "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
        "import_id": "3fa51dbc-fc07-4f70-9ecd-98d2fec80632",
        "source_id": "46015f39-3c66-4e8e-8f62-8449daf60d0f",
        "version_id": "f4c1af4c-d173-44f3-8afc-7a0f13fd38cd",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "80a050f7-5dcd-4562-99e7-2962d0d61055",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-c55925bbc57e004b600c459f9ea68acfceac4ad7618e2ee42979a80e758ca162",
      "input_id": "a",
      "binding": {
        "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
        "import_id": "f8e862aa-6052-4630-839f-339c6c2485f9",
        "source_id": "3d0a7c06-4c2c-4480-81e9-c29618c6b0d4",
        "version_id": "d56a60ba-13eb-4f8a-8cf3-8b6046376ece",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "540e412a-37cc-4f50-858e-82b569279604",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-fa8eb86b9c1b9719ea1dfcedceed93e6c78feb09fc0d7de0d8f14961ffe9edf5",
      "input_id": "c",
      "binding": {
        "project_id": "10f79e09-7694-44c3-ad50-af8294e5a1c1",
        "import_id": "5a0991e5-dae1-4ea5-b78b-9519b1ef857c",
        "source_id": "ed9cfb0b-847c-4ad0-a1af-5d2f19d99a09",
        "version_id": "10632e7c-1c05-4b23-8c80-336d609e20af",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "5a581d83-91d7-4759-886f-17db7abd1c2e",
          "ordinal": 0,
          "resource_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 105,
        "text": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 104,
          "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
          "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "51fa59a0-255f-4867-836c-aa39bdc01906",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "fact_id": "fact-2176d0ef755e6f1de61cf485f79a5805b933ddc9487e83fcd12064c305a175a4",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-45b8d3aefdc5c571a612da47f35de2af23905cbdbe6c8dfdc6abd6e536b2d799",
        "occ-c55925bbc57e004b600c459f9ea68acfceac4ad7618e2ee42979a80e758ca162"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "fact_id": "fact-6bc62067e5e15c97430ccb915d046434ef2b5edab41254cf60e7ef28f896d03b",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-fa8eb86b9c1b9719ea1dfcedceed93e6c78feb09fc0d7de0d8f14961ffe9edf5"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "left_occurrence_id": "occ-45b8d3aefdc5c571a612da47f35de2af23905cbdbe6c8dfdc6abd6e536b2d799",
      "right_occurrence_id": "occ-c55925bbc57e004b600c459f9ea68acfceac4ad7618e2ee42979a80e758ca162",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-45b8d3aefdc5c571a612da47f35de2af23905cbdbe6c8dfdc6abd6e536b2d799",
      "right_occurrence_id": "occ-fa8eb86b9c1b9719ea1dfcedceed93e6c78feb09fc0d7de0d8f14961ffe9edf5",
      "relation": "complement",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-c55925bbc57e004b600c459f9ea68acfceac4ad7618e2ee42979a80e758ca162",
      "right_occurrence_id": "occ-fa8eb86b9c1b9719ea1dfcedceed93e6c78feb09fc0d7de0d8f14961ffe9edf5",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "totals": {
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c887e1209f1bc3b55bb15d4a0dd5c9b15633e6b571ebc30d031e0237ad28f2f0",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "18f8f3166f3b9003e8bfa7170ecafd6bfb2733a3511bf82894490f50bc1e9e7b",
      "byte_length": 55919
    },
    "coordination-original.json": {
      "sha256": "07d91861e8fe1ac02d2417e961b58a0bc6964bd14f459fb3389e28214382d02c",
      "byte_length": 6403
    },
    "identity-original.json": {
      "sha256": "419d4155e834d9774b862516ffddc125a381c2c6cf36f35cc02cc1992d492048",
      "byte_length": 1616
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "db9446180582c457c8f477f652621c096651db5c71dd51c6afcd126e8b0b7462",
      "byte_length": 2978
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
      "byte_length": 726
    },
    "input-a--knowledge-ir.json": {
      "sha256": "c54016c2555357ebb633ff1e4df0f1297329481b9627c305cb7a3f0ccd02fbb4",
      "byte_length": 12081
    },
    "input-a--review-original.json": {
      "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "00965b5a61eb7a557f2fa4f21b15d75dd20c17d39bebd986110f3de0f0877336",
      "byte_length": 996
    },
    "input-a--verification.json": {
      "sha256": "aa037655e3ba3eb0c89477997efe88ce9f5aa7db9424d7e93a7a56987b55f382",
      "byte_length": 16573
    },
    "input-a--verification.md": {
      "sha256": "8488ab30425f1d0fcc7e0a2e46eb2160090430b129add6a41c9afd26114672ff",
      "byte_length": 17007
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "8b64283e436d51904cf1c65be9db6f40ec935408dbae69a2fed89d48a744ada1",
      "byte_length": 2978
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "151db9aadb63f9ff5e899ef585550c5df2773e33f1d0e5b438f4a3bbb1f894bc",
      "byte_length": 672
    },
    "input-b--knowledge-ir.json": {
      "sha256": "be7916f0bad25496e8f9ee9185b13af6030a508c64f980164b978a3b01cd0787",
      "byte_length": 12081
    },
    "input-b--review-original.json": {
      "sha256": "4478ac1581a3e2538063a25adb267eea7b41cfc1641a5e655cdb826e1cf70d74",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "d8b18429a31e82494d58863ee5ffbff29f6cc28c2edefaab024b83782e9bf316",
      "byte_length": 996
    },
    "input-b--verification.json": {
      "sha256": "011e09b0e127fe7f8f40eb177068f8b7ef92f306740b9ae567b4feea8d925dd4",
      "byte_length": 16573
    },
    "input-b--verification.md": {
      "sha256": "52a709f0edee76a5716a89d9adf75e664773f4a9ae99504e83754d807fdd8cf2",
      "byte_length": 17007
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "4445c53929f3ada499034a7c1c59ce9ce27553370191dc26c7b4f9964d289ff7",
      "byte_length": 2970
    },
    "input-c--decision-original.json": {
      "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
      "byte_length": 139
    },
    "input-c--gold-original.json": {
      "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
      "byte_length": 720
    },
    "input-c--knowledge-ir.json": {
      "sha256": "a87a81bb8345e5ca02b7d2ae0335b0056434f2ee95df4fa4dd967407e92af373",
      "byte_length": 12036
    },
    "input-c--review-original.json": {
      "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
      "byte_length": 509
    },
    "input-c--source-snapshot.json": {
      "sha256": "21f05a6391df2a0f8402dba654552e2c3e92cf05e44ab1edfed15b2623d4df47",
      "byte_length": 994
    },
    "input-c--verification.json": {
      "sha256": "2224f3862eea05eefad94b500a61f05b8ab45ac0e95c17ec909bce2a03e9d72d",
      "byte_length": 16533
    },
    "input-c--verification.md": {
      "sha256": "1bf19ff504c9ad07765c812bdab46e6645057ba7bf2abc97803e7fbf86e3fa30",
      "byte_length": 16967
    }
  }
}
```
