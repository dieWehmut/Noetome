# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-c",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "30c10955-3487-4496-b9f2-55cde4357545",
      "import_id": "2e50894e-8c63-4047-94c4-12a2047397e0",
      "source_id": "c7740499-6f30-4b66-beb2-fe7fac27952e",
      "version_id": "a700b413-cb07-4ba6-80a8-b85b92b5ed06",
      "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
      "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "74bc680d-e0cf-4e70-a24e-ddcb24692143",
          "ordinal": 0,
          "resource_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 105,
        "text": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "30c10955-3487-4496-b9f2-55cde4357545",
    "import_id": "2e50894e-8c63-4047-94c4-12a2047397e0",
    "source_id": "c7740499-6f30-4b66-beb2-fe7fac27952e",
    "version_id": "a700b413-cb07-4ba6-80a8-b85b92b5ed06",
    "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
    "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "5c3cb2ee051a6deb36bb89c700dfcec4655dfecdc4087391696254e06cff9c49",
        "byte_length": 2970
      },
      "decision.json": {
        "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
        "byte_length": 139
      },
      "gold.json": {
        "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
        "byte_length": 720
      },
      "review.json": {
        "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
        "byte_length": 509
      }
    },
    "gold_sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "质量",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "c-mass"
        ],
        "decision": {
          "atom_ids": [
            "c-mass"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
          "import_id": "2e50894e-8c63-4047-94c4-12a2047397e0",
          "manifest_sha256": null,
          "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
          "parse_id": null,
          "project_id": "30c10955-3487-4496-b9f2-55cde4357545",
          "source_id": "c7740499-6f30-4b66-beb2-fe7fac27952e",
          "version_id": "a700b413-cb07-4ba6-80a8-b85b92b5ed06"
        },
        "request_id": "synthetic-coordination-c"
      },
      "actual": {
        "binding": {
          "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
          "import_id": "2e50894e-8c63-4047-94c4-12a2047397e0",
          "manifest_sha256": null,
          "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
          "parse_id": null,
          "project_id": "30c10955-3487-4496-b9f2-55cde4357545",
          "source_id": "c7740499-6f30-4b66-beb2-fe7fac27952e",
          "version_id": "a700b413-cb07-4ba6-80a8-b85b92b5ed06"
        },
        "request_id": "synthetic-coordination-c"
      }
    },
    {
      "category": "duplicate",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "c-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 104,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 105,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "c-support",
        "excerpt_end_byte": 104,
        "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
        "excerpt_start_byte": 0,
        "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 104,
        "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "c-support",
          "excerpt_end_byte": 104,
          "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
          "excerpt_start_byte": 0,
          "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "质量"
        ],
        "compound": "样例 A 质量"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "c-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "质量",
            "concept_id": "c-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "2",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "kg",
        "value": "2",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "kg",
      "actual": {
        "measurement": "kg",
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 105,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "kg"
      },
      "actual": [
        "kg",
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "5c3cb2ee051a6deb36bb89c700dfcec4655dfecdc4087391696254e06cff9c49",
      "byte_length": 2970
    },
    "decision-original.json": {
      "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
      "byte_length": 139
    },
    "gold-original.json": {
      "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
      "byte_length": 720
    },
    "knowledge-ir.json": {
      "sha256": "725caf22c3e6349dbc200ba589e9162b027e9677ceae667d588737163ef1231c",
      "byte_length": 12036
    },
    "review-original.json": {
      "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "853d102d43ccd00b18e2fd42d4b48c389f5316d986e16eb6c36b3b8d795b73c5",
      "byte_length": 994
    }
  }
}
```
