# PDF 单文件解析沙盒

| 字段 | 值 |
| --- | --- |
| schema_version | 1 |
| report_kind | pdf_parse_sandbox |
| status | parsed |
| input_sha256 | 39da594adb8486be9022c64f0c43f208860a985f0d6c97dda2e25de54d9f32a4 |
| input_byte_length | 2370 |
| parser | pdfplumber 0.11.9 / pdfminer.six 20251230 / noetome-pdf-text-v1 / crop-pt-lines-v1 / Python 3.12.14 |
| page_count | 1 |
| parsed_page_count | 1 |
| needs_review_page_count | 0 |
| failed_page_count | 0 |
| manifest_path | parser/pdf-manifest.json |
| manifest_sha256 | 4442cdbcacbbcc482aa08bd9c003f69613952b1cf6adb39fea928c0f2d3ecc98 |
| elapsed_ms | 212 |
| resource_bytes | 7110 |

物理索引从0开始；显示物理页为索引+1；印刷页码未确认。知识抽取、OCR与科学验证未运行。

| 物理索引 | 显示物理页 | 状态 |
| --- | --- | --- |
| 0 | 1 | parsed |

| 问题 | 来源单元 | 原因 |
| --- | --- | --- |
