# 有界来源知识核对

状态：failed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": null,
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "229ee48f-9499-4862-8abf-df86e2fc2579",
      "import_id": "e08a9356-0ed5-4fae-8665-e13d27b1d0ad",
      "source_id": "3d7cb8b3-ab15-4f44-b298-4172b9fd05b4",
      "version_id": "a3bd158f-58bc-434b-9ad9-d8de1695f2aa",
      "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "75545232-db60-4dfe-9fc8-60b2cacf743b",
          "ordinal": 0,
          "resource_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 195,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。\n这是独立作者的工程例外测试，不是科学质量基准。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "229ee48f-9499-4862-8abf-df86e2fc2579",
    "import_id": "e08a9356-0ed5-4fae-8665-e13d27b1d0ad",
    "source_id": "3d7cb8b3-ab15-4f44-b298-4172b9fd05b4",
    "version_id": "a3bd158f-58bc-434b-9ad9-d8de1695f2aa",
    "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": null,
    "transport_mode": null,
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "2bc5edab992842de86e31b30b38308e95bbbbf30f232394d3fe165630f741a71",
        "byte_length": 2850
      },
      "decision.json": {
        "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
        "byte_length": 144
      },
      "gold.json": {
        "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
        "byte_length": 704
      },
      "review.json": {
        "sha256": "acae59cea8be9488a4587417060cd694866663d0acf150ea6d708f8e4e09efd2",
        "byte_length": 547
      }
    },
    "gold_sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "issue_codes": [
        "VERIFY_MISSING",
        "VERIFY_SCHEMA"
      ]
    }
  ],
  "candidate_results": [],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_SCHEMA",
      "expected": "strict_schema_1",
      "actual": "missing field `schema_version` at line 16 column 15"
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_MISSING",
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 1,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": null,
    "unexpected_atoms": null,
    "duplicate_atoms": null,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "concept": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "condition": {
      "expected": 2,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 2,
      "status": "unprocessed"
    },
    "content": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "coverage": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "evidence": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "exception": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "schema": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "812bd51d0990260fd4af6def669fe049e0ba700fe56e26af37c71280007813f7",
      "byte_length": 135
    },
    "candidates-original.json": {
      "sha256": "2bc5edab992842de86e31b30b38308e95bbbbf30f232394d3fe165630f741a71",
      "byte_length": 2850
    },
    "decision-original.json": {
      "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
      "byte_length": 144
    },
    "gold-original.json": {
      "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
      "byte_length": 704
    },
    "review-original.json": {
      "sha256": "acae59cea8be9488a4587417060cd694866663d0acf150ea6d708f8e4e09efd2",
      "byte_length": 547
    },
    "source-snapshot.json": {
      "sha256": "8d4e89033d682413e64b15ca484ec17d42626495c9eb4638bf75b277b97c14f4",
      "byte_length": 1085
    }
  }
}
```
