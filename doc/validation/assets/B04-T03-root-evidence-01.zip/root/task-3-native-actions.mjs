import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.NOETOME_PLAYWRIGHT_PACKAGE);
const root = process.cwd();
const sdk = path.join(root, '.superpowers/sdd/B04-T03_REVIEW_PLAN');
const prefix = 'task-3-native-actions-01';
const resultPath = path.join(sdk, `${prefix}.json`);
assert(!existsSync(resultPath));
const launch = JSON.parse(readFileSync(path.join(sdk, 'task-3-native-debug-01-launch.json')));
const report = { schema_version: 1, started_at: new Date().toISOString(), tested_executable: launch.executable, executable_sha256: launch.executable_sha256, pid: launch.pid, url: 'http://tauri.localhost/', transport: 'installed WebView CDP 127.0.0.1:9243', os_metadata: 'read-only GetWindowRect/IsWindowVisible/IsIconic/IsZoomed', physical_drag_verified: false, physical_tray_restore_verified: false, input_scope: 'actual DOM controls and CDP keyboard/mouse events; no OS input injection', checks: [], observations: [], errors: [] };
const hash = p => createHash('sha256').update(readFileSync(p)).digest('hex');
assert.equal(hash(launch.executable), launch.executable_sha256);
report.verifier_sha256 = hash(new URL(import.meta.url));
function probe(label) {
  const args = ['-X', 'utf8', path.join(sdk, 'task-3-native-window-probe.py'), '--exe', launch.executable, '--pid', String(launch.pid), '--label', `actions-01-${label}`];
  const r = spawnSync(process.env.NOETOME_TEST_PYTHON, args, { cwd: root, encoding: 'utf8', timeout: 10000 });
  assert.equal(r.status, 0, r.stderr || r.stdout);
  const file = `task-3-native-actions-01-${label}.json`;
  const data = JSON.parse(readFileSync(path.join(sdk, file)));
  report.observations.push({ label, file, sha256: hash(path.join(sdk, file)), window: data.windows[0] });
  return data.windows[0];
}
async function check(name, fn) {
  try { const detail = await fn(); report.checks.push({ name, passed: true, detail }); }
  catch (error) { report.checks.push({ name, passed: false, error: String(error.stack || error) }); throw error; }
}
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
let page;
async function waitControl(name) {
  await page.waitForFunction(label => [...document.querySelectorAll('.app-window-controls button')].some(b => b.getAttribute('aria-label') === label && !b.disabled), name);
}
async function menu(label, item) {
  await page.locator(`#app-menu-${label.toLowerCase()}`).click();
  await page.locator('#app-menu-dropdown').getByRole('menuitem', { name: item, exact: true }).click();
}
try {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9243');
  const pages = browser.contexts().flatMap(c => c.pages()).filter(p => p.url() === report.url);
  assert.equal(pages.length, 1);
  page = pages[0];
  page.on('pageerror', e => report.errors.push(String(e)));
  page.on('console', m => { if (m.type() === 'error') report.errors.push(m.text()); });
  await page.locator('.app-menu-bar').waitFor();
  await waitControl('最大化');
  await check('one_native_top_row_and_same_row_controls', async () => {
    const os = probe('initial');
    assert(os.visible && !os.minimized && !os.maximized);
    assert(os.native_title_band_height <= 2);
    const dom = await page.evaluate(() => {
      const rect = e => { const r = e.getBoundingClientRect(); return { x: r.x, y: r.y, width: r.width, height: r.height, right: r.right }; };
      return { native: !!window.__TAURI_INTERNALS__, header: rect(document.querySelector('.app-menu-bar')), menus: [...document.querySelectorAll('.app-menu-trigger')].map(e => e.textContent), controls: [...document.querySelectorAll('.app-window-controls button')].map(e => ({ label: e.getAttribute('aria-label'), disabled: e.disabled, rect: rect(e) })), viewport_width: innerWidth };
    });
    assert(dom.native); assert.equal(dom.header.y, 0); assert.equal(dom.header.height, 36);
    assert.deepEqual(dom.menus, ['File', 'Edit', 'View', 'Help']);
    assert.equal(dom.controls.length, 3);
    for (const b of dom.controls) { assert(!b.disabled); assert(b.rect.y >= 0 && b.rect.y + b.rect.height <= 36 && b.rect.right <= dom.viewport_width); }
    return { os, dom };
  });
  await check('actual_maximize_button_and_native_state', async () => {
    await page.getByRole('button', { name: '最大化', exact: true }).click();
    await waitControl('还原'); await pause(250);
    const os = probe('maximized'); assert(os.maximized && os.visible && !os.minimized);
    await page.screenshot({ path: path.join(sdk, `${prefix}-maximized-client.png`) });
    return os;
  });
  await check('keyboard_restore_button_and_native_state', async () => {
    await page.getByRole('button', { name: '还原', exact: true }).focus();
    await page.keyboard.press('Enter'); await waitControl('最大化'); await pause(250);
    const os = probe('keyboard-restored'); assert(!os.maximized && !os.minimized && os.visible); return os;
  });
  await check('actual_minimize_button_preserves_visible_window_object', async () => {
    await page.getByRole('button', { name: '最小化', exact: true }).click(); await pause(350);
    const os = probe('minimized'); assert(os.minimized && os.visible); return os;
  });
  await check('existing_toggle_maximize_api_restores_minimized_window', async () => {
    await page.locator('.app-window-controls button[aria-label="最大化"]').evaluate(b => b.click());
    await waitControl('还原'); await pause(250);
    const os = probe('restore-from-minimize'); assert(!os.minimized && os.maximized && os.visible);
    await page.getByRole('button', { name: '还原', exact: true }).click(); await waitControl('最大化');
    return { os, method: 'existing DOM button click delivered over CDP while minimized; no physical taskbar click claimed' };
  });
  await check('blank_region_double_click_handler_changes_real_native_state_once', async () => {
    await page.locator('.app-window-drag-area').dispatchEvent('mousedown', { button: 0, detail: 2 });
    await waitControl('还原'); await pause(250);
    const os = probe('blank-detail-two'); assert(os.maximized && os.visible);
    await page.getByRole('button', { name: '还原', exact: true }).click(); await waitControl('最大化');
    return { os, event: 'DOM mousedown detail=2 over CDP, physical double-click not claimed' };
  });
  await check('sidebar_toggle_and_file_keyboard_menu', async () => {
    const toggle = page.getByRole('button', { name: '切换侧栏', exact: true });
    await toggle.click(); assert.equal(await page.locator('#app-sidebar').evaluate(e => e.hidden), true);
    await toggle.click(); assert.equal(await page.locator('#app-sidebar').evaluate(e => e.hidden), false);
    await page.locator('#app-menu-file').focus(); await page.keyboard.press('ArrowDown');
    assert.equal(await page.evaluate(() => document.activeElement.textContent.trim()), '工作台');
    await page.keyboard.press('Escape'); assert.equal(await page.locator('#app-menu-dropdown').count(), 0);
    return { sidebar_restored: true, menu_keyboard: 'ArrowDown focuses first enabled item; Escape closes' };
  });
  await check('help_menu_actual_version_ipc', async () => {
    await menu('Help', '查看版本'); await page.locator('.console-status.success').waitFor();
    const output = await page.locator('pre[aria-label="CLI 运行结果"]').textContent();
    assert.match(output, /noetome 0\.1\.0/i);
    writeFileSync(path.join(sdk, `${prefix}-version.txt`), output, { flag: 'wx' }); return { output, actual_native_host: true };
  });
  await check('help_menu_actual_help_ipc_and_runtime_check', async () => {
    await menu('Help', '查看帮助'); await page.locator('.console-status.success').waitFor();
    const output = await page.locator('pre[aria-label="CLI 运行结果"]').textContent();
    assert.match(output, /noetome/i); assert.match(output, /project/);
    writeFileSync(path.join(sdk, `${prefix}-help.txt`), output, { flag: 'wx' });
    await page.getByRole('button', { name: '检查连接', exact: true }).click(); await page.locator('.state-success').waitFor();
    const runtime = await page.locator('.runtime-details').textContent(); assert.match(runtime, /0\.1\.0/);
    return { output_sha256: hash(path.join(sdk, `${prefix}-help.txt`)), runtime };
  });
  await check('navigation_edit_select_all_and_sticky_single_row', async () => {
    await menu('File', '工作台');
    await page.getByRole('button', { name: '后退', exact: true }).click();
    assert.match(await page.locator('h1').textContent(), /检查本地连接/);
    await page.getByRole('button', { name: '前进', exact: true }).click();
    await menu('Edit', '全选');
    const selection = await page.evaluate(() => getSelection().toString()); assert(selection.length > 20);
    await page.evaluate(() => { getSelection().removeAllRanges(); scrollTo(0, document.documentElement.scrollHeight); });
    const dom = await page.evaluate(() => ({ y: document.querySelector('.app-menu-bar').getBoundingClientRect().y, height: document.querySelector('.app-menu-bar').getBoundingClientRect().height, scroll_y: scrollY }));
    assert.equal(dom.y, 0); assert.equal(dom.height, 36); assert(dom.scroll_y > 0);
    await page.evaluate(() => scrollTo(0, 0)); return { selected_characters: selection.length, ...dom, clipboard_writes: 0 };
  });
  await check('close_button_hides_to_tray_without_exiting', async () => {
    await menu('File', '窗口设置'); await page.locator('#close-behavior:not(:disabled)').waitFor();
    report.original_close_behavior = await page.locator('#close-behavior').inputValue();
    if (report.original_close_behavior !== 'hide_to_tray') {
      await page.locator('#close-behavior').selectOption('hide_to_tray'); await page.getByRole('button', { name: '保存设置', exact: true }).click();
      await page.waitForFunction(() => document.querySelector('#window-settings-status').textContent.includes('已保存：隐藏到托盘'));
    }
    await page.getByRole('button', { name: '关闭窗口', exact: true }).click(); await pause(350);
    const os = probe('close-hidden'); assert(!os.visible); return { os, native_process_alive: true, tray_restore_physical_click_pending: true };
  });
  await check('existing_api_restores_hidden_window_and_original_close_preference', async () => {
    await page.locator('.app-window-controls button[aria-label="最大化"]').evaluate(b => b.click());
    await waitControl('还原'); await pause(250);
    const os = probe('restore-from-hidden'); assert(os.visible && os.maximized && !os.minimized);
    await page.getByRole('button', { name: '还原', exact: true }).click(); await waitControl('最大化');
    if (report.original_close_behavior !== 'hide_to_tray') {
      await page.locator('#close-behavior').selectOption(report.original_close_behavior); await page.getByRole('button', { name: '保存设置', exact: true }).click();
      await page.waitForFunction(() => document.querySelector('#window-settings-status').textContent.includes('已保存：'));
    }
    assert.equal(await page.locator('#close-behavior').inputValue(), report.original_close_behavior);
    await menu('File', '工作台');
    return { os, method: 'existing DOM maximize button; physical tray Show click is not claimed', original_close_behavior_restored: true };
  });
  await check('final_normal_geometry_no_ui_error_and_unchanged_installed_binary', async () => {
    const os = probe('final-normal'); assert(os.visible && !os.minimized && !os.maximized && os.native_title_band_height <= 2);
    const alerts = await page.locator('[role="alert"]').allTextContents(); assert.deepEqual(alerts, []); assert.deepEqual(report.errors, []);
    assert.equal(hash(launch.executable), launch.executable_sha256);
    await page.screenshot({ path: path.join(sdk, `${prefix}-final-client.png`) }); return { os, alerts };
  });
} catch (error) { report.failure = String(error.stack || error); }
report.finished_at = new Date().toISOString();
report.passed = !report.failure && report.checks.every(c => c.passed);
writeFileSync(resultPath, JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ evidence: resultPath, passed: report.passed, checks: report.checks.map(c => ({ name: c.name, passed: c.passed })), failure: report.failure || null }));
process.exit(report.passed ? 0 : 1);
