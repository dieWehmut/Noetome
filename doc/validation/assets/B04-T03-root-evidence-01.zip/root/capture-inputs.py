"""Read-only snapshots of the already selected T02 fixture and service files.

No credential decrypt, model request, source edit or recursive cleanup.
The credential reference is hashed as encrypted DPAPI bytes; its contents
are neither parsed nor copied to evidence.
"""
from __future__ import annotations

import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3

REPO = Path(__file__).resolve().parents[3]
SDK = Path(__file__).resolve().parent
LIVE = REPO / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
PROJECT = LIVE / "source-project"
SERVICE = Path(os.environ["LOCALAPPDATA"]) / "Noetome/model-services"
RESPONSES = [
    "73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b",
    "f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a",
    "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b",
    "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9",
    "b04c99ff593ee99431f140747a5c088cf4011a1a87237981e03cd176feb07f8f",
    "019f0ae95e154b230175cd6df31912e8130593f657344db723a4c3da7d8e82ac",
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def receipt(path):
    assert path.is_file() and not path.is_symlink(), path
    stat = path.stat()
    assert stat.st_nlink == 1, path
    data = path.read_bytes()
    end = path.stat()
    assert (stat.st_size, stat.st_mtime_ns, stat.st_ino) == (end.st_size, end.st_mtime_ns, end.st_ino), path
    return {"sha256": sha(data), "byte_length": len(data), "mtime_ns": stat.st_mtime_ns}


def capture():
    previous = json.loads((LIVE / "source-before.json").read_bytes())
    actual = {key: receipt(PROJECT / key) for key in previous["project_files"]}
    assert actual == previous["project_files"], "T02 source files differ from original before-call snapshot"
    actual_names = {str(p.relative_to(PROJECT)) for p in PROJECT.rglob("*") if p.is_file()}
    assert actual_names == set(actual), "source file inventory differs"
    with closing(sqlite3.connect((PROJECT / "project.sqlite").resolve().as_uri() + "?mode=ro&immutable=1", uri=True)) as db:
        sql = list(db.iterdump())
    assert sha("\n".join(sql).encode()) == "28a25e0f7f3cfe2395b51e82c9e5134ed2ce900a5bf9c9cccafcac18eefa9fc5"
    files = {"source-before.json": receipt(LIVE / "source-before.json"), "gold-before.json": receipt(LIVE / "gold-before.json")}
    assert files["gold-before.json"]["sha256"] == previous["gold_sha256"]
    for ordinal, digest in enumerate(RESPONSES, 1):
        response = LIVE / f"api-live-{ordinal:02d}" / "response.bin"
        current = receipt(response)
        assert current["sha256"] == digest, ordinal
        files[f"api-live-{ordinal:02d}/response.bin"] = current
        for name in ["request.json", "request-body.json", "validation.json", "validation.md"]:
            path = response.parent / name
            if path.is_file():
                files[f"api-live-{ordinal:02d}/{name}"] = receipt(path)
        for name in [f"live-command-{ordinal:02d}.json", f"live-budget-reservation-{ordinal:02d}.json", f"live-budget-settlement-{ordinal:02d}.json"]:
            files[name] = receipt(LIVE / name)
    files["api-live-06/candidates.json"] = receipt(LIVE / "api-live-06/candidates.json")
    assert files["api-live-06/candidates.json"]["sha256"] == "92fed9123fa6f711ce76df524e4ff79a36aada79a7c4f5fb72f64f68027915fa"
    for name in ["api-real-config.json", "api-chat-config.json", "api-chat-preflight-config.json"]:
        files[name] = receipt(LIVE / name)
    ledger = json.loads((SERVICE / "tangmao-deepseek.usage.json").read_bytes())
    budget = {key: ledger[key] for key in ["approved_total_tokens", "accounted_tokens", "pending_reserved_tokens", "remaining_tokens", "model_attempts"]}
    assert budget == {"approved_total_tokens": 10000000, "accounted_tokens": 30097, "pending_reserved_tokens": 0, "remaining_tokens": 9969903, "model_attempts": 6}
    assert [record["confirmed_total_tokens"] for record in ledger["records"]] == [936, 9683, 4912, 4783, 3479, 6304]
    assert sum(record["confirmed_total_tokens"] for record in ledger["records"]) == budget["accounted_tokens"]
    saved = {
        "model_profile": receipt(SERVICE / "tangmao-deepseek.json"),
        "cumulative_ledger": receipt(SERVICE / "tangmao-deepseek.usage.json"),
        "encrypted_dpapi_reference": receipt(SERVICE.parent / "credentials/tangmao-deepseek.dpapi"),
    }
    candidate = json.loads((LIVE / "api-live-06/candidates.json").read_bytes())
    raw = json.loads((LIVE / "api-live-06/response.bin").read_bytes())
    assert candidate["payload"] == json.loads(raw["choices"][0]["message"]["content"])
    gold = json.loads((LIVE / "gold-before.json").read_bytes())
    atom = candidate["payload"]["atoms"][0]
    assert atom["measurement"]["value"] == gold["value"] and atom["measurement"]["unit"] == gold["unit"]
    assert set(gold["conditions"]) < set(atom["measurement"]["conditions"])
    return {"source_files": actual, "source_sql_sha256": sha("\n".join(sql).encode()), "source_file_inventory": sorted(actual_names), "immutable_call_inputs": files, "saved_service_receipts": saved, "budget": budget}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["before", "after"])
    args = parser.parse_args()
    facts = capture()
    if args.phase == "after":
        before = json.loads((SDK / "root-inputs-before.json").read_bytes())
        assert facts == before["facts"], "B04-T03 changed original source/candidate/gold/response/config/budget"
    result = {"phase": args.phase, "captured_at": datetime.now(timezone.utc).isoformat(), "source": str(Path(__file__)), "source_sha256": sha(Path(__file__).read_bytes()), "facts": facts, "new_network_calls": 0, "credential_decryptions": 0, "checks_passed": True}
    destination = SDK / f"root-inputs-{args.phase}.json"
    with destination.open("x", encoding="utf-8", newline="\n") as out:
        out.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"phase": args.phase, "source_files": len(facts["source_files"]), "original_responses": len(RESPONSES), "frozen_gold_unchanged": True, "budget": facts["budget"], "evidence": str(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
