"""Fresh review: audit existing bytes/receipts only; never invoke CLI or suites."""
import collections
import hashlib
import json
from pathlib import Path
import re
import zipfile

REPO = Path('D:/Noetome')
SDK = REPO / '.superpowers/sdd/B04-T03_REVIEW_PLAN'
ASSETS = REPO / 'doc/validation/assets'
checks = []
fingerprints = {}

def fp(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))

def check(value, label):
    checks.append(dict(label=label, passed=bool(value)))
    if not value:
        raise AssertionError(label)

def load(path):
    raw = path.read_bytes()
    fingerprints[str(path)] = fp(raw)
    return json.loads(raw)

def main():
    manifest = load(ASSETS / 'B04-T03-task-2-manifest.json')
    audit = load(ASSETS / 'B04-T03-task-2-audit.json')
    archive = ASSETS / manifest['archive']
    fingerprints[str(archive)] = fp(archive.read_bytes())
    check(fingerprints[str(archive)] == dict(sha256=manifest['archive_sha256'], byte_length=manifest['archive_byte_length']), 'archive SHA/length')
    with zipfile.ZipFile(archive) as z:
        check(len(z.namelist()) == len(set(z.namelist())) == len(manifest['files']) == 3829, 'archive unique 3829 entries')
        check(set(z.namelist()) == {x['member'] for x in manifest['files']}, 'manifest exact archive membership')
        for f in manifest['files']:
            expected = {k:f[k] for k in ('sha256','byte_length')}
            check(fp(z.read(f['member'])) == expected, 'archive bytes: '+f['member'])
        check(z.read('runs/B04-T03-task-2-matrix-07/audit.json') == (ASSETS / 'B04-T03-task-2-audit.json').read_bytes(), 'archived final audit exact committed bytes')
    root = Path(manifest['final_root'])
    check(audit['scenario_count'] == len(audit['rows']) == 52, '52 real scenario rows')
    check(len(audit['calls']) == manifest['calls'] == 60, '60 real CLI receipts')
    check(audit['report_count'] == sum('verification' in r for r in audit['rows']) == 34, '34 report rows')
    check(audit['passed_knowledge_samples'] == sum(r.get('verification',{}).get('status') == 'passed' for r in audit['rows']) == 5, '5 bounded passed knowledge samples')
    check(audit['error'] is None and manifest['real_original_sixth_executed'] is False, 'offline completed; original06 explicitly pending')
    binary = Path(audit['binary'])
    fingerprints[str(binary)] = fp(binary.read_bytes())
    check(fingerprints[str(binary)] == audit['binary_fingerprint'], 'current unchanged binary fingerprint')
    for i,c in enumerate(audit['calls'],1):
        saved = load(root / ('call-%03d.json' % i))
        check(c == saved, 'call receipt %d exact saved bytes/fields' % i)
        for stream in ('stdout','stderr'):
            check(fp(c[stream].encode()) == c[stream+'_fingerprint'], 'call %d %s fingerprint' % (i,stream))
        check(c['argv'][1:3] in (['project','init'],['source','import'],['extract','verify']), 'call %d offline command allowlist' % i)
    status_counts = collections.Counter()
    for r in audit['rows']:
        c = audit['calls'][r['call_index']-1]
        check(c['exit_code'] == r['observed_exit'] == r['expected_exit'], r['name']+' actual exit')
        if 'verification' not in r:
            continue
        out = Path(r['output'])
        report = load(out/'verification.json')
        md = (out/'verification.md').read_text(encoding='utf-8')
        matches = re.findall(r'```json\n(.*?)\n```',md,re.S)
        check(len(matches)==1 and json.loads(matches[0])==report, r['name']+' independently parsed JSON/MD')
        check(json.loads(c['stdout']) == report, r['name']+' stdout equals saved JSON')
        check(report['totals']['expected_atoms']==sum(report['totals'][s] for s in ('passed','failed','needs_review','unprocessed'))==1, r['name']+' expected denominator partition')
        check(report['status']==r['verification']['status'],r['name']+' saved observed status')
        status_counts[report['status']] += 1
        for name, expected in r['output_fingerprints'].items():
            check(fp((out/name).read_bytes())==expected,r['name']+' output SHA/length '+name)
        for name, expected in report['artifacts'].items():
            check(fp((out/name).read_bytes())==expected,r['name']+' artifact SHA/length '+name)
        gold = json.loads((out/'gold-original.json').read_bytes())
        check(report['quality']['condition']['expected']==len(gold['conditions']),r['name']+' frozen condition denominator')
        check(report['quality']['exception']['expected']==len(gold.get('exceptions',[])),r['name']+' frozen exception denominator')
        if not gold.get('exceptions',[]):
            check(report['quality']['exception']['status']=='not_applicable',r['name']+' empty exception not_applicable')
        snapshot = json.loads((out/'source-snapshot.json').read_bytes())
        check(snapshot['binding']==report['binding'] and snapshot['units']==report['scope']['units'],r['name']+' snapshot/report same facts')
        check((out/'knowledge-ir.json').exists()==(report['status']=='passed'),r['name']+' IR only passed')
        if report['status']=='passed':
            ir=json.loads((out/'knowledge-ir.json').read_bytes())
            payload=json.loads((out/'candidates-original.json').read_bytes())['payload']
            for key in ('concepts','atoms','evidence'):
                check(ir[key]==payload[key],r['name']+' IR exact original '+key)
            check(all(a['atom']['verification']=='unverified' and a['atom']['required'] is False for a in ir['atoms']),r['name']+' IR unverified/required false')
    paired = 0
    for i,receipt in enumerate(audit['source_receipts']):
        if 'inventory_after' in receipt:
            paired += 1
            check(receipt['inventory']==receipt['inventory_after'], 'source receipt %d original SHA/mtime/identity/inventory unchanged'%i)
            check(receipt['sql']==receipt['sql_after'], 'source receipt %d SQL unchanged'%i)
    for name, expected in audit['author_gold_before_cli'].items():
        check(fp((root/name).read_bytes())==expected,'author gold remains '+name)
    for name, needles in {
        'B04-T03-task-2-red-behavior.log':['Ran 15 tests','FAILED (failures=14)'],
        'B04-T03-task-2-red-results.log':['Ran 19 tests','FAILED (failures=4)'],
        'B04-T03-task-2-green-final.log':['Ran 19 tests','OK'],
    }.items():
        data=(ASSETS/name).read_bytes()
        fingerprints[str(ASSETS/name)]=fp(data)
        check(all(n in data.decode() for n in needles), name+' actual test summary')
    diff=SDK/'review-98fbbea..bb33808.diff'
    raw=diff.read_bytes()
    fingerprints[str(diff)]=fp(raw)
    files=re.findall(r'^diff --git a/(.*?) b/',raw.decode().replace('\r\n','\n'),re.M)
    for name in files:
        path=REPO/name
        if path.is_file(): fingerprints[str(path)]=fp(path.read_bytes())
    for name in ('scripts/verify_extraction_knowledge.py','tests/test_extraction_knowledge_verifier.py'):
        section=next(p for p in re.split(r'(?m)(?=^diff --git )',raw.decode().replace('\r\n','\n')) if p.startswith('diff --git a/'+name+' '))
        added='\n'.join(l[1:] for l in section.splitlines() if l.startswith('+') and not l.startswith('+++'))+'\n'
        check(added==(REPO/name).read_text(encoding='utf-8'),name+' full added diff equals current source')
    return dict(archive_entries=3829,calls=60,scenarios=52,reports=34,knowledge_passed=5,source_before_after_pairs=paired,status_counts=dict(status_counts),changed_files=files)

result={'review_scope':'Task 2 immutable diff; read-only evidence audit; no CLI/suite/build/network/original06 execution', 'commands': ['selected Python -X utf8 -B .superpowers/sdd/B04-T03_REVIEW_PLAN/task-2-review-audit.py'], 'process_deviation':'Initial parallel onboarding command ran git status --short --branch once before the no-Git brief was read. Read-only result; no further Git command and no product/index/HEAD/branch mutation.'}
try:
    result['summary']=main()
except Exception as exc:
    result['audit_error']=repr(exc)
    raise
finally:
    result['assertion_count']=len(checks)
    result['passed_assertions']=sum(x['passed'] for x in checks)
    result['checks']=checks
    result['fingerprints']=fingerprints
    (SDK/'task-2-review-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','fingerprints')},ensure_ascii=False))
