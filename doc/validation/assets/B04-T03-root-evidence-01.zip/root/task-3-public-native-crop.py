"""Crop the actual foreground screenshot to DWM's visible Noetome frame."""
from __future__ import annotations
import ctypes
from ctypes import wintypes as w
import hashlib
import json
from pathlib import Path
from PIL import Image

SDK = Path(__file__).resolve().parent
ASSETS = SDK.parents[2] / "doc/validation/assets"
capture = json.loads((SDK / "task-3-native-full-capture.json").read_bytes())
assert capture["selected_is_foreground"] and capture["screen_crop_captured"]
user = ctypes.WinDLL("user32", use_last_error=True)
dwm = ctypes.WinDLL("dwmapi", use_last_error=True)
user.SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
user.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
dwm.DwmGetWindowAttribute.argtypes = [w.HWND, w.DWORD, ctypes.c_void_p, w.DWORD]
dwm.DwmGetWindowAttribute.restype = ctypes.c_long
frame = w.RECT()
assert dwm.DwmGetWindowAttribute(capture["selected"]["hwnd"], 9, ctypes.byref(frame), ctypes.sizeof(frame)) == 0
bounds = capture["physical_window_rect"]
crop = [frame.left-bounds[0], frame.top-bounds[1], frame.right-bounds[0], frame.bottom-bounds[1]]
image = Image.open(SDK / "task-3-native-full-screen.png")
assert 0 <= crop[0] < crop[2] <= image.width and 0 <= crop[1] < crop[3] <= image.height
visible = image.crop(tuple(crop))
full_path = ASSETS / "B04-T03-ui-native-full-window.png"
header_path = ASSETS / "B04-T03-ui-native-header.png"
assert not full_path.exists() and not header_path.exists()
visible.save(full_path)
visible.crop((0, 0, visible.width, 76)).save(header_path)
record = {
    "source_capture_sha256": hashlib.sha256((SDK / "task-3-native-full-screen.png").read_bytes()).hexdigest(),
    "actual_selected_foreground_window": capture["selected"],
    "physical_window_rect": bounds, "dwm_visible_frame_rect": [frame.left, frame.top, frame.right, frame.bottom],
    "crop_from_original": crop, "caption_top_was_preserved": crop[1] <= 2,
    "purpose": "Remove invisible resize borders containing unrelated background pixels; preserve actual full visible frame and top menu pixels",
    "artifacts": {p.name: {"sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "byte_length": p.stat().st_size} for p in [full_path, header_path]},
    "raw_screen_kept_local_only": True,
}
assert record["caption_top_was_preserved"]
with (SDK / "task-3-native-public-crop.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps(record, ensure_ascii=False))
