"""Record final unchanged-input comparisons and the two real probe receipts."""
import hashlib
import json
from pathlib import Path

sdk=Path('D:/Noetome/.superpowers/sdd/B04-T03_REVIEW_PLAN')
path=sdk/'task-2-review-evidence.json'
e=json.loads(path.read_bytes())
def fp(p):
    raw=p.read_bytes()
    return {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}
e['end_unchanged_comparisons']=[]
for name,expected in e['fingerprints'].items():
    observed=fp(Path(name))
    same=observed==expected
    e['end_unchanged_comparisons'].append({'path':name,'passed':same,'observed':observed})
    assert same,name
e['focused_probes']=[json.loads((sdk/('task-2-review-probe-'+m+'.json')).read_bytes()) for m in ('strict-boolean','diagnostic-identity')]
e['focused_probe_invocations']=2
e['focused_probe_setup_assertions']=sum(p['explicit_probe_assertions'] for p in e['focused_probes'])
e['focused_probe_corruptions_rejected']=sum(p['corruption_rejected'] for p in e['focused_probes'])
e['final_unchanged_assertions']=len(e['end_unchanged_comparisons'])
e['reviewer_artifacts']={str(sdk/n):fp(sdk/n) for n in ('task-2-review.md','task-2-review-audit.py','task-2-review-probe.py','task-2-review-finalize.py','task-2-review-probe-strict-boolean.json','task-2-review-probe-diagnostic-identity.json')}
e['verdict']={'spec_compliance':'Issues found','task_quality':'Needs fixes','critical':0,'important':['R1: incomplete typed candidate validation accepts false successful IR','R2: per-check object identity and diagnostic codes are not independently verified'],'controller_original06_full_closure':'pending by design; not executed here'}
e['commands'].append('selected Python -X utf8 -B .superpowers/sdd/B04-T03_REVIEW_PLAN/task-2-review-finalize.py')
path.write_text(json.dumps(e,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:e[k] for k in ('assertion_count','passed_assertions','focused_probe_invocations','focused_probe_setup_assertions','focused_probe_corruptions_rejected','final_unchanged_assertions','verdict')},ensure_ascii=False))
