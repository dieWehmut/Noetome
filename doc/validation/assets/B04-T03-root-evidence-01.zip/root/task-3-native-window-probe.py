"""Read native window metadata for the selected installed Noetome executable.

This performs no app input, activation, SendInput, UI Automation or state changes.
"""
from __future__ import annotations
import argparse
import ctypes
from ctypes import wintypes as w
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

SDK = Path(__file__).resolve().parent
user = ctypes.WinDLL("user32", use_last_error=True)
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
user.GetWindowThreadProcessId.argtypes = [w.HWND, ctypes.POINTER(w.DWORD)]
user.GetWindowThreadProcessId.restype = w.DWORD
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
kernel.QueryFullProcessImageNameW.restype = w.BOOL
kernel.CloseHandle.argtypes = [w.HANDLE]
user.GetWindowTextW.argtypes = [w.HWND, w.LPWSTR, ctypes.c_int]
user.GetWindowTextW.restype = ctypes.c_int
user.GetWindowRect.argtypes = [w.HWND, ctypes.POINTER(w.RECT)]
user.GetClientRect.argtypes = [w.HWND, ctypes.POINTER(w.RECT)]
user.ClientToScreen.argtypes = [w.HWND, ctypes.POINTER(w.POINT)]
user.GetWindowLongPtrW.argtypes = [w.HWND, ctypes.c_int]
user.GetWindowLongPtrW.restype = ctypes.c_ssize_t
for operation in (user.IsWindowVisible, user.IsIconic, user.IsZoomed):
    operation.argtypes = [w.HWND]
    operation.restype = w.BOOL
CALLBACK = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
user.EnumWindows.argtypes = [CALLBACK, w.LPARAM]


def image_path(pid: int) -> str | None:
    handle = kernel.OpenProcess(0x1000, False, pid)
    if not handle:
        return None
    try:
        size = w.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(size.value)
        return buffer.value if kernel.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)) else None
    finally:
        kernel.CloseHandle(handle)


def rectangle(rect: w.RECT) -> list[int]:
    return [rect.left, rect.top, rect.right, rect.bottom]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--exe", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--pid", type=int)
    parser.add_argument("--expect-caption-absent", action="store_true")
    parser.add_argument("--expect-title-band-absent", action="store_true")
    args = parser.parse_args()
    target = args.exe.resolve(strict=True)
    assert args.label and all(c.isalnum() or c in "-_" for c in args.label)
    destination = SDK / f"task-3-native-{args.label}.json"
    assert not destination.exists()
    windows = []

    @CALLBACK
    def inspect(hwnd, _):
        pid = w.DWORD()
        user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if args.pid is not None and pid.value != args.pid:
            return True
        image = image_path(pid.value)
        if image is None or str(Path(image).resolve()).casefold() != str(target).casefold():
            return True
        title = ctypes.create_unicode_buffer(1024)
        user.GetWindowTextW(hwnd, title, len(title))
        if title.value != "Noetome":
            return True
        outer, client, origin = w.RECT(), w.RECT(), w.POINT(0, 0)
        assert user.GetWindowRect(hwnd, ctypes.byref(outer))
        assert user.GetClientRect(hwnd, ctypes.byref(client))
        assert user.ClientToScreen(hwnd, ctypes.byref(origin))
        style = user.GetWindowLongPtrW(hwnd, -16) & 0xFFFFFFFF
        left_border = origin.x - outer.left
        right_border = outer.right - origin.x - client.right
        top_border = origin.y - outer.top
        title_band = max(0, top_border - max(left_border, right_border)) if not user.IsIconic(hwnd) else None
        windows.append({
            "hwnd": int(hwnd), "pid": pid.value, "exe": image, "title": title.value,
            "style": style, "style_hex": f"0x{style:08x}",
            "caption_present": bool(style & 0x00C00000),
            "caption_field_means_style_bits_only": True,
            "visible": bool(user.IsWindowVisible(hwnd)), "minimized": bool(user.IsIconic(hwnd)),
            "maximized": bool(user.IsZoomed(hwnd)), "window_rect": rectangle(outer),
            "client_rect": rectangle(client), "client_origin_screen": [origin.x, origin.y],
            "client_top_offset": origin.y - outer.top,
            "left_border": left_border, "right_border": right_border,
            "native_title_band_height": title_band,
        })
        return True

    assert user.EnumWindows(inspect, 0)
    unique = len(windows) == 1
    absent = unique and not windows[0]["caption_present"]
    checks = [{"name": "unique_selected_installed_window", "passed": unique, "actual": len(windows), "expected": 1}]
    if args.expect_caption_absent:
        checks.append({"name": "native_caption_absent", "passed": absent, "actual": windows[0]["caption_present"] if unique else None, "expected": False})
    if args.expect_title_band_absent:
        band = windows[0]["native_title_band_height"] if unique else None
        checks.append({"name": "no_extra_native_title_band", "passed": band is not None and band <= 2, "actual": band, "maximum": 2})
    result = {
        "schema_version": 1, "captured_at": datetime.now(timezone.utc).isoformat(),
        "command": [sys.executable, *sys.argv], "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "exe_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "exe_bytes": target.stat().st_size,
        "windows": windows, "checks": checks, "passed": all(c["passed"] for c in checks),
        "app_inputs": 0, "ui_automation_calls": 0, "app_state_changes": 0,
    }
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"evidence": str(destination), "checks": checks, "windows": windows, "passed": result["passed"]}, ensure_ascii=False))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
