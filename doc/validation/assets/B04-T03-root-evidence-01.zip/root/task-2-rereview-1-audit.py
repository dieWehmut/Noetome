"""Scoped Fix1 retained-byte audit. No verifier, CLI, suites or builds invoked."""
import ast
import collections
import hashlib
import json
from pathlib import Path
import re
import zipfile

REPO = Path('D:/Noetome')
SDK = REPO / '.superpowers/sdd/B04-T03_REVIEW_PLAN'
ASSETS = REPO / 'doc/validation/assets'
checks, fingerprints = [], {}

def fp(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

def check(value, label):
    checks.append({'label': label, 'passed': bool(value)})
    if not value:
        raise AssertionError(label)

def read(path):
    raw = path.read_bytes()
    fingerprints[str(path)] = fp(raw)
    return raw

def load(path):
    return json.loads(read(path))

def schema_ok(value, schema):
    """Independent generic saved-request JSON wire schema, exact JSON scalar types."""
    if 'anyOf' in schema:
        return any(schema_ok(value, s) for s in schema['anyOf'])
    kind = schema.get('type')
    expected = {'object': dict, 'array': list, 'string': str, 'integer': int, 'boolean': bool, 'null': type(None)}
    if kind and type(value) is not expected[kind]:
        return False
    if 'enum' in schema and not any(type(value) is type(x) and value == x for x in schema['enum']):
        return False
    if kind == 'object':
        props = schema['properties']
        if not set(schema.get('required', [])) <= set(value):
            return False
        if schema.get('additionalProperties') is False and not set(value) <= set(props):
            return False
        return all(schema_ok(x, props[k]) for k, x in value.items())
    if kind == 'array':
        return all(schema_ok(x, schema['items']) for x in value)
    return True

def patched_source(name, original_diff, fix_diff):
    original = next(s for s in re.split(r'(?m)(?=^diff --git )', original_diff) if s.startswith('diff --git a/'+name+' '))
    before = [s[1:] for s in original.splitlines() if s.startswith('+') and not s.startswith('+++')]
    patch = next(s for s in re.split(r'(?m)(?=^diff --git )', fix_diff) if s.startswith('diff --git a/'+name+' '))
    out, cursor = [], 0
    for hunk in re.split(r'(?m)(?=^@@ )', patch)[1:]:
        lines = hunk.splitlines()
        start = int(re.match(r'@@ -(\d+)', lines[0])[1])-1
        out.extend(before[cursor:start])
        cursor = start
        for line in lines[1:]:
            if line.startswith((' ', '-')):
                check(before[cursor] == line[1:], name+' patch preimage line '+str(cursor+1))
                cursor += 1
            if line.startswith((' ', '+')):
                out.append(line[1:])
    out.extend(before[cursor:])
    return '\n'.join(out)+'\n'

def main():
    manifest = load(ASSETS / 'B04-T03-task-2-fix-1-manifest.json')
    archive = ASSETS / manifest['archive']
    check(fp(read(archive)) == {'sha256':manifest['archive_sha256'], 'byte_length':manifest['archive_byte_length']}, 'archive real SHA/length')
    retained = {}
    with zipfile.ZipFile(archive) as bundle:
        check(len(bundle.namelist()) == len(set(bundle.namelist())) == manifest['entry_count'] == 2960, '2960 unique actual archive entries')
        check(set(bundle.namelist()) == {f['member'] for f in manifest['files']}, 'exact archive membership')
        for row in manifest['files']:
            raw = bundle.read(row['member'])
            check(fp(raw) == {k:row[k] for k in ('sha256','byte_length')}, 'archived member SHA/size '+row['member'])
            retained[row['member']] = raw
    original_diff = read(SDK / 'review-98fbbea..bb33808.diff').decode().replace('\r\n','\n')
    fix_diff = read(SDK / 'review-7ce4b09..b2c0cba.diff').decode().replace('\r\n','\n')
    files = re.findall(r'^diff --git a/(.*?) b/', fix_diff, re.M)
    check(len(files) == 11 and len(set(files)) == 11, 'exact fix patch has11 unique files')
    for name in files:
        if not name.startswith('doc/') or name.endswith('.zip'):
            continue
        section = next(s for s in re.split(r'(?m)(?=^diff --git )', fix_diff) if s.startswith('diff --git a/'+name+' '))
        added='\n'.join(s[1:] for s in section.splitlines() if s.startswith('+') and not s.startswith('+++'))+'\n'
        check(added==read(REPO/name).decode().replace('\r\n','\n'), name+' exact added fix artifact')
    for name in ('scripts/verify_extraction_knowledge.py', 'tests/test_extraction_knowledge_verifier.py'):
        archived = retained['source/'+name]
        current = read(REPO/name)
        check(current == archived, name+' current bytes equal tested archive')
        check(patched_source(name, original_diff, fix_diff) == archived.decode().replace('\r\n','\n'), name+' exact patch reconstructs tested source')
    tree = ast.parse(retained['source/tests/test_extraction_knowledge_verifier.py'])
    test_names = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    check(len(test_names) == 28 and len(set(test_names)) == 28, '28 actual test methods; no inherited duplicate names')
    check(sum(n.startswith('test_fix1_') for n in test_names) == 9, '9 Fix1 methods supplement existing19')
    schema_request = load(ASSETS/'B04-T02-live-fifth-request-body.json')
    message = json.loads(next(x['content'] for x in schema_request['messages'] if x['role'] == 'user'))
    wire = message['response_schema']
    atom_schema = wire['properties']['atoms']['items']['properties']['atom']
    check(atom_schema['properties']['kind']['enum'] == ['definition','statement','comparison_value'], 'actual saved external kind enum')
    check(atom_schema['properties']['value_status']['enum'] == ['known','unknown','not_applicable'], 'actual saved external value-status enum')
    check(atom_schema['properties']['evidence_links']['items']['properties']['relation']['enum'] == ['supports','refutes','qualifies'], 'actual saved external evidence relation enum')
    root = Path(manifest['final_matrix_root'])
    audit = load(root/'audit.json')
    check(read(root/'audit.json') == retained['runs/'+root.name+'/audit.json'], 'final real audit equals archive bytes')
    check(audit['error'] is None and len(audit['rows']) == audit['scenario_count'] == 52, '52 completed actual rows')
    check(len(audit['calls']) == manifest['call_count'] == 60, '60 retained real CLI calls')
    check(fp(read(Path(audit['binary']))) == audit['binary_fingerprint'], 'unchanged debug binary exact tested SHA/size')
    for i, call in enumerate(audit['calls'], 1):
        check(load(root/('call-%03d.json'%i)) == call, 'call%d exact standalone receipt'%i)
        for stream in ('stdout','stderr'):
            check(fp(call[stream].encode()) == call[stream+'_fingerprint'], 'call%d %s SHA/size'%(i,stream))
        check(call['argv'][1:3] in (['project','init'],['source','import'],['extract','verify']), 'call%d offline CLI scope'%i)
    statuses, diagnostics, nullable = collections.Counter(), 0, []
    for row in audit['rows']:
        call = audit['calls'][row['call_index']-1]
        check(call['exit_code'] == row['observed_exit'] == row['expected_exit'], row['name']+' actual expected exit')
        if 'verification' not in row:
            continue
        out = Path(row['output'])
        report = load(out/'verification.json')
        md = read(out/'verification.md').decode()
        snapshots = re.findall(r'```json\n(.*?)\n```',md,re.S)
        check(len(snapshots)==1 and json.loads(snapshots[0])==report, row['name']+' JSON/MD exact facts')
        check(json.loads(call['stdout']) == report, row['name']+' actual stdout exact JSON')
        check(report['status'] == row['verification']['status'], row['name']+' audit actual status')
        statuses[report['status']] += 1
        for name, expected in row['output_fingerprints'].items():
            check(fp(read(out/name)) == expected, row['name']+' output fingerprint '+name)
        for name, expected in report['artifacts'].items():
            check(fp(read(out/name)) == expected, row['name']+' artifact fingerprint '+name)
        totals = report['totals']
        check(totals['expected_atoms'] == sum(totals[s] for s in ('passed','failed','needs_review','unprocessed')) == 1, row['name']+' true expected denominator1')
        gold = load(out/'gold-original.json')
        review = load(out/'review-original.json')
        for category, denominator in (('condition',len(gold['conditions'])),('unit',int(gold['unit'] is not None)),('exception',len(gold.get('exceptions',[])))):
            quality = report['quality'][category]
            check(quality['expected']==sum(quality[s] for s in ('passed','failed','needs_review','unprocessed'))==denominator, row['name']+' author denominator '+category)
            if denominator == 0:
                check(quality['status'] == 'not_applicable', row['name']+' empty '+category+' not_applicable')
        check((out/'knowledge-ir.json').exists() == (report['status']=='passed'), row['name']+' real IR presence')
        if totals['candidate_atoms'] is None:
            nullable.append(row['name'])
            check(totals['unexpected_atoms'] is None and totals['duplicate_atoms'] is None and report['candidate_results']==[], row['name']+' actual syntax-unknown nullable counts')
            continue
        candidate = json.loads(read(out/'candidates-original.json'))
        typed = report['quality']['schema']['status'] == 'passed'
        if not typed:
            check(report['status']!='passed' and totals['duplicate_atoms'] is None, row['name']+' schema rejection no invented duplicate count')
            continue
        check(schema_ok(candidate['payload'], wire), row['name']+' independent complete saved payload type/field/enum schema')
        items = candidate['payload']['atoms']
        check(totals['candidate_atoms']==len(items)==len(report['candidate_results']), row['name']+' actual candidate occurrence count')
        snapshot = load(out/'source-snapshot.json')
        unit = snapshot['units'][0]
        observed = report['checks']
        starts = [i for i,x in enumerate(observed) if x['category']=='duplicate']
        bounds = [(i-int(i>0 and observed[i-1]['category']=='strict_candidate')) for i in starts]
        segments = [(begin,bounds[index+1] if index+1<len(bounds) else len(observed)) for index,begin in enumerate(bounds)]
        shared_categories = {'schema','source','exclusion','coverage','binding'}
        for position, diagnostic in enumerate(observed):
            category = diagnostic['category']
            atom_index = next((i for i,(begin,end) in enumerate(segments) if begin<=position<end), -1)
            if category in shared_categories or (category=='strict_candidate' and diagnostic['object_id']=='expected-0'):
                check(diagnostic['object_id']=='expected-0', row['name']+' shared expected identity '+category)
            elif category=='evidence_identity':
                evidence = next(e for e in candidate['payload']['evidence'] if e['evidence_id']==diagnostic['object_id'])
                check(type(diagnostic['start_byte']) is int and type(diagnostic['end_byte']) is int and diagnostic['start_byte']==evidence['excerpt_start_byte'] and diagnostic['end_byte']==evidence['excerpt_end_byte'], row['name']+' actual evidence-local raw offsets')
                check(evidence['evidence_id'] in {x['evidence_id'] for x in items[atom_index]['atom']['evidence_links'] if x['relation']=='supports'}, row['name']+' evidence belongs to this actual occurrence')
            else:
                check(diagnostic['object_id']==items[atom_index]['atom']['atom_id'], row['name']+' per-occurrence identity '+category)
            check(diagnostic['unit_id']==unit['unit_id'], row['name']+' diagnostic actual unit '+category)
            if category!='evidence_identity':
                check(type(diagnostic['start_byte']) is int and type(diagnostic['end_byte']) is int and diagnostic['start_byte']==unit['start_byte'] and diagnostic['end_byte']==unit['end_byte'], row['name']+' diagnostic exact unit offsets '+category)
            codes = {'condition_set':'VERIFY_CONDITION','exception_set':'VERIFY_EXCEPTION','qualifiers':'VERIFY_CONDITION','evidence_identity':'VERIFY_EVIDENCE','source':'VERIFY_SOURCE_REVIEW','coverage':'VERIFY_MISSING' if not items else 'VERIFY_COVERAGE'}
            if category!='strict_candidate':
                expected_code = None if diagnostic['status']=='passed' else ('VERIFY_UNKNOWN' if category=='fact' and diagnostic['status']=='needs_review' else codes.get(category,'VERIFY_'+category.upper()))
                check(diagnostic['code']==expected_code, row['name']+' exact category/state code '+category)
            diagnostics += 1
        check(report['expected_results'][0]['issue_codes']==sorted({x['code'] for x in observed if x['code'] is not None}), row['name']+' complete expected issue set')
        for index, item in enumerate(items):
            # Slice starts at strict+duplicate or duplicate, never grouping by raw ID.
            begin,end=segments[index]
            codes = sorted({x['code'] for x in observed[begin:end] if x['status']=='failed' and x['object_id']==item['atom']['atom_id'] and x['code'] is not None})
            check(report['candidate_results'][index]['object_id']==item['atom']['atom_id'] and report['candidate_results'][index]['issue_codes']==codes, row['name']+' actual occurrence%d issue set'%index)
        if report['status']=='passed':
            ir = load(out/'knowledge-ir.json')
            for key in ('concepts','atoms','evidence'):
                check(ir[key]==candidate['payload'][key], row['name']+' IR retains exact original '+key)
    check(sum(statuses.values()) == 34 and statuses['passed']==5, 'actual34 reports5 bounded pass')
    source_pairs = 0
    for i, receipt in enumerate(audit['source_receipts']):
        if 'inventory_after' in receipt:
            source_pairs += 1
            check(receipt['inventory']==receipt['inventory_after'], 'source%d saved real SHA/mtime/identity unchanged'%i)
            check(receipt['sql']==receipt['sql_after'], 'source%d saved real SQL unchanged'%i)
    log_summaries = {}
    for name, count, summary in (
        ('red.log',4,'FAILED (failures=15)'), ('red-diagnostics.log',7,'FAILED (failures=5)'),
        ('red-evidence-range.log',1,'FAILED (failures=1)'), ('red-diagnostic-type.log',1,'FAILED (failures=1)'),
        ('green.log',26,'OK'), ('green-final.log',27,'OK'), ('green-final-2.log',28,'OK')):
        raw = retained['logs/task-2-fix-1-'+name]
        text = raw.decode()
        check('Ran '+str(count)+' test' in text and summary in text and 'ERROR:' not in text, 'retained genuine '+name+' count/result not setup error')
        failures = len(re.findall(r'^FAIL: ',text,re.M))
        check(failures == (int(re.search(r'failures=(\d+)',summary)[1]) if summary.startswith('FAILED') else 0), 'actual '+name+' failure blocks match summary')
        log_summaries[name] = {'test_methods':count,'result':summary,'fingerprint':fp(raw)}
    test_roots = []
    for test_root in manifest['preserved_test_roots']:
        prefix='runs/'+Path(test_root).name+'/'
        names={n.split('/')[2] for n in retained if n.startswith(prefix+'test_')}
        if names==set(test_names):
            test_roots.append((test_root,prefix))
    check(len(test_roots)==1, 'one retained final run has all28 exact test method directories')
    final_test_root,prefix=test_roots[0]
    setup=json.loads(retained[prefix+'setup-calls.json'])
    check(len(setup)==3, 'final28 test run retained three actual setup calls')
    negative_members=[n for n in retained if n.startswith(prefix) and n.endswith('/negative-cli-receipt.json')]
    check(len(negative_members)==4, 'final28 test run retained four actual negative CLI calls')
    for member in negative_members:
        receipt=json.loads(retained[member])
        check(receipt['argv'][1:3]==['extract','verify'] and receipt['exit']==3, member+' actual negative CLI exit3')
        check(json.loads(receipt['stdout'])['status']=='failed', member+' genuine failure stdout')
    outside=prefix+'test_fix1_actual_invalid_evidence_range_is_preserved/negative-output/'
    failure=json.loads(retained[outside+'verification.json'])
    raw_candidate=json.loads(retained[outside+'candidates-original.json'])
    unit=failure['scope']['units'][0]
    diagnostic=next(x for x in failure['checks'] if x['category']=='evidence_identity')
    check(diagnostic['end_byte']==raw_candidate['payload']['evidence'][0]['excerpt_end_byte']==unit['end_byte']+1 and diagnostic['status']=='failed' and diagnostic['code']=='VERIFY_EVIDENCE', 'actual retained outside-unit failure preserves exact raw range and code')
    for name in ('strict-boolean','diagnostic-identity'):
        old_probe=load(SDK/('task-2-review-probe-'+name+'.json'))
        check(old_probe['corruption_rejected'] is False, 'old actual '+name+' acceptance reproduction retained')
        for path,expected in old_probe['fingerprints'].items():
            check(fp(read(Path(path)))==expected, 'original actual probe '+name+' fingerprint preserved '+Path(path).name)
    probe_record = load(SDK/'task-2-fix-1-probe-check.json')
    previous = load(SDK/'task-2-review-evidence.json')
    for probe in probe_record['results']:
        check(probe['rejected'] is True, 'retained original '+probe['mode']+' rejected by Fix1')
        for name, expected in probe['fingerprints'].items():
            path=SDK/('task-2-review-probe-'+probe['mode'])/name
            check(fp(read(path))==expected, 'original coherent '+probe['mode']+' bytes remain '+name)
    for path, expected in previous['fingerprints'].items():
        if '/task-2-review-probe-' in path.replace('\\','/'):
            check(fp(read(Path(path)))==expected, 'original reviewer before-Fix1 probe preserved '+path)
    for path,expected in list(fingerprints.items()):
        check(fp(Path(path).read_bytes())==expected,'audit-read file unchanged '+path)
    source_tree=ast.parse(retained['source/scripts/verify_extraction_knowledge.py'])
    locations={n.name:n.lineno for n in source_tree.body if isinstance(n,ast.FunctionDef)}
    return {'fix_files':files,'archive_entries':2960,'scenarios':52,'calls':60,'reports':34,'knowledge_passed':5,'status_counts':dict(statuses),'diagnostic_records_audited':diagnostics,'nullable_syntax_rows':nullable,'source_before_after_pairs':source_pairs,'log_summaries':log_summaries,'final28_test_root':final_test_root,'final28_actual_setup_calls':3,'final28_actual_negative_calls':4,'source_function_lines':locations,'new_test_methods':[n for n in test_names if n.startswith('test_fix1_')]}

result={'scope':'Task2 Fix1 exact7ce4b09..b2c0cba; saved bytes/receipts audit only','fix_base':'7ce4b09493e6a4d93bbcf41a2f5ecf3f1e6df4c2','fix_head':'b2c0cba117993a5d755b7e69692d37a561291aba','command':'selected Python -X utf8 -B .superpowers/sdd/B04-T03_REVIEW_PLAN/task-2-rereview-1-audit.py','rerun_suites':0,'rerun_cli_matrix':0,'focused_new_probes':0,'git_commands':0,'network_model_calls':0}
try:
    result['summary']=main()
except Exception as exc:
    result['audit_error']=repr(exc)
    raise
finally:
    result['assertion_count']=len(checks)
    result['passed_assertions']=sum(x['passed'] for x in checks)
    result['checks']=checks
    result['fingerprints']=fingerprints
    (SDK/'task-2-rereview-1-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','fingerprints')},ensure_ascii=False))
