"""Read-only full-frame capture for the selected installed Noetome window."""
from __future__ import annotations
import ctypes
from ctypes import wintypes as w
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageGrab

SDK = Path(__file__).resolve().parent
state = json.loads((SDK / "task-3-native-after-install.json").read_bytes())["windows"][0]
user = ctypes.WinDLL("user32", use_last_error=True)
gdi = ctypes.WinDLL("gdi32", use_last_error=True)
user.GetWindowRect.argtypes = [w.HWND, ctypes.POINTER(w.RECT)]
user.GetForegroundWindow.restype = w.HWND
user.SetThreadDpiAwarenessContext.argtypes = [ctypes.c_void_p]
user.SetThreadDpiAwarenessContext.restype = ctypes.c_void_p
user.GetDC.argtypes = [w.HWND]
user.GetDC.restype = w.HDC
gdi.CreateCompatibleDC.argtypes = [w.HDC]
gdi.CreateCompatibleDC.restype = w.HDC
gdi.CreateCompatibleBitmap.argtypes = [w.HDC, ctypes.c_int, ctypes.c_int]
gdi.CreateCompatibleBitmap.restype = w.HBITMAP
gdi.SelectObject.argtypes = [w.HDC, w.HGDIOBJ]
gdi.SelectObject.restype = w.HGDIOBJ
user.PrintWindow.argtypes = [w.HWND, w.HDC, w.UINT]
gdi.GetBitmapBits.argtypes = [w.HBITMAP, w.LONG, ctypes.c_void_p]
gdi.GetBitmapBits.restype = w.LONG
gdi.DeleteObject.argtypes = [w.HGDIOBJ]
gdi.DeleteDC.argtypes = [w.HDC]
user.ReleaseDC.argtypes = [w.HWND, w.HDC]
user.SetThreadDpiAwarenessContext(ctypes.c_void_p(-4))
rectangle = w.RECT()
assert user.GetWindowRect(state["hwnd"], ctypes.byref(rectangle))
bounds = [rectangle.left, rectangle.top, rectangle.right, rectangle.bottom]
width, height = rectangle.right - rectangle.left, rectangle.bottom - rectangle.top
assert width > 100 and height > 100 and state["visible"] and not state["minimized"]
dc = user.GetDC(state["hwnd"])
memory = gdi.CreateCompatibleDC(dc)
bitmap = gdi.CreateCompatibleBitmap(dc, width, height)
original = gdi.SelectObject(memory, bitmap)
try:
    printed = bool(user.PrintWindow(state["hwnd"], memory, 2))
    pixels = ctypes.create_string_buffer(width * height * 4)
    copied = gdi.GetBitmapBits(bitmap, len(pixels), pixels)
    assert copied == len(pixels)
    capture = Image.frombuffer("RGB", (width, height), pixels.raw, "raw", "BGRX", 0, 1)
    capture.save(SDK / "task-3-native-full-printwindow.png")
finally:
    gdi.SelectObject(memory, original)
    gdi.DeleteObject(bitmap)
    gdi.DeleteDC(memory)
    user.ReleaseDC(state["hwnd"], dc)
foreground = int(user.GetForegroundWindow() or 0)
screen_path = SDK / "task-3-native-full-screen.png"
if foreground == state["hwnd"]:
    ImageGrab.grab(bbox=tuple(bounds), all_screens=True).save(screen_path)
result = {
    "selected": state, "physical_window_rect": bounds, "printwindow_returned": printed,
    "foreground_hwnd": foreground, "selected_is_foreground": foreground == state["hwnd"],
    "screen_crop_captured": screen_path.exists(), "app_inputs": 0,
    "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "captures": {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in [SDK / "task-3-native-full-printwindow.png", screen_path] if p.exists()},
}
with (SDK / "task-3-native-full-capture.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps(result, ensure_ascii=False))
