"""Launch the selected installed app for local WebView/native validation."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", required=True)
    parser.add_argument("--port", type=int)
    args = parser.parse_args()
    assert args.label and all(c.isalnum() or c in "-_" for c in args.label)
    record = SDK / f"task-3-{args.label}-launch.json"
    assert not record.exists()
    executable = Path(os.environ["LOCALAPPDATA"]) / "Programs/Noetome/noetome-desktop.exe"
    expected = json.loads((SDK / "task-3-install-receipt.json").read_bytes())
    binary = executable.read_bytes()
    signature = hashlib.sha256(binary).hexdigest()
    assert signature == expected["executable_sha256"] and expected["matches_current_build"]
    environment = os.environ.copy()
    environment.pop("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", None)
    environment.pop("WEBVIEW2_USER_DATA_FOLDER", None)
    folder = None
    if args.port:
        assert 1024 < args.port < 65536
        with socket.socket() as check:
            check.bind(("127.0.0.1", args.port))
        folder = REPO / "target/compiler-temp" / f"B04-T03-{args.label}-webview"
        folder.mkdir()
        environment["WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS"] = f"--remote-debugging-port={args.port} --remote-debugging-address=127.0.0.1"
        environment["WEBVIEW2_USER_DATA_FOLDER"] = str(folder)
    with (SDK / f"task-3-{args.label}-stdout.log").open("xb") as out, (SDK / f"task-3-{args.label}-stderr.log").open("xb") as err:
        process = subprocess.Popen([str(executable)], env=environment, stdout=out, stderr=err)
    result = {
        "schema_version": 1, "started_at": datetime.now(timezone.utc).isoformat(),
        "label": args.label, "pid": process.pid, "executable": str(executable),
        "executable_sha256": signature, "executable_bytes": len(binary),
        "debug_port": args.port, "debug_address": "127.0.0.1" if args.port else None,
        "isolated_webview_directory": str(folder) if folder else None,
        "normal_visible_app_window_requested": True,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    with record.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
