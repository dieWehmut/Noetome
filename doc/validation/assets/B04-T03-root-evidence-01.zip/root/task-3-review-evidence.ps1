$ErrorActionPreference = 'Stop'
$reviewRoot = 'D:/Noetome'
$reviewSdk = Join-Path $reviewRoot '.superpowers/sdd/B04-T03_REVIEW_PLAN'
$reviewSources = @('apps/desktop/src/AppMenuBar.tsx', 'apps/desktop/src/WindowControls.tsx', 'apps/desktop/src/styles.css', 'crates/noetome-desktop/capabilities/main.json', 'crates/noetome-desktop/tauri.conf.json')
function ReadReviewHash([string]$reviewPath) { (Get-FileHash -LiteralPath $reviewPath -Algorithm SHA256).Hash.ToLower() }
$reviewSourceHashes = @{}
foreach ($reviewSource in $reviewSources) { $reviewSourceHashes[$reviewSource] = ReadReviewHash (Join-Path $reviewRoot $reviewSource) }
$reviewPhases = foreach ($reviewPhase in @('red', 'green', 'state-red', 'final')) {
    $reviewPath = Join-Path $reviewRoot ('doc/validation/assets/B04-T03-ui-implementation-' + $reviewPhase + '-checks.json')
    $reviewData = Get-Content -LiteralPath $reviewPath -Raw | ConvertFrom-Json
    $reviewMatches = @($reviewData.sources.PSObject.Properties | ForEach-Object { [pscustomobject]@{path=$_.Name; declared_sha256=$_.Value; matches_current=($reviewSourceHashes[$_.Name] -eq $_.Value)} })
    [pscustomobject]@{phase=$reviewPhase; at=$reviewData.at; native_os_proof=$reviewData.native_os_proof; passed=@($reviewData.results | Where-Object status -eq passed).Count; failed=@($reviewData.results | Where-Object status -eq failed).Count; sha256=(ReadReviewHash $reviewPath); source_matches=$reviewMatches; retained_results=$reviewData.results}
}
$reviewAssets = @(Get-ChildItem -LiteralPath (Join-Path $reviewRoot 'doc/validation/assets') -Filter 'B04-T03-ui-implementation-*' -File | ForEach-Object { [pscustomobject]@{path=('doc/validation/assets/' + $_.Name); bytes=$_.Length; sha256=(ReadReviewHash $_.FullName)} })
$reviewDependencies = @('node_modules/@tauri-apps/api/package.json', 'node_modules/@tauri-apps/api/core.js', 'node_modules/@tauri-apps/api/window.js', 'node_modules/@tauri-apps/api/event.js', 'crates/noetome-desktop/gen/schemas/desktop-schema.json', 'crates/noetome-desktop/src/main.rs')
$reviewDependencyHashes = @($reviewDependencies | ForEach-Object { [pscustomobject]@{path=$_; sha256=(ReadReviewHash (Join-Path $reviewRoot $_))} })
$reviewDragPath = 'C:/Users/Lyinn/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tauri-2.12.5/src/window/scripts/drag.js'
$reviewFinalStdout = Get-Content -LiteralPath (Join-Path $reviewRoot 'doc/validation/assets/B04-T03-ui-implementation-final-output.txt') -Raw | ConvertFrom-Json
$reviewFinalFile = Get-Content -LiteralPath (Join-Path $reviewRoot 'doc/validation/assets/B04-T03-ui-implementation-final-checks.json') -Raw | ConvertFrom-Json
$reviewStdoutMatches = (($reviewFinalStdout | ConvertTo-Json -Depth 10 -Compress) -eq ($reviewFinalFile | ConvertTo-Json -Depth 10 -Compress))
if (@($reviewPhases | Where-Object phase -eq final).source_matches.matches_current -contains $false) { throw 'Final source fingerprint mismatch' }
if (-not $reviewStdoutMatches) { throw 'Final retained stdout differs from checks JSON' }
$reviewEvidence = [ordered]@{
    schema_version=1; kind='task-scoped-read-only-review'; generated_at_utc=[DateTime]::UtcNow.ToString('o'); task='B04-T03 Task 3 single-row header'; base='b2c0cba117993a5d755b7e69692d37a561291aba'; head='634d6382b687b706b7bd34396ee5f386c57ef67e'; diff_sha256=(ReadReviewHash (Join-Path $reviewSdk 'review-b2c0cba..634d638.diff'));
    spec_compliance='compliant_implementation_gate'; quality='Approved'; critical=0; important=0; minor=1; fresh_behavioral_tests=0; native_os_proof=$false; report='task-3-review.md'; report_sha256=(ReadReviewHash (Join-Path $reviewSdk 'task-3-review.md'));
    actual_review_checks=@('exact supplied diff read once; truncated retained verifier/log segment recovered from named assets', 'actual locked JS API2.12.4 and minimal permission schema inspected', 'current-window event listener target and unlisten lifecycle inspected', 'exact Tauri2.12.5 automatic drag handler inspected', 'existing CloseRequested and main window config-consumption integration inspected', 'retained RED/GREEN/state-RED/final JSON parsed and source hashes compared', 'final stdout JSON equals retained final checks JSON', 'all 19 named UI implementation assets hashed', 'final TypeScript/Vite logs inspected without rerun', 'final 640px and controlled-error PNGs visually inspected');
    final_stdout_matches_checks=$reviewStdoutMatches; current_sources=$reviewSourceHashes; retained_runs=@($reviewPhases); assets=$reviewAssets; inspected_dependency_hashes=$reviewDependencyHashes; tauri_drag=@{path=$reviewDragPath; sha256=(ReadReviewHash $reviewDragPath)};
    fresh_probe_reason='No unanswered specific code risk justified an additional behavioral probe.'; native_acceptance='pending_root_build_install_full_window_operations_tray_real_menu_IPC'; process_exit_codes='implementer_report_only_not_reconstructed'; forbidden_actions_performed=@(); writes=@('task-3-review.md', 'task-3-review-evidence.ps1', 'task-3-review-evidence.json')
}
$reviewOut = Join-Path $reviewSdk 'task-3-review-evidence.json'
[System.IO.File]::WriteAllText($reviewOut, ($reviewEvidence | ConvertTo-Json -Depth 15) + "`n", [System.Text.UTF8Encoding]::new($false))
[pscustomobject]@{result='passed_read_only_evidence_audit'; final_source_matches=5; final_retained_checks=10; final_stdout_matches=$reviewStdoutMatches; asset_count=$reviewAssets.Count; native_os_proof=$false; evidence_sha256=(ReadReviewHash $reviewOut)} | ConvertTo-Json
