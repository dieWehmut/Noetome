"""One focused saved-artifact probe per named review doubt; no CLI execution."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys

REPO=Path('D:/Noetome')
SDK=REPO/'.superpowers/sdd/B04-T03_REVIEW_PLAN'
ROOT=REPO/'target/compiler-temp/B04-T03-task-2-matrix-07'
spec=importlib.util.spec_from_file_location('task2_review_verifier',REPO/'scripts/verify_extraction_knowledge.py')
v=importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
mode=sys.argv[1]
name='normal-exception' if mode=='strict-boolean' else 'condition-missing'
dest=SDK/('task-2-review-probe-'+mode)
shutil.copytree(ROOT/('out-'+name),dest)
inputs={p.name:p.read_bytes() for p in (ROOT/('case-'+name)).iterdir() if p.is_file()}
review=json.loads(inputs['review.json'])
candidate=json.loads(inputs['candidates.json'])
source=v.actual_source(ROOT/'project 中文',candidate['binding']['import_id'],review['selection'][0])
baseline=v.verify_report(dest,inputs['candidates.json'],inputs['gold.json'],source,inputs)
report=json.loads((dest/'verification.json').read_bytes())
assert baseline['status']==('passed' if mode=='strict-boolean' else 'failed')
if mode=='strict-boolean':
    # This required boolean is invalid JSON type, not merely a semantic variant.
    candidate['payload']['concepts'][0]['needs_full_explanation']='not-a-boolean'
    inputs['candidates.json']=v.encoded(candidate)
    (dest/'candidates-original.json').write_bytes(inputs['candidates.json'])
    report['origin']['input_fingerprints']['candidates.json']=v.fingerprint(inputs['candidates.json'])
    report['artifacts']['candidates-original.json']=v.fingerprint(inputs['candidates.json'])
    for c in report['checks']:
        if c['category']=='concept':
            c['actual']['linked'][0]['needs_full_explanation']='not-a-boolean'
    ir=json.loads((dest/'knowledge-ir.json').read_bytes())
    ir['concepts']=copy.deepcopy(candidate['payload']['concepts'])
    ir['checks']=copy.deepcopy(report['checks'])
    v.save(dest/'knowledge-ir.json',ir)
    report['artifacts']['knowledge-ir.json']=v.fingerprint((dest/'knowledge-ir.json').read_bytes())
    assert type(candidate['payload']['concepts'][0]['needs_full_explanation']) is str
    mutation='Required concept boolean changed to string in raw candidate, copied input, diagnostics and IR; byte fingerprints consistently updated.'
elif mode=='diagnostic-identity':
    changed=0
    for c in report['checks']:
        if c['category']=='condition':
            c['object_id']='NONEXISTENT-ATOM'
            c['code']=None
            changed+=1
    for r in report['expected_results']+report['candidate_results']:
        r['issue_codes']=[]
    assert changed==2 and all(a['atom']['atom_id']!='NONEXISTENT-ATOM' for a in candidate['payload']['atoms'])
    mutation='Both failed condition diagnostics point to nonexistent atom; their codes removed and both expected/candidate issue_codes emptied; source and raw candidate unchanged.'
else:
    raise ValueError(mode)
v.save(dest/'verification.json',report)
(dest/'verification.md').write_text('```json\n'+json.dumps(report,ensure_ascii=False)+'\n```\n',encoding='utf-8')
result=dict(mode=mode,mutation=mutation,baseline=baseline,command='selected Python -X utf8 -B .superpowers/sdd/B04-T03_REVIEW_PLAN/task-2-review-probe.py '+mode,production_cli_calls=0,explicit_probe_assertions=2)
try:
    result['observed']=v.verify_report(dest,inputs['candidates.json'],inputs['gold.json'],source,inputs)
    result['corruption_rejected']=False
except Exception as exc:
    result['observed_error']=repr(exc)
    result['corruption_rejected']=True
result['fingerprints']={str(p):v.fingerprint(p.read_bytes()) for p in dest.iterdir() if p.is_file()}
v.save(SDK/('task-2-review-probe-'+mode+'.json'),result)
print(json.dumps({k:x for k,x in result.items() if k!='fingerprints'},ensure_ascii=False))
