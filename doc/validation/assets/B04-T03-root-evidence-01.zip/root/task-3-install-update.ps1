$ErrorActionPreference = 'Stop'
$taskRepoRoot = 'D:\Noetome'
$taskSdk = Join-Path $taskRepoRoot '.superpowers\sdd\B04-T03_REVIEW_PLAN'
$taskInstalledExe = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\Noetome\noetome-desktop.exe'))
$taskBeforeHash = (Get-FileHash -LiteralPath $taskInstalledExe -Algorithm SHA256).Hash.ToLowerInvariant()
$taskStopped = @()
foreach ($taskRunning in @(Get-Process -Name 'noetome-desktop' -ErrorAction SilentlyContinue)) {
    if (-not $taskRunning.Path) { continue }
    $taskRunningPath = [IO.Path]::GetFullPath($taskRunning.Path)
    if (-not [string]::Equals($taskRunningPath, $taskInstalledExe, [StringComparison]::OrdinalIgnoreCase)) { continue }
    $taskStopped += [pscustomobject]@{ pid = $taskRunning.Id; path = $taskRunningPath; old_executable_sha256 = $taskBeforeHash }
    Stop-Process -Id $taskRunning.Id -Force
    Wait-Process -Id $taskRunning.Id -Timeout 15 -ErrorAction SilentlyContinue
}
$taskStopEvidence = Join-Path $taskSdk 'task-3-update-old-processes.json'
if (Test-Path -LiteralPath $taskStopEvidence) { throw 'Old process evidence already exists; do not overwrite an earlier run.' }
@{ selected_executable = $taskInstalledExe; old_executable_sha256 = $taskBeforeHash; stopped = $taskStopped; reason = 'User requested installed single-row window correction'; other_processes_stopped = 0 } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $taskStopEvidence -Encoding utf8
$taskPriorInstall = Join-Path $taskRepoRoot '.artifacts\desktop-install.json'
$taskPriorCopy = Join-Path $taskSdk 'task-3-prior-install-receipt.json'
if (Test-Path -LiteralPath $taskPriorInstall) {
    if (Test-Path -LiteralPath $taskPriorCopy) { throw 'Prior install receipt already preserved.' }
    [IO.File]::WriteAllBytes($taskPriorCopy, [IO.File]::ReadAllBytes($taskPriorInstall))
}
& (Join-Path $taskRepoRoot 'scripts\install_desktop.ps1') -InstallerPath (Join-Path $taskRepoRoot 'target\release\bundle\nsis\Noetome_0.1.0_x64-setup.exe') -OutputDir (Join-Path $env:LOCALAPPDATA 'NoetomeBuilds\windows\B04-T03-ui-single-row')
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$taskNewCopy = Join-Path $taskSdk 'task-3-install-receipt.json'
if (Test-Path -LiteralPath $taskNewCopy) { throw 'New install receipt already exists.' }
[IO.File]::WriteAllBytes($taskNewCopy, [IO.File]::ReadAllBytes((Join-Path $taskRepoRoot '.artifacts\desktop-install.json')))
