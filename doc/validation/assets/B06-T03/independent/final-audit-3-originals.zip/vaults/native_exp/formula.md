# 选定公式保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "6f628a1d-e510-4f58-9e2b-66de05deb7a2",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "native_exp",
    "title": "公式保真样例 native_exp",
    "source_kind": "tex",
    "tex": {
      "file": "original.tex",
      "sha256": "8dcd01f607af975e2b0fbb6c98e345c8ecdfd3306cb1e9b6293c9911d55d6c99"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "5b29469f27149119c9e67cb8b892fe5a6cc4722e8b91fe7972be3a2d0f58347b"
    },
    "region": {
      "file": "region.png",
      "sha256": "a30de55f74c6dccda0e3dabcc064236002d11a772429cf77e69d0da0c67a6a47",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": "C_i(t) = C_0 \\exp(-k t)",
    "symbols": [
      {
        "symbol": "C",
        "definition": "test concentration",
        "unit": "mmol/L"
      },
      {
        "symbol": "i",
        "definition": "selected integer sample index",
        "unit": null
      },
      {
        "symbol": "t",
        "definition": "elapsed time",
        "unit": "s"
      },
      {
        "symbol": "k",
        "definition": "positive decay coefficient",
        "unit": "1/s"
      }
    ],
    "conditions": [
      "k > 0"
    ],
    "ranges": [
      "i = 1,2,3",
      "0 <= t <= 10 s"
    ],
    "exceptions": [
      "Do not apply outside the selected time interval."
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "passed",
    "symbol_definitions": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "native_math",
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": []
  },
  "tokens": [
    "C",
    "_",
    "i",
    "(",
    "t",
    ")",
    "=",
    "C",
    "_",
    "0",
    "\\exp",
    "(",
    "-",
    "k",
    "t",
    ")"
  ],
  "plan_fingerprint": {
    "sha256": "c941ddc1c25507314975d5fbf1df03c5188aa993ba90bab7dce8ff91f4d90c39",
    "byte_length": 2058
  },
  "inputs": {
    "original.png": {
      "sha256": "a30de55f74c6dccda0e3dabcc064236002d11a772429cf77e69d0da0c67a6a47",
      "byte_length": 7885
    },
    "original.tex": {
      "sha256": "8dcd01f607af975e2b0fbb6c98e345c8ecdfd3306cb1e9b6293c9911d55d6c99",
      "byte_length": 24
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "a906e7cef9ea5f2937fd29651f174ea86c786f20013deeaa4c61525f62d882a8",
      "byte_length": 723
    },
    "source-semantics.json": {
      "sha256": "5b29469f27149119c9e67cb8b892fe5a6cc4722e8b91fe7972be3a2d0f58347b",
      "byte_length": 656
    }
  },
  "files": [
    {
      "relative_path": "公式预览.md",
      "content_sha256": "dd9f0d191c83538335fef8ffa5d04daf4dcc49a0b84c5090934f7fd9a6ec264c",
      "byte_length": 857,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 64
        },
        {
          "kind": "expression",
          "source_field": "tex",
          "start_byte": 84,
          "end_byte": 107
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[0].symbol",
          "start_byte": 162,
          "end_byte": 163
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[0].definition",
          "start_byte": 188,
          "end_byte": 206
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[0].unit",
          "start_byte": 231,
          "end_byte": 237
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[1].symbol",
          "start_byte": 276,
          "end_byte": 277
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[1].definition",
          "start_byte": 302,
          "end_byte": 331
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[1].unit",
          "start_byte": 356,
          "end_byte": 377
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[2].symbol",
          "start_byte": 416,
          "end_byte": 417
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[2].definition",
          "start_byte": 442,
          "end_byte": 454
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[2].unit",
          "start_byte": 479,
          "end_byte": 480
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[3].symbol",
          "start_byte": 519,
          "end_byte": 520
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[3].definition",
          "start_byte": 545,
          "end_byte": 571
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[3].unit",
          "start_byte": 596,
          "end_byte": 599
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[0]",
          "start_byte": 630,
          "end_byte": 635
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[0]",
          "start_byte": 660,
          "end_byte": 669
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[1]",
          "start_byte": 683,
          "end_byte": 697
        },
        {
          "kind": "exception",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 722,
          "end_byte": 770
        },
        {
          "kind": "attachment_link",
          "source_field": "tex",
          "start_byte": 793,
          "end_byte": 819
        },
        {
          "kind": "attachment_link",
          "source_field": "region",
          "start_byte": 821,
          "end_byte": 855
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "e6cfded4e74e4731738a05b3cfd8f9cfa1842c5071aacb8a0fae3afa4dc1ef6f",
      "byte_length": 152
    },
    "compiled.tex": {
      "sha256": "3646f491e8689f08f0040829f742483e574fe45b1bd2629a9d1df8960c6cc112",
      "byte_length": 23
    },
    "original.png": {
      "sha256": "a30de55f74c6dccda0e3dabcc064236002d11a772429cf77e69d0da0c67a6a47",
      "byte_length": 7885
    },
    "original.tex": {
      "sha256": "8dcd01f607af975e2b0fbb6c98e345c8ecdfd3306cb1e9b6293c9911d55d6c99",
      "byte_length": 24
    },
    "plan.json": {
      "sha256": "c941ddc1c25507314975d5fbf1df03c5188aa993ba90bab7dce8ff91f4d90c39",
      "byte_length": 2058
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "a906e7cef9ea5f2937fd29651f174ea86c786f20013deeaa4c61525f62d882a8",
      "byte_length": 723
    },
    "source-semantics.json": {
      "sha256": "5b29469f27149119c9e67cb8b892fe5a6cc4722e8b91fe7972be3a2d0f58347b",
      "byte_length": 656
    },
    "公式预览.md": {
      "sha256": "dd9f0d191c83538335fef8ffa5d04daf4dcc49a0b84c5090934f7fd9a6ec264c",
      "byte_length": 857
    }
  }
}
```
