# 选定公式保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "210d8756-f87c-4b21-92f1-76198112728c",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "compatibility",
    "title": "公式保真样例 compatibility",
    "source_kind": "tex",
    "tex": {
      "file": "original.tex",
      "sha256": "9a6901f2473b4009b50a8ca6bad09d8f5c4e401dfe9352f8c9245784a76fec74"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "6d7db5420b925bd8a0e5ed7940aa5bad33b6680ccd0a64105cb5c6c2e27b3f6c"
    },
    "region": {
      "file": "region.png",
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": "C_i(t) = -\\dfrac{a}{b} t^{2}",
    "symbols": [
      {
        "symbol": "C",
        "definition": "test concentration",
        "unit": "mmol/L"
      },
      {
        "symbol": "i",
        "definition": "selected integer sample index",
        "unit": null
      },
      {
        "symbol": "t",
        "definition": "elapsed time",
        "unit": "s"
      },
      {
        "symbol": "a",
        "definition": "positive scaling constant",
        "unit": "mmol/L"
      },
      {
        "symbol": "b",
        "definition": "positive nonzero divisor",
        "unit": "s^2"
      }
    ],
    "conditions": [
      "a > 0 and b > 0",
      "This is a fictional engineering example, not a scientific claim."
    ],
    "ranges": [
      "i = 1,2,3",
      "0 <= t <= 10 s"
    ],
    "exceptions": [
      "Do not apply outside the selected time interval."
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": false,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "passed",
    "symbol_definitions": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "formula_image",
    "fallback_reasons": [
      "FORMULA_DFRAC_UNAVAILABLE"
    ],
    "compatibility_rewrites": [],
    "issue_codes": []
  },
  "tokens": [
    "C",
    "_",
    "i",
    "(",
    "t",
    ")",
    "=",
    "-",
    "\\frac",
    "{",
    "a",
    "}",
    "{",
    "b",
    "}",
    "t",
    "^",
    "{",
    "2",
    "}"
  ],
  "plan_fingerprint": {
    "sha256": "f7dd88b5cad098ce89f209a57de3861768e3af26f325b8486e63f9fe49d73c54",
    "byte_length": 2323
  },
  "inputs": {
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "9a6901f2473b4009b50a8ca6bad09d8f5c4e401dfe9352f8c9245784a76fec74",
      "byte_length": 29
    },
    "profile.json": {
      "sha256": "24fbb84d69c5ce9ef86dc9ae7af916a77d8c56dafeaa88f4fa3df750011ad8f7",
      "byte_length": 202
    },
    "source-case.json": {
      "sha256": "4ce8f5d0c33d023c8c8a2150ffe7e96bf1eed481fb6be1ccfd4d19a17e9fb04c",
      "byte_length": 729
    },
    "source-semantics.json": {
      "sha256": "6d7db5420b925bd8a0e5ed7940aa5bad33b6680ccd0a64105cb5c6c2e27b3f6c",
      "byte_length": 847
    }
  },
  "files": [
    {
      "relative_path": "公式预览.md",
      "content_sha256": "15d39263f3a98b62c8e7b05d8058b6e1cf0c78eff35b6216f4e9c02bdd090cc6",
      "byte_length": 1055,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "image_embed",
          "source_field": "region",
          "start_byte": 84,
          "end_byte": 101
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[0].symbol",
          "start_byte": 153,
          "end_byte": 154
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[0].definition",
          "start_byte": 179,
          "end_byte": 197
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[0].unit",
          "start_byte": 222,
          "end_byte": 228
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[1].symbol",
          "start_byte": 267,
          "end_byte": 268
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[1].definition",
          "start_byte": 293,
          "end_byte": 322
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[1].unit",
          "start_byte": 347,
          "end_byte": 368
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[2].symbol",
          "start_byte": 407,
          "end_byte": 408
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[2].definition",
          "start_byte": 433,
          "end_byte": 445
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[2].unit",
          "start_byte": 470,
          "end_byte": 471
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[3].symbol",
          "start_byte": 510,
          "end_byte": 511
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[3].definition",
          "start_byte": 536,
          "end_byte": 561
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[3].unit",
          "start_byte": 586,
          "end_byte": 592
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[4].symbol",
          "start_byte": 631,
          "end_byte": 632
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[4].definition",
          "start_byte": 657,
          "end_byte": 681
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[4].unit",
          "start_byte": 706,
          "end_byte": 709
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[0]",
          "start_byte": 740,
          "end_byte": 755
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[1]",
          "start_byte": 769,
          "end_byte": 833
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[0]",
          "start_byte": 858,
          "end_byte": 867
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[1]",
          "start_byte": 881,
          "end_byte": 895
        },
        {
          "kind": "exception",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 920,
          "end_byte": 968
        },
        {
          "kind": "attachment_link",
          "source_field": "tex",
          "start_byte": 991,
          "end_byte": 1017
        },
        {
          "kind": "attachment_link",
          "source_field": "region",
          "start_byte": 1019,
          "end_byte": 1053
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "c1b75c7e76023fe5d48f1a7524920f2271eab87263616218dab5fc8ccce408cb",
      "byte_length": 152
    },
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "9a6901f2473b4009b50a8ca6bad09d8f5c4e401dfe9352f8c9245784a76fec74",
      "byte_length": 29
    },
    "plan.json": {
      "sha256": "f7dd88b5cad098ce89f209a57de3861768e3af26f325b8486e63f9fe49d73c54",
      "byte_length": 2323
    },
    "profile.json": {
      "sha256": "24fbb84d69c5ce9ef86dc9ae7af916a77d8c56dafeaa88f4fa3df750011ad8f7",
      "byte_length": 202
    },
    "source-case.json": {
      "sha256": "4ce8f5d0c33d023c8c8a2150ffe7e96bf1eed481fb6be1ccfd4d19a17e9fb04c",
      "byte_length": 729
    },
    "source-semantics.json": {
      "sha256": "6d7db5420b925bd8a0e5ed7940aa5bad33b6680ccd0a64105cb5c6c2e27b3f6c",
      "byte_length": 847
    },
    "公式预览.md": {
      "sha256": "15d39263f3a98b62c8e7b05d8058b6e1cf0c78eff35b6216f4e9c02bdd090cc6",
      "byte_length": 1055
    }
  }
}
```
