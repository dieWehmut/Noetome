# 选定公式保真预览报告

状态：needs_review；预览：not_run；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "8ec497df-710d-45f0-82c5-6f2ddb414aa8",
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "curve_no_data",
    "title": "公式保真样例 curve_no_data",
    "source_kind": "experimental_curve",
    "tex": null,
    "semantics": {
      "file": "semantics.json",
      "sha256": "2353321e126485127850f7ac363fb4c5c30411dc597b0aecf881e9431a811a2b"
    },
    "region": {
      "file": "region.png",
      "sha256": "129145d5d38c25663701921e9a8ac38587b1043780b9c6eebaa54ad48e0c9179",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": null,
    "symbols": [],
    "conditions": [
      "No original numerical data were provided."
    ],
    "ranges": [],
    "exceptions": []
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "needs_review",
    "symbol_definitions": "needs_review",
    "semantic_review": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "decision": {
    "representation": null,
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": [
      "FORMULA_CURVE_NO_DATA"
    ]
  },
  "tokens": null,
  "plan_fingerprint": null,
  "inputs": {
    "original.png": {
      "sha256": "129145d5d38c25663701921e9a8ac38587b1043780b9c6eebaa54ad48e0c9179",
      "byte_length": 5245
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "dacfc49d8b0d7145f22c0b07585d6f48405fc60209604e212575266745fee39f",
      "byte_length": 634
    },
    "source-semantics.json": {
      "sha256": "2353321e126485127850f7ac363fb4c5c30411dc597b0aecf881e9431a811a2b",
      "byte_length": 172
    }
  },
  "files": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "031201e3adcf0b0963811f18a47c64bad54a86e478938b0aaa57f774aaa1e70c",
      "byte_length": 152
    },
    "original.png": {
      "sha256": "129145d5d38c25663701921e9a8ac38587b1043780b9c6eebaa54ad48e0c9179",
      "byte_length": 5245
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "dacfc49d8b0d7145f22c0b07585d6f48405fc60209604e212575266745fee39f",
      "byte_length": 634
    },
    "source-semantics.json": {
      "sha256": "2353321e126485127850f7ac363fb4c5c30411dc597b0aecf881e9431a811a2b",
      "byte_length": 172
    }
  }
}
```
