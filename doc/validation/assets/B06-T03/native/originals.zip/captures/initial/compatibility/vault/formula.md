# 选定公式保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "1ac26282-4337-4f83-a2e9-268506e2bcd0",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "compatibility",
    "title": "公式保真样例 compatibility",
    "source_kind": "tex",
    "tex": {
      "file": "original.tex",
      "sha256": "9a6901f2473b4009b50a8ca6bad09d8f5c4e401dfe9352f8c9245784a76fec74"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "6d7db5420b925bd8a0e5ed7940aa5bad33b6680ccd0a64105cb5c6c2e27b3f6c"
    },
    "region": {
      "file": "region.png",
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": "C_i(t) = -\\dfrac{a}{b} t^{2}",
    "symbols": [
      {
        "symbol": "C",
        "definition": "test concentration",
        "unit": "mmol/L"
      },
      {
        "symbol": "i",
        "definition": "selected integer sample index",
        "unit": null
      },
      {
        "symbol": "t",
        "definition": "elapsed time",
        "unit": "s"
      },
      {
        "symbol": "a",
        "definition": "positive scaling constant",
        "unit": "mmol/L"
      },
      {
        "symbol": "b",
        "definition": "positive nonzero divisor",
        "unit": "s^2"
      }
    ],
    "conditions": [
      "a > 0 and b > 0",
      "This is a fictional engineering example, not a scientific claim."
    ],
    "ranges": [
      "i = 1,2,3",
      "0 <= t <= 10 s"
    ],
    "exceptions": [
      "Do not apply outside the selected time interval."
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "passed",
    "symbol_definitions": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "native_math",
    "fallback_reasons": [],
    "compatibility_rewrites": [
      "FORMULA_DFRAC_COMPATIBILITY"
    ],
    "issue_codes": []
  },
  "tokens": [
    "C",
    "_",
    "i",
    "(",
    "t",
    ")",
    "=",
    "-",
    "\\frac",
    "{",
    "a",
    "}",
    "{",
    "b",
    "}",
    "t",
    "^",
    "{",
    "2",
    "}"
  ],
  "plan_fingerprint": {
    "sha256": "cd3ea994a169673a47b4471e6504509289c906ad295c2f43f6ff1d1c9730b3e7",
    "byte_length": 2349
  },
  "inputs": {
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "9a6901f2473b4009b50a8ca6bad09d8f5c4e401dfe9352f8c9245784a76fec74",
      "byte_length": 29
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "4ce8f5d0c33d023c8c8a2150ffe7e96bf1eed481fb6be1ccfd4d19a17e9fb04c",
      "byte_length": 729
    },
    "source-semantics.json": {
      "sha256": "6d7db5420b925bd8a0e5ed7940aa5bad33b6680ccd0a64105cb5c6c2e27b3f6c",
      "byte_length": 847
    }
  },
  "files": [
    {
      "relative_path": "公式预览.md",
      "content_sha256": "deceafd87d08fb3a08177d567e11e7e9dab2fb578b0d348b81dd3b27f422cb73",
      "byte_length": 1071,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "expression",
          "source_field": "tex",
          "start_byte": 87,
          "end_byte": 114
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[0].symbol",
          "start_byte": 169,
          "end_byte": 170
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[0].definition",
          "start_byte": 195,
          "end_byte": 213
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[0].unit",
          "start_byte": 238,
          "end_byte": 244
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[1].symbol",
          "start_byte": 283,
          "end_byte": 284
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[1].definition",
          "start_byte": 309,
          "end_byte": 338
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[1].unit",
          "start_byte": 363,
          "end_byte": 384
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[2].symbol",
          "start_byte": 423,
          "end_byte": 424
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[2].definition",
          "start_byte": 449,
          "end_byte": 461
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[2].unit",
          "start_byte": 486,
          "end_byte": 487
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[3].symbol",
          "start_byte": 526,
          "end_byte": 527
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[3].definition",
          "start_byte": 552,
          "end_byte": 577
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[3].unit",
          "start_byte": 602,
          "end_byte": 608
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[4].symbol",
          "start_byte": 647,
          "end_byte": 648
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[4].definition",
          "start_byte": 673,
          "end_byte": 697
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[4].unit",
          "start_byte": 722,
          "end_byte": 725
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[0]",
          "start_byte": 756,
          "end_byte": 771
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[1]",
          "start_byte": 785,
          "end_byte": 849
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[0]",
          "start_byte": 874,
          "end_byte": 883
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[1]",
          "start_byte": 897,
          "end_byte": 911
        },
        {
          "kind": "exception",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 936,
          "end_byte": 984
        },
        {
          "kind": "attachment_link",
          "source_field": "tex",
          "start_byte": 1007,
          "end_byte": 1033
        },
        {
          "kind": "attachment_link",
          "source_field": "region",
          "start_byte": 1035,
          "end_byte": 1069
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "3274a131b148d3de452f1e1d7e0e948aec2e67fe0eb7d70aff5073b6c5c0123e",
      "byte_length": 152
    },
    "compiled.tex": {
      "sha256": "ba13467e89656ca236d818e075c4c09dd5dca26dd6398ea03a7ea67dbf618733",
      "byte_length": 27
    },
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "9a6901f2473b4009b50a8ca6bad09d8f5c4e401dfe9352f8c9245784a76fec74",
      "byte_length": 29
    },
    "plan.json": {
      "sha256": "cd3ea994a169673a47b4471e6504509289c906ad295c2f43f6ff1d1c9730b3e7",
      "byte_length": 2349
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "4ce8f5d0c33d023c8c8a2150ffe7e96bf1eed481fb6be1ccfd4d19a17e9fb04c",
      "byte_length": 729
    },
    "source-semantics.json": {
      "sha256": "6d7db5420b925bd8a0e5ed7940aa5bad33b6680ccd0a64105cb5c6c2e27b3f6c",
      "byte_length": 847
    },
    "公式预览.md": {
      "sha256": "deceafd87d08fb3a08177d567e11e7e9dab2fb578b0d348b81dd3b27f422cb73",
      "byte_length": 1071
    }
  }
}
```
