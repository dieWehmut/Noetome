"""Verify and archive actual05 failure; never repair its candidates."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
OUTPUT = LIVE / "api-live-05"
ASSETS = ROOT / "doc/validation/assets"
sys.path.insert(0, str(ROOT / "scripts"))
from validate_extraction_gateway import sql_snapshot

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_bytes(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        with path.open("xb") as handle:
            handle.write(raw)

before = read(LIVE / "source-before.json")
project = Path(before["project"]).resolve()
files = {str(p.relative_to(project)): {"sha256": sha(p.read_bytes()), "byte_length": p.stat().st_size, "mtime_ns": p.stat().st_mtime_ns} for p in project.rglob("*") if p.is_file()}
assert files == before["project_files"]
assert sha("\n".join(sql_snapshot(project)).encode()) == before["project_sql_sha256"]
assert sha((LIVE / "gold-before.json").read_bytes()) == before["gold_sha256"]
report = read(OUTPUT / "validation.json")
blocks = re.findall(r"```json\s*\n(.*?)\n```", (OUTPUT / "validation.md").read_text(encoding="utf-8"), re.S)
assert len(blocks) == 1 and json.loads(blocks[0]) == report
assert report["status"] == "failed" and [e["code"] for e in report["errors"]] == ["EXTRACT_KNOWLEDGE"]
assert report["validated_atoms"] == 0 and not (OUTPUT / "candidates.json").exists()
assert report["request_strategy"] == "tangmao-deepseek-chat-qualifiers-v5" and report["transport_mode"] == "live"
assert report["knowledge_status"] == "pending" and report["scientific_quality"] == "not_run" and report["published"] is False
wire = read(OUTPUT / "response.bin")
choice = wire["choices"][0]
assert len(wire["choices"]) == 1 and choice["finish_reason"] == "stop"
candidate = json.loads(choice["message"]["content"])
body = read(OUTPUT / "request-body.json")
user = json.loads(body["messages"][1]["content"])
assert candidate["binding"] == user["request"]["binding"] and candidate["request_id"] == user["request"]["request_id"]
bad_revisions = [{"collection": "concepts", "object_id": c["concept_id"], "revision": c["revision"]} for c in candidate["concepts"] if c["revision"] == 0]
bad_revisions += [{"collection": "atoms", "object_id": c["atom"]["atom_id"], "revision": c["atom"]["revision"]} for c in candidate["atoms"] if c["atom"]["revision"] == 0]
assert len(bad_revisions) == 4
anchors = {a["unit_id"]: a for a in user["request"]["evidence_anchors"]}
assert all(all(e[k] == anchors[e["unit_id"]][k] for k in ["excerpt_start_byte", "excerpt_end_byte", "excerpt_sha256", "quote"]) for e in candidate["evidence"])
for c in candidate["atoms"]:
    assert set(c) == {"atom", "measurement"}
    m = c["measurement"]
    assert m["unit"] in c["atom"]["qualifiers"]
    assert all(condition in c["atom"]["qualifiers"] for condition in m["conditions"])
usage = wire["usage"]
assert usage["prompt_tokens"] + usage["completion_tokens"] == usage["total_tokens"] == 3479
assert report["usage"]["network_attempts"] == 1 and report["usage"]["model_usage_status"] == "validated"
assert report["usage"]["raw_model_usage"] == usage
settled = read(LIVE / "live-budget-settlement-05.json")["ledger_after_settlement"]
assert [r["confirmed_total_tokens"] for r in settled["records"]] == [936, 9683, 4912, 4783, 3479]
assert (settled["accounted_tokens"], settled["remaining_tokens"], settled["pending_reserved_tokens"], settled["model_attempts"]) == (23793, 9976207, 0, 5)
assert read(Path(read(LIVE / "live-budget-settlement-05.json")["ledger_reference"])) == settled
for number, digest in [(1, "73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b"), (2, "f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a"), (3, "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b"), (4, "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9")]:
    assert sha((LIVE / f"api-live-{number:02d}/response.bin").read_bytes()) == digest
after = read(LIVE / "live-after-05.json")
assert after["source_config_gold_binary_unchanged"]
diagnosis = {"verified_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "result": "actual_strict_candidate_failure",
             "request_strategy": report["request_strategy"], "error_codes": ["EXTRACT_KNOWLEDGE"], "invalid_revisions": bad_revisions,
             "domain_rule": "DATA_CONTRACTS revision is a positive integer; shared validate_basics rejects revision=0",
             "wire_schema_revision_constraint": user["response_schema"]["properties"]["concepts"]["items"]["properties"]["revision"],
             "quote_and_anchor_match": True, "measurement_qualifiers_match": True, "response_and_gold_unmodified": True,
             "source_original_capture_unchanged": True, "raw_response_sha256": sha((OUTPUT / "response.bin").read_bytes()),
             "raw_response_byte_length": (OUTPUT / "response.bin").stat().st_size,
             "reasoning_content_utf8_bytes": len((choice["message"].get("reasoning_content") or "").encode()),
             "thinking_switch_enforcement": "unverified", "usage": usage,
             "cumulative_accounted_tokens": 23793, "remaining_tokens": 9976207, "pending_reserved_tokens": 0,
             "scientific_quality": "not_run", "next_scope": "selected Chat positive revision schema/prompt; keep DTO/Core and previous routes"}
save_bytes(LIVE / "live-diagnosis-05.json", (json.dumps(diagnosis, ensure_ascii=False, indent=2) + "\n").encode())
records = []
for source, name in {
    "api-live-05/request.json": "request.json", "api-live-05/request-body.json": "request-body.json", "api-live-05/response.bin": "response.bin",
    "api-live-05/validation.json": "validation.json", "api-live-05/validation.md": "validation.md", "live-command-05.json": "command.json",
    "live-budget-reservation-05.json": "reservation.json", "live-budget-settlement-05.json": "settlement.json", "live-after-05.json": "after.json",
    "live-diagnosis-05.json": "diagnosis.json",
}.items():
    raw = (LIVE / source).read_bytes()
    target = ASSETS / ("B04-T02-live-fifth-" + name)
    save_bytes(target, raw)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw)})
for name in ["qualifier-review.md", "qualifier-review-evidence.json"]:
    raw = (PLAN / name).read_bytes()
    save_bytes(ASSETS / ("B04-T02-" + name), raw)
raw = Path(__file__).read_bytes()
source_record = {"source": Path(__file__).relative_to(ROOT).as_posix(), "source_sha256": sha(raw), "byte_length": len(raw), "source_text": raw.decode("utf-8")}
save_bytes(ASSETS / "B04-T02-live-fifth-diagnosis-source.json", (json.dumps(source_record, ensure_ascii=False, indent=2) + "\n").encode())
manifest = {"records": records, "actual_model_calls_in_archive_step": 0, "strict_failure_preserved": True, "cumulative_accounted_tokens": 23793}
save_bytes(ASSETS / "B04-T02-live-fifth-failure-archive.json", (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"verified_failure": True, "invalid_revision_objects": 4, "archived_records": len(records), "raw_response_sha256": diagnosis["raw_response_sha256"], "cumulative_accounted_tokens": 23793, "remaining_tokens": 9976207}, ensure_ascii=False))
