## Task 2: 已选网关的 Responses 请求策略

**文件责任**：现有 extraction_api_config/schema/Core 和相关 scoped native tests。保持 reqwest/TLS、来源/配置/新根保护、严格 wire 与候选领域校验。controller 编写独立外部行为审计和文档。

**端点**：保留已有官方 Responses 离线候选，增加用户明确选定的 `https://ai.1343263.xyz/v1/responses`；后者只认已选 `deepseek-flash`，不宽泛允许其他服务、模型、端口、userinfo、查询、fragment 或路径。local_http_test 的数字环回及 public synthetic 凭据/模型规则保持。

**请求**：按 DeepSeek 当前 Responses 文档及兼容表，沿用 input/instructions/text.format 的 json_schema/name/schema、max_output_tokens、stream=false、tools=[]、tool_choice=none；所选策略 reasoning.effort=none。仅发送官方已核查支持或明确忽略但安全的字段，不能将不受支持的 strict 标记当作服务器保证；Core 继续拒绝非法 schema/重复 key/未知候选/错误来源。旧官方策略保持其 strict JSON Schema 字段。

**审计**：request.json 与 validation JSON/Markdown都记录明确 request_strategy 版本；配置模型与实际返回模型继续分开。格式策略不改变计量定义、输入预留、null/unknown、一次POST、无重试、凭据回显或来源保护语义。先保存所选端点/模型与策略的真实 RED，再最小实现，所有 scoped native tests、普通CLI与独立旧API/fake回归实跑。

**精确裁定**：所选策略 `request_strategy=tangmao-deepseek-responses-json-schema-v1`；旧官方/本地假服务策略 `openai-responses-strict-json-schema-v1`。两个保存快照都包含策略，validation也包含endpoint。所选body保留store=false表达客户端意图，移除background/service_tier/truncation和text.format.strict，添加reasoning.effort=none；不改变name/schema/input/证据anchor。controller 已保存普通CLI 1通过/1失败的真实RED于该计划工作区gateway-cli-red.json，作者普通CLI测试文件由controller负责，不由worker编辑。

