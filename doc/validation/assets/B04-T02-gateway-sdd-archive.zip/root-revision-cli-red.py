"""Controller ordinary CLI RED before selected Chat positive revision fix."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "root-revision-cli-red.json"
assert not OUT.exists()
argv = [sys.argv[1], "-NoLogo", "-NoProfile", "-NonInteractive", "-Command",
        "& .\\scripts\\cargo_local.ps1 test --test extraction_api ordinary_chat_ --locked --offline '--' --test-threads=4; exit $LASTEXITCODE"]
env = dict(os.environ)
env["CARGO_TERM_COLOR"] = "never"
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
stdout, stderr = run.stdout.decode("utf-8"), run.stderr.decode("utf-8")
rows = re.findall(r"test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored", stdout + stderr)
record = {"command": argv, "started_at": started, "elapsed_seconds": time.monotonic() - clock,
          "exit_code": run.returncode, "stdout": stdout, "stderr": stderr,
          "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
          "result_rows": rows, "model_calls": 0, "paid_calls": 0,
          "production_base": "fd53462c5217060c40a30a38f40b3bcc2e2b8fc0"}
with OUT.open("x", encoding="utf-8", newline="\n") as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
assert run.returncode == 101 and rows == [("0", "2", "0")], record
assert "Every concept.revision and atom.revision must be a positive integer" in stdout + stderr
print(json.dumps({"exit_code": run.returncode, "passed": 0, "failed": 2,
                  "reason": "missing positive revision request contract", "evidence": str(OUT)}))
