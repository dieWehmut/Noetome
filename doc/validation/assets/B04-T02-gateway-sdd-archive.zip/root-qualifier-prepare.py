"""Preserve actual04 and prepare the author RED for its observed qualifier gap."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
OUTPUT = LIVE / "api-live-04"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save_new(path, raw):
    assert not path.exists(), path
    with path.open("xb") as handle:
        handle.write(raw)

report = json.loads((OUTPUT / "validation.json").read_bytes())
wire_raw = (OUTPUT / "response.bin").read_bytes()
wire = json.loads(wire_raw)
candidate = json.loads(wire["choices"][0]["message"]["content"])
assert sha(wire_raw) == "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9"
assert report["status"] == "failed" and report["errors"][0]["code"] == "EXTRACT_QUALIFIERS"
assert len(candidate["atoms"]) == 1 and set(candidate["atoms"][0]) == {"atom", "measurement"}
item = candidate["atoms"][0]
assert item["measurement"]["unit"] not in item["atom"]["qualifiers"]
assert all(condition in item["atom"]["qualifiers"] for condition in item["measurement"]["conditions"])
assert wire["usage"] == {"prompt_tokens": 1712, "completion_tokens": 3071, "total_tokens": 4783}
copies = [(LIVE / "live-command-04.json", "command.json"),
          (LIVE / "live-budget-reservation-04.json", "reservation.json"),
          (LIVE / "live-budget-settlement-04.json", "settlement.json"),
          (LIVE / "live-after-04.json", "after.json")]
copies += [(OUTPUT / name, name) for name in ["request.json", "request-body.json", "response.bin", "validation.json", "validation.md"]]
for path, name in copies:
    save_new(ASSETS / ("B04-T02-live-fourth-" + name), path.read_bytes())
diagnosis = {"response_sha256": sha(wire_raw), "response_byte_length": len(wire_raw), "error_code": "EXTRACT_QUALIFIERS",
             "atom_id": item["atom"]["atom_id"], "atom_qualifiers": item["atom"]["qualifiers"],
             "measurement": item["measurement"], "measurement_unit_in_qualifiers": False,
             "measurement_conditions_in_qualifiers": True, "nested_atom_shape_present": True,
             "native_rule": "crates/noetome-cli/src/extraction.rs:338-350", "usage": wire["usage"],
             "cumulative_accounted_tokens": 20314, "remaining_tokens": 9979686, "pending_reserved_tokens": 0,
             "response_repaired": False, "knowledge_assessed": False,
             "reasoning_content_utf8_bytes": len((wire["choices"][0]["message"].get("reasoning_content") or "").encode())}
save_new(ASSETS / "B04-T02-live-fourth-diagnosis.json", (json.dumps(diagnosis, ensure_ascii=False, indent=2) + "\n").encode())
source = (PLAN / "root-shape-cli-red.py").read_text(encoding="utf-8-sig")
source = source.replace("root-shape-cli-red.json", "root-qualifier-cli-red.json")
source = source.replace("94b0ebb40bb43cb5cdb72d924a40cf2d0893fa10", "25bcff5b474611fdb2b1c1f96eb0a33caae42e4d")
source = source.replace("two top-level keys: atom and measurement", "Include measurement.unit verbatim in atom.qualifiers")
source = source.replace("missing explicit nested atom task instruction", "missing explicit cross-field unit qualifier instruction")
source = source.replace("missing explicit nested atom", "missing explicit cross-field qualifier")
source = source.replace("missing explicit nested atom task instruction", "missing cross-field qualifier task instruction")
source = source.replace("missing explicit nested atom task instruction", "missing qualifier instruction")
save_new(PLAN / "root-qualifier-cli-red.py", source.encode())
print(json.dumps({"actual04_archived_files": len(copies) + 1, "diagnosis": diagnosis, "model_calls_in_preparation": 0}, ensure_ascii=False))
