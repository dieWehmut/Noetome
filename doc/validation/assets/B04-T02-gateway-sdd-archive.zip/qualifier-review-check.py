"""Read-only integrity review of the named v5 evidence, without executing tests."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('D:/Noetome')
HERE = ROOT / '.superpowers/sdd/B04-T02_GATEWAY_PLAN'
assets = json.loads((HERE / 'qualifier-review-assets.json').read_text(encoding='utf-8-sig'))
checks = []

def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def asset(name):
    return assets['doc/validation/assets/' + name + '.json']

summary = asset('B04-T02-qualifier-final-workspace-summary')
worker = asset('B04-T02-qualifier-fix-artifacts')
for path, digest in summary['source_sha256'].items():
    check('current-v5-source:' + path, sha((ROOT / path).read_bytes()) == digest)
    if path in worker['files']:
        check('worker-source:' + path, worker['files'][path]['sha256'] == digest)
check('current-debug-binary', sha((ROOT / 'target/debug/noetome.exe').read_bytes()) == summary['binary_sha256'])
for path, record in worker['files'].items():
    raw = (ROOT / path).read_bytes()
    check('worker-artifact:' + path, sha(raw) == record['sha256'] and len(raw) == record['bytes'])
archive = asset('B04-T02-qualifier-final-archive')
for record in archive['records']:
    raw = (ROOT / record['path']).read_bytes()
    check('archive-record:' + record['path'], sha(raw) == record['sha256'] and len(raw) == record['byte_length'])

runs = {}
for suffix in ['fix-native-red','cli-red','fix-native-green','fix-cli-green','fix-fake-green','python-tests','final-workspace-tests','final-check','final-fmt']:
    value = asset('B04-T02-qualifier-' + suffix)
    output = value.get('output', '') + value.get('stdout', '') + value.get('stderr', '')
    rows = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', output)
    runs[suffix] = {'exit_code': value['exit_code'], 'rows': rows,
                    'python76': 'Ran 76 tests' in output and '\nOK' in output,
                    'warnings': [line for line in output.splitlines() if 'warning:' in line]}
    for key in ['stdout','stderr']:
        if key + '_sha256' in value:
            check('recorded-stream-digest:' + suffix + ':' + key, sha(value[key].encode()) == value[key + '_sha256'])

audits = {}
for name, expected_checks, expected_calls, expected_posts in [('api',84,90,54), ('fake',54,60,0), ('chat',35,37,29)]:
    value = asset('B04-T02-qualifier-final-' + name + '-audit')
    posts = sum(c.get('local_post_count',0) for c in value['checks'])
    check('final-audit:' + name, len(value['checks']) == expected_checks and len(value['calls']) == expected_calls and posts == expected_posts and all(c['passed'] for c in value['checks']) and value['binary_sha256'] == summary['binary_sha256'])
    check('final-source-sql:' + name, value['source_sql_before'] == value['source_sql_after'])
    audits[name] = {'checks':len(value['checks']), 'cli_calls':len(value['calls']), 'local_posts':posts}
    if name == 'chat':
        missing = next(c for c in value['checks'] if c['name'] == 'chat-missing-unit-qualifier')
        check('chat-missing-unit-rejected', missing['observed_exit'] == 3 and missing['passed'] and missing['local_post_count'] == 1)

snap = asset('B04-T02-qualifier-final-snapshot-verification')
check('snapshot-counts', len(snap['reports']) == 128 and len(snap['requests']) == 90 and snap['report_counts'] == {'api':59, 'fake':38, 'chat':30, 'selected-zero':1})
strategy = 'tangmao-deepseek-chat-qualifiers-v5'
with zipfile.ZipFile(ROOT / 'doc/validation/assets/B04-T02-qualifier-final-reports.zip') as z:
    check('archive716', len(z.namelist()) == len(set(z.namelist())) == 716)
    for entry in snap['reports']:
        path = entry['path']
        raw = z.read(path)
        md = z.read(path[:-5] + '.md')
        report = json.loads(raw)
        blocks = re.findall(r'```json\s*\n(.*?)\n```', md.decode(), re.S)
        check('report-pair:' + path, sha(raw) == entry['json_sha256'] and sha(md) == entry['markdown_sha256'] and len(blocks) == 1 and json.loads(blocks[0]) == report)
        check('report-status:' + path, report['knowledge_status'] == 'pending' and report['scientific_quality'] == 'not_run' and report['published'] is False)
        parent = path.rsplit('/',1)[0] + '/'
        for name, record in report['artifacts'].items():
            raw_artifact = z.read(parent + name)
            check('report-artifact:' + parent + name, sha(raw_artifact) == record['sha256'] and len(raw_artifact) == record['byte_length'])
        if entry['kind'] in ['chat','selected-zero']:
            body = json.loads(z.read(parent + 'request-body.json'))
            user = json.loads(body['messages'][1]['content'])
            check('v5-chat-request:' + path, set(body) == {'model','messages','thinking','response_format','max_tokens','stream'} and report['request_strategy'] == strategy and set(user) == {'task','response_schema','request'} and all(phrase in user['task'] for phrase in ['Include measurement.unit verbatim in atom.qualifiers','Include every measurement.conditions string verbatim in atom.qualifiers','two top-level keys: atom and measurement','inside atom','sibling of atom','Do not flatten']))
    for entry in snap['requests']:
        parent = entry['path'].rsplit('/',1)[0] + '/'
        check('request-digests:' + entry['path'], sha(z.read(parent + 'request-body.json')) == entry['body_sha256'] and sha(z.read(parent + 'request.json')) == entry['request_sha256'])

fourth_raw = (ROOT / 'doc/validation/assets/B04-T02-live-fourth-response.bin').read_bytes()
fourth = json.loads(fourth_raw)
candidate = json.loads(fourth['choices'][0]['message']['content'])['atoms'][0]
measure = candidate['measurement']
report = asset('B04-T02-live-fourth-validation')
check('original-fourth-unit-missing', measure['unit'] == 'm/s' and measure['unit'] not in candidate['atom']['qualifiers'] and all(c in candidate['atom']['qualifiers'] for c in measure['conditions']))
check('original-fourth-core-failure', report['status'] == 'failed' and report['errors'][0]['code'] == 'EXTRACT_QUALIFIERS' and report['usage']['model_usage'] == {'input_tokens':1712,'output_tokens':3071,'total_tokens':4783} and report['usage']['model_usage_status'] == 'validated')
check('original-fourth-digest', sha(fourth_raw) == 'a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9' and len(fourth_raw) == 13739)

evidence = {'base':'8004df0f70dddc38a3f37be192d6928f3970c10e', 'head':'fd53462c5217060c40a30a38f40b3bcc2e2b8fc0', 'binary_sha256':summary['binary_sha256'], 'runs':runs, 'audits':audits, 'checks':checks, 'checks_passed':sum(c['passed'] for c in checks), 'checks_failed':sum(not c['passed'] for c in checks), 'commands_executed':'read-only evidence helper only; no suites, Cargo, builds, UI, network or model calls'}
(HERE / 'qualifier-review-evidence.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:evidence[k] for k in ['checks_passed','checks_failed','runs','audits']}, ensure_ascii=False, indent=2))
