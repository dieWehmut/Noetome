"""Prepare an independent actual06 verifier, preserving earlier scripts."""
import ast
from pathlib import Path

PLAN = Path(__file__).resolve().parent
source = (PLAN / "root-live-fifth-verify.py").read_text(encoding="utf-8")
source = source.replace("actual05", "actual06").replace("api-live-05", "api-live-06").replace("-05.json", "-06.json")
source = source.replace("root-qualifier", "root-revision").replace("tangmao-deepseek-chat-qualifiers-v5", "tangmao-deepseek-chat-positive-revision-v6")
source = source.replace("import datetime\n", "import copy\nimport datetime\n")
source = source.replace('EXPECTED_BINARY = "514ce3c5414874956dffcc3e612ecd538b59393e0eec71977d011d938f69b236"',
                        'EXPECTED_BINARY = json.loads((PLAN / "root-revision-workspace-summary.json").read_text(encoding="utf-8"))["binary_sha256"]')
source = source.replace('previous_body = read(LIVE / "api-live-04/request-body.json")', 'previous_body = read(LIVE / "api-live-05/request-body.json")')
source = source.replace('assert user["response_schema"] == previous_user["response_schema"]', '''expected_schema = copy.deepcopy(previous_user["response_schema"])
expected_schema["properties"]["concepts"]["items"]["properties"]["revision"]["minimum"] = 1
expected_schema["properties"]["atoms"]["items"]["properties"]["atom"]["properties"]["revision"]["minimum"] = 1
assert user["response_schema"] == expected_schema
assert "Every concept.revision and atom.revision must be a positive integer" in user["task"]''')
source = source.replace('prior = read(LIVE / "live-budget-settlement-04.json")', 'prior = read(LIVE / "live-budget-settlement-05.json")')
source = source.replace('[936, 9683, 4912, 4783, total]', '[936, 9683, 4912, 4783, 3479, total]')
source = source.replace('== 20314', '== 23793').replace('== 9979686', '== 9976207')
source = source.replace('== 9979686 -', '== 9976207 -').replace('== 20314 +', '== 23793 +')
source = source.replace('settled["model_attempts"] == 5', 'settled["model_attempts"] == 6')
source = source.replace('for e in evidence.values():', 'assert all(type(c["revision"]) is int and c["revision"] > 0 for c in raw_candidate["concepts"])\nfor e in evidence.values():')
source = source.replace('    atom, measurement = item["atom"], item["measurement"]', '    atom, measurement = item["atom"], item["measurement"]\n    assert type(atom["revision"]) is int and atom["revision"] > 0')
needle = '(4, "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9")]'
assert source.count(needle) == 1
source = source.replace(needle, '(4, "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9"), (5, "b04c99ff593ee99431f140747a5c088cf4011a1a87237981e03cd176feb07f8f")]')
source = source.replace('"original_four_responses_unchanged"', '"original_five_responses_unchanged"')
ast.parse(source)
with (PLAN / "root-live-sixth-verify.py").open("x", encoding="utf-8", newline="\n") as handle:
    handle.write(source)
source = (PLAN / "root-live-fifth-archive.py").read_text(encoding="utf-8")
source = source.replace("actual05", "actual06").replace("api-live-05", "api-live-06").replace("-05.json", "-06.json")
source = source.replace("fifth", "sixth").replace("qualifier-review", "revision-review")
source = source.replace('"original_four_responses_unchanged"', '"original_five_responses_unchanged"')
ast.parse(source)
with (PLAN / "root-live-sixth-archive.py").open("x", encoding="utf-8", newline="\n") as handle:
    handle.write(source)
print("Prepared actual06 independent verification/archive only; no model call.")
