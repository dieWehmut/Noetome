import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('D:/Noetome')
WORK = ROOT / '.superpowers/sdd/B04-T02_GATEWAY_PLAN'
ASSETS = ROOT / 'doc/validation/assets'
LIVE = ROOT / 'target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556'
checks = []

def check(name, condition, detail=None):
    checks.append({'check': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        raise AssertionError(name)

def fingerprint(path):
    data = path.read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'byte_length': len(data)}

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def unique(pairs):
    d = {}
    for key, value in pairs:
        if key in d:
            raise ValueError('duplicate key')
        d[key] = value
    return d

def main():
    diff_path = WORK / 'review-e7002e8..332fcd9.diff'
    lines = diff_path.read_text(encoding='utf-8').splitlines()
    files, path, hunk, line_number = [], None, [], None
    def validate_hunk():
        if line_number is not None:
            actual = (ROOT / path).read_text(encoding='utf-8').splitlines()
            check('immutable diff hunk matches checkout', actual[line_number - 1:line_number - 1 + len(hunk)] == hunk,
                  {'path': path, 'line': line_number, 'line_count': len(hunk)})
    for line in lines:
        if line.startswith('diff --git '):
            validate_hunk()
            path = line.split(' b/', 1)[1]
            files.append(path)
            hunk, line_number = [], None
        elif line.startswith('@@ '):
            validate_hunk()
            line_number = int(re.search(r'\+(\d+)', line).group(1))
            hunk = []
        elif line_number is not None and line[:1] in ('+', ' '):
            hunk.append(line[1:])
    validate_hunk()
    check('exact reviewed package file count', len(files) == 44, files)
    artifacts = load(WORK / 'inline-fix-artifacts.json')
    for path, expected in artifacts.items():
        if path.startswith('crates/') or path.endswith('live-first-response.bin'):
            check('implementer immutable native/raw fingerprint', fingerprint(ROOT / path) ==
                  {'sha256': expected['sha256'], 'byte_length': expected['bytes']}, path)

    logs = {}
    for name, exit_code, result in [
        ('inline-fix-native-red.json', 1, '0 passed; 3 failed'),
        ('inline-cli-red.json', 1, '1 passed; 1 failed'),
        ('inline-fix-native-green.json', 1, 'error[E0061]'),
        ('inline-fix-native-green2.json', 0, '29 passed; 0 failed'),
        ('inline-fix-cli-green.json', 0, '5 passed; 0 failed'),
        ('inline-fix-fake-green.json', 0, '3 passed; 0 failed'),
        ('inline-fix-check.json', 0, 'Finished `dev`'),
        ('inline-fix-owned-fmt-check.json', 0, ''),
        ('inline-fix-fmt-check.json', 1, 'tests\\extraction_api.rs:367')]:
        log = load(WORK / name)
        check('retained actual command result', log['exit_code'] == exit_code and result in log['output'], name)
        if exit_code == 0:
            check('green command has no Rust warnings/errors', 'warning:' not in log['output'] and 'error:' not in log['output'], name)
        logs[name] = {'command': log['command'], 'exit_code': log['exit_code'], 'output': log['output'],
                      'fingerprint': fingerprint(WORK / name)}
    format_log = load(ASSETS / 'B04-T02-inline-root-format-review.json')
    check('controller format correction recorded', format_log['result']['exit_code'] == 0)

    raw_path = ASSETS / 'B04-T02-live-first-response.bin'
    check('exact authorized raw response SHA', fingerprint(raw_path)['sha256'] ==
          '73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b')
    raw = json.loads(raw_path.read_bytes(), object_pairs_hook=unique)
    check('first response selected completed sparse envelope', raw['status'] == 'completed' and
          'error' not in raw and 'incomplete_details' not in raw)
    usage = {k: raw['usage'][k] for k in ('input_tokens', 'output_tokens', 'total_tokens')}
    check('actual first response independent valid usage', usage ==
          {'input_tokens': 551, 'output_tokens': 385, 'total_tokens': 936})
    output_text = [part['text'] for item in raw['output'] if item['type'] == 'message'
                   for part in item['content'] if part['type'] == 'output_text']
    check('first actual response exactly one candidate text', len(output_text) == 1)
    try:
        json.loads(output_text[0], object_pairs_hook=unique)
        candidate_json = True
    except ValueError:
        candidate_json = False
    check('first actual plaintext remains invalid JSON', not candidate_json)
    check('raw output archive equals original live output', raw_path.read_bytes() == (LIVE / 'api-live-01/response.bin').read_bytes())
    report = load(ASSETS / 'B04-T02-live-first-validation.json')
    request = load(ASSETS / 'B04-T02-live-first-request.json')
    body = load(ASSETS / 'B04-T02-live-first-request-body.json')
    check('historical failed report remains v1 with real usage', report['status'] == 'failed' and
          report['request_strategy'] == 'tangmao-deepseek-responses-json-schema-v1' and
          report['usage']['model_usage'] == raw['usage'] and report['usage']['network_attempts'] == 1)
    check('historical first-call original failure preserved', [e['code'] for e in report['errors']] == ['EXTRACT_API_RESPONSE'])
    check('original v1 request stays flat', set(json.loads(body['input'])) ==
          {'request_id', 'binding', 'units', 'evidence_anchors'})
    check('request real body hash and reservation', report['usage']['request_utf8_bytes'] == len((ASSETS / 'B04-T02-live-first-request-body.json').read_bytes()) and
          report['usage']['input_reserved_tokens'] == report['usage']['request_utf8_bytes'] + 1024)
    for filename in ('request.json', 'request-body.json', 'validation.json'):
        check('first-call saved provenance matches original output', (LIVE / 'api-live-01' / filename).read_bytes() ==
              (ASSETS / ('B04-T02-live-first-' + filename)).read_bytes(), filename)
    check('no candidate/IR/Vault emitted by first failed call', not any(
          (LIVE / 'api-live-01' / name).exists() for name in ('candidates.json', 'ir.json', 'compile.sqlite', 'Vault', 'vault')))
    reservation = load(ASSETS / 'B04-T02-live-first-reservation.json')
    settlement = load(ASSETS / 'B04-T02-live-first-settlement.json')['ledger_after_settlement']
    check('actual first-call cumulative ledger settlement', settlement['approved_total_tokens'] == 10000000 and
          settlement['accounted_tokens'] == 936 and settlement['pending_reserved_tokens'] == 0 and
          settlement['remaining_tokens'] == 9999064 and settlement['model_attempts'] == 1)
    rec = settlement['records'][0]
    check('record binds request, source, model and actual failure', rec['source_import_id'] == request['binding']['import_id'] and
          rec['configured_model'] == body['model'] == raw['model'] and rec['response_id'] == raw['id'] and
          rec['confirmed_total_tokens'] == 936 and rec['result_status'] == 'failed')
    before = load(LIVE / 'source-before.json')
    check('source fixed before reservation', before['author_data_fixed_before_model_call'] and
          before['model_calls_before_capture'] == 0 and before['captured_at'] < rec['reserved_at'])
    source_fingerprints = {}
    for rel, expected in before['project_files'].items():
        file = LIVE / 'source-project' / rel
        actual = fingerprint(file)
        actual['mtime_ns'] = file.stat().st_mtime_ns
        source_fingerprints[rel] = actual
        check('original selected source file SHA length mtime unchanged', actual == expected, rel)
    actual_files = {str(p.relative_to(LIVE / 'source-project')) for p in (LIVE / 'source-project').rglob('*') if p.is_file()}
    check('same five selected source files', actual_files == set(before['project_files']) and len(actual_files) == 5)
    check('source fixture and saved gold unchanged', fingerprint(ROOT / 'fixtures/extraction-gateway-v1/source.txt')['sha256'] == before['source_sha256'] and
          fingerprint(LIVE / 'gold-before.json')['sha256'] == before['gold_sha256'] and
          fingerprint(ASSETS / 'B04-T02-live-gold-before.json')['sha256'] == before['gold_sha256'])
    check('settlement source/gold hashes match pre-call fixed author data', rec['source_sha256'] == before['source_sha256'] and rec['gold_sha256'] == before['gold_sha256'])
    return {'diff': fingerprint(diff_path), 'files': files, 'implementer_runs': logs,
            'first_call_usage': usage, 'source_fingerprints': source_fingerprints,
            'reviewer_cargo_runs': [], 'network_model_calls': 0,
            'actual_secret_or_operator_config_reads': 0,
            'scope': 'e7002e8d47cc3bcee5c244bfacac2e91e143ee86..332fcd97c264ce8c9e88099ae3d0b1179e4f80d6'}

result = {}
try:
    result = main()
finally:
    result['captured_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['checks'] = checks
    result['passed'] = bool(checks) and all(c['passed'] for c in checks)
    (WORK / 'inline-review-evidence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'passed': result['passed'], 'checks': len(checks)}, ensure_ascii=False))
