from pathlib import Path
import hashlib
import json

plan=Path(__file__).resolve().parent
source=(plan/'root-live-fourth.py').read_text(encoding='utf-8')
source=source.replace('v4 nested-atom','v5 qualifier-contract').replace('tangmao-deepseek-chat-nested-atoms-v4','tangmao-deepseek-chat-qualifiers-v5')
source=source.replace('api-live-04','api-live-05').replace('-04.json','-05.json')
source=source.replace('root-shape','root-qualifier').replace('== 127','== 128')
source=source.replace('Path("C:/Users/Lyinn/AppData/Local/Noetome/model-services/tangmao-deepseek.json")','Path(os.environ["LOCALAPPDATA"]) / "Noetome/model-services/tangmao-deepseek.json"')
source=source.replace('Path("C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe")','Path(sys.argv[1])')
source=source.replace('== 15531','== 20314').replace('== 9984469','== 9979686').replace('== 3\nassert len(ledger["records"]) == 3','== 4\nassert len(ledger["records"]) == 4')
source=source.replace('== [936, 9683, 4912]','== [936, 9683, 4912, 4783]')
source=source.replace('One documented Chat v4 verification after complete but flattened third response; nested atom task RED/GREEN, fresh review and final regressions; same source/gold and cumulative budget','One documented Chat v5 verification after nested fourth response omitted unit qualifier; generic cross-field task RED/GREEN, fresh review and final same-source regressions; same source/gold and cumulative budget')
guard='assert sha((LIVE / "api-live-04/response.bin").read_bytes()) == "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9"\n'
source=source.replace('verified = read(PLAN / "root-qualifier-snapshot-verification.json")',guard+'verified = read(PLAN / "root-qualifier-snapshot-verification.json")')
source=source.replace('assert unchanged\n','assert unchanged\n'+guard)
path=plan/'root-live-fifth.py'
assert not path.exists(), path
path.write_bytes(source.encode())
archive=plan/'root-qualifier-final-archive.py'
text=archive.read_text(encoding='utf-8').replace('("root-qualifier-snapshot-check.py", "qualifier-final-snapshot-source.json")','("root-qualifier-snapshot-check-v2.py", "qualifier-final-snapshot-source.json")')
archive.write_bytes(text.encode())
print(json.dumps({'driver_prepared_only':True,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'model_calls':0}))
