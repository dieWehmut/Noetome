"""Read-only final review evidence audit; no product/test execution or private state access."""
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('D:/Noetome')
OUT = ROOT / '.superpowers/sdd/B04-T02_GATEWAY_PLAN'
ASSETS = ROOT / 'doc/validation/assets'
checks = []
fingerprints = {}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)

def unique(pairs):
    result = {}
    for k, v in pairs:
        if k in result:
            raise ValueError('duplicate key ' + k)
        result[k] = v
    return result

def parse(b):
    return json.loads(b, object_pairs_hook=unique)

def raw(path):
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    b = p.read_bytes()
    fingerprints[p.relative_to(ROOT).as_posix()] = {'sha256': sha(b), 'bytes': len(b)}
    return b

def read(name):
    return parse(raw(ASSETS / ('B04-T02-' + name + '.json')))

def output(j):
    return j.get('output', '') + j.get('stdout', '') + j.get('stderr', '')

def summary(j):
    rows = re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored', output(j))
    return tuple(sum(int(r[i]) for r in rows) for i in range(3))

try:
    raw(OUT / 'review-8004df0..bee1603.diff')
    ws = read('revision-final-workspace-summary')
    binary = ws['binary_sha256']
    for p, expected in ws['source_sha256'].items():
        check('current reviewed source hash: ' + p, sha(raw(p)) == expected)
    check('final executable binding', sha(raw('target/debug/noetome.exe')) == binary)
    for manifest in ['revision-final-archive', 'live-sixth-archive']:
        j = read(manifest)
        check(manifest + ' binary', j['binary_sha256'] == binary)
        for item in j['records']:
            b = raw(item['path'])
            check('manifest bytes: ' + item['path'], sha(b) == item['sha256'] and len(b) == item['byte_length'])
    for name, expected in [('revision-final-workspace-tests', (502, 0, 0)), ('revision-fix-native-red', (1, 3, 0)), ('revision-cli-red', (0, 2, 0))]:
        j = read(name)
        check(name + ' actual result rows', summary(j) == expected)
        check(name + ' recorded exit', j['exit_code'] == (0 if expected[1] == 0 else 101))
    for name in ['revision-final-workspace-tests', 'revision-python-tests', 'revision-cli-red']:
        j = read(name)
        for stream in ['stdout', 'stderr']:
            check(name + ' ' + stream + ' exact captured hash', sha(j[stream].encode()) == j[stream + '_sha256'])
    py = read('revision-python-tests')
    check('Python 76 recorded pass', py['exit_code'] == 0 and 'Ran 76 tests' in output(py) and re.search(r'\bOK\b', output(py)))
    for name in ['revision-final-fmt', 'revision-final-check']:
        check(name + ' exit', read(name)['exit_code'] == 0)
    empty = read('revision-fix-native-empty-target')
    check('mistaken empty target retained separately', summary(empty) == (0, 0, 0))
    check('initial formatting failure retained', read('revision-fix-fmt-initial-failure')['exit_code'] != 0)
    for name, count, calls, posts in [('api', 84, 90, 54), ('fake', 54, 60, None), ('chat', 37, 39, 31)]:
        j = read('revision-final-' + name + '-audit')
        check(name + ' matrix binding/counts', j['binary_sha256'] == binary and len(j['checks']) == count and len(j['calls']) == calls)
        check(name + ' matrix all passed', all(x['passed'] for x in j['checks']))
        check(name + ' source SQL unchanged', j['source_sql_before'] == j['source_sql_after'])
        if posts is not None:
            check(name + ' local POST count', sum(x['local_post_count'] for x in j['checks']) == posts)
            check(name + ' no model calls', j['real_model_calls'] == j['paid_calls'] == 0)
        if name == 'chat':
            for neg in ['chat-missing-unit-qualifier', 'chat-zero-concept-revision', 'chat-zero-atom-revision']:
                c = next(x for x in j['checks'] if x['name'] == neg)
                check(neg + ' strict failure', c['expected_exit'] == c['observed_exit'] == 3)
    snapshot = read('revision-final-snapshot-verification')
    with zipfile.ZipFile(ASSETS / 'B04-T02-revision-final-reports.zip') as z:
        check('728 archived unique files', len(z.infolist()) == len(set(z.namelist())) == 728)
        check('archive CRC integrity', z.testzip() is None)
        check('130 report records and 92 request records', len(snapshot['reports']) == 130 and len(snapshot['requests']) == 92)
        for entry in snapshot['reports']:
            jp = entry['path']; mp = jp[:-5] + '.md'
            jb, mb = z.read(jp), z.read(mp)
            check('paired archive hashes: ' + jp, sha(jb) == entry['json_sha256'] and sha(mb) == entry['markdown_sha256'])
            blocks = re.findall(r'```json\s*\n(.*?)\n```', mb.decode('utf-8'), re.S)
            check('paired report equality: ' + jp, len(blocks) == 1 and parse(blocks[0]) == parse(jb))
        for entry in snapshot['requests']:
            parent = entry['path'].rsplit('/', 1)[0]
            check('request archive hashes: ' + parent, sha(z.read(parent + '/request-body.json')) == entry['body_sha256'] and sha(z.read(parent + '/request.json')) == entry['request_sha256'])
    request = read('live-sixth-request')
    body = read('live-sixth-request-body')
    previous = read('live-fifth-request-body')
    user = parse(body['messages'][1]['content'])
    old_user = parse(previous['messages'][1]['content'])
    check('same six Chat body fields', set(body) == {'model', 'messages', 'thinking', 'response_format', 'max_tokens', 'stream'})
    check('bounded intended request controls', body['max_tokens'] == 8192 and body['stream'] is False and body['thinking'] == {'type': 'disabled'} and body['response_format'] == {'type': 'json_object'})
    check('unchanged system instructions', body['messages'][0] == previous['messages'][0])
    check('v5 prefix and exact new suffix', user['task'] == old_user['task'] + ' Every concept.revision and atom.revision must be a positive integer; use 1 for a newly extracted candidate. Never use 0.')
    expected = copy.deepcopy(old_user['response_schema'])
    expected['properties']['concepts']['items']['properties']['revision']['minimum'] = 1
    expected['properties']['atoms']['items']['properties']['atom']['properties']['revision']['minimum'] = 1
    check('only two schema additions', user['response_schema'] == expected)
    for k in ['binding', 'units', 'evidence_anchors']:
        check('unchanged source request ' + k, user['request'][k] == old_user['request'][k])
    wire = parse(raw(ASSETS / 'B04-T02-live-sixth-response.bin'))
    check('single stopped assistant response', len(wire['choices']) == 1 and wire['choices'][0]['index'] == 0 and wire['choices'][0]['finish_reason'] == 'stop' and wire['choices'][0]['message']['role'] == 'assistant')
    payload = parse(wire['choices'][0]['message']['content'])
    saved = read('live-sixth-candidates')
    report = read('live-sixth-validation')
    command = read('live-sixth-command')
    check('original content equals saved payload', payload == saved['payload'])
    check('CLI report equality', parse(command['stdout']) == report and command['exit_code'] == 0 and command['binary_sha256'] == binary)
    check('live identity and API success', payload['request_id'] == request['request_id'] == report['request_id'] and payload['binding'] == request['binding'] == report['binding'] and report['http_status'] == 200 and report['status'] == 'candidates_validated' and report['errors'] == [])
    check('honest knowledge boundary', report['knowledge_status'] == 'pending' and report['scientific_quality'] == 'not_run' and report['published'] is False)
    check('unknown billing', report['usage']['price_usd'] is None and report['usage']['paid_calls'] is None)
    check('single live model/network attempt', report['usage']['real_model_calls'] == report['usage']['network_attempts'] == 1)
    check('positive concept and atom revisions', all(type(c['revision']) is int and c['revision'] > 0 for c in payload['concepts']) and all(type(a['atom']['revision']) is int and a['atom']['revision'] > 0 for a in payload['atoms']))
    for item in payload['atoms']:
        m = item['measurement']; q = item['atom']['qualifiers']
        check('exact measurement qualifiers', m is None or ((m['unit'] is None or m['unit'] in q) and all(c in q for c in m['conditions'])))
    source = raw('fixtures/extraction-gateway-v1/source.txt')
    for e in payload['evidence']:
        b = source[e['excerpt_start_byte']:e['excerpt_end_byte']]
        check('exact source UTF8 quote and SHA', b.decode('utf-8') == e['quote'] and sha(b) == e['excerpt_sha256'])
    check('reasoning retained and bounded count', len(wire['choices'][0]['message']['reasoning_content'].encode()) == 16715)
    check('source SHA binding', sha(source) == request['binding']['content_sha256'])
    md = raw(ASSETS / 'B04-T02-live-sixth-validation.md').decode()
    blocks = re.findall(r'```json\s*\n(.*?)\n```', md, re.S)
    check('live JSON Markdown equality', len(blocks) == 1 and parse(blocks[0]) == report)
    for name, info in report['artifacts'].items():
        if name == '.owner.json':
            continue
        b = raw(ASSETS / ('B04-T02-live-sixth-' + name))
        check('live report declared artifact: ' + name, sha(b) == info['sha256'] and len(b) == info['byte_length'])
    reserved = read('live-sixth-reservation')['ledger_after_reservation']
    settled = read('live-sixth-settlement')['ledger_after_settlement']
    prior = read('live-fifth-settlement')['ledger_after_settlement']
    check('preserved five settled records', reserved['records'][:-1] == settled['records'][:-1] == prior['records'])
    totals = [r['confirmed_total_tokens'] for r in settled['records']]
    check('six actual usage totals', totals == [936, 9683, 4912, 4783, 3479, 6304])
    check('external pre-call reserved arithmetic', reserved['approved_total_tokens'] == 10000000 and reserved['accounted_tokens'] == 23793 and reserved['pending_reserved_tokens'] == 65536 and reserved['remaining_tokens'] == 10000000 - 23793 - 65536)
    check('settled cumulative arithmetic', settled['accounted_tokens'] == sum(totals) == 30097 and settled['remaining_tokens'] == 10000000 - sum(totals) == 9969903 and settled['pending_reserved_tokens'] == 0 and settled['model_attempts'] == 6)
    check('live response usage mapping', wire['usage'] == {'prompt_tokens': 1792, 'completion_tokens': 4512, 'total_tokens': 6304} and report['usage']['model_usage'] == {'input_tokens': 1792, 'output_tokens': 4512, 'total_tokens': 6304})
    body_bytes = raw(ASSETS / 'B04-T02-live-sixth-request-body.json')
    check('serialized body reservation exact', report['usage']['input_reserved_tokens'] == len(body_bytes) + 1024 and report['usage']['reserved_tokens'] == len(body_bytes) + 1024 + 8192 <= 65536)
    check('captured settled record binds original response', settled['records'][-1]['response_id'] == wire['id'] and settled['records'][-1]['invocation_id'] == command['invocation_id'])
    expected_hashes = ['73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b','f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a','6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b','a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9','b04c99ff593ee99431f140747a5c088cf4011a1a87237981e03cd176feb07f8f']
    for name, digest in zip(['first','second','third','fourth','fifth'], expected_hashes):
        check('original ' + name + ' response', sha(raw(ASSETS / ('B04-T02-live-' + name + '-response.bin'))) == digest)
    for name in ['live-sixth-controller-source', 'live-sixth-verification-source']:
        j = read(name)
        check(name + ' executable source archive hash', sha(j['source_text'].encode()) == j['source_sha256'] and len(j['source_text'].encode()) == j['byte_length'])
    tasks = parse(raw('dev-log/tasks.json'))['tasks']
    check('single T02 current task and T03 pending', [t['id'] for t in tasks if t['status'] == 'in_progress'] == ['B04-T02'] and next(t for t in tasks if t['id'] == 'B04-T03')['status'] == 'todo')
finally:
    evidence = {'reviewed_base': '8004df0f70dddc38a3f37be192d6928f3970c10e', 'reviewed_head': 'bee1603bde81d555d11c7b9646c1ff5cb4cd5378', 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'methods': ['static immutable supplied diff review', 'captured JSON unique-key parsing and arithmetic', 'SHA256 and byte counts', 'ZIP CRC/read without extraction', 'captured test-output result parsing; no test or build execution'], 'assertions': len(checks), 'failures': [c for c in checks if not c['passed']], 'checks': checks, 'fingerprints': fingerprints, 'limits': ['No network/model calls', 'No private profile, external live ledger, or DPAPI reads', 'Source SQL preservation evaluated from captured controller verification, not rerun', 'No independent knowledge/scientific assessment']}
    (OUT / 'gateway-final-review-evidence.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'assertions':len(checks), 'failures':evidence['failures'], 'fingerprints':len(fingerprints)}))
