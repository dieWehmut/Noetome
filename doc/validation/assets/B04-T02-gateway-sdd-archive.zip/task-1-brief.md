## Task 1: 本机遮蔽凭据保存与复用脚本

**文件责任**：新建 `scripts/set_api_credential.ps1`、`scripts/invoke_api_credential.ps1`，以及针对它们的 `tests/test_api_credential_scripts.py`。只编辑这些文件，controller 负责模型设置文件、文档及真实调用。不得打开任何实际用户密钥文件或读取 Codex 认证值。

**保存接口**：`set_api_credential.ps1 -CredentialFile <外部绝对路径> -ServiceUrl <HTTPS origin> -Model <标识> [-Dialog] [-FromEnvironment <明确变量>]`。没有明文 key 参数；默认 Read-Host -AsSecureString，Dialog 使用原生 WPF PasswordBox，显示服务和模型、保存/取消按钮。只在操作者点击保存后保存，Enter 不能绕过检查。FromEnvironment 供明确选中环境变量及离线 public synthetic key 测试；从不枚举环境或默认密钥。

**保存保护**：Windows CurrentUser DPAPI（ConvertFrom-SecureString 默认模式），仓库之外的普通文件；拒绝仓库内/相对路径、任何已有目的文件及 reparse point 祖先。正常创建新文件，不覆盖旧凭据；加密内容不可混入 key 值、服务配置、认证头、stdout/stderr 或错误正文。输入须为非空 ASCII、无控制/空白、最多8192字节。Dialog 不返回 PasswordBox 内容，取消没有凭据文件。保存完成只输出无敏感值的状态及引用路径。保持 PowerShell 5.1/7 Windows 可用，失败用稳定诊断。

**复用接口**：`invoke_api_credential.ps1 -Binary <CLI> -Project <选定项目> -ImportId <ID> -Config <配置> -OutputRoot <全新根> -CredentialFile <DPAPI文件> [-CancelFile <信号>]`。只读明确 config 和 credential；由 config.credential_env 选择2..64位大写变量。解密值仅保存在当前进程内存和子 CLI 环境，不成为命令行参数或临时明文文件；调用既有 `extract api`，保留CLI退出码。finally 还原原环境变量，ZeroFreeBSTR；拒绝仓库内凭据及链接，不自行读私人目录或发起 HTTP。本脚本不自动重试、循环或新增批量。

**验收**：先真实失败再实现，用 public `noetome-test-...` 密钥验证 DPAPI 加密文件不是原文、解密后只断言相等不打印值、已有文件/仓库内/非法输入停止，明确环境变量注入选定子入口且没有 key 值出现在参数或输出、退出码和环境恢复。WPF 使用真实系统加载/窗口入口检查，不把 headless 断言称为用户实际输入。测试不依赖本机固定运行时，Windows 外明确 skip。不产生真实模型请求。

