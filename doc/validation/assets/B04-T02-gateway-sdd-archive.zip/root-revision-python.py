"""Fresh Python regression for the current independent Chat audit source."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
record_file = PLAN / "root-revision-python-tests.json"
assert not record_file.exists()
script = ROOT / "scripts/validate_extraction_chat.py"
script_sha = hashlib.sha256(script.read_bytes()).hexdigest()
argv = [sys.executable, "-X", "utf8", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"]
env = dict(os.environ)
env["NOETOME_PDF_PYTHON"] = env["NOETOME_TEST_PYTHON"] = sys.executable
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
stdout, stderr = run.stdout.decode("utf-8"), run.stderr.decode("utf-8")
counts = re.findall(r"Ran (\d+) tests? in", stdout + stderr)
record = {"command": argv, "started_at": started, "elapsed_seconds": time.monotonic() - clock,
          "exit_code": run.returncode, "stdout": stdout, "stderr": stderr,
          "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
          "script_sha256": script_sha, "model_calls": 0, "test_counts": counts}
with record_file.open("x", encoding="utf-8", newline="\n") as handle:
    json.dump(record, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
assert run.returncode == 0 and counts == ["76"], record
assert hashlib.sha256(script.read_bytes()).hexdigest() == script_sha
print(json.dumps({"exit_code": 0, "passed": 76, "elapsed_seconds": record["elapsed_seconds"], "evidence": str(record_file)}))
