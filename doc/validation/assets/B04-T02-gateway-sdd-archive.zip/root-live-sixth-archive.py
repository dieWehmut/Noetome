"""Archive the completed single actual06 and independent verification verbatim."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
ASSETS = ROOT / "doc/validation/assets"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_bytes(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, "archive differs: " + str(path)
    else:
        with path.open("xb") as handle:
            handle.write(raw)

verification = read(LIVE / "live-independent-verification-06.json")
assert verification["core_candidates_validated"] and verification["source_original_capture_unchanged"]
assert verification["original_five_responses_unchanged"] and verification["pending_reserved_tokens"] == 0
assert verification["knowledge_assessment"] == "pending_B04-T03"
review = PLAN / "revision-review.md"
assert review.is_file()
sources = {
    "api-live-06/request.json": "request.json",
    "api-live-06/request-body.json": "request-body.json",
    "api-live-06/response.bin": "response.bin",
    "api-live-06/candidates.json": "candidates.json",
    "api-live-06/validation.json": "validation.json",
    "api-live-06/validation.md": "validation.md",
    "live-command-06.json": "command.json",
    "live-budget-reservation-06.json": "reservation.json",
    "live-budget-settlement-06.json": "settlement.json",
    "live-after-06.json": "after.json",
    "live-independent-verification-06.json": "verification.json",
}
records = []
for source, name in sources.items():
    path = LIVE / source
    raw = path.read_bytes()
    target = ASSETS / ("B04-T02-live-sixth-" + name)
    save_bytes(target, raw)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw)})
for source, name in [("revision-review.md", "B04-T02-revision-review.md"), ("revision-review-evidence.json", "B04-T02-revision-review-evidence.json")]:
    path = PLAN / source
    if path.is_file():
        raw = path.read_bytes()
        target = ASSETS / name
        save_bytes(target, raw)
        records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw)})
for source, name in [("root-live-sixth-verify.py", "verification-source.json"), ("root-live-sixth-archive.py", "archive-source.json")]:
    path = PLAN / source
    raw = path.read_bytes()
    value = {"source": path.relative_to(ROOT).as_posix(), "source_sha256": sha(raw), "byte_length": len(raw), "source_text": raw.decode("utf-8-sig")}
    content = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    target = ASSETS / ("B04-T02-live-sixth-" + name)
    save_bytes(target, content)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(content), "byte_length": len(content)})
manifest = {"archived_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "request_strategy": verification["request_strategy"],
            "binary_sha256": verification["binary_sha256"], "core_candidates_validated": True, "knowledge_assessment": "pending_B04-T03",
            "cumulative_accounted_tokens": verification["cumulative_accounted_tokens"], "remaining_tokens": verification["remaining_tokens"],
            "pending_reserved_tokens": 0, "records": records, "actual_model_calls_in_archive_step": 0}
save_bytes(ASSETS / "B04-T02-live-sixth-archive.json", (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"archived_records": len(records), "core_candidates_validated": True, "knowledge_assessment": "pending_B04-T03",
                  "cumulative_accounted_tokens": verification["cumulative_accounted_tokens"], "remaining_tokens": verification["remaining_tokens"]}))
