"""One specifically justified v4 nested-atom Chat real verification, selected saved DPAPI helper only.

No key is read by this controller or passed as an argument/file. Unknown usage
retains the cumulative reservation. The original failed output/gold is immutable.
"""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
PROFILE = Path("C:/Users/Lyinn/AppData/Local/Noetome/model-services/tangmao-deepseek.json")
LEDGER = PROFILE.with_name("tangmao-deepseek.usage.json")
PWSH = Path("C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe")
CONFIG = LIVE / "api-chat-config.json"
OUTPUT = LIVE / "api-live-04"
CAP = 65536
STRATEGY = "tangmao-deepseek-chat-nested-atoms-v4"
sys.path.insert(0, str(ROOT / "scripts"))
from validate_extraction_gateway import sql_snapshot

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())

def atomic_ledger(value, previous_raw):
    assert sha(LEDGER.read_bytes()) == sha(previous_raw), "cumulative ledger changed concurrently"
    temporary = LEDGER.with_name(LEDGER.name + "." + uuid.uuid4().hex + ".tmp")
    assert temporary.parent.resolve() == PROFILE.parent.resolve()
    save_new(temporary, value)
    assert sha(LEDGER.read_bytes()) == sha(previous_raw), "cumulative ledger changed before replace"
    os.replace(temporary, LEDGER)

def source_files():
    project = Path(before["project"]).resolve()
    return {str(p.relative_to(project)): {"sha256": sha(p.read_bytes()), "byte_length": p.stat().st_size, "mtime_ns": p.stat().st_mtime_ns} for p in project.rglob("*") if p.is_file()}

before = read(LIVE / "source-before.json")
assert Path(before["project"]).resolve().is_relative_to(ROOT / "target/compiler-temp")
assert source_files() == before["project_files"]
assert sha("\n".join(sql_snapshot(Path(before["project"]).resolve())).encode()) == before["project_sql_sha256"]
assert sha((LIVE / "gold-before.json").read_bytes()) == before["gold_sha256"]
assert sha((ROOT / "fixtures/extraction-gateway-v1/source.txt").read_bytes()) == before["source_sha256"]
assert sha((LIVE / "api-live-01/response.bin").read_bytes()) == "73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b"
assert sha((LIVE / "api-live-02/response.bin").read_bytes()) == "f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a"
assert sha((LIVE / "api-live-03/response.bin").read_bytes()) == "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b"
verified = read(PLAN / "root-shape-snapshot-verification.json")
assert verified["source_original_capture_unchanged"] and len(verified["reports"]) == 127
binary = ROOT / "target/debug/noetome.exe"
binary_sha = sha(binary.read_bytes())
assert binary_sha == verified["binary_sha256"]
zero = read(PLAN / "root-shape-selected-zero/validation.json")
assert zero["request_strategy"] == STRATEGY and zero["usage"]["reserved_tokens"] <= CAP
profile = read(PROFILE)
config_raw = CONFIG.read_bytes()
config = json.loads(config_raw)
assert config["provider"] == profile["interface"] == "openai_chat_completions"
assert config["endpoint"] == profile["endpoint"] == "https://ai.1343263.xyz/v1/chat/completions"
assert config["model"] == profile["model"] == "deepseek-flash"
assert config["credential_env"] == profile["credential_env"] == "NOETOME_TANGMAO_API_KEY"
assert config["budget"] == {"max_requests": 1, "max_total_tokens": CAP, "max_cost_usd": None}
assert config["limits"] == {"max_units": 1, "max_input_bytes": 65536, "max_response_bytes": 1048576, "max_output_tokens": 8192, "timeout_ms": 60000}
assert not OUTPUT.exists()
assert Path(profile["credential_file"]).is_file(), "selected credential reference missing"
ledger_raw = LEDGER.read_bytes()
ledger = json.loads(ledger_raw)
assert ledger["approved_total_tokens"] == profile["approved_total_tokens"] == 10000000
assert ledger["accounted_tokens"] == 15531 and ledger["pending_reserved_tokens"] == 0
assert ledger["remaining_tokens"] == 9984469 and ledger["model_attempts"] == 3
assert len(ledger["records"]) == 3 and [r["confirmed_total_tokens"] for r in ledger["records"]] == [936, 9683, 4912]
invocation = str(uuid.uuid4())
record = {"invocation_id": invocation, "task_id": "B04-T02", "reserved_at": now(), "status": "reserved", "endpoint": config["endpoint"], "configured_model": config["model"], "request_strategy": STRATEGY, "reservation_tokens": CAP, "reservation_policy": "bounded_request_total_cap_65536_tokens", "confirmed_total_tokens": None, "network_attempts": None, "config_reference": str(CONFIG), "config_sha256": sha(config_raw), "output_root": str(OUTPUT), "source_import_id": before["import_id"], "source_sha256": before["source_sha256"], "gold_sha256": before["gold_sha256"], "price_usd": None, "reason": "One documented Chat v4 verification after complete but flattened third response; nested atom task RED/GREEN, fresh review and final regressions; same source/gold and cumulative budget"}
reserved = copy.deepcopy(ledger)
reserved["records"].append(record)
reserved["pending_reserved_tokens"] += CAP
reserved["remaining_tokens"] -= CAP
reserved["updated_at"] = now()
atomic_ledger(reserved, ledger_raw)
save_new(LIVE / "live-budget-reservation-04.json", {"profile_reference": str(PROFILE), "ledger_reference": str(LEDGER), "record": record, "ledger_after_reservation": reserved, "binary_sha256": binary_sha})
argv = [str(PWSH), "-NoLogo", "-NoProfile", "-NonInteractive", "-File", str(ROOT / "scripts/invoke_api_credential.ps1"), "-Binary", str(binary), "-Project", before["project"], "-ImportId", before["import_id"], "-Config", str(CONFIG), "-OutputRoot", str(OUTPUT), "-CredentialFile", profile["credential_file"]]
started = now()
clock = time.monotonic()
result = subprocess.run(argv, cwd=ROOT, capture_output=True)
command = {"schema_version": 1, "producer": "actual_selected_gateway_cli_invocation", "invocation_id": invocation, "started_at": started, "completed_at": now(), "elapsed_seconds": time.monotonic() - clock, "command": argv, "exit_code": result.returncode, "stdout": result.stdout.decode("utf-8"), "stderr": result.stderr.decode("utf-8"), "binary_sha256": binary_sha}
save_new(LIVE / "live-command-04.json", command)
report = read(OUTPUT / "validation.json") if (OUTPUT / "validation.json").is_file() else None
settle_raw = LEDGER.read_bytes()
settled = json.loads(settle_raw)
assert settled == reserved
entry = settled["records"][-1]
assert entry["invocation_id"] == invocation and entry["status"] == "reserved"
usage = report.get("usage", {}) if report else {}
model_usage = usage.get("model_usage")
valid_usage = usage.get("model_usage_status") == "validated" and isinstance(model_usage, dict)
if valid_usage:
    values = [model_usage.get(k) for k in ["input_tokens", "output_tokens", "total_tokens"]]
    assert all(type(v) is int and v >= 0 for v in values)
    input_tokens, output_tokens, total = values
    assert input_tokens + output_tokens == total <= CAP
    assert input_tokens <= usage["input_reserved_tokens"] and output_tokens <= config["limits"]["max_output_tokens"]
    entry["confirmed_total_tokens"] = total
    entry["model_usage"] = model_usage
    entry["status"] = "settled_valid_usage_candidates_validated" if report["status"] == "candidates_validated" else "settled_valid_usage_response_failed"
    settled["accounted_tokens"] += total
    settled["pending_reserved_tokens"] -= CAP
else:
    entry["status"] = "unknown_usage_reservation_retained"
    entry["model_usage"] = None
entry.update({"settled_at": now(), "actual_model": report.get("actual_model") if report else None, "result_status": report.get("status") if report else "invocation_failed", "error_codes": [e["code"] for e in report.get("errors", [])] if report else ["INVOCATION_FAILED"], "response_id": report.get("response_id") if report else None, "network_attempts": usage.get("network_attempts"), "cli_exit_code": result.returncode, "paid_calls": usage.get("paid_calls"), "real_model_calls": usage.get("real_model_calls")})
if type(entry["network_attempts"]) is int:
    settled["model_attempts"] += entry["network_attempts"]
settled["remaining_tokens"] = settled["approved_total_tokens"] - settled["accounted_tokens"] - settled["pending_reserved_tokens"]
assert settled["remaining_tokens"] >= 0
settled["updated_at"] = now()
atomic_ledger(settled, settle_raw)
save_new(LIVE / "live-budget-settlement-04.json", {"ledger_reference": str(LEDGER), "ledger_after_settlement": settled})
after = source_files()
unchanged = after == before["project_files"] and sha(CONFIG.read_bytes()) == sha(config_raw) and sha((LIVE / "gold-before.json").read_bytes()) == before["gold_sha256"] and sha(binary.read_bytes()) == binary_sha
save_new(LIVE / "live-after-04.json", {"source_config_gold_binary_unchanged": unchanged, "source_files": after, "binary_sha256": binary_sha, "first_response_unchanged": sha((LIVE / "api-live-01/response.bin").read_bytes()) == "73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b", "second_response_unchanged": sha((LIVE / "api-live-02/response.bin").read_bytes()) == "f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a", "third_response_unchanged": sha((LIVE / "api-live-03/response.bin").read_bytes()) == "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b", "preserved_responses_config_unchanged": sha((LIVE / "api-real-config.json").read_bytes()) == "2d2ade4e5642d65cb9b536a26a42789fe0202fdbeb526bb96ad52bb9bef39d72"})
print(json.dumps({"cli_exit_code": result.returncode, "elapsed_seconds": command["elapsed_seconds"], "status": report.get("status") if report else None, "errors": entry["error_codes"], "actual_model": entry["actual_model"], "http_status": report.get("http_status") if report else None, "model_usage": entry["model_usage"], "validated_atoms": report.get("validated_atoms") if report else None, "remaining_tokens": settled["remaining_tokens"], "pending_reserved_tokens": settled["pending_reserved_tokens"], "source_config_gold_binary_unchanged": unchanged, "output_root": str(OUTPUT)}, ensure_ascii=False), flush=True)
assert unchanged

assert sha((LIVE / "api-live-03/response.bin").read_bytes()) == "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b"
