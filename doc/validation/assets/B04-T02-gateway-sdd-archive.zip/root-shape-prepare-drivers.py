"""Prepare new v4 evidence drivers; do not run a model or mutate a ledger."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write_new(path, raw):
    assert not path.exists(), path
    with path.open("xb") as handle:
        handle.write(raw)

fingerprints = json.loads((PLAN / "shape-fix-artifacts.json").read_text(encoding="utf-8-sig"))
for source, info in fingerprints["files"].items():
    raw = (ROOT / source).read_bytes()
    assert sha(raw) == info["sha256"] and len(raw) == info["bytes"], source
for path in sorted(PLAN.glob("shape-fix-*")):
    if path.suffix == ".patch":
        raw = path.read_bytes()
        value = {"source": path.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw), "patch": raw.decode("utf-8")}
        write_new(ASSETS / "B04-T02-shape-fix-source-patch.json", (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())
    else:
        assert path.suffix in (".json", ".md"), path
        write_new(ASSETS / ("B04-T02-" + path.name), path.read_bytes())
for source, target in [
    ("root-shape-prototype-chat-command.json", "shape-prototype-chat-command.json"),
    ("root-shape-prototype-chat/audit.json", "shape-prototype-chat-audit.json"),
]:
    write_new(ASSETS / ("B04-T02-" + target), (PLAN / source).read_bytes())

version_old = "tangmao-deepseek-chat-json-object-no-thinking-v3"
version_new = "tangmao-deepseek-chat-nested-atoms-v4"
workspace = (PLAN / "root-chat-workspace-checks.py").read_text(encoding="utf-8-sig")
workspace = workspace.replace("root-chat-", "root-shape-").replace('["passed"] == 497', '["passed"] == 498')
snapshot = (PLAN / "root-chat-snapshot-check.py").read_text(encoding="utf-8-sig")
snapshot = snapshot.replace("root-chat-", "root-shape-").replace(version_old, version_new)
needle = '            assert user["task"].startswith(body["messages"][0]["content"])\n'
assert snapshot.count(needle) == 1
snapshot = snapshot.replace(needle, needle + '            for phrase in ["two top-level keys: atom and measurement", "inside atom", "sibling of atom", "Do not flatten"]:\n                assert phrase in user["task"]\n')
live = (PLAN / "root-live-third.py").read_text(encoding="utf-8-sig")
live = live.replace("One specifically justified v3 Chat real verification", "One specifically justified v4 nested-atom Chat real verification")
live = live.replace(version_old, version_new).replace("api-live-03", "api-live-04")
live = live.replace("root-chat-", "root-shape-").replace("-03.json", "-04.json")
live = live.replace('== 10619', '== 15531').replace('== 9989381', '== 9984469').replace('["model_attempts"] == 2', '["model_attempts"] == 3')
live = live.replace('len(ledger["records"]) == 2', 'len(ledger["records"]) == 3').replace('== [936, 9683]', '== [936, 9683, 4912]')
live = live.replace("One documented Chat v3 verification after two Responses failures, explicit disabled-thinking protocol, RED/GREEN, cache consistency closure and final regressions", "One documented Chat v4 verification after complete but flattened third response; nested atom task RED/GREEN, fresh review and final regressions; same source/gold and cumulative budget")
needle = 'assert sha((LIVE / "api-live-02/response.bin").read_bytes()) == "f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a"\n'
assert live.count(needle) == 1
third_guard = 'assert sha((LIVE / "api-live-03/response.bin").read_bytes()) == "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b"\n'
live = live.replace(needle, needle + third_guard)
live = live.replace('"preserved_responses_config_unchanged":', '"third_response_unchanged": sha((LIVE / "api-live-03/response.bin").read_bytes()) == "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b", "preserved_responses_config_unchanged":')
live += '\nassert sha((LIVE / "api-live-03/response.bin").read_bytes()) == "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b"\n'
records = []
for name, source in [("root-shape-workspace-checks.py", workspace), ("root-shape-snapshot-check.py", snapshot), ("root-live-fourth.py", live)]:
    ast.parse(source)
    raw = source.encode("utf-8")
    write_new(PLAN / name, raw)
    records.append({"path": name, "sha256": sha(raw), "byte_length": len(raw), "syntax_validated": True})
write_new(PLAN / "root-shape-driver-preparation.json", (json.dumps({"records": records, "model_calls": 0, "ledger_mutations": 0}, indent=2) + "\n").encode())
print(json.dumps({"drivers_prepared": len(records), "worker_patch_fingerprints_validated": len(fingerprints["files"]), "model_calls": 0, "ledger_mutations": 0}))
