"""Independent local matrices bound to the final v4 workspace executable."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ("api", "fake", "chat")
binary = ROOT / "target/debug/noetome.exe"
summary = json.loads((PLAN / "root-shape-workspace-summary.json").read_text(encoding="utf-8-sig"))
expected_hash = summary["binary_sha256"]
assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_hash
script = ROOT / "scripts" / {"api": "validate_extraction_api.py", "fake": "validate_extraction_gateway.py", "chat": "validate_extraction_chat.py"}[mode]
output = PLAN / ("root-shape-final-" + mode)
record_file = output.with_name(output.name + "-command.json")
assert not output.exists() and not record_file.exists()
argv = [sys.executable, "-X", "utf8", str(script), "--binary", str(binary), "--root", str(output)]
env = dict(os.environ)
env["NOETOME_PDF_PYTHON"] = env["NOETOME_TEST_PYTHON"] = sys.executable
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
record = {"command": argv, "started_at": started, "elapsed_seconds": time.monotonic() - clock, "exit_code": run.returncode,
          "stdout": run.stdout.decode("utf-8"), "stderr": run.stderr.decode("utf-8"),
          "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
          "binary_sha256": expected_hash, "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(), "model_calls": 0}
record_file.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert run.returncode == 0, record
audit = json.loads((output / ("evidence.json" if mode == "fake" else "audit.json")).read_text(encoding="utf-8-sig"))
assert len(audit["checks"]) == {"api": 84, "fake": 54, "chat": 34}[mode]
assert len(audit["calls"]) == {"api": 90, "fake": 60, "chat": 36}[mode]
assert audit["binary_sha256"] == expected_hash == hashlib.sha256(binary.read_bytes()).hexdigest()
print(json.dumps({"matrix": mode, "checks": len(audit["checks"]), "cli_calls": len(audit["calls"]),
                  "exit_code": 0, "binary_sha256": expected_hash, "evidence": str(record_file)}))
