"""Retain the completed read-only review and controller index guard."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
records = []
for path in sorted(PLAN.glob("shape-review*")):
    raw = path.read_bytes()
    if path.suffix == ".py":
        target = ASSETS / "B04-T02-shape-review-source.json"
        value = {"source": path.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw), "source_text": raw.decode("utf-8-sig")}
        content = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    else:
        assert path.suffix in (".md", ".json")
        target, content = ASSETS / ("B04-T02-" + path.name), raw
    assert not target.exists(), target
    with target.open("xb") as handle:
        handle.write(content)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(content).hexdigest(), "byte_length": len(content)})
for name in ["root-shape-stage-first-command.json", "root-shape-stage-check.json", "root-shape-driver-preparation.json"]:
    raw = (PLAN / name).read_bytes()
    target = ASSETS / ("B04-T02-" + name.removeprefix("root-"))
    assert not target.exists()
    with target.open("xb") as handle:
        handle.write(raw)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)})
evidence = json.loads((PLAN / "shape-review-evidence.json").read_text(encoding="utf-8-sig"))
print(json.dumps({"archived_review_and_guard_files": len(records), "spec": evidence.get("spec"), "quality": evidence.get("quality"), "model_calls": 0}))
