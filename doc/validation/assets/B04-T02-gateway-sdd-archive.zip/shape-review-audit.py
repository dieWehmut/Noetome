"""Bounded read-only nested-atom fix review; no suites, HTTP, Git or private reads.

Checks only the immutable package, named component evidence and explicitly
archived author/synthetic files. ZIP contents are inspected without extraction.
"""
from pathlib import Path
import hashlib
import io
import json
import re
import zipfile

ROOT = Path('D:/Noetome')
PLAN = ROOT / '.superpowers/sdd/B04-T02_GATEWAY_PLAN'
ASSETS = ROOT / 'doc/validation/assets'
checks, fingerprints = [], {}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    path = Path(path)
    assert path.is_relative_to(ROOT)
    assert path.name != 'tasks.json'  # active external files are never followed
    raw = path.read_bytes()
    fingerprints[str(path.relative_to(ROOT)).replace('\\', '/')] = {'sha256': digest(raw), 'bytes': len(raw)}
    return raw

def load(path):
    return json.loads(read(path).decode('utf-8-sig'))

def check(name, passed):
    checks.append({'name': name, 'passed': bool(passed)})
    if not passed:
        raise AssertionError(name)

package = read(PLAN / 'review-94b0ebb..25bcff5.diff').decode()
sections = {}
for part in re.split(r'^diff --git ', package, flags=re.M)[1:]:
    match = re.match(r'a/(.*?) b/', part)
    sections[match[1]] = part
source_paths = [p for p in sections if p.startswith(('crates/', 'scripts/'))]
check('exact source fix scope', set(source_paths) == {
    'crates/noetome-cli/src/extraction_api_config.rs', 'crates/noetome-cli/src/extraction_api_schema.rs',
    'crates/noetome-cli/src/extraction_api_wire/chat.rs', 'crates/noetome-cli/tests/extraction_api.rs',
    'scripts/validate_extraction_chat.py'})
wire_part = sections['crates/noetome-cli/src/extraction_api_wire/chat.rs']
wire_added = '\n'.join(x[1:] for x in wire_part.splitlines() if x.startswith('+') and not x.startswith('+++'))
wire_removed = [x for x in wire_part.splitlines() if x.startswith('-') and not x.startswith('---')]
check('Chat wire patch adds only original-response regression', not wire_removed and
      'shape_fix_original_third_flattened_candidate_stays_rejected_with_usage' in wire_added and
      'fn decode' not in wire_added and 'fn chat_metadata' not in wire_added)
check('no SDK/DTO/schema/cache/CLI interface change in package',
      not any(p.endswith(('Cargo.toml', 'Cargo.lock', '/lib.rs', 'extraction_model.rs', 'extraction_api_wire.rs')) for p in sections))

artifacts = load(PLAN / 'shape-fix-artifacts.json')
for relative, expected in artifacts['files'].items():
    raw = read(ROOT / relative)
    check('component/evidence fingerprint: ' + relative, digest(raw) == expected['sha256'] and len(raw) == expected['bytes'])
patch = load(ASSETS / 'B04-T02-shape-fix-source-patch.json')
check('committed source patch equals retained actual patch',
      patch['patch'].encode() == read(PLAN / 'shape-fix-source.patch') and
      digest(patch['patch'].encode()) == patch['sha256'] and len(patch['patch'].encode()) == patch['byte_length'])

results = {}
for name, code, summary in [
    ('shape-fix-native-red.json', 1, '0 passed; 1 failed'),
    ('root-shape-cli-red.json', 101, '0 passed; 2 failed'),
    ('shape-fix-native-green.json', 0, '37 passed; 0 failed'),
    ('shape-fix-cli-green.json', 0, '7 passed; 0 failed'),
    ('shape-fix-fake-green.json', 0, '3 passed; 0 failed'),
    ('shape-fix-check.json', 0, None), ('shape-fix-owned-fmt.json', 0, None), ('shape-fix-diff-check.json', 0, None),
]:
    row = load(PLAN / name)
    output = row.get('output', '') + row.get('stdout', '') + row.get('stderr', '')
    check('retained actual result: ' + name, row['exit_code'] == code and (summary is None or summary in output))
    if name.endswith('red.json'):
        check('RED specifically lacks shape phrase: ' + name, 'two top-level keys: atom and measurement' in output)
    if 'green' in name or name == 'shape-fix-check.json':
        check('no Rust warning: ' + name, 'warning:' not in output)
    results[name] = {'exit_code': row['exit_code'], 'summary': summary}

prototype = load(ASSETS / 'B04-T02-shape-prototype-chat-audit.json')
prototype_command = load(ASSETS / 'B04-T02-shape-prototype-chat-command.json')
check('v4 independent prototype 34/36/28 and no paid calls',
      len(prototype['checks']) == 34 and len(prototype['calls']) == 36
      and sum(r['local_post_count'] for r in prototype['checks']) == 28
      and all(r['passed'] for r in prototype['checks']) and prototype['real_model_calls'] == prototype['paid_calls'] == 0
      and prototype_command['exit_code'] == 0 and prototype['binary_sha256'] == prototype_command['binary_sha256'])
check('v4 prototype script fingerprint', digest(read(ROOT / 'scripts/validate_extraction_chat.py')) == prototype_command['script_sha256'])
py = load(ASSETS / 'B04-T02-shape-python-tests.json')
check('retained current Python76', py['exit_code'] == 0 and 'Ran 76 tests' in py['stderr'] and 'OK' in py['stderr'])

raw_third = read(ASSETS / 'B04-T02-live-third-response.bin')
wire = json.loads(raw_third)
report = load(ASSETS / 'B04-T02-live-third-validation.json')
command = load(ASSETS / 'B04-T02-live-third-command.json')
request = load(ASSETS / 'B04-T02-live-third-request.json')
body = load(ASSETS / 'B04-T02-live-third-request-body.json')
user = json.loads(body['messages'][1]['content'])
choice = wire['choices'][0]
candidate = json.loads(choice['message']['content'])
check('original third response exact fingerprint', digest(raw_third) == '6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b')
check('original third is complete stopped JSON, flattened atom remains',
      len(wire['choices']) == 1 and choice['finish_reason'] == 'stop' and choice['message']['role'] == 'assistant'
      and 'atom_id' in candidate['atoms'][0] and 'atom' not in candidate['atoms'][0]
      and set(user['response_schema']['properties']['atoms']['items']['properties']) == {'atom', 'measurement'})
atom_fields = set(user['response_schema']['properties']['atoms']['items']['properties']['atom']['properties'])
schema_part = sections['crates/noetome-cli/src/extraction_api_schema.rs']
hint_fields = re.search(r'all ten Atom fields (.*?) inside atom', schema_part)[1].split(', ')
check('new generic Atom field list agrees with original generated schema', len(hint_fields) == 10 and set(hint_fields) == atom_fields)
atom_schema = user['response_schema']['properties']['atoms']['items']['properties']['atom']['properties']
check('original statement/not_applicable values remain legal schema enums',
      all(atom['kind'] in atom_schema['kind']['enum'] and atom['value_status'] in atom_schema['value_status']['enum'] for atom in candidate['atoms']))
check('new task hint has no fixed gold values or filled candidate template',
      '10 m/s' not in schema_part and '20 ℃' not in schema_part and '样例 A' not in schema_part)
check('third usage raw and normalized/report/command reconcile',
      wire['usage'] == report['usage']['raw_model_usage'] and wire['usage']['prompt_tokens'] == 1583
      and wire['usage']['completion_tokens'] == 3329 and wire['usage']['total_tokens'] == 4912
      and report['usage']['model_usage'] == {'input_tokens': 1583, 'output_tokens': 3329, 'total_tokens': 4912}
      and json.loads(command['stdout']) == report and command['exit_code'] == 3
      and report['errors'][0]['code'] == 'EXTRACT_API_CANDIDATES' and report['status'] == 'failed'
      and report['published'] is False and report['validated_atoms'] == 0)
for name, original_name in [('request-body', 'request-body.json'), ('request', 'request.json'), ('response', 'response.bin')]:
    raw = read(ASSETS / ('B04-T02-live-third-' + name + ('.bin' if name == 'response' else '.json')))
    check('third archived artifact: ' + name, digest(raw) == report['artifacts'][original_name]['sha256'] and len(raw) == report['artifacts'][original_name]['byte_length'])
check('third request preserved v3 exact body keys/binding/reservation',
      set(body) == {'model', 'messages', 'thinking', 'response_format', 'max_tokens', 'stream'}
      and set(user) == {'task', 'response_schema', 'request'} and user['request']['binding'] == report['binding'] == request['binding']
      and report['usage']['input_reserved_tokens'] == len(read(ASSETS / 'B04-T02-live-third-request-body.json')) + 1024
      and report['request_strategy'] == 'tangmao-deepseek-chat-json-object-no-thinking-v3')
reasoning_bytes = len(choice['message'].get('reasoning_content', '').encode())
check('actual reasoning remains visible without switch compliance inference', reasoning_bytes == 10305)

manifest = load(ASSETS / 'B04-T02-chat-final-archive.json')
check('v3 archive explicitly historical 127/89 with18 records',
      manifest['historical_strategy'] == 'tangmao-deepseek-chat-json-object-no-thinking-v3'
      and manifest['report_pairs'] == 127 and manifest['request_records'] == 89 and len(manifest['records']) == 18)
for row in manifest['records']:
    raw = read(ROOT / row['path'])
    check('v3 manifest fingerprint: ' + row['path'], digest(raw) == row['sha256'] and len(raw) == row['byte_length'])
workspace = load(ASSETS / 'B04-T02-chat-final-workspace-summary.json')
check('historical v3 whole workspace497 belongs to third-call program only',
      workspace['records'][-1]['passed'] == 497 and workspace['records'][-1]['failed'] == 0
      and workspace['binary_sha256'] == manifest['binary_sha256'] == command['binary_sha256']
      == '07536109b727bb199213cb9f05a53988e1791de4d54f0b9ba4c1e4a6c4a78506'
      and prototype['binary_sha256'] != manifest['binary_sha256'])

snapshot = load(ASSETS / 'B04-T02-chat-final-snapshot-verification.json')
zip_raw = read(ASSETS / 'B04-T02-chat-final-reports.zip')
with zipfile.ZipFile(io.BytesIO(zip_raw)) as z:
    entries = z.namelist()
    check('ZIP exactly710 unique original files', len(entries) == len(set(entries)) == 710)
    approved_prefixes = ['.superpowers/sdd/B04-T02_GATEWAY_PLAN/' + name + '/' for name in
                         ['root-chat-final-api', 'root-chat-final-fake', 'root-chat-final-chat', 'root-chat-selected-zero']]
    for name in entries:
        check('ZIP original byte equality: ' + name,
              any(name.startswith(prefix) for prefix in approved_prefixes)
              and '..' not in Path(name).parts and z.read(name) == read(ROOT / name))
    check('v3 snapshot cardinalities match archive', len(snapshot['reports']) == 127 and len(snapshot['requests']) == 89)
    for row in snapshot['reports']:
        raw_json = z.read(row['path'])
        raw_md = z.read(row['path'].replace('validation.json', 'validation.md'))
        blocks = re.findall(r'```json\s*\n(.*?)\n```', raw_md.decode(), re.S)
        check('archived JSON/Markdown snapshot equivalence: ' + row['path'],
              digest(raw_json) == row['json_sha256'] and digest(raw_md) == row['markdown_sha256']
              and any(json.loads(block) == json.loads(raw_json) for block in blocks))
    for row in snapshot['requests']:
        folder = str(Path(row['path']).parent).replace('\\', '/')
        raw_body = z.read(folder + '/request-body.json')
        raw_request = z.read(folder + '/request.json')
        check('archived request fingerprint/strategy: ' + row['path'],
              digest(raw_body) == row['body_sha256'] and digest(raw_request) == row['request_sha256']
              and json.loads(raw_request)['request_strategy'] == row['strategy'])

stage = load(PLAN / 'root-shape-stage-check.json')
first_stage = load(PLAN / 'root-shape-stage-first-command.json')
check('retained failed staging guard is preserved', first_stage['exit_code'] == 1 and 'archive line endings or bytes changed in index' in first_stage['output'])
check('retained successful staging guard71/57/18 and user deletions',
      stage['staged_files'] == 71 and stage['exact_archive_files'] == len(stage['files']) == 57
      and stage['archive_manifest_records_verified'] == 18 and stage['unrelated_docs_deletions_unstaged'] is True)
stage_fingerprints_verified = 0
immutable_text_fingerprints_verified = 0
for row in stage['files']:
    raw = read(ROOT / row['path'])
    check('retained staged archive current fingerprint: ' + row['path'], digest(raw) == row['sha256'] and len(raw) == row['byte_length'])
    stage_fingerprints_verified += 1
    part = sections.get(row['path'], '')
    if 'new file mode ' in part and not row['path'].endswith(('.bin', '.zip')):
        content = [line[1:] for line in part.splitlines() if line.startswith('+') and not line.startswith('+++')]
        variants = [(ending.join(content) + suffix).encode() for ending in ['\n', '\r\n'] for suffix in ['', ending]]
        check('immutable package reconstructs archive bytes: ' + row['path'], raw in variants)
        immutable_text_fingerprints_verified += 1
check('scoped .gitattributes preserves JSON archives and binary originals',
      '+doc/validation/assets/B04-T02-shape-*.json -text' in sections['.gitattributes']
      and '+doc/validation/assets/B04-T02-live-third-response.bin binary' in sections['.gitattributes']
      and '+doc/validation/assets/B04-T02-chat-final-reports.zip binary' in sections['.gitattributes'])

capture = load(ROOT / 'target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556/source-before.json')
after = load(ASSETS / 'B04-T02-live-third-after.json')
check('third source fingerprints agree with before-call and historical snapshot', capture['project_files'] == after['source_files'] == snapshot['source_files'])
for name, expected in capture['project_files'].items():
    path = Path(capture['project']) / name
    raw = read(path)
    check('selected fixed source bytes/mtime: ' + name,
          digest(raw) == expected['sha256'] and len(raw) == expected['byte_length'] and path.stat().st_mtime_ns == expected['mtime_ns'])
gold = read(ROOT / 'fixtures/extraction-gateway-v1/expected.json')
check('author gold fixed before calls', digest(gold) == capture['gold_sha256'] == snapshot['gold_sha256'])
first = load(ASSETS / 'B04-T02-live-first-validation.json')
second = load(ASSETS / 'B04-T02-live-second-validation.json')
totals = [row['usage']['model_usage']['total_tokens'] for row in [first, second, report]]
check('observed cumulative usage and remaining arithmetic', totals == [936, 9683, 4912] and sum(totals) == 15531 and 10000000 - sum(totals) == 9984469)
settlement = load(ASSETS / 'B04-T02-live-third-settlement.json')['ledger_after_settlement']
reservation = load(ASSETS / 'B04-T02-live-third-reservation.json')
activation = load(ASSETS / 'B04-T02-chat-profile-activation.json')
config_before = load(ASSETS / 'B04-T02-chat-config-before.json')
check('authorized archived settlement reconciles cumulative/pending/attempts',
      settlement['accounted_tokens'] == sum(totals) and settlement['remaining_tokens'] == 9984469
      and settlement['pending_reserved_tokens'] == 0 and settlement['model_attempts'] == 3
      and settlement['records'][-1]['confirmed_total_tokens'] == 4912)
check('authorized archived reservation is same historical program', reservation['binary_sha256'] == command['binary_sha256'])
previous_profile, current_profile = activation['previous_profile'], activation['current_profile']
check('archived profile transition preserves origin/model/credential/budget without private reads',
      activation['same_credential_reference'] is True and activation['same_model_and_cumulative_budget'] is True
      and activation['credential_read'] is False and activation['network_model_calls'] == 0
      and all(previous_profile[k] == current_profile[k] for k in ['base_url', 'model', 'credential_file', 'credential_env', 'approved_total_tokens'])
      and current_profile['interface'] == 'openai_chat_completions' and current_profile['endpoint'] == report['endpoint'])
check('archived Chat configuration retains author-gold before third call', config_before['author_gold_unchanged'] == digest(gold) and config_before['model_calls_before_capture'] == 2)
for ordinal, expected in [('first', '73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b'),
                          ('second', 'f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a')]:
    check('older actual response remains original: ' + ordinal, digest(read(ASSETS / ('B04-T02-live-' + ordinal + '-response.bin'))) == expected)

evidence = {'schema_version': 1, 'base': '94b0ebb40bb43cb5cdb72d924a40cf2d0893fa10', 'head': '25bcff5b474611fdb2b1c1f96eb0a33caae42e4d',
            'spec': 'PASS', 'quality': 'PASS', 'findings': [], 'checks': checks, 'check_count': len(checks),
            'fingerprints': fingerprints, 'fingerprint_count': len(fingerprints), 'retained_results': results,
            'historical_v3_binary': manifest['binary_sha256'], 'v4_prototype_binary': prototype['binary_sha256'],
            'archive': {'files_verified': 710, 'report_pairs_verified': 127, 'requests_verified': 89, 'manifest_verified': 18},
            'retained_staging_guard': {'staged_files': 71, 'index_equalities': 57,
                                      'reviewer_current_fingerprints': stage_fingerprints_verified,
                                      'immutable_text_reconstructions': immutable_text_fingerprints_verified},
            'observed_usage': {'totals': totals, 'cumulative': sum(totals), 'remaining_arithmetic': 10000000-sum(totals),
                               'pending_reserved_tokens_in_archive': settlement['pending_reserved_tokens'],
                               'authorized_repo_settlement_snapshot_read': True, 'active_ledger_read': False},
            'reviewer_suites_builds_cli_network_model_credential_profile_ledger_reads': 0,
            'limits': ['No tests/builds/ordinary CLI/Git/index actions were executed.',
                       'The staged index equalities/user deletions are retained evidence; current index was not inspected.',
                       'Only explicitly authorized non-secret repo ledger/profile snapshots were read; active external files were never followed.',
                       'Historical v3 workspace497 and prototype v4 evidence are not current final v4 acceptance.',
                       'Final v4 workspace expected498 and the fourth bounded actual request remain unverified.']}
(PLAN / 'shape-review-evidence.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'spec': 'PASS', 'quality': 'PASS', 'checks_passed': len(checks), 'fingerprints': len(fingerprints),
                  'archive_files': 710, 'pairs': 127, 'requests': 89, 'reviewer_suites_builds_network_private_reads': 0}))
