"""Final fmt/check/workspace tests and exact source/binary binding for v6."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
PWSH = sys.argv[1]
FILES = ["crates/noetome-cli/src/extraction_api_config.rs", "crates/noetome-cli/src/extraction_api_schema.rs", "crates/noetome-cli/src/extraction_api_wire/chat.rs", "crates/noetome-cli/tests/extraction_api.rs", "scripts/validate_extraction_chat.py"]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def source_hashes():
    return {name: sha((ROOT / name).read_bytes()) for name in FILES}

def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")

summary_path = PLAN / "root-revision-workspace-summary.json"
assert not summary_path.exists()
before = source_hashes()
env = dict(os.environ)
env["NOETOME_PDF_PYTHON"] = env["NOETOME_TEST_PYTHON"] = sys.executable
env["CARGO_TERM_COLOR"] = "never"
records = []
commands = [("fmt", "& .\\scripts\\cargo_local.ps1 fmt --all --check; exit $LASTEXITCODE"),
            ("check", "& .\\scripts\\cargo_local.ps1 check --workspace --locked --offline; exit $LASTEXITCODE"),
            ("workspace-tests", "& .\\scripts\\cargo_local.ps1 test --workspace --locked --offline '--' --test-threads=4; exit $LASTEXITCODE")]
for name, command in commands:
    path = PLAN / ("root-revision-" + name + ".json")
    assert not path.exists()
    argv = [PWSH, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
    stdout, stderr = run.stdout.decode("utf-8"), run.stderr.decode("utf-8")
    record = {"command": argv, "started_at": started, "elapsed_seconds": time.monotonic() - clock, "exit_code": run.returncode,
              "stdout": stdout, "stderr": stderr, "stdout_sha256": sha(run.stdout), "stderr_sha256": sha(run.stderr), "model_calls": 0}
    if name == "workspace-tests":
        rows = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored", stdout + stderr)
        assert rows
        record["passed"] = sum(int(r[0]) for r in rows)
        record["failed"] = sum(int(r[1]) for r in rows)
        record["ignored"] = sum(int(r[2]) for r in rows)
    save(path, record)
    records.append({"name": name, "path": path.relative_to(ROOT).as_posix(), "sha256": sha(path.read_bytes()),
                    "exit_code": run.returncode, **{k: record[k] for k in ["passed", "failed", "ignored"] if k in record}})
    assert run.returncode == 0, record
assert source_hashes() == before
assert records[-1]["failed"] == records[-1]["ignored"] == 0
binary = ROOT / "target/debug/noetome.exe"
head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, check=True).stdout.decode().strip()
summary = {"captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source_commit": head,
           "source_sha256": before, "request_strategy": "tangmao-deepseek-chat-positive-revision-v6",
           "binary_sha256": sha(binary.read_bytes()), "binary_byte_length": binary.stat().st_size, "records": records,
           "model_calls": 0, "paid_calls": 0, "source_unchanged_during_checks": True}
save(summary_path, summary)
print(json.dumps({"passed": records[-1]["passed"], "failed": 0, "ignored": 0, "binary_sha256": summary["binary_sha256"], "source_commit": head}))
