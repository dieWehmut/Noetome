"""Prepare distinct v6 final verification scripts and one actual06 controller."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent

def write_new(name, source):
    ast.parse(source)
    path = PLAN / name
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(source)
    return {"path": path.relative_to(ROOT).as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}

records = []
source = (PLAN / "root-qualifier-final-matrix.py").read_text(encoding="utf-8")
source = source.replace("root-qualifier", "root-revision").replace("final v5", "final v6")
source = source.replace('"chat": 35', '"chat": 37').replace('"chat": 37}[mode]', '"chat": 39}[mode]')
# The first replacement also touches the checks dictionary; replace the two
# complete assertions explicitly to retain distinct check/call counts.
source = source.replace('assert len(audit["checks"]) == {"api": 84, "fake": 54, "chat": 39}[mode]',
                        'assert len(audit["checks"]) == {"api": 84, "fake": 54, "chat": 37}[mode]')
records.append(write_new("root-revision-final-matrix.py", source))

source = (PLAN / "root-qualifier-snapshot-check-v2.py").read_text(encoding="utf-8")
source = source.replace("root-qualifier", "root-revision").replace("tangmao-deepseek-chat-qualifiers-v5", "tangmao-deepseek-chat-positive-revision-v6")
source = source.replace('("chat", 35, 37)', '("chat", 37, 39)').replace('"chat": 30', '"chat": 32')
source = source.replace('len(reports) == 128 and len(requests) == 90', 'len(reports) == 130 and len(requests) == 92')
needle = '            assert user["response_schema"]["additionalProperties"] is False\n'
assert source.count(needle) == 1
source = source.replace(needle, needle + '''            for phrase in ["Include measurement.unit verbatim in atom.qualifiers", "Include every measurement.conditions string verbatim in atom.qualifiers", "Every concept.revision and atom.revision must be a positive integer"]:
                assert phrase in user["task"]
            for revision in [user["response_schema"]["properties"]["concepts"]["items"]["properties"]["revision"], user["response_schema"]["properties"]["atoms"]["items"]["properties"]["atom"]["properties"]["revision"]]:
                assert revision == {"type": "integer", "minimum": 1}
''')
records.append(write_new("root-revision-snapshot-check.py", source))

source = (PLAN / "root-live-fifth.py").read_text(encoding="utf-8")
source = source.replace("actual05", "actual06").replace("api-live-05", "api-live-06").replace("-05.json", "-06.json")
source = source.replace("root-qualifier", "root-revision").replace("tangmao-deepseek-chat-qualifiers-v5", "tangmao-deepseek-chat-positive-revision-v6")
source = source.replace('len(verified["reports"]) == 128', 'len(verified["reports"]) == 130')
source = source.replace('== 20314', '== 23793').replace('== 9979686', '== 9976207')
source = source.replace('ledger["model_attempts"] == 4', 'ledger["model_attempts"] == 5')
source = source.replace('len(ledger["records"]) == 4', 'len(ledger["records"]) == 5')
source = source.replace('[936, 9683, 4912, 4783]', '[936, 9683, 4912, 4783, 3479]')
source = source.replace('One specifically justified v5 qualifier-contract Chat real verification', 'One specifically justified v6 positive-revision Chat real verification')
source = source.replace('One documented Chat v5 verification after nested fourth response omitted unit qualifier; generic cross-field task RED/GREEN, fresh review and final same-source regressions; same source/gold and cumulative budget',
                        'One documented Chat v6 verification after fifth response used four revision=0 entities; positive inline Schema/task RED/GREEN, fresh review and final same-source regressions; same source/gold and cumulative budget')
needle = 'assert sha((LIVE / "api-live-04/response.bin").read_bytes()) == "a6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9"'
assert source.count(needle) == 2
source = source.replace(needle, needle + '\nassert sha((LIVE / "api-live-05/response.bin").read_bytes()) == "b04c99ff593ee99431f140747a5c088cf4011a1a87237981e03cd176feb07f8f"')
records.append(write_new("root-live-sixth.py", source))

source = (PLAN / "root-qualifier-final-archive.py").read_text(encoding="utf-8")
source = source.replace("root-qualifier", "root-revision").replace("qualifier-", "revision-")
source = source.replace("root-revision-resume.py", "root-revision-workspace.py").replace("root-revision-snapshot-check-v2.py", "root-revision-snapshot-check.py")
source = source.replace("root-live-fifth.py", "root-live-sixth.py").replace("live-fifth-controller", "live-sixth-controller")
source = source.replace('== 499', '== 502').replace('== 128', '== 130').replace('== 90', '== 92')
source = source.replace('"report_pairs": 128', '"report_pairs": 130').replace('"request_records": 90', '"request_records": 92')
source = source.replace('"tangmao-deepseek-chat-qualifiers-v5"', '"tangmao-deepseek-chat-positive-revision-v6"')
source = source.replace('Archive the already completed v3 validation and original third-call provenance.', 'Archive the completed v6 validation and preserve prior original call provenance.')
records.append(write_new("root-revision-final-archive.py", source))
path = PLAN / "root-revision-prepared-scripts.json"
with path.open("x", encoding="utf-8", newline="\n") as handle:
    json.dump({"records": records, "actual_model_calls": 0, "actual06_prepared_only": True}, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps({"prepared_scripts": len(records), "actual_model_calls": 0, "actual06_prepared_only": True}))
