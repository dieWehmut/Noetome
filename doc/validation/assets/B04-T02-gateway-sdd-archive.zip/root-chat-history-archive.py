"""Archive the already completed v3 validation and original third-call provenance."""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
EXPECTED_BINARY = "07536109b727bb199213cb9f05a53988e1791de4d54f0b9ba4c1e4a6c4a78506"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_bytes(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        with path.open("xb") as handle:
            handle.write(raw)

summary = read(PLAN / "root-chat-workspace-summary.json")
snapshot = read(PLAN / "root-chat-snapshot-verification.json")
assert summary["binary_sha256"] == snapshot["binary_sha256"] == EXPECTED_BINARY
assert summary["records"][-1]["passed"] == 497
assert len(snapshot["reports"]) == 127 and len(snapshot["requests"]) == 89
assert snapshot["source_original_capture_unchanged"]
mappings = {
    "root-chat-workspace-tests.json": "chat-final-workspace-tests.json",
    "root-chat-workspace-summary.json": "chat-final-workspace-summary.json",
    "root-chat-fmt.json": "chat-final-fmt.json",
    "root-chat-check.json": "chat-final-check.json",
    "root-chat-final-api-command.json": "chat-final-api-command.json",
    "root-chat-final-fake-command.json": "chat-final-fake-command.json",
    "root-chat-final-chat-command.json": "chat-final-chat-command.json",
    "root-chat-final-api/audit.json": "chat-final-api-audit.json",
    "root-chat-final-fake/evidence.json": "chat-final-fake-audit.json",
    "root-chat-final-chat/audit.json": "chat-final-chat-audit.json",
    "root-chat-selected-zero-command.json": "chat-final-selected-zero-command.json",
    "root-chat-snapshot-verification.json": "chat-final-snapshot-verification.json",
    "root-shape-cli-red.json": "shape-cli-red.json",
}
records = []
for source, name in mappings.items():
    path, target = PLAN / source, ASSETS / ("B04-T02-" + name)
    raw = path.read_bytes()
    if name.endswith("-audit.json"):
        assert read(path)["binary_sha256"] == EXPECTED_BINARY
    save_bytes(target, raw)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw)})
for source, name in [
    ("root-chat-workspace-checks.py", "chat-final-workspace-source.json"),
    ("root-chat-snapshot-check.py", "chat-final-snapshot-source.json"),
    ("root-live-third.py", "live-third-controller-source.json"),
    ("root-shape-cli-red.py", "shape-cli-red-source.json"),
]:
    path = PLAN / source
    raw = path.read_bytes()
    value = {"source": path.relative_to(ROOT).as_posix(), "source_sha256": sha(raw), "byte_length": len(raw), "source_text": raw.decode("utf-8-sig")}
    output = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    target = ASSETS / ("B04-T02-" + name)
    save_bytes(target, output)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(output), "byte_length": len(output)})

files = {}
for item in snapshot["reports"]:
    path = (ROOT / item["path"]).resolve()
    assert path.is_relative_to(PLAN)
    raw, md = path.read_bytes(), path.with_suffix(".md").read_bytes()
    assert sha(raw) == item["json_sha256"] and sha(md) == item["markdown_sha256"]
    files[path] = raw
    files[path.with_suffix(".md")] = md
    for name, fingerprint in json.loads(raw)["artifacts"].items():
        artifact = (path.parent / name).resolve()
        assert artifact.parent == path.parent
        content = artifact.read_bytes()
        assert sha(content) == fingerprint["sha256"] and len(content) == fingerprint["byte_length"]
        files[artifact] = content
archive = ASSETS / "B04-T02-chat-final-reports.zip"
assert not archive.exists(), archive
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path, raw in sorted(files.items()):
        info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(2026, 11, 3, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        handle.writestr(info, raw)
with zipfile.ZipFile(archive) as handle:
    assert len(handle.namelist()) == len(files)
    for path, raw in files.items():
        assert handle.read(path.relative_to(ROOT).as_posix()) == raw
records.append({"path": archive.relative_to(ROOT).as_posix(), "sha256": sha(archive.read_bytes()), "byte_length": archive.stat().st_size, "files": len(files)})
manifest = {"captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "binary_sha256": EXPECTED_BINARY,
            "historical_strategy": "tangmao-deepseek-chat-json-object-no-thinking-v3", "report_pairs": 127,
            "request_records": 89, "records": records, "actual_model_call_in_archive_step": 0}
save_bytes(ASSETS / "B04-T02-chat-final-archive.json", (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"archived_records": len(records), "report_pairs": 127, "request_records": 89,
                  "report_archive_files": len(files), "binary_sha256": EXPECTED_BINARY}))
