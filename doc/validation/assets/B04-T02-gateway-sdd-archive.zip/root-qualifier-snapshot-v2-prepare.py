import hashlib
import json
from pathlib import Path

plan=Path(__file__).resolve().parent
original=(plan/'root-qualifier-snapshot-check.py').read_bytes()
record={'command':['python','root-qualifier-snapshot-check.py'],'exit_code':1,
        'original_script_sha256':hashlib.sha256(original).hexdigest(),
        'failure':'AssertionError at line116: dict(counts) expected chat29 from v4; current v5 adds the missing-unit scene and has chat30. Existing API59/fake38/chat30/selected-zero1 reports remain unchanged.',
        'actual_model_calls':0,'selected_zero_preflight_created':True}
(plan/'root-qualifier-snapshot-first-failure.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
text=original.decode('utf-8').replace('"chat": 29','"chat": 30')
start=text.index('assert not zero.exists()')
end=text.index('assert result.returncode == 3',start)
text=text[:start]+'''argv = [str(binary), "extract", "api", str(project), before["import_id"], str(config), str(zero)]
command_path = OUT / "root-qualifier-selected-zero-command.json"
if zero.exists():
    previous = read(command_path)
    assert previous["command"] == argv and previous["exit_code"] == 3
    assert previous["binary_sha256"] == summary["binary_sha256"]
    result_code = previous["exit_code"]
else:
    env = dict(os.environ)
    env["NOETOME_TANGMAO_API_KEY"] = "noetome-test-selected-chat-zero-budget"
    result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
    save(command_path, {"command": argv, "exit_code": result.returncode, "stdout": result.stdout.decode("utf-8"), "stderr": result.stderr.decode("utf-8"), "binary_sha256": summary["binary_sha256"]})
    result_code = result.returncode
'''+text[end:]
text=text.replace('assert result.returncode == 3','assert result_code == 3')
(plan/'root-qualifier-snapshot-check-v2.py').write_bytes(text.encode())
print('Original count failure preserved; v2 reuses unchanged zero-call report and checks v5 chat30.')
