"""Recoverable top-level SDD plans/scripts/reviews; report roots have their ZIPs.

This archive preserves files without deleting or moving any workspace.
"""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
assert (PLAN / "gateway-final-review.md").is_file()
archive = ASSETS / "B04-T02-gateway-sdd-archive.zip"
manifest = ASSETS / "B04-T02-gateway-sdd-archive.json"
assert not archive.exists() and not manifest.exists()
extensions = {".md", ".py", ".json", ".patch", ".diff", ".ps1", ".txt"}
files = {p.name: p.read_bytes() for p in sorted(PLAN.iterdir()) if p.is_file() and p.suffix in extensions and not p.is_symlink()}
assert "gateway-final-review.md" in files and "progress.md" in files
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for name, raw in files.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        handle.writestr(info, raw)
with zipfile.ZipFile(archive) as handle:
    assert set(handle.namelist()) == set(files)
    assert all(handle.read(name) == raw for name, raw in files.items())
rulings = [line for line in files["progress.md"].decode("utf-8-sig").splitlines() if "Ruling:" in line]
value = {"scope": "top-level plan/scripts/reviews only; current728/older716/710 report artifacts have separate committed ZIPs",
         "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "archive_byte_length": archive.stat().st_size,
         "file_count": len(files), "files": [{"name": name, "sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)} for name, raw in files.items()],
         "rulings": rulings, "workspace_retained": True, "destructive_operation": False, "actual_model_calls": 0}
with manifest.open("x", encoding="utf-8", newline="\n") as handle:
    json.dump(value, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps({"archive_files": len(files), "archive_bytes": archive.stat().st_size, "rulings": len(rulings), "workspace_retained": True}))
