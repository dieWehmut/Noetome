"""Verify the exact staged archives and preserve unrelated user deletions."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
staged = subprocess.check_output(["git", "diff", "--cached", "--name-only"], cwd=ROOT).decode().splitlines()
assert staged and not any(path.startswith("docs/") for path in staged)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip() == "94b0ebb40bb43cb5cdb72d924a40cf2d0893fa10"
manifest = json.loads((ROOT / "doc/validation/assets/B04-T02-chat-final-archive.json").read_text(encoding="utf-8-sig"))
for row in manifest["records"]:
    raw = (ROOT / row["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["sha256"] and len(raw) == row["byte_length"], row["path"]
verified = []
for path in staged:
    if path.startswith("doc/validation/assets/"):
        raw = (ROOT / path).read_bytes()
        blob = subprocess.check_output(["git", "show", ":" + path], cwd=ROOT)
        assert raw == blob, "archive line endings or bytes changed in index: " + path
        verified.append({"path": path, "sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)})
record = {"staged_files": len(staged), "exact_archive_files": len(verified), "files": verified,
          "unrelated_docs_deletions_unstaged": True, "archive_manifest_records_verified": len(manifest["records"]), "model_calls": 0}
path = PLAN / "root-shape-stage-check.json"
assert not path.exists()
path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in record.items() if k != "files"}))
