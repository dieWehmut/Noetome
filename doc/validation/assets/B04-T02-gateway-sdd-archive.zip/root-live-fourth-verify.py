"""Read-only verification of a successful actual04; gold comparison is diagnostic.

This does not certify subject knowledge or change model output. B04-T03 performs
the independent knowledge assessment with the previously fixed author gold.
"""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
OUTPUT = LIVE / "api-live-04"
VERSION = "tangmao-deepseek-chat-nested-atoms-v4"
sys.path.insert(0, str(ROOT / "scripts"))
from validate_extraction_gateway import sql_snapshot

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, "duplicate JSON field: " + key
        result[key] = value
    return result

def parse(raw):
    return json.loads(raw, object_pairs_hook=unique_object)

def read(path):
    return parse(path.read_bytes())

before = read(LIVE / "source-before.json")
project = Path(before["project"]).resolve()
files = {str(p.relative_to(project)): {"sha256": sha(p.read_bytes()), "byte_length": p.stat().st_size, "mtime_ns": p.stat().st_mtime_ns} for p in project.rglob("*") if p.is_file()}
assert files == before["project_files"]
assert sha("\n".join(sql_snapshot(project)).encode()) == before["project_sql_sha256"]
source = (ROOT / "fixtures/extraction-gateway-v1/source.txt").read_bytes()
gold_raw = (LIVE / "gold-before.json").read_bytes()
assert sha(source) == before["source_sha256"] and sha(gold_raw) == before["gold_sha256"]
gold = parse(gold_raw)
summary = read(PLAN / "root-shape-workspace-summary.json")
assert sha((ROOT / "target/debug/noetome.exe").read_bytes()) == summary["binary_sha256"]
command = read(LIVE / "live-command-04.json")
assert command["exit_code"] == 0 and command["binary_sha256"] == summary["binary_sha256"]
report = read(OUTPUT / "validation.json")
blocks = re.findall(r"```json\s*\n(.*?)\n```", (OUTPUT / "validation.md").read_text(encoding="utf-8"), re.S)
assert len(blocks) == 1 and parse(blocks[0]) == report
assert report["status"] == "candidates_validated" and report["provider"] == "openai_chat_completions"
assert report["transport_mode"] == "live" and report["request_strategy"] == VERSION
assert report["knowledge_status"] == "pending" and report["scientific_quality"] == "not_run" and report["published"] is False
assert report["usage"]["network_attempts"] == 1 and report["usage"]["model_usage_status"] == "validated"
artifacts = []
for name, info in report["artifacts"].items():
    path = (OUTPUT / name).resolve()
    assert path.parent == OUTPUT.resolve()
    raw = path.read_bytes()
    assert sha(raw) == info["sha256"] and len(raw) == info["byte_length"]
    artifacts.append({"name": name, "sha256": sha(raw), "byte_length": len(raw)})

request = read(OUTPUT / "request.json")
body_raw = (OUTPUT / "request-body.json").read_bytes()
body = parse(body_raw)
assert set(body) == {"model", "messages", "thinking", "response_format", "max_tokens", "stream"}
assert body["model"] == "deepseek-flash" and body["thinking"] == {"type": "disabled"}
assert body["response_format"] == {"type": "json_object"} and body["max_tokens"] == 8192 and body["stream"] is False
assert [m["role"] for m in body["messages"]] == ["system", "user"]
user = parse(body["messages"][1]["content"])
assert set(user) == {"task", "response_schema", "request"}
for phrase in ["two top-level keys: atom and measurement", "inside atom", "sibling of atom", "Do not flatten"]:
    assert phrase in user["task"]
previous_body = read(LIVE / "api-live-03/request-body.json")
previous_user = parse(previous_body["messages"][1]["content"])
assert body["messages"][0] == previous_body["messages"][0]
assert user["response_schema"] == previous_user["response_schema"]
inner = user["request"]
assert inner["binding"] == previous_user["request"]["binding"] == request["binding"]
assert inner["units"] == previous_user["request"]["units"] == request["units"]
assert inner["evidence_anchors"] == previous_user["request"]["evidence_anchors"]
assert inner["request_id"] == request["request_id"]
assert report["usage"]["input_reserved_tokens"] == len(body_raw) + 1024
assert report["usage"]["reserved_tokens"] == len(body_raw) + 1024 + body["max_tokens"]

wire = read(OUTPUT / "response.bin")
assert wire["object"] == "chat.completion" and len(wire["choices"]) == 1
choice = wire["choices"][0]
assert choice["index"] == 0 and choice["finish_reason"] == "stop" and choice["message"]["role"] == "assistant"
raw_candidate = parse(choice["message"]["content"])
saved = read(OUTPUT / "candidates.json")
assert saved["producer"] == "api" and saved["transport_mode"] == "live"
assert saved["payload"] == raw_candidate
assert raw_candidate["binding"] == inner["binding"] and raw_candidate["request_id"] == inner["request_id"]
assert len(raw_candidate["atoms"]) == report["validated_atoms"] > 0
concept_ids = {c["concept_id"] for c in raw_candidate["concepts"]}
evidence = {e["evidence_id"]: e for e in raw_candidate["evidence"]}
assert len(evidence) == len(raw_candidate["evidence"]) and len(concept_ids) == len(raw_candidate["concepts"])
for e in evidence.values():
    start, end = e["excerpt_start_byte"], e["excerpt_end_byte"]
    assert type(start) is int and type(end) is int and 0 <= start < end <= len(source)
    excerpt = source[start:end]
    assert excerpt.decode("utf-8") == e["quote"] and sha(excerpt) == e["excerpt_sha256"]
gold_matches = []
atom_fields = set(user["response_schema"]["properties"]["atoms"]["items"]["properties"]["atom"]["required"])
for item in raw_candidate["atoms"]:
    assert set(item) == {"atom", "measurement"} and set(item["atom"]) == atom_fields
    atom, measurement = item["atom"], item["measurement"]
    assert atom["required"] is False and atom["verification"] == "unverified"
    assert set(atom["concept_ids"]) <= concept_ids and atom["concept_ids"]
    assert any(link["relation"] == "supports" and link["evidence_id"] in evidence for link in atom["evidence_links"])
    if measurement is not None:
        assert set(measurement) == {"conditions", "unit", "value", "value_status"}
        if measurement["value"] == gold["value"] and measurement["unit"] == gold["unit"] and sorted(measurement["conditions"]) == sorted(gold["conditions"]):
            gold_matches.append(atom["atom_id"])

usage = wire["usage"]
total = usage["total_tokens"]
assert all(type(usage[k]) is int and usage[k] >= 0 for k in ["prompt_tokens", "completion_tokens", "total_tokens"])
assert usage["prompt_tokens"] + usage["completion_tokens"] == total <= 65536
assert report["usage"]["raw_model_usage"] == usage
assert report["usage"]["model_usage"]["input_tokens"] == usage["prompt_tokens"]
assert report["usage"]["model_usage"]["output_tokens"] == usage["completion_tokens"]
assert report["usage"]["model_usage"]["total_tokens"] == total
settled = read(LIVE / "live-budget-settlement-04.json")["ledger_after_settlement"]
assert [r["confirmed_total_tokens"] for r in settled["records"]] == [936, 9683, 4912, total]
assert settled["accounted_tokens"] == 15531 + total and settled["pending_reserved_tokens"] == 0
assert settled["remaining_tokens"] == 9984469 - total and settled["model_attempts"] == 4
for number, digest in [(1, "73de263b3d469facd25f3a80244c430165d0383b309efb37630fd280dab81d9b"), (2, "f1afb7be3978a2fc7a1b3cf8dd86f63ba508b7a483860eaec881a4cce141435a"), (3, "6ed4b15a330aeb8d552d8bd7ef2d684345427d662cbb54b2aae4b1a5732fb04b")]:
    assert sha((LIVE / f"api-live-{number:02d}/response.bin").read_bytes()) == digest
result = {"verified_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source_before_sha256": sha((LIVE / "source-before.json").read_bytes()),
          "source_original_capture_unchanged": True, "source_sql_sha256": before["project_sql_sha256"], "gold_sha256": before["gold_sha256"],
          "request_strategy": VERSION, "binary_sha256": summary["binary_sha256"], "raw_response_sha256": sha((OUTPUT / "response.bin").read_bytes()),
          "raw_candidate_matches_saved_payload": True, "core_candidates_validated": True, "validated_atoms": len(raw_candidate["atoms"]),
          "validated_evidence": len(evidence), "artifacts": artifacts, "gold_literal_measurement_matches": gold_matches,
          "knowledge_assessment": "pending_B04-T03", "scientific_quality": "not_run", "underlying_model_identity": "unverified_alias_only",
          "reasoning_content_utf8_bytes": len((choice["message"].get("reasoning_content") or "").encode()), "thinking_switch_enforcement": "unverified",
          "usage": usage, "cumulative_accounted_tokens": settled["accounted_tokens"], "remaining_tokens": settled["remaining_tokens"], "pending_reserved_tokens": 0}
path = LIVE / "live-independent-verification-04.json"
assert not path.exists()
path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in result.items() if k not in ("usage", "artifacts")}, ensure_ascii=False))
