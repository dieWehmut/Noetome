"""Archive the already completed v3 validation and original third-call provenance."""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
EXPECTED_BINARY = json.loads((PLAN / "root-qualifier-workspace-summary.json").read_text(encoding="utf-8-sig"))["binary_sha256"]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_bytes(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        with path.open("xb") as handle:
            handle.write(raw)

summary = read(PLAN / "root-qualifier-workspace-summary.json")
snapshot = read(PLAN / "root-qualifier-snapshot-verification.json")
assert summary["binary_sha256"] == snapshot["binary_sha256"] == EXPECTED_BINARY
assert summary["records"][-1]["passed"] == 499
assert len(snapshot["reports"]) == 128 and len(snapshot["requests"]) == 90
assert snapshot["source_original_capture_unchanged"]
mappings = {
    "root-qualifier-workspace-tests.json": "qualifier-final-workspace-tests.json",
    "root-qualifier-workspace-summary.json": "qualifier-final-workspace-summary.json",
    "root-qualifier-fmt.json": "qualifier-final-fmt.json",
    "root-qualifier-check.json": "qualifier-final-check.json",
    "root-qualifier-final-api-command.json": "qualifier-final-api-command.json",
    "root-qualifier-final-fake-command.json": "qualifier-final-fake-command.json",
    "root-qualifier-final-chat-command.json": "qualifier-final-chat-command.json",
    "root-qualifier-final-api/audit.json": "qualifier-final-api-audit.json",
    "root-qualifier-final-fake/evidence.json": "qualifier-final-fake-audit.json",
    "root-qualifier-final-chat/audit.json": "qualifier-final-chat-audit.json",
    "root-qualifier-selected-zero-command.json": "qualifier-final-selected-zero-command.json",
    "root-qualifier-snapshot-verification.json": "qualifier-final-snapshot-verification.json",
    "root-qualifier-cli-red.json": "qualifier-cli-red.json",
}
records = []
for source, name in mappings.items():
    path, target = PLAN / source, ASSETS / ("B04-T02-" + name)
    raw = path.read_bytes()
    if name.endswith("-audit.json"):
        assert read(path)["binary_sha256"] == EXPECTED_BINARY
    save_bytes(target, raw)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw)})
for source, name in [
    ("root-qualifier-resume.py", "qualifier-final-workspace-source.json"),
    ("root-qualifier-snapshot-check-v2.py", "qualifier-final-snapshot-source.json"),
    ("root-live-fifth.py", "live-fifth-controller-source.json"),
    ("root-qualifier-cli-red.py", "qualifier-cli-red-source.json"),
]:
    path = PLAN / source
    raw = path.read_bytes()
    value = {"source": path.relative_to(ROOT).as_posix(), "source_sha256": sha(raw), "byte_length": len(raw), "source_text": raw.decode("utf-8-sig")}
    output = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    target = ASSETS / ("B04-T02-" + name)
    save_bytes(target, output)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(output), "byte_length": len(output)})

files = {}
for item in snapshot["reports"]:
    path = (ROOT / item["path"]).resolve()
    assert path.is_relative_to(PLAN)
    raw, md = path.read_bytes(), path.with_suffix(".md").read_bytes()
    assert sha(raw) == item["json_sha256"] and sha(md) == item["markdown_sha256"]
    files[path] = raw
    files[path.with_suffix(".md")] = md
    for name, fingerprint in json.loads(raw)["artifacts"].items():
        artifact = (path.parent / name).resolve()
        assert artifact.parent == path.parent
        content = artifact.read_bytes()
        assert sha(content) == fingerprint["sha256"] and len(content) == fingerprint["byte_length"]
        files[artifact] = content
archive = ASSETS / "B04-T02-qualifier-final-reports.zip"
assert not archive.exists(), archive
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path, raw in sorted(files.items()):
        info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(2026, 11, 3, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        handle.writestr(info, raw)
with zipfile.ZipFile(archive) as handle:
    assert len(handle.namelist()) == len(files)
    for path, raw in files.items():
        assert handle.read(path.relative_to(ROOT).as_posix()) == raw
records.append({"path": archive.relative_to(ROOT).as_posix(), "sha256": sha(archive.read_bytes()), "byte_length": archive.stat().st_size, "files": len(files)})
manifest = {"captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "binary_sha256": EXPECTED_BINARY,
            "validated_strategy": "tangmao-deepseek-chat-qualifiers-v5", "report_pairs": 128,
            "request_records": 90, "records": records, "actual_model_call_in_archive_step": 0}
save_bytes(ASSETS / "B04-T02-qualifier-final-archive.json", (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"archived_records": len(records), "report_pairs": 128, "request_records": 90,
                  "report_archive_files": len(files), "binary_sha256": EXPECTED_BINARY}))
