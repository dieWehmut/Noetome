"""Archive the completed v6 validation and preserve prior original call provenance."""
import datetime
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
EXPECTED_BINARY = json.loads((PLAN / "root-revision-workspace-summary.json").read_text(encoding="utf-8-sig"))["binary_sha256"]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save_bytes(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        with path.open("xb") as handle:
            handle.write(raw)

summary = read(PLAN / "root-revision-workspace-summary.json")
snapshot = read(PLAN / "root-revision-snapshot-verification.json")
assert summary["binary_sha256"] == snapshot["binary_sha256"] == EXPECTED_BINARY
assert summary["records"][-1]["passed"] == 502
assert len(snapshot["reports"]) == 130 and len(snapshot["requests"]) == 92
assert snapshot["source_original_capture_unchanged"]
mappings = {
    "root-revision-workspace-tests.json": "revision-final-workspace-tests.json",
    "root-revision-workspace-summary.json": "revision-final-workspace-summary.json",
    "root-revision-fmt.json": "revision-final-fmt.json",
    "root-revision-check.json": "revision-final-check.json",
    "root-revision-final-api-command.json": "revision-final-api-command.json",
    "root-revision-final-fake-command.json": "revision-final-fake-command.json",
    "root-revision-final-chat-command.json": "revision-final-chat-command.json",
    "root-revision-final-api/audit.json": "revision-final-api-audit.json",
    "root-revision-final-fake/evidence.json": "revision-final-fake-audit.json",
    "root-revision-final-chat/audit.json": "revision-final-chat-audit.json",
    "root-revision-selected-zero-command.json": "revision-final-selected-zero-command.json",
    "root-revision-snapshot-verification.json": "revision-final-snapshot-verification.json",
    "root-revision-cli-red.json": "revision-cli-red.json",
}
records = []
for source, name in mappings.items():
    path, target = PLAN / source, ASSETS / ("B04-T02-" + name)
    raw = path.read_bytes()
    if name.endswith("-audit.json"):
        assert read(path)["binary_sha256"] == EXPECTED_BINARY
    save_bytes(target, raw)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(raw), "byte_length": len(raw)})
for source, name in [
    ("root-revision-workspace.py", "revision-final-workspace-source.json"),
    ("root-revision-snapshot-check.py", "revision-final-snapshot-source.json"),
    ("root-live-sixth.py", "live-sixth-controller-source.json"),
    ("root-revision-cli-red.py", "revision-cli-red-source.json"),
]:
    path = PLAN / source
    raw = path.read_bytes()
    value = {"source": path.relative_to(ROOT).as_posix(), "source_sha256": sha(raw), "byte_length": len(raw), "source_text": raw.decode("utf-8-sig")}
    output = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()
    target = ASSETS / ("B04-T02-" + name)
    save_bytes(target, output)
    records.append({"path": target.relative_to(ROOT).as_posix(), "sha256": sha(output), "byte_length": len(output)})

files = {}
for item in snapshot["reports"]:
    path = (ROOT / item["path"]).resolve()
    assert path.is_relative_to(PLAN)
    raw, md = path.read_bytes(), path.with_suffix(".md").read_bytes()
    assert sha(raw) == item["json_sha256"] and sha(md) == item["markdown_sha256"]
    files[path] = raw
    files[path.with_suffix(".md")] = md
    for name, fingerprint in json.loads(raw)["artifacts"].items():
        artifact = (path.parent / name).resolve()
        assert artifact.parent == path.parent
        content = artifact.read_bytes()
        assert sha(content) == fingerprint["sha256"] and len(content) == fingerprint["byte_length"]
        files[artifact] = content
archive = ASSETS / "B04-T02-revision-final-reports.zip"
assert not archive.exists(), archive
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
    for path, raw in sorted(files.items()):
        info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(2026, 11, 3, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        handle.writestr(info, raw)
with zipfile.ZipFile(archive) as handle:
    assert len(handle.namelist()) == len(files)
    for path, raw in files.items():
        assert handle.read(path.relative_to(ROOT).as_posix()) == raw
records.append({"path": archive.relative_to(ROOT).as_posix(), "sha256": sha(archive.read_bytes()), "byte_length": archive.stat().st_size, "files": len(files)})
manifest = {"captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "binary_sha256": EXPECTED_BINARY,
            "validated_strategy": "tangmao-deepseek-chat-positive-revision-v6", "report_pairs": 130,
            "request_records": 92, "records": records, "actual_model_call_in_archive_step": 0}
save_bytes(ASSETS / "B04-T02-revision-final-archive.json", (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"archived_records": len(records), "report_pairs": 130, "request_records": 92,
                  "report_archive_files": len(files), "binary_sha256": EXPECTED_BINARY}))
