"""Read-only verification of the one cache-counter closure and retained runs."""
from pathlib import Path
import hashlib
import json
import re

repo = Path('D:/Noetome')
plan = repo / '.superpowers/sdd/B04-T02_GATEWAY_PLAN'
assets = repo / 'doc/validation/assets'
checks, fingerprints = [], {}

def read(path):
    raw = path.read_bytes()
    fingerprints[str(path.relative_to(repo)).replace('\\', '/')] = {
        'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return raw

def load(path):
    return json.loads(read(path))

def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    assert condition, name

diff = read(plan / 'review-1b699d2..94b0ebb.diff').decode()
paths = re.findall(r'^diff --git a/(.*?) b/', diff, re.M)
check('only Chat wire source changes', [p for p in paths if p.startswith(('crates/', 'scripts/'))] == ['crates/noetome-cli/src/extraction_api_wire/chat.rs'])
check('both-present checked sum is in immutable fix', 'if hit.checked_add(miss) != Some(input)' in diff)
artifact = load(assets / 'B04-T02-chat-cache-fix-artifacts.json')
source = read(repo / 'crates/noetome-cli/src/extraction_api_wire/chat.rs')
check('scoped source matches retained fingerprint', hashlib.sha256(source).hexdigest() == artifact['source_sha256'] and len(source) == artifact['source_bytes'])
patch = load(assets / 'B04-T02-chat-cache-fix-source-patch.json')
patch_bytes = patch['content'].encode()
check('source patch matches retained fingerprint', hashlib.sha256(patch_bytes).hexdigest() == artifact['patch_sha256'] == patch['sha256'] and len(patch_bytes) == patch['byte_length'])
results = {}
for name, code, summary in [('red', 1, '0 passed; 1 failed'), ('green', 0, '4 passed; 0 failed'), ('owned-fmt', 0, None), ('diff-check', 0, None)]:
    entry = load(assets / ('B04-T02-chat-cache-fix-' + name + '.json'))
    check('retained ' + name, entry['exit_code'] == code and (summary is None or summary in entry['output']))
    if name == 'green':
        check('GREEN has no Rust warning', 'warning:' not in entry['output'])
    results[name] = {'exit_code': entry['exit_code'], 'test_summary': summary}
ledger = load(repo / 'dev-log/tasks.json')
states = {task['id']: task['status'] for task in ledger['tasks']}
check('task phase unchanged', states['B04-T02'] == 'in_progress' and states['B04-T03'] == 'todo')
evidence = {'base': '1b699d2bc9e30342953d7a687a4385a0bcb74eee', 'head': '94b0ebb40bb43cb5cdb72d924a40cf2d0893fa10',
            'finding': 'optional cache pair checked sum', 'finding_verdict': 'ADDRESSED', 'scoped_verdict': 'PASS',
            'new_breakage': [], 'checks': checks, 'fingerprints': fingerprints, 'retained_results': results,
            'reviewer_tests_builds_network_private_reads': 0,
            'limits': 'One finding and fix diff only; no full component, workspace or real-call acceptance.'}
(plan / 'chat-cache-closure-evidence.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'finding': 'ADDRESSED', 'scoped': 'PASS', 'checks_passed': len(checks), 'fingerprints': len(fingerprints), 'reviewer_tests_builds_network_private_reads': 0}))
