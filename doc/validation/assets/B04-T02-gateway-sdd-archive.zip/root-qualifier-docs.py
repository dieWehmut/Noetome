from pathlib import Path

root = Path.cwd()
contract=root/'doc/technical/EXTRACTION_API_CONTRACT.md'
text=contract.read_text(encoding='utf-8')
old='Chat策略tangmao-deepseek-chat-nested-atoms-v4沿用v3的六字段正文'
assert old in text
text=text.replace(old,'Chat当前策略tangmao-deepseek-chat-qualifiers-v5沿用v3/v4的六字段正文')
text=text.replace('thinking只是请求意图，三次实际回包仍含reasoning信息','thinking只是请求意图，四次实际回包仍含reasoning信息')
needle='用户已授权的10000000为累计额度'
assert needle in text
text=text.replace(needle,'v5仅在完整v4包装/条件提示后明确已有跨字段规则：非null measurement.unit必须逐字出现在atom.qualifiers，每个measurement.conditions字符串也须逐字保留；measurement字段本身不能代替Atom限定信息。原第四响应仍因缺单位限定被Core拒绝，不修补原响应、Schema、合法枚举或严格验证器。\n\n'+needle)
contract.write_bytes(text.encode())
validation=root/'doc/validation/B04-T02.md'
text=validation.read_text(encoding='utf-8')
old='新鲜窄范围审查、最终程序完整回归及新的一次预算内实际调用仍待完成。'
assert old in text
text=text.replace(old,'v4新鲜审查与最终回归已按下节归档；第四次实际失败和v5修复继续独立记录。')
old='继续完成v4嵌套提示及新鲜审查/最终相关检查，复用已保存Chat接口、DPAPI凭据及9984469累计剩余额度，以同一固定作者来源/gold执行一次新的有界验证。三份失败和调用前gold保持原字节；'
assert old in text
text=text.replace(old,'继续完成v5跨字段限定提示的新鲜审查/最终相关核对，复用已保存Chat接口、DPAPI凭据及9979686累计剩余额度，以同一固定作者来源/gold执行一次新的有界验证。四份失败和调用前gold保持原字节；')
text+='''

## 第四次真实失败与v5限定信息修复

v4的新鲜[1124项/797份指纹审查](assets/B04-T02-shape-review.md)通过，完整[498 Rust](assets/B04-T02-shape-final-workspace-tests.json)、API84/fake54/Chat34及[127双报告/89请求](assets/B04-T02-shape-final-snapshot-verification.json)绑定程序5797c708...通过；[710原文件归档](assets/B04-T02-shape-final-reports.zip)保留。它们只证明v4历史，不替代v5最终源码验证。

[第四次真实调用](assets/B04-T02-live-fourth-command.json)HTTP200/stop、JSON及嵌套结构正确，计量1712+3071=4783，已[结算](assets/B04-T02-live-fourth-settlement.json)到累计20314/余额9979686/pending0。measurement.unit为m/s，却未同时放入atom.qualifiers，原Core报EXTRACT_QUALIFIERS。两个温度/适用条件均已保留；合法枚举与JSON包装不是本次失败原因。[原响应](assets/B04-T02-live-fourth-response.bin)SHAa6081c965ef7f64416639b4cb3ade403ae72bd97331a3af0f8627927f954cbe9、[诊断](assets/B04-T02-live-fourth-diagnosis.json)和[来源保护](assets/B04-T02-live-fourth-after.json)不修改。

v5只增加上述既有单位/条件与Atom限定信息的逐字对应提示，不放宽Core、不填入gold、不补原回包。controller普通CLI[真实RED0/2](assets/B04-T02-qualifier-cli-red.json)及worker[native RED0/1](assets/B04-T02-qualifier-fix-native-red.json)先于生产修改；[native38/API CLI7/fake3](assets/B04-T02-qualifier-fix-report.md)和[独立Chat35](assets/B04-T02-qualifier-prototype-chat-audit.json)、[Python76](assets/B04-T02-qualifier-python-tests.json)通过。原第四回包的wire结构解码可通过，但单位限定仍缺失，不称为Core接受。

用户截图顶部栏已单独在B04U-T01验收并推送8004df0；恢复B04R模型任务。该期间[完整Rust499及最终程序](assets/B04U-T01-workspace-summary.json)的v5四份源码SHA与worker及当前工作树逐字节一致，程序514ce3c5414874956dffcc3e612ecd538b59393e0eec71977d011d938f69b236不变，所以复用已通过的fmt/check/499结果，避免重跑相同Cargo。当前最终API84/90CLI、fake54/60CLI、Chat35/37CLI已以新根验证；128双报告/90请求和选定端点0请求预检核对通过，最终归档/新鲜审查/一个新根的真实验证继续按结果记录。没有第五次真实调用或v5实际候选成功声明。
'''
validation.write_bytes(text.encode())
next_path=root/'doc/execution/NEXT_STEPS.md'
text=next_path.read_text(encoding='utf-8')
anchor='2026-11-03 用户新增截图界面要求'
position=text.index(anchor)
end=text.index('\n\n',position)
text=text[:position]+'B04U-T01 顶部栏已按用户截图验收、安装并推送核对8004df0。当前批次为 **B04R**，进行中仅 **B04-T02**：按[网关计划](B04-T02_GATEWAY_PLAN.md)继续v5限定提示、新鲜审查、最终报告核对和一次有界真实请求；之后才进入B04-T03独立知识核对。保留原任务ID和全部失败/解除/恢复历史。'+text[end:]
next_path.write_bytes(text.encode())
print('Current v5 contract/actual fourth failure and UI-to-model schedule recorded.')
