"""Bounded read-only evidence audit for BASE332fcd9..HEAD1b699d2 Chat review.

Reads only the supplied package, scoped source/evidence and selected author fixture.
No builds, tests, HTTP requests, credential/profile/auth access or Git mutations.
"""
from pathlib import Path
import hashlib
import json
import re
import time

ROOT = Path('D:/Noetome')
OUT = ROOT / '.superpowers/sdd/B04-T02_GATEWAY_PLAN'
ASSETS = ROOT / 'doc/validation/assets'
checks = []
fingerprints = {}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    path = Path(path)
    raw = path.read_bytes()
    fingerprints[str(path.relative_to(ROOT)).replace('\\', '/')] = {
        'sha256': sha(raw), 'bytes': len(raw)}
    return raw

def load(path):
    return json.loads(read(path))

def check(name, passed, details=None):
    checks.append({'name': name, 'passed': bool(passed), 'details': details})
    if not passed:
        raise AssertionError(name)

package = OUT / 'review-332fcd9..1b699d2.diff'
diff = read(package).decode('utf-8')
changed = re.findall(r'^diff --git a/(.*?) b/', diff, flags=re.M)
check('no new SDK/dependency/lib entry in immutable package',
      not any(p.endswith(('Cargo.toml', 'Cargo.lock', '/lib.rs')) for p in changed))

artifacts = load(ASSETS / 'B04-T02-chat-fix-artifacts.json')
immutable_new_file = 'crates/noetome-cli/src/extraction_api_wire/chat.rs'
new_section = next(s for s in diff.split('diff --git ') if s.startswith('a/' + immutable_new_file + ' b/'))
new_lines = [line[1:] for line in new_section.splitlines() if line.startswith('+') and not line.startswith('+++')]
new_file_candidates = [('LF', ('\n'.join(new_lines) + '\n').encode()),
                       ('CRLF', ('\r\n'.join(new_lines) + '\r\n').encode())]
for relative, expected in artifacts.items():
    if relative == 'target/debug/noetome.exe':
        continue  # historical component binary; final build belongs to controller
    if relative == immutable_new_file:
        matching = [(ending, raw) for ending, raw in new_file_candidates if sha(raw) == expected['sha256']]
        check('immutable new Chat file reconstructed from supplied package', len(matching) == 1)
        actual = matching[0][1]
        fingerprints[relative] = {'sha256': sha(actual), 'bytes': len(actual),
                                  'source': 'immutable review package', 'line_ending': matching[0][0]}
    else:
        actual = read(ROOT / relative)
    check('retained component artifact fingerprint: ' + relative,
          sha(actual) == expected['sha256'] and len(actual) == expected['bytes'])

py = load(ASSETS / 'B04-T02-root-chat-python-tests.json')
for script, expected in py['scripts_sha256'].items():
    check('independent script fingerprint: ' + script,
          sha(read(ROOT / 'scripts' / script)) == expected)
check('retained Python result', py['exit_code'] == 0 and 'Ran 76 tests' in py['stderr'] and 'OK' in py['stderr'])

capture = load(ASSETS / 'B04-T02-chat-thinking-primary-capture.json')
check('primary capture has no credentials', capture['credential_used'] is False)
for item in capture['records']:
    actual = read(Path(item['file']))
    check('primary fingerprint: ' + Path(item['file']).name,
          item['http_status'] == 200 and sha(actual) == item['sha256'] and len(actual) == item['byte_length'])

retained_results = {}
for name, expected_exit, result in [
    ('chat-fix-native-red.json', 1, '0 passed; 2 failed'),
    ('chat-cli-red.json', 101, '0 passed; 2 failed'),
    ('chat-fix-native-route-final.json', 0, '35 passed; 0 failed'),
    ('chat-fix-cli-final.json', 0, '7 passed; 0 failed'),
    ('chat-fix-fake-green.json', 0, '3 passed; 0 failed'),
    ('chat-fix-check.json', 0, None),
    ('chat-fix-owned-fmt.json', 0, None),
    ('chat-fix-fmt-all.json', 0, None),
    ('chat-fix-diff-check.json', 0, None),
]:
    entry = load(OUT / name)
    output = entry.get('output', '') + entry.get('stdout', '') + entry.get('stderr', '')
    check('retained command result: ' + name,
          entry['exit_code'] == expected_exit and (result is None or result in output))
    retained_results[name] = {'exit_code': entry['exit_code'], 'expected_test_result': result,
                             'rust_warning': 'warning:' in output and name != 'chat-fix-diff-check.json'}

proto = load(ASSETS / 'B04-T02-root-chat-prototype-audit.json')
proto_cmd = load(ASSETS / 'B04-T02-root-chat-prototype-command.json')
prototype = {'scenes': len(proto['checks']), 'cli_calls': len(proto['calls']),
             'local_posts': sum(c['local_post_count'] for c in proto['checks']),
             'binary_sha256': proto['binary_sha256'], 'historical_component_run': True}
check('retained independent Chat prototype 34/36/28',
      (prototype['scenes'], prototype['cli_calls'], prototype['local_posts']) == (34, 36, 28)
      and all(c['passed'] for c in proto['checks']) and proto['real_model_calls'] == 0
      and proto['paid_calls'] == 0 and proto_cmd['exit_code'] == 0
      and proto_cmd['binary_sha256'] == proto['binary_sha256'])
live_rejection = next(c for c in proto['checks'] if c['name'] == 'chat-unselected-live-host')
check('independent live-host rejection has no POST', live_rejection['local_post_count'] == 0)

live_root = ROOT / 'target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556'
before = load(live_root / 'source-before.json')
source_project = Path(before['project'])
observed = {str(p.relative_to(source_project)) for p in source_project.rglob('*') if p.is_file()}
check('fixed selected project has exactly the five recorded files', observed == set(before['project_files']))
for relative, expected in before['project_files'].items():
    path = source_project / relative
    actual = read(path)
    check('selected source remains byte/mtime identical: ' + relative,
          sha(actual) == expected['sha256'] and len(actual) == expected['byte_length']
          and path.stat().st_mtime_ns == expected['mtime_ns'])
check('fixed author source hash', sha(read(ROOT / 'fixtures/extraction-gateway-v1/source.txt')) == before['source_sha256'])
check('fixed author gold hash', sha(read(ROOT / 'fixtures/extraction-gateway-v1/expected.json')) == before['gold_sha256'])
check('gold-before still equals independently fixed author gold',
      load(live_root / 'gold-before.json') == load(ROOT / 'fixtures/extraction-gateway-v1/expected.json'))

live = []
for ordinal, total in [('first', 936), ('second', 9683)]:
    response_path = ASSETS / f'B04-T02-live-{ordinal}-response.bin'
    wire = json.loads(read(response_path))
    report = load(ASSETS / f'B04-T02-live-{ordinal}-validation.json')
    usage = wire['usage']
    check('retained failed actual ' + ordinal + ' usage and receipt',
          usage['input_tokens'] + usage['output_tokens'] == usage['total_tokens'] == total
          and usage == report['usage']['model_usage']
          and report['status'] == 'failed' and report['published'] is False
          and report['response_receipt']['sha256'] == sha(response_path.read_bytes()))
    if ordinal == 'second':
        check('second raw remains incomplete/max_output_tokens',
              wire['status'] == 'incomplete' and wire['incomplete_details']['reason'] == 'max_output_tokens')
    live.append({'ordinal': ordinal, 'total_tokens': total,
                 'response_sha256': sha(response_path.read_bytes()), 'status': report['status']})
settled = load(ASSETS / 'B04-T02-live-second-settlement.json')['ledger_after_settlement']
check('retained cumulative 10619/9989381/pending0',
      settled['accounted_tokens'] == sum(r['total_tokens'] for r in live) == 10619
      and settled['remaining_tokens'] == 9989381 and settled['pending_reserved_tokens'] == 0)
ledger = load(ROOT / 'dev-log/tasks.json')
states = {t['id']: t['status'] for t in ledger['tasks']}
check('review does not advance task phase', states['B04-T02'] == 'in_progress' and states['B04-T03'] == 'todo')

evidence = {'schema_version': 1, 'created_at_unix': time.time(),
            'base': '332fcd97c264ce8c9e88099ae3d0b1179e4f80d6',
            'head': '1b699d2bc9e30342953d7a687a4385a0bcb74eee',
            'spec': 'PASS', 'quality': 'PASS', 'findings': {'critical': 0, 'important': 0, 'minor': 1},
            'checks': checks, 'check_count': len(checks), 'fingerprints': fingerprints,
            'retained_results': retained_results, 'prototype': prototype, 'actual_responses': live,
            'reviewer_tests_executed': 0, 'reviewer_network_requests': 0,
            'reviewer_credential_or_profile_reads': 0,
            'limits': ['No full workspace tests/builds or local matrix rerun.',
                       'Prototype binary is historical; controller must bind final whole workspace program.',
                       'Third actual call, deployed thinking behavior, bottom model and prices remain unverified.',
                       'Only supplied author fixture/source and non-secret retained archives were read.']}
(OUT / 'chat-review-evidence.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'checks_passed': len(checks), 'fingerprints': len(fingerprints),
                  'prototype': prototype, 'reviewer_tests': 0, 'reviewer_network_requests': 0}))
