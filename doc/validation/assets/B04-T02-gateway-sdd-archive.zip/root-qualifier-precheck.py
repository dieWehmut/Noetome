"""Record controller-owned local Chat or Python checks without credentials."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ("chat", "python")
output = PLAN / ("root-qualifier-" + ("prototype-chat-command" if mode == "chat" else "python-tests") + ".json")
assert not output.exists(), output
binary = ROOT / "target/debug/noetome.exe"
script = ROOT / "scripts/validate_extraction_chat.py"
if mode == "chat":
    argv = [sys.executable, "-X", "utf8", str(script), "--binary", str(binary), "--root", str(PLAN / "root-qualifier-prototype-chat")]
else:
    argv = [sys.executable, "-X", "utf8", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"]
env = dict(os.environ)
env["NOETOME_PDF_PYTHON"] = env["NOETOME_TEST_PYTHON"] = sys.executable
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
record = {"command": argv, "started_at": started, "elapsed_seconds": time.monotonic() - clock, "exit_code": run.returncode,
          "stdout": run.stdout.decode("utf-8"), "stderr": run.stderr.decode("utf-8"),
          "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
          "model_calls": 0, "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest() if mode == "chat" else None,
          "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest() if mode == "chat" else None}
output.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert run.returncode == 0, record
assert "35 independent Chat CLI/local HTTP checks passed" in record["stdout"] if mode == "chat" else re.search(r"Ran 76 tests.*\n\s*\nOK", record["stderr"], re.S)
print(json.dumps({"mode": mode, "exit_code": 0, "passed": 35 if mode == "chat" else 76,
                  "elapsed_seconds": record["elapsed_seconds"], "evidence": str(output)}))
