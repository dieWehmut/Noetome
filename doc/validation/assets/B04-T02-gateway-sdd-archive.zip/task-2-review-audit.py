"""Fresh read-only audit of immutable gateway review evidence; no HTTP calls."""
import collections
import hashlib
import json
import pathlib
import re
import subprocess
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[3]
PLAN = pathlib.Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"
BASE = "cd01771459d0ae0f55ad8758fa8bd80f95f54512"
HEAD = "27879efc46a2709c2c93f4cf3271c26a4cf0584e"
FINAL_SHA = "c3755d7f5d966c70d78d903745c9bdbbfbe08d04c28b1c77045f41d4c3070f7e"
SELECTED = "https://ai.1343263.xyz/v1/responses"
OPENAI = "openai-responses-strict-json-schema-v1"
TANGMAO = "tangmao-deepseek-responses-json-schema-v1"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def require(condition, label):
    if not condition:
        raise AssertionError(label)

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)

reviewed_sources = []
for path in [
    "crates/noetome-cli/src/extraction_api.rs",
    "crates/noetome-cli/src/extraction_api_config.rs",
    "crates/noetome-cli/src/extraction_api_schema.rs",
    "crates/noetome-cli/tests/extraction_api.rs",
]:
    committed = git("show", f"{HEAD}:{path}")
    current = (ROOT / path).read_bytes()
    require(current.replace(b"\r\n", b"\n") == committed.replace(b"\r\n", b"\n"), path)
    reviewed_sources.append({"path": path, "commit_sha256": sha(committed),
                             "worktree_sha256": sha(current), "normalized_equal": True})

verification = read_json(ASSETS / "B04-T02-selected-verification.json")
require(verification["binary_sha256"] == FINAL_SHA, "final recorded binary")
counts = collections.Counter()
snapshots = []
all_api_schema = []
for saved in verification["reports"]:
    path = ROOT / saved["path"]
    require(path.is_relative_to(PLAN), "report path inside selected review plan")
    raw = path.read_bytes()
    md_path = path.with_suffix(".md")
    md_raw = md_path.read_bytes()
    require(sha(raw) == saved["json_sha256"], str(path) + " json sha")
    require(sha(md_raw) == saved["markdown_sha256"], str(path) + " md sha")
    report = json.loads(raw)
    blocks = re.findall(r"```json\s*\n(.*?)\n```", md_raw.decode("utf-8"), re.S)
    require(len(blocks) == 1 and json.loads(blocks[0]) == report, str(path) + " MD snapshot")
    counts[saved["kind"]] += 1
    checked = {"path": saved["path"], "kind": saved["kind"], "sha_equal": True,
               "json_markdown_equal": True}
    if saved["kind"] != "fake":
        request_path = path.parent / "request.json"
        body_path = path.parent / "request-body.json"
        request_raw, body_raw = request_path.read_bytes(), body_path.read_bytes()
        request, body = json.loads(request_raw), json.loads(body_raw)
        require(sha(request_raw) == saved["request_sha256"], "request sha")
        require(sha(body_raw) == saved["body_sha256"], "body sha")
        require(request["request_body"] == {"sha256": sha(body_raw), "byte_length": len(body_raw)}, "body receipt")
        require(request["input_reserved_tokens"] == len(body_raw) + 1024, "input reservation")
        require(request["reserved_tokens"] == len(body_raw) + 1024 + body["max_output_tokens"], "total reservation")
        require(report["usage"]["request_utf8_bytes"] == len(body_raw), "report request bytes")
        require(report["usage"]["input_reserved_tokens"] == request["input_reserved_tokens"], "report reservation")
        require(report["usage"]["reserved_tokens"] == request["reserved_tokens"], "report total reservation")
        expected_strategy = TANGMAO if saved["kind"] == "selected_zero" else OPENAI
        require(report["request_strategy"] == request["request_strategy"] == saved["request_strategy"] == expected_strategy, "strategy")
        require(report["endpoint"] == request["endpoint"] == saved["endpoint"], "endpoint")
        require(body["model"] == request["configured_model"] == report["configured_model"], "configured model")
        for key, value in [("store", False), ("stream", False), ("tools", []), ("tool_choice", "none")]:
            require(body[key] == value, "bounded body policy " + key)
        fmt = body["text"]["format"]
        require(fmt["type"] == "json_schema" and fmt["name"] == "noetome_candidates_v1", "format")
        require(fmt["schema"]["additionalProperties"] is False, "schema closed")
        all_api_schema.append(fmt["schema"])
        content = json.loads(body["input"])
        require(content["binding"] == request["binding"] and content["request_id"] == request["request_id"], "input binding")
        for unit, anchor in zip(content["units"], content["evidence_anchors"], strict=True):
            require(anchor == {"unit_id": unit["unit_id"], "excerpt_start_byte": unit["start_byte"],
                               "excerpt_end_byte": unit["end_byte"], "quote": unit["text"],
                               "excerpt_sha256": sha(unit["text"].encode("utf-8"))}, "absolute UTF8 anchor")
        if expected_strategy == TANGMAO:
            require(request["endpoint"] == SELECTED and request["transport_mode"] == "live", "selected route")
            require(body["model"] == "deepseek-flash", "selected model")
            require("strict" not in fmt, "unsupported strict omitted")
            require(body["reasoning"] == {"effort": "none"}, "selected reasoning")
            require(not any(k in body for k in ["background", "service_tier", "truncation"]), "unsupported fields omitted")
            require(report["usage"]["network_attempts"] == report["usage"]["real_model_calls"] == 0, "zero calls")
            require(report["actual_model"] is None and report["usage"]["model_usage"] is None, "no actual usage")
            require(report["status"] == "failed" and report["errors"][0]["code"] == "EXTRACT_BUDGET_STOP", "budget stop")
            require(not (path.parent / "candidates.json").exists(), "no selected candidate")
        else:
            require(fmt["strict"] is True, "official/local strict preserved")
            require(body["background"] is False and body["service_tier"] == "default" and body["truncation"] == "disabled", "official/local policy")
            require("reasoning" not in body, "old strategy reasoning unchanged")
        checked.update({"request_strategy": expected_strategy, "endpoint": report["endpoint"],
                        "request_receipt_exact": True, "reservation_exact": True, "absolute_anchors_exact": True})
    snapshots.append(checked)
require(dict(counts) == {"local_http": 59, "selected_zero": 1, "fake": 38}, "snapshot counts")
require(all(schema == all_api_schema[0] for schema in all_api_schema), "shared candidate schema")

regressions = []
for name, expected_checks, expected_calls in [("api", 84, 90), ("fake", 54, 60)]:
    path = ASSETS / f"B04-T02-selected-{name}-final.json"
    data = read_json(path)
    require(data["binary_sha256"] == FINAL_SHA, "regression recorded binary")
    require(len(data["checks"]) == expected_checks and all(c["passed"] for c in data["checks"]), "regression checks")
    require(len(data["calls"]) == expected_calls, "ordinary CLI count")
    before, after = data["source_inventory_before"], data["source_inventory_after"]
    controlled = data.get("controlled_source_scene_files", [])
    require(all(before[k] == after.get(k) for k in before), "registered source inventory")
    require(sorted(set(after) - set(before)) == sorted(controlled), "only recorded controlled source additions")
    require(data["source_sql_before"] == data["source_sql_after"], "source SQL")
    entry = {"kind": name, "path": str(path.relative_to(ROOT)), "checks": expected_checks,
             "cli_calls": expected_calls, "registered_source_inventory_sql_equal": True,
             "controlled_source_additions": controlled}
    if name == "api":
        posts = sum(c["local_post_count"] for c in data["checks"])
        require(posts == 54 and data["real_model_calls"] == data["paid_calls"] == 0, "local-only receipts")
        entry["local_posts"] = posts
    regressions.append(entry)

full = read_json(ASSETS / "B04-T02-selected-workspace-tests.json")
native = full["native_output"].encode("utf-8")
require(len(native) == full["raw_byte_length"] and sha(native) == full["raw_sha256"], "raw full test log fingerprint")
suites = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", full["native_output"])
require(sum(int(p) for p, _, _ in suites) == 484 and all(int(f) == int(i) == 0 for _, f, i in suites), "raw suite counts")
red = []
for name, expected in [("native", "0 passed; 1 failed"), ("cli", "1 passed; 1 failed")]:
    data = read_json(ASSETS / f"B04-T02-selected-{name}-red.json")
    require(data["exit_code"] == 1 and expected in data["output"] and "EXTRACT_API_ENDPOINT" in data["output"], "true RED")
    red.append({"kind": name, "exit_code": 1, "expected_failure_text_present": True})

interface = read_json(ASSETS / "B04-T02-selected-service-interface.json")
primary = []
for entry in interface["official_deepseek_sources"]:
    filename = "raw-" + entry["url"].rsplit("/", 1)[1]
    raw = (ROOT / "target/gateway-primary-docs-20261103" / filename).read_bytes()
    require(sha(raw) == entry["download_sha256"] and len(raw) == entry["byte_length"], "primary download fingerprint")
    primary.append({"url": entry["url"], "sha_length_equal": True})

result = {"recorded_at": datetime.now(timezone.utc).isoformat(), "base_commit": BASE,
          "head_commit": HEAD, "reviewed_sources": reviewed_sources,
          "spec": "PASS", "quality": "PASS", "actionable_findings": [],
          "fresh_native_api_tests": {"passed": 25, "failed": 0, "command": ".\\scripts\\cargo_local.ps1 test -p noetome-cli --locked --offline extraction_api '--' --test-threads=1"},
          "fresh_ordinary_cli_tests": {"passed": 5, "failed": 0, "command": ".\\scripts\\cargo_local.ps1 test -p noetome-cli --locked --offline --test extraction_api '--' --test-threads=1", "log": "task-2-review-cli-tests.txt"},
          "snapshot_counts": dict(counts), "snapshots": snapshots, "regression_evidence_rechecked": regressions,
          "preserved_full_native_log": {"passed": 484, "failed": 0, "suites": len(suites), "raw_byte_length": len(native), "raw_sha256": sha(native)},
          "true_red_evidence_rechecked": red, "primary_saved_bytes_rechecked": primary,
          "recorded_root_final_binary_sha256": FINAL_SHA,
          "reviewer_package_build_binary_sha256": sha((ROOT / "target/debug/noetome.exe").read_bytes()),
          "reviewer_audit_history": ["Initial audit exit 1: overbroad inventory equality assertion found the expressly recorded human-source-human-scene.txt addition. Corrected the audit to require every preexisting source entry unchanged and exactly the recorded controlled additions; no product/source change."],
          "limits": ["Full 484/Python 76 and independent 84/54 are reviewed saved root evidence, not rerun by reviewer.",
                     "Reviewer focused package tests rebuilt standalone-package feature executable; root must restore and reverify workspace binary before actual smoke.",
                     "No external HTTP, model, paid calls or real credential reads performed.",
                     "No deployment equivalence, actual selected response, provider billing, broad compatibility or scientific correctness claim."]}
(PLAN / "task-2-review-evidence.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"spec": "PASS", "quality": "PASS", "actionable_findings": [], "snapshots": dict(counts),
                  "regression_counts": regressions, "full_raw_passed": 484, "primary_sources": len(primary)}, ensure_ascii=True))
