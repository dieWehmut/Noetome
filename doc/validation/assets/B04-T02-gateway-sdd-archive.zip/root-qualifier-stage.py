import hashlib
import json
from pathlib import Path
import subprocess

root=Path.cwd()
plan=root/'.superpowers/sdd/B04-T02_GATEWAY_PLAN'
assets=root/'doc/validation/assets'
for name in ('root-qualifier-snapshot-first-failure.json','root-qualifier-resume-source-check.json'):
    out=assets/('B04-T02-'+name.replace('root-',''))
    assert not out.exists()
    out.write_bytes((plan/name).read_bytes())
doc=root/'doc/validation/B04-T02.md'
text=doc.read_text(encoding='utf-8')
text+='\n最终快照核对初次在旧Chat29份报告计数处失败，记录[原核对失败](assets/B04-T02-qualifier-snapshot-first-failure.json)；v5实际新增一份缺单位场景。保留原核对器和零请求报告，v2只修正为Chat30并重读已保存零请求结果，最终128份双报告/90请求逐字节通过，716份原文件已封存[最终归档](assets/B04-T02-qualifier-final-archive.json)。这一修正没有修改候选、产品验证器或再次发起真实模型请求。\n'
doc.write_bytes(text.encode())
with (plan/'progress.md').open('ab') as p:
    p.write(b'\nUI interruption completed/pushed8004df0; B04R T02 reopened/started. V5 cross-field qualifier correction implementation RED native0/1 and CLI0/2 then native38/CLI7/fake3/Chat35/Python76 pass. Reused exact source-equal Rust499/binary514ce3... from UI working snapshot; final API84/fake54/Chat35 all pass on same binary. Snapshot initial obsoleteChat29 count failed after zero-call report; v2 preserves it and checks Chat30,128pairs/90requests/716 archivedfiles. Fresh scoped review pending; actual05 driver prepared only, no real call yet; cumulative20314/rem9979686/pending0.\n')
owned=['.gitattributes','crates/noetome-cli/src/extraction_api_config.rs','crates/noetome-cli/src/extraction_api_schema.rs',
       'crates/noetome-cli/src/extraction_api_wire/chat.rs','crates/noetome-cli/tests/extraction_api.rs','scripts/validate_extraction_chat.py',
       'dev-log/tasks.json','dev-log/STATUS.md','dev-log/TODO.md','dev-log/DONE.md','doc/execution/NEXT_STEPS.md',
       'doc/execution/B04-T02_GATEWAY_PLAN.md','doc/technical/EXTRACTION_API_CONTRACT.md','doc/validation/B04-T02.md']
new_files=subprocess.check_output(['git','ls-files','--others','--exclude-standard','doc/validation/assets']).decode().splitlines()
archive_paths=[p for p in new_files if Path(p).name.startswith('B04-T02-')]
subprocess.run(['git','add','--',*owned,*archive_paths],check=True)
names=subprocess.check_output(['git','diff','--cached','--name-only']).decode().splitlines()
assert set(names) <= set(owned+archive_paths), names
assert not any(p.startswith('docs/') or p.startswith('apps/') for p in names), names
for name in archive_paths:
    p=root/name
    raw=p.read_bytes()
    blob=subprocess.check_output(['git','show',':'+name])
    assert raw==blob, name
subprocess.run(['git','diff','--cached','--check'],check=True)
print(json.dumps({'staged_files':len(names),'exact_new_api_archives':len(archive_paths),'unrelated_paths_staged':False}))
