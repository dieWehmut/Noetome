"""Stage current v6 final and actual06 evidence without user deletions."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def git(*args):
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, check=True).stdout

summary = read(PLAN / "root-revision-workspace-summary.json")
assert summary["records"][-1]["passed"] == 502
assert sha((ROOT / "target/debug/noetome.exe").read_bytes()) == summary["binary_sha256"]
assert all(sha((ROOT / p).read_bytes()) == s for p, s in summary["source_sha256"].items())
assets = []
for manifest in ["B04-T02-revision-final-archive.json", "B04-T02-live-sixth-archive.json"]:
    path = ASSETS / manifest
    for item in read(path)["records"]:
        target = ROOT / item["path"]
        raw = target.read_bytes()
        assert sha(raw) == item["sha256"] and len(raw) == item["byte_length"]
        assets.append(item["path"])
    assets.append(path.relative_to(ROOT).as_posix())
fixed = [".gitattributes", "doc/execution/NEXT_STEPS.md", "doc/requirements/MODEL_SERVICE.md", "doc/validation/B04-T02.md"]
links = 0
for name in fixed[1:]:
    path = ROOT / name
    for target in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
        if re.match(r"https?://|#", target):
            continue
        target = target.split("#", 1)[0]
        assert (path.parent / target).resolve().exists(), (name, target)
        links += 1
line = "\nTask2 v6 fresh scoped review SPEC/QUALITY PASS30 evidence checks; minor NEXT_STEPS v5 marker fixed, historical Git notices retained. Final source-equal Rust502/Python76/fmt/check/API84/fake54/Chat37 and130pairs/92requests/728files passed on4ce92d8... . One actual06 HTTP200/stop exit0 candidates_validated1atom/1evidence;1792+4512=6304 settled cumulative30097/rem9969903/pending0. Independent originalpayload/Schemachanges/revisions/UTF8/dualreports/source/gold/SQL/five prior responses verification passes. Literal gold complete measurement collection diagnostic0, reasoning16715B and alias-only metadata retain not_run/pending/false; T03 independent assessment required. Current final wholebranch review and devlog completion/push pending; no further real call.\n"
with (PLAN / "progress.md").open("a", encoding="utf-8", newline="\n") as handle:
    handle.write(line)
paths = sorted(set(fixed + assets))
git("add", "--", *paths)
staged = git("diff", "--cached", "--name-only").decode().splitlines()
assert set(staged) <= set(paths) and not any(p.startswith("docs/") for p in staged)
for path in assets:
    assert git("show", ":" + path) == (ROOT / path).read_bytes(), path
check = subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, capture_output=True)
assert check.returncode == 0, check.stdout + check.stderr
print(json.dumps({"staged_files": len(staged), "exact_archives": len(set(assets)), "local_links_checked": links, "diff_check_exit": 0}))
