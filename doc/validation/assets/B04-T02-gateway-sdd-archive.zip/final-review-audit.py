"""Final reviewer: local read-only audit of the selected immutable branch evidence.

Writes only final-review evidence. Never builds, launches CLI, reads credentials,
reads user settings, or accesses HTTP. All inspected sources were selected by task.
"""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / 'doc/validation/assets'
BASE = 'd1a46df397d58b2f4fedd5b3aecd8a67dcebad03'
HEAD = 'e7002e8d47cc3bcee5c244bfacac2e91e143ee86'
EXPECTED_BINARY = 'b66463d89114fae5a6743626a34930a51495277755a4fcb7d0cb4268b4ac1f2b'
OPENAI = 'openai-responses-strict-json-schema-v1'
SELECTED = 'tangmao-deepseek-responses-json-schema-v1'
checks = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def asset(name):
    return read(ASSETS / ('B04-T02-' + name + '.json'))

def require(value, label):
    if not value:
        raise AssertionError(label)
    checks.append(label)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def schema_closed(node):
    if isinstance(node, dict):
        if node.get('type') == 'object':
            require(node.get('additionalProperties') is False, 'schema object closed')
            require(set(node.get('required', [])) == set(node.get('properties', {})), 'schema required complete')
        for value in node.values():
            schema_closed(value)
    elif isinstance(node, list):
        for value in node:
            schema_closed(value)

require(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'immutable HEAD observed')
status_before = git('status', '--short').decode()
changed = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
changed_fingerprints = []
for name in changed:
    raw = (ROOT / name).read_bytes()
    committed = git('show', HEAD + ':' + name)
    require(raw.replace(b'\r\n', b'\n') == committed.replace(b'\r\n', b'\n'), 'immutable file: ' + name)
    changed_fingerprints.append({'path': name, 'sha256': sha(raw), 'byte_length': len(raw)})
require(not git('diff', '--check', BASE, HEAD), 'whole immutable range whitespace gate')
binary_before = sha((ROOT / 'target/debug/noetome.exe').read_bytes())
require(binary_before == EXPECTED_BINARY, 'final executable fingerprint')

summary = asset('selected-workspace-build-verification')
require(summary['binary_sha256'] == binary_before, 'summary uses current executable')
for name, entry in summary['sources'].items():
    require(sha((ROOT / name).read_bytes()) == entry['workspace_sha256'], 'native source fingerprint: ' + name)
counts = collections.Counter()
schemas = []
report_fingerprints = []
for record in summary['reports']:
    path = ROOT / record['path']
    require(path.resolve().is_relative_to(PLAN), 'report stays in selected plan')
    raw = path.read_bytes()
    markdown = path.with_suffix('.md').read_bytes()
    require(sha(raw) == record['json_sha256'], 'report JSON hash: ' + record['path'])
    require(sha(markdown) == record['markdown_sha256'], 'report Markdown hash: ' + record['path'])
    report = json.loads(raw)
    blocks = re.findall(r'```json\s*\n(.*?)\n```', markdown.decode('utf-8'), flags=re.S)
    require(len(blocks) == 1 and json.loads(blocks[0]) == report, 'full dual-report equality: ' + record['path'])
    require(report['knowledge_status'] == 'pending' and report['published'] is False and report['scientific_quality'] == 'not_run', 'no knowledge/science/publication claim')
    counts[record['kind']] += 1
    report_fingerprints.append({'path': record['path'], 'sha256': sha(raw), 'markdown_sha256': sha(markdown)})
    if record['kind'] == 'fake':
        require(report['producer'] == 'fake', 'fake report identified')
        continue
    body_raw = (path.parent / 'request-body.json').read_bytes()
    request_raw = (path.parent / 'request.json').read_bytes()
    request, body = json.loads(request_raw), json.loads(body_raw)
    require(sha(body_raw) == record['body_sha256'] and sha(request_raw) == record['request_sha256'], 'request/body saved hashes')
    require(request['request_body'] == {'sha256': sha(body_raw), 'byte_length': len(body_raw)}, 'request actual body receipt')
    require(request['input_reserved_tokens'] == len(body_raw) + 1024, 'actual body input reservation')
    require(request['reserved_tokens'] == len(body_raw) + 1024 + body['max_output_tokens'], 'total reservation')
    require(report['usage']['reserved_tokens'] == request['reserved_tokens'] and report['usage']['input_reserved_tokens'] == request['input_reserved_tokens'], 'report reservation equality')
    require(report['usage']['request_utf8_bytes'] == len(body_raw), 'report actual request bytes')
    require(report['endpoint'] == request['endpoint'] == record['endpoint'], 'endpoint audit equality')
    require(body['model'] == request['configured_model'] == report['configured_model'], 'configured model equality')
    require(body['store'] is False and body['stream'] is False and body['tools'] == [] and body['tool_choice'] == 'none', 'bounded request switches')
    fmt = body['text']['format']
    require(fmt['type'] == 'json_schema' and fmt['name'] == 'noetome_candidates_v1', 'format schema name')
    schemas.append(fmt['schema'])
    content = json.loads(body['input'])
    require(content['binding'] == request['binding'] == report['binding'] and content['request_id'] == request['request_id'] == report['request_id'], 'source and request identity')
    require(content['units'] == request['units'], 'request units match actual serialized input')
    require(len(content['units']) == len(content['evidence_anchors']), 'one full anchor per unit')
    for unit, anchor in zip(content['units'], content['evidence_anchors']):
        require(anchor == {'unit_id': unit['unit_id'], 'excerpt_start_byte': unit['start_byte'], 'excerpt_end_byte': unit['end_byte'], 'excerpt_sha256': sha(unit['text'].encode()), 'quote': unit['text']}, 'absolute UTF8 anchor byte binding')
    if record['kind'] == 'selected_zero':
        require(report['request_strategy'] == request['request_strategy'] == record['request_strategy'] == SELECTED, 'selected strategy audit equality')
        require(body['model'] == 'deepseek-flash' and request['endpoint'] == 'https://ai.1343263.xyz/v1/responses', 'selected exact model and endpoint')
        require(body['reasoning'] == {'effort': 'none'} and 'strict' not in fmt, 'selected reasoning and schema mode')
        require(not {'background', 'service_tier', 'truncation'} & set(body), 'unsupported selected fields absent')
        require(report['usage']['network_attempts'] == report['usage']['real_model_calls'] == 0 and report['actual_model'] is None, 'selected preflight zero calls')
        require(request['budget']['max_requests'] == 0 and report['errors'][0]['code'] == 'EXTRACT_BUDGET_STOP', 'selected zero-budget stop')
        require(not (path.parent / 'candidates.json').exists(), 'selected has no fabricated candidates')
    else:
        require(report['request_strategy'] == request['request_strategy'] == record['request_strategy'] == OPENAI, 'official/local strategy unchanged')
        require(fmt['strict'] is True and body['background'] is False and body['service_tier'] == 'default' and body['truncation'] == 'disabled' and 'reasoning' not in body, 'official/local request policy')
require(counts == {'local_http': 59, 'selected_zero': 1, 'fake': 38}, '98 reports counted from bytes')
require(all(schema == schemas[0] for schema in schemas), '60 API requests have identical domain schema')
schema_closed(schemas[0])

matrices = []
for kind, expected_checks, expected_calls in [('api', 84, 90), ('fake', 54, 60)]:
    data = asset('selected-' + kind + '-workspace-build')
    require(data['binary_sha256'] == binary_before, kind + ' matrix final executable')
    require(len(data['checks']) == expected_checks and all(c['passed'] for c in data['checks']), kind + ' all checks passed')
    require(len(data['calls']) == expected_calls, kind + ' raw CLI calls counted')
    before, after = data['source_inventory_before'], data['source_inventory_after']
    require(all(after.get(k) == v for k, v in before.items()), kind + ' existing source inventory unchanged')
    require(set(after) - set(before) == set(data.get('controlled_source_scene_files', [])), kind + ' additions match controlled scenes only')
    require(data['source_sql_before'] == data['source_sql_after'], kind + ' source SQL equality')
    if kind == 'api':
        receipts = [r for c in data['checks'] for r in c.get('server_receipts', [])]
        require(sum(c['local_post_count'] for c in data['checks']) == len(receipts) == 54, '54 actual local POST receipts')
        require(all(r['method'] == 'POST' and r['path'] == '/v1/responses' and r['authorization_matches_artificial_test_key'] for r in receipts), 'local receipt method path synthetic authorization')
        require(data['real_model_calls'] == data['paid_calls'] == 0, 'local matrix zero real/paid calls')
    matrices.append({'kind': kind, 'checks': expected_checks, 'calls': expected_calls})

full = asset('selected-workspace-tests')
native = full['native_output'].encode('utf-8')
require(len(native) == full['raw_byte_length'] == 46019 and sha(native) == full['raw_sha256'] == 'd281c355f2aa4b2c5bec610b3201be0c070f0b769d4c5388b70ff728895c6aa6', '484 raw log exact size/hash')
require(native == (PLAN / 'root-workspace-tests.txt').read_bytes(), '484 raw bytes match original retained log')
suites = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', full['native_output'])
require(sum(int(p) for p, _, _ in suites) == 484 and all(f == i == '0' for _, f, i in suites), '484 passed zero failed/ignored counted from raw suites')
python_log = (ASSETS / 'B04-T02-selected-python.txt').read_text(encoding='utf-8')
require('Ran 76 tests' in python_log and '\nOK' in python_log, '76 Python completion evidence')
credential_log = (ASSETS / 'B04-T02-credential-fix-green-full.txt').read_text(encoding='utf-8')
require('Ran 32 tests' in credential_log and '\nOK' in credential_log and credential_log.count(' ... ok') == 32, '32 real Windows credential tests raw log')
for kind in ['native', 'cli']:
    red = asset('selected-' + kind + '-red')
    require(red['exit_code'] != 0 and 'EXTRACT_API_ENDPOINT' in red['output'] and '1 failed' in red['output'], kind + ' actual historical RED retained')
red = asset('credential-fix-red')
require('FAILED' in red['native_output'], 'credential hardlink actual historical failure retained')

primary = []
for record in asset('selected-service-interface')['official_deepseek_sources']:
    raw = (ROOT / 'target/gateway-primary-docs-20261103' / ('raw-' + record['url'].rsplit('/', 1)[-1])).read_bytes()
    require(len(raw) == record['byte_length'] and sha(raw) == record['download_sha256'], 'retained public primary source fingerprint: ' + record['url'])
    primary.append({'url': record['url'], 'sha256': sha(raw), 'byte_length': len(raw)})

preparation = asset('live-preparation')
for name, fingerprint in preparation['artifacts'].items():
    raw = (ASSETS / name).read_bytes()
    require(len(raw) == fingerprint['byte_length'] and sha(raw) == fingerprint['raw_sha256'], 'pre-call retained artifact hash: ' + name)
source = asset('live-source-before')
project = Path(source['project'])
require(project.resolve().is_relative_to(ROOT / 'target/compiler-temp'), 'selected source test project only')
current_files = {str(p.relative_to(project)): {'sha256': sha(p.read_bytes()), 'byte_length': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns} for p in project.rglob('*') if p.is_file()}
require(current_files == source['project_files'], 'all five selected source files SHA size mtime inventory still equal to 04:58 capture')
require(sha((ROOT / 'fixtures/extraction-gateway-v1/source.txt').read_bytes()) == source['source_sha256'], 'author source unchanged')
require(sha((ASSETS / 'B04-T02-live-gold-before.json').read_bytes()) == source['gold_sha256'], 'author gold retained before calls')
zero = asset('selected-zero-workspace-build')
require(zero['binary_sha256'] == binary_before and zero['exit_code'] == 3 and zero['network_attempts'] == zero['model_calls'] == 0, 'latest selected preflight final build and zero calls')
persistence = asset('model-service-persistence')
require(persistence['approved_total_tokens'] == persistence['remaining_tokens'] == 10000000 and persistence['accounted_tokens'] == persistence['pending_reserved_tokens'] == persistence['model_attempts'] == 0, 'archived cumulative budget remains 10M with zero used/pending')
tasks = {t['id']: t for t in read(ROOT / 'dev-log/tasks.json')['tasks']}
require(tasks['B04-T02']['status'] == 'blocked' and tasks['B04-T03']['status'] == 'todo', 'honest task acceptance gates')
require(sum(t['status'] == 'in_progress' for t in tasks.values()) == 0, 'no unintended phase advancement')
require(sha((ROOT / 'target/debug/noetome.exe').read_bytes()) == binary_before, 'executable unchanged during final review')
require(git('status', '--short').decode() == status_before, 'tracked checkout and user deletions unchanged')
result = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'base': BASE, 'head': HEAD,
          'audit_assertions_passed': len(checks), 'current_binary_sha256': binary_before,
          'changed_files': changed_fingerprints, 'report_counts': dict(counts), 'report_fingerprints': report_fingerprints,
          'regression_matrices': matrices, 'raw_workspace_tests': {'passed': 484, 'failed': 0, 'ignored': 0, 'suites': len(suites), 'byte_length': len(native), 'sha256': sha(native)},
          'python_saved_evidence': {'passed': 76, 'credential_tests': 32}, 'public_primary_retained_sources': primary,
          'source_preparation_unchanged': True, 'git_status': status_before,
          'fresh_model_calls': 0, 'fresh_cli_calls': 0, 'fresh_credential_reads': 0,
          'limits': ['Fresh read-only audit of saved actual executions; no builds or test/CLI reruns.', 'No actual credentials or external local settings read.', 'Operator Save, gateway live response, pricing and scientific correctness remain unverified.']}
(PLAN / 'final-review-evidence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'assertions_passed': len(checks), 'changed_files': len(changed), 'reports': dict(counts), 'binary_sha256': binary_before, 'raw_rust_passed': 484, 'read_only': True}))
