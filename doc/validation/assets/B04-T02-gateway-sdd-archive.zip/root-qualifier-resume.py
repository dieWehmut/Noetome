import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT/'doc/validation/assets'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def write_new(p, raw):
    if p.exists(): assert p.read_bytes() == raw, p
    else: p.write_bytes(raw)
def save(p, value): write_new(p,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())

summary = read(ASSETS/'B04U-T01-workspace-summary.json')
assert summary['passed'] == 499
worker = read(PLAN/'qualifier-fix-artifacts.json')['files']
for relative, digest in summary['source_sha256'].items():
    assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest() == digest, relative
    if relative in worker: assert worker[relative]['sha256'] == digest
assert hashlib.sha256((ROOT/'target/debug/noetome.exe').read_bytes()).hexdigest() == summary['binary_sha256']
records=[]
for label in ('fmt','check','workspace-tests'):
    value=read(ASSETS/f'B04U-T01-{label}.json')
    assert value['exit_code']==0
    records.append({k:v for k,v in value.items() if k not in ('stdout','stderr','result_rows','command')})
    write_new(PLAN/f'root-qualifier-{label}.json',(ASSETS/f'B04U-T01-{label}.json').read_bytes())
compat=dict(summary,records=records,source_validation_reused_from='B04U-T01 shared working tree; exact v5 source/binary equality checked',network_model_calls=0)
save(PLAN/'root-qualifier-workspace-summary.json',compat)
for p in sorted(PLAN.glob('qualifier-fix-*.json')):
    write_new(ASSETS/('B04-T02-'+p.name),p.read_bytes())
write_new(ASSETS/'B04-T02-qualifier-fix-report.md',(PLAN/'qualifier-fix-report.md').read_bytes().replace(b'\r\n',b'\n').rstrip(b'\n')+b'\n')
for src,name in [('root-qualifier-cli-red.json','qualifier-cli-red.json'),('root-qualifier-prototype-chat-command.json','qualifier-prototype-chat-command.json'),
                 ('root-qualifier-prototype-chat/audit.json','qualifier-prototype-chat-audit.json'),('root-qualifier-python-tests.json','qualifier-python-tests.json')]:
    write_new(ASSETS/('B04-T02-'+name),(PLAN/src).read_bytes())
patch=(PLAN/'qualifier-fix-source.patch').read_bytes()
save(ASSETS/'B04-T02-qualifier-fix-source-patch.json',{'source':'.superpowers/sdd/B04-T02_GATEWAY_PLAN/qualifier-fix-source.patch','sha256':hashlib.sha256(patch).hexdigest(),'bytes':len(patch),'text':patch.decode('utf-8')})
for source,name in [('root-shape-final-matrix.py','root-qualifier-final-matrix.py'),('root-shape-snapshot-check.py','root-qualifier-snapshot-check.py'),('root-shape-final-archive.py','root-qualifier-final-archive.py')]:
    text=(PLAN/source).read_text(encoding='utf-8').replace('root-shape','root-qualifier').replace('shape-final','qualifier-final')
    text=text.replace('final v4','final v5').replace('== 498','== 499').replace('== 127','== 128').replace('== 89','== 90')
    text=text.replace('("chat", 34)','("chat", 35)').replace('"chat": 34','"chat": 35')
    text=text.replace('"chat": 36','"chat": 37').replace('("chat", 34, 36)','("chat", 35, 37)')
    text=text.replace('tangmao-deepseek-chat-nested-atoms-v4','tangmao-deepseek-chat-qualifiers-v5')
    text=text.replace('"report_pairs": 127','"report_pairs": 128').replace('"request_records": 89','"request_records": 90')
    if source == 'root-shape-final-archive.py':
        text=text.replace('shape-cli-red','qualifier-cli-red')
        text=text.replace('"root-qualifier-workspace-checks.py", "qualifier-final-workspace-source.json"','"root-qualifier-resume.py", "qualifier-final-workspace-source.json"')
        text=text.replace('"root-live-fourth.py", "live-fourth-controller-source.json"','"root-live-fifth.py", "live-fifth-controller-source.json"')
    write_new(PLAN/name,text.encode())
save(PLAN/'root-qualifier-resume-source-check.json',{'actual_source_commit':summary['source_commit'],'binary_sha256':summary['binary_sha256'],'rust_passed':499,'source_sha256':summary['source_sha256'],'repeated_cargo':False,'model_calls':0})
print(json.dumps({'reused_rust_passed':499,'binary_sha256':summary['binary_sha256'],'worker_source_match':True,'model_calls':0}))
