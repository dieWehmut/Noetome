"""Controller final source validation; no model, actual credential, or network work."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PWSH = Path("C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe")
env = dict(os.environ)
env["NOETOME_PDF_PYTHON"] = sys.executable
env["NOETOME_TEST_PYTHON"] = sys.executable
env["CARGO_TERM_COLOR"] = "never"
commands = [
    ("fmt", ".\\scripts\\cargo_local.ps1 fmt --all --check"),
    ("check", ".\\scripts\\cargo_local.ps1 check --workspace --locked --offline"),
    ("workspace-tests", ".\\scripts\\cargo_local.ps1 test --workspace --locked --offline '--' --test-threads=4"),
]
records = []
for name, command in commands:
    path = OUT / ("root-chat-" + name + ".json")
    assert not path.exists(), path
    argv = [str(PWSH), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", "& " + command + "; exit $LASTEXITCODE"]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
    stdout, stderr = result.stdout.decode("utf-8"), result.stderr.decode("utf-8")
    combined = stdout + stderr
    item = {
        "command": argv, "started_at": started,
        "elapsed_seconds": time.monotonic() - clock, "exit_code": result.returncode,
        "stdout": stdout, "stderr": stderr,
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
    }
    if name == "workspace-tests":
        rows = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored", combined)
        item["result_rows"] = [[int(v) for v in row] for row in rows]
        item["passed"] = sum(int(row[0]) for row in rows)
        item["failed"] = sum(int(row[1]) for row in rows)
        item["ignored"] = sum(int(row[2]) for row in rows)
    path.write_text(json.dumps(item, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    records.append({k: v for k, v in item.items() if k not in ("stdout", "stderr", "result_rows", "command")})
    print(json.dumps({"step": name, "exit_code": result.returncode, "elapsed_seconds": item["elapsed_seconds"], "passed": item.get("passed"), "evidence": str(path)}, ensure_ascii=False), flush=True)
    if result.returncode != 0:
        print(combined[-5000:], flush=True)
        raise SystemExit(result.returncode)
binary = ROOT / "target/debug/noetome.exe"
summary = {
    "completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
    "records": records, "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
    "binary_byte_length": binary.stat().st_size, "rust_test_threads": 4,
    "network_model_calls": 0,
}
assert records[-1]["passed"] == 497 and records[-1]["failed"] == records[-1]["ignored"] == 0, records[-1]
path = OUT / "root-chat-workspace-summary.json"
assert not path.exists(), path
path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False), flush=True)
