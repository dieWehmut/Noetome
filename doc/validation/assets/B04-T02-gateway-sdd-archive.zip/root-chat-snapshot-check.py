"""Current Chat and retained Responses/fake byte-level independent verification."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
CHAT = "tangmao-deepseek-chat-json-object-no-thinking-v3"
sys.path.insert(0, str(ROOT / "scripts"))
from validate_extraction_gateway import sql_snapshot

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

before = read(LIVE / "source-before.json")
project = Path(before["project"]).resolve()
assert project.is_relative_to(ROOT / "target/compiler-temp")
def source_guard():
    files = {str(p.relative_to(project)): {"sha256": sha(p.read_bytes()), "byte_length": p.stat().st_size, "mtime_ns": p.stat().st_mtime_ns} for p in project.rglob("*") if p.is_file()}
    assert files == before["project_files"]
    assert sha("\n".join(sql_snapshot(project)).encode()) == before["project_sql_sha256"]
    for p in [LIVE / "gold-before.json", ROOT / "fixtures/extraction-gateway-v1/expected.json"]:
        assert sha(p.read_bytes()) == before["gold_sha256"]
    assert sha((ROOT / "fixtures/extraction-gateway-v1/source.txt").read_bytes()) == before["source_sha256"]
    return files

files = source_guard()
summary = read(OUT / "root-chat-workspace-summary.json")
binary = ROOT / "target/debug/noetome.exe"
assert sha(binary.read_bytes()) == summary["binary_sha256"]
audits = {name: read(OUT / ("root-chat-final-" + name) / file) for name, file in [("api", "audit.json"), ("fake", "evidence.json"), ("chat", "audit.json")]}
for name, checks, calls in [("api", 84, 90), ("fake", 54, 60), ("chat", 34, 36)]:
    a = audits[name]
    assert len(a["checks"]) == checks and len(a["calls"]) == calls
    assert a["binary_sha256"] == summary["binary_sha256"] and a["source_sql_before"] == a["source_sql_after"]
    assert a["scientific_quality"] == "not_run"
    if name != "fake":
        assert a["real_model_calls"] == a["paid_calls"] == 0

config = LIVE / "api-chat-preflight-config.json"
config_raw = config.read_bytes()
assert read(config)["budget"]["max_requests"] == 0
zero = OUT / "root-chat-selected-zero"
assert not zero.exists()
argv = [str(binary), "extract", "api", str(project), before["import_id"], str(config), str(zero)]
env = dict(os.environ)
env["NOETOME_TANGMAO_API_KEY"] = "noetome-test-selected-chat-zero-budget"
result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
save(OUT / "root-chat-selected-zero-command.json", {"command": argv, "exit_code": result.returncode, "stdout": result.stdout.decode("utf-8"), "stderr": result.stderr.decode("utf-8"), "binary_sha256": summary["binary_sha256"]})
assert result.returncode == 3
report = read(zero / "validation.json")
assert report["errors"][0]["code"] == "EXTRACT_BUDGET_STOP"
assert report["usage"]["network_attempts"] == report["usage"]["real_model_calls"] == 0
assert report["provider"] == "openai_chat_completions" and report["request_strategy"] == CHAT
assert config.read_bytes() == config_raw
source_guard()

reports, requests = [], []
counts = collections.Counter()
roots = [(name, OUT / ("root-chat-final-" + name)) for name in ["api", "fake", "chat"]] + [("selected-zero", zero)]
for kind, root in roots:
    for path in sorted(root.rglob("validation.json")):
        r = read(path)
        md = path.with_suffix(".md").read_bytes()
        blocks = re.findall(r"```json\s*\n(.*?)\n```", md.decode("utf-8"), re.S)
        assert len(blocks) == 1 and json.loads(blocks[0]) == r
        assert r["knowledge_status"] == "pending" and r["published"] is False and r["scientific_quality"] == "not_run"
        for name, fingerprint in r["artifacts"].items():
            raw = (path.parent / name).read_bytes()
            assert sha(raw) == fingerprint["sha256"] and len(raw) == fingerprint["byte_length"]
        counts[kind] += 1
        reports.append({"kind": kind, "path": path.relative_to(ROOT).as_posix(), "json_sha256": sha(path.read_bytes()), "markdown_sha256": sha(md)})
        if kind == "fake":
            assert r["producer"] == "fake"
            continue
        body_raw = (path.parent / "request-body.json").read_bytes()
        body = json.loads(body_raw)
        request = read(path.parent / "request.json")
        if kind in ["chat", "selected-zero"]:
            assert r["provider"] == "openai_chat_completions" and r["request_strategy"] == request["request_strategy"] == CHAT
            assert body["thinking"] == {"type": "disabled"} and body["response_format"] == {"type": "json_object"}
            assert [m["role"] for m in body["messages"]] == ["system", "user"]
            user = json.loads(body["messages"][1]["content"])
            assert set(user) == {"task", "response_schema", "request"}
            assert user["task"].startswith(body["messages"][0]["content"])
            assert user["response_schema"]["additionalProperties"] is False
            inner, output_cap = user["request"], body["max_tokens"]
        else:
            assert r["request_strategy"] == request["request_strategy"] == "openai-responses-strict-json-schema-v1"
            assert body["text"]["format"]["strict"] is True
            inner, output_cap = json.loads(body["input"]), body["max_output_tokens"]
        assert inner["request_id"] == request["request_id"] and inner["binding"] == request["binding"] and inner["units"] == request["units"]
        for unit, anchor in zip(inner["units"], inner["evidence_anchors"], strict=True):
            assert anchor["excerpt_start_byte"] == unit["start_byte"] and anchor["excerpt_end_byte"] == unit["end_byte"]
            assert anchor["quote"] == unit["text"] and anchor["excerpt_sha256"] == sha(unit["text"].encode())
        assert r["usage"]["request_utf8_bytes"] == len(body_raw)
        assert r["usage"]["input_reserved_tokens"] == len(body_raw) + 1024
        assert r["usage"]["reserved_tokens"] == len(body_raw) + 1024 + output_cap
        requests.append({"path": path.relative_to(ROOT).as_posix(), "body_sha256": sha(body_raw), "request_sha256": sha((path.parent / "request.json").read_bytes()), "strategy": r["request_strategy"]})
assert dict(counts) == {"api": 59, "fake": 38, "chat": 29, "selected-zero": 1}
assert len(reports) == 127 and len(requests) == 89
assert sha(binary.read_bytes()) == summary["binary_sha256"]
source_guard()
evidence = {"completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "binary_sha256": summary["binary_sha256"], "report_counts": dict(counts), "reports": reports, "requests": requests, "source_files": files, "source_original_capture_unchanged": True, "source_sql_sha256": before["project_sql_sha256"], "gold_sha256": before["gold_sha256"], "network_model_calls": 0, "scientific_quality": "not_run"}
save(OUT / "root-chat-snapshot-verification.json", evidence)
print(json.dumps({"report_pairs": len(reports), "request_records": len(requests), "binary_sha256": summary["binary_sha256"], "source_original_capture_unchanged": True, "network_model_calls": 0}))
