"""Archive exact v6 component proof and stage only the current task allowlist."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
PLAN = Path(__file__).resolve().parent
ASSETS = ROOT / "doc/validation/assets"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def git(*args):
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, check=True).stdout

def save_bytes(path, raw):
    if path.exists():
        assert path.read_bytes() == raw, path
    else:
        with path.open("xb") as handle:
            handle.write(raw)

worker = read(PLAN / "revision-fix-artifacts.json")
for item in worker["sources"]:
    raw = (ROOT / item["path"]).read_bytes()
    assert sha(raw) == item["sha256"] and len(raw) == item["bytes"]
assets = []
for item in worker["evidence"]:
    path = ROOT / item["path"]
    raw = path.read_bytes()
    assert sha(raw) == item["sha256"] and len(raw) == item["bytes"]
    name = "revision-fix-report.md" if path.name == "task-2-revision-report.md" else path.name
    target = ASSETS / ("B04-T02-" + name)
    save_bytes(target, raw)
    assets.append(target.relative_to(ROOT).as_posix())
for name in ["revision-fix-artifacts.json", "root-revision-cli-red.json", "root-revision-python-tests.json"]:
    target_name = name.removeprefix("root-")
    target = ASSETS / ("B04-T02-" + target_name)
    save_bytes(target, (PLAN / name).read_bytes())
    assets.append(target.relative_to(ROOT).as_posix())
for name, target_name in [("revision-fix-owned.patch", "revision-fix-source-patch.json"), ("root-revision-cli-red.py", "revision-cli-red-source.json"),
                          ("root-revision-python.py", "revision-python-source.json"), ("root-revision-prepare.py", "revision-preparation-source.json"),
                          ("root-live-sixth.py", "live-sixth-controller-source.json")]:
    path = PLAN / name
    raw = path.read_bytes()
    value = {"source": path.relative_to(ROOT).as_posix(), "source_sha256": sha(raw), "byte_length": len(raw), "source_text": raw.decode("utf-8-sig")}
    target = ASSETS / ("B04-T02-" + target_name)
    save_bytes(target, (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())
    assets.append(target.relative_to(ROOT).as_posix())
assets += ["doc/validation/assets/B04-T02-qualifier-review.md", "doc/validation/assets/B04-T02-qualifier-review-evidence.json"]
assets += [item["path"] for item in read(ASSETS / "B04-T02-live-fifth-failure-archive.json")["records"]]
assets += ["doc/validation/assets/B04-T02-live-fifth-diagnosis-source.json", "doc/validation/assets/B04-T02-live-fifth-failure-archive.json"]
fixed = [".gitattributes", "crates/noetome-cli/src/extraction_api_config.rs", "crates/noetome-cli/src/extraction_api_schema.rs",
         "crates/noetome-cli/src/extraction_api_wire/chat.rs", "crates/noetome-cli/tests/extraction_api.rs", "scripts/validate_extraction_chat.py",
         "doc/execution/B04-T02_GATEWAY_PLAN.md", "doc/execution/NEXT_STEPS.md", "doc/requirements/MODEL_SERVICE.md",
         "doc/technical/EXTRACTION_API_CONTRACT.md", "doc/validation/B04-T02.md"]
line = "\nTask2 v5 fresh899 scoped review passed; actual05 HTTP200/stop failed EXTRACT_KNOWLEDGE with four revision=0 entities, valid3479 settled/cumulative23793/rem9976207/pending0, exact response/source/gold preserved. New v6 selected inline positive revision constraint: ordinary RED0/2 and native RED1/3 (zero-test initial target explicitly excluded), native41/API7/fake3/check/fmt/Python76 pass. Initial root integration format failure retained then only fmt repeated. Fresh scoped review/final source-binary matrices and actual06 pending; no sixth call yet.\n"
with (PLAN / "progress.md").open("a", encoding="utf-8", newline="\n") as handle:
    handle.write(line)
paths = sorted(set(fixed + assets))
git("add", "--", *paths)
staged = git("diff", "--cached", "--name-only").decode().splitlines()
assert set(staged) <= set(paths) and not any(p.startswith("docs/") for p in staged)
for name in assets:
    assert git("show", ":" + name) == (ROOT / name).read_bytes(), "archive normalization: " + name
check = subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, capture_output=True)
assert check.returncode == 0, check.stdout + check.stderr
print(json.dumps({"staged_files": len(staged), "archive_files": len(set(assets)), "exact_archive_bytes": True, "cached_diff_check_exit": 0}))
