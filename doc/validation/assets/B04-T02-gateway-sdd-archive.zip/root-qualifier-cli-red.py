"""Controller author regression before the Chat shape prompt implementation."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent / "root-qualifier-cli-red.json"
PWSH = Path("C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe")
assert not OUT.exists(), OUT
argv = [str(PWSH), "-NoLogo", "-NoProfile", "-NonInteractive", "-Command",
        "& .\\scripts\\cargo_local.ps1 test --test extraction_api ordinary_chat_ --locked --offline '--' --test-threads=4; exit $LASTEXITCODE"]
env = dict(os.environ)
env["CARGO_TERM_COLOR"] = "never"
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
run = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
stdout, stderr = run.stdout.decode("utf-8"), run.stderr.decode("utf-8")
rows = re.findall(r"test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored", stdout + stderr)
record = {"command": argv, "started_at": started, "elapsed_seconds": time.monotonic() - clock,
          "exit_code": run.returncode, "stdout": stdout, "stderr": stderr,
          "stdout_sha256": hashlib.sha256(run.stdout).hexdigest(),
          "stderr_sha256": hashlib.sha256(run.stderr).hexdigest(),
          "result_rows": rows, "model_calls": 0, "paid_calls": 0,
          "production_base": "25bcff5b474611fdb2b1c1f96eb0a33caae42e4d"}
OUT.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
assert run.returncode == 101 and rows == [("0", "2", "0")], record
assert 'task.contains("Include measurement.unit verbatim in atom.qualifiers")' in stdout + stderr
print(json.dumps({"exit_code": run.returncode, "passed": 0, "failed": 2,
                  "reason": "missing explicit cross-field unit qualifier instruction", "evidence": str(OUT)}))
