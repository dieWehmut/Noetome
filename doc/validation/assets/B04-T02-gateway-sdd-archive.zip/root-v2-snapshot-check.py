"""Independent saved-byte, request, dual-report and original-source checks."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
LIVE = ROOT / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
sys.path.insert(0, str(ROOT / "scripts"))
from validate_extraction_gateway import sql_snapshot

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def source_guard():
    before = read(LIVE / "source-before.json")
    project = Path(before["project"]).resolve()
    assert project.is_relative_to(ROOT / "target/compiler-temp")
    files = {str(p.relative_to(project)): {"sha256": sha(p.read_bytes()), "byte_length": p.stat().st_size, "mtime_ns": p.stat().st_mtime_ns} for p in project.rglob("*") if p.is_file()}
    assert files == before["project_files"], "original source SHA/size/mtime/inventory changed"
    assert sha("\n".join(sql_snapshot(project)).encode()) == before["project_sql_sha256"]
    assert sha((ROOT / "fixtures/extraction-gateway-v1/source.txt").read_bytes()) == before["source_sha256"]
    assert sha((LIVE / "gold-before.json").read_bytes()) == before["gold_sha256"]
    assert sha((ROOT / "fixtures/extraction-gateway-v1/expected.json").read_bytes()) == before["gold_sha256"]
    return before, files

summary = read(OUT / "root-v2-workspace-summary.json")
binary = ROOT / "target/debug/noetome.exe"
assert sha(binary.read_bytes()) == summary["binary_sha256"]
before, files = source_guard()
audits = {name: read(OUT / ("root-v2-" + name) / filename) for name, filename in [("api", "audit.json"), ("fake", "evidence.json")]}
assert len(audits["api"]["checks"]) == 84 and len(audits["api"]["calls"]) == 90
assert len(audits["fake"]["checks"]) == 54 and len(audits["fake"]["calls"]) == 60
for name, audit in audits.items():
    assert audit["binary_sha256"] == summary["binary_sha256"]
    assert audit["source_sql_before"] == audit["source_sql_after"]
    assert audit["scientific_quality"] == "not_run"
    if name == "api":
        assert audit["real_model_calls"] == audit["paid_calls"] == 0
    else:
        assert audit["producer"] == "independent_cli_audit"

config = LIVE / "api-preflight-config.json"
config_sha = sha(config.read_bytes())
assert read(config)["budget"]["max_requests"] == 0
zero = OUT / "root-v2-selected-zero"
assert not zero.exists()
argv = [str(binary), "extract", "api", before["project"], before["import_id"], str(config), str(zero)]
env = dict(os.environ)
env["NOETOME_TANGMAO_API_KEY"] = "noetome-test-selected-zero-budget-only"
result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
save(OUT / "root-v2-selected-zero-command.json", {"command": argv, "exit_code": result.returncode, "stdout": result.stdout.decode("utf-8"), "stderr": result.stderr.decode("utf-8"), "binary_sha256": summary["binary_sha256"]})
assert result.returncode == 3
zero_report = read(zero / "validation.json")
assert zero_report["errors"][0]["code"] == "EXTRACT_BUDGET_STOP"
assert zero_report["usage"]["network_attempts"] == zero_report["usage"]["real_model_calls"] == 0
assert zero_report["request_strategy"] == "tangmao-deepseek-responses-inline-json-schema-v2"
assert sha(config.read_bytes()) == config_sha
source_guard()

reports, requests = [], []
counts = collections.Counter()
for kind, root in [("api", OUT / "root-v2-api"), ("fake", OUT / "root-v2-fake"), ("selected-zero", zero)]:
    for path in sorted(root.rglob("validation.json")):
        report = read(path)
        md = path.with_suffix(".md").read_bytes()
        blocks = re.findall(r"```json\s*\n(.*?)\n```", md.decode("utf-8"), re.S)
        assert len(blocks) == 1 and json.loads(blocks[0]) == report, path
        assert report["knowledge_status"] == "pending" and report["published"] is False and report["scientific_quality"] == "not_run"
        for name, fingerprint in report["artifacts"].items():
            raw = (path.parent / name).read_bytes()
            assert sha(raw) == fingerprint["sha256"] and len(raw) == fingerprint["byte_length"], (path, name)
        counts[kind] += 1
        reports.append({"kind": kind, "path": path.relative_to(ROOT).as_posix(), "json_sha256": sha(path.read_bytes()), "markdown_sha256": sha(md)})
        if kind == "fake":
            continue
        body_raw = (path.parent / "request-body.json").read_bytes()
        body = json.loads(body_raw)
        request = read(path.parent / "request.json")
        inner = json.loads(body["input"])
        if kind == "selected-zero":
            assert set(inner) == {"task", "response_schema", "request"}
            assert inner["task"].startswith(body["instructions"]) and "no Markdown" in inner["task"]
            assert inner["response_schema"] == body["text"]["format"]["schema"]
            inner = inner["request"]
            assert body["reasoning"] == {"effort": "none"}
            assert "strict" not in body["text"]["format"]
            assert not (set(body) & {"background", "service_tier", "truncation"})
        else:
            assert request["request_strategy"] == report["request_strategy"] == "openai-responses-strict-json-schema-v1"
            assert body["text"]["format"]["strict"] is True
        assert inner["request_id"] == request["request_id"] and inner["binding"] == request["binding"] and inner["units"] == request["units"]
        for unit, anchor in zip(inner["units"], inner["evidence_anchors"], strict=True):
            assert anchor["excerpt_start_byte"] == unit["start_byte"] and anchor["excerpt_end_byte"] == unit["end_byte"]
            assert anchor["quote"] == unit["text"] and anchor["excerpt_sha256"] == sha(unit["text"].encode("utf-8"))
        usage = report["usage"]
        assert usage["request_utf8_bytes"] == len(body_raw)
        assert usage["input_reserved_tokens"] == len(body_raw) + 1024
        assert usage["reserved_tokens"] == len(body_raw) + 1024 + body["max_output_tokens"]
        requests.append({"path": path.relative_to(ROOT).as_posix(), "body_sha256": sha(body_raw), "request_sha256": sha((path.parent / "request.json").read_bytes()), "strategy": report["request_strategy"]})
assert dict(counts) == {"api": 59, "fake": 38, "selected-zero": 1}, counts
assert len(reports) == 98 and len(requests) == 60
assert sha(binary.read_bytes()) == summary["binary_sha256"]
source_guard()
evidence = {"completed_at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "binary_sha256": summary["binary_sha256"], "report_counts": dict(counts), "reports": reports, "requests": requests, "source_files": files, "source_original_capture_unchanged": True, "source_sql_sha256": before["project_sql_sha256"], "gold_sha256": before["gold_sha256"], "network_model_calls": 0, "scientific_quality": "not_run"}
save(OUT / "root-v2-snapshot-verification.json", evidence)
print(json.dumps({"report_pairs": len(reports), "request_records": len(requests), "binary_sha256": summary["binary_sha256"], "source_original_capture_unchanged": True, "network_model_calls": 0}))
