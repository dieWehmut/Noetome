"""Read-only saved evidence checks; writes only new final-fix probe copies."""
import base64
import copy
import importlib.util
import json
from pathlib import Path

repo = Path("D:/Noetome")
sdk = repo / ".superpowers/sdd/B04-T03_REVIEW_PLAN"
spec = importlib.util.spec_from_file_location("final_fixed_verifier", repo / "scripts/verify_extraction_knowledge.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
review_path = sdk / "final-review-evidence.json"
review_before = v.fingerprint(review_path.read_bytes())
probe = json.loads(review_path.read_bytes())["summaries"]["missing_array_probe"]
files = {name: base64.b64decode(raw) for name, raw in probe["unknown_count_files_base64"].items()}
raw = files["candidates-original.json"]
assert raw == b"{}" and v.fingerprint(raw) == probe["candidate_fingerprint"]
record = {"ordinary_cli_calls": 0, "new_model_calls": 0, "network_calls": 0,
          "review_evidence_before": review_before, "candidate": v.fingerprint(raw), "outcomes": []}
for name, truthful in (("null-count", True), ("fabricated-zero", False)):
    output = sdk / ("final-fix-1-probe-" + name)
    output.mkdir()
    current = dict(files)
    if not truthful:
        current["verification.json"] = base64.b64decode(probe["zero_count_report_base64"])
        current["verification.md"] = b"```json\n" + current["verification.json"] + b"\n```\n"
    for filename, content in current.items():
        (output / filename).write_bytes(content)
    report = json.loads(current["verification.json"])
    source = v.actual_source(repo / "target/compiler-temp/B04-T03-root-original06-01/project 中文", report["binding"]["import_id"], {"kind": "text", "ordinal": 0})
    inputs = {name: current[copied] for name, copied in (("review.json", "review-original.json"), ("candidates.json", "candidates-original.json"), ("gold.json", "gold-original.json"), ("decision.json", "decision-original.json"))}
    outcome = {"name": name, "output": str(output), "fingerprints": {k: v.fingerprint(b) for k, b in current.items()}}
    try:
        outcome["verification"] = v.verify_report(output, raw, inputs["gold.json"], source, inputs)
        assert truthful and outcome["verification"]["candidate_atoms"] is None
        outcome["accepted"] = True
    except AssertionError as error:
        assert not truthful and str(error) == "actual candidate count", (name, str(error))
        outcome.update(accepted=False, error=str(error))
    record["outcomes"].append(outcome)

# Recheck saved final original06 report without repeating the unchanged CLI.
live = repo / "target/compiler-temp/b04-t02-live-v2-d62b632edc08458eb7dcccdfc7a68556"
project = live / "source-project"
final = repo / "target/compiler-temp/B04-T03-root-final-original06-01"
inputs = {name: (final / "case" / name).read_bytes() for name in ("review.json", "candidates.json", "gold.json", "decision.json")}
output = final / "output"
before = {p.name: v.fingerprint(p.read_bytes()) for p in output.iterdir() if p.is_file()}
candidate = v.strict_json(inputs["candidates.json"])
source = v.actual_source(project, candidate["binding"]["import_id"], {"kind": "text", "ordinal": 0})
verified = v.verify_report(output, inputs["candidates.json"], inputs["gold.json"], source, inputs)
assert verified["independently_passed"] and verified["candidate_atoms"] == 1
assert before == {p.name: v.fingerprint(p.read_bytes()) for p in output.iterdir() if p.is_file()}
assert (output / "verification.json").read_bytes() == (repo / "doc/validation/assets/B04-T03-root-final-original06-verification.json").read_bytes()
assert v.fingerprint(review_path.read_bytes()) == review_before
record.update(final_original06_read_only={"output": str(output), "verification": verified, "fingerprints": before, "source_resource_sha256": source["resource_sha256"]}, review_evidence_after=v.fingerprint(review_path.read_bytes()), source=v.fingerprint((repo / "scripts/verify_extraction_knowledge.py").read_bytes()))
v.save(sdk / "final-fix-1-probe-outcomes.json", record)
print(json.dumps({"ordinary_cli_calls": 0, "outcomes": [{k: x for k, x in r.items() if k != "fingerprints"} for r in record["outcomes"]], "final_original06": verified, "original_review_unchanged": True}, ensure_ascii=False))
