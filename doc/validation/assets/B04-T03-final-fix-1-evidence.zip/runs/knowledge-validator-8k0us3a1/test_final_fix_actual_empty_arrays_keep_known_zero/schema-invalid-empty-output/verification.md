# 有界来源知识核对

状态：failed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": null,
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "73c82a4c-855b-4fe6-bd8a-1ef1219b04cd",
      "import_id": "7a45fd01-5ef0-42a9-9b0f-a08cfcf285f3",
      "source_id": "57b5c785-656c-417a-9782-e09715b403f5",
      "version_id": "2ecf8011-24c0-4c76-adc3-4c80c05c0823",
      "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a1fdc16b-d0f2-4188-a419-6fc351ce3c29",
          "ordinal": 0,
          "resource_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 195,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。\n这是独立作者的工程例外测试，不是科学质量基准。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "73c82a4c-855b-4fe6-bd8a-1ef1219b04cd",
    "import_id": "7a45fd01-5ef0-42a9-9b0f-a08cfcf285f3",
    "source_id": "57b5c785-656c-417a-9782-e09715b403f5",
    "version_id": "2ecf8011-24c0-4c76-adc3-4c80c05c0823",
    "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": null,
    "transport_mode": null,
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "4e6ba3074c9a1c7ff1d3dfbece970eab1d69df3520d710470b349f2d32b824e6",
        "byte_length": 39
      },
      "decision.json": {
        "sha256": "44d918d8c2817f4963d8c012dac1d7d2363a7de2cd467494b279395758376020",
        "byte_length": 115
      },
      "gold.json": {
        "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
        "byte_length": 704
      },
      "review.json": {
        "sha256": "22b01f767ee7da4a2b3426faba2eb6e1db59edaaef61ff923596c9165581c5ce",
        "byte_length": 486
      }
    },
    "gold_sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "issue_codes": [
        "VERIFY_MISSING",
        "VERIFY_SCHEMA"
      ]
    }
  ],
  "candidate_results": [],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_SCHEMA",
      "expected": "strict_schema_1",
      "actual": "missing field `schema_version` at line 4 column 3"
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_MISSING",
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 1,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 0,
    "unexpected_atoms": 0,
    "duplicate_atoms": null,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "concept": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "condition": {
      "expected": 2,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 2,
      "status": "unprocessed"
    },
    "content": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "coverage": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "evidence": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "exception": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "schema": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "812bd51d0990260fd4af6def669fe049e0ba700fe56e26af37c71280007813f7",
      "byte_length": 135
    },
    "candidates-original.json": {
      "sha256": "4e6ba3074c9a1c7ff1d3dfbece970eab1d69df3520d710470b349f2d32b824e6",
      "byte_length": 39
    },
    "decision-original.json": {
      "sha256": "44d918d8c2817f4963d8c012dac1d7d2363a7de2cd467494b279395758376020",
      "byte_length": 115
    },
    "gold-original.json": {
      "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
      "byte_length": 704
    },
    "review-original.json": {
      "sha256": "22b01f767ee7da4a2b3426faba2eb6e1db59edaaef61ff923596c9165581c5ce",
      "byte_length": 486
    },
    "source-snapshot.json": {
      "sha256": "e820aa7825cbed3a98def8ca78908ad7cc205f9977bf2989863df8afb07af2e6",
      "byte_length": 1085
    }
  }
}
```
