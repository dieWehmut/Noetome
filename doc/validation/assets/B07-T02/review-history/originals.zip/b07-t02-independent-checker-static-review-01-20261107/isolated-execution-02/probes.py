"""Isolated checker probes only. No product CLI, HTTP or OS kill is invoked."""
from pathlib import Path
import sys,importlib.util,json,sqlite3,hashlib
repo=Path('/home/lyinn/project/Noetome')
base=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(repo/'scripts'))
spec=importlib.util.spec_from_file_location('review_budget_checker',base/'scripts/verify_request_budget.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
audit.ROOT=repo;audit.FIXTURE=repo/'fixtures/run-api-budget-v1'
results={}

# SQLite's own context manager manages a transaction, not the connection lifetime.
db_path=base/'sqlite-context-manager.db'
with sqlite3.connect(db_path) as db:
 db.execute('CREATE TABLE example(value INTEGER)')
 db.execute('INSERT INTO example VALUES(1)')
results['sqlite_context_connection_alive_after_with']=db.execute('SELECT value FROM example').fetchone()==(1,)
db.close()
results['sqlite_closed_explicitly']=False
try: db.execute('SELECT value FROM example')
except sqlite3.ProgrammingError: results['sqlite_closed_explicitly']=True

# Preserve real frozen request originals, and author a deliberately contradictory
# transport/report bundle. This is a checker adversary, not a product execution.
runroot=base/'forged-checker-originals';attempt=runroot/'attempts/unit-a/1';attempt.mkdir(parents=True)
rawbody=(audit.FIXTURE/'originals/core05-request-body-a.json').read_bytes()
bound=audit.request_body_check(rawbody,audit.FIXTURE)
metadata=audit.strict_json((audit.FIXTURE/'originals/preflight-api-a/request.json').read_bytes())
metadata['endpoint']='http://127.0.0.1:9/v1/responses'
metadata['request_id']=bound['request_id']
request_id=bound['request_id']
(attempt/'request-body.json').write_bytes(rawbody)
(attempt/'request.json').write_bytes(audit.canonical(metadata))
(attempt/'.owner.json').write_bytes(audit.canonical({'producer':'api','purpose':'unpublished_extraction_test','request_id':request_id,'schema_version':1,'transport_mode':'local_http_test'}))
transport={'schema_version':1,'producer':'synthetic_api_transport_receipt','request_id':request_id,'http_status':200,'http_request_id':None,'response_complete':True,'network_attempts':1,'response':{'sha256':audit.sha(b'unsafe artificial credential echo'),'byte_length':len(b'unsafe artificial credential echo')},'response_file':None,'error_code':'EXTRACT_API_CREDENTIAL_ECHO','omission_reason':'omitted_credential_echo','elapsed_ms':8}
(attempt/'transport-receipt.json').write_bytes(audit.canonical(transport))
report=audit.strict_json((audit.FIXTURE/'originals/preflight-api-a/validation.json').read_bytes())
report.update(request_id=request_id,published=False,knowledge_status='pending',scientific_quality='not_run',status='failed',validated_atoms=0,http_status=None,response_complete=False,response_id=None,http_request_id=None)
report['usage'].update(network_attempts=0,real_model_calls=0,paid_calls=0,price_usd=None,model_tokenizer=None,model_usage=None)
report['errors']=[{'code':'EXTRACT_API_CREDENTIAL_ECHO','message':'isolated checker forgery, never an actual network result'}]
report['artifacts']={p.name:{'sha256':audit.sha(p.read_bytes()),'byte_length':p.stat().st_size} for p in attempt.iterdir()}
report_bytes=audit.canonical(report)
(attempt/'validation.json').write_bytes(report_bytes)
(attempt/'validation.md').write_text('Isolated checker adversary.\n```json\n'+report_bytes.decode()+'\n```\n')
plan={'key':{'run_id':'10000000-0000-4000-8000-000000000001','unit_id':'unit-a','attempt_no':1,'request_id':request_id},'attempt_root':'attempts/unit-a/1','request_body':{'sha256':audit.sha(rawbody),'byte_length':len(rawbody)},'request_metadata':{'sha256':audit.sha((attempt/'request.json').read_bytes()),'byte_length':(attempt/'request.json').stat().st_size},'input_reserved_tokens':6262,'max_output_tokens':2048,'reserved_tokens':8310,'reservation_policy':'request_utf8_bytes_plus_1024_v1'}
receipt={'report':{'sha256':audit.sha(report_bytes),'byte_length':len(report_bytes)},'response':None,'network_attempts':0,'http_status':None,'response_complete':False,'response_id':None,'http_request_id':None,'usage':None,'candidate_status':'failed','error_code':'EXTRACT_API_CREDENTIAL_ECHO','elapsed_ms':0,'price_usd':None}
original={'plan':plan,'identity':{'root':audit.paths.actual_identity(attempt),'parent':audit.paths.actual_identity(attempt.parent),'directories':{p:audit.paths.actual_identity(runroot/p) for p in ['attempts','attempts/unit-a','attempts/unit-a/1']}},'files':{p.name:audit.observed_stamp(p)[0] for p in attempt.iterdir()},'transport_sealed':True,'state':'not_sent','receipt':receipt}
run={'spec':{'run_root':str(runroot)},'inputs_changed':True,'outcome':'invalidated'}
try:
 evidence=audit.verify_attempt_originals(original,run,audit.FIXTURE)
 results['contradictory_network1_transport_network0_receipt_accepted']=True
 results['contradictory_bundle_evidence']=evidence
except Exception as error:
 results['contradictory_network1_transport_network0_receipt_accepted']=False
 results['contradictory_bundle_rejection']={'type':type(error).__name__,'message':str(error)}
results['scope']={'source':'exact copied checker snapshot','hand_authored_contradictory_bundle':True,'source_semantic_check_skipped_by_existing_invalidated_input_branch':True,'product_CLI_count':0,'HTTP_requests':0,'OS_kills':0,'models':0,'not_a_product_acceptance':True}
(base/'isolated-probes.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(results,ensure_ascii=False))
