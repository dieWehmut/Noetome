from pathlib import Path
import hashlib,json,stat,zipfile,time
BASE=Path('/home/lyinn/project/Noetome/.artifacts')
OUT=BASE/'b07-t02-independent-behavior-review-04-20261107/package'
OUT.mkdir(exist_ok=False)
sources={}
for num in [1,2,3,4]:
    parent=BASE/f'b07-t02-independent-behavior-review-{num:02d}-20261107'
    for name in ['audit.py','actual.json','stdout.bin','stderr.bin']:
        sources[f'attempt{num:02d}/{name}']=parent/name
for name in ['README.md','pair-and-incoming-readback.json','package.py']:
    sources['final/'+name]=BASE/'b07-t02-independent-behavior-review-04-20261107'/name
cleanup=BASE/'b07-t02-independent-import-cache-cleanup-20261107'
for p in sorted(cleanup.iterdir()):sources['import-cache-cleanup/'+p.name]=p
def pin(path):
    s=path.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
    b=path.read_bytes();t=path.lstat()
    assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
    return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
before={};manifest={}
archive=OUT/'originals.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sources.items():
        b,fp=pin(p);before[name]=fp;z.writestr(name,b)
        manifest[name]={'original_path':str(p),'original_pin':fp,'sha256':fp['sha256'],'byte_length':len(b)}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(sources)
    for name,p in sources.items():
        b,fp=pin(p);member=z.read(name)
        assert fp==before[name] and member==b and hashlib.sha256(member).hexdigest()==manifest[name]['sha256'] and len(member)==manifest[name]['byte_length']
        manifest[name]['CRC_SHA_length_actual_original_before_after_equal']=True
(OUT/'manifest.json').write_text(json.dumps({'schema_version':1,'members':manifest},indent=2)+'\n')
a={'producer':'independent_readonly_behavior_evidence_package','status':'passed','members':len(manifest),'all_full_member_CRC_SHA_length_readback_passed':True,'actual_original_identity_mtime_bytes_before_after_equal':True,'archive':pin(archive)[1],'manifest':pin(OUT/'manifest.json')[1],'full03_scope':{'ordinary_CLI':364,'explicit_driver':33,'distinct_recorded_PIDs':397,'real_OS_kill_wait_exit_minus9':23,'groups':62,'actual_HTTP_complete_incoming_and_UUID_receipts':70,'valid_flow_SQL_events':511,'valid_flow_ledgers':39,'protection_groups':23,'fixed_source_members':130},'old_full02_failed_scope_preserved':True,'own_import_failures_cache_creation_and_cleanup_limitation_preserved':True,'product_HTTP_or_Cargo_invocations_by_auditor':0,'fixed_ELF_bodies_not_in_this_ZIP':True,'root_product_originals_referenced_not_duplicated':True}
(OUT/'actual.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'package_root':str(OUT),'members':len(manifest),'archive':a['archive'],'manifest':a['manifest'],'actual':pin(OUT/'actual.json')[1]}))
