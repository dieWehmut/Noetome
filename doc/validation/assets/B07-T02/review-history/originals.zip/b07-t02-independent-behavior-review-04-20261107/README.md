# B07-T02 independent Linux original evidence audit

This package records an independent read-only audit of the actual Linux full03
run. It does not run the product, generate HTTP, invoke Cargo, or change the
frozen author, Rust, Python, public documentation, or task ledger. Native and
whole-workspace regression results have separate owners and are not claimed.

`actual.json` passed after reading 397 physical command receipts and all original
stdout/stderr bytes: 364 ordinary CLI processes and 33 explicit test drivers.
All 397 recorded PIDs are distinct. The 23 intentional interruptions include
real kill request times, wait records and exit -9, rather than normal exits.
The actual 62 groups are preserved as 62 separate results.

The collector independently hashes the complete immutable SQL payload chain and
uses the frozen independent checker for schema, event replay, original file
identity, original source, body, wire usage and Core/gold validation. The 511 SQL
events counted in `successful_flow_SQL_event_count` belong to valid flow ledgers,
including the live-worker recovery; deliberately corrupted protection databases
are separately rejected and are not included in that count. The four allowed
input invalidations preserve their exact original event prefix and balances,
append only `run_invalidated`, and preserve source/config/Run files. Other
protection cases retain the entire attacked inventory across actual refusal.

`pair-and-incoming-readback.json` independently reads the complete fixed CLI and
driver bodies twice, compares their SHA/length with the actual build receipt,
and reads all 130 current compiled source files against the source ZIP. The ZIP
has 130 members, all read with CRC/SHA/length checks. The fixed programs remain
at the original pair04 paths; their bodies are referenced, not included here.
The independent supplementary readback counts 70 actual complete server incoming
bodies and 70 UUID-bound receipt rows, with no server error rows. This total
includes the eight HTTP originals created before output/live-worker protection.

The audit checks the frozen 14 core case expected values, R = 5238 + 1024 + 2048
= 8310, two distinct requests with the same response SHA each costing 700, prior
opening/spend, atomic near-limit admission, real nonblocking worker traces and
cross-Run PIDs, exact persisted backoff, original Run/unit dispatch deadlines,
Unknown commitments, never-MaySend NotSent release, and candidate failure paid
usage. Rust `ThreadId` evidence is explicitly not called an OS thread ID.

The historical full02 result remains failed after 48 successful groups and a
real compiler-mirror readonly status exit 0. Its actual 291 CLI + 27 driver,
17 SIGKILL, 503 valid SQL events and 62 HTTP originals are separately audited in
attempt02. Full03 uses the new pair04 and verifies compiler-mirror status exit 3.
Neither an old successful subset nor a build receipt is labeled final acceptance.

Own collector failures are preserved. Attempt01 failed because its frozen
checker import lacked the T01 transitive `verify_fixture_compile` import path.
Attempt03 wrongly required all four legitimate input-invalidation budget
inventories to be byte-identical; actual raw evidence showed only allowed
invalidation transactions. Attempt04 fixes the oracle and does not change any
product or expected bytes. The frozen three checker files are copied from the
actual run; the unchanged T01 transitive helper is separately pinned from the
repository and is not falsely described as a full03 copied source file.

The initial imports also generated two `.pyc` caches in each full02/full03
checker-source directory. The four newly generated cache bodies, identity/mtime
and cleanup receipt are preserved separately. Only these four own files and
their empty directories were removed. Original receipts, DBs, body/response and
source files were untouched. The checker-source directory mtime was changed by
the initial import; no claim is made that its original mtime was restored.
Attempt02's root inventory was taken after that cache creation. Attempt04 runs
with bytecode writing disabled and proves stable before/after inventory from the
post-cleanup state. This limitation is not hidden inside a blanket assertion.

The package manifest enumerates copied audit reports, scripts, physical raw
stdout/stderr and generated-cache cleanup originals. Product/source/HTTP roots
are referenced by full pin inventories and preserved at their explicit original
paths; this small audit ZIP does not claim to include all product-run bodies.
