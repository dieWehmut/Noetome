"""Static, original-byte review only: no test, product, HTTP or Cargo run."""
from pathlib import Path
import hashlib,json,re,difflib,stat
REPO=Path('/home/lyinn/project/Noetome')
OLD=Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-native-01-20261107')
OUT=Path(__file__).parent
originals={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 pin={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
 assert originals.setdefault(str(p),pin)==pin
 return b
def copy(p,name):
 b=read(p);dest=OUT/name;dest.write_bytes(b);assert read(dest)==b;return b
actual={'producer':'independent_native_CRLF_failure_static_audit','status':'running','product_test_HTTP_Cargo_invocations':0}
try:
 rec=json.loads(copy(OLD/'full-python.json','original-full-python.json'))
 stderr=copy(OLD/'full-python.stderr.bin','original-full-python.stderr.bin')
 stdout=copy(OLD/'full-python.stdout.bin','original-full-python.stdout.bin')
 for key,b in [('stderr',stderr),('stdout',stdout)]:
  assert hashlib.sha256(b).hexdigest()==rec[key]['sha256'] and len(b)==rec[key]['byte_length']
 assert rec['exit_code']==1 and rec['pid']==45788 and rec['source_before_after_equal']
 text=stderr.decode('utf8')
 names=re.findall(r'^ERROR: (\S+) \(',text,re.M)
 assert set(names)=={'test_actual_server_response_bytes_must_equal_received_API_original','test_actual_source_binding_and_complete_readonly_budget_files'}
 assert 'Ran 527 tests' in text and 'FAILED (errors=2, skipped=8)' in text
 assert text.count('AuditError: real Markdown report JSON')==2
 actual['original_native_fullPython_failure']={'PID':rec['pid'],'exit_code':1,'ran':527,'errors':2,'skipped':8,'derived_passed':517,'actual_error_tests':names,'both_fail_at_original_LF_fence_guard':True,'stdout':rec['stdout'],'stderr':rec['stderr'],'source_guard_true':True}
 old=copy(OLD/'repo/tests/test_verify_request_budget.py','old-test75df.py')
 new=copy(REPO/'tests/test_verify_request_budget.py','current-test-source.py')
 checkerold=copy(OLD/'repo/scripts/verify_request_budget.py','old-checker-source.py')
 checkernew=copy(REPO/'scripts/verify_request_budget.py','current-checker-source.py')
 def region(src,marker):
  start=src.index(marker)
  rest=src[start:]
  end=re.search(rb'\n(?:def |class )',rest[1:])
  return rest[:end.start()+1] if end else rest
 semantic_names=['def request_body_check(','def candidate_gold(','def usage_from_wire(','def transport_check(','def verify_attempt_originals(','def read_authority(','def verify_server_receipts(','def reconstruct_events(','class Ledger:']
 for name in semantic_names:assert region(checkerold,name.encode())==region(checkernew,name.encode()),name+' exact semantic source unchanged'
 orchestration_delta=''.join(difflib.unified_diff(checkerold.decode().splitlines(True),checkernew.decode().splitlines(True),fromfile='native01-checker7fef.py',tofile='current-checker4f328.py'))
 (OUT/'earlier-checker-parallel-launch-delta.patch').write_text(orchestration_delta,encoding='utf8',newline='\n')
 expected=[];sites=[]
 for number,line in enumerate(old.decode().splitlines(keepends=True),1):
  if '(attempt / "validation.md").write_text(' in line:
   ending='\n' if line.endswith('\n') else '';s=line.rstrip('\n')
   s=s.replace('.write_text(','.write_bytes((',1)
   assert s.endswith(')');s=s[:-1]+').encode("utf-8"))'+ending
   expected.append(s);sites.append(number)
  else: expected.append(line)
 assert len(sites)==3 and ''.join(expected).encode()==new,'only three synthetic Markdown writer byte changes permitted'
 delta=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='native01-old-test75df.py',tofile='current-test-source.py'))
 (OUT/'test-writer-only.patch').write_text(delta,encoding='utf8',newline='\n')
 api=copy(OLD/'repo/crates/noetome-cli/src/extraction_api.rs','old-native-api.rs')
 curapi=copy(REPO/'crates/noetome-cli/src/extraction_api.rs','current-api.rs')
 output=copy(OLD/'repo/crates/noetome-cli/src/extraction_output.rs','old-native-output.rs')
 curoutput=copy(REPO/'crates/noetome-cli/src/extraction_output.rs','current-output.rs')
 assert api==curapi and output==curoutput
 report=api.decode().split('fn save_report(',1)[1].split('\n}\n',1)[0]
 assert '```json\\n{snapshot}\\n```\\n' in report and 'output.add("validation.md", md.as_bytes())?' in report
 assert 'file.write_all(bytes)' in output.decode() and 'file.sync_all()' in output.decode()
 guard=checkernew.decode().split('markdown = originals["validation.md"].decode()',1)[1].split('    elif ',1)[0]
 assert 'require("```json\\n" in markdown' in guard and 'strict_json(fragment) == report' in guard
 actual['source_delta']={'old_test_sha256':hashlib.sha256(old).hexdigest(),'new_test_sha256':hashlib.sha256(new).hexdigest(),'changed_lines':sites,'exact_only_three_write_text_to_utf8_write_bytes':True,'old_checker_SHA':hashlib.sha256(checkerold).hexdigest(),'current_checker_SHA':hashlib.sha256(checkernew).hexdigest(),'whole_checker_difference_from_prior_parallel_launch_fix_not_this_CRLF_fix':True,'byte_equal_semantic_functions':semantic_names,'old_current_API_byte_equal':True,'old_current_OutputRoot_byte_equal':True,'synthetic_fixture_markdown':True,'no_changed_expected_body_usage_candidate_or_original_file_checks':True}
 actual['basis']={'old_synthetic_writer':'Path.write_text without explicit newline; Windows text newline translation applies','actual_Rust_writer':'format! literal LF then md.as_bytes -> write_all + sync_all; bytes have no text newline translation','original_guard':'raw original bytes decoded without universal newline conversion; exact LF JSON fence and strict JSON report equality','scope':'static source and original failure evidence; no retained failing Markdown body available, not claimed as a byte-captured failed body; focused rerun belongs to Python owner'}
 for p in list(originals):
  if not str(OUT) in p: read(Path(p))
 actual['status']='passed_static_failure_diagnosis_test_writer_only_fix'
except Exception as e:
 import traceback
 actual['status']='failed';actual['error']=str(e);actual['traceback']=traceback.format_exc();traceback.print_exc()
finally:
 actual['original_actual_readback_pins']=originals
 (OUT/'actual.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 print(json.dumps({k:actual[k] for k in ['status','source_delta','error'] if k in actual},ensure_ascii=False))
 if actual['status']=='failed':raise SystemExit(1)
