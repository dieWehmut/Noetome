# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "58d0c90bb95ecc7017f03aaf308c59db3e8dbb7477b0e197cc27e1f7f4c99fa2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4392d0bd2d708c5982eef1d282c1b50fdd04e8da4b9e55855ff5e47f5e44b6e6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "146c6e9f61e2f00998b79df6b8b8c85b83420634853aa61706debdc268925669"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "757229b765eb19c85e6dbcd1b121e4da6f6e72a50d3de61c13007ee3ab59b7b7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ee60adac07386bac8805203ef5d8718669f45171e93230e312fec4957efcbd98"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "711d7aed96758a978779201221596f9eb31ff6bca3ef1af32bece2a9d40718e4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5e7e4b9b-b7f8-45c9-84c0-2329b092ef56",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ad8c927d-b965-4fbe-921d-d329ff9e87da",
    "source_id": "86fc42c6-9af0-4c75-9242-1b012d9c77c3",
    "version_id": "20f254cd-1fbd-4bcf-8080-277062c36000"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38069/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c93043ac-e75e-4908-b908-6e72d089af29",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ee60adac07386bac8805203ef5d8718669f45171e93230e312fec4957efcbd98"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
