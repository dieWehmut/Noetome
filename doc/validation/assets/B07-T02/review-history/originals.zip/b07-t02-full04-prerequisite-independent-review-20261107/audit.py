from pathlib import Path
import hashlib,json,sqlite3,stat
BASE=Path('/home/lyinn/project/Noetome')
ROOT=BASE/'.artifacts/b07-t02-request-full-04-20261107'
CASE=ROOT/'unknown-remote-completion-retained--OS-kill-after-accepted'
OUT=Path(__file__).parent
pins={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 pin={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns};assert pins.setdefault(str(p),pin)==pin;return b
def copy(p,name):
 b=read(p);q=OUT/name;q.write_bytes(b);assert read(q)==b;return b
a=json.loads(copy(ROOT/'actual.json','original-full04-actual.json'))
assert a['status']=='failed' and a['ordinary_CLI_count']==140 and a['driver_count']==7 and len(a['cases'])==19 and all(a['guards'].values())
server=json.loads(copy(CASE/'server/server-receipts.json','original-server-receipts.json'))
assert len(server['receipts'])==2 and server['errors']==[{'type':'AuditError','text':'independent B did not finish within first A response timing window'}]
ra,rb=server['receipts'];assert ra['unit_id']=='unit-a' and rb['unit_id']=='unit-b' and 'response_file' not in ra and rb['advertised_status']==200
for r in server['receipts']:
 body=copy(CASE/'server'/r['request_body_file'],r['unit_id']+'-actual-HTTP-request.bin');assert hashlib.sha256(body).hexdigest()==r['request_body_sha256'] and len(body)==r['request_body_byte_length']==5238
resp=copy(CASE/'server'/rb['response_file'],'unit-b-actual-HTTP-response.bin');assert hashlib.sha256(resp).hexdigest()==rb['response_sha256'] and json.loads(resp)['usage']['total_tokens']==700
db=CASE/'budget/control/budget.sqlite';copy(db,'original-final-budget.sqlite')
with sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True) as conn:
 rows=list(conn.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
events=[];previous='0'*64
for seq,prev,payload,digest in rows:
 assert seq==len(events)+1 and prev==previous and hashlib.sha256(payload.encode()).hexdigest()==digest
 e=json.loads(payload);events.append(e);previous=digest
assert len(events)==9 and not any(e['event']['kind']=='unit_finished' for e in events)
sealed=[e for e in events if e['event']['kind']=='transport_sealed'];known=[e for e in events if e['event']['kind']=='receipt_settled'];assert len(sealed)==len(known)==1
receipt=known[0]['event']['receipt'];assert known[0]['event']['key']['unit_id']=='unit-b' and receipt['usage']=={'input_tokens':100,'output_tokens':600,'total_tokens':700} and receipt['candidate_status']=='validated'
unitb=CASE/'run-main/attempts/unit-b/attempt-0001'
report=json.loads(copy(unitb/'validation.json','unit-b-original-validation.json'));assert report['status']=='candidates_validated' and report['validated_atoms']==1
copy(unitb/'validation.md','unit-b-original-validation.md');copy(unitb/'transport-receipt.json','unit-b-original-transport.json')
commands=[c for c in a['commands'] if c['wait_action']=='actual_OS_force_kill_and_wait'];assert len(commands)==1
c=commands[0];assert c['PID']==734424 and c['exit_code']==-9 and c['kill_requested_utc_ns']<c['finished_utc_ns']
for n in ['receipt.json','launch.json','stdout.bin','stderr.bin']:copy(ROOT/'commands'/f"{c['number']:04d}"/n,'actual-killed-driver-'+n)
author=json.loads(read(BASE/'fixtures/run-api-budget-v1/cases.json'));case=next(q for q in author['cases'] if q['case_id']=='unknown-remote-completion-retained');variant=next(q for q in case['variants'] if q['name']=='OS-kill-after-accepted')
assert not any('terminal' in k for k in variant)
script=copy(ROOT/'checker-source/verify_request_budget.py','actual-full04-checker-source.py');assert 'end = time.monotonic() + 0.125' in script.decode()
for p in list(pins):
 if not p.startswith(str(OUT)):read(Path(p))
r={'producer':'independent_actual_dual_worker_prerequisite_failure_audit','status':'passed_readonly_failure_diagnosis_not_product_matrix_pass','actual_full04_failed_counts':{'ordinary_CLI':140,'driver':7,'passed_groups':19},'A_actual_server_receive_utc_ns':ra['request_received_utc_ns'],'B_actual_server_flush_utc_ns':rb['response_flush_utc_ns'],'B_actual_transport_sealed_event':sealed[0],'B_actual_Known700_settlement_event':known[0],'B_unit_terminal_present':False,'actual_ownPID_kill':{'PID':c['PID'],'kill_requested_utc_ns':c['kill_requested_utc_ns'],'wait_finished_utc_ns':c['finished_utc_ns'],'exit_code':-9},'actual_original_SQL_payload_chain_SHA_verified':True,'frozen_author_OS_kill_variant':variant,'author_has_no_prior_B_terminal_requirement':True,'raw_failure_is_checker_added_125ms_unit_terminal_prerequisite':True,'strict_possible_future_prerequisite':'B actual sealed original response + validated Known700 receipt and actual server200; after recovery same old B key/bytes/prefix, no new B HTTP, only actual terminal completion','does_not_infer_terminal_from_known':True,'no_product_HTTP_Cargo_invocations_by_auditor':True,'original_actual_pins':pins}
(OUT/'actual.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'actualSHA':hashlib.sha256((OUT/'actual.json').read_bytes()).hexdigest(),'byte_length':(OUT/'actual.json').stat().st_size}))
