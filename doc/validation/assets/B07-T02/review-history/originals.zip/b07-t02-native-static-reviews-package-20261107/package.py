from pathlib import Path
import json,hashlib,zipfile,stat
BASE=Path('/home/lyinn/project/Noetome/.artifacts')
OUT=Path(__file__).parent
members={}
roots={'static-attempt01':'b07-t02-native-CRLF-independent-review-20261107','static-attempt02':'b07-t02-native-CRLF-independent-review-20261107-02','native-focused02':'b07-t02-native-focused02-independent-readback-20261107','syncforge-actual-gate':'b07-t02-syncforge-MD-original-review-20261107'}
for prefix,name in roots.items():
 for p in sorted((BASE/name).iterdir()):
  if p.is_file():members[prefix+'/'+p.name]=p
for name in ['README.md','package.py']:members['package/'+name]=OUT/name
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
archive=OUT/'originals.zip';assert not archive.exists();before={};manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in members.items():
  b,pin=read(p);before[name]=pin;z.writestr(name,b);manifest[name]={'original_path':str(p),'original_pin':pin,'sha256':pin['sha256'],'byte_length':len(b)}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)
 for name,p in members.items():
  b,pin=read(p);assert pin==before[name] and z.read(name)==b
  manifest[name]['all_CRC_SHA_length_original_identity_mtime_bytes_before_after_equal']=True
(OUT/'manifest.json').write_text(json.dumps({'members':manifest},indent=2)+'\n')
a={'producer':'independent_native_static_review_original_package','status':'passed','members':len(manifest),'archive':read(archive)[1],'manifest':read(OUT/'manifest.json')[1],'all_member_CRC_SHA_length_readback_passed':True,'actual_original_file_identity_mtime_bytes_before_after_equal':True,'Native01_failure_raw_preserved':True,'Native_focused02_50_pass_originals_independently_readback':True,'syncforge_specific_Core_gate_coverage_gap_preserved':True,'old_Linux_full03_package_not_changed':True,'final_native_behavior_acceptance_not_claimed':True,'no_product_HTTP_Cargo_invocations_by_auditor':True}
(OUT/'actual.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({'members':a['members'],'archive':a['archive'],'manifest':a['manifest'],'actual':read(OUT/'actual.json')[1]}))
