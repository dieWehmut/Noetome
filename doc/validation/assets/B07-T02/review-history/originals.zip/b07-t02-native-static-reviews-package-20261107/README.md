# B07-T02 Native01 fixture failure and dedicated protection gate review

This is a small independent original-evidence review package. It does not run
the product, send HTTP, invoke Cargo, or claim the final native behavior matrix.
The earlier full03 Linux audit package remains frozen and unchanged.

Native01 actually ran 527 Python tests with two errors and eight skips, exit 1,
PID 45788. Both errors reached the original LF Markdown JSON fence check. The
old test source75df used platform-translating `Path.write_text` for three
synthetic report writers; the corrected test42825f changes only those three
writers to UTF-8 bytes. Actual Rust `save_report` uses literal LF, `as_bytes`,
`write_all` and `sync_all`. Rust API/Output source bytes and the strict semantic
checker functions are unchanged. A failing Markdown file body was not retained
by the original unit cleanup; no byte-captured failed body is claimed here.

Native01 captured checker7fef, before the already separate parallel-launch
checker4f328 fix. This is recorded explicitly. The first independent static
collector wrongly assumed whole-checker equality and failed; its script,
physical stdout/stderr and actual failure report remain included. The corrected
collector compares the exact semantic functions and preserves the prior
orchestration delta separately.

Native focused02 actually ran 50 tests, all passed without skips, test PID
78372 and outer PID 72456. Original stdout/stderr, source-before/after and every
49-file copied snapshot member were independently read back. The selected old
PE was used only for ordinary source init/import setup; this result does not
claim a new native compiler fingerprint or full native request-run acceptance.

A separate precise coverage gap was found in Linux full03's two synchronized
forgery scenarios. All four original ordinary CLI stderr files actually report
`REQUEST_BUDGET_INTEGRITY` with the double-report raw-byte mismatch diagnostic.
The synthetic rewritten validation.json uses compact JSON while its Markdown
embedded JSON uses default spaced formatting. For the candidate-wrapper case,
2413 original JSON bytes differ from 2547 embedded bytes, although decoded JSON
is equal. Core checks these exact bytes before the raw-wire/candidate gates.
Thus the old actual rejection and independent Python semantic checks remain
true, but these exact ordinary CLI attempts do not establish the dedicated
Core usage/candidate gate. A fixture writer must embed the current report file
bytes with LF, and a targeted supplemental/native test must record the resulting
specific refusal. Original run artifacts and previous audit packages are never
rewritten to hide this gap.

All archive members are actual review reports, scripts, original stdout/stderr,
source snapshots, exact patches or selected real forgery artifacts. Large PE
bodies, native build caches and all original run roots are referenced by pins
and retained at their explicit paths, not duplicated in this small ZIP.
