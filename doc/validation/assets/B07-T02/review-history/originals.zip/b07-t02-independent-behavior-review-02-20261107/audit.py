"""Independent read-only audit of immutable historical full02 originals.

No product invocation, HTTP, source writes, or SQLite mutation.
The existing frozen checker is reused only for read-only parsing/reconstruction;
this collector separately checks command raw files, original inventory, event
hashes, server incoming bytes, kill timelines, budget arithmetic and source ZIP.
"""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import sqlite3
import stat
import sys
import traceback
import zipfile

REPO = Path('/home/lyinn/project/Noetome')
ROOT = REPO / '.artifacts/b07-t02-request-full-02-20261107'
OUT = Path(__file__).parent
FIXTURE = REPO / 'fixtures/run-api-budget-v1'
FP = '7bdb2d8ddf638d362e3c3a1532ff0f896d0628ece1abcf2677cf11ea85ca147e'
errors = []
pins = {}

def sha(b): return hashlib.sha256(b).hexdigest()
def require(v, text):
    if not v: raise AssertionError(text)

def raw(path):
    path = Path(path)
    s = path.lstat()
    require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, 'ordinary single-link original: '+str(path))
    b = path.read_bytes()
    t = path.lstat()
    p = {'sha256':sha(b), 'byte_length':len(b), 'device':s.st_dev, 'inode':s.st_ino, 'mtime_ns':s.st_mtime_ns}
    require((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns), 'original changed while reading')
    old=pins.setdefault(str(path),p)
    require(old==p,'original changed during audit '+str(path))
    return b

def js(path): return json.loads(raw(path))
def inventory(root):
    result={}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs+files:
            p=Path(parent)/name;s=p.lstat()
            require(not stat.S_ISLNK(s.st_mode),'no symlink descent '+str(p))
            result[str(p.relative_to(root))]={'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':s.st_mode,'byte_length':s.st_size}
            if stat.S_ISREG(s.st_mode):
                b=raw(p);result[str(p.relative_to(root))]['sha256']=sha(b)
    return result

result={'producer':'independent_request_budget_original_audit','status':'running','scope':'historical full02, 48 successful groups then real compiler-status failure; not final full acceptance','product_invocations':0,'HTTP_requests_generated_by_auditor':0}
try:
    before=inventory(ROOT)
    actual=js(ROOT/'actual.json')
    binding=js(ROOT/'source-build-binding.json')
    result['original_actual_pin']=pins[str(ROOT/'actual.json')]
    require(actual['status']=='failed' and 'readonly corrupted/changed source status' in actual['failure']['text'],'preserve historical RED')
    for prefix in ['author','checker']:
        require(js(ROOT/(prefix+'-source-before.json'))==js(ROOT/(prefix+'-source-after.json')),prefix+' actual before/after pins')
    # The full02 freeze contains the three actual selected checker files.
    # Their unchanged T01 transitive compile-check helpers are explicitly pinned
    # from current repository source, separately from frozen full02 checker pins.
    sys.path.insert(0,str(REPO/'scripts'))
    sys.path.insert(0,str(ROOT/'checker-source'))
    for name in ['verify_fixture_compile.py']:
        raw(REPO/'scripts'/name)
    spec=importlib.util.spec_from_file_location('frozen_budget_audit', ROOT/'checker-source/verify_request_budget.py')
    checker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=checker;spec.loader.exec_module(checker)
    checker.author_check(FIXTURE)
    result['frozen_author_manifest']=dict(pins.setdefault(str(FIXTURE/'frozen-sha256.json'),{})) if str(FIXTURE/'frozen-sha256.json') in pins else {'sha256':sha(raw(FIXTURE/'frozen-sha256.json'))}
    copied_checker={}
    for source,pin in js(ROOT/'checker-source-before.json').items():
        p=ROOT/'checker-source'/Path(source).name;b=raw(p)
        require(sha(b)==pin['sha256'] and len(b)==pin['byte_length'],'frozen checker copy matches actual source-before')
        copied_checker[str(p)]=pins[str(p)]
    result['frozen_checker_copies']=copied_checker
    archive=Path(binding['source_archive']);ab=raw(archive)
    require(sha(ab)==binding['receipt_original']['source_archive']['sha256'],'actual compiled source ZIP binding')
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None,'full compiled source ZIP CRC')
        require(len(z.infolist())==len(binding['source_members'])==130,'130 original compiled source members')
        for name,pin in binding['source_members'].items():
            b=z.read(name);require(sha(b)==pin['sha256'] and len(b)==pin['byte_length'],'compiled source member SHA '+name)
    result['compiled_source_archive']={'path':str(archive),'pin':pins[str(archive)],'members':130,'all_CRC_SHA_length_passed':True,'current_source_equality_not_claimed':True}
    commands=[];kills=[];traces=[]
    for c in actual['commands']:
        cr=ROOT/'commands'/f"{c['number']:04d}"
        r=js(cr/'receipt.json');launch=js(cr/'launch.json')
        require(r==c,'physical command receipt equals actual row')
        for k,v in launch.items(): require(c[k]==v,'launch prefix actual exact '+k)
        for stream in ['stdout','stderr']:
            b=raw(cr/(stream+'.bin'));require(sha(b)==c[stream]['sha256'] and len(b)==c[stream]['byte_length'],'raw command stream exact')
        require(c['started_utc_ns']<=c['finished_utc_ns'] and c['started_monotonic_ns']<=c['finished_monotonic_ns'],'actual command/wait order')
        require(c['credential_value_omitted'] and 'NOETOME_TEST_CREDENTIAL' in c['fake_environment_keys'],'synthetic env selected without credential disclosure')
        rows=[]
        for line in raw(cr/'stdout.bin').decode('utf8',errors='strict').splitlines():
            try: v=json.loads(line)
            except ValueError: continue
            if isinstance(v,dict) and v.get('producer')=='request_run_checkpoint_test_handshake':
                require(v['pid']==c['PID'] and v['compiler_fingerprint']==FP,'actual trace PID/compiled FP')
                rows.append(v)
        if rows: traces.append({'number':c['number'],'PID':c['PID'],'selection':c.get('explicit_request_test_selection'),'trace':rows})
        summary={'number':c['number'],'PID':c['PID'],'kind':c['command_kind'],'label':c['label'],'exit_code':c['exit_code'],'wait_action':c['wait_action'],'stdout_pin':c['stdout'],'stderr_pin':c['stderr']}
        commands.append(summary)
        if c['wait_action']=='actual_OS_force_kill_and_wait':
            require(c['exit_code']==-9 and c['started_utc_ns']<=c['kill_requested_utc_ns']<=c['finished_utc_ns'],'own PID SIGKILL then waited exit -9')
            require(c['command_kind']=='explicit_test_driver','kill actual driver only')
            kills.append({**summary,'kill_requested_utc_ns':c['kill_requested_utc_ns'],'finished_utc_ns':c['finished_utc_ns'],'selection':c['explicit_request_test_selection'],'actual_traces':rows})
    kinds=dict(collections.Counter(x['kind'] for x in commands))
    require(kinds=={'ordinary_cli':291,'explicit_test_driver':27} and len(kills)==17,'independent physical command/kill counts')
    result['commands']={'counts':kinds,'actual_OS_kill_and_wait_count':len(kills),'physical_raw_and_receipts_checked':len(commands),'records':commands,'kills':kills,'traces':traces}
    cases=[];all_http=0;all_rows=0
    selected_groups=actual['cases']
    require(len(selected_groups)==48 and all(g['status']=='passed' for g in selected_groups),'historical 48 groups success only')
    for g in selected_groups:
        name=g['case_id'];case=ROOT/name
        if name.startswith('protection-'):
            try:
                checker.read_authority(case/'budget',fixture=FIXTURE,authority_config=case/'authority-config.json',expected_fingerprint=FP,selected_run_roots=[case/'run-main'])
            except Exception as e:
                cases.append({'case_id':name,'expected_rejected_corrupted_original':True,'actual_readonly_rejection':str(e)})
            else: raise AssertionError('independent corrupt authority accepted '+name)
            continue
        approved=[p for p in case.iterdir() if p.is_dir() and p.name.startswith('run-')]
        ledger,evidence=checker.read_authority(case/'budget',fixture=FIXTURE,authority_config=case/'authority-config.json',expected_fingerprint=FP,selected_run_roots=approved)
        sr=js(case/'server/server-receipts.json');receipts=sr['receipts']
        traffic=checker.verify_server_receipts(ledger,receipts,case/'server')
        require(sr['observed_HTTP_request_count']==len(receipts),'actual HTTP count from real server originals')
        for incoming in sr['incoming']:
            if incoming.get('body_complete'):
                b=raw(case/'server'/incoming['request_body_file'])
                require(sha(b)==incoming['request_body_sha256'] and len(b)==incoming['request_body_byte_length'],'original incoming bytes')
        sums=dict(ledger.authority['opening']);attempts=[];retries=[]
        for key,a in ledger.attempts.items():
            state=a['state'];R=a['plan']['request_body']['byte_length']+1024+a['plan']['max_output_tokens']
            require(R==a['plan']['reserved_tokens']==8310,'original-byte R=5238+1024+2048')
            if state=='known': sums['accounted_tokens']+=a['receipt']['usage']['total_tokens'];sums['dispatched_requests']+=1
            elif state in ['may_send','unknown']: sums['held_tokens']+=R;sums['dispatched_requests']+=1
            elif state=='reserved': sums['held_tokens']+=R;sums['held_requests']+=1
            detail={'key':list(key),'state':state,'reserved_tokens':R,'receipt':a.get('receipt'),'retry':a.get('retry')}
            attempts.append(detail)
        require(sums==ledger.totals(),'separate scalar sums from full event replay')
        # Raw SQL hashes and physical full payload chain independently checked.
        with sqlite3.connect((case/'budget/control/budget.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True) as conn:
            sqlrows=conn.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence').fetchall()
        prev='0'*64
        for seq,ps,payload,digest in sqlrows:
            v=json.loads(payload);require(ps==prev and sha(payload.encode())==digest and v['sequence']==seq and v['previous_sha256']==ps,'independent original SQL payload hash chain')
            prev=digest
        for row in ledger.rows:
            ev=row['event']
            if ev['kind']=='retry_scheduled':
                key=checker.validate_key(ev['key']);run=ledger.runs[key[0]];schedule=ev.get('schedule',ev)
                retries.append({'key':list(key),'raw_event':ev,'at_utc':row['at_utc']})
        require(traffic['observed_HTTP_requests']==g.get('actual_HTTP_requests',traffic['observed_HTTP_requests']),'actual case HTTP count')
        all_http+=len(receipts);all_rows+=len(sqlrows)
        item={'case_id':name,'events':len(sqlrows),'last_sha256':prev,'event_counts':dict(collections.Counter(r['event']['kind'] for r in ledger.rows)),'independent_scalar_totals':sums,'run_totals':{k:ledger.totals(k) for k in ledger.runs},'HTTP_receipts':receipts,'traffic':traffic,'attempts':attempts,'retries':retries,'original_inputs':evidence['input_checks'],'selected_run_roots':[str(p) for p in approved]}
        if name=='same-response-sha-different-attempts':
            known=[a for a in ledger.attempts.values() if a['state']=='known'];resp=[r['response_sha256'] for r in receipts]
            require(len(known)==2 and len(set(resp))==1 and sums['accounted_tokens']==1400 and len({r['request_id'] for r in receipts})==2,'same SHA two unique actual requests each 700')
        if name.startswith('reserved-expired'):
            require(not receipts and sums['held_tokens']==sums['held_requests']==0 and all(a['state']=='not_sent' for a in ledger.attempts.values()),'expired pre-MaySend release actual NotSent zeroHTTP')
        if name.endswith('--actual-worker-observe'):
            ctr=[t for t in traces if any(x['root'] in {str(p) for p in approved} for x in t['trace'])]
            threads={x['thread_id'] for t in ctr for x in t['trace'] if x['unit']}
            require(len(threads)>=2 or len(ctr)>=2,'real worker trace evidence')
            require(all(not x['will_wait'] for t in ctr for x in t['trace']),'observe concurrent scheduling has no input handshake')
            require(len(receipts)==1,'parallel nearcap only one HTTP permitted')
            item['actual_worker_observe']={'PIDs':[t['PID'] for t in ctr],'Rust_ThreadIds':sorted(threads),'ThreadIds_are_not_OS_thread_IDs':True,'all_trace_nonblocking':True}
        cases.append(item)
    result['historical_successful_groups']=cases
    result['successful_group_count']=len(cases)
    result['successful_flow_SQL_event_count']=all_rows
    result['actual_HTTP_in_successful_flows']=all_http
    mirror=ROOT/'protection-compiler-mirror'
    owner=js(mirror/'budget/control/owner.json');runowner=js(mirror/'run-main/control/owner.json')
    require(owner['compiler_fingerprint']!=FP and runowner['compiler_fingerprint']==FP,'real unknown budget compiler mirror preserves original Run compiler')
    mirror_commands=[c for c in actual['commands'] if str(mirror/'budget') in c['argv']]
    badstatus=[c for c in mirror_commands if c['argv'][1:4]==['run','api','status']]
    require(len(badstatus)==1 and badstatus[0]['exit_code']==0,'historical actual wrong status exit0')
    result['historical_true_product_failure']={'case_id':'protection-compiler-mirror','ordinary_status_PID':badstatus[0]['PID'],'ordinary_status_exit':0,'budget_compiler_fingerprint':owner['compiler_fingerprint'],'unchanged_run_fingerprint':runowner['compiler_fingerprint'],'fix_requires_new_pair':'status calls store.verify_version before authority_binding/inputs; old full02 remains failed'}
    after=inventory(ROOT);require(before==after,'all historical root original identity/mtime/length/SHA preserved')
    result['full_original_inventory']={'file_count':sum('sha256' in p for p in before.values()),'entry_count':len(before),'before_after_equal':True,'before':before,'after':after}
    result['status']='passed_readonly_historical_audit_not_full_acceptance'
except Exception as e:
    result['status']='audit_failed';result['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    traceback.print_exc()
finally:
    result['all_read_original_pins']=pins
    (OUT/'actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:result[k] for k in ['status','scope','successful_group_count','successful_flow_SQL_event_count','actual_HTTP_in_successful_flows','failure'] if k in result},ensure_ascii=False))
    if result['status']=='audit_failed': sys.exit(1)
