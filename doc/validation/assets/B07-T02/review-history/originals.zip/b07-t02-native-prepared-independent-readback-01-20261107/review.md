独立读回通过，范围为 B07-T02 native01 的准备原件、启动控制和具名源码清单。第二轮审查脚本实际退出 0；本审查没有运行 Cargo、CLI、HTTP、原生单元测试或完整 Python。native01 本身已由 root 启动，不能把准备通过当作其最终验证通过。

实际准备根为 `/mnt/d/Noetome/.artifacts/b07-t02-windows-native-01-20261107`。`snapshot.json` SHA 为 `481e8ca6e065ad24087bf721d0381d55f1e3cf70ff412ff41339d2dfb8ffc1fc`，422669 字节；`source-originals.zip` SHA 为 `f76f19cdee1768adbf79d6a784c946cf8a5edb0a9a95572db550e5d1ae2817a1`，8207899 字节；copied `runner.py` SHA 为 `0366df7362782f3a482fa1ddb66ddf6c0bcb5bf2450b7fc245d2ef52dd456a8a`，41506 字节，逐字节等于当前 draft02。

本轮实际核对了这些事实：

- 七份原控制文件在读取前后 SHA/长度完全相同：snapshot、source ZIP、runner、launcher、precise scopes、conservative subset、prepared-source。prepared-source 内六个 pin 都等于实际文件；第七份 prepared-source 自身以审查读取前的独立 pin 约束。本审查保留小型控制副本，没有重复复制全部 source ZIP。
- ZIP 库存严格为 2056 个 `repo/` 文件和四个辅助原件，共 2060 个唯一成员。全部成员实际 CRC 通过、长度和 SHA 与 snapshot 等值；每份 ZIP 原字节还逐项等于 native repo 或实际控制原件。四个辅助原件是 snapshot、subset、precise scopes、runner。
- launcher 的三个显式外部 SHA 参数各出现一次，值精确等于 snapshot、copied runner 和 source ZIP 原件。launcher 在 ZIP 关闭后生成，prepared-source 在 launcher 落盘后封存，未构造自引用哈希。
- 独立重建四份具体文件集合：直接 `build.rs` 输入 93 项；CLI/Cargo 与 CLI 集成测试 129 项；全 workspace Rust 129 项；保守 Rust/test/fixture/sidecar 输入 1913 项。每份名字集合和每个 SHA/长度都等于 prepared scopes，且当前工作树这四份集合逐文件等值。两份 129 项清单是不同集合：CLI 独有 Cargo.lock、workspace Cargo.toml、CLI Cargo.toml；workspace 独有 desktop build.rs、main.rs、preferences.rs。root 原编译检查的宽 130 项应明确为 CLI/Cargo/tests 129 加 rust-toolchain.toml，不能称作直接指纹或全 workspace 集合。
- 45 项选定作者包为 `fixtures/run-api-budget-v1/`，其 frozen manifest SHA 精确为 `ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272`。作者 expected 保持原件，审查没有从产品报告生成任何 expected。

对 copied runner 的静态复核确认：外层 launch 比较 reviewed `__file__` 与 copied runner，核 current `source_names` 完整名字清单及源字节；原生 entry 核三个外部 SHA、准备控制和四个 ZIP 辅助原件，每条命令前后与最终都调用完整 controls/source/assets/sentinel 守卫。旧测试实际使用的 `repo/target/debug/noetome.exe` 在 selected PE 复制后保存 `binary_aliases[path] = pin(selected PE)`；所有后续命令和最终守卫均对该普通路径重新读 SHA/长度，检查代码未依赖 alias manifest 的自述来放行。该赋值发生在完整 Python 之前，原始 selected PE 与同源 test driver 也继续守卫。

运行环境代码选定真实 Windows Rust 1.98.1、Windows Python 3.12.14、cache PowerShell 7.6.5 与系统 PowerShell 5.1；实际 `shutil.which`/samefile 与版本、程序 pin 都作为门禁，两引擎各 39 条原合成凭据测试须在完整 unittest 原 stderr 中实际出现且全部 `ok`。这里确认的是这些门禁存在；最终实际版本、39 条结果、完整 Rust 和 Python 数量待 native 原 stdout/stderr 结束后另审。

native01 的冻结 checker 为 `scripts/verify_request_budget.py` SHA `7fefaf56b53c8f943fe0f900c1529c30a87d8ecafd55d6c46012aa277a94a363` 与 tests SHA `75df93ea189724f545b70b675ea2c352736790393ae2e82618296be77cf8786d`。读回时公共 checker 已在获授权的并发启动修复窗口，观测到 script `4f328990691946163089749c17c75bb68bc8b1db04b8daf3d5d74b4be805efaf`。本报告保留两组实际 pin，不声明 current whole-source 与 native01 相同，也不把旧 checker 的通过结果绑定新 checker。后续完整 Python continuation 必须另建新根、新快照并跑最终 checker；若复用 native01 Rust，须核全部实际 Cargo 原件、完整 Rust summaries、实际 PE/driver/FP 与这四份独立具名不变集合。

第一轮本审查误假设作者包目录名为 request-budget-v1，已在完整 ZIP 和四份 Rust 清单核对后由路径断言退出 1。该脚本、stderr 和中间结果完整保留于 `attempt-01-author-path-assumption/`；第二轮只按实际选定 `run-api-budget-v1` 修正审查路径并重新全量读回。它是审查 wrapper 的假设错误，不是产品或 native 构建失败。

机器结果在 `actual.json`；完整 ZIP 成员 pin 在 `archive-members.json`；具名四集合在 `independently-recomputed-current-rust-scopes.json`，宽 130 单列在 `root-check-wide-plus-toolchain.json`；两组 checker pin 在 `native01-frozen-checker-vs-observed-current.json`。实际子进程 argv/PID/退出码和原 stdout/stderr 在 `command.json` 及对应 `.bin` 文件。
