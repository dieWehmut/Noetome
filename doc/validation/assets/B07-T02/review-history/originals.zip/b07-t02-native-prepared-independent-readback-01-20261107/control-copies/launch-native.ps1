$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-native-01-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-native-01-20261107' --snapshot-sha256 '481e8ca6e065ad24087bf721d0381d55f1e3cf70ff412ff41339d2dfb8ffc1fc' --runner-sha256 '0366df7362782f3a482fa1ddb66ddf6c0bcb5bf2450b7fc245d2ef52dd456a8a' --source-archive-sha256 'f76f19cdee1768adbf79d6a784c946cf8a5edb0a9a95572db550e5d1ae2817a1'
exit $LASTEXITCODE
