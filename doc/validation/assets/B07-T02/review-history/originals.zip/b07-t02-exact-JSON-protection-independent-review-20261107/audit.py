from pathlib import Path
import hashlib,json,stat,collections
ROOT=Path('/home/lyinn/project/Noetome/.artifacts/b07-t02-artifact-protection-exact-json-matrix-01-20261107')
OUT=Path(__file__).parent
pins={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 pin={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns};assert pins.setdefault(str(p),pin)==pin;return b
def copy(p,name):
 b=read(p);q=OUT/name;q.write_bytes(b);assert read(q)==b;return b
a=json.loads(copy(ROOT/'actual.json','original-actual.json'))
assert a['status']=='passed' and a['failure'] is None and len(a['cases'])==7 and all(a['guards'].values())
assert collections.Counter(c['command_kind'] for c in a['commands'])=={'ordinary_cli':37,'explicit_test_driver':5}
assert len({c['PID'] for c in a['commands']})==42
commands=[];kills=[]
for c in a['commands']:
 d=ROOT/'commands'/f"{c['number']:04d}";receipt=json.loads(read(d/'receipt.json'));launch=json.loads(read(d/'launch.json'));assert receipt==c and all(c[k]==v for k,v in launch.items())
 for stream in ['stdout','stderr']:
  b=read(d/(stream+'.bin'));assert hashlib.sha256(b).hexdigest()==c[stream]['sha256'] and len(b)==c[stream]['byte_length']
 if c['wait_action']=='actual_OS_force_kill_and_wait':
  assert c['exit_code']==-9 and c['started_utc_ns']<=c['kill_requested_utc_ns']<=c['finished_utc_ns'];kills.append({'PID':c['PID'],'exit_code':-9,'kill_requested_utc_ns':c['kill_requested_utc_ns'],'finished_utc_ns':c['finished_utc_ns']})
 commands.append({'PID':c['PID'],'number':c['number'],'kind':c['command_kind'],'exit_code':c['exit_code'],'label':c.get('label')})
assert len(kills)==5
HTTP=0;targets=[]
for group in a['cases']:
 case=ROOT/group['case_id'];audit=json.loads(read(case/'independent-audit.json'));assert audit['after_deliberate_attack_before_commands']==audit['after_commands']
 server=json.loads(read(case/'server/server-receipts.json'));assert not server['errors'] and len(server['incoming'])==len(server['receipts'])==server['observed_HTTP_request_count']==1
 incoming=server['incoming'][0];request=read(case/'server'/incoming['request_body_file']);assert incoming['body_complete'] and len(request)==incoming['request_body_byte_length']==5238 and hashlib.sha256(request).hexdigest()==incoming['request_body_sha256']
 receipt=server['receipts'][0];response=read(case/'server'/receipt['response_file']);assert hashlib.sha256(response).hexdigest()==receipt['response_sha256'] and len(response)==receipt['response_byte_length'];assert json.loads(response)['usage']['total_tokens']==700
 HTTP+=1
 if group['case_id'].startswith('protection-synchronized-'):
  short=group['case_id'].removeprefix('protection-');attempt=next((case/'run-main/attempts/unit-a').iterdir());j=copy(attempt/'validation.json',short+'-actual-validation.json');md=copy(attempt/'validation.md',short+'-actual-validation.md');embedded=md.split(b'```json\n',1)[1].split(b'\n```\n',1)[0]
  assert j==embedded and b'\r\n' not in md
  selected=[]
  expected='原wire独立用量与结算不等' if short=='synchronized-known-usage' else '已批准候选与原wire/请求绑定不等'
  for c in a['commands']:
   label=c.get('label') or ''
   if short in label and 'artifact protection' in label:
    d=ROOT/'commands'/f"{c['number']:04d}";err=copy(d/'stderr.bin',short+f"-PID{c['PID']}-stderr.bin");copy(d/'receipt.json',short+f"-PID{c['PID']}-receipt.json")
    assert expected in err.decode() and '双报告原字节不等' not in err.decode() and c['exit_code']==3
    selected.append({'PID':c['PID'],'exit_code':3,'actual_specific_diagnostic':err.decode().strip(),'stderr_pin':c['stderr']})
  assert len(selected)==2;targets.append({'case_id':group['case_id'],'JSON_byte_length':len(j),'MD_embedded_JSON_byte_length':len(embedded),'embedded_original_bytes_equal':True,'LF_bytes_without_CRLF':True,'actual_specific_guard_commands':selected})
assert HTTP==7 and len(targets)==2
for p in ['checker-source-before.json','checker-source-after.json','author-source-before.json','author-source-after.json','source-build-binding.json']:
 copy(ROOT/p,'original-'+p)
assert json.loads(read(ROOT/'checker-source-before.json'))==json.loads(read(ROOT/'checker-source-after.json')) and json.loads(read(ROOT/'author-source-before.json'))==json.loads(read(ROOT/'author-source-after.json'))
result={'producer':'independent_actual_exact_JSON_protection_original_audit','status':'passed_specific_Core_protection_gates_verified','ordinary_CLI':37,'driver':5,'unique_actual_PIDs':42,'actual_SIGKILL_wait_exit_minus9':kills,'groups':7,'actual_body_complete_HTTP':7,'specific_target_results':targets,'all_42_physical_command_receipt_raw_SHA_length_equal':True,'source_author_original_before_after_equal':True,'all_protection_original_inventories_preserved':True,'prior_full03_coverage_gap_now_closed_by_actual_supplement':True,'does_not_add_7_new_unique_core_cases_to_62':True,'no_product_HTTP_Cargo_invocations_by_auditor':True,'command_records':commands,'original_actual_pins':pins}
for p in list(pins):
 if not p.startswith(str(OUT)):read(Path(p))
(OUT/'actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':result['status'],'actualSHA':hashlib.sha256((OUT/'actual.json').read_bytes()).hexdigest(),'byte_length':(OUT/'actual.json').stat().st_size,'targets':targets},ensure_ascii=False))
