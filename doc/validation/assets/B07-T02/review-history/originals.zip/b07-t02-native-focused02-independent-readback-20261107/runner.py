from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path(__file__).parent
repo = root / "repo"
before = json.loads((root / "source-before.json").read_bytes())
cli = Path(r"D:\Noetome\.artifacts\b07-t02-windows-native-01-20261107\selected\noetome.exe")
env = {k: os.environ[k] for k in ("PATH", "SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "TEMP", "TMP") if k in os.environ}
env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", NO_PROXY="127.0.0.1,::1", no_proxy="127.0.0.1,::1", NOETOME_TEST_BINARY=str(cli))
with (root / "stdout.bin").open("wb") as out, (root / "stderr.bin").open("wb") as err:
    child = subprocess.Popen([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_verify_request_budget.py"], cwd=repo, env=env, stdout=out, stderr=err)
    code = child.wait(timeout=120)
after = {str(p.relative_to(repo)).replace("\\", "/"): {"sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "byte_length": p.stat().st_size} for p in repo.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
raw = (root / "stderr.bin").read_text(encoding="utf-8")
run = re.search(r"Ran (\d+) tests", raw)
skip = re.search(r"OK \(skipped=(\d+)\)", raw)
result = {"status": "passed" if code == 0 and before == after else "failed", "OS": os.name, "python": sys.executable, "version": sys.version, "outer_PID": os.getpid(), "actual_test_PID": child.pid, "exit_code": code, "tests_run": int(run.group(1)) if run else None, "skips": int(skip.group(1)) if skip else 0, "source_before": before, "source_after": after, "source_before_after_equal": before == after, "selected_old_source_init_import_PE": str(cli), "selected_PE_sha256": hashlib.sha256(cli.read_bytes()).hexdigest(), "stdout_sha256": hashlib.sha256((root / "stdout.bin").read_bytes()).hexdigest(), "stderr_sha256": hashlib.sha256((root / "stderr.bin").read_bytes()).hexdigest(), "scope": "native independent checker tests/real artificial loopback/NTFS readonly identity and old source init/import only; no new run-api budget feature inferred"}
(root / "actual.json").write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
raise SystemExit(code if before == after else 1)
