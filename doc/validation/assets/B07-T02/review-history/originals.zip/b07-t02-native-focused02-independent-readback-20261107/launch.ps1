$ErrorActionPreference = 'Stop'
$requestBudgetFocusPython = 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe'
$requestBudgetFocusRunner = 'D:\Noetome\.artifacts\b07-t02-budget-python-focused-native-02-20261107\runner.py'
& $requestBudgetFocusPython $requestBudgetFocusRunner
exit $LASTEXITCODE
