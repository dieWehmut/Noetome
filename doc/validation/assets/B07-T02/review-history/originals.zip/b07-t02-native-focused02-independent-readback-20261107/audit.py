from pathlib import Path
import hashlib,json,stat
ROOT=Path('/mnt/d/Noetome/.artifacts/b07-t02-budget-python-focused-native-02-20261107')
OUT=Path(__file__).parent
pins={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 pin={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns};assert pins.setdefault(str(p),pin)==pin;return b
def copy(p,name):
 b=read(p);q=OUT/name;q.write_bytes(b);assert read(q)==b;return b
actual=json.loads(copy(ROOT/'actual.json','original-actual.json'))
stdout=copy(ROOT/'stdout.bin','original-stdout.bin');stderr=copy(ROOT/'stderr.bin','original-stderr.bin')
assert actual['status']=='passed' and actual['OS']=='nt' and actual['exit_code']==0 and actual['tests_run']==50 and actual['skips']==0
assert actual['source_before']==actual['source_after'] and actual['source_before_after_equal']
assert hashlib.sha256(stdout).hexdigest()==actual['stdout_sha256'] and hashlib.sha256(stderr).hexdigest()==actual['stderr_sha256']
assert b'Ran 50 tests' in stderr and b'\nOK' in stderr.replace(b'\r\n',b'\n')
source={}
for name,expected in actual['source_before'].items():
 p=ROOT/'repo'/name;b=read(p);assert hashlib.sha256(b).hexdigest()==expected['sha256'] and len(b)==expected['byte_length'];source[name]=pins[str(p)]
for name in ['tests/test_verify_request_budget.py','scripts/verify_request_budget.py','scripts/verify_fixture_compile.py','scripts/verify_run_checkpoint.py']:
 copy(ROOT/'repo'/name,'source-'+Path(name).name)
for name in ['runner.py','launch.ps1']:
 copy(ROOT/name,name)
for p in list(pins):
 if not p.startswith(str(OUT)):read(Path(p))
result={'producer':'independent_native_focused_test_original_readback','status':'passed','actual_OS':'nt','actual_test_PID':actual['actual_test_PID'],'outer_PID':actual['outer_PID'],'ran':50,'passed':50,'skipped':0,'exit_code':0,'source_before_after_equal':True,'copied_snapshot_actual_members_read':len(source),'actual_source':source,'synthetic_fixture_only':True,'test_source_SHA':actual['source_before']['tests/test_verify_request_budget.py']['sha256'],'checker_SHA':actual['source_before']['scripts/verify_request_budget.py']['sha256'],'selected_old_source_init_import_PE':actual['selected_old_source_init_import_PE'],'selected_PE_sha256':actual['selected_PE_sha256'],'does_not_claim_new_native_FP_full_behavior':True,'no_product_HTTP_Cargo_invocations_by_auditor':True,'original_actual_pins':pins}
(OUT/'actual.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'actual_SHA':hashlib.sha256((OUT/'actual.json').read_bytes()).hexdigest(),'byte_length':(OUT/'actual.json').stat().st_size,'source_members':len(source)}))
