Native03 准备原件独立读回通过，选定 Python 的实际审查脚本退出 0。本轮只读源、控制原件和已闭合来源证明，没有启动 native、Cargo、CLI、HTTP 或 test driver；完整原生结果另等实际结束后审查。

新准备根 `/mnt/d/Noetome/.artifacts/b07-t02-windows-native-03-20261107` 的 snapshot SHA 为 `5dbeaf6d475331390432a91531eca8f8338f8805824bcc36639c0b12bafe9f83`，423009 字节；源码 ZIP SHA 为 `f270c1a400cd5396a335ac0971280f1d3c2e28a27503f7c2c4b3496d17b714bd`，8208866 字节；runner `3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1`，43402 字节，逐字节等于已审 draft03。

七份控制原件实际读取前后 pin 全同；prepared-source 的六个 pin 精确等于实际 snapshot、ZIP、runner、launcher、精确 scopes 和 conservative subset。launcher 的三个外部 SHA 参数各出现一次，值精确等于相应原件。ZIP 为 2056 个 repo 文件加四个控制辅助原件，共2060个唯一成员；全成员实际 CRC、SHA、长度均读回，且每份字节等于 native 副本或辅助原件。新完整2056项输入也逐pin等于当前工作树，没有只检查旧名字而漏掉新源码的数量推断。

最终 Rust 引擎原件为 `606ec22cbd049f25b0e934d9606074423a07aeaac582787217e74478927c1bec`；checker 为 `42055cf5fe8beda6abe468e66cfabc9fabfc8df17449c513803f054c7a3e4083`、159201 字节；tests 为 `42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348`、50420 字节。45项作者原件及 frozen manifest `ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272` 保持原字节。

四份独立完整具名清单实际重建后分别为：build.rs 直接93、CLI/Cargo/tests129、全workspace Rust129、保守依赖1913。每个文件名、SHA和长度精确匹配；Root CLI/Cargo/tests 加 toolchain 的130项单独列出，逐项等于已实际构建的 Linux pair04 source-before/source-after。Linux实际 CLI fingerprint `8a62da0b6a1b533fdeb0dc1134b39ac28395bbaeca79ef81a9984c23ee06714f` 有此前闭合编译/原探针锚；Windows 的实际 fingerprint还须由新Cargo env与新CLI/driver真实探针观察，不能因为源字节相同就填Linux值。

Native03 相对未运行的 native02，仅两份 Python 原字节改变，所有 Rust/scopes 仍同源。完整 diff及AST核对确认最后修复仅涉及 checker `artifact_protection_matrix` 的一处人工Markdown写入，以及 tests 中三个人工原件写入：测试writer改成显式UTF8 bytes，保证LF；同步伪造harness直接把已经写入的 validation.json 原字节放入LF fenced block。这避免Windows默认CRLF和compact/pretty差异先触发结构门禁，保留原 reader/ledger/wire/receipt判断；所有其他函数AST保持相同。它没有放宽产品输出判据。旧四次同步伪造先停在双报告字节门禁的历史不能改称usage/wrapper专项通过，最终真实target4拒绝及新矩阵原件应另审。

缓存目标仍是 native01 的临时build-target。原 outer-native-result实际已生成，旧进程退出1，工作树差异保留，控制原件全同；旧失败及程序原件不会覆盖。新runner显式不复用任何旧测试结果，仍执行当前完整fmt/check/build/test与完整Python，两真实PowerShell引擎各39条实际发现和版本/程序pin门禁保持不变。

本阶段只确认来源和准备，Windows完整Rust数量、原stdout/stderr、实际PE/driver/FP、完整Python及两引擎结果均为pending，不把native01旧789条Rust或其两个Python错误转为新通过。原件由root保留，本审查包仅保存控制小副本、source maps、ZIP逐成员pin、最终writer diff和原命令输出。后续最终原生审查会保存另一个目录，不修改这份准备记录或旧native01/native02/pair03报告。
