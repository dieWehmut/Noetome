$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-native-03-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-native-03-20261107' --snapshot-sha256 '5dbeaf6d475331390432a91531eca8f8338f8805824bcc36639c0b12bafe9f83' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 'f270c1a400cd5396a335ac0971280f1d3c2e28a27503f7c2c4b3496d17b714bd'
exit $LASTEXITCODE
