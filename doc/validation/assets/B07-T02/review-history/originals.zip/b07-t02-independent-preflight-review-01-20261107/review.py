from pathlib import Path
import copy, hashlib, json, sqlite3, stat, time

ROOT = Path('/home/lyinn/project/Noetome')
BASE = ROOT / '.artifacts/b07-t02-author-preflight-02-20261107'
PACK = ROOT / 'fixtures/run-api-budget-v1'
OUT = ROOT / '.artifacts/b07-t02-independent-preflight-review-01-20261107'
observed = {}

def sha(data): return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, str(path)
    data = path.read_bytes()
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')
    assert all(getattr(before, x) == getattr(after, x) for x in fields), str(path)
    pin = dict(sha256=sha(data), byte_length=len(data), device=after.st_dev, inode=after.st_ino, modified_ns=after.st_mtime_ns)
    if str(path) in observed: assert observed[str(path)] == pin
    observed[str(path)] = pin
    return data

def obj(path): return json.loads(read(path))

started = time.time_ns()
actual = obj(BASE / 'actual.json')
script = read(BASE / 'preflight.py')
assert b'"max_requests":0' in script
assert b'source_author_files_unchanged' in script
assert len(actual['commands']) == 4
for number, row in enumerate(actual['commands'], 1):
    folder = BASE / 'commands' / f'{number:03d}'
    assert obj(folder / 'receipt.json') == row
    stdout, stderr = read(folder / 'stdout.bin'), read(folder / 'stderr.bin')
    assert sha(stdout) == row['stdout_sha256'] and sha(stderr) == row['stderr_sha256']
    assert row['exit_code'] == (0 if number <= 2 else 3)
    assert row['finished_ns'] >= row['started_ns'] and row['pid'] > 0
    if number >= 3:
        report = json.loads(stdout)
        assert report['usage']['network_attempts'] == 0
        assert report['usage']['real_model_calls'] == report['usage']['paid_calls'] == 0
        assert report['usage']['model_usage'] is None
        assert report['errors'][0]['code'] == 'EXTRACT_BUDGET_STOP'
        assert b'EXTRACT_BUDGET_STOP' in stderr

config = obj(BASE / 'zero-budget-api-config.json')
assert config['budget']['max_requests'] == 0
assert config['transport_mode'] == 'local_http_test'
assert config['endpoint'] == 'http://127.0.0.1:1/v1/responses'
pins = obj(PACK / 'source-pins.json')
originals = []
for rel, spec in pins['original_sources'].items():
    a = read(PACK / rel)
    b = read(ROOT / spec['source_path'])
    assert a == b and sha(a) == spec['sha256'] and len(a) == spec['byte_length']
    originals.append(dict(copy=rel, original=spec['source_path'], sha256=sha(a), byte_length=len(a)))
source = read(PACK / 'source/source.txt')
source_sha = sha(source)
db = BASE / 'project/project.sqlite'
read(db)
with sqlite3.connect(db.resolve().as_uri() + '?immutable=1', uri=True) as conn:
    assert conn.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
    versions = conn.execute('SELECT content_sha256, byte_length, raw_snapshot FROM source_versions').fetchall()
    assert len(versions) == 1 and versions[0][:2] == (source_sha, len(source)) and versions[0][2].encode() == source
    assert conn.execute('SELECT count(*) FROM source_imports').fetchone() == (1,)
    assert conn.execute('SELECT count(*) FROM source_spans').fetchone() == (1,)

bodies = []
for index, name in enumerate(('a', 'b'), 3):
    folder = BASE / f'api-prepared-{name}'
    body = read(folder / 'request-body.json')
    request = obj(folder / 'request.json')
    report_bytes = read(folder / 'validation.json')
    report = json.loads(report_bytes)
    stdout = read(BASE / 'commands' / f'{index:03d}' / 'stdout.bin')
    assert json.loads(stdout) == report
    assert read(PACK / f'originals/core05-request-body-{name}.json') == body
    md = read(folder / 'validation.md')
    embedded = md.split(b'```json\n', 1)[1].split(b'\n```\n', 1)[0]
    assert embedded == report_bytes
    input_reservation = len(body) + 1024
    output_limit = request['limits']['max_output_tokens']
    reservation = input_reservation + output_limit
    assert (len(body), input_reservation, output_limit, reservation) == (5238, 6262, 2048, 8310)
    assert request['request_body'] == dict(sha256=sha(body), byte_length=len(body))
    assert request['input_reserved_tokens'] == report['usage']['input_reserved_tokens'] == input_reservation
    assert request['reserved_tokens'] == report['usage']['reserved_tokens'] == reservation
    wire = json.loads(body)
    decoded = json.loads(wire['input'])
    assert wire['max_output_tokens'] == output_limit
    assert decoded['request_id'] == request['request_id'] == report['request_id']
    assert decoded['binding'] == request['binding'] == report['binding']
    assert decoded['binding']['content_sha256'] == source_sha
    assert decoded['units'][0]['text'].encode() == source
    assert decoded['units'][0]['start_byte'] == 0 and decoded['units'][0]['end_byte'] == len(source)
    entry = actual['body_preflights'][index-3]
    assert entry['sha256'] == sha(body) and entry['byte_length'] == len(body)
    assert entry['report_sha256'] == sha(report_bytes)
    bodies.append(dict(name=name, sha256=sha(body), byte_length=len(body), input_reserved_tokens=input_reservation, output_limit_tokens=output_limit, reserved_tokens=reservation, wire=wire, decoded=decoded))
assert bodies[0]['decoded']['request_id'] != bodies[1]['decoded']['request_id']
a, b = copy.deepcopy(bodies[0]['decoded']), copy.deepcopy(bodies[1]['decoded'])
a['request_id'] = b['request_id']
assert a == b
outer_a, outer_b = copy.deepcopy(bodies[0]['wire']), copy.deepcopy(bodies[1]['wire'])
outer_a.pop('input'); outer_b.pop('input')
assert outer_a == outer_b

for row in bodies: row.pop('wire'); row.pop('decoded')
for path in list(observed): read(path)
result = dict(status='passed_with_capture_limitation', producer='independent_readonly_preflight_review', source_scope='old Core05 zero-request preparation only; new T02 product behavior not_run', started_ns=started, finished_ns=time.time_ns(), verified_command_count=4, command_exit_codes=[0,0,3,3], body_checks=bodies, old_source_copy_checks=originals, source_database_snapshot_equal=True, source_database_open='immutable read-only; no recovery or mutation', all_observed_files_equal_before_after=True, originals=observed, HTTP_requests_from_this_review=0, product_processes_from_this_review=0, real_credentials_or_ledgers_accessed=False, known_capture_limitations=['Historical preflight.py assigns source_author_files_unchanged:true literally, without saving a pre/post input inventory. This review proves current exact old source/gold/template pins and before/after equality during its own reads; it does not invent historical inventory or syscall-level network observation.','Zero HTTP is supported by two physical ordinary-CLI failure reports with network_attempts0/max_requests0, raw exits3 and stable EXTRACT_BUDGET_STOP, plus inspected Core05 call ordering; no packet/server observer was captured in this preparatory run.'])
(OUT / 'actual.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','verified_command_count','command_exit_codes','body_checks','old_source_copy_checks','known_capture_limitations']},ensure_ascii=False))
