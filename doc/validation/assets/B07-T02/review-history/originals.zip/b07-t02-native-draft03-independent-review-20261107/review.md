draft03 静态审查通过，绑定 runner SHA `3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1`、43402 字节。独立 AST 检查和选定 Linux Python `--help` 实际退出 0；本轮没有 prepare、Windows launch、Cargo、CLI 或 HTTP。

相对已审 draft02 `0366df7362782f3a482fa1ddb66ddf6c0bcb5bf2450b7fc245d2ef52dd456a8a`，新增逻辑仅为显式依赖缓存：prepare 只接受实际 D: task artifacts 内名为 build-target 的普通已有目录，并要求其父根有原 prepared-source；保存目标和 prior 根于新 snapshot，随后由外部 SHA、source ZIP 四辅助原件和七控制原件一起封存。launch 和原生 entry 都要求 prior `outer-native-result.json` 已存在，该原件由旧外层真实 child.wait 结束后产生；它是缓存不并发使用的门禁，不表示旧测试通过。

独立 AST 对比确认这些函数完全保持原逻辑：source_names、current_source_names、controls、ordinary、NativeRun.guards、command、cargo、registry、runtime_probes、execute。完整 execute 中仍实际执行六条 Cargo 操作：

- clean -p noetome-cli，清除该包旧构建产物；
- fmt --all --check；
- check --workspace --locked --offline；
- build -p noetome-cli --locked --offline；
- test -p noetome-cli --lib --no-run --locked --offline --message-format=json；
- test --workspace --locked --offline -- --test-threads=4 --nocapture。

随后仍有新 selected PE/driver 完整复制与哈希、Cargo build-script FP 对照实际 CLI/driver probe、完整原生 Python及两真实 PowerShell 引擎各 39 条实际原测试。复用的是临时 compiler dependency cache，`compiler-cache-scope.json` 显式声明 previous_test_results_reused=false。旧 selected 程序体、repo alias、source ZIP 和 raw stdout/stderr 不在 build-target 中，不能由这个缓存路径改写。

新源码包含 status 版本门禁修复，旧 native01 的 Rust 结果只保留原 source 历史；draft03 未提供旧结果复用捷径。新结果仍须对新完整 source_names、四独立具名集合、七控制、原 registry package/source、哨兵、复制后的程序体和 legacy fallback alias 执行各命令前后守卫；实际最终 Cargo exit、Rust summaries、FP 和完整 Python 原 stderr 必须另读回。

缓存目录是 root 明确选择的本任务临时编译目录，旧 prepared-source/结束标记仅确定其来源和非并发阶段。它没有作为新编译来源或通过证明。根代理应待旧实际 native 结束后再 launch，保存其旧失败/工作树 checker 差异；新 source freeze、所选 Windows Rust/Python/PowerShell runtime 和新程序体须按新轮次独立记录。

审查原件在 `actual.json`、copied `runner.py`、完整最小 `delta.patch` 和原 help stdout/stderr。当前结论只覆盖具名 draft03 静态和 help；没有声明 native02 或任何完整回归已经通过。
