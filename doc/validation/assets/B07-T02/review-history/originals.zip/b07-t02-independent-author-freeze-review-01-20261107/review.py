from pathlib import Path
import hashlib, io, json, stat, time, zipfile, zlib

ROOT = Path('/home/lyinn/project/Noetome')
PACK = ROOT / 'fixtures/run-api-budget-v1'
AUTHOR = ROOT / '.artifacts/b07-t02-author-freeze-20261107'
OUT = ROOT / '.artifacts/b07-t02-independent-author-freeze-review-01-20261107'
ANCHOR = 'ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272'
PINS = {}
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
    p = Path(p); a = p.lstat()
    assert stat.S_ISREG(a.st_mode) and a.st_nlink == 1, str(p)
    b = p.read_bytes(); c = p.lstat()
    assert (a.st_dev,a.st_ino,a.st_mtime_ns,a.st_size)==(c.st_dev,c.st_ino,c.st_mtime_ns,c.st_size)
    pin = dict(sha256=sha(b),byte_length=len(b),device=c.st_dev,inode=c.st_ino,mtime_ns=c.st_mtime_ns,nlink=c.st_nlink)
    if str(p) in PINS: assert PINS[str(p)] == pin
    PINS[str(p)] = pin
    return b
def obj(p): return json.loads(read(p))

started = time.time_ns()
freeze_bytes = read(PACK / 'frozen-sha256.json')
assert sha(freeze_bytes) == ANCHOR
freeze = json.loads(freeze_bytes)
assert len(freeze['files']) == 44
all_names = {p.relative_to(PACK).as_posix() for p in PACK.rglob('*') if p.is_file()}
assert all_names == set(freeze['files']) | {'frozen-sha256.json'}
for name, pin in freeze['files'].items():
    b = read(PACK / name)
    assert sha(b)==pin['sha256'] and len(b)==pin['byte_length'], name
assert read(PACK/'.gitattributes') == b'* -text\n'

for before_name, after_name, folder in [('original-author-before.json','original-author-after.json',ROOT/'fixtures/extraction-gateway-v1'),('source-copy-before.json','source-copy-after.json',PACK/'source')]:
    before,after = obj(AUTHOR/before_name),obj(AUTHOR/after_name)
    assert before == after and len(before)==3
    for name,pin in before.items():
        read(folder/name)
        assert PINS[str(folder/name)] == pin
guard = obj(AUTHOR/'freeze-author-guard.json')
assert guard['original_author_before_after_equal'] and guard['source_copies_before_after_equal']
assert guard['old_preflight_historical_guard_claimed'] is False
source_pins = obj(PACK/'source-pins.json')
for name,pin in source_pins['original_sources'].items():
    copied,original = read(PACK/name),read(ROOT/pin['source_path'])
    assert copied==original and sha(copied)==pin['sha256'] and len(copied)==pin['byte_length']

cases = obj(PACK/'cases.json')['cases']
assert len(cases)==14 and len({c['case_id'] for c in cases})==14
assert sum(len(c['variants']) for c in cases)==5
case_checks=[]
for case in cases:
    e=case['expected']; name=case['case_id']
    assert e['unknown_commitment_tokens']==8310*e['unknown_commitment_attempts']
    assert e['total_committed_tokens']==e['known_tokens']+e['unknown_commitment_tokens']
    assert e['known_tokens']%700==0
    assert e['real_model_calls']==e['paid_calls']==0 and e['price_usd'] is None and e['published'] is False and e['scientific_quality']=='not_run'
    streams=[mode for modes in case['units'].values() for mode in modes]
    known_modes={'success','fixed-invalid-candidate','preceding-success'}
    unknown_modes={'http-429','http-503','unknown-after-accept'}
    if 'near-limit' in name:
        assert streams==['success-held','success-held']
        assert e['observed_HTTP_requests']==1 and e['known_tokens']==700 and e['unknown_commitment_tokens']==0
        layout=case['execution_layout']['unit_to_run']
        assert len(set(layout.values()))==(2 if name.startswith('global-') else 1)
        assert e['simultaneous_real_workers']==2 and e['while_first_response_held_admitted']==1 and e['loser_observed_HTTP_requests']==0
    else:
        known=sum(mode in known_modes for mode in streams)
        unknown=sum(mode in unknown_modes for mode in streams)
        assert e['observed_HTTP_requests']==known+unknown
        assert e['known_tokens']==known*700 and e['unknown_commitment_attempts']==unknown
    case_checks.append(dict(case_id=name,expected_HTTP=e['observed_HTTP_requests'],known_tokens=e['known_tokens'],unknown_tokens=e['unknown_commitment_tokens'],total_committed=e['total_committed_tokens']))

policy=obj(PACK/'policies/author-policy.json')
assert policy['retry']['retryable']==['EXTRACT_API_HTTP_RATE_LIMIT','EXTRACT_API_HTTP_SERVER','EXTRACT_TIMEOUT','EXTRACT_API_TRANSPORT','EXTRACT_API_TRUNCATED']
assert policy['interrupted_process_recovery']['classification']=='REQUEST_INTERRUPTED'
assert policy['interrupted_process_recovery']['not_ordinary_retryable_report_class'] is True
expected=obj(PACK/'expected.json')
assert expected['baseline_R']==8310 and expected['near_token_cap']==9009 and expected['remaining_after_known700']==8309
rawbad=read(PACK/'wire/fixed-200-invalid-candidate.bin'); bad=json.loads(rawbad)
assert bad['usage']['input_tokens']==100 and bad['usage']['output_tokens']==600 and bad['usage']['total_tokens']==700
assert bad['output'][0]['content'][0]['text']=='{}'
same=next(c for c in cases if c['case_id']=='same-response-sha-different-attempts')
assert same['expected']['same_response_sha256']==sha(rawbad) and same['expected']['known_tokens']==1400
opening=obj(PACK/'policies/authority-opening-template.json')
assert opening['opening']['accounted_tokens']==700 and opening['opening']['dispatched_requests']==1 and opening['global_budget']['max_total_tokens']==9009

originals=AUTHOR/'package'
archive_bytes=read(originals/'originals.zip'); manifest_bytes=read(originals/'manifest.json')
manifest=json.loads(manifest_bytes); package=obj(originals/'actual.json')
assert sha(archive_bytes)==manifest['archive_sha256']==package['archive_sha256']=='bfb1e20087851150389e8f2531035c7533bad9c6086c47ad6ce1140534c5cb9f'
assert len(archive_bytes)==manifest['archive_byte_length']==package['archive_byte_length']==779533
assert sha(manifest_bytes)==package['manifest_sha256']
archive_records=[]
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
    assert z.testzip() is None
    assert len(z.infolist())==len(set(z.namelist()))==len(manifest['members'])==128
    assert set(z.namelist())==set(manifest['members'])
    for member,pin in manifest['members'].items():
        data=z.read(member); info=z.getinfo(member)
        assert info.CRC==zlib.crc32(data) and info.file_size==len(data)==pin['byte_length'] and sha(data)==pin['sha256']
        path=Path(pin['source_path']); path=path if path.is_absolute() else ROOT/path
        assert read(path)==data
        assert PINS[str(path)]=={k:pin[k] for k in PINS[str(path)]}
        archive_records.append(dict(member=member,sha256=sha(data),byte_length=len(data),crc32=info.CRC))
    before=json.loads(z.read('before-new-feature-build/source-before.json'))
    after=json.loads(z.read('before-new-feature-build/source-after.json'))
    assert before==after
    with zipfile.ZipFile(io.BytesIO(z.read('before-new-feature-build/source-originals.zip'))) as nested:
        assert nested.testzip() is None and len(nested.infolist())==125
        assert set(nested.namelist())==set(before)
        nested_records=[]
        for member,pin in before.items():
            data=nested.read(member); info=nested.getinfo(member)
            assert info.CRC==zlib.crc32(data) and sha(data)==pin['sha256'] and len(data)==pin['byte_length']
            nested_records.append(dict(member=member,sha256=sha(data),byte_length=len(data),crc32=info.CRC))
checks=obj(AUTHOR/'actual.json')
assert checks['check_count']==len(checks['checks'])==169 and all(x['passed'] is True for x in checks['checks'])
assert checks['new_feature_behavior_tests']=='not_run' and checks['freeze_sha256']==ANCHOR
for path in list(PINS): read(path)
result=dict(status='passed',producer='independent_readonly_frozen_author_archive_review',started_ns=started,finished_ns=time.time_ns(),freeze_manifest=dict(path=str(PACK/'frozen-sha256.json'),sha256=ANCHOR,byte_length=len(freeze_bytes)),frozen_payload_members=44,author_files_including_manifest=45,core_cases=14,variants=5,author_static_check_rows_reviewed=169,new_product_behavior_tests='not_run',independently_recalculated_cases=case_checks,preflight_detail_review=str(ROOT/'.artifacts/b07-t02-independent-preflight-review-02-20261107/actual.json'),package=dict(path=str(originals/'originals.zip'),sha256=sha(archive_bytes),byte_length=len(archive_bytes),members=128),package_manifest=dict(path=str(originals/'manifest.json'),sha256=sha(manifest_bytes),byte_length=len(manifest_bytes)),all_archive_CRC_SHA_length_and_source_bytes_equal=True,all_observed_file_identity_mtime_bytes_equal_before_after=True,archive_member_records=archive_records,nested_old_Core05_source_members=125,nested_old_Core05_source_records=nested_records,original_file_pins=PINS,binary_body_in_archive=False,binary_body_scope='old Core05 actual CLI identity and clean build receipt/source125/raw are bound; ELF body is retained at fixed build05 path, not in this archive',historical_preflight_guard_claimed=False,new_freeze_guard_original3_and_copy3_verified=True,HTTP_requests_from_this_review=0,product_processes_from_this_review=0,real_credentials_or_ledgers_accessed=False)
(OUT/'actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','frozen_payload_members','author_files_including_manifest','core_cases','variants','author_static_check_rows_reviewed','package','nested_old_Core05_source_members','all_archive_CRC_SHA_length_and_source_bytes_equal']},ensure_ascii=False))
