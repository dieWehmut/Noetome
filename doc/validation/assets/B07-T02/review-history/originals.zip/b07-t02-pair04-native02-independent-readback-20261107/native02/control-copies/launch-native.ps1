$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-native-02-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-native-02-20261107' --snapshot-sha256 '6c43a0513904b9d57605859bf670c3c926629b9dcd0ae66cb0498bb110c350bc' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '9ee628d17372103c3942bba4c6632aab7a440f69c1c365ccca8d527e03a70839'
exit $LASTEXITCODE
