"""Read immutable native01 preparation originals; never run the native driver."""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile


REPO = Path('/home/lyinn/project/Noetome')
BASE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-native-02-20261107')
OUT = Path(__file__).parent


def pin_bytes(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}


def pin(path):
    return pin_bytes(path.read_bytes())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')


def main():
    start = datetime.now(timezone.utc).isoformat()
    prepared = json.loads((BASE / 'prepared-source.json').read_bytes())
    control = {
        'snapshot.json': prepared['snapshot'],
        'source-originals.zip': prepared['source_archive'],
        'runner.py': prepared['runner'],
        'launch-native.ps1': prepared['launcher'],
        'precise-source-scopes.json': prepared['precise_scopes'],
        'rust-dependency-subset.json': prepared['rust_dependencies'],
        'prepared-source.json': pin(BASE / 'prepared-source.json'),
    }
    before = {name: pin(BASE / name) for name in control}
    assert before == control
    snap = json.loads((BASE / 'snapshot.json').read_bytes())
    frozen = snap['files']
    assert len(frozen) == prepared['source_count']
    assert control['snapshot.json']['sha256'] == '6c43a0513904b9d57605859bf670c3c926629b9dcd0ae66cb0498bb110c350bc'
    current_full = {name: pin(REPO / name) for name in frozen}
    assert current_full == frozen
    assert frozen['crates/noetome-cli/src/request_run.rs']['sha256'] == '606ec22cbd049f25b0e934d9606074423a07aeaac582787217e74478927c1bec'
    assert frozen['scripts/verify_request_budget.py']['sha256'] == '4f328990691946163089749c17c75bb68bc8b1db04b8daf3d5d74b4be805efaf'
    assert pin(REPO / '.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py') == control['runner.py']
    ast.parse((BASE / 'runner.py').read_text('utf8'))
    launcher = (BASE / 'launch-native.ps1').read_text('utf8')
    for argument, name in [
        ('snapshot-sha256', 'snapshot.json'),
        ('runner-sha256', 'runner.py'),
        ('source-archive-sha256', 'source-originals.zip'),
    ]:
        assert re.search(r'--' + argument + r" '" + control[name]['sha256'] + r"'", launcher)
    assert launcher.count('--snapshot-sha256') == launcher.count('--runner-sha256') == launcher.count('--source-archive-sha256') == 1

    auxiliary = ['snapshot.json', 'rust-dependency-subset.json', 'precise-source-scopes.json', 'runner.py']
    members = {}
    with zipfile.ZipFile(BASE / 'source-originals.zip') as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        assert len(names) == len(set(names)) == len(frozen) + len(auxiliary)
        assert set(names) == {'repo/' + name for name in frozen} | set(auxiliary)
        assert archive.testzip() is None
        for info in infos:
            raw = archive.read(info.filename)
            actual = pin_bytes(raw)
            assert actual['byte_length'] == info.file_size
            members[info.filename] = {**actual, 'crc32': f'{info.CRC:08x}'}
            if info.filename.startswith('repo/'):
                name = info.filename[5:]
                assert actual == frozen[name]
                assert raw == (BASE / 'repo' / name).read_bytes()
            else:
                assert raw == (BASE / info.filename).read_bytes()
    save('archive-members.json', members)

    keys = set(frozen)
    direct = {name for name in keys if name in {
        'Cargo.toml', 'Cargo.lock', 'crates/noetome-cli/Cargo.toml', 'crates/noetome-cli/build.rs'
    } or name.startswith('crates/noetome-cli/src/') and name.endswith('.rs')}
    cli = direct | {name for name in keys if name.startswith('crates/noetome-cli/tests/') and name.endswith('.rs')}
    workspace = {name for name in keys if name.startswith('crates/') and name.endswith('.rs')}
    conservative = {name for name in keys if name.startswith(('crates/', 'apps/', 'fixtures/', 'sidecars/')) or name in {
        'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'scripts/cargo_local.ps1'
    }}
    exact_sets = {
        'direct_build_rs_input_files': direct,
        'cli_cargo_and_test_files': cli,
        'all_workspace_rust_files': workspace,
        'conservative_rust_dependency_files': conservative,
    }
    scoped = json.loads((BASE / 'precise-source-scopes.json').read_bytes())
    current_scopes = {}
    for label, selected in exact_sets.items():
        expected = {name: frozen[name] for name in sorted(selected)}
        assert scoped[label] == expected
        current_scopes[label] = {name: pin(REPO / name) for name in sorted(selected)}
        assert current_scopes[label] == expected
    subset = json.loads((BASE / 'rust-dependency-subset.json').read_bytes())['files']
    assert subset == scoped['conservative_rust_dependency_files']
    assert len(subset) == prepared['rust_dependency_count']
    assert scoped['cli_scope_only'] == sorted(cli - workspace)
    assert scoped['workspace_scope_only'] == sorted(workspace - cli)
    save('independently-recomputed-current-rust-scopes.json', current_scopes)
    save('root-check-wide-plus-toolchain.json', {name: frozen[name] for name in sorted(cli | {'rust-toolchain.toml'})})

    author_manifest = 'fixtures/run-api-budget-v1/frozen-sha256.json'
    author = [name for name in frozen if name.startswith('fixtures/run-api-budget-v1/')]
    # Resolve the actual selected frozen request pack from the named input set;
    # no expected is generated from the product report.
    if author_manifest not in frozen:
        candidates = [name for name in frozen if 'request' in name and name.endswith('/frozen-sha256.json')]
        assert len(candidates) == 1, candidates
        author_manifest = candidates[0]
        author = [name for name in frozen if name.startswith(author_manifest.rsplit('/', 1)[0] + '/')]
    assert frozen[author_manifest]['sha256'] == 'ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272'

    checker = {name: frozen[name] for name in ('scripts/verify_request_budget.py', 'tests/test_verify_request_budget.py')}
    observed_current_checker = {name: pin(REPO / name) for name in checker}
    # Current public checker may be under its separately authorized timing fix.
    # This observation does not assert its source remained unchanged while native01 ran.
    save('native01-frozen-checker-vs-observed-current.json', {'frozen': checker, 'current_observed': observed_current_checker})

    after = {name: pin(BASE / name) for name in control}
    assert after == before
    copies = OUT / 'control-copies'
    copies.mkdir()
    for name in control:
        if name != 'source-originals.zip':
            shutil.copyfile(BASE / name, copies / name)
    result = {
        'schema_version': 1,
        'producer': 'independent_native02_preparation_readback',
        'status': 'passed_preparation_readback_only',
        'started_utc': start,
        'finished_utc': datetime.now(timezone.utc).isoformat(),
        'native_base': str(BASE),
        'controls_before': before,
        'controls_after': after,
        'original_control_count': len(control),
        'source_count': len(frozen),
        'archive_member_count': len(members),
        'archive_auxiliary': auxiliary,
        'archive_crc_sha_length_and_native_repo_bytes_equal': True,
        'reviewed_runner_equals_copied_original': True,
        'external_launcher_sha_arguments_exact': True,
        'scope_counts': {label: len(values) for label, values in exact_sets.items()},
        'all_current_2056_selected_input_pins_equal': current_full == frozen,
        'prepared_cache_target': snap.get('compiler_cache_target'),
        'cache_prior_native_base': snap.get('cache_prior_native_base'),
        'four_separate_named_rust_scopes_equal_current': True,
        'root_check_cli_plus_toolchain_count': len(cli | {'rust-toolchain.toml'}),
        'cli_scope_only': sorted(cli - workspace),
        'workspace_scope_only': sorted(workspace - cli),
        'author_manifest': {'path': author_manifest, **frozen[author_manifest]},
        'author_named_input_count': len(author),
        'frozen_checker': checker,
        'observed_current_checker': observed_current_checker,
        'native_state_observation': json.loads((BASE / 'native-running.json').read_bytes()) if (BASE / 'native-running.json').exists() else {'status': 'prepared_not_launched'},
        'scope': 'Read-only preparation originals and source scopes. No Cargo, CLI, HTTP, native tests or full-Python result inferred. Native02 binds its frozen checker even if current public checker changes.',
        'real_model_calls_by_this_audit': 0,
        'native_commands_by_this_audit': 0,
    }
    save('actual.json', result)
    print(json.dumps({k: result[k] for k in ('status', 'source_count', 'archive_member_count', 'scope_counts', 'root_check_cli_plus_toolchain_count', 'author_named_input_count')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
