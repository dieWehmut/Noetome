"""Audit closed pair04 / focused originals; no product execution."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

REPO = Path('/home/lyinn/project/Noetome')
ART = REPO / '.artifacts'
OUT = Path(__file__).parent
PAIR = ART / 'b07-t02-linux-pair-04-20261107'


def byte_pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}


def pin(path):
    return byte_pin(path.read_bytes())


def normalized(value):
    return {name: {k: v[k] for k in ('sha256', 'byte_length')} for name, v in value.items()}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def check_command(folder, expected_count=None):
    actual = json.loads((folder / 'actual.json').read_bytes())
    assert actual['exit_code'] == 0 and actual['source_before_after_equal'] is True and actual['source_delta'] == {}
    before = json.loads((folder / 'source-before.json').read_bytes())
    after = json.loads((folder / 'source-after.json').read_bytes())
    assert before == after and len(before) == actual['source_count']
    for label in ('stdout', 'stderr'):
        assert pin(folder / (label + '.bin')) == {k: actual[label][k] for k in ('sha256', 'byte_length')}
    stdout = (folder / 'stdout.bin').read_bytes()
    summaries = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)
    if expected_count is not None:
        assert [tuple(map(int, row)) for row in summaries] == [(expected_count, 0, 0)]
    copied = OUT / folder.name
    copied.mkdir()
    for name in ('actual.json', 'source-before.json', 'source-after.json', 'launch.json', 'stdout.bin', 'stderr.bin'):
        shutil.copyfile(folder / name, copied / name)
    return {'path': str(folder), 'actual': pin(folder / 'actual.json'), 'source_count': len(before),
            'source_bytes': normalized(before), 'summaries': [tuple(map(int, row)) for row in summaries],
            'argv': actual['argv'], 'pid': actual['pid'], 'exit_code': actual['exit_code']}


def main():
    actual = json.loads((PAIR / 'actual.json').read_bytes())
    before = json.loads((PAIR / 'source-before.json').read_bytes())
    after = json.loads((PAIR / 'source-after.json').read_bytes())
    assert before == after and len(before) == actual['source_files'] == 130
    source = normalized(before)
    assert actual['source_before_after_equal'] is True
    assert pin(PAIR / 'source-originals.zip') == {k: actual['source_archive'][k] for k in ('sha256', 'byte_length')}
    members = {}
    with zipfile.ZipFile(PAIR / 'source-originals.zip') as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(source) and len(archive.namelist()) == len(source)
        for name in archive.namelist():
            members[name] = byte_pin(archive.read(name))
            assert members[name] == source[name]
    assert pin(PAIR / 'noetome') == {k: actual['cli'][k] for k in ('sha256', 'byte_length')}
    assert pin(PAIR / 'request-test-driver') == {k: actual['test_driver'][k] for k in ('sha256', 'byte_length')}
    for label in ('cli_probe_stdout', 'cli_probe_stderr'):
        filename = label.replace('_', '-').replace('cli-probe-stdout', 'cli-probe.stdout').replace('cli-probe-stderr', 'cli-probe.stderr') + '.bin'
        assert pin(PAIR / filename) == {k: actual[label][k] for k in ('sha256', 'byte_length')}
    envelope = json.loads((PAIR / 'cli-probe.stdout.bin').read_bytes())
    assert envelope['compiler_fingerprint'] == actual['actual_cli_fingerprint']
    assert actual['cargo_build_script_fingerprints'] == [actual['actual_cli_fingerprint']]
    assert actual['cli_probe_exit_code'] == 0
    launch = json.loads((PAIR / 'cli-probe.launch.json').read_bytes())
    assert launch['pid'] == actual['cli_probe_pid']
    commands = {}
    for folder, count in [
        ('b07-t02-root-check-03-20261107', None),
        ('b07-t02-root-cli-build-03-20261107', None),
        ('b07-t02-root-driver-guards-03-20261107', 2),
    ]:
        commands[folder] = check_command(ART / folder, count)
    for label, key in [('build_receipt', 'b07-t02-root-cli-build-03-20261107'), ('driver_guard_test_receipt', 'b07-t02-root-driver-guards-03-20261107')]:
        assert commands[key]['actual'] == {k: actual[label][k] for k in ('sha256', 'byte_length')}
    mismatches = {key: {name: {'command': data['source_bytes'].get(name), 'pair': source.get(name)}
                        for name in set(data['source_bytes']) | set(source) if data['source_bytes'].get(name) != source.get(name)}
                  for key, data in commands.items()}
    cargo_fp = set()
    cli_artifacts = []
    driver_artifacts = []
    for folder, artifacts in [('b07-t02-root-cli-build-03-20261107', cli_artifacts), ('b07-t02-root-driver-guards-03-20261107', driver_artifacts)]:
        for line in (ART / folder / 'stdout.bin').read_text().splitlines():
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get('reason') == 'build-script-executed':
                cargo_fp.update(item[1] for item in row.get('env', []) if item[0] == 'NOETOME_RUN_COMPILER_FINGERPRINT')
            if row.get('reason') == 'compiler-artifact' and row.get('executable'):
                artifacts.append(row)
    assert cargo_fp == {actual['actual_cli_fingerprint']}
    assert any(row['executable'] == actual['original_cli'] for row in cli_artifacts)
    assert any(row['executable'] == actual['original_test_driver'] for row in driver_artifacts)
    assert all(not differences for differences in mismatches.values())
    assert all(pin(REPO / name) == old for name, old in source.items())
    current_delta = {name: {'archived_pair': old, 'observed_current': pin(REPO / name)} for name, old in source.items() if pin(REPO / name) != old}
    copied = OUT / 'pair04-original-controls'
    copied.mkdir()
    for filename in ('actual.json', 'source-before.json', 'source-after.json', 'cli-probe.launch.json', 'cli-probe.stdout.bin', 'cli-probe.stderr.bin'):
        shutil.copyfile(PAIR / filename, copied / filename)
    result = {'producer': 'independent_pair04_and_focused_originals_audit',
              'status': 'passed_closed_originals_readback',
              'pair_actual': pin(PAIR / 'actual.json'), 'pair_source_archive': pin(PAIR / 'source-originals.zip'),
              'source_member_count': len(members), 'source_members': members,
              'actual_cli': actual['cli'], 'actual_driver': actual['test_driver'],
              'actual_cli_fingerprint': actual['actual_cli_fingerprint'],
              'actual_cargo_fingerprints': sorted(cargo_fp), 'actual_cli_probe_pid': launch['pid'],
              'commands': commands, 'command_source_differences_from_pair04': mismatches,
              'observed_current_source_differences_from_pair04': current_delta,
              'native_build_or_product_calls_by_audit': 0,
              'scope': 'Closed Linux pair04 and focused actual originals only. The actual2 output guards are not full workspace/native/OSkill coverage. Per-command source and later current source are explicit separate comparisons; new status/checker source needs new final runs.'}
    save('actual.json', result)
    print(json.dumps({'status': result['status'], 'source_member_count': len(members), 'command_mismatch_counts': {k: len(v) for k, v in mismatches.items()}, 'current_difference_names': sorted(current_delta)}))


if __name__ == '__main__':
    main()
