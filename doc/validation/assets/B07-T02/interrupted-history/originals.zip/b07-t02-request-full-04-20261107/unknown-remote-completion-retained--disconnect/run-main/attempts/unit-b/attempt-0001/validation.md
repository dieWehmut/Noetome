# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d0cb12aad839ccf8cf6ea3e4be5e971d374e19f65e80f92f13ae67b7019b9ea6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "125f61aa044dfdecd3863474b774f6ec82096c21d7a5f62c7f052745566429c3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7d9079704f0f96a9103a2966cfe5a3ead94cc1d895b287d1b14202a3f68c30b5"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "269e4bdd6f5f6b411d97da4282392a5c77a92a1328dd571e885a6076c2f23993"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c4b33532a38b8ca5c87c74744548aaa2baedeb4bce8caa624a2202dc63d3f2d5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8c3c6b2e9727c1945b000b2fba9c90cb3efb2b495f8fcb3213ed0c8b0d48efea"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a6213b88-4c76-4c97-b921-0bf8caa9cb22",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bab96b69-7489-46d9-a93a-be6132753397",
    "source_id": "0b81a817-65ac-4123-91eb-722319d3c124",
    "version_id": "d6962db7-a990-47f5-8700-4b6f98124bee"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38315/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "88876d28-0cc2-4bed-8ea9-43fa022db9a4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c4b33532a38b8ca5c87c74744548aaa2baedeb4bce8caa624a2202dc63d3f2d5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
