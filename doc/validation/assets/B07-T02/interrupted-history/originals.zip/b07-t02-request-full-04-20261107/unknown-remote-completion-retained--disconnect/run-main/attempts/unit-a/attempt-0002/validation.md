# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0d2468e02be0e6055406e863c614d6d7a492565326655de3de9c201e35553e7a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "bdd3481376c84ff9335096ccbc97ab5471ec481e7b5759faabf58d089442edf7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a4821a8b843a85f1203183d7b4ba101470bf5e4c71429b30b52b1d493b0a5586"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "d33c9645b8e608d7bc13aa728ed4f1ae9b91b386d7f87aeea0d968df1dbaa9f2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "86ce16693ab0c828a08ce7edb00622822c36e93d07dbac5368b5676e08547623"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c2b0e2140bc2b0d7d11650dc4f7a48f6c159d41faed9e799295bfafdc6398e62"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cd5d2702-2ded-42c7-ac73-02e5be899f07",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "20f5ba5d-b5d6-4bb7-8344-52fdcf75f10e",
    "source_id": "cca48614-f6a1-4068-b7f7-5f057e2d329b",
    "version_id": "a2fe0d09-4b4c-425b-8971-1aac26c91fba"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38315/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6a1913cc-0694-4f53-b527-d1eb6e4aa1c7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "86ce16693ab0c828a08ce7edb00622822c36e93d07dbac5368b5676e08547623"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
