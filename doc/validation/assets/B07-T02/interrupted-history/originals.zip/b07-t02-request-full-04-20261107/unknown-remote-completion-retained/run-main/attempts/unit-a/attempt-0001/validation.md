# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1c271cbeeb726370d939c3ec3ed226ff00187ac8096db75d30c08a8d9e77c73c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "50205b9c8efb7aea3ca18cb707107ea55c6f13fe3133978ce8f49dba43414740"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "dab3de6307aa30408b1bb107e9b87813ca1517aa3aab9b479a4b9329f6e6da93"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "e328c5b2d102a098796c5751f3c6dcad8859e65d11cadbc526894d4aed5959d5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5558323b-fe53-45ef-9b43-cc62ce6330ed",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c7f7b25b-8ec7-4912-870a-96782aa349fa",
    "source_id": "b96f7c8a-01c2-4cb5-91e2-33d9cfe35766",
    "version_id": "433c2764-4065-4521-be6f-90eb8ac9e4b4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36831/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4b35d272-95c2-4834-9f23-3d1c549b3d9b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
