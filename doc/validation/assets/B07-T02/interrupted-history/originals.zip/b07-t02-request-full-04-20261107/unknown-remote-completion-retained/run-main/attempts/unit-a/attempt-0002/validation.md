# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c48a032b1874a119e847f7133e00f5d535463a73bc2676ac70064998e4cc8cbe"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "963525caaf741d4f68f87e2b450c9a5c15a94434f5060d22b30f1c43411f7614"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c7a8b8493a78ee83e6d1988b10b6981f26f4ceb4f0883d83d51a097badebc9d6"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "0eafe6b12bc46e770391da9c42c74749610ed6ba8e2024b8ee90f0b5a7f76c50"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b83525467455e47c7cd8996e8258b22fe98d7f4d7081dba6450c05b605ff7971"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7d67344666ead556eb69c7f301fca18e010bfaa464b6f8492691fd7c9e147d7e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5558323b-fe53-45ef-9b43-cc62ce6330ed",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c7f7b25b-8ec7-4912-870a-96782aa349fa",
    "source_id": "b96f7c8a-01c2-4cb5-91e2-33d9cfe35766",
    "version_id": "433c2764-4065-4521-be6f-90eb8ac9e4b4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36831/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b7b8b42c-857d-4413-abc7-2f791e98fc9d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b83525467455e47c7cd8996e8258b22fe98d7f4d7081dba6450c05b605ff7971"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
