# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "73e8f94651813751d7926261c01f3247623375f645d0a101ae46d8146897e50a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f9f47ef5ea0d8bf863972d24ab7ac2970d9f977fa7dbf7daf7fca406f7aea54c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ddd0aba2c9915ddba6c5c4a66534f93949ba839b3f4c594241425bbb9c14cb31"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "48d0cb336b6dd86461f8b59d04093fdbb53113941613662d912853824d6dfb9a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "18367f38d36d446ad5a4e52590cff16c180eec346c770c2b26d24e083a3ac1e9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b4c84c8c1b71efa6495e693b952a17a9ea40cbccbed4dfdcb934d65145976c18"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "25e45b42-e3b8-42d4-84a3-c5bb515bd4d3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b731d2c6-ba0d-42ef-84a2-7e4df90227f0",
    "source_id": "79b2d338-632f-4a75-8ddd-9f39636851b3",
    "version_id": "ce11e77c-f484-47d9-964a-5ed2a220ae92"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36831/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7e838e0b-1088-48e6-83b5-73087e40a86c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "18367f38d36d446ad5a4e52590cff16c180eec346c770c2b26d24e083a3ac1e9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
