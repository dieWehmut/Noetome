# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4fb99d03b9df854010d15c9080a83a55c092935eb8fcc1cb9bc72d40f8fda094"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3a0fa5b5d683d3ebaa07954c2ca6e419916dadca378d22beb2b2349e4c8641f0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bc7ddc91b107fc443a3406dbf87e3e5a5c62785131649898a9e1184d17a770f0"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "d83ae6622205aa004aba7857e06873d54d344244977ca9946fbb09b64f179c47"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f2e8cb02961f31903664826791d28a4f03295020fc32e060e5fbfe2d7a115931"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f484fb46f1e10e7a29b88a0fb4619532db2e210fd48edb9aecfb64428be82947"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6692d68a-1ea0-4e6d-ad6d-4da0931d1cef",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b74ad2fb-3934-4553-8f2c-c18df5fb7ba6",
    "source_id": "0688b03a-5a7e-4596-a4d9-b234d0ac229a",
    "version_id": "387af8e7-2d77-4aa6-a492-a48d366e0d2a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37943/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "31e27fea-e22e-45b3-8233-556e99483b06",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f2e8cb02961f31903664826791d28a4f03295020fc32e060e5fbfe2d7a115931"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
