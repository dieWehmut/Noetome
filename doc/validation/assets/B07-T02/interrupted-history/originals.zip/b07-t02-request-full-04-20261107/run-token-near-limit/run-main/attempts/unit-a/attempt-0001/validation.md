# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "01ed2356192b82a209dd0f7b864ba11c741de402075fceac3013c2f79c4f16e0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "50cb319f5670f1f1017c6dff53dfe70bc762a5d8c9b9f3f6f1350f0056861dff"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9399e09ca2f996085fb7487c3b6f3fe781dbd3bb6d9d780f60605bd31a11e44e"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "4e30f45a80eb699e3d71bef869ef74604f53edcc937e60e9d92fc061f9730296"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2315982f3d7fe7e921b2e3191b74cd07005bc3c023946786a6d75f00d6ae1611"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "505c7d0db4220f03d5798c4cdac739b17f1b44f56ab259783978a851d0155936"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fef97395-4f67-4d40-b04a-4df3ed682122",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8c7a70f9-e2a8-4f13-969b-1c482390f4d1",
    "source_id": "5ed331ed-068c-4271-a7ba-42d37166a784",
    "version_id": "5484a84c-e5d9-4d7b-9d92-2ebf39fb8c7c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38365/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4146b0a8-9d37-4427-b8ae-267dd653ccb9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2315982f3d7fe7e921b2e3191b74cd07005bc3c023946786a6d75f00d6ae1611"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
