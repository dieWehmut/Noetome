# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "25a16fa9e7ad09bb7fd1e1e1b4053438859b490a589b79129f4a5d9e5aa63210"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3edbb73c97521fe3f96e827e8b119d839c716f25f80d74aba1b6e56c09cfbcf0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c403b70709e04ac7cbbdccd807d8b9545c8b071024724ef9d588a87953bf457d"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "4c52f2bfc93a4486e849e14e41a67c2800fbc4de5c8e442fcd08a8fcf662f867"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0d933b2b8f2c04e87572c77996ebc3dc668d8614b7f1f40492b695b31ae93020"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f615f4d5863ff5f39cd9e6b3a961a1f9f555da75a39a94c95888e3fd9472394d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a5aa23d1-a379-4b59-a49b-142bb309013f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ec2de59b-d19e-4ac9-9e94-88e21f17b3ba",
    "source_id": "9a39b064-89dd-4170-acbc-141d117684e2",
    "version_id": "f7b81e4d-d3bf-475e-9e41-a7cad170318e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36505/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7a144357-67de-4324-b722-e197bfb32035",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0d933b2b8f2c04e87572c77996ebc3dc668d8614b7f1f40492b695b31ae93020"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
