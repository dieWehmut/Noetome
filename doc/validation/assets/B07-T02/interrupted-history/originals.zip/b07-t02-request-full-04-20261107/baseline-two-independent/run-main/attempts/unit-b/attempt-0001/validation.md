# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "17a75587a83b61572d6f0c2ee87389b357968b00b2b6e0981f7e0efce115082d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0a05219158c3acb6791c27624ebaf8a389ef1bbb42495a45dfa77c7d32747d8f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7409cf94ac80481c01c5e7cf88003fbb0bde20a63c1ff1af2bfd3da171857b85"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "9891599dca3ceb7e7a5f431dd0a266c1c27b0ed4e029372aa175768cbe5d5f1f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ca3411bee9911ed68c647e3a3235157765b5c06cbe92627a8ffea927bea39456"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d268ed736a3b089c70128692267d57021b2743a9eb76d8c1d3b9c47582d7f4c6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1b53c426-2b31-4d88-9dcb-8d1c2551226f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "12692042-6227-419a-975a-6c21e5943ffb",
    "source_id": "6915af05-0081-40b5-b4a5-8f12fc6c4270",
    "version_id": "99c17e9d-4792-445b-a3d0-b70096d6b7bb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38299/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1d154d85-bd5a-43cf-a662-e938dc0d84d8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ca3411bee9911ed68c647e3a3235157765b5c06cbe92627a8ffea927bea39456"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
