# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dcab3f9c8d1b55254a4f97e7834f005b3a4070d70b0daafdefff969736120bcc"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e9235c33f0295a1d2a1321c5803bcedbbbabd39e72ebd7639ec4d116835f4412"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "08961b7294a4b66f3d1b00ce48ab6eb18b31bf22d3a25edc9ce519421aaf544b"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "f58adafb67d633bfd8002ecfc94c9bdca487fbb28676d6a9d191dd5c58445923"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4690d2a86f68d7273ed6f77e1cddcd13d96734cf394ab55c25b9f6cfeec4cdbc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cb885d4cac2249d2cc957fe2ca7642e5eee991df99ead87908064f8eeaa28b0d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "05db694c-6444-4578-8a3e-c578b6f70e40",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "63d2cafa-f1b4-4b06-8617-35e0094199dc",
    "source_id": "3cc68cd4-6012-4273-bedc-579265102e39",
    "version_id": "8559f961-150f-4793-8bf6-9208b172fb31"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38299/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "41820cb5-ee1b-4120-812d-f8631f9016f3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4690d2a86f68d7273ed6f77e1cddcd13d96734cf394ab55c25b9f6cfeec4cdbc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
