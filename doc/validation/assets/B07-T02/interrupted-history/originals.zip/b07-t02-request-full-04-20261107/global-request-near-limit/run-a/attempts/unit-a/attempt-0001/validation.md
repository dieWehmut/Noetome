# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "91092dac15cfa797af91c9984f08ac8a731da24d578959c628c6cc41325e271e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "15dad0d10438587130e9aba4a0d017c0e5da0df1e07948b6dd7465593c7aa3ca"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2210550b1318f34b68a05af83c66939deafef851f83850e8087ee9f0f88c16d7"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "baaa8a982c1e842f6a1cff9c4a7dadf053f31798219a636e5a7ffad7f16a4dfa"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f61760cbc25e8e15d6ad736eae5a7f057df5340de982283b1302cd193201194e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1eb6aff30758994d0821723193f85d3275475a144a0b7806d69af190626599e5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "32eec309-0b9b-4fd2-988d-d3277f7fd239",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2279f6bc-9ec4-4224-9332-6d7e3d180ffa",
    "source_id": "b091b63c-d9b9-41fd-8dbc-30ae938acc97",
    "version_id": "48a754e8-659b-4e59-839b-cd3b409044e3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37091/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "be5869bc-43b7-4527-9b43-cc13ac0e48f0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f61760cbc25e8e15d6ad736eae5a7f057df5340de982283b1302cd193201194e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
