# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "532f0a6eb26daf3ce67299023796f176ab9385795751711ea8f8931d15e6851a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a77ae4ce34c6e83505e7b4306c711c8bb4bc3f60768c67e73d90c77c5b7cbd91"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2e67972d90c1f92b4a7a9a7b57917acb7ba503b0096f55d6929818149779e7fb"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "b3761a5171b8645182ba454beba04546881fdf8bcb6bb6463ed24d2b9f6c18e0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "dda61c90883af395fafed98a5d2f940451c3ad64295c7099c9cd7a932759bf76"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "66e44cdb3e878f1af9805620b6540b5c736073c03e975eb1b76111ac3073a7f0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "20bf2b8d-481f-40c0-818c-ba7854951b73",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "49b7413d-f6f7-46dc-9055-709435a4a4ff",
    "source_id": "162f8723-7675-44ac-8297-121b1164d3ad",
    "version_id": "44608630-09fd-4aa3-8591-21e553a6bcb3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36541/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e2c95350-0458-47e9-848b-a0b7d042ce77",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "dda61c90883af395fafed98a5d2f940451c3ad64295c7099c9cd7a932759bf76"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
