# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c3e80ea21de3f57441685564392f8a3fd46bc73e8c8a273661cb8daca50f23e1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "875ef909c20a9d928464a9e89ae1a36f07b532b5114c91b94af5b0c2014bc2a0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "132e37c439c32303f8448dd947b033ae816b673d5bf959f764ef17485ef17cd5"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "74c55de043a4a333a62ecd9f0f1771dbec4663973a87526563f7179ffa61eb71"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4ac371f3ae41f91b3a11573c57c40eb39bd8187ed38643c7e04a275b45b32911"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "902106a8f2b9b94998163321ec0f9c7207618659711a3fc8b130f1c24339c1c9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2591d3f9-47c4-4f40-8ba8-78bcf55fc566",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3b5b900e-5d75-4bcc-a073-d50c10e77f77",
    "source_id": "65809f14-d264-4022-8f95-202021c67c84",
    "version_id": "721911d3-2047-4e86-9e20-840b8850318c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36541/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e4b1ee7a-b907-4fde-ab7e-70a53fb2c963",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4ac371f3ae41f91b3a11573c57c40eb39bd8187ed38643c7e04a275b45b32911"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
