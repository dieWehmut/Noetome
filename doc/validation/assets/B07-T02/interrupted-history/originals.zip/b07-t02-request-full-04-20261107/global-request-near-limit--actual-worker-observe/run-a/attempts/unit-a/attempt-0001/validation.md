# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e63be53ac8cea28f258e531f8cd88ac1784697f30fb38739640a988fa91c826d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d8aa9d96c774cdcfc34f5bf09100297ea6f7b5d7053a8e5441eda7c1f6e51051"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b052a060810492e752340c197d28150e2071f600e2fa17f8894a1019733de6a7"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "4e78de7492df9561e299144f256158a4e10447171b52626cc70a8dc71d589973"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "850ae07d198449cc1dbbc04286d7d6f47530f81f20956212a1853b2673d016d1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "81642ff26ef577abb21ec1d7fc2c807b082d436bf55775caad9d0c5a23b96158"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cfe8e775-4b45-4aaa-b169-c454dd291a16",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "50bbe4ee-f5ca-4c0e-9323-e2d7df3f6164",
    "source_id": "d93c3f0b-f830-4a02-ad3a-ffe08359975c",
    "version_id": "d5d3d4b7-5a76-4787-b80f-3c9c04f64127"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38101/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "661cb59e-baaa-4f59-bbae-7351e5230d7a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "850ae07d198449cc1dbbc04286d7d6f47530f81f20956212a1853b2673d016d1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
