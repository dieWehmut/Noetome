# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a3b5df707d7afc25a6e35ccca7cb2ca85fa73ee0c537d04ed17470d6e42ef362"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d7d2a8254459c71473cefeca8cf8e8d02a85bebcfdf5916f73e0ae53bde81f9d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9ec82f8e6506155731f35da6351398bb16a3239778dcef670afff7ba48e21b0f"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "82b7afbb1bed1f4e4e344354c2c21a692d78bec5b73cf5ff6bba41116cac5069"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "efff793f623d49aa243f3f0dcbe5a736acb81c3b39b2f9cde34996a9004f81df"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "13792b3217b3e66b0b4b44350e3d635d7b4f8ae0aa7e0cc6dc8bbdaa071f7ec6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b2002f41-7b70-4206-abcd-c23849943c3a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4df10732-8e75-4ef2-afe7-93e8412f84d8",
    "source_id": "6c0c4eaf-89de-4666-9b88-f8ef960f617a",
    "version_id": "1eef9576-6adf-4d40-9c1b-f0ac8afc254c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37069/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d02ec4ab-6226-4f99-88d7-ee39e82bbc8b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "efff793f623d49aa243f3f0dcbe5a736acb81c3b39b2f9cde34996a9004f81df"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
