# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "86cfd244b8a4c8d3ccdb576012c5349f2871a46af8f6a51491720ae37229af48"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6df9463ae435425a99acc93f065e6145ed8eafd0d72a18cff4a712c2f45cf8ba"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f97c538d8e762c134dbf609fbe679acd0f19dc658f26b156b71cbe3d036269d4"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "2cc6dda0fa5ce40736226a83e963d74311f7fb4d9faaa7962fc716789cef812c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e02f2582f2c3f118c285f8e9876e184b8df04da15a807ec6521a0f4be9dadb38"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a2b168e91aec3126683e88f3b924fb756f1b34aad7091e5c0d3e96b19115c699"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "63accb98-b2ad-440f-957e-20372cd3e65e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "396fee0b-541e-4cc1-b1f4-db521606e34e",
    "source_id": "91f74161-f429-4a00-931a-cc28e8af5d24",
    "version_id": "9c03af59-9730-4ef7-9c1c-f181c702af85"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38353/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ce680568-8f5b-460c-af6d-e2e472ecbe61",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e02f2582f2c3f118c285f8e9876e184b8df04da15a807ec6521a0f4be9dadb38"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
