# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1d7ceda84e1b2a9b12129a3a5b976ff666f185cb26b0e4cd6fe59bb957cf96e5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e7f35e9cbd5c2adf5d44d9f8da5cdd68feb664d453a03015e961b50f64c601cc"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cf83edafcd06b9bcdcfc1a7978a6855864cadaa6142759523aa04ff631cd6909"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "580e8139d89ff7ecf274fa60dbfe339d909372412179cd41b3be7932f2996b8c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0d93c04e03469d308c1cdf8ef23f21ada5a912c10422cc0b096c7ef5bcf18611"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e817f36eb4ed1a19241dfeeee20eeef7da2ea3ee6232c66d0eb2efbf04a28651"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "dbe77b5b-b616-4a04-979e-e8f42ec2f4f9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5d7a2a30-307a-4f48-8299-0e814cf80c1e",
    "source_id": "59373cfc-5ae1-4831-b625-b0717d4d0d24",
    "version_id": "f8ae2c33-0b56-4f31-86a7-97120f8d95a6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37861/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "120c3427-25d4-402f-b384-807c02a42990",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0d93c04e03469d308c1cdf8ef23f21ada5a912c10422cc0b096c7ef5bcf18611"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
