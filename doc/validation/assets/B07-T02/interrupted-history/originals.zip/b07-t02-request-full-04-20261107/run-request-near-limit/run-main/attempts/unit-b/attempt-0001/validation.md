# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6155552ce83a67dedb4da38e8f740448d2d9d3a0db6d9339eb1c2627d877936e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c0558e2626c6400212d8c6060d85897940a6e24491416234dddcb5fd6e40b6ca"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5f32734dfca2b831b4fd3958dc8c1dd07ba7822d85da35c4c4ffc8a8f47a87a3"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "8f8fd8d232f5c685a919cb71458b7b0d67e385610bf5b0b7113c456f6d79f4b6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5828a4852b1f11ba90613e4fb71328dea674b6205da895998768fecf08549e9f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "128948756deff0d0581329934b8f1ebc4c91a827d74ff3e4da838ae121b1318f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0c2bf140-ba46-41e9-84a0-ea0fd9a5535b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8b9b367d-74bf-48b6-9ea1-ab60a4d9ebef",
    "source_id": "0d9399e7-8325-4f48-b56f-fa683ec2a493",
    "version_id": "aacef969-e397-497f-a7ae-d9aad9db6d23"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36907/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9bee3383-43f9-443e-a076-9c1e0e647a53",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5828a4852b1f11ba90613e4fb71328dea674b6205da895998768fecf08549e9f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
