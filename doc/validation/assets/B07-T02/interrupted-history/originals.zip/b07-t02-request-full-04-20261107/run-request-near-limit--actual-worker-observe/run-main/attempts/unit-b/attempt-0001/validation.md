# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e4ebc6ac3b2cca0af399f796051345d0dc1b8666c28fa5fb863c5cfd07c430b4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e52eb908bd9b0197ee1e0d45e078dc180f80bdc32c4c633da2f162f90d340038"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c5e9e118de3ae040c50e104082311469a46bd8a10eee40483215f2abff4d174c"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "03e567bd27058cc1a91261cca9e6e67efb8c0b9a35cc5422ebae8b91746a0a93"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b2d3a0eea8ccf61d1cc8c068feaf1ed52f8dbc2f770edf18fbcfaac39ae84b8d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b338aa704e5d8b2d883570c059d86fee9eec70d0c925b18b40b49a463b26ac42"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "409252b2-3c4e-4b07-aec4-9f5e78f6eb04",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "78ea70af-bd50-43db-b608-01de44da40e4",
    "source_id": "baf1fcda-b682-420f-b681-6cac8c2a9f0f",
    "version_id": "f0bb51b3-dbd4-43d3-b3fb-f270a673c89f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36621/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "670cd6dc-86e8-4e1b-9d0e-ea61606cbb5b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b2d3a0eea8ccf61d1cc8c068feaf1ed52f8dbc2f770edf18fbcfaac39ae84b8d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
