$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-02-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-02-20261107' --snapshot-sha256 '19d202c2ba27de0f98509bd84c71da2d3029586d9d3ac63981e207b918538914' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '68f6a44d1a2d7535183e8fc0d358de5553cd848b0f7a88e652be61a2fd99e82d' --executor-sha256 '30ad5487a56460e29f85acc2e99d1c7801a5482de9752bf5d2d3231d1379b0d3'
exit $LASTEXITCODE
