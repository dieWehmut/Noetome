"""New source-bound native release CLI/driver build only; no full tests/Python/HTTP."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import shutil
import sys
import zipfile

RUNNER_SHA = '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1'
RUST_SHA = '2e7357871bc000afc308abc4de4db0d131bfe86cadb93471e5fe0063beb33b06'
PYTHON_SHA = '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7'
TESTS_SHA = '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348'
CONTROL_NAMES = ('snapshot.json', 'source-originals.zip', 'runner.py', 'launch-native.ps1',
                 'precise-source-scopes.json', 'rust-dependency-subset.json', 'prepared-source.json', 'release-executor.py')


def ordinary(path):
    path = Path(path)
    for part in (path, *path.parents):
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('linked/reparse path before read: ' + str(part))
    return path


def metadata(path, *, temporary_cargo_output=False):
    path = ordinary(path); info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink < 1 or (not temporary_cargo_output and info.st_nlink != 1):
        raise RuntimeError('source/control/program is not a regular single-link file: ' + str(path))
    return {key: getattr(info, key) for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')}


class StrongFiles:
    """One fixed metadata baseline; registration never refreshes an old path."""
    def __init__(self): self.initial = {}

    def register(self, path):
        path = Path(path); observed = metadata(path); key = str(path)
        if key in self.initial and self.initial[key] != observed:
            raise RuntimeError('attempt to refresh changed metadata baseline: ' + key)
        self.initial.setdefault(key, observed)

    def check(self):
        for path, expected in self.initial.items():
            if metadata(path) != expected:
                raise RuntimeError('original file actual identity/time/length/link changed: ' + path)

    def capture_sources(self, base, source_root):
        for name in CONTROL_NAMES: self.register(base / name)
        # Controls were checked as ordinary files before decoding this path list.
        snapshot = load(base / 'snapshot.json'); self.check()
        for name in snapshot['files']:
            if name.startswith(('/', '\\')) or '\\' in name or ':' in name or any(p in {'', '.', '..'} for p in name.split('/')):
                raise RuntimeError('unsafe selected source relative path')
            self.register(source_root / name)
        self.check()

    def receipt(self):
        return {'files': self.initial, 'fixed_initial_metadata': True,
                'file_actual_ID_mtime_length_singlelink_guard': True,
                'ancestor_reparse_checked_before_reads': True,
                'directory_actual_identity_guard': False, 'runtime_tool_actual_identity_guard': False}


def pin(path):
    h = hashlib.sha256(); length = 0
    with Path(path).open('rb') as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b''): h.update(b); length += len(b)
    return {'sha256': h.hexdigest(), 'byte_length': length}


def load(path): return json.loads(Path(path).read_bytes())


def module(path):
    before = metadata(path)
    if pin(path)['sha256'] != RUNNER_SHA: raise RuntimeError('original reviewed runner differs')
    if metadata(path) != before: raise RuntimeError('original runner metadata changed during hash')
    spec = importlib.util.spec_from_file_location('release_original_runner', path)
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old); return old


def extra_controls(base, old):
    prepared = load(base / 'prepared-source.json'); expected = prepared['release_executor']
    old.require(pin(base / 'release-executor.py') == expected, 'sealed release executor original differs')
    return {**old.controls(base), 'release-executor.py': expected}


def prepare(args):
    ordinary(args.original_runner); ordinary(args.repo)
    old = module(args.original_runner.resolve())
    for name, expected in [('crates/noetome-cli/src/request_run.rs', RUST_SHA), ('scripts/verify_request_budget.py', PYTHON_SHA), ('tests/test_verify_request_budget.py', TESTS_SHA)]:
        metadata(args.repo / name)
        old.require(pin(args.repo / name)['sha256'] == expected, 'current selected source freeze differs: ' + name)
    old.prepare(argparse.Namespace(repo=args.repo, native_base=args.native_base, freeze_label=args.freeze_label, cache_target=args.cache_target))
    base = args.native_base; shutil.copyfile(Path(__file__), base / 'release-executor.py')
    frozen = load(base / 'snapshot.json')
    if args.cache_target is not None:
        prior = args.cache_target.resolve().parent
        cli_receipt = load(prior / 'release-cli-build.json'); outer_receipt = load(prior / 'outer-native-result.json')
        old.require(cli_receipt['exit_code'] == 0 and cli_receipt['guard_error'] is None and cli_receipt['source_before_after_equal'], 'prior cache CLI compilation or source guard did not complete')
        old.require(outer_receipt['worktree_before_after_equal'] and outer_receipt['control_originals_equal'], 'prior native cache process/source closure missing')
        current_scopes = load(base / 'precise-source-scopes.json'); prior_scopes = load(prior / 'precise-source-scopes.json')
        keys = ('direct_build_rs_input_files', 'cli_cargo_and_test_files', 'all_workspace_rust_files', 'conservative_rust_dependency_files')
        old.require(all(current_scopes[k] == prior_scopes[k] for k in keys), 'prior cache and current compiler dependency names/bytes differ')
        frozen['cache_scope'] = 'Dependency/object cache only. Both current release Cargo build commands execute again; no previous test/build success or executable is reused as acceptance.'
        frozen['release_cache_evidence'] = {n: pin(prior / n) for n in ('snapshot.json', 'precise-source-scopes.json', 'release-cli-build.json', 'outer-native-result.json')}
        old.save(base / 'snapshot.json', frozen)
    # Freeze the final accurate cache description in the source archive itself.
    archive_path = base / 'source-originals.zip'; replacement = base / 'source-originals-prepared.zip'
    with zipfile.ZipFile(archive_path) as original, zipfile.ZipFile(replacement, 'x', zipfile.ZIP_DEFLATED) as archive:
        for item in original.infolist():
            archive.writestr(item, (base / 'snapshot.json').read_bytes() if item.filename == 'snapshot.json' else original.read(item.filename))
        archive.write(base / 'release-executor.py', 'release-executor.py')
    replacement.replace(archive_path)
    with zipfile.ZipFile(base / 'source-originals.zip') as archive:
        old.require(archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == len(load(base / 'snapshot.json')['files']) + 5, 'extended release source archive inventory/CRC differs')
        old.require(archive.read('release-executor.py') == (base / 'release-executor.py').read_bytes(), 'archived release executor differs')
    native = 'D:\\' + base.relative_to(Path('/mnt/d')).as_posix().replace('/', '\\')
    def quote(value): return "'" + value.replace("'", "''") + "'"
    launch = "$ErrorActionPreference='Stop'\n$env:PSExecutionPolicyPreference='Bypass'\n& " + quote(old.PDF_PYTHON) + ' -X utf8 ' + quote(native + '\\release-executor.py') + ' run --base ' + quote(native)
    for flag, name in [('snapshot', 'snapshot.json'), ('runner', 'runner.py'), ('source-archive', 'source-originals.zip'), ('executor', 'release-executor.py')]: launch += ' --' + flag + '-sha256 ' + quote(pin(base / name)['sha256'])
    (base / 'launch-native.ps1').write_text(launch + '\nexit $LASTEXITCODE\n', encoding='utf8')
    prepared = load(base / 'prepared-source.json'); prepared.update({'snapshot': pin(base / 'snapshot.json'), 'source_archive': pin(base / 'source-originals.zip'), 'launcher': pin(base / 'launch-native.ps1'), 'release_executor': pin(base / 'release-executor.py'), 'status': 'frozen_release_build_not_executed'})
    old.save(base / 'prepared-source.json', prepared); extra_controls(base, old)
    print(json.dumps({'status': prepared['status'], 'base': str(base), 'snapshot': prepared['snapshot'], 'source_archive': prepared['source_archive'], 'executor': prepared['release_executor']}), flush=True)


def launch(args):
    ordinary(args.native_base); base = args.native_base.resolve(); old = module(base / 'runner.py')
    fixed = StrongFiles()
    for name in CONTROL_NAMES: fixed.register(base / name)
    snapshot = load(base / 'snapshot.json'); fixed.check()
    fixed.capture_sources(base, Path(snapshot['source_root']))
    before = extra_controls(base, old)
    old.require(pin(Path(__file__)) == before['release-executor.py'], 'reviewed release executor differs from prepared copy')
    # The unchanged original launcher supplies real WSL/native PID wait and the
    # full current worktree/named/control before/after guards.
    inherited_files = old.files
    def guarded_files(root, names):
        fixed.check(); result = inherited_files(root, names); fixed.check(); return result
    old.files = guarded_files
    fixed.check(); old.launch_native(argparse.Namespace(native_base=base)); fixed.check()
    old.require(old.files(base, before) == before, 'additional release executor original changed across real wait')
    old.save(base / 'outer-strong-metadata-guard.json', fixed.receipt())


def parse_build(raw):
    rows = [json.loads(line) for line in raw.decode('utf8').splitlines()]
    return [v for v in rows if v.get('reason') == 'compiler-artifact'], [v for v in rows if v.get('reason') == 'build-script-executed']


def native(args):
    ordinary(args.base); fixed = StrongFiles()
    for name in CONTROL_NAMES: fixed.register(args.base / name)
    old = module(args.base / 'runner.py'); fixed.check()
    old.require(pin(args.base / 'snapshot.json')['sha256'] == args.snapshot_sha256, 'external snapshot differs before reading source list')
    fixed.capture_sources(args.base, args.base / 'repo')
    old.require(pin(args.base / 'release-executor.py')['sha256'] == args.executor_sha256, 'external release executor SHA differs')
    fixed.check(); context = old.NativeRun(args); fixed.check()
    context.control_before = extra_controls(context.base, old)
    for name in context.build_assets: fixed.register(context.repo / name)
    inherited_guard = context.guards
    def strong_guard():
        fixed.check(); result = inherited_guard(); fixed.check(); return result
    context.guards = strong_guard
    old.save(context.base / 'strong-metadata-before.json', fixed.receipt())
    cache_evidence = context.snapshot.get('release_cache_evidence')
    if 'compiler_cache_target' in context.snapshot:
        old.require(cache_evidence is not None, 'explicit prior release cache compilation/closure evidence required')
        prior = Path(context.env['CARGO_TARGET_DIR']).parent
        old.require(all(pin(prior / n) == p for n, p in cache_evidence.items()), 'prior cache source/Cargo/closure originals differ')
        prior_cli = load(prior / 'release-cli-build.json'); prior_outer = load(prior / 'outer-native-result.json')
        old.require(prior_cli['exit_code'] == 0 and prior_cli['guard_error'] is None and prior_cli['source_before_after_equal'], 'prior cache Cargo/source receipt failed')
        old.require(prior_outer['worktree_before_after_equal'] and prior_outer['control_originals_equal'], 'prior cache source/outer closure failed')
        current_scopes = load(context.base / 'precise-source-scopes.json'); prior_scopes = load(prior / 'precise-source-scopes.json')
        keys = ('direct_build_rs_input_files', 'cli_cargo_and_test_files', 'all_workspace_rust_files', 'conservative_rust_dependency_files')
        old.require(all(current_scopes[k] == prior_scopes[k] for k in keys), 'prior cache and current compiler dependency names/bytes differ')
    old.save(context.base / 'compiler-cache-scope.json', {'target': context.env['CARGO_TARGET_DIR'], 'dependency_cache_reused': cache_evidence is not None, 'prior_release_cache_evidence': cache_evidence, 'previous_test_results_reused': False, 'scope': 'Dependency/object cache only; both current release Cargo build commands execute again. CLI/driver build only; no full Rust/Python or HTTP acceptance executed.'})
    for name in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_BUILD_TARGET', 'CARGO_PROFILE_RELEASE_OPT_LEVEL', 'CARGO_PROFILE_RELEASE_DEBUG', 'CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS'): context.env.pop(name, None)
    tools = {}
    for tool in ('cargo', 'rustc', 'rustfmt', 'rustdoc'):
        raw, _ = context.command('rustup-which-' + tool, [old.RUSTUP, 'which', tool]); path = old.ordinary(Path(raw.decode().strip())); tools[tool] = {'path': str(path), **pin(path)}
    raw, _ = context.command('rustc-version', [tools['rustc']['path'], '--version', '--verbose']); old.require(b'release: 1.98.1' in raw and b'host: x86_64-pc-windows-msvc' in raw, 'selected actual native compiler differs')
    raw, _ = context.command('cargo-version', [tools['cargo']['path'], '--version', '--verbose']); old.require(b'cargo 1.98.1' in raw, 'actual selected Cargo differs')
    old.save(context.base / 'native-runtime.json', {'platform': sys.platform, 'python': sys.version, 'python_executable': sys.executable, 'python_pin': pin(sys.executable), 'compiler_tools': tools, 'selected_environment': {n: context.env.get(n) for n in ('RUSTUP_TOOLCHAIN', 'CARGO_TARGET_DIR', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_BUILD_TARGET')}, 'scope': 'Native release candidate narrow builds/probes only; no full tests/Python/HTTP.'})
    registry_before = context.registry(); old.save(context.base / 'registry-before.json', registry_before)
    raw, _ = context.cargo('release-cli-build', 'build', '-p', 'noetome-cli', '--bin', 'noetome', '--release', '--locked', '--offline', '--message-format=json')
    cli_artifacts, cli_scripts = parse_build(raw)
    candidates = [v for v in cli_artifacts if v['target']['name'] == 'noetome' and not v['profile']['test'] and v.get('executable')]
    old.require(len(candidates) == 1, 'one actual release CLI Cargo artifact required'); cli_record = candidates[0]; built_cli = Path(cli_record['executable'])
    built_cli_metadata = metadata(built_cli, temporary_cargo_output=True)
    cli = context.base / 'selected/noetome.exe'; shutil.copyfile(built_cli, cli); fixed.register(cli)
    old.require(pin(cli) == pin(built_cli) and cli.stat().st_nlink == 1, 'actual release CLI copy failed'); context.selected[cli.name] = pin(cli)
    old.require(metadata(built_cli, temporary_cargo_output=True) == built_cli_metadata, 'built CLI identity/time changed during selected copy')
    with cli.open('rb') as f: old.require(f.read(2) == b'MZ', 'actual release CLI is not PE')
    raw, _ = context.cargo('release-driver-build', 'test', '-p', 'noetome-cli', '--lib', '--release', '--no-run', '--locked', '--offline', '--message-format=json')
    driver_artifacts, driver_scripts = parse_build(raw)
    candidates = [v for v in driver_artifacts if v['target']['name'] == 'noetome_cli' and v['profile']['test'] and v.get('executable')]
    old.require(len(candidates) == 1, 'one actual release libtest artifact required'); driver_record = candidates[0]; built_driver = Path(driver_record['executable'])
    built_driver_metadata = metadata(built_driver, temporary_cargo_output=True)
    driver = context.base / 'selected/noetome-cli-testdriver.exe'; shutil.copyfile(built_driver, driver); fixed.register(driver)
    old.require(pin(driver) == pin(built_driver) and driver.stat().st_nlink == 1, 'actual release driver copy failed'); context.selected[driver.name] = pin(driver)
    old.require(metadata(built_driver, temporary_cargo_output=True) == built_driver_metadata, 'built driver identity/time changed during selected copy')
    with driver.open('rb') as f: old.require(f.read(2) == b'MZ', 'actual release test-driver is not PE')
    for record in (cli_record, driver_record):
        old.require(record['profile']['opt_level'] == '3' and record['profile']['debug_assertions'] is False, 'actual release Cargo optimization profile differs')
    cli_fp = {v[1] for s in cli_scripts for v in s.get('env', []) if v[0] == 'NOETOME_RUN_COMPILER_FINGERPRINT'}
    driver_fp = {v[1] for s in driver_scripts for v in s.get('env', []) if v[0] == 'NOETOME_RUN_COMPILER_FINGERPRINT'}
    old.require(len(cli_fp) == 1 and cli_fp == driver_fp, 'release CLI/driver actual Cargo compiler fingerprints differ')
    old.save(context.base / 'compiler-artifacts.json', {'cli': cli_artifacts, 'driver': driver_artifacts}); old.save(context.base / 'actual-build-script-records.json', {'cli': cli_scripts, 'driver': driver_scripts})
    context.command('test-driver-list', [driver, '--list'])
    envelope, fp, handshakes, fingerprints = context.runtime_probes(cli, driver, driver_scripts)
    old.require({fp} == cli_fp, 'actual release CLI/driver probes differ from both Cargo builds')
    registry_after = context.registry(); old.save(context.base / 'registry-after.json', registry_after)
    old.require(all(registry_after['files'].get(n) == v for n, v in registry_before['files'].items()) and all(registry_after['archives'].get(n) == v for n, v in registry_before['archives'].items()), 'original locked dependencies changed')
    for item in tools.values(): old.require(pin(item['path']) == {k: item[k] for k in ('sha256', 'byte_length')}, 'actual compiler tool body changed')
    context.guards(); old.save(context.base / 'source-after.json', old.files(context.repo, context.expected))
    fixed.check(); old.save(context.base / 'strong-metadata-after.json', fixed.receipt())
    receipt = {'status': 'passed_release_build_and_probes_only', 'platform': 'windows', 'profile': 'release', 'source_count': len(context.expected), 'source_before_after_equal': True, 'source_snapshot': pin(context.base / 'snapshot.json'), 'source_archive': pin(context.base / 'source-originals.zip'), 'precise_source_scopes': pin(context.base / 'precise-source-scopes.json'), 'executor': pin(context.base / 'release-executor.py'), 'selected_executables': context.selected, 'actual_cli_and_driver_compiler_fingerprint': fp, 'actual_cli_cargo_fingerprints': sorted(cli_fp), 'actual_driver_cargo_fingerprints': sorted(driver_fp), 'actual_cargo_artifacts': {'cli': cli_record, 'driver': driver_record}, 'runtime_probes': {'cli': envelope, 'driver_handshake': handshakes[0]}, 'compiler_tools': tools, 'registry_before_after_existing_bytes_equal': True, 'declared_build_assets': context.build_assets, 'external_sentinel_before_after_equal': True, 'commands': context.commands, 'full_rust_tests': 'not_run', 'full_python_tests': 'not_run', 'HTTP_acceptance': 'not_run', 'previous_test_results_reused': False}
    receipt['temporary_cargo_output_copy_guard'] = {
        'cli': built_cli_metadata,
        'driver': built_driver_metadata,
        'scope': 'Only generated Cargo outputs may have their ordinary Cargo hardlinks; actual ID/time/link-count metadata must remain unchanged across copy. Source/control/selected paths require one link.',
    }
    receipt['compiler_cache_scope'] = {'receipt': pin(context.base / 'compiler-cache-scope.json'), 'dependency_cache_reused': cache_evidence is not None, 'previous_test_results_reused': False}
    receipt['strong_metadata_guard'] = {
        'before': pin(context.base / 'strong-metadata-before.json'),
        'after': pin(context.base / 'strong-metadata-after.json'),
        'fixed_initial_per_file': True,
        'file_actual_ID_mtime_length_singlelink_guard': True,
        'ancestor_reparse_checked_before_reads': True,
        'selected_programs_registered_once_before_use': True,
        'binary_aliases_created': False,
        'directory_actual_identity_guard': False,
        'runtime_tool_actual_identity_guard': False,
    }
    old.save(context.base / 'release-build-receipt.json', receipt); old.save(context.base / 'native-final.json', receipt)
    print(json.dumps({'status': receipt['status'], 'compiler_fingerprint': fp, 'selected_executables': context.selected}), flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__); modes = p.add_subparsers(dest='mode', required=True)
    q = modes.add_parser('prepare'); q.add_argument('--repo', type=Path, required=True); q.add_argument('--native-base', type=Path, required=True); q.add_argument('--original-runner', type=Path, required=True); q.add_argument('--freeze-label', required=True); q.add_argument('--cache-target', type=Path)
    q = modes.add_parser('launch'); q.add_argument('--native-base', type=Path, required=True)
    q = modes.add_parser('run'); q.add_argument('--base', type=Path, required=True)
    for name in ('snapshot', 'runner', 'source-archive', 'executor'): q.add_argument('--' + name + '-sha256', required=True)
    args = p.parse_args()
    if args.mode == 'prepare': return prepare(args)
    if args.mode == 'launch': return launch(args)
    try: native(args)
    except Exception as error:
        if args.base.exists():
            old = module(args.base / 'runner.py'); old.save(args.base / 'native-failure.json', {'status': 'failed_release_candidate', 'error_type': type(error).__name__, 'error': str(error), 'scope': 'Narrow candidate failed; original raw/build evidence retained, no tests or timing pass inferred.'})
        raise


if __name__ == '__main__': main()
