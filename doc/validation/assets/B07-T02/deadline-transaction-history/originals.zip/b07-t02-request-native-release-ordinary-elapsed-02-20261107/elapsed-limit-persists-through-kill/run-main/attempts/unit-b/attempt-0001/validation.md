# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9ce5f670014d6067bc665699743623aac66d7100c173214ed36c2481f35aceb4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c781280bf1ab6a837cbb85e9f71e2d0f04ee3fa082e321c159925e650b06d562"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "23cf7a21533ac9697fe66eef93d0f63e203bf0175300fb53421c3d4863d0078d"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "792b2b0c61e2354d0c6121999ab694dc0d79390d0dd818dbf881651990ac4aea"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6bd0cbf5c61bfd411adf307b868ca06af091f0f6c231bb6084264eb85c1ccce7"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3ce6445f45e01a202d7f23b81b1120ba2430cd0dd4e1d37e77b4d896b296c4e6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9226be31-e3be-45b9-bde7-6d90a9c5f16d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "da682d15-4370-4197-a27b-55ddeb2ec5b0",
    "source_id": "d3bdd672-21c9-46d9-9457-9856e876f9b7",
    "version_id": "cdd56487-ef48-4083-ab22-c8f0cca77095"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:57464/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "561039fd-cd2d-436a-8572-fb39bedf8e34",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6bd0cbf5c61bfd411adf307b868ca06af091f0f6c231bb6084264eb85c1ccce7"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
