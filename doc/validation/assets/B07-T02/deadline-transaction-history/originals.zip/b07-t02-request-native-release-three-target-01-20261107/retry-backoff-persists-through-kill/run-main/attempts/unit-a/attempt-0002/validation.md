# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "38146f16c4ec9e0be54daa8b6deec2d31ac34703ca9dd0127777ca1854976e3a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "de43c685bb35fed01ad9dc241573fa7a9e21a2fdae14f0ee06bf962ffd2cd3a8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9bf67192da72c7eb9b6bae2f6502571bf657c958eb3ae22a82a76cf0037067e3"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "ac08451be5c30d19db342ba4da129fe8524dc7274c3010df3ab2b03ce7a9379e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "80d59e0a9f90594b981174f0530d7d682c8987f758f44f07d1f59fbcc37afdf3"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e7148d8a2c72bc630c60b794867e94d5e9d95f6e6128121a037c07d0fa9e51ff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ed9f1c13-b0bf-4814-a558-2d720f28d6fd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "023f0811-fb36-4b39-89ab-ad38b5d502c4",
    "source_id": "32c41ee6-ce99-4178-a7aa-3da0ac3ee04f",
    "version_id": "f4a1c419-0011-420c-885c-abc355cb06b5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:56283/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "50655839-5f42-43fd-9e5c-f3cac5074a94",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "80d59e0a9f90594b981174f0530d7d682c8987f758f44f07d1f59fbcc37afdf3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
