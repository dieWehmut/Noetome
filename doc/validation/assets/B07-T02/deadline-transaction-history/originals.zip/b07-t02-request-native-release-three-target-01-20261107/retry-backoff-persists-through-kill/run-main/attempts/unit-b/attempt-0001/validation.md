# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1ae87e9855e45f1c8fcfcab7f8e61cf3f00c92aedba07dbc995f954e5fe1b6b7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2cbee21e90832c7301e56e75a82ad8c321b2c3f2145c6176477de16875ef116a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "71e22248f2776050de7680eb32da7a612b83e3fa14fc961c6e9947e1d512e0b2"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "16b3040121c651e65d5b2f8e53f71313e51931147f313990aae353044265802b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "39981651652af7a2120b1ba31f3281fc0f4563889deb73f1cb19881e04c14d37"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5453d2e2ce79eef1c34f7f60e13cbde7122c946aa04632a1603e59601863b01c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "41627247-4b77-4053-9eb6-f2e3d685dd05",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4bac6a0a-f276-42cf-a512-08fa163fc734",
    "source_id": "121d9aff-0ab0-4534-8ab9-e018ccb728ca",
    "version_id": "7e40703c-2cc8-4c37-a992-652816b3004f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:56283/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dd503b46-5f40-4e4e-b710-32cd1b3e3cdb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "39981651652af7a2120b1ba31f3281fc0f4563889deb73f1cb19881e04c14d37"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
