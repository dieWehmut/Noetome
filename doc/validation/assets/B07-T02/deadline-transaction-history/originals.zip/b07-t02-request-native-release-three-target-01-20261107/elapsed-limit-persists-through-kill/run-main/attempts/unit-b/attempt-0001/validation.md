# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f87e1449ef2377bf644584caac079c4b150f172785941cbdb397bd653965409b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "307323355b2ea0e99adca5421c19929d5c6e32ed696a93b0d8dcccfd3007f34b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a472eaaf3fb46de48f8744c67b689c7ee2fb243d6bd37075b1e6c99b35e42587"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "9488699800bde90ea35f3c2a51e2f9cc640d975c7158636c23717f275588075d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "47b1e2c218bac4261fa101ba70bf1b3d0cfacf819078a400fdfc159d89de804d"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "ea75afa07be463d52b4e890bac7ff510c9bbe79b0939a89dfe2ee437e4d6b468"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "58b23e63-1e32-4865-849f-b8ba510bf677",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cce15810-0400-42c3-b43f-379d15156e9d",
    "source_id": "1c7b5390-d934-4109-9026-4dd8362d5d4f",
    "version_id": "de740270-f0bb-4145-a468-8165d016812a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63253/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e691b52b-4f7b-4210-8724-10554154b242",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "47b1e2c218bac4261fa101ba70bf1b3d0cfacf819078a400fdfc159d89de804d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
