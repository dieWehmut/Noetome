$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:NO_PROXY='127.0.0.1,::1'
$env:no_proxy='127.0.0.1,::1'
$runtime = @{powershell_PID=$PID;version=$PSVersionTable.PSVersion.ToString();stage='normalize';scope='actual outer PowerShell process; Native Python stage retains child binary streams'} | ConvertTo-Json
[System.IO.File]::WriteAllText('D:\Noetome\.artifacts\b07-t02-native-release-wrapper-02-20261107\powershell-normalize-runtime.json',$runtime,[System.Text.UTF8Encoding]::new($false))
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-release-wrapper-02-20261107\run_stage.py' --new-stage-root 'D:\Noetome\.artifacts\b07-t02-native-release-normalize-stage-02-20261107' --runtime-record 'D:\Noetome\.artifacts\b07-t02-native-release-normalized-source-02-20261107\primary-readback.json' -- 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-release-wrapper-02-20261107\normalize_build.py' --native-build-root 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-02-20261107' --new-root 'D:\Noetome\.artifacts\b07-t02-native-release-normalized-source-02-20261107' --expected-fingerprint '44a16b70f9d09212309902d1120f5eab5fe842af71cd0860f2bb50114722ac41' --expected-cli-sha '08246181e7c9d2ff57387977d5d8ceb2075b7dc8c6eb520611eb43296d9d6cf5' --expected-driver-sha '8a65d3972ccfa08c1e81a1c993d413fb6cada4436ea0601a6c3cb615d13aa6b9'
exit $LASTEXITCODE
