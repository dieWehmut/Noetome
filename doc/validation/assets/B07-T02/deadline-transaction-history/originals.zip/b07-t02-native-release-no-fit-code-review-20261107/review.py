"""Read-only review of already closed native runs and archived compiled source.

No product, test driver, HTTP server, or native auxiliary process is started.
Event timestamps are not labeled as COMMIT-completion timestamps.
"""
import hashlib
import json
from pathlib import Path
import sqlite3
from contextlib import closing


ROOT = Path(__file__).parent
SOURCE = ROOT / "source"
NATIVE_ARTIFACTS = Path("/mnt/d/Noetome/.artifacts")
EXPECTED = {
    "request_run.rs": "2e7357871bc000afc308abc4de4db0d131bfe86cadb93471e5fe0063beb33b06",
    "request_budget_store.rs": "726267c95e18e153d22e14207ef3f8c92cf726a23de86e289824725e3144be13",
    "extraction_api.rs": "e937de215338b192bb99aadec5dce669153614ffb6834123ab3cba95ccfc8c1e",
}


def pin(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return {"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw), "read_platform_device": after.st_dev, "read_platform_inode": after.st_ino, "mtime_ns": after.st_mtime_ns}


def utc_ns(text):
    from datetime import datetime, timezone
    date, fraction = text[:-1].split(".")
    seconds = int(datetime.fromisoformat(date).replace(tzinfo=timezone.utc).timestamp())
    return seconds * 1_000_000_000 + int((fraction + "0" * 9)[:9])


def case_review(name, root_name):
    run = NATIVE_ARTIFACTS / root_name
    case = run / "elapsed-limit-persists-through-kill"
    database = case / "budget/control/budget.sqlite"
    before = pin(database)
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as db:
        rows = list(db.execute("SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence"))
    assert before == pin(database)
    parsed, previous = [], None
    for index, (sequence, prev, raw, digest) in enumerate(rows, 1):
        assert index == sequence and hashlib.sha256(raw.encode("utf-8")).hexdigest() == digest
        if previous is not None:
            assert prev == previous
        record = json.loads(raw)
        assert record["sequence"] == sequence and record["previous_sha256"] == prev
        parsed.append(record)
        previous = digest
    registered = parsed[0]["event"]
    assert registered["kind"] == "run_registered"
    unit = next(unit for unit in registered["spec"]["units"] if unit["unit_id"] == "unit-a")
    deadline = utc_ns(unit["deadline_utc"])
    clock = deadline - 1_500_000_000
    timeline = []
    for record in parsed:
        event = record["event"]
        row = {"sequence": record["sequence"], "original_event_at_utc": record["at_utc"], "milliseconds_from_original_A_clock": (utc_ns(record["at_utc"]) - clock) / 1_000_000, "kind": event["kind"]}
        for key in ("key", "unit_id", "outcome", "diagnostic", "schedule"):
            if key in event:
                row[key] = event[key]
        if event["kind"] == "receipt_settled":
            receipt = event["receipt"]
            row["actual_receipt_transport"] = {key: receipt[key] for key in ("http_status", "network_attempts", "response_complete", "error_code", "elapsed_ms", "usage")}
        timeline.append(row)
    a_settlement = next(row for row in timeline if row["kind"] == "receipt_settled" and row["key"]["unit_id"] == "unit-a")
    assert a_settlement["actual_receipt_transport"]["http_status"] == 429 and a_settlement["actual_receipt_transport"]["response_complete"] is True and a_settlement["actual_receipt_transport"]["error_code"] == "EXTRACT_API_HTTP_RATE_LIMIT"
    assert not any(record["event"]["kind"] == "retry_scheduled" for record in parsed)
    assert any(record["event"].get("diagnostic") == "No retry fits the original absolute deadline" for record in parsed)
    server_path = case / "server/server-receipts.json"
    actual_server = json.loads(server_path.read_bytes())
    assert len(actual_server["receipts"]) == 2 and not actual_server["errors"]
    actual = json.loads((run / "actual.json").read_bytes())
    assert all(actual["guards"].values())
    assert all("exit_code" in command and "wait_action" in command for command in actual["commands"])
    return {
        "name": name, "actual_root": str(run), "database_original_read_before": before,
        "database_original_read_after": pin(database), "event_rows": len(parsed),
        "original_event_rows": parsed, "timeline": timeline,
        "original_A_clock_utc_ns": clock, "original_A_deadline_utc_ns": deadline,
        "original_retry_delay_ms": 1000,
        "earliest_required_retry_schedule_window_from_A_clock_ms": 500,
        "A_settlement_event_ms_from_A_clock": a_settlement["milliseconds_from_original_A_clock"],
        "settlement_event_already_after_latest_possible_1000ms_retry_window": a_settlement["milliseconds_from_original_A_clock"] >= 500,
        "actual_server_receipts": actual_server,
        "actual_closed_command_receipts": actual["commands"], "original_run_guards": actual["guards"],
        "scope": "Existing native originals only. Event.at is generated inside the SQLite update before INSERT/COMMIT and is not an actual COMMIT-finish or individual function duration. These rows prove NoFit with complete429/B200, not OS recovery acceptance.",
    }


source_pins = {name: pin(SOURCE / name) for name in EXPECTED}
assert all(source_pins[name]["sha256"] == digest for name, digest in EXPECTED.items())
result = {
    "producer": "native_release_no_fit_archived_source_review", "status": "read_only_existing_phase_and_compiled_call_path_review_completed",
    "selected_compiled_FP": "44a16b70f9d09212309902d1120f5eab5fe842af71cd0860f2bb50114722ac41",
    "compiled_source_files": source_pins,
    "cases": [case_review("ordinary external2msobserver no cfgtest", "b07-t02-request-native-release-ordinary-elapsed-02-20261107"), case_review("selected current2e735 helper; no unmatched callbacks", "b07-t02-request-native-release-three-target-01-20261107")],
    "first_attempt_static_mandatory_call_paths_before_MaySend": {
        "scope": "Code-derived mandatory successful first-attempt path for these existing complete Prepared/Reserved/MaySend records; no timed instrumentation or syscall count is claimed. Counts include only explicitly listed engine/store calls, excluding API SourceSession and startup handling.",
        "BudgetStore_open_full_witness_calls": 2,
        "open_call_sites": ["request_run.rs:1178 unit_loop store", "request_run.rs:1426 inner Hooks store"],
        "BudgetStore_view_full_witness_calls": 4,
        "view_call_sites": ["request_run.rs:1181 first loop", "request_run.rs:1504 prepared guard", "request_run.rs:1504 reservation guard", "request_run.rs:1504 before_send guard"],
        "BudgetStore_update_full_witness_transactions": 4,
        "update_paths": ["Hooks.prepared -> Store.prepare: Prepared", "Hooks.reserve -> Store.reserve -> Store.prepare: already Prepared no-event COMMIT", "Store.reserve -> update: Reserved", "Store.mark_may_send -> update: MaySend"],
        "RunGuard_inputs_full_Run_pin_hash_passes": 4,
        "RunGuard_input_inventory_passes": 8,
        "Store_verify_inputs_full_Run_pin_hash_passes": 3,
        "full_witness_scopes_before_MaySend_in_listed_paths": 10,
        "after_first_receipt_extra_current_full_views_before_retry_decision": ["request_run.rs:1482 immediately after finished typed settle", "request_run.rs:1181 next loop after RunGuard.verify+inputs"],
    },
    "read_only_optimization_candidates": [
        {"change": "Use a prepared-only reservation path for this engine", "preserve": "First Prepared COMMIT/callback remains separate. Reserved decision rechecks the exact prior plan, current complete chain, original witnesses, all inputs, Run/global limits and deadline inside its own BEGIN IMMEDIATE. Do not infer admission from a cached view.", "removes": "Second already-Prepared no-event full transaction in reserve."},
        {"change": "Keep the same unit thread's owned BudgetStore connection in Hooks", "preserve": "First connection open/version check plus every mutation's current full transaction verification; B keeps its own independent connection, HTTP remains outside transaction.", "removes": "Second BudgetStore::open full load/witness per attempt. Current worktree was observed changing toward this design, but this report is bound to archived old compiled2e735."},
        {"change": "Return/set an engine-local typed receipt_committed fact only after successful Store.settle", "preserve": "No API/output report self-certification. Next loop still performs full current Run/input/store witness checks before retry and Store.schedule_retry_after still rechecks current state under BEGIN IMMEDIATE.", "removes": "Immediate post-API view followed by the same next-loop full view, while preserving the no-receipt error when the hook never committed."},
        {"change": "Use a bounded per-witness-operation observed-original byte map", "preserve": "Full actual inventory, reparse/single-link/identity/mtime/length/SHA before/after checks; parse request, transport, report, embedded MD and candidate from exactly the same observed sealed raw bytes. Map is scoped to one protected validation, never across COMMIT, HTTP, another view or changed identity.", "removes": "Repeated stamp/read of the same sealed request/response/transport/report/candidate inside sealed_files loop, verify_request, transport_files and receipt_files."},
    ],
    "protection_requirements": ["No cached Run/global balances or skipped BEGIN IMMEDIATE reread", "No metadata-only shortcut for original SHA", "No skipped SourceSession/source/import identity proof", "No removal of independent original policy or owner anchors", "Keep every real durable boundary and SamePrepared UUID identity", "Keep normal5 fault classification, Known700 charge, UnknownR and original1500/1000/200 limits", "If per-operation bytes are reused, retain complete name/identity before/after evidence and reject replacements/mtime/same-inode modifications"],
    "new_product_invocations": 0, "new_test_driver_invocations": 0, "new_HTTP_requests": 0,
    "limitation": "No native syscall or function duration instrumentation was added. Named static call-path counts are not claimed as measured FileStamp/open syscall totals. Neither failed elapsed case is an OS acceptance pass.",
}
assert source_pins == {name: pin(SOURCE / name) for name in EXPECTED}
with (ROOT / "actual.json").open("xb") as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"status": result["status"], "cases": len(result["cases"]), "output": str(ROOT / "actual.json"), "new_product_calls": 0}))
