"""Later artifact bridge for a closed native release build, with no HTTP calls.

Primary Cargo/probe/source originals stay separate and are retained verbatim.
Only explicit repo members are put in the independent checker's flat archive.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def pin(path):
    before = path.stat()
    require(path.is_file() and before.st_nlink == 1, "ordinary single-link original required: " + str(path))
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(data)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_nlink) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_nlink), "original identity/mtime/length/link changed while read")
    return {"sha256": digest.hexdigest(), "byte_length": before.st_size, "device": before.st_dev, "inode": before.st_ino, "mtime_ns": before.st_mtime_ns, "nlink": before.st_nlink}


def byte_pin(value):
    return {key: value[key] for key in ("sha256", "byte_length")}


def save(path, value):
    with path.open("xb") as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--native-build-root", type=Path, required=True)
    parser.add_argument("--new-root", type=Path, required=True)
    parser.add_argument("--expected-fingerprint", required=True)
    parser.add_argument("--expected-cli-sha", required=True)
    parser.add_argument("--expected-driver-sha", required=True)
    args = parser.parse_args()
    require(os.name == "nt", "Actual native Windows Python required")
    require(not args.new_root.exists() and args.new_root.parent.is_dir(), "new ordinary artifact root with existing parent required")
    native = args.native_build_root
    original_paths = {name: native / name for name in ("selected-build-receipt.json", "release-build-receipt.json", "snapshot.json", "source-after.json", "source-originals.zip")}
    before_pins = {name: pin(path) for name, path in original_paths.items()}
    primary_raw = original_paths["selected-build-receipt.json"].read_bytes()
    release_raw = original_paths["release-build-receipt.json"].read_bytes()
    primary, release = json.loads(primary_raw), json.loads(release_raw)
    require(primary["platform"] == "windows" and primary["status"] == "built_runtime_identity_bound_not_full_validation", "actual closed builder runtime-bound selected receipt required")
    cli, driver = Path(primary["cli"]["path"]), Path(primary["test_driver"]["path"])
    cli_before, driver_before = pin(cli), pin(driver)
    require(byte_pin(cli_before) == byte_pin(primary["cli"]) and cli_before["sha256"] == args.expected_cli_sha, "actual selected CLI original body equals handoff and primary")
    require(byte_pin(driver_before) == byte_pin(primary["test_driver"]) and driver_before["sha256"] == args.expected_driver_sha, "actual selected driver original body equals handoff and primary")
    fp = primary["actual_compiler_fingerprint"]
    require(fp == args.expected_fingerprint and primary["cargo_build_script_fingerprints"] == [fp] and primary["cli_probe"]["compiler_fingerprint"] == fp and primary["driver_handshake"]["compiler_fingerprint"] == fp, "actual selected Cargo/CLI/driver/handoff exact fingerprint")
    require(byte_pin(before_pins["snapshot.json"]) == byte_pin(primary["source_snapshot"]) and byte_pin(before_pins["source-originals.zip"]) == byte_pin(primary["source_archive"]), "primary source snapshot/archive actual anchors")
    snapshot = json.loads(original_paths["snapshot.json"].read_bytes())
    source_before = snapshot["files"]
    actual_source_after = json.loads(original_paths["source-after.json"].read_bytes())
    # Different builders may wrap their exact post-build map under "files".
    # We keep the complete original object; only a clearly named map is selected.
    if "files" in actual_source_after:
        actual_source_after = actual_source_after["files"]
    require(isinstance(actual_source_after, dict) and set(actual_source_after) == set(source_before), "actual post-build full source inventory has exact original names")
    args.new_root.mkdir()
    flat_before, flat_after = {}, {}
    original_members = []
    with zipfile.ZipFile(original_paths["source-originals.zip"]) as original, zipfile.ZipFile(args.new_root / "source-originals.zip", "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as flat:
        names = original.namelist()
        require(len(names) == len(set(names)), "no duplicate primary original archive members")
        for name in names:
            raw = original.read(name)
            original_members.append({"member": name, "sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)})
        for name, fields in source_before.items():
            require(not Path(name).is_absolute() and ".." not in Path(name).parts and "\\" not in name, "safe explicit repository source-relative name")
            expected = byte_pin(fields)
            raw = original.read("repo/" + name)
            require({"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)} == expected == byte_pin(actual_source_after[name]), "actual before/after/archive original source bytes: " + name)
            current = pin(native / "repo" / name)
            require(byte_pin(current) == expected, "actual selected repository still equals the original release compilation snapshot: " + name)
            flat.writestr(name, raw)
            flat_before[name] = expected
            flat_after[name] = byte_pin(current)
    require(flat_before == flat_after, "complete explicitly named actual source-before/after byte scope")
    require(flat_before["scripts/verify_request_budget.py"]["sha256"] == "3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7" and flat_before["tests/test_verify_request_budget.py"]["sha256"] == "42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348", "exact current frozen checker/test originals; no source adaptation")
    require(before_pins == {name: pin(path) for name, path in original_paths.items()} and cli_before == pin(cli) and driver_before == pin(driver), "all primary/source/selected body identity mtime bytes preserved")
    save(args.new_root / "source-before.json", flat_before)
    save(args.new_root / "source-after.json", flat_after)
    save(args.new_root / "actual.json", {
        "status": "normalized_actual_native_release_build_receipt_not_behavior_acceptance",
        "source_archive": byte_pin(pin(args.new_root / "source-originals.zip")),
        "cli": byte_pin(cli_before), "test_driver": byte_pin(driver_before),
        "actual_cli_fingerprint": fp, "cargo_build_script_fingerprints": [fp],
        "primary_native_receipt": str(original_paths["selected-build-receipt.json"]),
        "primary_native_receipt_pin": before_pins["selected-build-receipt.json"],
        "release_build_receipt_pin": before_pins["release-build-receipt.json"],
        "original_native_build_receipt": primary, "original_native_release_build_receipt": release,
        "scope": "Only exact actual repository source originals are flattened for the independent checker. Five builder auxiliary members remain in the separately preserved primary archive, never mislabeled as flat compilation-source members. Actual behavior not yet run.",
    })
    with (args.new_root / "selected-build-receipt-original.json").open("xb") as stream:
        stream.write(primary_raw)
    with (args.new_root / "release-build-receipt-original.json").open("xb") as stream:
        stream.write(release_raw)
    save(args.new_root / "primary-readback.json", {"actual_native_Python_PID": os.getpid(), "sys_executable": sys.executable, "sys_version": sys.version, "native_platform": os.name, "primary_before": before_pins, "primary_after": {name: pin(path) for name, path in original_paths.items()}, "primary_members_CRC_SHA_length": original_members, "flat_actual_repo_members": len(flat_before), "selected_CLI_before": cli_before, "selected_CLI_after": pin(cli), "selected_driver_before": driver_before, "selected_driver_after": pin(driver), "program": str(Path(__file__).absolute()), "program_pin": pin(Path(__file__).absolute()), "scope": "Later no-HTTP native artifact normalization; original release build/process/profile claims are retained from the primary receipts, not synthesized by this bridge."})
    print(json.dumps({"status": "normalized_source_readback_passed_no_HTTP", "source_members": len(flat_before), "primary_members": len(original_members), "FP": fp, "CLI": byte_pin(cli_before), "driver": byte_pin(driver_before), "flat_receipt": str(args.new_root / "actual.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
