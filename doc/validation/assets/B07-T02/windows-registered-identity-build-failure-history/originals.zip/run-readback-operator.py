from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-07-20261107'
SCRIPT = OUT / 'readback-operator.py'
source = SCRIPT.read_bytes()
argv = ['/tmp/noetome-b05-t03-python/bin/python', '-B', str(SCRIPT)]
started = time.time_ns()
(OUT / 'readback-start.json').write_text(json.dumps({'argv': argv, 'operator_PID': os.getpid(),
        'script_sha256': hashlib.sha256(source).hexdigest(), 'script_byte_length': len(source),
        'saved_script_existed_before_Popen': True, 'started_utc_ns': started}, indent=2) + '\n')
with (OUT / 'readback.stdout.bin').open('wb') as stdout, (OUT / 'readback.stderr.bin').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    (OUT / 'readback-pid.json').write_text(json.dumps({'PID': child.pid, 'operator_PID': os.getpid()}, indent=2) + '\n')
    code = child.wait()
record = {'argv': argv, 'operator_PID': os.getpid(), 'PID': child.pid,
          'started_utc_ns': started, 'finished_utc_ns': time.time_ns(), 'exit_code': code,
          'actual_wait_closed': True, 'script_before_after_byte_equal': source == SCRIPT.read_bytes(),
          'Native': 'not_run', 'Cargo': 'not_run', 'HTTP': 'not_run'}
(OUT / 'readback-actual.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(code if code else int(not record['script_before_after_byte_equal']))
