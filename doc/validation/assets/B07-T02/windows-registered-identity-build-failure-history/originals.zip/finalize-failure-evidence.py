from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-07-20261107'

def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

prepare = json.loads((OUT / 'prepare-actual.json').read_bytes())
readback = json.loads((OUT / 'readback-actual.json').read_bytes())
launch = json.loads((OUT / 'launch-actual.json').read_bytes())
copied = json.loads((OUT / 'native-failure-copy-receipt.json').read_bytes())
cli = json.loads((OUT / 'temporary-cli-preservation.json').read_bytes())
assert prepare['exit_code'] == readback['exit_code'] == 0 and launch['exit_code'] == 1
assert all(item['actual_wait_closed'] for item in (prepare, readback, launch))
assert pin((OUT / 'temporary-cli.exe.original').read_bytes()) == cli['complete_MZ_body']
summary = {'schema_version': 1, 'status': 'failed_release07_driver_compile_originals_preserved',
           'prepare_PIDs': [prepare['operator_PID'], prepare['PID']],
           'prepare_seconds': (prepare['finished_utc_ns'] - prepare['started_utc_ns']) / 1e9,
           'prepared_readback_PIDs': [readback['operator_PID'], readback['PID']],
           'prepared_readback_seconds': (readback['finished_utc_ns'] - readback['started_utc_ns']) / 1e9,
           'launch_PIDs': [launch['operator_PID'], launch['PID']],
           'launch_seconds': (launch['finished_utc_ns'] - launch['started_utc_ns']) / 1e9,
           'launch_actual_exit': 1, 'all_actual_Popen_waits_closed': True,
           'actual_Native_commands': copied['actual_commands'],
           'all_actual_source_asset_sentinel_control_guards_passed': True,
           'source2056_ZIP2061_crc_sha_lengths_all_passed': True,
           'compiled_source_Run_Store': copied['source_Snapshot_Run_Store'],
           'whole_CLI_MZ': cli['complete_MZ_body'],
           'temporary_CLI_actual_nlink': cli['metadata_before']['st_nlink'],
           'temporary_CLI_actual_ID_mtime_length_nlink_before_after_equal': True,
           'Cargo_fingerprint_values_not_runtime_probes': cli['compile_fingerprint_values_not_runtime_probes'],
           'driver_compile_error': 'E0433 at Store3073/3080: fs2 dependency reference in newly added Windows-only test',
           'Root_followup_fix': 'Only two cfgtest lines changed to std File try_lock/unlock; new c87 source not claimed to be release07 source',
           'selected_pair': 'not_created', 'driver': 'not_built', 'FP_runtime_probes': 'not_run',
           'full807': 'not_run', 'HTTP': 'not_run', 'real_paid': 0,
           'not_generic_environment_failure_or_native_behavior_pass': True}
(OUT / 'execution-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
inventory = {}
archive = OUT / 'failure-originals.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    files = [p for p in OUT.iterdir() if p.is_file()
             and p.name not in {'failure-originals.zip', 'failure-manifest.json', 'prepared-source-originals.zip'}]
    files += [p for p in (OUT / 'native-top').iterdir() if p.is_file()]
    for item in sorted(files):
        member = str(item.relative_to(OUT)); raw = item.read_bytes()
        z.writestr(member, raw); inventory[member] = pin(raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(inventory)
    for name, expected in inventory.items(): assert pin(z.read(name)) == expected
manifest = {'schema_version': 1, 'archive': pin(archive.read_bytes()),
            'members': inventory, 'member_count': len(inventory),
            'all_CRC_SHA_length_readback': True,
            'scope': 'closed prepare/readback/operator/native failure raws and original source ZIP, complete actually built CLI MZ only; no mutable cache, driver or fake probe'}
(OUT / 'failure-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'summary': pin((OUT / 'execution-summary.json').read_bytes()),
                  'archive': manifest['archive'], 'members': len(inventory),
                  'manifest': pin((OUT / 'failure-manifest.json').read_bytes()),
                  'CRC_SHA_length_readback': True}, indent=2))
