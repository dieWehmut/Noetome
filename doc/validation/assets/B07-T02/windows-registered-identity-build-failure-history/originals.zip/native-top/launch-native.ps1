$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-07-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-07-20261107' --snapshot-sha256 '8f217096b86397326605598abb14524d34b3d0325c75a6ee0419790b27b7d968' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '901ebfab967b33b40d77b8cfed31d16c21f6959ba077f3f1b487040ae2372f4e' --executor-sha256 '0bed092e1e54705ebb5b977c21acc0debd663f402024705516f8799c0820e53f'
exit $LASTEXITCODE
