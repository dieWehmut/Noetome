from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/home/lyinn/project/Noetome');OUT=ROOT/'.artifacts/b07-t02-native-release-execution-07-20261107'
EXE=ROOT/'.artifacts/b07-t02-release-builder-draft-07-20261107/executor.py';BASE=Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-07-20261107')
assert hashlib.sha256(EXE.read_bytes()).hexdigest()=='0bed092e1e54705ebb5b977c21acc0debd663f402024705516f8799c0820e53f'
prepare=json.loads((OUT/'prepare-actual.json').read_text());readback=json.loads((OUT/'prepared-input-readback.json').read_text())
assert prepare['exit_code']==0 and prepare['actual_wait_closed'] and prepare['original_source_names_ID_mtime_size_singlelinks_equal']
assert readback['status']=='passed_prepared_inputs_only' and readback['all_CRC_SHA_lengths'] and readback['eight_control_metadata_before_after_equal']
argv=['/tmp/noetome-b05-t03-python/bin/python','-B',str(EXE),'launch','--native-base',str(BASE)]
env=os.environ.copy()
for n in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(n,None)
env['NO_PROXY']=env['no_proxy']='localhost,127.0.0.1'
start=time.time_ns()
(OUT/'launch-start.json').write_text(json.dumps({'argv':argv,'operator_PID':os.getpid(),'cwd':str(ROOT),'child_environment_names':sorted(env),'started_utc_ns':start},indent=2)+'\n')
with (OUT/'launch.stdout.bin').open('wb') as stdout,(OUT/'launch.stderr.bin').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
 (OUT/'launch-pid.json').write_text(json.dumps({'PID':child.pid,'operator_PID':os.getpid()},indent=2)+'\n')
 code=child.wait()
record={'argv':argv,'operator_PID':os.getpid(),'PID':child.pid,'started_utc_ns':start,'finished_utc_ns':time.time_ns(),'exit_code':code,'actual_wait_closed':True}
(OUT/'launch-actual.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(code)
