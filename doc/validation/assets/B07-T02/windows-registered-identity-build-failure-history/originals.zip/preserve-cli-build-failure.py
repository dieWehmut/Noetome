"""Seal the actually built release07 CLI only; do not run it or invent a driver."""
from pathlib import Path, PureWindowsPath
import hashlib
import json
import os
import stat
import time

ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-07-20261107'
BASE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-07-20261107')
PHYSICAL = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-01-20261107/build-target')
EXPECTED_NATIVE = PureWindowsPath('D:/Noetome/.artifacts/b07-t02-windows-release-pair-01-20261107/build-target/release/noetome.exe')
KEYS = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')

def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

def ordinary(path):
    for part in (path, *path.parents):
        info = part.lstat()
        assert not stat.S_ISLNK(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 0x400

def meta(info):
    assert stat.S_ISREG(info.st_mode) and info.st_nlink > 0
    return {key: getattr(info, key) for key in KEYS}

started = time.time_ns()
cli_log = (BASE / 'release-cli-build.stdout.bin').read_bytes()
cli_record = json.loads((BASE / 'release-cli-build.json').read_bytes())
driver_record = json.loads((BASE / 'release-driver-build.json').read_bytes())
assert cli_record['exit_code'] == 0 and driver_record['exit_code'] == 101
rows = [json.loads(line) for line in cli_log.splitlines()]
selected = [row for row in rows if row.get('reason') == 'compiler-artifact'
            and row['target']['name'] == 'noetome' and 'bin' in row['target']['kind']
            and row.get('executable')]
assert len(selected) == 1 and PureWindowsPath(selected[0]['executable']) == EXPECTED_NATIVE
source = PHYSICAL / 'release/noetome.exe'
ordinary(source)
before = meta(source.lstat())
flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
fd = os.open(source, flags)
current = None
try:
    opened = meta(os.fstat(fd)); assert opened == before
    parts, remaining = [], before['st_size'] + 1
    while remaining:
        body = os.read(fd, min(1024 * 1024, remaining))
        if not body: break
        parts.append(body); remaining -= len(body)
    raw = b''.join(parts)
    after = meta(os.fstat(fd)); ordinary(source)
    current = os.open(source, flags)
    current_meta = meta(os.fstat(current)); path_after = meta(source.lstat())
    assert before == opened == after == current_meta == path_after
    assert len(raw) == before['st_size'] and raw.startswith(b'MZ')
    destination = OUT / 'temporary-cli.exe.original'
    with destination.open('xb') as stream: stream.write(raw)
    copied = destination.read_bytes(); assert copied == raw
    ordinary(source); assert meta(source.lstat()) == before
finally:
    if current is not None: os.close(current)
    os.close(fd)
fingerprints = [value for row in rows if row.get('reason') == 'build-script-executed'
                for key, value in row.get('env', []) if key == 'NOETOME_RUN_COMPILER_FINGERPRINT']
record = {'schema_version': 1, 'producer': 'release07_actual_CLI_body_failure_preservation',
          'PID': os.getpid(), 'started_utc_ns': started, 'finished_utc_ns': time.time_ns(),
          'actual_CargoJSON_cli_artifact': selected[0], 'Cargo_stdout': pin(cli_log),
          'Cargo_cli_exit': 0, 'Cargo_driver_exit': 101,
          'source_path': str(source), 'source_native_path': str(EXPECTED_NATIVE),
          'metadata_before': before, 'actual_opened_fstat': opened,
          'after_read_fstat': after, 'actual_current_fstat': current_meta, 'path_after': path_after,
          'actual_positive_nlink_stable_not_selected_singlelink_claim': True,
          'complete_MZ_body': pin(raw), 'copy_path': str(destination),
          'full_byte_copy_readback_equal': True,
          'compile_fingerprint_values_not_runtime_probes': fingerprints,
          'identity_observer': 'actual Home Python fstat of closed temporary Cargo artifact',
          'driver': 'not_built', 'selected_pair': 'not_created', 'FP_probes': 'not_run',
          'HTTP': 'not_run', 'full807': 'not_run', 'real_paid': 0}
(OUT / 'temporary-cli-preservation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'PID': record['PID'], 'source_Cargo_pid': cli_record['pid'],
                  'body': record['complete_MZ_body'], 'positive_nlink': before['st_nlink'],
                  'copy_readback_equal': True, 'no_driver_no_pair_no_probe': True}, indent=2))
