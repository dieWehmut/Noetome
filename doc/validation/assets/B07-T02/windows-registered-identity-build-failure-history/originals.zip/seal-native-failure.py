"""Exact-copy closed release07 failure evidence, without touching mutable cache."""
from pathlib import Path
import hashlib
import json
import os
import types

ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-07-20261107'
BASE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-07-20261107')
READER = OUT / 'readback-operator.py'
EXPECTED_READER = 'c791ef40785711232ab1ff44857e141ea67dde5e59c60968588c3174d17a1be8'
raw = READER.read_bytes(); assert hashlib.sha256(raw).hexdigest() == EXPECTED_READER
module = types.ModuleType('sealed_release07_reader_helpers'); module.__file__ = str(READER)
exec(compile(raw, str(READER), 'exec'), module.__dict__)
destination = OUT / 'native-top'
destination.mkdir(exist_ok=False)
copied = {}
for source in sorted(BASE.iterdir()):
    if source.is_dir():
        continue
    body, proof = module.read_guarded(source)
    target = destination / source.name
    with target.open('xb') as stream:
        stream.write(body)
    assert target.read_bytes() == body
    copied[source.name] = {'pin': module.pin(body), 'source_actual_read_proof': proof,
                           'destination': str(target.relative_to(OUT)), 'full_byte_copy_equal': True}
archive = destination / 'source-originals.zip'
frozen = json.loads((destination / 'snapshot.json').read_bytes())
import zipfile
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 2061
    expected_names = {'repo/' + name for name in frozen['files']} | {
        'snapshot.json', 'runner.py', 'precise-source-scopes.json',
        'rust-dependency-subset.json', 'release-executor.py'}
    assert set(z.namelist()) == expected_names
    for name, expected in frozen['files'].items():
        assert module.pin(z.read('repo/' + name)) == expected
    for name in expected_names - {'repo/' + item for item in frozen['files']}:
        assert z.read(name) == (destination / name).read_bytes()
commands = json.loads((destination / 'native-commands.json').read_bytes())
cli = json.loads((destination / 'release-cli-build.json').read_bytes())
driver = json.loads((destination / 'release-driver-build.json').read_bytes())
outer = json.loads((destination / 'outer-native-result.json').read_bytes())
launch = json.loads((OUT / 'launch-actual.json').read_bytes())
assert cli['exit_code'] == 0 and driver['exit_code'] == 101
assert outer['exit_code'] == launch['exit_code'] == 1 and launch['actual_wait_closed']
assert outer['worktree_before_after_equal'] and outer['worktree_named_inventory_equal'] and outer['control_originals_equal']
assert all(row['guard_error'] is None and row['source_before_after_equal']
           and row['declared_build_assets_equal'] and row['external_sentinel_before_after_equal'] for row in commands)
receipt = {'schema_version': 1, 'producer': 'closed_native07_failure_exact_copy',
           'PID': os.getpid(), 'native_root': str(BASE), 'copied_top_files': copied,
           'source_snapshot_count': len(frozen['files']), 'source_zip_members': 2061,
           'source_originals_CRC_SHA_length_all_equal': True,
           'source_Snapshot_Run_Store': {name: frozen['files'][name] for name in (
               'crates/noetome-cli/src/request_run.rs', 'crates/noetome-cli/src/request_budget_store.rs')},
           'all_Cargo_command_source_asset_sentinel_guards_true': True,
           'actual_commands': [{'name': row['name'], 'pid': row['pid'], 'exit_code': row['exit_code'],
                               'elapsed_seconds': row['elapsed_seconds']} for row in commands],
           'CLI_build': 'passed_exit0', 'driver_build': 'failed_exit101_E0433_fs2_test_reference',
           'outer_and_operator_wait_closed_exit1': True,
           'selected_pair': 'not_created', 'FP_runtime_probes': 'not_run',
           'HTTP': 'not_run', 'full807': 'not_run', 'real_paid': 0,
           'current_Home_after_Root_cfgtest_fix_not_claimed_equal_to_original57c1': True,
           'mutable_Cargo_cache_not_copied': True}
(OUT / 'native-failure-copy-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'PID': os.getpid(), 'copied_top_files': len(copied), 'source2056_ZIP2061_all_equal': True,
                  'CLI0_driver101_no_pair_no_probes_no_HTTP': True, 'all_source_asset_sentinel_guards': True}, indent=2))
