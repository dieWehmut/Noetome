$ErrorActionPreference = 'Stop'
$requestBudgetPython = 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe'
$requestBudgetRunner = 'D:\Noetome\.artifacts\b07-t02-native-request-full03-launcher-20261107\native_request_runner.py'
$requestBudgetBuild = 'D:\Noetome\.artifacts\b07-t02-windows-native-05-20261107'
$requestBudgetLaunch = 'D:\Noetome\.artifacts\b07-t02-request-native-launch-06-20261107'
$requestBudgetMatrix = 'D:\Noetome\.artifacts\b07-t02-request-native-full-03-20261107'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:NO_PROXY = '127.0.0.1,::1'
$env:no_proxy = '127.0.0.1,::1'
& $requestBudgetPython $requestBudgetRunner --native-build-root $requestBudgetBuild --new-launch-root $requestBudgetLaunch --new-matrix-root $requestBudgetMatrix
exit $LASTEXITCODE
