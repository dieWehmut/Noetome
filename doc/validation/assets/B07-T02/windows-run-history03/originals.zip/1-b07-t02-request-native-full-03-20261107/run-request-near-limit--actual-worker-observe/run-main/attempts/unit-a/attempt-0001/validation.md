# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f7ba4c3eb9b408e30648b12ccc0fd024f66a82dc262f87468f1fba4a7703f8d2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6d69e4776305737c34d94a97674181f8fa4ec27408b835e06f507d27231f6a33"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0b25cf535f78b3dd4f19f28929dd3a4b877091358797e180060b2e9aa0224846"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "c066e07e72685dd1d5ed37eaf1efb33bc16c69aeff6b80ecb91f7b5eb0c8bb66"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c7fa11def88f430ddfe21e837da6f7ba268bda9f1db52c64bd9bd3a79ec073d9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "216ceb4625520e54963d088d85cb08e641f2ff0376649247afbd8a328e15e1a1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0ce6a5e4-7a78-4f9e-b246-444112c09711",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1310c6bb-8c86-45e9-88f2-3afe48385c44",
    "source_id": "7fb4030a-2a1b-411b-80db-3433edce6cbf",
    "version_id": "d614fce6-af55-4d1c-ad70-4593d2ff443a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:64397/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1a79e41e-a348-40a3-b61a-e9e5510e4a0f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c7fa11def88f430ddfe21e837da6f7ba268bda9f1db52c64bd9bd3a79ec073d9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
