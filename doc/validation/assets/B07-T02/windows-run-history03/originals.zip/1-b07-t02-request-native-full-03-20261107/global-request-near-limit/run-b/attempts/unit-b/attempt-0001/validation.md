# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ca895e06e95776417b2c531da9cf93e07a416823d78d02397df26b51ee0f7ceb"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4fa0e597a0e74c9089f8cc533d70d9b582de4fb03a72a477ca3482729d8db367"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fcf3b58257ddf69e46f9de3c0adc958a21651069e3c283dbceef1ae103616f88"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "0e5abfa178fb8e166ea21a238cba8d8ae2aa2201e2f52bf9e441217a040d4059"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "67157d50be9a43b2cc6d02fc21422520994c953fa183b07a7f305b9477750b85"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6dd7eaec6df6e3c351a354552e4e5fb2651d62ecddabd23906ad409074bdf3ac"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c92826b6-e977-4504-a77e-1fec9323d486",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "433744f7-81bd-4562-b0ae-7705374d453a",
    "source_id": "1d1d9121-2755-43fe-8f78-16a9bca7fa84",
    "version_id": "2fee3485-affb-44e1-ab23-535f0ea2f372"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60636/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "360cde6b-01d4-4c35-b680-02c9df81e55d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "67157d50be9a43b2cc6d02fc21422520994c953fa183b07a7f305b9477750b85"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
