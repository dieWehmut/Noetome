# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b26e7e7fbdfbc64f164aaf58a130341f0e7786653177489e1c59c9844744ac00"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d78e9234893e07569209b0971f371cf93baea41b859b44c558175df6b749794b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5515f36f8605bed408faec0e02d4532e2a13c83c8032b4ff1b3ccf721a0cc1f3"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "0857754cfbec62bd647ace08cf50f79d9c85b05b14ed2ec60a9e3ca437f63658"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7cfafe2df491187ff267430ff7fc5296b21aa428ae7d4848d4917b6ab5564be7"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7d0b0f5ce7c81cbc7ba5e07a981283c2bb99ee582e785595ddc4801f9e977137"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2a1b85e0-217f-48a5-a980-23a0e9548477",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "df8d434d-0fd2-4308-98a3-dc299825fc07",
    "source_id": "4452d5ad-1e25-436d-ad3b-2623fab0afa5",
    "version_id": "505bf6ea-2d4b-40fb-a803-4be16b3c7e00"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:64378/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7f4a0763-a313-45cb-ad26-1a7381998e36",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7cfafe2df491187ff267430ff7fc5296b21aa428ae7d4848d4917b6ab5564be7"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
