# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e811ee4c6eb850675c5e44362fff071c524def58b420c686949f0929740abd23"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3111b5fb70e07b97560a4bb75b44fb5e819f61a67011b8fefa8f23329437df3d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "996038c71372d8cf17eaeeae09487886c9f914402cc403013fd42c8be2e47a30"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "46d7757eb930b2125d8ec6877128334a1af100e6e05d3b62e8d2cb64fd924e10"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1d956b811fd73d2995e8df8e93a15843129a50943dd342d8b963d9088264257b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2fa9c6b00f0552dd0231e77509ecfc90350542efc41299811ad1d48c6a5a3286"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "edeb3789-82f0-45de-abc5-a46f36126215",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "be899dba-d8d2-42f8-a97b-1c096061f1dd",
    "source_id": "83fe266e-a61b-4447-aacb-782638028faa",
    "version_id": "d79e8697-0611-4734-a91f-2ccc93c55fa1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51878/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8d43423c-c267-413d-8b28-acee350bd570",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1d956b811fd73d2995e8df8e93a15843129a50943dd342d8b963d9088264257b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
