# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "87e38714a25fad4f24afc9da0f9b95a1c47e65303b233062bd44df106e343b65"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5fc7df813bc479da353489513bc30aeeb707ea23a5d57865091d1bb97e090599"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "ede3942f47cafee48bd418bcda46cabd80f2149b4a4ffef00b32829d0f99aa4b"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 482,
      "sha256": "675afce55fd1d5e89ed281a2f674d70295a747b0535ee9601be29feae09710f7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "025c2944-46e3-4ba8-9f81-9bd3e20c3210",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2f691313-0654-4fec-ab85-1740e259ae01",
    "source_id": "da69c775-5f73-42dc-a6e4-f0c849fb6d9c",
    "version_id": "91db2475-a873-47a1-87a4-ff6bae67992b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51878/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRANSPORT",
      "message": "EXTRACT_API_TRANSPORT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d5902773-3090-479b-9e21-5b343459f407",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
