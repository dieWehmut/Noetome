# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5a61703ec957b985be657bb6e8c99d3bc775c252f9aece81ad4201d50bd76c85"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "641b7a5b34d04da8111d6571e21343ffcef1add5af2fc4fc46b69302e10a6cc1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5efcfeb7673d6b3c88dc06317e718631e052750d9d9dea123e034a77992e4031"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "a8bdda9e4f39472107835ccdca5c5de1b0c660fc444cacd52d81a2c562cee847"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c90b3ce03d6f55da94008e6444184ab47fd9aed4540d7ba2d0b0fd1d069e9a72"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9203691222594115ed0f7c683ea26ef3c06a1e8af1201c8faa2fbcf6e0bc885b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f264c2eb-15a7-4bb5-9a45-9ceef57300dc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7142a9a0-3778-4070-abc1-2d648f737dc3",
    "source_id": "a2f7c235-7a31-4821-b5ca-b7032b0cca4b",
    "version_id": "23769372-db36-4624-93b1-5c0682d3a90f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60719/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "593d16c5-d5c8-4dc1-b583-13a3194d10f1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c90b3ce03d6f55da94008e6444184ab47fd9aed4540d7ba2d0b0fd1d069e9a72"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
