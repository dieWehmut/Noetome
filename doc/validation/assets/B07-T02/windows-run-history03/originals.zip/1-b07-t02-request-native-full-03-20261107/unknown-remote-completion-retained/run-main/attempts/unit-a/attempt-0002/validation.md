# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0c33ec0f0f8687ef013fa79d592decb80f75e66e0981fefaa4b73368e366bbbe"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cad9f5aba5afcd269f9959c077710d85b92cf51f241619e2f6d4c340cf159301"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e152041ba3b18bc4d8cfc3e60c9042c168c1994f54dc33e5a31ed4f54335197f"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "b7de748f693cb18c58c52495275dd1461cfc41417cd837d648b13b4d32a751f4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "49a756a8936a8a8981734c5c65cabd8c2f077d3cf5add6ebf61bc6636a3be568"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6806d9c401aade03d66239ed29d0c9a319528f51442f6ec54b6448db9ccd3f24"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3af7ca42-6c87-4d4e-bf0a-97c09423b6d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "de88901a-d882-48b9-8461-4b7638c9b826",
    "source_id": "632b1488-cc98-4bb1-8d41-0a382b997b0b",
    "version_id": "5fac94eb-2906-45af-a991-823924d15bc7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60719/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "961a9266-d8d5-4088-9248-72f1cb13590b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "49a756a8936a8a8981734c5c65cabd8c2f077d3cf5add6ebf61bc6636a3be568"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
