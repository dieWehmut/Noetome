# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ceecbdbe8240806164cd04e5d16ac8913c3e593713726bb34146069ecdfaf9bc"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4aff3a03065d02d5c76974a5336f2b4723d48732ecdf322f4e0ff88c9292367c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f4d2fc3a075f145caf1cee1455d69c4e7670b6bd82e509b02fee0d84dbbdb5c6"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "df4999108d995499f27e34dd108facfa3444c1449e1e11b596b5540e9aa04f83"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "db5af17c6cec0ed9d69d71f6578c64c7303305169b170f900e08311bfbd50e4d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "162e6b0526011bd779bf9a228da9752622dc52287408df8ca5b1dde7d849f4bf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4a452240-7032-4753-88b0-a80e253b5dff",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a70d65a0-ca43-4453-abff-e53420f809e9",
    "source_id": "f1c386d0-e4b8-4a98-9532-539baf5b30e5",
    "version_id": "72781794-8f29-4d02-ac0e-0076b587e6c9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51918/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "04aab25b-7586-43ca-b087-195229eaafb2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "db5af17c6cec0ed9d69d71f6578c64c7303305169b170f900e08311bfbd50e4d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
