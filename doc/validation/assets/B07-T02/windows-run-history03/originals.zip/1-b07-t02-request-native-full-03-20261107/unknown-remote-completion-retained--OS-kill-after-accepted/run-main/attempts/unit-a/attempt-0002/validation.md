# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c61626dfae12a5d6694ad479a3c76f03c21d7dd6825e91fbf69e72dd65a2186b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "00533fa59d0c06647809a9f678cc039b724bc68d935f6272246ad0985ca3e970"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4ac6b73edd0b63b3c4ce7bcc7313b04cddff1c7fc31161c213f65b099f2e57ca"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "54805db20901ab64ada49943e575f2f6a2f6e8c9c23132579c197db3bcff119e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8521f8efef3229e26400e00f8e6d574b2d2c3ba79258d94018f02082ff646a67"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7bb4965e0fdf25b6aa0d6879537c79cf010622c00601fb50e67ad9b83f1abdc0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "aeea7ed9-8495-46ca-aac8-3d364e16da4b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f40a1211-eef8-4da7-b5de-ebd01d88dfb0",
    "source_id": "4f118dba-bc78-4f6d-89a7-b7915031f1c7",
    "version_id": "83b1915b-385d-4bdf-a56c-4092397cb0fd"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51918/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "06a76ace-0778-4dd4-81ae-719f588a5ee9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8521f8efef3229e26400e00f8e6d574b2d2c3ba79258d94018f02082ff646a67"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
