# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d62fe5ca3d2dbcbe5ade26bcd4f2ff14e2f1b113d18670f7936537041e8630bd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "57c322ab55194e5a57dd9155c36275a53611bca24d4b69f943817b78d96e0a81"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "353da2e5713303c8c8da67535428b12c5c5e0843108716e4dfa6db68478afa39"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "ce758f4ff2cffffdfda7b943383fdaf9ab6da2ee1a77959d95756a4f4d922d99"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f084d32271be674d1796b82880bf289f843e13ff219f82e418d7048bc6d0c60d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d260425e8bec7f954a421097702fd0f1e66db1fcfe5fc3acd7582da4776eb266"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ef1437cc-adbf-4ea9-8c97-09a823f01d35",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f5d10666-1805-48c3-97e2-10f453633e49",
    "source_id": "10064ef2-d674-4a32-b310-aee582de9fa3",
    "version_id": "89aa3ae2-8114-48f2-a777-0baa781d3b6e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60671/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4eba3dc4-ee65-4aeb-9cd1-d39a20b3ec56",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f084d32271be674d1796b82880bf289f843e13ff219f82e418d7048bc6d0c60d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
