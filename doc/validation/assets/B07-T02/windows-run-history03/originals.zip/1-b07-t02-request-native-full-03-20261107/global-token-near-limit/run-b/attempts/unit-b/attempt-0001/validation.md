# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f7b1d3324ddca2e216569fa688d8b9f816b48f0934fafa772a686622ba437551"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0ddd4b5f7aa90da8e6ef8eb8419a573bb3a91915caafd864b9546c6c43cc286a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d77a6b435f1f83ef53a5fb7424980cf147372f0b1672e78ac2aebd40d85132f2"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "4075201ee7126b83880d9450bc9acb87ff68c8debcce9eef65a0338b4f603cf7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bc6ff202b2bcd116229a78d471ae4572a0be35914e31b806a0c7c520b91fb298"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c40fb0e2e46afc8521254a480cf57e36e9ec0cb267709cf5ed8b1072bf6ba0b8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ca6392fa-6f90-4da0-bf27-1435b72bd81d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dcb76ccd-004e-401d-80ee-7626e8233579",
    "source_id": "e2f270ff-6d90-42cd-823b-a21d16ca2798",
    "version_id": "8b55d72a-37b9-4716-9fc2-a32ee6f25945"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60660/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8ddd38ab-6674-4bf1-9749-6760fd9b9f66",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bc6ff202b2bcd116229a78d471ae4572a0be35914e31b806a0c7c520b91fb298"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
