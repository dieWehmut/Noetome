# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c144adf632aa5f93ef8bf4c6a0abdb6a7738e73568854631a5ae09bb23813aa8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "13c5aa2294a35961bbff61191b4dd447a5a0cd547d24cc91e1ae7cbd2e7d2fa5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "15100704166ef3183d43368447353cf18c0d30997311dcb053ca8113b3910e65"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "12fdd9b4b6a64e2a70faf0eff532924c1f88207b3c064dc2fb4b3e7eafe04359"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b237671863664f62d025eeb6a8b052379a15c6a7ffb2e64390b98831ac76d2f0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "223a89c292b2eb806a51d1ac64bc317fa598a89352d619073a7c7ba89813dccd"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8de1951f-9893-42cd-b3e3-8c22f0e022d5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7fa9ed44-a67a-43ec-9afa-9deebcf6fa0b",
    "source_id": "7e696bf0-eb11-4835-bb10-d3cf20050294",
    "version_id": "d1e0933e-28e3-49dd-892c-d55b8f9175ac"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59537/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f13115e1-0ca3-411c-9b27-eb3261df84de",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b237671863664f62d025eeb6a8b052379a15c6a7ffb2e64390b98831ac76d2f0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
