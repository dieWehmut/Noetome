# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "02806695400086d44b079c5cefc16ce31fdb7d7aa281aa93b87980bc4c4f88db"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "06e7d460d67dadb7c90d9bbdb651f3d86d5967201cb1a04e5cdfc55d1154e3f7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "78aaf066c35f99f76c30ceed41866f4c7d6f2691fd0b85ce01196fc4c56f81af"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "90a8ade26c5e9f0b291360b14025c6601035a7085ca70255df85a5c93952678f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a37e54e6e60014cb016d6f7040c84ca793ba5f8e58cb688dec62b125411c664a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a489444ff8235ee85237a156136ee1e92066dc973a8735e879a52aa5ad95aeda"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2e2c949c-3693-4472-9b7c-a961dbd44fd4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f7b82942-27e6-4e24-8ae9-b07e841badd6",
    "source_id": "c3b1b813-db1b-4474-84e7-93cdedf74280",
    "version_id": "c9c2bc3a-7327-4633-adad-e90f70206609"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59537/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "24615279-61ed-4610-8282-257b415898c1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a37e54e6e60014cb016d6f7040c84ca793ba5f8e58cb688dec62b125411c664a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
