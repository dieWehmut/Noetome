# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d51339cfccbd99e049f68bdcd793497eefd1606cb4a1c2f97c12060b6c203b4c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "29dc00acdef15515d612b322bfa33774e0a88b67f83aaa61190d4ab52e7a48c0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "06b3c0fab2460b236cbba93bbfb4cd78dfe43b823548f39db661f464856ebfab"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "d4bea4742c3248db059f0975166459154d0ad9669a3be7c45678dacf472d3960"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6b3e875d96a1d9f722f203d5e811449cb2c464e07775387a7b898cbaca2fb04e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f2c7c90cd33a4f53f466402a38eddd796836810b06499e05f26302adc6aa0a0c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ab52b02e-a607-49bc-b525-bae06c0bad35",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a68959b3-7d12-41ed-a523-e3fc30a8ac62",
    "source_id": "6c38eff3-5c5c-43d7-a87e-e6325476f8d7",
    "version_id": "08b66307-c45a-4de2-bddc-dae0b988b356"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51899/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9f685ba1-f091-4649-886e-cf2424411d18",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6b3e875d96a1d9f722f203d5e811449cb2c464e07775387a7b898cbaca2fb04e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
