# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "34815292c3d02885cc8ee13cb0e08ed7ac49a1e2034e99547bd7de5ce26ea525"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b25e6e1b0c418c14a63a85de002139ea3b48ec281ae424b722fa938aa92877fb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "47db51cdc8fc6ab2765e6b66edcea397299e318e224573c1a8e27f8d9ae85e2b"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "cf1381b734264b372db37684a1585c66a5957d3f2a450d06c4f521f4ee3608ca"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d1c20f05fb4d19093183c7c1de876708e6bee0c7d1ba937689936164227fee7c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8de2b90a254a18a69d8eaeb77dd972008dfa4b05fad1c96b807bce937d73b0db"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a5b2687f-3d47-434c-b27a-5cbad4bf81cf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6016384f-817b-4407-bb18-b81046a3f993",
    "source_id": "2f3cde74-c574-4d9c-adc0-be2c28c37e34",
    "version_id": "444d9047-3721-459f-9f15-1d644d65b11e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59547/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "99860cc8-0270-4858-974e-c0d985a51495",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d1c20f05fb4d19093183c7c1de876708e6bee0c7d1ba937689936164227fee7c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
