# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0b80066d3563c03c91fa108d6c1fe27dcfa7def8e4e66e5bec7d7a5d8aa563b4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "217fa8eefe83202a31a7e82a14ffcd38400a81edf71b8979a932b33b731bf3f5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "011ac79d98041d8416aaf18c84345d6e1d2d12146a76e6b86923c323067b941c"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "64f5d6bc5260ade037f30652efb9b8027e0df17a14f3f52fdebd0297b8d0a4d7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fe77424e861e787cd769689f0d6f068e437f76ba64fd7d130160fd3c040f921c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "10fc1c2dba38500994d26f2e039bcf86bbf705cd9855e41c39a8afba7dce84a6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "805186b5-8ae9-47df-9262-860995b775ac",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "19c40ae7-3e4c-45ce-bcb2-2788a8fa5009",
    "source_id": "1bbf1831-3ceb-4c5a-be20-5913453b9686",
    "version_id": "1fda46eb-3832-45c8-bf9e-071a3beefdfe"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59547/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "76235410-adce-4d4d-915c-138c98250efb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fe77424e861e787cd769689f0d6f068e437f76ba64fd7d130160fd3c040f921c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
