# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d948f2edda67308c364071cfce269c5008e81298149603f7aad7f38f78ff64f7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d3d1d6d8d6498cc6d12abfc00c90d0082f97eda89dade6234be6b5a0bbceea10"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ccdb9d318d755b5b89a53e2a556f20a579713ee5614597db89481e5b8ddb5c62"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "57c9c55ead9cb266175662a5557a26f13c919038c526b815d3a33782556c1d0d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8eab408aea833a0c361034af83e26b229d18f4157b9e7b37ea1da0741ecd4b33"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8ac36319ce7fdaf8c2d0da1a6602531813688704ce85737f315ea6b6d8650cb7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c5012717-5e93-4393-b707-32abd038bc6b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1d5956ba-98bf-42f6-99b5-c79a226a544d",
    "source_id": "381dd095-2aa1-4190-bde9-984e55f5ce44",
    "version_id": "fb73f020-8af2-4865-a56b-33bda0177d30"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51938/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "41366330-3131-4e9b-8493-8cd6f6c33eec",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8eab408aea833a0c361034af83e26b229d18f4157b9e7b37ea1da0741ecd4b33"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
