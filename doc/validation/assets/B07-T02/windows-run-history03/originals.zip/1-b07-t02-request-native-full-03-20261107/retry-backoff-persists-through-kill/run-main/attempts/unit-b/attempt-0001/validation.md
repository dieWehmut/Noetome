# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3a10ed8f9134660d88b9c0020bce76c46ee804010f905cf4c0c464ead176d2f8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f0c1bcb7f97e0ef2c18cb8d2fc82bf39c07ad050dbb32f633e46f2ef5dc94441"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "78eac6095213f62f02758c5ffb94b3c555e3089fd4a20088c502218249306b3c"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "44e53bc5a23c8633b4d9e48ed44fd9e8d03e6bc95ba4c07f3fc4f743de07c1c5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ca0d7fc4ef7695ce2d86a5f2695f962b0ba98b4b3aabd513a3b20414c8f978ac"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0c1b009c13edebb52c00c4d9649a7e2e35a63a16fbba7cfaff56bfbaabe5728c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "527d6eac-f56e-44a9-86b0-3914241c2a94",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c5469ae2-dcca-4320-87dc-0759dff112c0",
    "source_id": "627079ff-2e4c-4241-97e0-84390b4eb3a4",
    "version_id": "3f5b3252-8f67-4a9a-9fb0-f3348fcff0e7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:51938/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "10df620a-06f1-45f4-aed8-4a34982136d8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ca0d7fc4ef7695ce2d86a5f2695f962b0ba98b4b3aabd513a3b20414c8f978ac"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
