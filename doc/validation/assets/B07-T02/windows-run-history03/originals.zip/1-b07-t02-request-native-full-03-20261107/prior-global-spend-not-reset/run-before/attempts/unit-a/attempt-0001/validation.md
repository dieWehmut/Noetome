# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6f8baa6315d4866d01c9d2647986cc3908862be7dd53cdaf550aec618cbc913c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5433711000317f367896e7aa4ef782fcebc6fe6035cc80391949e467c121823f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8ac4518bf7aeab4a22d65781aa3ae578294a74e2d61016b94f2df5b0dc1b3ec3"
    },
    "request.json": {
      "byte_length": 2207,
      "sha256": "d7cf35962745b102db17eb966036dd9f097bfc82b66624a371cc4766b5412f72"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8594e2264ae4e643bf6f96fc077485d12dcb53d8ffc06e993f6a9df9072ac348"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f9833cdd45ec3fb09e7c3baff5db71267c85ad633246e4b52dad62394e647b2c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "401e47f4-5a11-4e90-bae3-e6c45a4329bf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1fcf904a-36ab-45f0-860e-87f3e78f821a",
    "source_id": "6c9ccf7b-48a7-4ab8-b50f-f6bf8791f18c",
    "version_id": "86c2e02e-cc1b-4d55-bac5-e6c5069af7a4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60698/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0640a89d-6585-45c4-af3a-5a077d4ff4cd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8594e2264ae4e643bf6f96fc077485d12dcb53d8ffc06e993f6a9df9072ac348"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
