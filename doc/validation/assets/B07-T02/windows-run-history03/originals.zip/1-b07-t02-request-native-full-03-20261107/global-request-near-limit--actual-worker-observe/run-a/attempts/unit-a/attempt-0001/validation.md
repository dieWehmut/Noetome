# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5f6b331fa867cae10fbd62353f93111b7e0283d4b0420d86e1d522e571f62dd9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e7708f361f76c810075c4f4d324ed30f63c5602d36ff5ea1af493850f2c7904b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1ba2b996fdf6a3da61343dfa7ef1ae96e6ae448ec056cb69c1401845ccb75e52"
    },
    "request.json": {
      "byte_length": 2227,
      "sha256": "7408b25cb3bae09dcf1fa09bd0ff0acc4f3f704bb866febc197ab411b78d46b9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6a538a5607323abd9e13b531fa832f7c6159a1441c1c7aa456669574a21fd1dd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0b84ca254fa18df14b1e85c5db6ca499ede7b120f4f1ebbf541017bcb09df0f0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "21b62851-babe-4f56-8702-5b4501f7686b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d711f376-17d5-4994-9888-dd803c7b4f38",
    "source_id": "a2e5db91-c3f5-45d1-8981-4bc8eff06e80",
    "version_id": "39d39431-989d-4fa4-a23c-6b05c80bf77a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:60647/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "92affc47-ccd7-49e4-86db-98fae4c27908",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6a538a5607323abd9e13b531fa832f7c6159a1441c1c7aa456669574a21fd1dd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
