from pathlib import Path
import ctypes, json, os, time
from ctypes import wintypes
root=Path(__file__).parent
pids=json.loads((root/'owned-pids.json').read_bytes())
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
kernel.OpenProcess.restype=wintypes.HANDLE
kernel.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)]
kernel.GetExitCodeProcess.restype=wintypes.BOOL
kernel.CloseHandle.argtypes=[wintypes.HANDLE]
rows=[]
for pid in pids:
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:
        error=ctypes.get_last_error()
        rows.append({'PID':pid,'OpenProcess_last_error':error,'actual_absent':error==87})
    else:
        code=wintypes.DWORD()
        ok=kernel.GetExitCodeProcess(handle,ctypes.byref(code))
        rows.append({'PID':pid,'GetExitCodeProcess_success':bool(ok),'exit_code':int(code.value),'actual_absent':bool(ok) and code.value!=259})
        kernel.CloseHandle(handle)
result={'status':'all_recorded_owned_PIDs_actual_absent' if all(r['actual_absent'] for r in rows) else 'review_required','native_observer_PID':os.getpid(),'utc_ns':time.time_ns(),'read_only_process_query':True,'new_CLI_HTTP_model_calls':0,'rows':rows}
(root/'pid-after.json').write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({'status':result['status'],'queried':len(rows),'observer_PID':os.getpid()}))
raise SystemExit(0 if all(r['actual_absent'] for r in rows) else 1)
