"""Save readers for new e4/c87/c61 originals; execute no product or Native."""
from pathlib import Path
import ast

OUT = Path(__file__).parent
OLD = OUT.parent / 'b07-t02-independent-linux-registered-identity-current-review-20261107'
mapping = {
    'registered-identity': 'standard-lock', 'registered_identity': 'standard_lock',
    '57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646': 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a',
    'Store57c1': 'Storec87', 'e4/57c1': 'e4/c87',
    'cb137897b122411e02bf42f67ad1484d8a77fd3efde62a8d402baa3f207ebcc4': 'c61bcf12b4ba35618adfd95c97e72550738bde319a9923726fdb9bf606dd594b',
    'cb1378': 'c61bcf',
    '45cae7385a3302fdf2e9f56f392d49be0e0d4b8cea7818c47222f773c8a1a826': '61dee75a00f6f4f14b165136d5d3067b7c2a1cae56588dc0f41ceae7e1991af9',
    '10cd542c0580fbb7c0166a31dff41a60ad507789b36fc817a9e8756136ba79c5': '85fb0aac46328d2b0c0d58b57aba90077a425a4cdde2464f05d045829f0fa395',
    '722613': '722596',
}
for name in ['audit.py', 'supplement.py', 'peer_archive.py', 'full_python.py', 'public_archives.py', 'global_after.py']:
    source = (OLD / name).read_text()
    for before, after in mapping.items():
        source = source.replace(before, after)
    if name == 'peer_archive.py':
        source = source.replace('2d91df6335bc74dd574b0ee995a814741ceb22770aa539d9f9583da4bb9a4a89', 'ff3451ed2edf4968db3ea4bb12cec828a34c41b2695d867f04bfa1969db634ea')
        source = source.replace('5004745', '4952288')
        source = source.replace('3795', '3794').replace('3796', '3795')
        source = source.replace('== 2504', "== len(reference_bytes)")
        source = source.replace(".startswith('afc49')", ".startswith('e42be')")
    elif name == 'full_python.py':
        source = source.replace('835867', '845648').replace('84.496', '77.219')
    elif name == 'public_archives.py':
        source = source.replace('3cba9df8a06625216accb3a76a27c8860ea55732b0f7269102026b965731d949', '759e462fe7bc7c0ed3ae120e3e4d5378dc123272362aa20739428907e0151872')
        source = source.replace('850048', '849390')
    elif name == 'global_after.py':
        source = source.replace('3796', '3795').replace('19025', '19024')
        source = source.replace('Frozen historical e4', 'Current frozen e4')
    ast.parse(source)
    with (OUT / name).open('x') as stream:
        stream.write(source)
print('Six current-source original readers saved and AST parsed; no product execution.')
