from pathlib import Path
import json,os,stat,sys
r=Path(sys.argv[1]);before=json.loads((r/'strong-metadata-before.json').read_bytes());after=json.loads((r/'strong-metadata-after.json').read_bytes());records=[]
for path,expected in after['files'].items():
 p=Path(path);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not (getattr(s,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT)
 observed={k:getattr(s,k) for k in expected};assert observed==expected,(path,observed,expected)
 records.append({'path':path,'actual_native_metadata':observed})
for path,expected in after['files'].items():
 s=Path(path).lstat();assert {k:getattr(s,k) for k in expected}==expected
value={'status':'passed','actual_native_readonly_process_PID':os.getpid(),'native_file_count':len(records),'before2065_after2067_old_metadata_exact':all(after['files'][p]==v for p,v in before['files'].items()),'records':records,'product_HTTP_Cargo_calls':0,'directory_identity_guard':False,'runtime_tool_identity_guard':False}
Path(sys.argv[2]).write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({'status':'passed','files':len(records),'PID':os.getpid()}))
