"""Closed Native release04 preflight only: original build/source/PE/metadata readback."""
from pathlib import Path, PureWindowsPath
import binascii
import hashlib
import io
import json
import os
import stat
import subprocess
import zipfile

REPO = Path('/home/lyinn/project/Noetome')
ROOT = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-04-20261107')
OUT = Path(__file__).parent
FP = '6dd8c9cab44153af6ec7234ad4ee9bb321b7405d61a77b84ef4a3c6f39b6383f'
PINS = {}
META = {}


def host(path):
    p = PureWindowsPath(path)
    assert p.is_absolute() and p.drive in ['C:', 'D:']
    return Path('/mnt/' + p.drive[0].lower()).joinpath(*p.parts[1:])


def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1, str(path)
    with path.open('rb') as stream:
        held = os.fstat(stream.fileno()); raw = stream.read(); held_after = os.fstat(stream.fileno())
    last = path.lstat()
    shape = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns, s.st_nlink)
    assert shape(first) == shape(held) == shape(held_after) == shape(last), str(path)
    p = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
         'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), p) == p
    META[str(path)] = {key: getattr(first, key) for key in ['st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink']}
    return raw


def pin_matches(raw, expected):
    assert hashlib.sha256(raw).hexdigest() == expected['sha256'] and len(raw) == expected['byte_length']


main_raw = read(ROOT / 'native-final.json'); main = json.loads(main_raw)
assert read(ROOT / 'release-build-receipt.json') == main_raw
selected = json.loads(read(ROOT / 'selected-build-receipt.json'))
outer = json.loads(read(ROOT / 'outer-native-result.json'))
launch = json.loads(read(ROOT / 'outer-native-launch.json'))
assert outer['exit_code'] == 0 and all(outer[key] for key in ['worktree_before_after_equal', 'worktree_named_inventory_equal', 'control_originals_equal'])
for stream in ['stdout', 'stderr']:
    pin_matches(read(ROOT / ('outer-native.' + stream + '.bin')), outer[stream])
assert main['status'] == 'passed_release_build_and_probes_only' and main['profile'] == 'release' and main['source_count'] == 2056
assert main['actual_cli_and_driver_compiler_fingerprint'] == FP
assert main['actual_cli_cargo_fingerprints'] == main['actual_driver_cargo_fingerprints'] == [FP]
assert len(main['commands']) == 11 and len({c['pid'] for c in main['commands']}) == 11
commands = []
for row in main['commands']:
    original = json.loads(read(ROOT / (row['name'] + '.json')))
    assert row == original and row['exit_code'] == 0 and not row['timed_out']
    assert row['guard_error'] is None and row['cleanup'] is None
    assert all(row[key] for key in ['source_before_after_equal', 'declared_build_assets_equal', 'external_sentinel_before_after_equal'])
    for stream in ['stdout', 'stderr']:
        pin_matches(read(host(row[stream]['path'])), row[stream])
    commands.append(row)
assert main['commands'] == json.loads(read(ROOT / 'native-commands.json'))
snapshot_raw = read(ROOT / 'snapshot.json'); snapshot = json.loads(snapshot_raw)
zip_raw = read(ROOT / 'source-originals.zip')
pin_matches(snapshot_raw, main['source_snapshot']); pin_matches(zip_raw, main['source_archive'])
assert len(snapshot['files']) == 2056
assert json.loads(read(ROOT / 'source-after.json')) == json.loads(read(ROOT / 'worktree-after.json')) == snapshot['files']
scopes = json.loads(read(ROOT / 'precise-source-scopes.json'))
assert [len(scopes[k]) for k in ['direct_build_rs_input_files', 'cli_cargo_and_test_files', 'all_workspace_rust_files', 'conservative_rust_dependency_files']] == [93, 129, 129, 1913]
source_members = []
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == 2061
    for name, pin in snapshot['files'].items():
        raw = archive.read(name); pin_matches(raw, pin)
        assert binascii.crc32(raw) & 0xffffffff == archive.getinfo(name).CRC
        assert read(ROOT / 'repo' / name) == raw == read(REPO / name)
        source_members.append({'path': name, 'pin': pin, 'native_source_copy': PINS[str(ROOT / 'repo' / name)], 'current_repository': PINS[str(REPO / name)]})
    auxiliaries = sorted(set(archive.namelist()) - set(snapshot['files']))
    assert len(auxiliaries) == 5
    for name in auxiliaries:
        raw = archive.read(name)
        assert binascii.crc32(raw) & 0xffffffff == archive.getinfo(name).CRC
    for key in ['direct_build_rs_input_files', 'cli_cargo_and_test_files', 'all_workspace_rust_files', 'conservative_rust_dependency_files']:
        assert all(snapshot['files'][name] == pin for name, pin in scopes[key].items())
expected = {'crates/noetome-cli/src/request_run.rs': '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc',
            'crates/noetome-cli/src/request_budget_store.rs': 'f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349',
            'scripts/verify_request_budget.py': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7',
            'tests/test_verify_request_budget.py': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348'}
assert all(snapshot['files'][name]['sha256'] == value for name, value in expected.items())
build_rows = {}
for short, name in [('cli', 'release-cli-build'), ('driver', 'release-driver-build')]:
    row = next(c for c in commands if c['name'] == name)
    assert '--release' in row['argv'] and '--locked' in row['argv'] and '--offline' in row['argv']
    records = [json.loads(line) for line in read(ROOT / (name + '.stdout.bin')).splitlines() if line.startswith(b'{')]
    env = [r for r in records if r.get('reason') == 'build-script-executed' and 'noetome-cli#' in r.get('package_id', '')]
    assert len(env) == 1 and ['NOETOME_RUN_COMPILER_FINGERPRINT', FP] in env[0]['env']
    arts = [r for r in records if r.get('reason') == 'compiler-artifact' and r.get('executable') and
            r['target']['name'] == ('noetome' if short == 'cli' else 'noetome_cli')]
    assert len(arts) == 1
    prof = arts[0]['profile']; assert prof['opt_level'] == '3' and prof['debuginfo'] == 0 and not prof['debug_assertions']
    assert prof['test'] == (short == 'driver')
    build_rows[short] = {'command': row, 'actual_Cargo_compiler_fingerprint': env[0], 'actual_artifact': arts[0]}
programs = []
for key in ['cli', 'test_driver']:
    record = selected[key]; path = host(record['path']); raw = read(path)
    assert raw[:2] == b'MZ'; pin_matches(raw, record); assert read(path) == raw
    programs.append({'path': str(path), 'pin': PINS[str(path)], 'complete_body_double_read_equal': True})
assert programs[0]['pin']['sha256'] == '3972ef561eb2c86bd3902a7682dfa5eae9c4236dcdf285c10ca4fa708929d164'
assert programs[1]['pin']['sha256'] == '57c0fb749f50221743951863469698f79f44e123a9defa432f497cd89bf11aa7'
cli_probe = json.loads(read(ROOT / 'actual-cli-compiler-probe.stdout.bin'))
driver_probe = [json.loads(line) for line in read(ROOT / 'actual-driver-compiler-probe.stdout.bin').splitlines() if line.startswith(b'{')]
assert cli_probe == selected['cli_probe'] == main['runtime_probes']['cli']
assert len(driver_probe) == 1 and driver_probe[0] == selected['driver_handshake'] == main['runtime_probes']['driver_handshake']
assert cli_probe['compiler_fingerprint'] == driver_probe[0]['compiler_fingerprint'] == FP
assert driver_probe[0]['pid'] == next(c['pid'] for c in commands if c['name'] == 'actual-driver-compiler-probe')
cache = json.loads(read(ROOT / 'compiler-cache-scope.json'))
assert snapshot['release_cache_physical_target'] == cache['target'] == 'D:\\Noetome\\.artifacts\\b07-t02-windows-release-pair-01-20261107\\build-target'
assert snapshot['release_cache_evidence_root'] == cache['independent_previous_evidence_root'] == 'D:\\Noetome\\.artifacts\\b07-t02-windows-release-pair-02-20261107'
assert snapshot['release_cache_evidence'] == cache['prior_release_cache_evidence']
for name, pin in snapshot['release_cache_evidence'].items():
    pin_matches(read(host(snapshot['release_cache_evidence_root']) / name), pin)
assert read(ROOT / 'registry-before.json') == read(ROOT / 'registry-after.json')
before = json.loads(read(ROOT / 'strong-metadata-before.json')); after = json.loads(read(ROOT / 'strong-metadata-after.json'))
assert len(before['files']) == 2065 and len(after['files']) == 2067
assert all(after['files'][path] == values for path, values in before['files'].items())
new = set(after['files']) - set(before['files']); assert new == {selected['cli']['path'], selected['test_driver']['path']}
outer_meta = json.loads(read(ROOT / 'outer-strong-metadata-guard.json'))
assert len(outer_meta['files']) == 2064
for path, values in outer_meta['files'].items():
    read(Path(path)); assert META[path] == values
native_helper = '''from pathlib import Path\nimport json,os,stat,sys\nr=Path(sys.argv[1]);before=json.loads((r/'strong-metadata-before.json').read_bytes());after=json.loads((r/'strong-metadata-after.json').read_bytes());records=[]\nfor path,expected in after['files'].items():\n p=Path(path);s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not (getattr(s,'st_file_attributes',0)&stat.FILE_ATTRIBUTE_REPARSE_POINT)\n observed={k:getattr(s,k) for k in expected};assert observed==expected,(path,observed,expected)\n records.append({'path':path,'actual_native_metadata':observed})\nfor path,expected in after['files'].items():\n s=Path(path).lstat();assert {k:getattr(s,k) for k in expected}==expected\nvalue={'status':'passed','actual_native_readonly_process_PID':os.getpid(),'native_file_count':len(records),'before2065_after2067_old_metadata_exact':all(after['files'][p]==v for p,v in before['files'].items()),'records':records,'product_HTTP_Cargo_calls':0,'directory_identity_guard':False,'runtime_tool_identity_guard':False}\nPath(sys.argv[2]).write_bytes((json.dumps(value,indent=2)+'\\n').encode())\nprint(json.dumps({'status':'passed','files':len(records),'PID':os.getpid()}))\n'''
helper_root = Path('/mnt/d/Noetome/.artifacts/b07-t02-native-release04-independent-preflight-metadata-20261107')
assert not helper_root.exists(); helper_root.mkdir()
helper_path = helper_root / 'native_metadata_readback.py'; helper_path.write_text(native_helper)
native_output = helper_root / 'actual.json'
windows_helper = str(PureWindowsPath('D:/Noetome/.artifacts/b07-t02-native-release04-independent-preflight-metadata-20261107/native_metadata_readback.py'))
windows_output = str(PureWindowsPath('D:/Noetome/.artifacts/b07-t02-native-release04-independent-preflight-metadata-20261107/actual.json'))
proc = subprocess.run(['/mnt/d/Noetome/.artifacts/b03-t02-python312/Scripts/python.exe', windows_helper,
                       str(PureWindowsPath('D:/Noetome/.artifacts/b07-t02-windows-release-pair-04-20261107')), windows_output], capture_output=True)
(OUT / 'native-metadata.stdout.bin').write_bytes(proc.stdout); (OUT / 'native-metadata.stderr.bin').write_bytes(proc.stderr)
assert proc.returncode == 0, proc.stderr
native_raw = read(native_output); native = json.loads(native_raw); assert native['status'] == 'passed' and native['native_file_count'] == 2067
(OUT / 'actual-native-metadata.json').write_bytes(native_raw)
(OUT / 'native_metadata_readback.py').write_bytes(read(helper_path))
for path in list(PINS):
    read(Path(path))
result = {'status': 'passed_independent_closed_Native_release04_initial_preflight', 'scope': 'Build/source/whole selected PE/probes/metadata only, current FP6dd8 source8e4d/f765/3b/428; no Native793/fullPython527/full62 results inferred. Reviewer executes only a readonly Python metadata inspection, zero product/HTTP/Cargo.',
          'actual_outer_launch': launch, 'actual_outer_result': outer, 'actual_commands': commands,
          'actual_compiler_fingerprint': FP, 'actual_Cargo_release_profile': build_rows,
          'complete_selected_PE_bodies': programs, 'source_members2056': source_members,
          'source_ZIP': main['source_archive'], 'source_ZIP_member_count': 2061, 'auxiliary_member_names': auxiliaries,
          'four_complete_named_source_scopes': {k: scopes[k] for k in ['direct_build_rs_input_files', 'cli_cargo_and_test_files', 'all_workspace_rust_files', 'conservative_rust_dependency_files']},
          'all_native_metadata2067_revalidated': {'process_exit_code': proc.returncode, 'actual_PID': native['actual_native_readonly_process_PID'], 'actual_output_pin': PINS[str(native_output)]},
          'initial_source_and_control_metadata_count': 2065, 'new_selected_registered_only_two': sorted(new),
          'eight_control_files_and_declared_derived_asset_bound': True,
          'outer_WSL_source_control_metadata2064_revalidated': True,
          'scope_limits': {'directory_identity_guard': False, 'runtime_tool_identity_guard': False, 'selected_registered_before_first_use_not_arbitrary_copy_race_guarantee': True},
          'actual_cli_probe': cli_probe, 'actual_driver_handshake': driver_probe[0], 'physical_cache_evidence_split': cache,
          'all_read_original_pins': PINS}
raw = (json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
(OUT / 'actual.json').write_bytes(raw)
print(json.dumps({'status':'passed','FP':FP,'commands':11,'source':2056,'ZIP_members':2061,'native_metadata':2067,'actual_sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}))
