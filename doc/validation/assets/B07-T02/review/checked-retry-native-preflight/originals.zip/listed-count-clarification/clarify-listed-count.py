"""Clarify one stale literal in original09 report; original files remain unchanged."""
from pathlib import Path
import hashlib,json,os,stat
R=Path('/home/lyinn/project/Noetome/.artifacts/b07-t02-native-release09-independent-preflight-20261107')
O=Path(__file__).resolve().parent
P={}
def read(p):
 p=Path(p);a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read();assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
 assert P.setdefault(str(p),v)==v;return b
read(Path(__file__).resolve())
source=read(R/'runtime-cache-supplement.py').decode()
b=read(R/'runtime-cache-supplement.json');v=json.loads(b)
assert hashlib.sha256(b).hexdigest()=='56d8e655b0ccd2300b7573495d3981df5429125f824eadf7ac385461d6ae07f6'
listed=v['actual_Windows_budget_module_listed_not_executed']
assert listed['count']==45
assert len(listed['names'])==len(set(listed['names']))==51
assert all(n.startswith('request_budget_store::tests::') and n.endswith(': test') for n in listed['names'])
assert 'assert len(listed)==len(set(listed))==51' in source
assert "{'count':45,'names':listed}" in source
wrapper=json.loads(read(R/'wrapper-actual.json'))
assert wrapper['actual_commands'][1]['name']=='runtime-cache' and wrapper['actual_commands'][1]['exit_code']==0 and wrapper['actual_commands'][1]['actual_wait_closed']
for p in list(P):read(p)
value={'status':'passed_clarification_of_original_Native09_supplement_count_literal_only','actual_PID':os.getpid(),
 'original_immutable_report':str(R/'runtime-cache-supplement.json'),'original_report_pin':P[str(R/'runtime-cache-supplement.json')],
 'incorrect_literal_field':'actual_Windows_budget_module_listed_not_executed.count','original_literal':45,
 'correct_actual_listed_count':51,'original_report_unique_actual_names_count':51,
 'original_executed_source_actual_gate':'len(listed)==len(set(listed))==51','source_gate_success_exit0_wait':True,
 'cause':'The report initializer retained parent08 count:45 literal, while the actual source gate and all51 names were updated and verified.',
 'full813_Python527_Native62':'not_run','listed_not_executed':True,'original_report_source_or_names_modified':False,
 'all_source_report_wrapper_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal':P,
 'new_Native_D_product_HTTP_Cargo_invocations':0}
b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode();(O/'actual.json').write_bytes(b)
print(json.dumps({'status':value['status'],'actual_PID':os.getpid(),'actual_sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'correct_listed_count':51}))
