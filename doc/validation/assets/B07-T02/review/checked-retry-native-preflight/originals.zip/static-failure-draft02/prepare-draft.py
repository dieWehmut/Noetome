"""Prepare only Home readonly preflight09 templates; Native/D/product calls zero."""
from pathlib import Path
import ast,difflib,hashlib,json,os,stat,sys
sys.dont_write_bytecode=True
R=Path('/home/lyinn/project/Noetome');O=Path(__file__).resolve().parent
B=R/'.artifacts/b07-t02-native-release08-independent-preflight-20261107'
P={}
def read(p):
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read()
  assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
 assert P.setdefault(str(p),v)==v;return b
def save(name,b):
 p=O/name
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert read(p)==b
def forward(text,pairs):
 for old,new in pairs:
  assert old in text,old
  text=text.replace(old,new)
 return text
def reverse(text,pairs):
 for old,new in reversed(pairs):text=text.replace(new,old)
 return text
SOURCE={
 'crates/noetome-cli/src/request_run.rs':('3f456b5c0623b4ca7a3239808e27647c6ef08f823a686e7f4b4a6fad9dec6cd5',75421),
 'crates/noetome-cli/src/request_budget_store.rs':('1d4e8e6d35caf6777cfa17fc8ad8c80c9916250377524be5ba3bcaa808b41335',182033),
 'scripts/verify_request_budget.py':('3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7',169966),
 'tests/test_verify_request_budget.py':('42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348',50420)}
for name,(sha,size) in SOURCE.items():
 b=read(R/name);assert hashlib.sha256(b).hexdigest()==sha and len(b)==size
read(Path(__file__).resolve())
records=[];generated={}
label_pairs=[('release08','release09'),('pair-08','pair-09')]
for name,pairs in [
 ('readback.py',label_pairs+[
 ('e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e',SOURCE['crates/noetome-cli/src/request_run.rs'][0]),
 ('c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a',SOURCE['crates/noetome-cli/src/request_budget_store.rs'][0]),
 ('74943','75421'),('165884','182033'),('sourceRun e4/Storec87','sourceRun 3f456/Store1d4e'),('fullNativeRust807','fullNativeRust813')]),
 ('runtime-cache-supplement.py',label_pairs+[('==45','==51')]),
 ('native_metadata_readback.py',[]),
]:
 old=read(B/name);new=forward(old.decode(),pairs).encode();assert reverse(new.decode(),pairs).encode()==old
 ast.parse(old);ast.parse(new);save(name,new);generated[name]=new
 diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile=str(B/name),tofile=str(O/name)))
 save(name+'.parent-to-current.diff',diff.encode())
 records.append({'name':name,'original':str(B/name),'original_pin':P[str(B/name)],'copy':str(O/name),'copy_pin':P[str(O/name)],
                 'exact_literal_substitutions':pairs,'reverse_whole_bytes_equal':True,'AST_only_no_import':True})

old=read(B/'run-preflight.py');text=old.decode()
pairs=[('release08','release09'),('e4/c87','3f456/1d4e'),('full807','full813'),('Full807','Full813'),('Rust807','Rust813'),
 ('4cea0428586e642b68d35519f37ccf4526fe512dd2084bc8c557f1a5f6c43a9c',hashlib.sha256(generated['readback.py']).hexdigest()),
 ('d1826057dfec4444882b6ddc6ea853311e25a13c59c9482116090167010b2ace',hashlib.sha256(generated['runtime-cache-supplement.py']).hexdigest()),
 ('15150',str(len(generated['readback.py'])))]
text=forward(text,pairs)
ready_dir_old=".artifacts/b07-t02-native-release09-independent-preflight-draft-20261107'"
ready_dir_new=".artifacts/b07-t02-native-release09-independent-preflight-draft-20261107-attempt02'"
assert text.count(ready_dir_old)==1
text=text.replace(ready_dir_old,ready_dir_new,1)
original_anchor_block=text[text.index('ANCHORS = {'):text.index('SOURCE_PINS = {')]
required_block="""parser = argparse.ArgumentParser(description='Root closed Native09 GO only: explicit nine current anchors, no previous FP defaults')
for label in ['fp', 'cli-sha256', 'driver-sha256', 'snapshot-sha256', 'source-zip-sha256']:
    parser.add_argument('--expected-' + label, required=True)
for label in ['cli-bytes', 'driver-bytes', 'snapshot-bytes', 'source-zip-bytes']:
    parser.add_argument('--expected-' + label, required=True, type=int)
args = parser.parse_args()
ANCHORS = {key: getattr(args, 'expected_' + key.replace('-', '_')) for key in
           ['fp', 'cli-sha256', 'cli-bytes', 'driver-sha256', 'driver-bytes',
            'snapshot-sha256', 'snapshot-bytes', 'source-zip-sha256', 'source-zip-bytes']}
for key, value in ANCHORS.items():
    if key.endswith('bytes'):
        assert isinstance(value, int) and value > 0
    else:
        assert isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)
"""
text=text.replace(original_anchor_block,required_block,1).replace('import ast\n','import ast\nimport argparse\n',1)
new=text.encode();ast.parse(new);save('run-preflight.py',new)
restored=text.replace('import ast\nimport argparse\n','import ast\n',1).replace(required_block,original_anchor_block,1)
restored=restored.replace(ready_dir_new,ready_dir_old,1)
assert reverse(restored,pairs).encode()==old
save('run-preflight.py.parent-to-current.diff',''.join(difflib.unified_diff(old.decode().splitlines(True),text.splitlines(True),fromfile=str(B/'run-preflight.py'),tofile=str(O/'run-preflight.py'))).encode())
records.append({'name':'run-preflight.py','original':str(B/'run-preflight.py'),'original_pin':P[str(B/'run-preflight.py')],
 'copy':str(O/'run-preflight.py'),'copy_pin':P[str(O/'run-preflight.py')], 'exact_literal_substitutions':pairs,
 'additional_required_delta':'Remove all nine real Native08 FP/body/snapshot/ZIP constants; add nine required external argument values with strict SHA/positive-length validation before any D access.',
 'reverse_all_declared_changes_whole_bytes_equal':True,'selected_scripts_source_sha_pins_recalculated_exact':True})
assert 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12' not in new.decode()
assert 'f6778071e8533819660e783a814b76d0d39a3b77ea254ddd0b66a65ad993adbc' not in new.decode()
assert 'windows-release-standard-lock' not in '\n'.join(x.decode() for x in generated.values())+text
for p in list(P):read(p)
v={'status':'prepared_Home_only_Native09_strong_preflight_templates_not_executed','actual_PID':os.getpid(),
 'current_four_source_pins':{n:{'sha256':p[0],'byte_length':p[1]} for n,p in SOURCE.items()},'records':records,
 'future_root':'D:/Noetome/.artifacts/b07-t02-windows-release-pair-09-20261107',
 'future_actual_FP':None,'future_two_MZ_SHA_lengths':None,'future_snapshot_ZIP_SHA_lengths':None,
 'future_fullRust813_fullPython527_Native62':'not_run','Windows51_budget_tests':'future actual list only, not execution',
 'all_original_copied_source_actual_fstat_path_ID_mtime_singlelink_bytes_before_after_equal':True,
 'all_selected_original_pins':P,'Native_D_product_Cargo_HTTP_prepare_calls':0,
 'strict_source2056_ZIP2061_Metadata2067_4maps8controls7cache_wholeMZ_double_read_guard_unchanged':True}
save('prepared.json',(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'status':v['status'],'actual_PID':os.getpid(),'scripts':{n:P[str(O/n)] for n in ['readback.py','runtime-cache-supplement.py','native_metadata_readback.py','run-preflight.py']}}))
