"""Preserve failed draft01; derive corrected Home-only preparation before execution."""
from pathlib import Path
import hashlib,json,os,stat
O=Path(__file__).resolve().parent
P=O.parent/'b07-t02-native-release09-independent-preflight-draft-20261107/prepare-draft.py'
a=P.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
with P.open('rb') as f:
 assert shape(a)==shape(os.fstat(f.fileno()));b=f.read()
 assert shape(a)==shape(os.fstat(f.fileno()))==shape(P.lstat())
t=b.decode()
old="pairs=[('release08','release09'),('pair-08','pair-09'),('e4/c87','3f456/1d4e'),('full807','full813'),('Rust807','Rust813'),"
new="pairs=[('release08','release09'),('e4/c87','3f456/1d4e'),('full807','full813'),('Full807','Full813'),('Rust807','Rust813'),"
assert t.count(old)==1;t=t.replace(old,new)
old="('d1826057dfec4444882b6ddc6ea853311e25a13c59c9482116090167010b2ace',hashlib.sha256(generated['runtime-cache-supplement.py']).hexdigest())]"
new="('d1826057dfec4444882b6ddc6ea853311e25a13c59c9482116090167010b2ace',hashlib.sha256(generated['runtime-cache-supplement.py']).hexdigest()),\n ('15150',str(len(generated['readback.py'])))]"
assert t.count(old)==1;t=t.replace(old,new)
old="text=forward(text,pairs)\noriginal_anchor_block="
new="text=forward(text,pairs)\nready_dir_old=\".artifacts/b07-t02-native-release09-independent-preflight-draft-20261107'\"\nready_dir_new=\".artifacts/b07-t02-native-release09-independent-preflight-draft-20261107-attempt02'\"\nassert text.count(ready_dir_old)==1\ntext=text.replace(ready_dir_old,ready_dir_new,1)\noriginal_anchor_block="
assert t.count(old)==1;t=t.replace(old,new)
old="assert reverse(restored,pairs).encode()==old"
new="restored=restored.replace(ready_dir_new,ready_dir_old,1)\nassert reverse(restored,pairs).encode()==old"
assert t.count(old)==1;t=t.replace(old,new)
target=O/'prepare-draft.py'
with target.open('xb') as f:f.write(t.encode());f.flush();os.fsync(f.fileno())
(O/'derivation.json').write_text(json.dumps({'original':str(P),'original_sha256':hashlib.sha256(b).hexdigest(),
 'source_after_same':shape(a)==shape(P.lstat()),'original_failure':'Draft01 asserted absent pair-08 in wrapper only; zero Native/product/D calls. Original script/stdout/stderr and partial three templates preserved.',
 'corrections':['per-file wrapper substitutions omit absent pair-08','both lower/upper full813 labels','derived exact readback byte length','ready attempt02 path and exact inverse before old-byte assertion'],
 'new_prepare_sha256':hashlib.sha256(t.encode()).hexdigest()},indent=2)+'\n')
print(target)
