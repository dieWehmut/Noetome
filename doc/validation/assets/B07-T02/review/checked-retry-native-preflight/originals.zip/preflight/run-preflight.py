"""Execute only Root-authorized readonly release09 preflight, saved before launch."""
from pathlib import Path
import ast
import argparse
import hashlib
import json
import os
import signal
import stat
import subprocess
import sys
import time

sys.dont_write_bytecode = True
REPO = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).resolve().parent
DRAFT = REPO / '.artifacts/b07-t02-native-release09-independent-preflight-draft-20261107-attempt03'
parser = argparse.ArgumentParser(description='Root closed Native09 GO only: explicit nine current anchors, no previous FP defaults')
for label in ['fp', 'cli-sha256', 'driver-sha256', 'snapshot-sha256', 'source-zip-sha256']:
    parser.add_argument('--expected-' + label, required=True)
for label in ['cli-bytes', 'driver-bytes', 'snapshot-bytes', 'source-zip-bytes']:
    parser.add_argument('--expected-' + label, required=True, type=int)
args = parser.parse_args()
ANCHORS = {key: getattr(args, 'expected_' + key.replace('-', '_')) for key in
           ['fp', 'cli-sha256', 'cli-bytes', 'driver-sha256', 'driver-bytes',
            'snapshot-sha256', 'snapshot-bytes', 'source-zip-sha256', 'source-zip-bytes']}
for key, value in ANCHORS.items():
    if key.endswith('bytes'):
        assert isinstance(value, int) and value > 0
    else:
        assert isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)
SOURCE_PINS = {
    'readback.py': ('b9a3cdf34cafc2d9ece3867556d965def6d50cbc9df2e36d70c051c7dacc14f7', 15154),
    'runtime-cache-supplement.py': ('3fad94bd45fff4a87c508681104e245d0af28931a7c920dc84e069561e3910ca', 5191),
}
GUARDS = {}

def metadata(s):
    return dict(device=s.st_dev, inode=s.st_ino, mode=s.st_mode, nlink=s.st_nlink,
                byte_length=s.st_size, mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

def read(path):
    path = Path(path)
    for p in (path, *path.parents):
        if p.is_symlink():
            raise AssertionError(f'linked selected component: {p}')
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    with path.open('rb') as f:
        assert metadata(before) == metadata(os.fstat(f.fileno()))
        b = f.read()
        assert metadata(before) == metadata(os.fstat(f.fileno())) == metadata(path.lstat())
    pin = {**metadata(before), 'sha256': hashlib.sha256(b).hexdigest()}
    assert len(b) == pin['byte_length']
    assert GUARDS.setdefault(str(path), pin) == pin
    return b

def save(name, value):
    p = OUT / name
    with p.open('x', encoding='utf-8') as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

read(Path(__file__).resolve())
save('external-root-anchors.json', {'explicit_Root_GO': 'All release09 build/probe/outer PIDs closed0; authorize only readonly Native Python metadata preflight.',
                                   'anchors': ANCHORS, 'current_Run_Store': '3f456/1d4e',
                                   'full813_fullPython527_Windows62': 'not_run',
                                   'no_old_FP_default': True})
for name, (sha, size) in SOURCE_PINS.items():
    b = read(DRAFT / name)
    assert hashlib.sha256(b).hexdigest() == sha and len(b) == size
    ast.parse(b)
    with (OUT / name).open('xb') as f:
        f.write(b)
        f.flush()
        os.fsync(f.fileno())
    assert read(OUT / name) == b
save('selected-script-originals-before.json', GUARDS)

env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
commands = []
started = time.time_ns()
for name, script in [('preflight', 'readback.py'), ('runtime-cache', 'runtime-cache-supplement.py')]:
    argv = [sys.executable, '-B', str(OUT / script)]
    if name == 'preflight':
        for key, value in ANCHORS.items():
            argv.extend(['--expected-' + key, str(value)])
    start = time.time_ns()
    stdout_path, stderr_path = OUT / (name + '.stdout.bin'), OUT / (name + '.stderr.bin')
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        p = subprocess.Popen(argv, cwd=REPO, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        save(name + '-launch.json', {'argv': argv, 'PID': p.pid, 'parent_PID': os.getpid(), 'started_ns': start,
                                    'read_only_Native_metadata_only': True})
        print(json.dumps({'phase': name, 'actual_PID': p.pid, 'started_ns': start}), flush=True)
        timed_out = False
        try:
            code = p.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(p.pid, signal.SIGKILL)
            code = p.wait()
        stdout.flush(); stderr.flush()
        os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
    row = {'name': name, 'argv': argv, 'PID': p.pid, 'exit_code': code, 'actual_wait_closed': p.poll() is not None,
           'started_ns': start, 'finished_ns': time.time_ns(), 'timed_out': timed_out,
           'stdout': {'path': str(stdout_path), 'pin': None}, 'stderr': {'path': str(stderr_path), 'pin': None}}
    for stream in ('stdout', 'stderr'):
        read(row[stream]['path']); row[stream]['pin'] = GUARDS[row[stream]['path']]
    commands.append(row)
    save(name + '-result.json', row)
    if code != 0:
        save('wrapper-failure.json', {'status': 'failed_actual_readonly_preflight', 'commands': commands,
                                    'original_failure_streams_preserved': True, 'anchors': ANCHORS,
                                    'product_Cargo_HTTP_calls': 0, 'new_Full813_Python527_Windows62': 'not_run'})
        raise SystemExit(code if code > 0 else 1)
    print(json.dumps({'phase': name, 'exit_code': code, 'actual_wait_closed': True}), flush=True)

for p in list(GUARDS):
    read(p)
save('selected-script-originals-after.json', GUARDS)
for name in ('actual.json', 'actual-native-metadata.json', 'runtime-cache-supplement.json', 'native-metadata.stdout.bin', 'native-metadata.stderr.bin'):
    read(OUT / name)
result = {'status': 'passed_independent_native_release09_readonly_preflight_all_processes_closed',
          'actual_wrapper_PID': os.getpid(), 'started_ns': started, 'finished_ns': time.time_ns(),
          'actual_commands': commands, 'external_nine_Root_anchors': ANCHORS,
          'original_and_copied_selected_scripts_actual_fstat_path_ID_mtime_bytes_before_after_equal': True,
          'all_guarded_input_output_pins': GUARDS,
          'actual_native_metadata_subprocess_returned_exit0': True,
          'readonly_Metadata_Native_process_only_product_Cargo_HTTP_zero': True,
          'fullNativeRust813_fullPython527_Windows62': 'not_run'}
save('wrapper-actual.json', result)
print(json.dumps({'status': result['status'], 'actual_wrapper_PID': os.getpid(), 'commands': len(commands),
                  'finished_ns': result['finished_ns']}), flush=True)
