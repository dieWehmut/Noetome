Native09 preflight original preservation, not a successful Windows behavior matrix.

Contains actual27232 main, NativeMetadata911c, all preflight caller/wrapper/readonly-child PID/raw/wait records and explicit nine anchors; original56d8 report, actual51 assert/names and0931 clarification; all four ready templates and both failed static preparation source/raw records.

After this preflight Root formal3 failed: real backoff WinKill48804/wait passed, elapsed74140 naturally exited0 before boundary, accepted/main62/full813/fullPython527 not_run. Root-context JSON bodies are preserved only where available at the exact announced Home path; otherwise the package explicitly records Root-reported fullSHA/length references and missing availability. This reviewer did not reread the complete failed product ledger, HTTP traffic or timers and did not repeat products.

Only selected closed Home roots were read. All originals use ordinary single-link fstat/path identity/mtime/full-byte guards before and after the archive, plus full memberCRC/SHA/length readback. CurrentSource3f456/1d4e and NativeFP74ad describe this failed historical candidate; future source changes are not covered. LargeMZ/sourceZIP remain in Root original build archive, not this package.
