"""Only Home argparse/AST checks; metadata script/supplement never executed."""
from pathlib import Path
import ast,hashlib,json,os,stat,subprocess,sys,time
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent
P={}
def read(p):
 p=Path(p);a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read()
  assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
 assert P.setdefault(str(p),v)==v;return b
read(Path(__file__).resolve());read(O/'prepared.json')
for name in ['readback.py','runtime-cache-supplement.py','native_metadata_readback.py','run-preflight.py']:
 b=read(O/name);ast.parse(b)
 assert b'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12' not in b
records=[]
for name in ['run-preflight.py','readback.py']:
 for mode in ['help','missing-required']:
  argv=[sys.executable,'-B',str(O/name)]+(['--help'] if mode=='help' else [])
  start=time.time_ns();p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  try:stdout,stderr=p.communicate(timeout=10)
  except subprocess.TimeoutExpired:
   p.kill();stdout,stderr=p.communicate();raise
  expected=0 if mode=='help' else 2;assert p.returncode==expected
  if mode=='help':
   for label in ['fp','cli-sha256','cli-bytes','driver-sha256','driver-bytes','snapshot-sha256','snapshot-bytes','source-zip-sha256','source-zip-bytes']:
    assert ('--expected-'+label).encode() in stdout
  else:assert b'are required' in stderr
  tag=name+'.'+mode
  (O/(tag+'.stdout.bin')).write_bytes(stdout);(O/(tag+'.stderr.bin')).write_bytes(stderr)
  records.append({'argv':argv,'actual_PID':p.pid,'exit_code':p.returncode,'expected_exit':expected,'actual_wait_closed':p.poll() is not None,
   'started_ns':start,'finished_ns':time.time_ns(),'no_D_access_before_argparse_exit':True})
for p in list(P):read(p)
v={'status':'passed_Home_only_AST_help_and_nine_required_no_default_args','actual_PID':os.getpid(),'commands':records,
 'source_actual_fstat_path_ID_mtime_singlelink_fullbytes_before_after_equal':P,'Native_D_product_Cargo_HTTP_calls':0,
 'no_runtime_cache_supplement_or_metadata_script_execution':True,'actual_future_FP_MZ_snapshot_ZIP':None}
b=(json.dumps(v,indent=2)+'\n').encode();(O/'template-static-checks.json').write_bytes(b)
print(json.dumps({'status':v['status'],'actual_PID':os.getpid(),'actual_sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'help_missing_argument_commands':len(records)}))
