"""Preserve attempt02; fix only path conversion in preparation's final guard."""
from pathlib import Path
import hashlib,json,os,stat
O=Path(__file__).resolve().parent
p=O.parent/'b07-t02-native-release09-independent-preflight-draft-20261107-attempt02/prepare-draft.py'
a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
with p.open('rb') as f:
 assert shape(a)==shape(os.fstat(f.fileno()));b=f.read();assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
t=b.decode();assert t.count('def read(p):\n')==1
t=t.replace('def read(p):\n','def read(p):\n p=Path(p)\n',1)
assert t.count('independent-preflight-draft-20261107-attempt02')==1
t=t.replace('independent-preflight-draft-20261107-attempt02','independent-preflight-draft-20261107-attempt03',1)
target=O/'prepare-draft.py'
with target.open('xb') as f:f.write(t.encode());f.flush();os.fsync(f.fileno())
(O/'derivation.json').write_text(json.dumps({'original':str(p),'original_sha256':hashlib.sha256(b).hexdigest(),
 'original_actual_fstat_path_ID_mtime_bytes_before_after_equal':shape(a)==shape(p.lstat()),
 'failure_preserved':'attempt02 final source after guard passed str instead of Path; AttributeError before prepared.json/zero Native/D/product calls',
 'changes':['read converts path at entry','new attempt03 ready path only'],'new_prepare_sha256':hashlib.sha256(t.encode()).hexdigest()},indent=2)+'\n')
print(target)
