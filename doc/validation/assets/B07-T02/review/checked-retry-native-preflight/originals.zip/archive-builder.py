"""Archive only selected closed Home preflight originals; saved before execution."""
from pathlib import Path
import binascii,hashlib,io,json,os,stat,sys,zipfile
sys.dont_write_bytecode=True
R=Path('/home/lyinn/project/Noetome');O=Path(__file__).resolve().parent
ROOTS={
 'preflight':R/'.artifacts/b07-t02-native-release09-independent-preflight-20261107',
 'caller':R/'.artifacts/b07-t02-native-release09-independent-preflight-launch-20261107',
 'listed-count-clarification':R/'.artifacts/b07-t02-native-release09-independent-preflight-clarification-20261107',
 'ready-draft03':R/'.artifacts/b07-t02-native-release09-independent-preflight-draft-20261107-attempt03',
 'static-failure-draft01':R/'.artifacts/b07-t02-native-release09-independent-preflight-draft-20261107',
 'static-failure-draft02':R/'.artifacts/b07-t02-native-release09-independent-preflight-draft-20261107-attempt02'}
CONTEXT={
 'Root-context/formal-three-target-actual.json':(R/'.artifacts/b07-t02-request-native-checked-retry-three-target-01-20261107/actual.json','d95fa787e8e6dd198734d57d52dbbf46228a191b1d036bda23a45662b763555c',24160),
 'Root-context/ordinary-phase-review-actual.json':(R/'.artifacts/b07-t02-native-checked-retry-execution-launch-01-20261107/ordinary-phase-review/actual.json','11aed5cab157fcb5bd400b32b712e2c481f26bf0b64bbdc2e4155fdcee74ff95',8311)}
P={};DIRS={}
def shape(s):return (s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
def read(p):
 p=Path(p)
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1,str(p)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read();assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 pin={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'mode':a.st_mode,'nlink':a.st_nlink}
 assert P.setdefault(str(p),pin)==pin;return b
def directory(p):
 s=p.lstat();assert stat.S_ISDIR(s.st_mode) and not stat.S_ISLNK(s.st_mode)
 v={'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'names':sorted(x.name for x in p.iterdir())}
 assert DIRS.setdefault(str(p),v)==v;return v
read(Path(__file__).resolve())
selections={}
for prefix,base in ROOTS.items():
 directory(base)
 for p in sorted(base.iterdir()):
  if p.is_dir():continue
  assert p.is_file() and not p.is_symlink()
  selections[prefix+'/'+p.name]=p
reported=[]
for name,(p,sha,size) in CONTEXT.items():
 if p.exists():
  b=read(p);assert hashlib.sha256(b).hexdigest()==sha and len(b)==size
  selections[name]=p
  reported.append({'name':name,'path':str(p),'sha256':sha,'byte_length':size,'actual_Home_body_independently_read_and_included':True})
 else:
  reported.append({'name':name,'reported_Home_path':str(p),'Root_reported_sha256':sha,'Root_reported_byte_length':size,
                   'actual_Home_body_independently_read_and_included':False,'availability':'Announced exact Home path absent; reference supplied by Root message only, not an independently verified original pin.'})
reference_path=O/'Root-reported-context-reference.json'
with reference_path.open('x') as f:f.write(json.dumps({'producer':'current standalone archive builder','records':reported,
 'complete_failed_workload_ledger_HTTP_timing_independently_audited':False},ensure_ascii=False,indent=2)+'\n')
selections['Root-context/reported-pin-reference.json']=reference_path
failure_base=O.parent/'b07-t02-checked-retry-native-preflight-package-20261107'
for label,p in [('source',failure_base/'build-archive.py'),('stdout',Path(str(failure_base)+'-build.stdout.bin')),('stderr',Path(str(failure_base)+'-build.stderr.bin'))]:
 selections['package-collector-failure01/'+label]=p
selections['archive-builder.py']=Path(__file__).resolve()
scope={
 'scope':'Actual closed Native09 release74ad/Run3f456/Store1d4e build and readonly preflight passed. The subsequent formal three targets failed; accepted/main62/fullRust813/fullPython527 not_run. No product repeat.',
 'successful_original_main':'27232fea1bf20583c0dc22c28a5082f317f7af3c02b5073c459980beef625bd7',
 'runtime_original_stale_count':'Original56d8 report count45 remains immutable; actual executed gate and51 unique names were correct. Posthoc0931 clarification separately included; no Native rerun.',
 'Root_context_only':'Root context is copied only if present at its exact supplied Home path; missing bodies use explicit reported fullSHA/length references, not verified originals. No complete failed ledger/HTTP/deadline audit is claimed; Owner archives failed workloads separately.',
 'static_failure_provenance':'Both failed draft preparation sources/raw/partial templates are preserved. Their standalone PID and historical source-after receipt were not captured before failure; this archive proves present original preservation, not invented historical receipts.',
 'metadata_scope':'Archive protection is actual Home/WSL fstat/pathID/mtime/SNL/fullbytes before/after. Original NativeVolume/FileIndex proof is the separately preserved actual metadata preflight. Directory/runtime-tool original lifetime identity guards are not added.',
 'complete_program_sourceZIP_bodies':'Not duplicated here; original full body/sourceZIP pins are in main preflight and Root windows-release-checked-retry build archive.',
 'root_prefixes':{k:str(v) for k,v in ROOTS.items()},'new_Native_D_product_HTTP_Cargo_calls':0}
scope_path=O/'scope.json'
with scope_path.open('x') as f:f.write(json.dumps(scope,ensure_ascii=False,indent=2)+'\n')
selections['scope.json']=scope_path
README=("Native09 preflight original preservation, not a successful Windows behavior matrix.\n\n"
 "Contains actual27232 main, NativeMetadata911c, all preflight caller/wrapper/readonly-child PID/raw/wait records and explicit nine anchors; original56d8 report, actual51 assert/names and0931 clarification; all four ready templates and both failed static preparation source/raw records.\n\n"
 "After this preflight Root formal3 failed: real backoff WinKill48804/wait passed, elapsed74140 naturally exited0 before boundary, accepted/main62/full813/fullPython527 not_run. Root-context JSON bodies are preserved only where available at the exact announced Home path; otherwise the package explicitly records Root-reported fullSHA/length references and missing availability. This reviewer did not reread the complete failed product ledger, HTTP traffic or timers and did not repeat products.\n\n"
 "Only selected closed Home roots were read. All originals use ordinary single-link fstat/path identity/mtime/full-byte guards before and after the archive, plus full memberCRC/SHA/length readback. CurrentSource3f456/1d4e and NativeFP74ad describe this failed historical candidate; future source changes are not covered. LargeMZ/sourceZIP remain in Root original build archive, not this package.\n")
readme_path=O/'README.md'
with readme_path.open('x') as f:f.write(README)
selections['README.md']=readme_path
package=O/'package';package.mkdir()
archive=package/'originals.zip';members=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in selections.items():
  b=read(p);z.writestr(name,b)
  members.append({'member':name,'original':str(p),'pin':P[str(p)],'CRC32':binascii.crc32(b)&0xffffffff,'origin_kind':'generated_Root_reported_context_reference' if name=='Root-context/reported-pin-reference.json' else 'ordinary_captured_Home_original'})
assert len(members)==len({x['member'] for x in members})
with zipfile.ZipFile(archive) as z:
 assert len(z.infolist())==len(members)
 for row in members:
  b=z.read(row['member']);i=z.getinfo(row['member']);assert i.CRC==row['CRC32'] and i.file_size==len(b)==row['pin']['byte_length']
  assert hashlib.sha256(b).hexdigest()==row['pin']['sha256'] and read(row['original'])==b
for p in list(P):read(p)
for p in list(DIRS):directory(Path(p))
archive_raw=read(archive)
manifest={'status':'passed_complete_selected_Home_original_preservation','member_count':len(members),'members':members,'scope':scope,
 'source_directory_originals_before_after':DIRS,'archive':P[str(archive)],'all_member_CRC_SHA_length_and_original_fstat_path_ID_mtime_singlelink_fullbytes_global_after_equal':True,
 'standalone_builder_saved_before_archive':Path(__file__).stat().st_mtime_ns<archive.stat().st_mtime_ns}
mp=package/'manifest.json'
with mp.open('x') as f:f.write(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
read(mp)
actual={'status':'passed_original_preservation','producer':'independent_Native09_preflight_cached_original_archive','members':len(members),
 'archive':P[str(archive)],'manifest':P[str(mp)],'all_members_CRC_SHA_length_exact_original_equal':True,
 'all_original_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal':True,'source_directory_inventory_ID_mtime_before_after_equal':True,
 'standalone_builder':P[str(Path(__file__).resolve())],'Root_formal_failure_context_is_not_independently_verified_full_workload':True,
 'new_product_HTTP_Cargo_Native_D_invocations':0,'complete_MZ_and_sourceZIP_bodies_duplicated':False,'source_scope':scope['scope']}
ap=package/'actual.json'
with ap.open('x') as f:f.write(json.dumps(actual,ensure_ascii=False,indent=2)+'\n')
b=read(ap)
print(json.dumps({'status':actual['status'],'members':len(members),'archive':P[str(archive)],'manifest':P[str(mp)],'actual_sha256':hashlib.sha256(b).hexdigest(),'actual_byte_length':len(b)}))
