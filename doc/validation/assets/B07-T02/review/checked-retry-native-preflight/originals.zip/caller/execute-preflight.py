"""Root-authorized readonly09 preflight launcher, saved before execution."""
from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path('/home/lyinn/project/Noetome');L=Path(__file__).resolve().parent
S=R/'.artifacts/b07-t02-native-release09-independent-preflight-draft-20261107-attempt03/run-preflight.py'
O=R/'.artifacts/b07-t02-native-release09-independent-preflight-20261107'
P={}
def read(p):
 p=Path(p)
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read()
  assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
 assert P.setdefault(str(p),v)==v;return b
def save(n,v):
 with (L/n).open('x') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
read(Path(__file__).resolve());raw=read(S)
assert hashlib.sha256(raw).hexdigest()=='16742a96ac1f88aa21cfce7867a047b46fb6f0ad2e222abf8d4f69d6acc5cf63' and len(raw)==6818
assert not O.exists();O.mkdir()
with (O/'run-preflight.py').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
assert read(O/'run-preflight.py')==raw
args={
 'fp':'74ad054e5013f9551af941813f84d3703cb28012e5fddaa14ef1ea10cfbb0a85',
 'cli-sha256':'c9ad64ed70a9489b785c7ec0df43b678adff43184c41df5c3b30a90c05eace70','cli-bytes':16127488,
 'driver-sha256':'a9683e1217449f3ec0672e7fd71cb1ffbb31e02f377f3b9625451b8a7f50158e','driver-bytes':22985216,
 'snapshot-sha256':'76d627212e7760e8b39c650aa620a1960ecdb8234cd6139bd3f26adbe40f77ad','snapshot-bytes':629322,
 'source-zip-sha256':'28e44ee58d3580e8528d82ba9d79d5bcf14cd7575f766589ff3e6c241f26f6af','source-zip-bytes':8241928}
argv=[sys.executable,'-B',str(O/'run-preflight.py')]
for k,v in args.items():argv+=['--expected-'+k,str(v)]
save('external-Root-anchors-and-copy-before.json',{'explicit_Root_GO':'closed Native09 all11 commands/outer/launch wait0; readonly metadata only','nine_anchors':args,'copy_originals':P,'argv':argv,
 'fullRust813_Python527_Native62':'not_run','new_product_HTTP_Cargo_calls':0})
start=time.time_ns()
with (L/'stdout.bin').open('xb') as so,(L/'stderr.bin').open('xb') as se:
 p=subprocess.Popen(argv,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=so,stderr=se,start_new_session=True)
 save('launch.json',{'actual_PID':p.pid,'parent_PID':os.getpid(),'argv':argv,'started_ns':start,'original_wrapper_unmodified':True})
 print(json.dumps({'phase':'Native09_readonly_preflight','actual_wrapper_PID':p.pid,'caller_PID':os.getpid()}),flush=True)
 timed_out=False
 try:code=p.wait(timeout=720)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 so.flush();se.flush();os.fsync(so.fileno());os.fsync(se.fileno())
for q in list(P):read(q)
read(L/'stdout.bin');read(L/'stderr.bin')
value={'status':'passed' if code==0 else 'failed_original_preflight_preserved','actual_PID':p.pid,'parent_PID':os.getpid(),'argv':argv,
 'exit_code':code,'actual_wait_closed':p.poll() is not None,'timed_out':timed_out,'started_ns':start,'finished_ns':time.time_ns(),
 'all_original_wrapper_and_copy_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal':True,'pins':P,
 'fullRust813_Python527_Native62':'not_run','new_product_HTTP_Cargo_calls':0}
save('actual.json',value)
print(json.dumps({'status':value['status'],'actual_PID':p.pid,'exit_code':code,'actual_wait_closed':value['actual_wait_closed']}),flush=True)
raise SystemExit(code if code>=0 else 1)
