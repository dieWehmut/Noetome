$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-08-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-08-20261107' --snapshot-sha256 'ca280811c714992a51be9a25d4ad580c428375a9dde1681b617ebb56cae64814' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 'b4f573f943927aa51ea63ae2981dfe1d0295f8841cf4d47c18809fdfd6fc6479' --executor-sha256 '2c1f409c09d6e04519117b50a962b4adeacb64ef653100866b309140ebc24f0a'
exit $LASTEXITCODE
