"""New source-bound native release CLI/driver build only; no full tests/Python/HTTP."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PureWindowsPath
import stat
import shutil
import sys
import zipfile

RUNNER_SHA = '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1'
RUST_SHA = 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'
STORE_SHA = 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'
PYTHON_SHA = '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7'
TESTS_SHA = '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348'
SOURCE_PINS = {'crates/noetome-cli/src/request_run.rs': {'sha256': 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 'byte_length': 74943}, 'crates/noetome-cli/src/request_budget_store.rs': {'sha256': 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a', 'byte_length': 165884}, 'scripts/verify_request_budget.py': {'sha256': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 'byte_length': 169966}, 'tests/test_verify_request_budget.py': {'sha256': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 'byte_length': 50420}}
SCOPE_KEYS = ('direct_build_rs_input_files', 'cli_cargo_and_test_files', 'all_workspace_rust_files', 'conservative_rust_dependency_files')
CACHE_BASE_NAME = 'b07-t02-windows-release-pair-02-20261107'
CACHE_TARGET_NATIVE = 'D:\\Noetome\\.artifacts\\b07-t02-windows-release-pair-01-20261107\\build-target'
ALLOWED_SOURCE_DELTA = {
    'crates/noetome-cli/src/request_run.rs': {
        'old': {'sha256': '2e7357871bc000afc308abc4de4db0d131bfe86cadb93471e5fe0063beb33b06', 'byte_length': 74989},
        'new': {'sha256': RUST_SHA, 'byte_length': 74943}},
    'crates/noetome-cli/src/request_budget_store.rs': {
        'old': {'sha256': '726267c95e18e153d22e14207ef3f8c92cf726a23de86e289824725e3144be13', 'byte_length': 128653},
        'new': {'sha256': STORE_SHA, 'byte_length': 165884}},
}
PRIOR_FIXED_PINS = {
    'compiler-cache-scope.json': {'sha256': '99317fc2e5ec802c384b4708ac5427f00a610ad93e2522fff6e22de6acce77e7', 'byte_length': 1007},
    'snapshot.json': {'sha256': '19d202c2ba27de0f98509bd84c71da2d3029586d9d3ac63981e207b918538914', 'byte_length': 423709},
    'precise-source-scopes.json': {'sha256': '5a586e5ed4851576d8728f54ca34a82a63929b5c0636126a9dc19fc9424f0a2f', 'byte_length': 459583},
    'outer-native-result.json': {'sha256': '7486da1e6d0a4fb43108b2ce5a1dcfce7b0014d57ed36f1b0a5120728707f8ed', 'byte_length': 437},
    'release-build-receipt.json': {'sha256': 'd7028ce000b54c87e232bff5d5a907d292dd71f102efe0647ddd77d46fcd0131', 'byte_length': 27132},
}
CACHE_RECEIPT_NAMES = (*PRIOR_FIXED_PINS, 'release-cli-build.json', 'release-driver-build.json')
CONTROL_NAMES = ('snapshot.json', 'source-originals.zip', 'runner.py', 'launch-native.ps1',
                 'precise-source-scopes.json', 'rust-dependency-subset.json', 'prepared-source.json', 'release-executor.py')


def ordinary(path):
    path = Path(path)
    for part in (path, *path.parents):
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('linked/reparse path before read: ' + str(part))
    return path


def metadata(path, *, temporary_cargo_output=False):
    path = ordinary(path); info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink < 1 or (not temporary_cargo_output and info.st_nlink != 1):
        raise RuntimeError('source/control/program is not a regular single-link file: ' + str(path))
    return {key: getattr(info, key) for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')}


class StrongFiles:
    """One fixed metadata baseline; registration never refreshes an old path."""
    def __init__(self): self.initial = {}

    def register(self, path):
        path = Path(path); observed = metadata(path); key = str(path)
        if key in self.initial and self.initial[key] != observed:
            raise RuntimeError('attempt to refresh changed metadata baseline: ' + key)
        self.initial.setdefault(key, observed)

    def check(self):
        for path, expected in self.initial.items():
            if metadata(path) != expected:
                raise RuntimeError('original file actual identity/time/length/link changed: ' + path)

    def capture_sources(self, base, source_root):
        for name in CONTROL_NAMES: self.register(base / name)
        # Controls were checked as ordinary files before decoding this path list.
        snapshot = load(base / 'snapshot.json'); self.check()
        for name in snapshot['files']:
            if name.startswith(('/', '\\')) or '\\' in name or ':' in name or any(p in {'', '.', '..'} for p in name.split('/')):
                raise RuntimeError('unsafe selected source relative path')
            self.register(source_root / name)
        self.check()

    def receipt(self):
        return {'files': self.initial, 'fixed_initial_metadata': True,
                'file_actual_ID_mtime_length_singlelink_guard': True,
                'ancestor_reparse_checked_before_reads': True,
                'directory_actual_identity_guard': False, 'runtime_tool_actual_identity_guard': False}


def pin(path):
    h = hashlib.sha256(); length = 0
    with Path(path).open('rb') as stream:
        for b in iter(lambda: stream.read(1024 * 1024), b''): h.update(b); length += len(b)
    return {'sha256': h.hexdigest(), 'byte_length': length}


def load(path): return json.loads(Path(path).read_bytes())


def module(path):
    before = metadata(path)
    if pin(path)['sha256'] != RUNNER_SHA: raise RuntimeError('original reviewed runner differs')
    if metadata(path) != before: raise RuntimeError('original runner metadata changed during hash')
    spec = importlib.util.spec_from_file_location('release_original_runner', path)
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old); return old


def extra_controls(base, old):
    prepared = load(base / 'prepared-source.json'); expected = prepared['release_executor']
    old.require(pin(base / 'release-executor.py') == expected, 'sealed release executor original differs')
    return {**old.controls(base), 'release-executor.py': expected}


def check_source_delta(current, prior):
    rows = {}
    for key in SCOPE_KEYS:
        before, after = prior[key], current[key]
        if set(before) != set(after):
            raise RuntimeError('cache/current precise source names changed: ' + key)
        changed = {name for name in before if before[name] != after[name]}
        if changed != set(ALLOWED_SOURCE_DELTA):
            raise RuntimeError('unexpected or missing compiler source delta: ' + key)
        for name, expected in ALLOWED_SOURCE_DELTA.items():
            if before[name] != expected['old'] or after[name] != expected['new']:
                raise RuntimeError('compiler source old/new SHA or length not authorized: ' + name)
        rows[key] = {'files': len(before), 'changed_names': sorted(changed),
                     'unchanged_names': sorted(set(before) - changed)}
    return {'allowed_source_delta': ALLOWED_SOURCE_DELTA, 'precise_scopes': rows,
            'same_names_and_all_other_file_SHA_lengths_exact': True,
            'previous_executables_or_results_reused': False}


def check_prior_cache(prior, physical_target):
    if prior.name != CACHE_BASE_NAME:
        raise RuntimeError('cache must be the explicitly closed release02 artifact')
    for name, expected in PRIOR_FIXED_PINS.items():
        before = metadata(prior / name)
        if pin(prior / name) != expected or metadata(prior / name) != before:
            raise RuntimeError('fixed prior source/build/outer original changed: ' + name)
    primary = load(prior / 'release-build-receipt.json')
    outer = load(prior / 'outer-native-result.json')
    scope = load(prior / 'compiler-cache-scope.json')
    if (primary['compiler_cache_scope']['receipt'] != PRIOR_FIXED_PINS['compiler-cache-scope.json']
            or scope['target'] != CACHE_TARGET_NATIVE or physical_target != scope['target']
            or scope['previous_test_results_reused'] is not False):
        raise RuntimeError('actual previous Cargo physical cache target or sealed cache receipt differs')
    if not (primary['status'] == 'passed_release_build_and_probes_only'
            and primary['source_before_after_equal']
            and primary['previous_test_results_reused'] is False
            and outer['exit_code'] == 0 and outer['worktree_before_after_equal']
            and outer['worktree_named_inventory_equal'] and outer['control_originals_equal']):
        raise RuntimeError('prior release builds/source guards/actual outer wait did not close')
    commands = {row['name']: row for row in primary['commands']}
    for name in ('release-cli-build', 'release-driver-build'):
        before = metadata(prior / (name + '.json')); row = load(prior / (name + '.json'))
        if (row != commands[name] or row['exit_code'] != 0 or row['guard_error'] is not None
                or not row['source_before_after_equal'] or not row['declared_build_assets_equal']
                or not row['external_sentinel_before_after_equal'] or row['timed_out']
                or metadata(prior / (name + '.json')) != before):
            raise RuntimeError('prior actual Cargo command or guards do not match fixed primary receipt: ' + name)
    return {name: pin(prior / name) for name in CACHE_RECEIPT_NAMES}


def prepare(args):
    ordinary(args.original_runner); ordinary(args.repo)
    old = module(args.original_runner.resolve())
    for name, expected in SOURCE_PINS.items():
        metadata(args.repo / name)
        old.require(pin(args.repo / name) == expected, 'current selected source SHA/length freeze differs: ' + name)
    if (args.cache_target is None) != (args.cache_evidence_root is None):
        raise RuntimeError('physical cache and independent closed evidence root must be selected together')
    physical_target = None
    if args.cache_target is not None:
        physical_target = str(PureWindowsPath('D:/') / args.cache_target.resolve().relative_to(Path('/mnt/d')).as_posix())
        check_prior_cache(args.cache_evidence_root.resolve(), physical_target)
    old.prepare(argparse.Namespace(repo=args.repo, native_base=args.native_base, freeze_label=args.freeze_label, cache_target=args.cache_target))
    base = args.native_base; shutil.copyfile(Path(__file__), base / 'release-executor.py')
    frozen = load(base / 'snapshot.json')
    if args.cache_target is not None:
        prior = args.cache_evidence_root.resolve()
        evidence = check_prior_cache(prior, physical_target)
        frozen['release_cache_physical_target'] = physical_target
        frozen['release_cache_evidence_root'] = str(PureWindowsPath('D:/') / prior.relative_to(Path('/mnt/d')).as_posix())
        current_scopes = load(base / 'precise-source-scopes.json'); prior_scopes = load(prior / 'precise-source-scopes.json')
        frozen['release_cache_source_delta'] = check_source_delta(current_scopes, prior_scopes)
        frozen['cache_scope'] = 'Dependency/object cache only. Exactly the two sealed compiler source changes are allowed; all other named scope pins equal. Both current release Cargo build commands execute again; no previous result or executable is reused as acceptance.'
        frozen['release_cache_evidence'] = evidence
        old.save(base / 'snapshot.json', frozen)
    # Freeze the final accurate cache description in the source archive itself.
    archive_path = base / 'source-originals.zip'; replacement = base / 'source-originals-prepared.zip'
    with zipfile.ZipFile(archive_path) as original, zipfile.ZipFile(replacement, 'x', zipfile.ZIP_DEFLATED) as archive:
        for item in original.infolist():
            archive.writestr(item, (base / 'snapshot.json').read_bytes() if item.filename == 'snapshot.json' else original.read(item.filename))
        archive.write(base / 'release-executor.py', 'release-executor.py')
    replacement.replace(archive_path)
    with zipfile.ZipFile(base / 'source-originals.zip') as archive:
        old.require(archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == len(load(base / 'snapshot.json')['files']) + 5, 'extended release source archive inventory/CRC differs')
        old.require(archive.read('release-executor.py') == (base / 'release-executor.py').read_bytes(), 'archived release executor differs')
    native = 'D:\\' + base.relative_to(Path('/mnt/d')).as_posix().replace('/', '\\')
    def quote(value): return "'" + value.replace("'", "''") + "'"
    launch = "$ErrorActionPreference='Stop'\n$env:PSExecutionPolicyPreference='Bypass'\n& " + quote(old.PDF_PYTHON) + ' -X utf8 ' + quote(native + '\\release-executor.py') + ' run --base ' + quote(native)
    for flag, name in [('snapshot', 'snapshot.json'), ('runner', 'runner.py'), ('source-archive', 'source-originals.zip'), ('executor', 'release-executor.py')]: launch += ' --' + flag + '-sha256 ' + quote(pin(base / name)['sha256'])
    (base / 'launch-native.ps1').write_text(launch + '\nexit $LASTEXITCODE\n', encoding='utf8')
    prepared = load(base / 'prepared-source.json'); prepared.update({'snapshot': pin(base / 'snapshot.json'), 'source_archive': pin(base / 'source-originals.zip'), 'launcher': pin(base / 'launch-native.ps1'), 'release_executor': pin(base / 'release-executor.py'), 'status': 'frozen_release_build_not_executed'})
    old.save(base / 'prepared-source.json', prepared); extra_controls(base, old)
    print(json.dumps({'status': prepared['status'], 'base': str(base), 'snapshot': prepared['snapshot'], 'source_archive': prepared['source_archive'], 'executor': prepared['release_executor']}), flush=True)


def launch(args):
    ordinary(args.native_base); base = args.native_base.resolve(); old = module(base / 'runner.py')
    fixed = StrongFiles()
    for name in CONTROL_NAMES: fixed.register(base / name)
    snapshot = load(base / 'snapshot.json'); fixed.check()
    fixed.capture_sources(base, Path(snapshot['source_root']))
    before = extra_controls(base, old)
    old.require(pin(Path(__file__)) == before['release-executor.py'], 'reviewed release executor differs from prepared copy')
    # The unchanged original launcher supplies real WSL/native PID wait and the
    # full current worktree/named/control before/after guards.
    inherited_files = old.files
    def guarded_files(root, names):
        fixed.check(); result = inherited_files(root, names); fixed.check(); return result
    old.files = guarded_files
    fixed.check(); old.launch_native(argparse.Namespace(native_base=base)); fixed.check()
    old.require(old.files(base, before) == before, 'additional release executor original changed across real wait')
    old.save(base / 'outer-strong-metadata-guard.json', fixed.receipt())


def parse_build(raw):
    rows = [json.loads(line) for line in raw.decode('utf8').splitlines()]
    return [v for v in rows if v.get('reason') == 'compiler-artifact'], [v for v in rows if v.get('reason') == 'build-script-executed']


def native(args):
    ordinary(args.base); fixed = StrongFiles()
    for name in CONTROL_NAMES: fixed.register(args.base / name)
    old = module(args.base / 'runner.py'); fixed.check()
    old.require(pin(args.base / 'snapshot.json')['sha256'] == args.snapshot_sha256, 'external snapshot differs before reading source list')
    fixed.capture_sources(args.base, args.base / 'repo')
    old.require(pin(args.base / 'release-executor.py')['sha256'] == args.executor_sha256, 'external release executor SHA differs')
    fixed.check(); context = old.NativeRun(args); fixed.check()
    old.require(all(context.expected.get(name) == expected for name, expected in SOURCE_PINS.items()), 'native sealed source SHA/length differs from this exact Run/Store/Python/test freeze')
    context.control_before = extra_controls(context.base, old)
    for name in context.build_assets: fixed.register(context.repo / name)
    inherited_guard = context.guards
    def strong_guard():
        fixed.check(); result = inherited_guard(); fixed.check(); return result
    context.guards = strong_guard
    old.save(context.base / 'strong-metadata-before.json', fixed.receipt())
    cache_evidence = context.snapshot.get('release_cache_evidence')
    if 'compiler_cache_target' in context.snapshot:
        old.require(cache_evidence is not None, 'explicit prior release cache compilation/closure evidence required')
        old.require(context.snapshot.get('release_cache_physical_target') == context.env['CARGO_TARGET_DIR'], 'selected physical cache differs from the sealed actual previous Cargo target')
        prior = Path(context.snapshot['release_cache_evidence_root'])
        old.require(all(pin(prior / n) == p for n, p in cache_evidence.items()), 'prior cache source/Cargo/closure originals differ')
        old.require(check_prior_cache(prior, context.env['CARGO_TARGET_DIR']) == cache_evidence, 'fixed previous release source/Cargo/closure originals differ')
        current_scopes = load(context.base / 'precise-source-scopes.json'); prior_scopes = load(prior / 'precise-source-scopes.json')
        old.require(check_source_delta(current_scopes, prior_scopes) == context.snapshot.get('release_cache_source_delta'), 'sealed exact two-file compiler source delta differs')
    old.save(context.base / 'compiler-cache-scope.json', {'target': context.env['CARGO_TARGET_DIR'], 'independent_previous_evidence_root': context.snapshot.get('release_cache_evidence_root'), 'dependency_cache_reused': cache_evidence is not None, 'prior_release_cache_evidence': cache_evidence, 'source_delta': context.snapshot.get('release_cache_source_delta'), 'previous_test_results_reused': False, 'scope': 'Dependency/object cache only; both current release Cargo build commands execute again. CLI/driver build only; no full Rust/Python or HTTP acceptance executed.'})
    for name in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_BUILD_TARGET', 'CARGO_PROFILE_RELEASE_OPT_LEVEL', 'CARGO_PROFILE_RELEASE_DEBUG', 'CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS'): context.env.pop(name, None)
    tools = {}
    for tool in ('cargo', 'rustc', 'rustfmt', 'rustdoc'):
        raw, _ = context.command('rustup-which-' + tool, [old.RUSTUP, 'which', tool]); path = old.ordinary(Path(raw.decode().strip())); tools[tool] = {'path': str(path), **pin(path)}
    raw, _ = context.command('rustc-version', [tools['rustc']['path'], '--version', '--verbose']); old.require(b'release: 1.98.1' in raw and b'host: x86_64-pc-windows-msvc' in raw, 'selected actual native compiler differs')
    raw, _ = context.command('cargo-version', [tools['cargo']['path'], '--version', '--verbose']); old.require(b'cargo 1.98.1' in raw, 'actual selected Cargo differs')
    old.save(context.base / 'native-runtime.json', {'platform': sys.platform, 'python': sys.version, 'python_executable': sys.executable, 'python_pin': pin(sys.executable), 'compiler_tools': tools, 'selected_environment': {n: context.env.get(n) for n in ('RUSTUP_TOOLCHAIN', 'CARGO_TARGET_DIR', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_BUILD_TARGET')}, 'scope': 'Native release candidate narrow builds/probes only; no full tests/Python/HTTP.'})
    registry_before = context.registry(); old.save(context.base / 'registry-before.json', registry_before)
    raw, _ = context.cargo('release-cli-build', 'build', '-p', 'noetome-cli', '--bin', 'noetome', '--release', '--locked', '--offline', '--message-format=json')
    cli_artifacts, cli_scripts = parse_build(raw)
    candidates = [v for v in cli_artifacts if v['target']['name'] == 'noetome' and not v['profile']['test'] and v.get('executable')]
    old.require(len(candidates) == 1, 'one actual release CLI Cargo artifact required'); cli_record = candidates[0]; built_cli = Path(cli_record['executable'])
    built_cli_metadata = metadata(built_cli, temporary_cargo_output=True)
    cli = context.base / 'selected/noetome.exe'; shutil.copyfile(built_cli, cli); fixed.register(cli)
    old.require(pin(cli) == pin(built_cli) and cli.stat().st_nlink == 1, 'actual release CLI copy failed'); context.selected[cli.name] = pin(cli)
    old.require(metadata(built_cli, temporary_cargo_output=True) == built_cli_metadata, 'built CLI identity/time changed during selected copy')
    with cli.open('rb') as f: old.require(f.read(2) == b'MZ', 'actual release CLI is not PE')
    raw, _ = context.cargo('release-driver-build', 'test', '-p', 'noetome-cli', '--lib', '--release', '--no-run', '--locked', '--offline', '--message-format=json')
    driver_artifacts, driver_scripts = parse_build(raw)
    candidates = [v for v in driver_artifacts if v['target']['name'] == 'noetome_cli' and v['profile']['test'] and v.get('executable')]
    old.require(len(candidates) == 1, 'one actual release libtest artifact required'); driver_record = candidates[0]; built_driver = Path(driver_record['executable'])
    built_driver_metadata = metadata(built_driver, temporary_cargo_output=True)
    driver = context.base / 'selected/noetome-cli-testdriver.exe'; shutil.copyfile(built_driver, driver); fixed.register(driver)
    old.require(pin(driver) == pin(built_driver) and driver.stat().st_nlink == 1, 'actual release driver copy failed'); context.selected[driver.name] = pin(driver)
    old.require(metadata(built_driver, temporary_cargo_output=True) == built_driver_metadata, 'built driver identity/time changed during selected copy')
    with driver.open('rb') as f: old.require(f.read(2) == b'MZ', 'actual release test-driver is not PE')
    for record in (cli_record, driver_record):
        old.require(record['profile']['opt_level'] == '3' and record['profile']['debug_assertions'] is False, 'actual release Cargo optimization profile differs')
    cli_fp = {v[1] for s in cli_scripts for v in s.get('env', []) if v[0] == 'NOETOME_RUN_COMPILER_FINGERPRINT'}
    driver_fp = {v[1] for s in driver_scripts for v in s.get('env', []) if v[0] == 'NOETOME_RUN_COMPILER_FINGERPRINT'}
    old.require(len(cli_fp) == 1 and cli_fp == driver_fp, 'release CLI/driver actual Cargo compiler fingerprints differ')
    old.save(context.base / 'compiler-artifacts.json', {'cli': cli_artifacts, 'driver': driver_artifacts}); old.save(context.base / 'actual-build-script-records.json', {'cli': cli_scripts, 'driver': driver_scripts})
    context.command('test-driver-list', [driver, '--list'])
    envelope, fp, handshakes, fingerprints = context.runtime_probes(cli, driver, driver_scripts)
    old.require({fp} == cli_fp, 'actual release CLI/driver probes differ from both Cargo builds')
    registry_after = context.registry(); old.save(context.base / 'registry-after.json', registry_after)
    old.require(all(registry_after['files'].get(n) == v for n, v in registry_before['files'].items()) and all(registry_after['archives'].get(n) == v for n, v in registry_before['archives'].items()), 'original locked dependencies changed')
    for item in tools.values(): old.require(pin(item['path']) == {k: item[k] for k in ('sha256', 'byte_length')}, 'actual compiler tool body changed')
    context.guards(); old.save(context.base / 'source-after.json', old.files(context.repo, context.expected))
    fixed.check(); old.save(context.base / 'strong-metadata-after.json', fixed.receipt())
    receipt = {'status': 'passed_release_build_and_probes_only', 'platform': 'windows', 'profile': 'release', 'source_count': len(context.expected), 'source_before_after_equal': True, 'source_snapshot': pin(context.base / 'snapshot.json'), 'source_archive': pin(context.base / 'source-originals.zip'), 'precise_source_scopes': pin(context.base / 'precise-source-scopes.json'), 'executor': pin(context.base / 'release-executor.py'), 'selected_executables': context.selected, 'actual_cli_and_driver_compiler_fingerprint': fp, 'actual_cli_cargo_fingerprints': sorted(cli_fp), 'actual_driver_cargo_fingerprints': sorted(driver_fp), 'actual_cargo_artifacts': {'cli': cli_record, 'driver': driver_record}, 'runtime_probes': {'cli': envelope, 'driver_handshake': handshakes[0]}, 'compiler_tools': tools, 'registry_before_after_existing_bytes_equal': True, 'declared_build_assets': context.build_assets, 'external_sentinel_before_after_equal': True, 'commands': context.commands, 'full_rust_tests': 'not_run', 'full_python_tests': 'not_run', 'HTTP_acceptance': 'not_run', 'previous_test_results_reused': False}
    receipt['temporary_cargo_output_copy_guard'] = {
        'cli': built_cli_metadata,
        'driver': built_driver_metadata,
        'scope': 'Only generated Cargo outputs may have their ordinary Cargo hardlinks; actual ID/time/link-count metadata must remain unchanged across copy. Source/control/selected paths require one link.',
    }
    receipt['compiler_cache_scope'] = {'receipt': pin(context.base / 'compiler-cache-scope.json'), 'dependency_cache_reused': cache_evidence is not None, 'previous_test_results_reused': False}
    receipt['strong_metadata_guard'] = {
        'before': pin(context.base / 'strong-metadata-before.json'),
        'after': pin(context.base / 'strong-metadata-after.json'),
        'fixed_initial_per_file': True,
        'file_actual_ID_mtime_length_singlelink_guard': True,
        'ancestor_reparse_checked_before_reads': True,
        'selected_programs_registered_once_before_use': True,
        'binary_aliases_created': False,
        'directory_actual_identity_guard': False,
        'runtime_tool_actual_identity_guard': False,
    }
    old.save(context.base / 'release-build-receipt.json', receipt); old.save(context.base / 'native-final.json', receipt)
    print(json.dumps({'status': receipt['status'], 'compiler_fingerprint': fp, 'selected_executables': context.selected}), flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__); modes = p.add_subparsers(dest='mode', required=True)
    q = modes.add_parser('prepare'); q.add_argument('--repo', type=Path, required=True); q.add_argument('--native-base', type=Path, required=True); q.add_argument('--original-runner', type=Path, required=True); q.add_argument('--freeze-label', required=True); q.add_argument('--cache-target', type=Path); q.add_argument('--cache-evidence-root', type=Path)
    q = modes.add_parser('launch'); q.add_argument('--native-base', type=Path, required=True)
    q = modes.add_parser('run'); q.add_argument('--base', type=Path, required=True)
    for name in ('snapshot', 'runner', 'source-archive', 'executor'): q.add_argument('--' + name + '-sha256', required=True)
    args = p.parse_args()
    if args.mode == 'prepare': return prepare(args)
    if args.mode == 'launch': return launch(args)
    try: native(args)
    except Exception as error:
        if args.base.exists():
            old = module(args.base / 'runner.py'); old.save(args.base / 'native-failure.json', {'status': 'failed_release_candidate', 'error_type': type(error).__name__, 'error': str(error), 'scope': 'Narrow candidate failed; original raw/build evidence retained, no tests or timing pass inferred.'})
        raise


if __name__ == '__main__': main()
