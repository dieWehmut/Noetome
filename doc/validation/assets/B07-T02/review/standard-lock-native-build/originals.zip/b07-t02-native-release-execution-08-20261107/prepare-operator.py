from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, time
ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-08-20261107'
EXE = ROOT / '.artifacts/b07-t02-release-builder-draft-08-20261107/executor.py'
BASE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-08-20261107')
EXPECTED = '2c1f409c09d6e04519117b50a962b4adeacb64ef653100866b309140ebc24f0a'
assert hashlib.sha256(EXE.read_bytes()).hexdigest() == EXPECTED
spec = importlib.util.spec_from_file_location('reviewed_release08_operator', EXE)
new = importlib.util.module_from_spec(spec); spec.loader.exec_module(new)
old = new.module(ROOT / '.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py')
names = old.source_names(ROOT)
before = {n:new.metadata(ROOT/n) for n in names}
(OUT/'prepare-source-metadata-before.json').write_text(json.dumps(before,indent=2)+'\n')
argv = ['/tmp/noetome-b05-t03-python/bin/python','-B',str(EXE),'prepare','--repo',str(ROOT),'--native-base',str(BASE),'--original-runner',str(ROOT/'.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py'),'--freeze-label','registered-identity-release08','--cache-target','/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-01-20261107/build-target','--cache-evidence-root','/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-02-20261107']
env = os.environ.copy()
for n in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):env.pop(n,None)
env['NO_PROXY']=env['no_proxy']='localhost,127.0.0.1'
start = time.time_ns()
(OUT/'prepare-start.json').write_text(json.dumps({'operator_PID':os.getpid(),'argv':argv,'cwd':str(ROOT),'child_environment_names':sorted(env),'started_utc_ns':start},indent=2)+'\n')
with (OUT/'prepare.stdout.bin').open('wb') as stdout,(OUT/'prepare.stderr.bin').open('wb') as stderr:
 child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
 (OUT/'prepare-pid.json').write_text(json.dumps({'PID':child.pid,'operator_PID':os.getpid()},indent=2)+'\n')
 code=child.wait()
error=None;after={}
try:
 after_names=old.source_names(ROOT);after={n:new.metadata(ROOT/n) for n in after_names}
 same=after_names==names and before==after
 if not same:error='original named source identity/mtime/length/singlelinks changed across prepare'
except Exception as e:same=False;error=repr(e)
(OUT/'prepare-source-metadata-after.json').write_text(json.dumps(after,indent=2)+'\n')
record={'argv':argv,'operator_PID':os.getpid(),'PID':child.pid,'started_utc_ns':start,'finished_utc_ns':time.time_ns(),'exit_code':code,'actual_wait_closed':True,'original_source_names_ID_mtime_size_singlelinks_equal':same,'source_guard_error':error,'Native':'not_run','Cargo':'not_run'}
(OUT/'prepare-actual.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(0 if code==0 and same else code or 1)
