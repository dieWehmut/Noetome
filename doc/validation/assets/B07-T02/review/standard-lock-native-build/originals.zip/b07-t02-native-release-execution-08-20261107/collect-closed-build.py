"""Collect closed release08 build originals only; do not run tests or HTTP."""
from pathlib import Path, PureWindowsPath
import hashlib
import json
import os
import types

ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-08-20261107'
BASE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-08-20261107')
READER = OUT / 'readback-operator.py'
raw = READER.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '328221a8a259114dc35f42a5a7937f1790b0e8319dd74808c25cedefd461b764'
reader = types.ModuleType('closed_release08_read_helpers'); reader.__file__ = str(READER)
exec(compile(raw, str(READER), 'exec'), reader.__dict__)
launch = json.loads((OUT / 'launch-actual.json').read_bytes())
assert launch['exit_code'] == 0 and launch['actual_wait_closed']
outer_body, _ = reader.read_guarded(BASE / 'outer-native-result.json')
outer = json.loads(outer_body)
assert outer['exit_code'] == 0 and outer['worktree_before_after_equal']
assert outer['worktree_named_inventory_equal'] and outer['control_originals_equal']
top = OUT / 'native-top'; top.mkdir(exist_ok=False)
copies = {}
for path in sorted(BASE.iterdir()):
    if path.is_dir(): continue
    body, proof = reader.read_guarded(path)
    destination = top / path.name
    with destination.open('xb') as stream: stream.write(body)
    assert destination.read_bytes() == body
    copies[path.name] = {'pin': reader.pin(body), 'source_readback': proof, 'full_byte_copy_equal': True}
primary = json.loads((top / 'release-build-receipt.json').read_bytes())
selected = json.loads((top / 'selected-build-receipt.json').read_bytes())
assert primary['status'] == 'passed_release_build_and_probes_only'
assert primary['source_before_after_equal'] and primary['external_sentinel_before_after_equal']
assert primary['registry_before_after_existing_bytes_equal'] and primary['previous_test_results_reused'] is False
commands = json.loads((top / 'native-commands.json').read_bytes())
assert len(commands) == 11
assert all(row['exit_code'] == 0 and row['guard_error'] is None and not row['timed_out']
           and row['source_before_after_equal'] and row['declared_build_assets_equal']
           and row['external_sentinel_before_after_equal'] for row in commands)
assert selected['source_snapshot'] == reader.pin((top / 'snapshot.json').read_bytes())
assert selected['source_archive'] == reader.pin((top / 'source-originals.zip').read_bytes())
assert selected['actual_compiler_fingerprint'] == primary['actual_cli_and_driver_compiler_fingerprint']
programs = OUT / 'selected'; programs.mkdir(exist_ok=False)
program_proofs = {}
for field, filename in (('cli', 'noetome.exe'), ('test_driver', 'noetome-cli-testdriver.exe')):
    expected = selected[field]
    source = BASE / 'selected' / filename
    native = PureWindowsPath('D:/') / source.relative_to(Path('/mnt/d')).as_posix()
    assert PureWindowsPath(expected['path']) == native
    body, proof = reader.read_guarded(source, {key: expected[key] for key in ('sha256', 'byte_length')})
    assert body.startswith(b'MZ')
    destination = programs / filename
    with destination.open('xb') as stream: stream.write(body)
    assert destination.read_bytes() == body
    again, _ = reader.read_guarded(source, reader.pin(body), proof['metadata_before'])
    assert again == body
    program_proofs[field] = {'original': expected, 'actual_Home_readback': proof,
                             'copy_path': str(destination), 'full_MZ_copy_readback_equal': True}
snapshot = json.loads((top / 'snapshot.json').read_bytes())
assert len(snapshot['files']) == primary['source_count'] == 2056
store = snapshot['files']['crates/noetome-cli/src/request_budget_store.rs']
assert store == {'sha256': 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a', 'byte_length': 165884}
record = {'schema_version': 1, 'producer': 'closed_release08_top_and_selected_exact_copy',
          'PID': os.getpid(), 'Native_root': str(BASE), 'top_files': copies,
          'selected_programs': program_proofs, 'actual_compiler_fingerprint': selected['actual_compiler_fingerprint'],
          'actual_commands': [{'name': row['name'], 'pid': row['pid'], 'exit_code': row['exit_code'],
                              'elapsed_seconds': row['elapsed_seconds']} for row in commands],
          'all_source_control_registry_asset_sentinel_guards_true': True,
          'actual_launch_outer_wait_closed0': True, 'source_count': 2056,
          'driver_list_only_not_test_execution': True,
          'mutable_cache_not_copied': True, 'HTTP': 'not_run', 'full807': 'not_run', 'real_paid': 0}
(OUT / 'closed-build-copy-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'PID': os.getpid(), 'top_files': len(copies), 'compiler_fingerprint': record['actual_compiler_fingerprint'],
                  'programs': {name: row['original'] for name, row in program_proofs.items()},
                  'all_11_commands_and_outer_wait0': True, 'no_HTTP_no_full807': True}, indent=2))
