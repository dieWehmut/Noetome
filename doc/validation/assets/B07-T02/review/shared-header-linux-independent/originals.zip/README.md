# B07-T02 冻结 891 候选的独立 Linux 原件审查

本包只保存独立审查的程序、原始输出、观察原件和报告。测试程序与五个主要证据包的完整大体保留在各自原包，本包不重复两个 ELF 或完整测试项目。所有审查均为只读；审查者没有调用产品、Cargo、HTTP、模型服务或 Windows 工作负载。

被审查的历史候选编译指纹是 `89136b36bc30a77c5e7a1a54fd480c8d06be89e060377f1482954fbed12433b0`，Run 源码 SHA 为 `b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c`，Store 源码 SHA 为 `2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184`。其 130 文件编译来源以固定 pair 的 `source-originals.zip` 为原锚；该 ZIP SHA 为 `3ff0d5211fbe7f119302387e1f2d36a3e5b9a5865ad70280f50c3c43be4216ef`。审查没有要求随后正在编辑的仓库源码与旧候选相等，也没有把旧测试结果用于新的 e4/57c1 身份 helper。

独立审查实际重读了 62 个成功验收组中的原 HTTP、请求/响应和完整事件链：39 个有效预算流程与 23 个保护/拒绝组分开，攻击后的数据库没有被计为有效账本。原矩阵有 364 次普通 CLI、33 次 libtest driver、397 个唯一已 wait 的 PID、70 个实际 HTTP incoming 和相应 UUID 接收原件，以及 23 次实际 SIGKILL/-9 后 wait。独立重建核对 511 个有效流程事件、R8310、Known700、不同请求同响应 SHA 的各次结算、并发近限、全局 opening、未知承诺、有限分类/退避和原绝对期限。

`special-pair-and-source-readback02.json` 保存 accepted 场景的真实 B 已 succeeded 且原请求/原件稳定、A 已接受但无 seal/receipt 的 kill 前后证据，并核对两条原 1000ms 退避中断链、1700ms 等待和四个同步篡改的实际原件诊断。两个完整 ELF 独立读回，程序包内 `pair-actual.json` 是确切普通原件；本包不声称它是新生成的证明。

诊断原始 stdout 确认 42 项预算模块测试通过，且五条诊断命令的完整 130 文件 before/after 清单均与固定 pair 的清单相等。完整 Python 原始 stderr 逐项重计为 466 项，444 通过、22 跳过、0 error/failure，实际 PID818751，原始 unittest 耗时77.660秒。测试快照2058文件、当时仓库 before/after2056文件、所选 CLI 的三个原锚和两份程序别名均实际核对。保留的两个多硬链接攻击文件只作为归档反例原件；所选输入和程序仍要求普通单链接。

五个包的所有 ZIP 成员分别为诊断41、程序2+2、主矩阵3792、完整Python15185，共19022个外层成员，均验证 CRC/SHA/长度和普通原件来源。嵌套编译 ZIP 的130成员另行完整读回。主包3792成员是3791个普通原件加一个生成引用；该引用与其事先保存的 standalone builder 及五个原引用文件独立核对，未把生成引用伪称成普通原件。完整 Python 保留一个符号链接的 metadata/target 字面值，没有读取链接目标。

所有五包审查结束后，`global-after-five-archives-readback.json` 又逐字节重读19064个唯一普通原件及公开文件，核对实际 fstat/路径 ID、mtime、链接数和完整 SHA；主矩阵5109个库存 metadata 条目也与最初捕获相等。这是跨整轮审查的后验复查，不仅是每次 archive.read 的 CRC 检查。该报告 SHA 为 `230290b44884261bc17451ed64698616f1cfdbf4d4e06f860e6aee78eae6f472`。

审查脚本的准备失败如实保留：第一次 Python 审查程序准备时字符串替换断言失败，原 inline 准备代码只存在工具记录，没有独立脚本或分离 stdout/stderr；随后 child Python 因目标审查脚本尚未生成而退出2，其真实 `full-python.stdout.bin`/`full-python.stderr.bin` 保留。`preparation-attempt01-observation.json` 是后来写的事实说明，不能冒称初次准备的原始 stdout。完整通过审查使用实际存在的 `full_python.py` 与 `full-python02.*` 原输出。

完整 Linux workspace Rust、当前新 helper 的完整回归、Windows 主62、完整 Windows Rust/Python、生产模型账单和科学质量未从本包推定。原 C2 Windows 窗口的 backoff kill 与 NoFit/未运行场景留在独立历史包，不能代替 Windows 完整验收。
