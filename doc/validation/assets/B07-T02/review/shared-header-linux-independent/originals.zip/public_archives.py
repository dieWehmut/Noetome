"""Independent readback of closed 891 diagnostic/program archives; no product calls."""
from pathlib import Path
import binascii
import hashlib
import io
import json
import os
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
REPO = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PUBLIC = REPO / 'doc/validation/assets/B07-T02'
PAIR = REPO / '.artifacts/b07-t02-linux-shared-header-pair-01-20261107'
FP = '89136b36bc30a77c5e7a1a54fd480c8d06be89e060377f1482954fbed12433b0'
PINS = {}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, str(path)
    shape = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_nlink)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        after_open = os.fstat(stream.fileno())
    after = path.lstat()
    assert shape(before) == shape(opened) == shape(after_open) == shape(after), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
           'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns,
           'mode': before.st_mode, 'nlink': before.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin, str(path)
    return raw

def data(path):
    return json.loads(read(path))

def short(pin):
    return {k: pin[k] for k in ['sha256', 'byte_length']}

def crc(archive, name, raw):
    item = archive.getinfo(name)
    assert item.file_size == len(raw) and (binascii.crc32(raw) & 0xffffffff) == item.CRC
    return item.CRC

def recorded_equals(actual, recorded):
    return all(actual[k] == value for k, value in recorded.items())

diag = PUBLIC / 'diagnostic-shared-header'
manifest = data(diag / 'manifest.json')
receipt = data(diag / 'receipt.json')
assert len(manifest) == receipt['members'] == 41
diag_raw = read(diag / 'originals.zip')
assert short(PINS[str(diag / 'originals.zip')]) == receipt['archive'] == {
    'sha256': '2d308c9fe23cfa234bb2eb202bf00878a45bb2cb26ac9c4cb27f0bcc8c440072',
    'byte_length': 847025}
assert data(diag / 'links.json') == {} and receipt['symlinks_recorded_without_target_read'] == 0
diag_members = []
with zipfile.ZipFile(io.BytesIO(diag_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == 41
    assert set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        raw = archive.read(name)
        value_crc = crc(archive, name, raw)
        original = REPO / '.artifacts' / name
        assert read(original) == raw
        pin = PINS[str(original)]
        assert short(pin) == {k: expected[k] for k in ['sha256', 'byte_length']}
        meta = expected['original_metadata']
        assert (pin['device'], pin['inode'], pin['mtime_ns'], pin['byte_length'], stat.S_IMODE(pin['mode'])) == (
            meta['device'], meta['inode'], meta['mtime_ns'], meta['size'], meta['mode'])
        diag_members.append({'member': name, 'original': str(original), 'pin': pin, 'CRC': value_crc})

pair_actual_raw = read(PAIR / 'actual.json')
pair_actual = json.loads(pair_actual_raw)
source_before = data(PAIR / 'source-before.json')
source_after = data(PAIR / 'source-after.json')
assert source_before == source_after and len(source_before) == 130
assert pair_actual['cargo_build_script_fingerprints'] == [FP] and pair_actual['actual_cli_fingerprint'] == FP
source_zip_raw = read(PAIR / 'source-originals.zip')
assert recorded_equals(PINS[str(PAIR / 'source-originals.zip')], pair_actual['source_archive'])
assert short(PINS[str(PAIR / 'source-originals.zip')]) == {
    'sha256': '3ff0d5211fbe7f119302387e1f2d36a3e5b9a5865ad70280f50c3c43be4216ef', 'byte_length': 720437}
source_members = []
with zipfile.ZipFile(io.BytesIO(source_zip_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == 130
    assert set(archive.namelist()) == set(source_before)
    for name, expected in source_before.items():
        raw = archive.read(name)
        value_crc = crc(archive, name, raw)
        assert {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)} == short(expected)
        source_members.append({'member': name, 'pin': short(expected), 'CRC': value_crc})
assert source_before['crates/noetome-cli/src/request_run.rs']['sha256'] == 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c'
assert source_before['crates/noetome-cli/src/request_budget_store.rs']['sha256'] == '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184'

commands = []
for label in ['guards', 'fmt', 'check', 'cli-build', 'driver-build']:
    root = REPO / '.artifacts' / ('b07-t02-linux-shared-header-' + label + '-01-20261107')
    actual = data(root / 'actual.json')
    launch = data(root / 'launch.json')
    before = data(root / 'source-before.json')
    after = data(root / 'source-after.json')
    assert before == after == source_before and len(before) == actual['source_count'] == 130
    assert actual['source_delta'] == {} and actual['exit_code'] == 0
    assert actual['pid'] == launch['pid'] and actual['argv'] == launch['argv']
    stdout_raw = read(root / 'stdout.bin')
    stderr_raw = read(root / 'stderr.bin')
    assert recorded_equals(PINS[str(root / 'stdout.bin')], actual['stdout'])
    assert recorded_equals(PINS[str(root / 'stderr.bin')], actual['stderr'])
    item = {'label': label, 'PID': actual['pid'], 'exit_code': actual['exit_code'],
            'argv': actual['argv'], 'actual_elapsed_seconds': actual['elapsed_seconds'],
            'source_full_130_before_after_and_pair_equal': True,
            'stdout': PINS[str(root / 'stdout.bin')], 'stderr': PINS[str(root / 'stderr.bin')]}
    if label == 'guards':
        stdout = stdout_raw.decode('utf8')
        rows = re.findall(r'^(test \S+) \.\.\. (ok|FAILED|ignored)$', stdout, re.M)
        assert len(rows) == len({name for name, result in rows}) == 42
        assert all(result == 'ok' for name, result in rows)
        assert re.findall(r'^test result: (.+)$', stdout, re.M) == ['ok. 42 passed; 0 failed; 0 ignored; 0 measured; 476 filtered out; finished in 1.77s']
        item['raw_42_unique_passed_test_rows'] = rows
    if label in ['cli-build', 'driver-build']:
        messages = [json.loads(line) for line in stdout_raw.splitlines() if line.startswith(b'{')]
        observed_fp = {value.split('=', 2)[2] for message in messages for value in message.get('env', [])
                       if isinstance(value, str) and value.startswith('cargo:rustc-env=NOETOME_RUN_COMPILER_FINGERPRINT=')}
        # Cargo JSON represents build-script env as two-element tuples.
        observed_fp |= {value[1] for message in messages for value in message.get('env', [])
                        if isinstance(value, list) and len(value) == 2 and value[0] == 'NOETOME_RUN_COMPILER_FINGERPRINT'}
        assert observed_fp == {FP}
        assert messages[-1]['reason'] == 'build-finished' and messages[-1]['success'] is True
        item['actual_Cargo_build_script_FP'] = sorted(observed_fp)
    commands.append(item)

probe_raw = read(PAIR / 'cli-probe.stdout.bin')
assert recorded_equals(PINS[str(PAIR / 'cli-probe.stdout.bin')], pair_actual['cli_probe_stdout'])
assert read(PAIR / 'cli-probe.stderr.bin') == b''
assert recorded_equals(PINS[str(PAIR / 'cli-probe.stderr.bin')], pair_actual['cli_probe_stderr'])
probe = json.loads(probe_raw)
probe_launch = data(PAIR / 'cli-probe.launch.json')
assert pair_actual['cli_probe_exit_code'] == 0 and pair_actual['cli_probe_pid'] > 0
assert probe_launch['pid'] == pair_actual['cli_probe_pid']
assert probe['compiler_fingerprint'] == FP

program_dir = PUBLIC / 'programs-shared-header'
program_manifest = data(program_dir / 'manifest.json')
program_receipt = data(program_dir / 'receipt.json')
assert len(program_manifest) == program_receipt['archives'] == 2
programs = []
for label, name, pair_field in [('linux-shared-header-pair-01-noetome', 'noetome', 'cli'),
                                ('linux-shared-header-pair-01-request-test-driver', 'request-test-driver', 'test_driver')]:
    expected = program_manifest[label]
    program_raw = read(PAIR / name)
    assert program_raw.startswith(b'\x7fELF')
    assert short(PINS[str(PAIR / name)]) == expected['original_executable']
    assert recorded_equals(PINS[str(PAIR / name)], expected['original_identity_mtime'])
    assert recorded_equals(PINS[str(PAIR / name)], pair_actual[pair_field])
    assert expected['actual_compiler_fingerprint'] == FP
    zip_path = program_dir / (label + '.zip')
    zip_raw = read(zip_path)
    assert short(PINS[str(zip_path)]) == expected['archive']
    members = []
    with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist())) == 2
        assert set(archive.namelist()) == {name, 'pair-actual.json'}
        for member, original_raw in [(name, program_raw), ('pair-actual.json', pair_actual_raw)]:
            raw = archive.read(member)
            assert raw == original_raw
            members.append({'member': member, 'sha256': hashlib.sha256(raw).hexdigest(),
                            'byte_length': len(raw), 'CRC': crc(archive, member, raw)})
    programs.append({'label': label, 'archive': PINS[str(zip_path)], 'program_original': PINS[str(PAIR / name)],
                     'members': members, 'pair_actual_member_is_exact_ordinary_original_not_generated': True})

# All touched ordinary originals stay fixed through the entire multi-archive audit.
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_frozen_891_diagnostic_and_full_program_original_readback', 'status': 'passed',
          'scope': 'Frozen b393/Store2e97/FP891 source and program originals only; new registered-identity helper is not tested by these results.',
          'new_product_Cargo_HTTP_invocations': 0, 'real_model_or_paid_calls': 0,
          'diagnostic_CRC_SHA_length_members': 41, 'program_archive_count': 2, 'program_CRC_SHA_length_members': 4,
          'nested_source_CRC_SHA_length_members': 130, 'compiler_fingerprint': FP,
          'all_touched_original_actual_fstat_path_ID_mtime_singlelink_bytes_initial_and_global_after_equal': True,
          'current_Root_source_equality_claimed': False, 'all_five_command_source_maps_equal_frozen_pair_130': True,
          'actual_commands': commands, 'actual_CLI_probe_PID': pair_actual['cli_probe_pid'],
          'actual_CLI_probe_exit_code': pair_actual['cli_probe_exit_code'],
          'diagnostic_members': diag_members, 'source_members': source_members, 'programs': programs,
          'all_original_pins': PINS, 'full_Linux_Rust': 'not_run', 'current_Native_main62': 'not_run'}
target = OUT / 'diagnostic-programs-source-readback.json'
with target.open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'outer_archive_members': 45, 'nested_source_members': 130,
                  'module_actual_passed': 42, 'source_before_after_and_pair': 130,
                  'actual_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'byte_length': target.stat().st_size}))
