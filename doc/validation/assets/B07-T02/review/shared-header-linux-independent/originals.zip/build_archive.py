"""Archive already closed reviewer originals; script is saved before generation."""
from pathlib import Path
import binascii
import hashlib
import io
import json
import os
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).parent
PACKAGE = ROOT / 'package'
PINS = {}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    shape = lambda x: (x.st_dev, x.st_ino, x.st_mode, x.st_size, x.st_mtime_ns, x.st_nlink)
    with path.open('rb') as stream:
        actual = os.fstat(stream.fileno())
        raw = stream.read()
        final = os.fstat(stream.fileno())
    after = path.lstat()
    assert shape(before) == shape(actual) == shape(final) == shape(after), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
           'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns,
           'mode': before.st_mode, 'nlink': before.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

files = sorted(path for path in ROOT.iterdir() if path.is_file())
assert ROOT / 'build_archive.py' in files and ROOT / 'README.md' in files
assert len(files) == len({p.name for p in files})
PACKAGE.mkdir(exist_ok=False)
manifest = {'producer': 'independent_review_original_preservation', 'scope': 'Frozen b393/2e97/FP891 Linux review only; no full ELF or main evidence body duplicated.', 'members': []}
zip_path = PACKAGE / 'originals.zip'
with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        raw = read(path)
        archive.writestr(path.name, raw)
        manifest['members'].append({'member': path.name, 'original': str(path), 'pin': PINS[str(path)]})
zip_raw = read(zip_path)
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files)
    for row in manifest['members']:
        raw = archive.read(row['member'])
        item = archive.getinfo(row['member'])
        assert len(raw) == item.file_size == row['pin']['byte_length']
        assert (binascii.crc32(raw) & 0xffffffff) == item.CRC
        assert hashlib.sha256(raw).hexdigest() == row['pin']['sha256']
        assert raw == read(Path(row['original']))
for path in list(PINS):
    read(Path(path))
manifest['member_count'] = len(files)
with (PACKAGE / 'manifest.json').open('x') as stream:
    stream.write(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
read(PACKAGE / 'manifest.json')
result = {'producer': 'independent_frozen_891_review_archive_readback', 'status': 'passed',
          'scope': manifest['scope'], 'members': len(files), 'archive': PINS[str(zip_path)],
          'manifest': PINS[str(PACKAGE / 'manifest.json')],
          'all_originals_actual_ID_mtime_singlelink_full_bytes_before_after_equal': True,
          'all_members_CRC_SHA_length_and_exact_original_readback_equal': True,
          'first_preparation_failure_retained_without_invented_raw': True,
          'main_five_archives_outer_members_independently_verified': 19022,
          'global_after_unique_original_public_files': 19064, 'real_model_or_paid_calls': 0,
          'new_product_HTTP_Cargo_Native_invocations': 0,
          'full_program_bodies_in_this_review_package': False,
          'two_complete_ELFs_original_package': 'doc/validation/assets/B07-T02/programs-shared-header',
          'current_e4_57c1_source_test_result_reuse_claimed': False,
          'standalone_builder': PINS[str(ROOT / 'build_archive.py')]}
with (PACKAGE / 'actual.json').open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
actual = read(PACKAGE / 'actual.json')
print(json.dumps({'status': 'passed', 'members': len(files), 'archive': PINS[str(zip_path)],
                  'manifest': PINS[str(PACKAGE / 'manifest.json')],
                  'actual_sha256': hashlib.sha256(actual).hexdigest(), 'actual_byte_length': len(actual)}))
