from pathlib import Path
import hashlib
import json
import os
import stat
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
out = repo / 'doc/validation/assets/B07-T02' / sys.argv[1]
out.mkdir(parents=True)
selected = sys.argv[2:]
manifest = {}
links = {}

def digest(body):
    return {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body)}

def stamp(path):
    info = path.lstat()
    return {'device': info.st_dev, 'inode': info.st_ino, 'mtime_ns': info.st_mtime_ns,
            'size': info.st_size, 'mode': stat.S_IMODE(info.st_mode)}

with zipfile.ZipFile(out / 'originals.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in selected:
        root = repo / '.artifacts' / name
        if not root.is_dir() or root.is_symlink():
            raise RuntimeError('selected original artifact root missing or linked: ' + name)
        for path in sorted(root.rglob('*')):
            member = name + '/' + path.relative_to(root).as_posix()
            if path.is_symlink():
                links[member] = {'target': os.readlink(path), 'original_metadata': stamp(path),
                                 'scope': 'link preserved as metadata; linked content not read'}
                continue
            if not path.is_file() or path.name in {'noetome', 'request-test-driver', 'noetome.exe', 'noetome-cli-testdriver.exe'}:
                continue
            before = stamp(path)
            body = path.read_bytes()
            if before != stamp(path):
                raise RuntimeError('original changed during archive: ' + member)
            manifest[member] = {**digest(body), 'original_metadata': before}
            archive.writestr(member, body)
with zipfile.ZipFile(out / 'originals.zip') as archive:
    if archive.testzip() is not None or set(archive.namelist()) != set(manifest):
        raise RuntimeError('archive CRC or named inventory mismatch')
    for member, original in manifest.items():
        if digest(archive.read(member)) != {k: original[k] for k in ['sha256', 'byte_length']}:
            raise RuntimeError('archive original bytes differ: ' + member)
for name, value in [('manifest.json', manifest), ('links.json', links)]:
    (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
receipt = {'status': 'originals_archived_and_read_back', 'selected_artifact_roots': selected,
           'members': len(manifest), 'original_byte_length': sum(v['byte_length'] for v in manifest.values()),
           'archive': digest((out / 'originals.zip').read_bytes()), 'symlinks_recorded_without_target_read': len(links),
           'scope': 'original evidence preservation only; this does not run tests or change their recorded outcomes',
           'real_model_calls': 0, 'paid_calls': 0}
(out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt, ensure_ascii=False), flush=True)
