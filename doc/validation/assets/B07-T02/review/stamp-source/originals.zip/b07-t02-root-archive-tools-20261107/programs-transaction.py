from pathlib import Path
import hashlib
import json
import zipfile

repo = Path(__file__).resolve().parents[2]
out = repo / 'doc/validation/assets/B07-T02/programs-transaction'
out.mkdir()
records = {}

def identity(path):
    for parent in (path,*path.parents):
        if parent.is_symlink(): raise RuntimeError('linked original path')
    v=path.lstat()
    if not path.is_file() or v.st_nlink!=1: raise RuntimeError('not a single-link original file')
    return {'device':v.st_dev,'inode':v.st_ino,'mtime_ns':v.st_mtime_ns}

def pin(body):
    return {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body)}

for number in ['01']:
    source = repo / '.artifacts' / f'b07-t02-linux-transaction-pair-{number}-20261107'
    actual = json.loads((source / 'actual.json').read_bytes())
    for executable, role in [('noetome', 'cli'), ('request-test-driver', 'test_driver')]:
        label = f'linux-transaction-pair-{number}-{executable}'
        expected = {k: actual[role][k] for k in ['sha256', 'byte_length']}
        original=source / executable
        expected_identity={k:actual[role][k] for k in ['device','inode','mtime_ns']}
        if identity(original)!=expected_identity: raise RuntimeError('original program identity differs from pair receipt')
        body = original.read_bytes()
        if pin(body) != expected or body[:4] != b'\x7fELF':
            raise RuntimeError('selected actual ELF differs: ' + label)
        path = out / (label + '.zip')
        with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr(executable, body)
            archive.writestr('pair-actual.json', (source / 'actual.json').read_bytes())
        if path.stat().st_size >= 100_000_000:
            raise RuntimeError('archive exceeds the per-file remote limit: ' + label)
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None or pin(archive.read(executable)) != expected:
                raise RuntimeError('program archive CRC/SHA differs: ' + label)
            if archive.read('pair-actual.json') != (source / 'actual.json').read_bytes():
                raise RuntimeError('original pair receipt differs: ' + label)
        if identity(original)!=expected_identity or pin(original.read_bytes()) != expected or identity(original)!=expected_identity:
            raise RuntimeError('selected original changed during archival')
        records[label] = {'original_executable': expected, 'original_identity_mtime':expected_identity, 'archive': pin(path.read_bytes()),
                          'actual_compiler_fingerprint': actual['actual_cli_fingerprint'],
                          'scope': 'full original program bytes preserved; original source and outcomes remain in diagnostic-transaction'}
        print(json.dumps({'archived': label, **records[label]}, ensure_ascii=False), flush=True)
(out / 'manifest.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
(out / 'receipt.json').write_text(json.dumps({'status': 'two_original_program_archives_read_back', 'archives': len(records),
    'CRC_SHA_length_verified': True, 'real_model_calls': 0, 'paid_calls': 0,
    'scope': 'program preservation only; no test executed or result reused'}, indent=2) + '\n', encoding='utf8')
