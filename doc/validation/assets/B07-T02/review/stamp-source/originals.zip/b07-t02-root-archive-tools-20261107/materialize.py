from pathlib import Path
import hashlib
import json
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
root = repo / 'doc/validation/assets/B07-T02' / sys.argv[1]

def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

def identity(path):
    value = path.lstat()
    if path.is_symlink() or not path.is_file() or value.st_nlink != 1:
        raise RuntimeError('not an ordinary single-link archive control: ' + str(path))
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_mode)

controls = [root / name for name in ['originals.zip', 'manifest.json', 'receipt.json']]
before = {p.name: identity(p) for p in controls}
raw = {p.name: p.read_bytes() for p in controls}
if before != {p.name: identity(p) for p in controls}:
    raise RuntimeError('archive controls changed during reading')
manifest = json.loads(raw['manifest.json'])
receipt = json.loads(raw['receipt.json'])
if pin(raw['originals.zip']) != receipt['archive']:
    raise RuntimeError('archive differs from its closed receipt')
rows = []
with zipfile.ZipFile(root / 'originals.zip') as archive:
    for member in sys.argv[2:]:
        expected = {k: manifest[member][k] for k in ['sha256', 'byte_length']}
        body = archive.read(member)
        if pin(body) != expected:
            raise RuntimeError('member CRC/SHA/length mismatch: ' + member)
        target = root / Path(member).name
        with target.open('xb') as stream:
            stream.write(body)
        if target.read_bytes() != body:
            raise RuntimeError('materialized bytes differ')
        rows.append({'member': member, 'output': target.name, 'pin': expected,
                     'archived_original_metadata': manifest[member]['original_metadata']})
if before != {p.name: identity(p) for p in controls}:
    raise RuntimeError('archive controls changed while materializing members')
result = {'status': 'exact_closed_archive_members_materialized', 'rows': rows,
          'archive': pin(raw['originals.zip']), 'control_identity_mtime_unchanged': True,
          'scope': 'reads archived evidence without rerunning tests; original identity evidence remains in the manifest and execution receipts',
          'real_model_calls': 0, 'paid_calls': 0}
with (root / 'materialization-receipt.json').open('x', encoding='utf8') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False), flush=True)
