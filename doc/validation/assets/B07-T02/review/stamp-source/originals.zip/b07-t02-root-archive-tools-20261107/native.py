from pathlib import Path
import hashlib
import json
import os
import stat
import sys
import zipfile

repo = Path(__file__).resolve().parents[2]
source = Path('/mnt/d/Noetome/.artifacts') / sys.argv[2]
output = repo / 'doc/validation/assets/B07-T02' / sys.argv[1]
terminal = json.loads((source / 'outer-native-result.json').read_bytes())
assert terminal['exit_code'] == int(sys.argv[3])
assert (source / 'native-final.json').is_file() if terminal['exit_code'] == 0 else (source / 'native-failure.json').is_file()
output.mkdir(parents=True)

def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

def stamp(path):
    value = path.lstat()
    return {'device': value.st_dev, 'inode': value.st_ino, 'mtime_ns': value.st_mtime_ns,
            'size': value.st_size, 'mode': stat.S_IMODE(value.st_mode)}

files = [p for p in source.iterdir() if p.is_file()]
for name in ['selected', 'cli-runtime-probe', 'driver-runtime-probe']:
    files.extend(p for p in (source / name).rglob('*') if p.is_file() or p.is_symlink())
manifest, links = {}, {}
with zipfile.ZipFile(output / 'originals.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(files):
        name = path.relative_to(source).as_posix()
        before = stamp(path)
        if path.is_symlink():
            links[name] = {'target': os.readlink(path), 'original_metadata': before}
            continue
        raw = path.read_bytes()
        assert before == stamp(path), name
        manifest[name] = {**pin(raw), 'original_metadata': before}
        archive.writestr(name, raw)
with zipfile.ZipFile(output / 'originals.zip') as archive:
    assert archive.testzip() is None and set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        assert pin(archive.read(name)) == {k: expected[k] for k in ['sha256', 'byte_length']}
        path = source / name
        assert stamp(path) == expected['original_metadata'] and pin(path.read_bytes()) == pin(archive.read(name))
receipt = {'status': 'originals_archived_and_read_back', 'source_root': str(source),
           'actual_outer_result': terminal, 'members': len(manifest),
           'archive': pin((output / 'originals.zip').read_bytes()),
           'source_originals_zip_included': True, 'selected_program_bodies_included': True,
           'excluded_directories': ['build-target', 'repo', 'runtime-temp'],
           'scope': 'preserves original completed run results without rerunning or reclassifying them',
           'real_model_calls': 0, 'paid_calls': 0}
for name, value in [('manifest.json', manifest), ('links.json', links), ('receipt.json', receipt)]:
    (output / name).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8'))
print(json.dumps(receipt, ensure_ascii=False), flush=True)
