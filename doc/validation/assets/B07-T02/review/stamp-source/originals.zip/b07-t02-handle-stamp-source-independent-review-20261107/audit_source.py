"""Readonly exact source delta and boundary review; no compile/test/product invocation."""
from pathlib import Path
import difflib,hashlib,io,json,os,re,stat,zipfile
REPO=Path('/home/lyinn/project/Noetome');OUT=Path(__file__).parent
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 with p.open('rb') as f:a=os.fstat(f.fileno());b=f.read();z=os.fstat(f.fileno())
 t=p.lstat();shape=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mtime_ns,q.st_nlink);assert shape(s)==shape(a)==shape(z)==shape(t)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
pub=REPO/'doc/validation/assets/B07-T02/windows-release/originals.zip';outer,pubpin=read(pub)
with zipfile.ZipFile(io.BytesIO(outer)) as z:
 raw=z.read('source-originals.zip')
 with zipfile.ZipFile(io.BytesIO(raw)) as s:old=s.read('repo/crates/noetome-cli/src/request_budget_store.rs')
oldpin={'sha256':hashlib.sha256(old).hexdigest(),'byte_length':len(old)};assert oldpin['sha256']=='f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349'
path=REPO/'crates/noetome-cli/src/request_budget_store.rs';new,newpin=read(path);assert newpin['sha256']=='4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e'
for name,raw in [('before-f765.rs',old),('after-4ca.rs',new)]:
 with (OUT/name).open('xb') as f:f.write(raw)
def block(raw,start,end):
 assert raw.count(start)==1 and raw.count(end)==1
 a=raw.index(start);b=raw.index(end,a);return a,b,raw[a:b]
oa,ob,old_prod=block(old,b'fn stamp_mode(',b'fn matches_pin(')
na,nb,new_prod=block(new,b'fn read_identity(',b'fn matches_pin(')
ta,tb,new_tests=block(new,b'    #[test]\n    fn budget_stamp_rejects_another_same_byte_read_handle()',b'    #[test]\n    fn budget_checked_reserve_requires_the_original_prepared_plan()')
normalized=new[:na]+old_prod+new[nb:ta]+new[tb:]
outside_equal=normalized==old
def diff(a,b):return ''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='before-f765',tofile='after-4ca'))
(OUT/'whole-source.patch').write_text(diff(old,new),encoding='utf-8')
(OUT/'stamp-production.patch').write_text(diff(old_prod,new_prod),encoding='utf-8')
(OUT/'new-stamp-tests.rs').write_bytes(new_tests)
(OUT/'outside-approved-blocks.patch').write_text(diff(old,normalized),encoding='utf-8')
checks={
 'caller_wrapper_always_noop_callback':b'stamp_opened(path, file, initial, || Ok(()))' in new_prod,
 'component_check_before_and_after':new_prod.count(b'project::check_components(path)?;')==2,
 'ordinary_path_check_before_and_after':new_prod.count(b'project::checked_file(path)?;')==2,
 'initial_path_handle_precedes_owned_open':new_prod.index(b'let initial = same_file::Handle::from_path(path)')<new_prod.index(b'let file = if owned'),
 'opened_identity_from_same_actual_read_handle':b'same_file::Handle::from_file(file.try_clone()' in new_prod,
 'initial_opened_current_retained_as_locals':all(x in new_prod for x in [b'if initial != opened',b'let current = same_file::Handle::from_path(path)',b'current != opened']),
 'unix_id_from_read_handle_metadata':all(x in new_prod for x in [b'metadata.dev()',b'metadata.ino()',b'metadata.nlink() != 1']),
 'windows_id_from_actual_read_handle_information':all(x in new_prod for x in [b'winapi_util::file::information(_file)',b'information.volume_serial_number()',b'information.file_index()',b'information.number_of_links() != 1',b'information.file_attributes() & 0x400']),
 'before_after_current_regular_reparse_singlelink':all(x in new_prod for x in [b'!metadata.is_file()',b'project::is_link(metadata)',b'read_identity(path, &file, &before)?',b'read_identity(path, &file, &after)?',b'read_identity(path, current.as_file(), &current_metadata)?']),
 'bounded_full_byte_length_before_after_current':all(x in new_prod for x in [b'before.len() > BYTE_LIMIT',b'.take(BYTE_LIMIT + 1)',b'before.len() != bytes.len() as u64',b'after.len() != before.len()',b'bytes.len() as u64 > BYTE_LIMIT',b'current_metadata.len() != before.len()']),
 'successful_mtime_errors_not_ignored':b'after.modified().map_err' in new_prod and b'.modified().ok()' not in new_prod,
 'owned_share3_and_external_read_guard_preserved':b'options.share_mode(3).custom_flags(0x00200000)' in new_prod and b'project::read_guard(path)?' in new_prod,
 'no_path_identity_reopen_in_stamp_block':b'identity(path)?' not in new_prod,
 'no_cross_call_cache_or_new_environment_flag':b'env::' not in new_prod and b'Static' not in new_prod and b'OnceLock' not in new_prod,
 'full_raw_sha_and_FileStamp_fields_unchanged':all(x in new_prod for x in [b'identity: id',b'sha256: sha256(&bytes)',b'byte_length: bytes.len() as u64',b'modified,']),
 'all_source_outside_stamp_block_and_7_new_test_definitions_exact':outside_equal}
assert all(checks.values()),checks
tests=re.findall(rb'fn (budget_stamp_[A-Za-z0-9_]+)\(',new_tests);assert len(tests)==7
assert new_tests.count(b'#[cfg(unix)]')==2 and new_tests.count(b'#[cfg(windows)]')==1
assert read(path)[1]==newpin and read(pub)[1]==pubpin
result={'status':'passed_independent_handle_stamp_source_review','scope':'Exact f765→4ca production stamp/read_identity/stamp_opened and seven cfg test definitions only. No compilation, tests, product, HTTP or Native invocation by reviewer. Does not infer Windows time-bound behavior or arbitrary external race safety.',
 'before_source':oldpin,'after_source':newpin,'historical_source_archive':pubpin,'checks':checks,
 'new_test_definition_names':[x.decode() for x in tests],'common_test_definitions':4,'unix_only_definitions':2,'windows_only_definitions':1,'actual_platform_test_count_delta':{'Linux':6,'Windows':5},
 'test_execution':'not_run_by_this_reviewer; Root actual guard02 must be bound separately',
 'scope_limits':['File read-handle identity is checked; directory/runtime tool identity holding is a separate existing caller responsibility and is not added by this patch.','No cross-call cache or arbitrary filesystem/mtime restoration guarantee is claimed.','Before6dd build and failed elapsed windows remain historical source only.']}
raw=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode();(OUT/'actual.json').write_bytes(raw)
print(json.dumps({'status':'passed','actual_sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'outside_blocks_byte_equal':outside_equal,'Linux_test_delta':6,'Windows_test_delta':5}))
