    #[test]
    fn budget_stamp_rejects_another_same_byte_read_handle() {
        let f = Fixture::new(100_000);
        let path = f.base.join("stamp-original");
        let other = f.base.join("stamp-replacement");
        fs::write(&path, b"same literal bytes").unwrap();
        fs::write(&other, b"same literal bytes").unwrap();
        let modified = fs::metadata(&path).unwrap().modified().unwrap();
        OpenOptions::new()
            .write(true)
            .open(&other)
            .unwrap()
            .set_times(fs::FileTimes::new().set_modified(modified))
            .unwrap();
        assert_eq!(fs::read(&path).unwrap(), fs::read(&other).unwrap());
        assert_eq!(fs::metadata(&other).unwrap().modified().unwrap(), modified);
        let initial = same_file::Handle::from_path(&path).unwrap();
        assert!(stamp_opened(&path, File::open(&other).unwrap(), initial, || Ok(())).is_err());
    }
    #[test]
    fn budget_stamp_rejects_a_hardlink_added_after_snapshot() {
        let f = Fixture::new(100_000);
        let path = f.base.join("stamp-original");
        fs::write(&path, b"literal bytes remain unchanged").unwrap();
        let initial = same_file::Handle::from_path(&path).unwrap();
        let file = File::open(&path).unwrap();
        let result = stamp_opened(&path, file, initial, || {
            fs::hard_link(&path, f.base.join("new-link")).map_err(|e| ProjectError::io(&path, e))
        });
        assert!(result.is_err());
        assert_eq!(fs::read(&path).unwrap(), b"literal bytes remain unchanged");
    }
    #[test]
    fn budget_stamp_rejects_growth_or_truncation_with_restored_mtime() {
        let f = Fixture::new(100_000);
        for replacement in [b"longer literal replacement".as_slice(), b"x".as_slice()] {
            let path = f.base.join("stamp-original");
            fs::write(&path, b"literal original").unwrap();
            let modified = fs::metadata(&path).unwrap().modified().unwrap();
            let initial = same_file::Handle::from_path(&path).unwrap();
            let file = File::open(&path).unwrap();
            let result = stamp_opened(&path, file, initial, || {
                fs::write(&path, replacement).map_err(|e| ProjectError::io(&path, e))?;
                OpenOptions::new()
                    .write(true)
                    .open(&path)
                    .map_err(|e| ProjectError::io(&path, e))?
                    .set_times(fs::FileTimes::new().set_modified(modified))
                    .map_err(|e| ProjectError::io(&path, e))
            });
            assert!(result.is_err());
            assert_eq!(fs::metadata(&path).unwrap().modified().unwrap(), modified);
        }
    }
    #[test]
    fn budget_stamp_binds_full_raw_bytes_and_rejects_over_limit() {
        let f = Fixture::new(100_000);
        let path = f.base.join("stamp-original");
        for bytes in [Vec::new(), (0..4096).map(|n| (n % 251) as u8).collect()] {
            fs::write(&path, &bytes).unwrap();
            let (pin, actual) = stamp(&path).unwrap();
            assert_eq!(actual, bytes);
            assert_eq!(pin.identity, identity(&path).unwrap());
            assert_eq!(pin.byte_length, bytes.len() as u64);
            assert_eq!(pin.sha256, sha256(&bytes));
        }
        OpenOptions::new()
            .write(true)
            .open(&path)
            .unwrap()
            .set_len(BYTE_LIMIT + 1)
            .unwrap();
        assert!(stamp(&path).is_err());
    }
    #[cfg(unix)]
    #[test]
    fn budget_stamp_rejects_same_bytes_mtime_leaf_replacement_during_read() {
        let f = Fixture::new(100_000);
        let path = f.base.join("stamp-original");
        fs::write(&path, b"same literal bytes").unwrap();
        let modified = fs::metadata(&path).unwrap().modified().unwrap();
        let initial = same_file::Handle::from_path(&path).unwrap();
        let file = File::open(&path).unwrap();
        let result = stamp_opened(&path, file, initial, || {
            fs::rename(&path, f.base.join("old-original"))
                .map_err(|e| ProjectError::io(&path, e))?;
            fs::write(&path, b"same literal bytes").map_err(|e| ProjectError::io(&path, e))?;
            OpenOptions::new()
                .write(true)
                .open(&path)
                .map_err(|e| ProjectError::io(&path, e))?
                .set_times(fs::FileTimes::new().set_modified(modified))
                .map_err(|e| ProjectError::io(&path, e))
        });
        assert!(result.is_err());
        assert_eq!(fs::read(&path).unwrap(), b"same literal bytes");
        assert_eq!(fs::metadata(&path).unwrap().modified().unwrap(), modified);
    }
    #[cfg(unix)]
    #[test]
    fn budget_stamp_rejects_leaf_and_ancestor_symlinks() {
        use std::os::unix::fs::symlink;
        let f = Fixture::new(100_000);
        let parent = f.base.join("stamp-parent");
        fs::create_dir(&parent).unwrap();
        let path = parent.join("original");
        fs::write(&path, b"literal bytes").unwrap();
        let leaf = f.base.join("leaf-link");
        symlink(&path, &leaf).unwrap();
        assert!(stamp(&leaf).is_err());
        let initial = same_file::Handle::from_path(&path).unwrap();
        let file = File::open(&path).unwrap();
        let result = stamp_opened(&path, file, initial, || {
            let saved = f.base.join("original-parent");
            fs::rename(&parent, &saved).map_err(|e| ProjectError::io(&parent, e))?;
            symlink(&saved, &parent).map_err(|e| ProjectError::io(&parent, e))
        });
        assert!(result.is_err());
        assert_eq!(fs::read(&path).unwrap(), b"literal bytes");
    }
    #[cfg(windows)]
    #[test]
    fn budget_stamp_keeps_owned_and_external_share_modes() {
        let f = Fixture::new(100_000);
        let path = f.base.join("stamp-original");
        fs::write(&path, b"literal bytes").unwrap();
        let writer = OpenOptions::new()
            .read(true)
            .write(true)
            .open(&path)
            .unwrap();
        assert_eq!(stamp_mode(&path, true).unwrap().1, b"literal bytes");
        assert!(stamp_mode(&path, false).is_err());
        drop(writer);
        assert_eq!(stamp_mode(&path, false).unwrap().1, b"literal bytes");
    }

