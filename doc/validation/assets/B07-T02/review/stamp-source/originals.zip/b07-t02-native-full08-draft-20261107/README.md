Full08仅静态草稿未prepare/launch，Root须在新release ordinary/三targets/完整62全部green后另给GO。

来源严格Run8e75784/Store4ca142612/Python3b169966/test42850420；prepare逐完整SHA+length+metadata固定，Native entry再核sealed expected包含同4pins。新WinfullRust预期798=原793+4common+1Win，Linuxmodule38=32+4common+2Unix、Winmodule36=31+4common+1Win（旧module有Unix专属一项）；数字只是预期，实际统计不同必须保留失败。fullPython527/8skip、两原生PS39、原全fmt/check/cleanbuild/test/CLI/driver/probe都真实重跑，不复用旧结果。

复制full07原完整execute路径/8controls/4外部SHA/StrongFiles固定metadata+selected/alias登记，只加确切Store/4来源门槛和793→798原判据；所有原PE/FP/source/registry/standalone sentinel及outerwait必须闭环。仅依赖cache可用已closedNative01/build-target且旧结果不替代当前。完整debug与release行为分别编译，FP不可混用。未改public源或既有runner。
