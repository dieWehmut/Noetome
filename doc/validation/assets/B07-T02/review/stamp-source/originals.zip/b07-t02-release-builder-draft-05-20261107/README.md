Release05仅artifact草稿未prepare/launch。严格复制已实际闭合的286bee release04执行器，只改Store新SHA f765→4ca和new长度133950→142612；Run8e/Python3b/test428、8control/4externalSHA/StrongFiles首尾固定元数据/两个真实releaseCargo/新PE新FP双probe保持逐字节不变。

仍以真实physical01/build-target作为依赖缓存，独立已closed02 source/Cargo/outer/cache-scope原件为证据根；固定所有原receipt pins，两currentnamedRust相对02 old2e/726允许精确Run8e/Store4ca的old/new两变化，其余四maps全names+SHA+length相等。新snapshot/sourceZIP封存两个字段和两delta，Native再核actual目标与独立evidence root，绝不以target.parent冒充。

两个release程序、CargoJSON、新FP/源/控制/registry/metadatasentinel/actualouterwait必须真正取得。此窄执行器不运行fullRust798或完整Python/HTTP。前一Native04程序/结果仅历史，新source/FP须重新建立。后继新root建议windows-release-pair-05-20261107，等待Root具体GO，不能恢复旧FP的Run。

实际driver --list还须核当前Windows BudgetStore模块36个，而Linux38不能代入；full798保持。--list是列举，不宣称模块测试执行通过。
