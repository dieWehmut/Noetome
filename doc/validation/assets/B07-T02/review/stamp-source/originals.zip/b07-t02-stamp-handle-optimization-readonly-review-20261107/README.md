只读评估结论：实际read句柄派生Identity并保留initial/opened/current三个活句柄的方案可减少重复路径打开，前提是显式保留原祖先/leaf/reparse/nlink/ID/mtime/length/64MiB/fullSHA和Windows共享语义。project::checked_file不查祖先/nlink；same_file::Handle仅比较文件身份数值，二者都不能代替原identity函数内的保护。

推荐顺序和针对性负例在actual.json。没有编辑源码或运行Cargo/Native/HTTP/测试；没有证明性能收益、Windows1500ms或新实现验收。当前旧NoFit是合法绝对时限结果，金标及1500/200/1000不得改。最终实际代码写完后仍须重新独审与新编译来源/FP/程序体及真正行为门槛。
