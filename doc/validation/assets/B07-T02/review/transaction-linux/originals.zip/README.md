本包保存当前 Linux transaction 实际原件独审和执行脚本。主审查、special-pair-and-source-readback02.json 与 peer-archive-readback.json 是三项独立读回结果；matrix/actual.json 是执行者原始运行结果。62 组包含 39 有效账本流与 23 拒绝保护组，后者不能当作有效账本重建。397 个真实 PID、70 份服务接受/响应原件、23 个 SIGKILL(-9) 和 wait 均按新运行重读。

accepted 原10链中 B 已 succeeded 且 Known700，再释放 A，服务实际接受后终止 A；恢复仍 Unknown8310，B 无额外 HTTP。130 个实际编译源与两完整 ELF 绑定当前 FP288fa7；大程序本体保留在 programs-transaction 两包，本包仅保留引用及源 ZIP。peer3790 = 3789 普通原件 + 1 生成引用；1e6b 独立生成器事前已保存，引用2439B完整重建相等。旧release与Native失败事实仍保留，不计为当前Native通过。

public-archives-review 保存四个新ZIP的独立完整读回：52+2+2+15186=15242成员、普通原件身份/mtime/bytes前后及每成员CRC/SHA/长度全等；一个链接仅核元数据不读目标。Python原始raw为466=444通过+22跳过，2056源与2058含两程序别名快照分别核对。主审查、special、peer、四ZIP审查均退出0。封装器首测将已统计整数字段当列表读取，实际TypeError/exit1发生在创建package之前；原脚本和物理stdout/stderr保留于package-first-failure，修正只改取值形状，不改测试/数据/验收阈值。另先前inline探读同类错误只有工具返回输出，不冒称存在独立原stdout文件。四大ZIP不重复收入本审查包。
