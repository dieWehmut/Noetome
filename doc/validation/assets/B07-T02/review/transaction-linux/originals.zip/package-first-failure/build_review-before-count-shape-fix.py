"""Package already completed independent transaction reviews, without product execution."""
from pathlib import Path
import argparse
import binascii
import hashlib
import json
import os
import stat
import zipfile

REPO = Path('/home/lyinn/project/Noetome')


def capture(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, str(path)
    with path.open('rb') as stream:
        held = os.fstat(stream.fileno())
        raw = stream.read()
        held_after = os.fstat(stream.fileno())
    after = path.lstat()
    ident = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_nlink)
    assert ident(before) == ident(held) == ident(held_after) == ident(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'nlink': before.st_nlink}


def save(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with path.open('xb') as stream:
        stream.write(raw)


def main(kind):
    if kind == 'behavior':
        source = REPO / '.artifacts/b07-t02-independent-linux-transaction-current-review-20261107'
        output = REPO / '.artifacts/b07-t02-independent-linux-transaction-current-package-20261107'
        main = json.loads(capture(source / 'actual.json')[0])
        special = json.loads(capture(source / 'special-pair-and-source-readback02.json')[0])
        peer = json.loads(capture(source / 'peer-archive-readback.json')[0])
        assert main['successful_group_count'] == 62 and main['successful_flow_SQL_event_count'] == 511 and main['actual_HTTP_in_successful_flows'] == 70
        assert len(main['strict_valid_budget_flow_groups']) == 39 and len(main['protection_refusal_groups']) == 23 and len(main['commands']) == 397
        assert special['status'] == peer['status'] == 'passed' and peer['total_CRC_SHA_length_members'] == 3790
        assert len(special['all_current_130_compiled_source_files_byte_equal']) == 130
        matrix = REPO / '.artifacts/b07-t02-request-linux-transaction-full-01-20261107'
        pair = REPO / '.artifacts/b07-t02-linux-transaction-pair-01-20261107'
        extra = [('matrix/actual.json', matrix / 'actual.json'), ('matrix/source-build-binding.json', matrix / 'source-build-binding.json')]
        extra += [('build/' + name, pair / name) for name in ['actual.json', 'source-before.json', 'source-after.json', 'source-originals.zip']]
        archive_review = REPO / '.artifacts/b07-t02-linux-transaction-public-delta-readback-20261107'
        archive_actual = json.loads(capture(archive_review / 'actual.json')[0])
        assert archive_actual['status'] == 'passed' and archive_actual['total_full_CRC_SHA_length_members'] == 15242
        extra += [('public-archives-review/' + path.name, path) for path in sorted(archive_review.iterdir()) if path.is_file()]
        references = [pair / 'noetome', pair / 'request-test-driver',
                      REPO / 'doc/validation/assets/B07-T02/programs-transaction/linux-transaction-pair-01-noetome.zip',
                      REPO / 'doc/validation/assets/B07-T02/programs-transaction/linux-transaction-pair-01-request-test-driver.zip',
                      REPO / 'doc/validation/assets/B07-T02/linux-run-transaction/originals.zip']
        references += [REPO / 'doc/validation/assets/B07-T02/diagnostic-transaction/originals.zip',
                       REPO / 'doc/validation/assets/B07-T02/linux-python-transaction/originals.zip']
        scope = 'Independent current Linux transaction full01 review:62 actual groups,364 ordinary CLI+33 driver=397 actual PIDs,70 original HTTP and23 SIGKILL(-9)/wait.39 valid budget flows contain511 events;23 protection/refusal groups are not adopted as valid ledgers. Current FP288fa7 source8e4d/f765 and checker3b/test428. Accepted/retry/elapsed cases require actual B succeeded before kill and retain original B key/receipt/files with no extra B HTTP. Full130 compiler source and both original ELF bodies were independently read; ELF bodies and main matrix original ZIP are referenced separately, not duplicated in this review ZIP. No product, HTTP, Cargo or Native execution by reviewer; current Native acceptance is not claimed.'
        readme = '本包保存当前 Linux transaction 实际原件独审和执行脚本。主审查、special-pair-and-source-readback02.json 与 peer-archive-readback.json 是三项独立读回结果；matrix/actual.json 是执行者原始运行结果。62 组包含 39 有效账本流与 23 拒绝保护组，后者不能当作有效账本重建。397 个真实 PID、70 份服务接受/响应原件、23 个 SIGKILL(-9) 和 wait 均按新运行重读。\n\naccepted 原10链中 B 已 succeeded 且 Known700，再释放 A，服务实际接受后终止 A；恢复仍 Unknown8310，B 无额外 HTTP。130 个实际编译源与两完整 ELF 绑定当前 FP288fa7；大程序本体保留在 programs-transaction 两包，本包仅保留引用及源 ZIP。peer3790 = 3789 普通原件 + 1 生成引用；1e6b 独立生成器事前已保存，引用2439B完整重建相等。旧release与Native失败事实仍保留，不计为当前Native通过。\n'
        readme += '\npublic-archives-review 保存四个新ZIP的独立完整读回：52+2+2+15186=15242成员、普通原件身份/mtime/bytes前后及每成员CRC/SHA/长度全等；一个链接仅核元数据不读目标。Python原始raw为466=444通过+22跳过，2056源与2058含两程序别名快照分别核对。本轮审查脚本均实际退出0，没有未保存的本轮失败；旧历史collector/static失败仍在既有历史原件，不改写旧包。四大ZIP不重复收入本审查包。\n'
        counts = {'groups': 62, 'ordinary_CLI': 364, 'driver': 33, 'actual_PID': 397, 'actual_HTTP': 70,
                  'SIGKILL_wait': 23, 'valid_budget_flow_groups': 39, 'protection_refusal_groups': 23,
                  'valid_flow_SQL_events': 511, 'peer_archive_members': 3790}
        counts.update({'new_public_archives': 4, 'new_public_archive_members': 15242,
                       'Python_run': 466, 'Python_pass': 444, 'Python_skip': 22})
    else:
        source = REPO / '.artifacts/b07-t02-linux-transaction-public-delta-readback-20261107'
        output = REPO / '.artifacts/b07-t02-linux-transaction-public-delta-review-package-20261107'
        actual = json.loads(capture(source / 'actual.json')[0])
        assert actual['status'] == 'passed' and actual['total_new_archives'] == 4 and actual['total_full_CRC_SHA_length_members'] == 15242
        extra = []
        references = [REPO / 'doc/validation/assets/B07-T02/diagnostic-transaction/originals.zip',
                      REPO / 'doc/validation/assets/B07-T02/programs-transaction/linux-transaction-pair-01-noetome.zip',
                      REPO / 'doc/validation/assets/B07-T02/programs-transaction/linux-transaction-pair-01-request-test-driver.zip',
                      REPO / 'doc/validation/assets/B07-T02/linux-python-transaction/originals.zip']
        scope = 'Independent readback of four current transaction public archives,52+2+2+15186=15242 full CRC/SHA/length members.Original ordinary file identity/mtime/bytes before/after verified. One metadata-only symlink target is not read. Current Linux full Python466=444pass22skip actual raw and current FP288fa7 selected CLI original guards/source2056+twoaliases2058 verified. These four archives are referenced, not duplicated here. No product HTTP/Cargo/Native execution by reviewer.'
        readme = '本包保存四个当前 Linux transaction 公开归档的独立读回程序、完整 actual 和原 stdout/stderr。52+2+2+15186=15242 个成员已实读 CRC/SHA/长度并与普通原件 FileID、mtime、bytes 前后核对。唯一链接只核元数据，不读其目标。Python 原始 stderr 证实 466=444通过+22跳过；源根2056与快照2058的两个明确程序别名分别处理，两完整 ELF 和当前FP288fa7绑定已实读。原四ZIP保留在公开独立位置，本审查包仅引用其实际pin，不重复大本体。Native回归和Native实际矩阵不由本包推定。\n'
        counts = {'archives': 4, 'CRC_SHA_length_members': 15242, 'metadata_only_links': 1,
                  'Python_run': 466, 'Python_pass': 444, 'Python_skip': 22}
    assert not output.exists(), 'new package only'
    output.mkdir()
    (output / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
    refs = [{'path': str(path), 'pin': capture(path)[1], 'included_as_body_in_this_review_ZIP': False} for path in references]
    save(output / 'referenced-originals.json', {'scope': scope, 'files': refs})
    pairs = [('review/' + path.name, path) for path in sorted(source.iterdir()) if path.is_file()]
    pairs += extra
    pairs += [('README.md', output / 'README.md'), ('referenced-originals.json', output / 'referenced-originals.json'),
              ('builder/build_review.py', Path(__file__).absolute())]
    assert len({name for name, path in pairs}) == len(pairs)
    before = [{'member': name, 'original': str(path), 'pin': capture(path)[1]} for name, path in pairs]
    with zipfile.ZipFile(output / 'originals.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for entry in before:
            raw, pin = capture(Path(entry['original']))
            assert pin == entry['pin']
            archive.writestr(entry['member'], raw)
    with zipfile.ZipFile(output / 'originals.zip') as archive:
        assert len(archive.namelist()) == len(before) == len(set(archive.namelist()))
        for entry in before:
            raw = archive.read(entry['member'])
            original, pin = capture(Path(entry['original']))
            assert pin == entry['pin'] and raw == original
            assert binascii.crc32(raw) & 0xffffffff == archive.getinfo(entry['member']).CRC
    assert refs == [{'path': str(path), 'pin': capture(path)[1], 'included_as_body_in_this_review_ZIP': False} for path in references]
    save(output / 'manifest.json', {'producer': 'independent_review_original_package', 'members': before,
                                  'member_count': len(before), 'counts': counts, 'scope': scope})
    save(output / 'actual.json', {'status': 'passed', 'kind': kind, 'members': len(before), 'counts': counts,
                                'all_CRC_SHA_length_readback': True, 'all_original_identity_mtime_bytes_before_after_equal': True,
                                'ZIP': capture(output / 'originals.zip')[1], 'manifest': capture(output / 'manifest.json')[1],
                                'large_original_bodies_not_duplicated': refs, 'scope': scope})
    print(json.dumps({'status': 'passed', 'kind': kind, 'members': len(before),
                      'ZIP': capture(output / 'originals.zip')[1], 'manifest': capture(output / 'manifest.json')[1],
                      'actual': capture(output / 'actual.json')[1], 'counts': counts}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=['behavior', 'archives'], required=True)
    main(parser.parse_args().kind)
