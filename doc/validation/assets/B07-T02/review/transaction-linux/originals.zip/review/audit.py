"""Independent read-only audit of actual current Linux release-full02 originals.

No product invocation, HTTP, source writes, or SQLite mutation.
The existing frozen checker is reused only for read-only parsing/reconstruction;
this collector separately checks command raw files, original inventory, event
hashes, server incoming bytes, kill timelines, budget arithmetic and source ZIP.
"""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import sqlite3
import stat
import sys
import traceback
import zipfile
sys.dont_write_bytecode = True

REPO = Path('/home/lyinn/project/Noetome')
ROOT = REPO / '.artifacts/b07-t02-request-linux-transaction-full-01-20261107'
OUT = Path(__file__).parent
FIXTURE = REPO / 'fixtures/run-api-budget-v1'
FP = '288fa7c28897954aebe42ebbd82d328f1c72a47f7d39cd867638aa91f77ac76f'
errors = []
pins = {}

def sha(b): return hashlib.sha256(b).hexdigest()
def require(v, text):
    if not v: raise AssertionError(text)

def raw(path):
    path = Path(path)
    s = path.lstat()
    require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, 'ordinary single-link original: '+str(path))
    b = path.read_bytes()
    t = path.lstat()
    p = {'sha256':sha(b), 'byte_length':len(b), 'device':s.st_dev, 'inode':s.st_ino, 'mtime_ns':s.st_mtime_ns}
    require((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns), 'original changed while reading')
    old=pins.setdefault(str(path),p)
    require(old==p,'original changed during audit '+str(path))
    return b

def js(path): return json.loads(raw(path))
def inventory(root):
    result={}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs+files:
            p=Path(parent)/name;s=p.lstat()
            require(not stat.S_ISLNK(s.st_mode),'no symlink descent '+str(p))
            result[str(p.relative_to(root))]={'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':s.st_mode,'byte_length':s.st_size}
            if stat.S_ISREG(s.st_mode):
                b=raw(p);result[str(p.relative_to(root))]['sha256']=sha(b)
    return result

result={'producer':'independent_request_budget_original_audit','status':'running','scope':'current Linux transaction full01 actual HTTP, source-bound releasepair01, checker3b263 and Run8e4d/Storef765, original ledger/budgets/real kills/protection; native and full regression remain separate','product_invocations':0,'HTTP_requests_generated_by_auditor':0}
try:
    before=inventory(ROOT)
    actual=js(ROOT/'actual.json')
    require(sha(raw(ROOT/'actual.json'))=='fb5ff2b0db73a55053645f8afb3ce6d883459f51f4766e0066d7209c1f2c8f2e','exact current transaction full01 actual anchor')
    binding=js(ROOT/'source-build-binding.json')
    result['original_actual_pin']=pins[str(ROOT/'actual.json')]
    require(actual['status']=='passed' and actual['failure'] is None,'actual current transaction full01 passed receipt')
    for prefix in ['author','checker']:
        require(js(ROOT/(prefix+'-source-before.json'))==js(ROOT/(prefix+'-source-after.json')),prefix+' actual before/after pins')
    # The full06 freeze contains the three actual selected checker files.
    # Their unchanged T01 transitive compile-check helpers are explicitly pinned
    # from current repository source, separately from frozen full02 checker pins.
    sys.path.insert(0,str(REPO/'scripts'))
    sys.path.insert(0,str(ROOT/'checker-source'))
    for name in ['verify_fixture_compile.py']:
        raw(REPO/'scripts'/name)
    spec=importlib.util.spec_from_file_location('frozen_budget_audit', ROOT/'checker-source/verify_request_budget.py')
    checker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=checker;spec.loader.exec_module(checker)
    author=checker.author_check(FIXTURE)
    author_cases={c['case_id']:c for c in author['cases']}
    result['frozen_author_manifest']=dict(pins.setdefault(str(FIXTURE/'frozen-sha256.json'),{})) if str(FIXTURE/'frozen-sha256.json') in pins else {'sha256':sha(raw(FIXTURE/'frozen-sha256.json'))}
    copied_checker={}
    for source,pin in js(ROOT/'checker-source-before.json').items():
        p=ROOT/'checker-source'/Path(source).name;b=raw(p)
        require(sha(b)==pin['sha256'] and len(b)==pin['byte_length'],'frozen checker copy matches actual source-before')
        copied_checker[str(p)]=pins[str(p)]
    result['frozen_checker_copies']=copied_checker
    archive=Path(binding['source_archive']);ab=raw(archive)
    require(sha(ab)==binding['receipt_original']['source_archive']['sha256'],'actual compiled source ZIP binding')
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None,'full compiled source ZIP CRC')
        require(len(z.infolist())==len(binding['source_members'])==130,'130 original compiled source members')
        for name,pin in binding['source_members'].items():
            b=z.read(name);require(sha(b)==pin['sha256'] and len(b)==pin['byte_length'],'compiled source member SHA '+name)
    result['compiled_source_archive']={'path':str(archive),'pin':pins[str(archive)],'members':130,'all_CRC_SHA_length_passed':True,'current_source_equality_not_claimed':True}
    commands=[];kills=[];traces=[]
    for c in actual['commands']:
        cr=ROOT/'commands'/f"{c['number']:04d}"
        r=js(cr/'receipt.json');launch=js(cr/'launch.json')
        require(r==c,'physical command receipt equals actual row')
        for k,v in launch.items(): require(c[k]==v,'launch prefix actual exact '+k)
        for stream in ['stdout','stderr']:
            b=raw(cr/(stream+'.bin'));require(sha(b)==c[stream]['sha256'] and len(b)==c[stream]['byte_length'],'raw command stream exact')
        require(c['started_utc_ns']<=c['finished_utc_ns'] and c['started_monotonic_ns']<=c['finished_monotonic_ns'],'actual command/wait order')
        require(c['credential_value_omitted'] and 'NOETOME_TEST_CREDENTIAL' in c['fake_environment_keys'],'synthetic env selected without credential disclosure')
        rows=[]
        for line in raw(cr/'stdout.bin').decode('utf8',errors='strict').splitlines():
            try: v=json.loads(line)
            except ValueError: continue
            if isinstance(v,dict) and v.get('producer')=='request_run_checkpoint_test_handshake':
                require(v['pid']==c['PID'] and v['compiler_fingerprint']==FP,'actual trace PID/compiled FP')
                rows.append(v)
        if rows: traces.append({'number':c['number'],'PID':c['PID'],'selection':c.get('explicit_request_test_selection'),'trace':rows})
        summary={'number':c['number'],'PID':c['PID'],'kind':c['command_kind'],'label':c['label'],'exit_code':c['exit_code'],'wait_action':c['wait_action'],'stdout_pin':c['stdout'],'stderr_pin':c['stderr']}
        commands.append(summary)
        if c['wait_action']=='actual_OS_force_kill_and_wait':
            require(c['exit_code']==-9 and c['started_utc_ns']<=c['kill_requested_utc_ns']<=c['finished_utc_ns'],'own PID SIGKILL then waited exit -9')
            require(c['command_kind']=='explicit_test_driver','kill actual driver only')
            kills.append({**summary,'kill_requested_utc_ns':c['kill_requested_utc_ns'],'finished_utc_ns':c['finished_utc_ns'],'selection':c['explicit_request_test_selection'],'actual_traces':rows})
    kinds=dict(collections.Counter(x['kind'] for x in commands))
    require(kinds=={'ordinary_cli':364,'explicit_test_driver':33} and len(kills)==23,'independent physical command/kill counts')
    result['commands']={'counts':kinds,'actual_OS_kill_and_wait_count':len(kills),'physical_raw_and_receipts_checked':len(commands),'records':commands,'kills':kills,'traces':traces}
    cases=[];all_http=0;all_rows=0
    selected_groups=actual['cases']
    require(len(selected_groups)==62 and all(g['status']=='passed' for g in selected_groups),'actual 62 groups success')
    for g in selected_groups:
        name=g['case_id'];case=ROOT/name
        if name.startswith('protection-') and name!='protection-actual-live-worker':
            audit=js(case/'independent-audit.json')
            pre=audit.get('after_deliberate_mutation_before_commands',audit.get('after_deliberate_attack_before_commands'))
            invalidated_names={'protection-API-mtime','protection-API-new-identity','protection-Run-config-mtime','protection-source-original-mutation'}
            typed_invalidation=pre!=audit['after_commands']
            require(not typed_invalidation or name in invalidated_names,'only typed input invalidation may append budget events')
            if typed_invalidation:
                require(all(pre[k]==audit['after_commands'][k] for k in ['runs','sources','configs']),'input invalidation preserves selected source/config/Run originals')
            observed={'budget':checker.paths.inventory(case/'budget'),'runs':{p.name:checker.paths.inventory(p) for p in case.iterdir() if p.is_dir() and p.name.startswith('run-')},'sources':{str(p):checker.paths.inventory(p) for p in (case/'sources').iterdir() if p.is_dir()},'configs':{p:checker.observed_stamp(Path(p))[0] for p in pre['configs']}}
            require(observed==audit['after_commands'],'independent live readback equals actual post-refusal inventory')
            pcs=[c for c in actual['commands'] if str(case/'budget') in c['argv'] and c['argv'][1:4] in [['run','api','status'],['run','api','resume']]]
            require(pcs and all(c['exit_code']==3 for c in pcs),'actual ordinary CLI guards refused with exit3')
            sr=js(case/'server/server-receipts.json');receipts=sr['receipts']
            require(sr['observed_HTTP_request_count']==len(receipts)==g.get('actual_HTTP_requests',0),'protection actual original HTTP count')
            for incoming in sr['incoming']:
                b=raw(case/'server'/incoming['request_body_file']);require(sha(b)==incoming['request_body_sha256'] and len(b)==incoming['request_body_byte_length'],'protected original server incoming bytes')
            for receipt in receipts:
                req=raw(case/'server'/receipt['request_body_file']);require(sha(req)==receipt['request_body_sha256'],'protected actual request original')
                checker.request_body_check(req,FIXTURE)
                if 'response_file' in receipt:
                    resp=raw(case/'server'/receipt['response_file']);require(sha(resp)==receipt['response_sha256'] and len(resp)==receipt['response_byte_length'],'protected actual response original')
                    usage=json.loads(resp)['usage'];require(usage['input_tokens']==100 and usage['output_tokens']==600 and usage['total_tokens']==700,'actual remote usage preserved despite coordinated forged local report')
            all_http+=len(receipts)
            rejected=None;retained_invalidation=None
            try:
                pl,pe=checker.read_authority(case/'budget',fixture=FIXTURE,authority_config=case/'authority-config.json',expected_fingerprint=FP,selected_run_roots=[case/'run-main'])
                if typed_invalidation:
                    original=audit['original_ledger'];require(pl.rows[original['sequence']-1]['sequence']==original['sequence'],'original confirmed prefix length')
                    require(sha(json.dumps(pl.rows[original['sequence']-1],ensure_ascii=False,separators=(',',':')).encode())==original['last_sha256'],'original exact persisted prefix digest')
                    require(not pl.attempts and pl.totals()==original['totals'] and all(r['outcome']=='invalidated' for r in pl.runs.values()),'typed retained invalidation no requests no balances reset')
                    require(all(r['event']['kind']=='run_invalidated' for r in pl.rows[original['sequence']:]),'only typed invalidation appended')
                    retained_invalidation={'original_prefix_sequence':original['sequence'],'original_prefix_sha256':original['last_sha256'],'post_sequence':pl.sequence,'post_totals':pl.totals(),'events_appended':[r['event'] for r in pl.rows[original['sequence']:]]}
            except Exception as e:
                rejected=str(e)
            # Wrong selected CLI argument is external to otherwise valid ledger;
            # changed input may have explicit retained invalidated state. These
            # are command-level refusal checks, not blanket corrupt-DB tests.
            require(rejected is not None or name=='protection-wrong-config-path' or retained_invalidation is not None,'independent corrupt source/artifact rejected or explicit typed invalidation')
            cases.append({'case_id':name,'actual_readonly_rejection':rejected,'retained_typed_invalidation':retained_invalidation,'actual_refusal_commands':[{'PID':c['PID'],'label':c['label'],'exit_code':c['exit_code']} for c in pcs],'HTTP_receipts':receipts,'actual_post_inventory_independently_readback':True,'Run_source_config_originals_preserved':True})
            continue
        approved=[p for p in case.iterdir() if p.is_dir() and p.name.startswith('run-')]
        ledger,evidence=checker.read_authority(case/'budget',fixture=FIXTURE,authority_config=case/'authority-config.json',expected_fingerprint=FP,selected_run_roots=approved)
        sr=js(case/'server/server-receipts.json');receipts=sr['receipts']
        traffic=checker.verify_server_receipts(ledger,receipts,case/'server')
        require(sr['observed_HTTP_request_count']==len(receipts),'actual HTTP count from real server originals')
        for incoming in sr['incoming']:
            if incoming.get('body_complete'):
                b=raw(case/'server'/incoming['request_body_file'])
                require(sha(b)==incoming['request_body_sha256'] and len(b)==incoming['request_body_byte_length'],'original incoming bytes')
        sums=dict(ledger.authority['opening']);attempts=[];retries=[]
        for key,a in ledger.attempts.items():
            state=a['state'];R=a['plan']['request_body']['byte_length']+1024+a['plan']['max_output_tokens']
            require(R==a['plan']['reserved_tokens']==8310,'original-byte R=5238+1024+2048')
            if state=='known': sums['accounted_tokens']+=a['receipt']['usage']['total_tokens'];sums['dispatched_requests']+=1
            elif state in ['may_send','unknown']: sums['held_tokens']+=R;sums['dispatched_requests']+=1
            elif state=='reserved': sums['held_tokens']+=R;sums['held_requests']+=1
            detail={'key':list(key),'state':state,'reserved_tokens':R,'receipt':a.get('receipt'),'retry':a.get('retry')}
            attempts.append(detail)
        require(sums==ledger.totals(),'separate scalar sums from full event replay')
        # Raw SQL hashes and physical full payload chain independently checked.
        with sqlite3.connect((case/'budget/control/budget.sqlite').resolve().as_uri()+'?mode=ro&immutable=1',uri=True) as conn:
            sqlrows=conn.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence').fetchall()
        prev='0'*64
        for seq,ps,payload,digest in sqlrows:
            v=json.loads(payload);require(ps==prev and sha(payload.encode())==digest and v['sequence']==seq and v['previous_sha256']==ps,'independent original SQL payload hash chain')
            prev=digest
        for row in ledger.rows:
            ev=row['event']
            if ev['kind']=='retry_scheduled':
                key=checker.validate_key(ev['key']);run=ledger.runs[key[0]];schedule=ev.get('schedule',ev)
                delay=min(run['spec']['retry_base_delay_ms']*2**(key[2]-1),run['spec']['retry_max_delay_ms'])
                retry_ns=checker.utc_ns(schedule['retry_at_utc']);at_ns=checker.utc_ns(row['at_utc'])
                require(retry_ns-at_ns==delay*1000000,'exact durable exponential backoff original schedule')
                prior=ledger.attempts[key]
                if schedule['error_code']=='REQUEST_INTERRUPTED':
                    require(prior['receipt'] is None and prior['state']=='unknown','explicit interrupted unknown no receipt')
                else:
                    rc=prior['receipt'];require(rc is not None and rc['usage'] is None and not(rc['response_complete'] and rc['http_status']==200),'no Known/full200 ordinary retry')
                next_starts=[checker.utc_ns(r['at_utc']) for r in ledger.rows if r['event']['kind']=='may_send' and r['event']['key']['run_id']==key[0] and r['event']['key']['unit_id']==key[1] and r['event']['key']['attempt_no']==key[2]+1]
                require(all(t>=retry_ns for t in next_starts),'persisted original retry cannot dispatch early after restart')
                retries.append({'key':list(key),'raw_event':ev,'at_utc':row['at_utc'],'actual_backoff_ms':delay,'next_dispatch_after_durable_retry_ms':[(t-retry_ns)/1000000 for t in next_starts]})
            elif ev['kind']=='may_send':
                key=checker.validate_key(ev['key']);run=ledger.runs[key[0]];unit=run['units'][key[1]]
                require(checker.utc_ns(row['at_utc'])<min(checker.utc_ns(run['spec']['deadline_utc']),checker.utc_ns(unit['spec']['deadline_utc'])),'every actual dispatch bounded by original Run/unit deadline')
        require(traffic['observed_HTTP_requests']==g.get('actual_HTTP_requests',traffic['observed_HTTP_requests']),'actual case HTTP count')
        all_http+=len(receipts);all_rows+=len(sqlrows)
        if name in author_cases: checker.case_expected_check(author_cases[name],ledger,traffic)
        item={'case_id':name,'events':len(sqlrows),'last_sha256':prev,'event_counts':dict(collections.Counter(r['event']['kind'] for r in ledger.rows)),'independent_scalar_totals':sums,'run_totals':{k:ledger.totals(k) for k in ledger.runs},'HTTP_receipts':receipts,'traffic':traffic,'attempts':attempts,'retries':retries,'original_inputs':evidence['input_checks'],'selected_run_roots':[str(p) for p in approved]}
        if name=='same-response-sha-different-attempts':
            known=[a for a in ledger.attempts.values() if a['state']=='known'];resp=[r['response_sha256'] for r in receipts]
            require(len(known)==2 and len(set(resp))==1 and sums['accounted_tokens']==1400 and len({r['request_id'] for r in receipts})==2,'same SHA two unique actual requests each 700')
        if name.startswith('reserved-expired'):
            require(not receipts and sums['held_tokens']==sums['held_requests']==0 and all(a['state']=='not_sent' for a in ledger.attempts.values()),'expired pre-MaySend release actual NotSent zeroHTTP')
        if name.endswith('--actual-worker-observe'):
            ctr=[t for t in traces if any(x['root'] in {str(p) for p in approved} for x in t['trace'])]
            threads={x['thread_id'] for t in ctr for x in t['trace'] if x['unit']}
            require(len(threads)>=2 or len(ctr)>=2,'real worker trace evidence')
            require(all(not x['will_wait'] for t in ctr for x in t['trace']),'observe concurrent scheduling has no input handshake')
            require(len(receipts)==1,'parallel nearcap only one HTTP permitted')
            item['actual_worker_observe']={'PIDs':[t['PID'] for t in ctr],'Rust_ThreadIds':sorted(threads),'ThreadIds_are_not_OS_thread_IDs':True,'all_trace_nonblocking':True}
        cases.append(item)
    result['audited_final_groups']=cases
    result['successful_group_count']=len(cases)
    result['strict_valid_budget_flow_groups']=sum('events' in c for c in cases)
    result['protection_refusal_groups']=sum('events' not in c for c in cases)
    require(result['strict_valid_budget_flow_groups']==39 and result['protection_refusal_groups']==23,'strict39 valid flows separately from23 protection/refusal attack groups')
    result['successful_flow_SQL_event_count']=all_rows
    result['actual_HTTP_in_successful_flows']=all_http
    require(all_http==70,'independent actual server total includes all protection originals')
    result['frozen_core_case_expected_checks']=14
    mirror=ROOT/'protection-compiler-mirror'
    owner=js(mirror/'budget/control/owner.json');runowner=js(mirror/'run-main/control/owner.json')
    require(owner['compiler_fingerprint']!=FP and runowner['compiler_fingerprint']==FP,'real unknown budget compiler mirror preserves original Run compiler')
    mirror_commands=[c for c in actual['commands'] if str(mirror/'budget') in c['argv']]
    badstatus=[c for c in mirror_commands if c['argv'][1:4]==['run','api','status']]
    require(len(badstatus)==1 and badstatus[0]['exit_code']==3,'actual new status refuses unknown mirrored compiler')
    result['compiler_mirror_RED_to_GREEN']={'case_id':'protection-compiler-mirror','ordinary_status_PID':badstatus[0]['PID'],'ordinary_status_exit':3,'budget_compiler_fingerprint':owner['compiler_fingerprint'],'unchanged_run_fingerprint':runowner['compiler_fingerprint'],'current_transaction_pair_real_source_binding':True,'historical_debug_full02_remains_failed':True}
    after=inventory(ROOT);require(before==after,'all historical root original identity/mtime/length/SHA preserved')
    result['full_original_inventory']={'file_count':sum('sha256' in p for p in before.values()),'entry_count':len(before),'before_after_equal':True,'before':before,'after':after}
    result['status']='passed_independent_current_Linux_transaction_original_behavior_audit'
except Exception as e:
    result['status']='audit_failed';result['failure']={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
    traceback.print_exc()
finally:
    result['all_read_original_pins']=pins
    (OUT/'actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:result[k] for k in ['status','scope','successful_group_count','successful_flow_SQL_event_count','actual_HTTP_in_successful_flows','failure'] if k in result},ensure_ascii=False))
    if result['status']=='audit_failed': sys.exit(1)
