"""Execute only Root-authorized readonly release08 preflight, saved before launch."""
from pathlib import Path
import ast
import hashlib
import json
import os
import signal
import stat
import subprocess
import sys
import time

sys.dont_write_bytecode = True
REPO = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).resolve().parent
DRAFT = REPO / '.artifacts/b07-t02-native-release08-independent-preflight-draft-20261107'
ANCHORS = {
    'fp': 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12',
    'cli-sha256': 'f6778071e8533819660e783a814b76d0d39a3b77ea254ddd0b66a65ad993adbc',
    'cli-bytes': 16480256,
    'driver-sha256': '68b890af5cfbc2d3c820365877e4c77822b687b3eeb21dec1b925c546ae86089',
    'driver-bytes': 22996480,
    'snapshot-sha256': 'ca280811c714992a51be9a25d4ad580c428375a9dde1681b617ebb56cae64814',
    'snapshot-bytes': 629328,
    'source-zip-sha256': 'b4f573f943927aa51ea63ae2981dfe1d0295f8841cf4d47c18809fdfd6fc6479',
    'source-zip-bytes': 8239314,
}
SOURCE_PINS = {
    'readback.py': ('4cea0428586e642b68d35519f37ccf4526fe512dd2084bc8c557f1a5f6c43a9c', 15150),
    'runtime-cache-supplement.py': ('d1826057dfec4444882b6ddc6ea853311e25a13c59c9482116090167010b2ace', 5191),
}
GUARDS = {}

def metadata(s):
    return dict(device=s.st_dev, inode=s.st_ino, mode=s.st_mode, nlink=s.st_nlink,
                byte_length=s.st_size, mtime_ns=s.st_mtime_ns, ctime_ns=s.st_ctime_ns)

def read(path):
    path = Path(path)
    for p in (path, *path.parents):
        if p.is_symlink():
            raise AssertionError(f'linked selected component: {p}')
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    with path.open('rb') as f:
        assert metadata(before) == metadata(os.fstat(f.fileno()))
        b = f.read()
        assert metadata(before) == metadata(os.fstat(f.fileno())) == metadata(path.lstat())
    pin = {**metadata(before), 'sha256': hashlib.sha256(b).hexdigest()}
    assert len(b) == pin['byte_length']
    assert GUARDS.setdefault(str(path), pin) == pin
    return b

def save(name, value):
    p = OUT / name
    with p.open('x', encoding='utf-8') as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

read(Path(__file__).resolve())
save('external-root-anchors.json', {'explicit_Root_GO': 'All release08 build/probe/outer PIDs closed0; authorize only readonly Native Python metadata preflight.',
                                   'anchors': ANCHORS, 'current_Run_Store': 'e4/c87',
                                   'full807_fullPython527_Windows62': 'not_run',
                                   'no_old_FP_default': True})
for name, (sha, size) in SOURCE_PINS.items():
    b = read(DRAFT / name)
    assert hashlib.sha256(b).hexdigest() == sha and len(b) == size
    ast.parse(b)
    with (OUT / name).open('xb') as f:
        f.write(b)
        f.flush()
        os.fsync(f.fileno())
    assert read(OUT / name) == b
save('selected-script-originals-before.json', GUARDS)

env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
commands = []
started = time.time_ns()
for name, script in [('preflight', 'readback.py'), ('runtime-cache', 'runtime-cache-supplement.py')]:
    argv = [sys.executable, '-B', str(OUT / script)]
    if name == 'preflight':
        for key, value in ANCHORS.items():
            argv.extend(['--expected-' + key, str(value)])
    start = time.time_ns()
    stdout_path, stderr_path = OUT / (name + '.stdout.bin'), OUT / (name + '.stderr.bin')
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        p = subprocess.Popen(argv, cwd=REPO, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        save(name + '-launch.json', {'argv': argv, 'PID': p.pid, 'parent_PID': os.getpid(), 'started_ns': start,
                                    'read_only_Native_metadata_only': True})
        print(json.dumps({'phase': name, 'actual_PID': p.pid, 'started_ns': start}), flush=True)
        timed_out = False
        try:
            code = p.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(p.pid, signal.SIGKILL)
            code = p.wait()
        stdout.flush(); stderr.flush()
        os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
    row = {'name': name, 'argv': argv, 'PID': p.pid, 'exit_code': code, 'actual_wait_closed': p.poll() is not None,
           'started_ns': start, 'finished_ns': time.time_ns(), 'timed_out': timed_out,
           'stdout': {'path': str(stdout_path), 'pin': None}, 'stderr': {'path': str(stderr_path), 'pin': None}}
    for stream in ('stdout', 'stderr'):
        read(row[stream]['path']); row[stream]['pin'] = GUARDS[row[stream]['path']]
    commands.append(row)
    save(name + '-result.json', row)
    if code != 0:
        save('wrapper-failure.json', {'status': 'failed_actual_readonly_preflight', 'commands': commands,
                                    'original_failure_streams_preserved': True, 'anchors': ANCHORS,
                                    'product_Cargo_HTTP_calls': 0, 'new_Full807_Python527_Windows62': 'not_run'})
        raise SystemExit(code if code > 0 else 1)
    print(json.dumps({'phase': name, 'exit_code': code, 'actual_wait_closed': True}), flush=True)

for p in list(GUARDS):
    read(p)
save('selected-script-originals-after.json', GUARDS)
for name in ('actual.json', 'actual-native-metadata.json', 'runtime-cache-supplement.json', 'native-metadata.stdout.bin', 'native-metadata.stderr.bin'):
    read(OUT / name)
result = {'status': 'passed_independent_native_release08_readonly_preflight_all_processes_closed',
          'actual_wrapper_PID': os.getpid(), 'started_ns': started, 'finished_ns': time.time_ns(),
          'actual_commands': commands, 'external_nine_Root_anchors': ANCHORS,
          'original_and_copied_selected_scripts_actual_fstat_path_ID_mtime_bytes_before_after_equal': True,
          'all_guarded_input_output_pins': GUARDS,
          'actual_native_metadata_subprocess_returned_exit0': True,
          'readonly_Metadata_Native_process_only_product_Cargo_HTTP_zero': True,
          'fullNativeRust807_fullPython527_Windows62': 'not_run'}
save('wrapper-actual.json', result)
print(json.dumps({'status': result['status'], 'actual_wrapper_PID': os.getpid(), 'commands': len(commands),
                  'finished_ns': result['finished_ns']}), flush=True)
