from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import zipfile

ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
REVIEW = ROOT / '.artifacts/b07-t02-checked-budget-source-independent-review-20261107'
TEST = ROOT / '.artifacts/transaction-guards-01'
PUBLIC = ROOT / 'doc/validation/assets/B07-T02/review/transaction-source'


def observed(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, str(path)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        body = stream.read()
        end = os.fstat(stream.fileno())
    after = path.lstat()
    attrs = ('st_dev', 'st_ino', 'st_mtime_ns', 'st_ctime_ns', 'st_size', 'st_mode', 'st_nlink')
    assert all(getattr(before, x) == getattr(opened, x) == getattr(end, x) == getattr(after, x) for x in attrs), str(path)
    return body, {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body), 'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'ctime_ns': before.st_ctime_ns}


def write_new(path, body):
    with path.open('xb') as stream:
        stream.write(body)
        stream.flush()
        os.fsync(stream.fileno())


def json_new(path, data):
    write_new(path, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode())


actual = json.loads(observed(TEST / 'actual.json')[0])
launch = json.loads(observed(TEST / 'launch.json')[0])
stdout, stdout_pin = observed(TEST / 'stdout.bin')
stderr, stderr_pin = observed(TEST / 'stderr.bin')
for key in ('sha256', 'byte_length', 'device', 'inode', 'mtime_ns'):
    assert stdout_pin[key] == actual['stdout'][key] and stderr_pin[key] == actual['stderr'][key], key
assert actual['exit_code'] == 0 and actual['pid'] == launch['pid'] == 787189 and actual['argv'] == launch['argv']
rows = re.findall(r'^test request_budget_store::tests::([^\s]+) \.\.\. ok$', stdout.decode(), re.M)
assert len(rows) == len(set(rows)) == 32
summary = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s', stdout.decode())
assert len(summary) == 1 and summary[0][:5] == ('32', '0', '0', '0', '476')
source_before = json.loads(observed(TEST / 'source-before.json')[0])
source_after = json.loads(observed(TEST / 'source-after.json')[0])
assert source_before == source_after and len(source_before) == actual['source_count'] == 130
source_readback = {}
for name, expected in source_before.items():
    body, pin = observed(ROOT / name)
    for field in ('sha256', 'byte_length', 'device', 'inode', 'mtime_ns'):
        assert pin[field] == expected[field], (name, field)
    source_readback[name] = pin
assert source_readback['crates/noetome-cli/src/request_run.rs']['sha256'] == '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc'
assert source_readback['crates/noetome-cli/src/request_budget_store.rs']['sha256'] == 'f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349'
new_tests = sorted(name for name in rows if name.startswith('budget_checked_'))
assert len(new_tests) == 4
store = observed(REVIEW / 'current-request_budget_store.rs')[0].decode()
start = store.index('    #[test]\n    fn budget_checked_reserve_requires_the_original_prepared_plan()')
end = store.index('    #[test]\n    fn budget_prepared_denial_seals_originals_without_commitments()', start)
write_new(OUT / 'four-new-negative-test-definitions.rs', store[start:end].encode())
json_new(OUT / 'actual-module32-source-readback.json', {
    'status': 'passed', 'actual_process_PID': 787189, 'actual_exit': 0,
    'actual_Cargo_argv': actual['argv'], 'actual_total_elapsed_seconds': actual['elapsed_seconds'],
    'actual_tests': rows, 'new_checked_tests': new_tests, 'summary': {'passed': 32, 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered': 476, 'module_elapsed_seconds': float(summary[0][5])},
    'raw_stdout': stdout_pin, 'raw_stderr': stderr_pin,
    'complete_source130_actual_metadata_hash_before_after_and_current_equal': source_readback,
    'scope': 'Root really executed this Linux release budget module test. Independent reviewer only reread its saved raw/source; full Linux workspace, new Native793 and new62 behavior are not claimed here.'
})
reference = {}
for name in ('source-originals.zip', 'actual.json'):
    origin = ROOT / '.artifacts/b07-t02-linux-release-pair-01-20261107' / name
    _, pin = observed(origin)
    reference[name] = {'original_path': str(origin), 'actual_pin': pin, 'scope': 'Earlier old2e Linux release pair dependency/baseline evidence only, not current8e build or acceptance.'}
json_new(OUT / 'fixed-baseline-dependency-references.json', reference)
write_new(OUT / 'README.md', b'''# Fresh checked transaction source and real module32 evidence

Current request_run8e4d / request_budget_storef765 source changed two production files. The independent source review preserves exact original layout/header/sidecar/schema, full event chain and original API semantics, complete input SHA/identity/mtime/inventory, and actual fresh BEGIN IMMEDIATE -> full load+witness -> guard -> now -> decide -> COMMIT -> postlayout order. Deferred receipt uses the exact current full attempt key before terminal/retry decisions. No cross-transaction cache or removed safeguard is accepted.

Root actually executed the module command under Linux release: PID787189, exit0, total67.784169 seconds including compile; original stdout32passed/0failed/0ignored/476filtered, module1.45s. Four new checked gate tests passed and their literal definitions are included. Original source130 pins and actual before/after/current metadata+bytes were independently reread. These focused results are separate from the not-yet-run new Native793/full62/full Python gates.

Current/baseline selected source files and the independent review program are saved here. Earlier complete program and source ZIP bodies are only fixed references and are not duplicated or claimed current. The old source capture assertion was during coordinated Root edits; its copied current files/tool-only limitation is explicitly stated in the source review actual.json.

This collector performed only original readback and new evidence packaging; no product/Cargo/HTTP or production/private access. Its own live stdout/stderr are excluded from this package; no active output is treated as frozen original.
''')

selected = {('source-review/' + p.name): p for p in REVIEW.iterdir() if p.is_file()}
selected.update({('module32/' + name): TEST / name for name in ('actual.json', 'launch.json', 'source-before.json', 'source-after.json', 'stdout.bin', 'stderr.bin')})
selected.update({name: OUT / name for name in ('four-new-negative-test-definitions.rs', 'actual-module32-source-readback.json', 'fixed-baseline-dependency-references.json', 'README.md', 'collect.py')})
package = OUT / 'package'
package.mkdir(exist_ok=False)
manifest = {}
with zipfile.ZipFile(package / 'originals.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, original in sorted(selected.items()):
        body, pin = observed(original)
        archive.writestr(name, body)
        manifest[name] = {'original_path': str(original), 'original_pin': pin, 'sha256': pin['sha256'], 'byte_length': pin['byte_length']}
with zipfile.ZipFile(package / 'originals.zip') as archive:
    assert set(archive.namelist()) == set(manifest) and len(archive.infolist()) == len(manifest)
    for name, record in manifest.items():
        body, after_pin = observed(Path(record['original_path']))
        assert after_pin == record['original_pin'] and archive.read(name) == body
        record['full_CRC_SHA_length_actual_original_identity_mtime_bytes_equal'] = True
json_new(package / 'manifest.json', manifest)
archive_body, archive_pin = observed(package / 'originals.zip')
manifest_body, manifest_pin = observed(package / 'manifest.json')
json_new(package / 'actual.json', {'status': 'passed', 'members': len(manifest), 'archive': archive_pin, 'manifest': manifest_pin, 'actual_module_tests': 32, 'actual_module_PID': 787189, 'actual_source_files': 130, 'current_Run_SHA': source_readback['crates/noetome-cli/src/request_run.rs']['sha256'], 'current_Store_SHA': source_readback['crates/noetome-cli/src/request_budget_store.rs']['sha256'], 'reviewer_Cargo_HTTP_product_calls': 0, 'scope': 'Focused actual module32 + independent static current source review only; not new Native/full-matrix acceptance.'})
PUBLIC.mkdir(exist_ok=False)
copies = {}
for name in ('originals.zip', 'manifest.json', 'actual.json'):
    body, before_pin = observed(package / name)
    write_new(PUBLIC / name, body)
    copied, copied_pin = observed(PUBLIC / name)
    original_after, after_pin = observed(package / name)
    assert copied == body == original_after and before_pin == after_pin
    copies[name] = {'original_path': str(package / name), 'original_before': before_pin, 'original_after': after_pin, 'copy_path': str(PUBLIC / name), 'copy_pin': copied_pin, 'exact_byte_copy': True}
json_new(PUBLIC / 'copy-receipt.json', {'status': 'passed', 'members': len(manifest), 'copies': copies, 'all_members_original_ID_mtime_bytes_and_CRC_SHA_length_rechecked': True, 'scope': 'Current transaction source and actual module32 only. No old large program/sourceZIP bodies duplicated.'})
_, copy_pin = observed(PUBLIC / 'copy-receipt.json')
json_new(OUT / 'actual-public-copy.json', {'status': 'passed', 'archive': archive_pin, 'manifest': manifest_pin, 'copies': copies, 'copy_receipt': copy_pin, 'members': len(manifest)})
print(json.dumps({'status': 'passed', 'members': len(manifest), 'archive': archive_pin, 'manifest': manifest_pin, 'copy_receipt': copy_pin, 'public': str(PUBLIC)}, ensure_ascii=False))
