# Fresh checked transaction source and real module32 evidence

Current request_run8e4d / request_budget_storef765 source changed two production files. The independent source review preserves exact original layout/header/sidecar/schema, full event chain and original API semantics, complete input SHA/identity/mtime/inventory, and actual fresh BEGIN IMMEDIATE -> full load+witness -> guard -> now -> decide -> COMMIT -> postlayout order. Deferred receipt uses the exact current full attempt key before terminal/retry decisions. No cross-transaction cache or removed safeguard is accepted.

Root actually executed the module command under Linux release: PID787189, exit0, total67.784169 seconds including compile; original stdout32passed/0failed/0ignored/476filtered, module1.45s. Four new checked gate tests passed and their literal definitions are included. Original source130 pins and actual before/after/current metadata+bytes were independently reread. These focused results are separate from the not-yet-run new Native793/full62/full Python gates.

Current/baseline selected source files and the independent review program are saved here. Earlier complete program and source ZIP bodies are only fixed references and are not duplicated or claimed current. The old source capture assertion was during coordinated Root edits; its copied current files/tool-only limitation is explicitly stated in the source review actual.json.

This collector performed only original readback and new evidence packaging; no product/Cargo/HTTP or production/private access. Its own live stdout/stderr are excluded from this package; no active output is treated as frozen original.
