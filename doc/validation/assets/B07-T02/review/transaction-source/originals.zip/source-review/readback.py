from __future__ import annotations

import difflib
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
EXPECTED = {
    'crates/noetome-cli/src/request_run.rs': '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc',
    'crates/noetome-cli/src/request_budget_store.rs': 'f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349',
}


def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        body = stream.read()
        end = os.fstat(stream.fileno())
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mtime_ns', 'st_ctime_ns', 'st_size', 'st_mode', 'st_nlink')
    assert all(getattr(before, field) == getattr(opened, field) == getattr(end, field) == getattr(after, field) for field in fields)
    return body, {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body), 'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns}


old_source = ROOT / '.artifacts/b07-t02-linux-release-pair-01-20261107/source-originals.zip'
old_zip_bytes, old_zip_pin = read(old_source)
current = {}
before = {}
originals = {}
with zipfile.ZipFile(old_source) as archive:
    assert len(archive.infolist()) == len(set(archive.namelist())) == 130
    for name in (*EXPECTED, 'crates/noetome-cli/src/request_run_recovery.rs'):
        original = archive.read(name)
        actual, pin = read(ROOT / name)
        if name in EXPECTED:
            assert pin['sha256'] == EXPECTED[name]
        originals[name] = original
        current[name] = actual
        before[name] = pin
        (OUT / ('current-' + Path(name).name)).write_bytes(actual)
        (OUT / ('baseline-' + Path(name).name)).write_bytes(original)
        (OUT / (Path(name).name + '.diff')).write_text(''.join(difflib.unified_diff(original.decode().splitlines(True), actual.decode().splitlines(True), fromfile='baseline/' + name, tofile='current/' + name)), encoding='utf-8')
assert read(old_source) == (old_zip_bytes, old_zip_pin)
assert originals['crates/noetome-cli/src/request_run.rs'] != current['crates/noetome-cli/src/request_run.rs']
assert originals['crates/noetome-cli/src/request_budget_store.rs'] != current['crates/noetome-cli/src/request_budget_store.rs']
assert originals['crates/noetome-cli/src/request_run_recovery.rs'] == current['crates/noetome-cli/src/request_run_recovery.rs']


def block(body, start, end):
    text = body.decode()
    return text[text.index(start):text.index(end, text.index(start))]


store_name = 'crates/noetome-cli/src/request_budget_store.rs'
run_name = 'crates/noetome-cli/src/request_run.rs'
unchanged = {}
for label, start, end in (
    ('physical_policy_owner_directory_header_sidecar_layout', 'fn layout(', 'fn compact('),
    ('complete_schema_metadata', 'fn schema(', 'impl BudgetStore {'),
    ('full_external_input_FileStamp', 'fn verify_inputs(', 'fn validate_plan('),
    ('full_event_chain_replay_and_state_machine', 'fn load(', 'fn witnesses('),
    ('registered_original_id_inventory_and_semantics_witnesses', 'fn witnesses(', 'fn allowed_file('),
    ('raw_transport_and_request_verification', 'fn transport_files(', 'fn receipt_files('),
    ('original_report_MD_wire_usage_candidate_Core_checks', 'fn receipt_files(', '#[cfg(test)]'),
):
    old = block(originals[store_name], start, end)
    new = block(current[store_name], start, end)
    assert old == new, label
    unchanged[label] = {'SHA256': hashlib.sha256(new.encode()).hexdigest(), 'byte_length': len(new.encode()), 'actual_byte_equal_to_prior_release_source': True}
for label, start, end in (
    ('Run_original_directory_owner_and_inventory', '    fn inventory(', '    fn claim('),
    ('Run_owner_original_byte_and_directory_verification', '    fn verify(', '    fn inputs('),
    ('Run_source_complete_inventory_hash_identity_and_compiler', '    fn inputs(', '\nstruct SourceGuard'),
):
    # The source helper endpoint is located separately below for the final block.
    if label == 'Run_source_complete_inventory_hash_identity_and_compiler':
        continue
    old = block(originals[run_name], start, end)
    new = block(current[run_name], start, end)
    assert old == new, label
    unchanged[label] = {'SHA256': hashlib.sha256(new.encode()).hexdigest(), 'byte_length': len(new.encode()), 'actual_byte_equal_to_prior_release_source': True}

store = current[store_name].decode()
run = current[run_name].decode()
checked = block(current[store_name], '    fn update_checked<', '    pub(crate) fn register_run(')
assert checked.index('TransactionBehavior::Immediate') < checked.index('load(&tx') < checked.index('witnesses(&view)?;') < checked.index('guard(&view)?;') < checked.index('let at = now()?;') < checked.index('decide(&view, &at)?;') < checked.index('tx.execute(') < checked.index('tx.commit()') < checked.rindex('layout(')
reserve = block(current[store_name], '    pub(crate) fn reserve_prepared_checked(', '    pub(crate) fn mark_may_send(')
assert 'validate_plan(plan)?;' in reserve and 'if a.plan != *plan' in reserve and 'attempt(view, &plan.key)?' in reserve
assert 'admission(view, plan, at)?' in reserve and 'verify_inputs(&run(view, &plan.key.run_id)?.spec)?' in reserve
dispatch = block(current[store_name], '    pub(crate) fn mark_may_send_checked(', '    /// The API calls this')
for exact in ('AttemptState::Reserved', 'view.global_stopped', 'r.budget_stopped', 'r.outcome.is_some()', 'u.outcome.is_some()', 'utc(at)? >= utc(&r.spec.deadline_utc)?', 'utc(at)? >= utc(&u.spec.deadline_utc)?', 'retry_not_due(u, key, at)?', 'verify_inputs(&r.spec)?'):
    assert exact in dispatch, exact
loop = block(current[run_name], 'fn unit_loop(', 'struct Hooks<')
assert loop.index('let view = store.view()?;') < loop.index('expect_receipt.take()') < loop.index('if u.outcome.is_some()')
assert 'a.plan.key == key && a.receipt.is_some()' in loop
assert loop.count('BudgetStore::open(') == 1 and 'store: &mut store' in loop
assert loop.index('if let Err(e) = execution') < loop.index('if let Some(scope) = denial') < loop.index('expect_receipt =')
guard_view = block(current[run_name], '    fn guard_view(', '    fn key(')
for exact in ('guard.verify()?;', 'guard.inventory(view)?;', 'guard.inputs()?;', 'stop.load(Ordering::SeqCst)'):
    assert exact in guard_view, exact
assert '.view(' not in guard_view and 'BudgetStore::' not in guard_view
assert 'reserve_prepared_checked(&plan, |view| Self::guard_view(guard, stop, view))?' in run
assert 'mark_may_send_checked(&key, |view| Self::guard_view(guard, stop, view))?' in run

for name, pin in before.items():
    after_body, after_pin = read(ROOT / name)
    assert current[name] == after_body and pin == after_pin

report = {
    'status': 'independent_static_source_review_passed',
    'current_source_pins_actual_before_after_equal': before,
    'baseline_actual_release_sourceZIP': old_zip_pin,
    'baseline_source_members': 130,
    'actual_changed_source_files': list(EXPECTED),
    'request_run_recovery_source_actual_byte_equal': True,
    'unchanged_guard_regions': unchanged,
    'actual_checked_sequence_proven': ['original authority lock/layout/schema', 'BEGIN IMMEDIATE', 'fresh full load+witnesses', 'guard verify/inventory/inputs/stop', 'fresh now after guard', 'original plan/state/admission/deadline/input decision', 'typed apply+INSERT', 'synchronous COMMIT', 'original post-layout'],
    'prepared_only_reserve_gate': 'Original plan/key exact, unknown Prepared refused, budget/limits/full external input recheck remain. Ordinary reserve retains prepare; existing Reserved branch is independently accepted only after Hooks fresh state==Reserved check. No MaySend reuse.',
    'borrowed_store_and_receipt_review': 'Exactly one BudgetStore open per unit loop; Hooks borrow it. Guard cannot reenter store.view/open. Finished API success uses exact current full AttemptKey, and the next fresh validated view checks real receipt before unit outcome/candidate/retry. Actual execution error and denial remain distinct, not suppressed.',
    'durable_boundaries_preserved': ['Prepared commit then request_body_original_sync', 'separate Reserved commit then attempt_reserved_commit', 'separate MaySend commit then dispatch_intent_commit', 'unchanged transport seal/settlement/retry/unit terminal updates and original callbacks'],
    'new_four_test_definitions_not_claimed_executed_by_reviewer': ['original Prepared plan required', 'failed reserve/send guards no commitment', 'another workers newer commitment seen in fresh view', 'guard precedes decision clock and input recheck'],
    'residual_scope': 'No cross-transaction caches or removed raw/source/owner/header/sidecar checks were found. Full input recheck still occurs after the decision timestamp, as before; current API actual remaining-deadline send controller is unchanged. This review proves source order/guard preservation, not runtime speed or arbitrary concurrent attacker atomicity. OS-lock/busy wait remains bounded5s and can still consume the original unit deadline; acceptance must come from new original Native1500/1000, OS kill/wait and full matrices, not old2e results.',
    'old_source_capture_note': 'During earlier planning capture Root intentionally changed the selected source. An old2e expectation assertion failed after three copied current source files, before a review receipt was saved. Those copies remain in .artifacts/b07-t02-budget-validation-reuse-independent-review-20261107; original assertion tool output is in conversation only, no standalone historical raw output file was captured. They are not claimed old-source proof.',
    'reviewer_product_Cargo_HTTP_invocations': 0,
}
(OUT / 'actual.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'source_pins': before, 'actual_sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(), 'actual_byte_length': (OUT / 'actual.json').stat().st_size}, ensure_ascii=False))
