"""Static exact source review only; compile, product and Native calls are forbidden."""
from pathlib import Path
import difflib
import hashlib
import io
import json
import os
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
EXPECTED = {
    'request_run.rs': ('e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 74943),
    'request_budget_store.rs': ('57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646', 165922)}
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1
    shape = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns, value.st_nlink)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final_opened = os.fstat(stream.fileno())
    last = path.lstat()
    assert shape(first) == shape(opened) == shape(final_opened) == shape(last), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
           'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'mode': first.st_mode, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

def section(text, first, next_marker):
    start = text.index(first)
    end = text.index(next_marker, start + len(first))
    return text[start:end]

source_zip = ROOT / '.artifacts/b07-t02-linux-shared-header-pair-01-20261107/source-originals.zip'
raw_zip = read(source_zip)
assert hashlib.sha256(raw_zip).hexdigest() == '3ff0d5211fbe7f119302387e1f2d36a3e5b9a5865ad70280f50c3c43be4216ef'
old = {}
new = {}
with zipfile.ZipFile(io.BytesIO(raw_zip)) as archive:
    for name, (sha, size) in EXPECTED.items():
        member = 'crates/noetome-cli/src/' + name
        old_raw = archive.read(member)
        new_raw = read(ROOT / member)
        assert hashlib.sha256(new_raw).hexdigest() == sha and len(new_raw) == size
        old[name] = old_raw.decode('utf8')
        new[name] = new_raw.decode('utf8')
        for suffix, raw in [('before-b393-2e97', old_raw), ('after-e4-57c1', new_raw)]:
            path = OUT / (name + '.' + suffix)
            with path.open('xb') as stream:
                stream.write(raw)
        difference = ''.join(difflib.unified_diff(old[name].splitlines(keepends=True), new[name].splitlines(keepends=True),
                                                name + '-before-b393-2e97', name + '-after-e4-57c1'))
        with (OUT / (name + '.patch')).open('x') as stream:
            stream.write(difference)

run_old = old['request_run.rs']
run_new = new['request_run.rs']
old_verify = section(run_old, '    fn verify(&self)', '    fn inputs(&self)')
new_verify = section(run_new, '    fn verify(&self)', '    fn inputs(&self)')
restored_run = run_new.replace('request_budget_store::{BudgetStore, registered_identity_matches}', 'request_budget_store::BudgetStore', 1)
restored_run = restored_run.replace(new_verify, old_verify, 1)
assert restored_run == run_old
assert new_verify.count('registered_identity_matches(') == 6
assert section(run_old, 'fn stamp_with(', 'fn stamp(') == section(run_new, 'fn stamp_with(', 'fn stamp(')

store_old = old['request_budget_store.rs']
store_new = new['request_budget_store.rs']
helper = section(store_new, 'fn registered_handle_identity(', 'fn empty_stamp(')
known_chain = section(store_new, 'fn known_expected_chain(', 'fn json(')
new_tests = section(store_new, '    #[test]\n    fn budget_registered_identity_checks_known_file_directory_without_byte_binding(', '    fn literal_database_header(')
new_names = re.findall(r'^    fn (budget_registered_identity_\w+)\(', new_tests, re.M)
assert len(new_names) == len(set(new_names)) == 5
restored_store = store_new.replace(helper, '', 1).replace(known_chain, '', 1).replace(new_tests, '', 1)
for first, next_marker in [('fn layout(', 'fn database_header('), ('fn witnesses(', 'fn directory_prefixes(')]:
    old_part = section(store_old, first, next_marker)
    new_part = section(store_new, first, next_marker)
    restored_store = restored_store.replace(new_part, old_part, 1)
assert restored_store == store_old
assert 'prefixes != expected.keys().cloned().collect::<BTreeSet<_>>()' in known_chain
assert helper.count('options.open(path)') == 1 and helper.count('same_file::Handle::from_path(path)') == 1
assert 'options.share_mode(3).custom_flags(0x02200000)' in helper
assert helper.index('registered_handle_identity(path, &file, &opened_metadata)? != *expected') < helper.index('after_snapshot()?')
assert 'current == opened' in helper and 'current_id == *expected' in helper
assert helper.count('project::check_components(path)?;') == 3
assert '.read_to_end' not in helper and 'read_exact' not in helper and '.modified()' not in helper
assert 'metadata.is_file() && metadata.nlink() != 1' in helper
assert 'information.number_of_links() != 1' in helper
assert 'information.file_attributes() & 0x400 != 0' in helper
assert 'options.share_mode(7);' in new_tests and 'fs::read(&path).is_err()' in new_tests
for first, next_marker in [('pub(super) fn stamp_mode(', 'fn matches_pin('),
                           ('fn database_header(', 'fn check_stage('),
                           ('    fn update_checked<R>(', '    pub(crate) fn register_run(')]:
    assert section(store_old, first, next_marker) == section(store_new, first, next_marker)
for path in list(PINS):
    read(Path(path))

result = {'producer': 'independent_registered_expected_identity_static_source_review', 'status': 'passed_static_scope_review',
          'scope': 'e4/57c1 source only; no tests, Cargo, Native workload or HTTP run by this reviewer. Historical891 results cover only b393/2e97.',
          'source_pins': PINS, 'outside_allowed_source_sections_byte_equal': True,
          'Run_delta': 'one import and six existing trusted-ID comparisons in RunGuard.verify; all remaining Run code exact',
          'Store_delta': 'three helper functions, layout/witnesses trusted-ID comparisons, complete expected-chain helper and five tests; remaining Store source exact',
          'unchanged_full_stamp_header_and_transaction_functions_byte_equal': True,
          'registered_identity_path_opens_static_count': 2, 'simultaneously_live_actual_clone_current_handles': 3,
          'unknown_initial_capture_still_global_identity': True, 'no_body_read_or_mtime_binding_in_identity_only_helper': True,
          'trusted_expected_handle_ID_before_callback': True, 'actual_and_current_expected_ID_type_singlelink_reparse_gates': True,
          'complete_expected_prefix_key_set_and_actual_each_ID': True,
          'new_test_definitions_not_test_results': new_names,
          'risk_boundaries': ['Identity-only observation deliberately permits same-ID byte/mtime change; every existing fullstamp input/owner/wire gate remains separate and byte-identical.',
                              'No cross-transaction cache or budget phase merge; BEGIN IMMEDIATE/load/witness/guard/now/decide and post-COMMIT layout are unchanged.',
                              'Final pathname revalidation does not promise protection against arbitrary external replacement after all handles are released.',
                              'Directories are not required to keep mtime/length/nlink stable; registered children may be created concurrently.',
                              'Static reduction in path opens is not a measured timing guarantee and does not prove Windows1500ms/full62 acceptance.'],
          'specific_blocking_findings': [], 'new_product_Cargo_HTTP_Native_invocations': 0,
          'current_full_Native_Rust807': 'not_run_by_this_reviewer', 'current_full_Native_main62': 'not_run'}
with (OUT / 'actual.json').open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
pin = read(OUT / 'actual.json')
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256(pin).hexdigest(), 'byte_length': len(pin),
                  'Run_SHA': EXPECTED['request_run.rs'][0], 'Store_SHA': EXPECTED['request_budget_store.rs'][0]}))
