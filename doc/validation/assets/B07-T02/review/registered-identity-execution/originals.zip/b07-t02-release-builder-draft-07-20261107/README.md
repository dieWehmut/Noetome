# B07-T02 release07 guarded build-only draft

当前冻结的四份输入为 Run e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e /74943B、Store 57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646 /165922B、checker 3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7 /169966B、tests 42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348 /50420B。

executor.py SHA256为0bed092e1e54705ebb5b977c21acc0debd663f402024705516f8799c0820e53f，27263B。直接父件为已冻结release06 83d34e42602b78b5438f90ad70766c17a3d33227d1fa4961a95a1d80a1d20c15 /27263B。只替换当前Run/Store SHA和长度；倒回这些literal可逐byte恢复父件，parent-to-current.patch保留完整差异。

严格缓存差异仍只允许原release02 Run2e735/74989与Store726267/128653到当前e4d/74943、57c1/165922。四个具名scope必须完整names一致，除这两文件外每项SHA和长度全等。物理缓存仍为真实release01/build-target，证据根独立为已闭合release02；七份固定缓存收据、原physical路径比较、两个Cargo原receipt行、八control和四个外部SHA保持原码，不能从target.parent推证据。此次本地静态验证没有读取D盘原收据或缓存目录。

源码、八control、新selected及aliases仍由原固定actual fileID/mtime/length/nlink与SHA守卫核对；所有父组件先拒reparse，登记不刷新旧baseline。不声称目录ID或runtime工具ID新增保护。临时Cargo输出允许原有正nlink并在复制前后复核实际ID/time/linkcount，新selected仍必须普通单link、完整body和真实FP实探。

Store新增五个common registered-identity测试定义，Run没有新增测试定义。Windows Store45、Linux Store47、Windows全workspace807为预期；列举与执行必须以后继原件为准。Root报告的当前Linux47通过不代表本草稿在Windows执行。executor仅执行两个真实release构建、driver列举与双程序探针，不执行全Rust、全Python或HTTP。

Root明确GO后才使用以下接口；目前均未执行：

```text
/tmp/noetome-b05-t03-python/bin/python executor.py prepare --repo /home/lyinn/project/Noetome --native-base /mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-07-20261107 --original-runner /home/lyinn/project/Noetome/.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py --freeze-label b07-t02-registered-identity-release07 --cache-target /mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-01-20261107/build-target --cache-evidence-root /mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-02-20261107
```

prepare实际闭合且所有guards通过后，后继Root GO才运行`executor.py launch --native-base <同新根>`。原native run子命令仍由外部snapshot/runner/sourcearchive/executor四SHA绑定的launcher调用。必须重新实际执行`cargo build -p noetome-cli --bin noetome --release --locked --offline --message-format=json`与`cargo test -p noetome-cli --lib --release --no-run --locked --offline --message-format=json`，不复用旧测试、旧程序或旧FP。CargoJSON选中的CLI/driver、release PROFILE与OPT_LEVEL、双方FP/probes/完整PE和实际outerwait须闭合。独立preflight和Root GO后才由唯一owner运行普通1500、三个目标与全62。

实际静态验证：AST通过，help PID834649 exit0且wait闭合；四个Home源码SHA/长度前后全等。实际check_source_delta内存输入一个合法精确差异通过，七个非法输入分别拒绝：旧Run、旧Store、第三变化、少名、多名、Run错长度、Store错长度。此类规则测试不是产品CLI或OS kill。原完整StrongFiles、commands、cache、controls代码逐byte保留。

静态脚本先保存后执行，源6876B/SHA4ee72037125c837f824c96855ba0e9463d969530ee684d66123daf4ce61f9172；父operator实际PID834648 exit0且wait闭合。原artifact launcher一度命名operator.py，启动时遮蔽Python stdlib导致import失败，未启动任何静态child或Native；该原源/错误保存在相邻static-preparation目录的operator-bootstrap-failure-01，改名run-static-drafts.py后实际检查通过。没有改产品源、标准、作者或旧草稿。
