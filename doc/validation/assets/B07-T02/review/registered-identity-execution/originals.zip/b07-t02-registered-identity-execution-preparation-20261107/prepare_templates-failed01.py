"""Prepare unused current-source execution templates. No subprocess or HTTP.

The retained originals, byte changes and current source pins are captured before
first read and rechecked. Future compiled FP/PE/Native-root remain pending.
"""
from pathlib import Path
import ast
import difflib
import hashlib
import json

REPO = Path('/home/lyinn/project/Noetome')
HERE = Path(__file__).parent
LINUX_OLD = REPO / '.artifacts/b07-t02-linux-shared-header-full-launch-01-20261107/launch.py'
NATIVE_OLD = REPO / '.artifacts/b07-t02-native-shared-header-plan-01-20261107/prepare_operator.py'
LINUX_NEW = REPO / '.artifacts/b07-t02-linux-registered-identity-full-launch-01-20261107/launch.py'
NATIVE_NEW = REPO / '.artifacts/b07-t02-native-registered-identity-plan-01-20261107/prepare_operator.py'
FOUR = {
    'crates/noetome-cli/src/request_run.rs': ('e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 74943),
    'crates/noetome-cli/src/request_budget_store.rs': ('57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646', 165922),
    'scripts/verify_request_budget.py': ('3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 169966),
    'tests/test_verify_request_budget.py': ('42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 50420),
}


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino,
                 'mtime_ns': after.st_mtime_ns, 'nlink': after.st_nlink,
                 'metadata_captured_before_first_read': True}


def save(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)


def replace_exact(source, changes):
    for old, new, expected_count in changes:
        assert source.count(old) == expected_count, (old, source.count(old), expected_count)
        source = source.replace(old, new)
    return source


def main():
    original_pins = {}
    old_sources = {}
    for label, path in [('linux', LINUX_OLD), ('native', NATIVE_OLD)]:
        raw, pin = capture(path)
        ast.parse(raw)
        old_sources[label] = raw
        original_pins[label] = {'original': str(path), 'pin': pin}
        save(HERE / (label + '-previous-original.py'), raw)
    linux = replace_exact(old_sources['linux'].decode(), [
        ('b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c', FOUR['crates/noetome-cli/src/request_run.rs'][0], 1),
        ('2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184', FOUR['crates/noetome-cli/src/request_budget_store.rs'][0], 1),
        (', 74782)', ', 74943)', 1), (', 151556)', ', 165922)', 1),
        ('b07-t02-linux-shared-header-pair-01-20261107', 'b07-t02-linux-registered-identity-pair-01-20261107', 1),
        ('b07-t02-request-linux-shared-header-full-01-20261107', 'b07-t02-request-linux-registered-identity-full-01-20261107', 1),
        ('current3b263 checker and b393ff18/2e97ac1d shared-read/header Release actualLinux full62; old4ca Linux62 and Native4650 failure remain historical;', 'current3b263 checker and e4d598e2/57c1d73b registered-identity Release actualLinux full62; oldb393 Linux62 and Nativec2f1 failure remain historical;', 1),
    ])
    native = replace_exact(old_sources['native'].decode(), [
        ('native-shared-header', 'native-registered-identity', 2),
        ('request-native-shared-header', 'request-native-registered-identity', 3),
        ('b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c', FOUR['crates/noetome-cli/src/request_run.rs'][0], 1),
        ('2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184', FOUR['crates/noetome-cli/src/request_budget_store.rs'][0], 1),
        ("'b07-t02-native-shared-header-'+stage", "'b07-t02-native-registered-identity-'+stage", 1),
        ('prepared_only_shared_header_native_handoff_pending_not_executed', 'prepared_only_registered_identity_native_handoff_pending_not_executed', 1),
        ('Root actual release06 closed pair receipt', 'Root actual new registered-identity closed pair receipt', 1),
        ('actually pinned to b393/2e97/3b/428', 'actually pinned to e4d598e2/57c1d73b/3b/428', 1),
    ])
    ast.parse(linux)
    ast.parse(native)
    save(LINUX_NEW, linux.encode('utf-8'))
    save(NATIVE_NEW, native.encode('utf-8'))
    changes = {}
    for label, old, new in [('linux', old_sources['linux'], linux.encode()), ('native', old_sources['native'], native.encode())]:
        diff = ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True), fromfile=label+'-previous-original.py', tofile=label+'-current-template.py'))
        save(HERE / (label + '-template.diff'), diff.encode())
        changes[label] = {'new': str(LINUX_NEW if label == 'linux' else NATIVE_NEW),
                          'pin': capture(LINUX_NEW if label == 'linux' else NATIVE_NEW)[1],
                          'static_python_AST_parse': True}
    current = {}
    for relative, (digest, size) in FOUR.items():
        raw, pin = capture(REPO / relative)
        assert (pin['sha256'], pin['byte_length']) == (digest, size)
        current[relative] = pin
    for relative, pin in current.items():
        assert capture(REPO / relative)[1] == pin
    for record in original_pins.values():
        assert capture(Path(record['original']))[1] == record['pin']
    report = {
        'status': 'prepared_templates_only_new_compiled_pair_pending_no_execution',
        'original_template_pins': original_pins, 'current_four_source_pins': current,
        'new_templates': changes, 'current_source_before_after_identity_mtime_bytes_equal': True,
        'future_compiler_fingerprint': None, 'future_original_CLI_body': None,
        'future_original_driver_body': None, 'future_Native_build_root': None,
        'Linux_scope': 'One --full62 only, no separate3targets; current source pins and actual future build receipt must pass before the checker sends anything. Launch only after Root new closed-pair GO.',
        'Native_scope': 'Mandatory actual NativeBuildRoot for every stage and newFP/twoPE SHA for normalization; all later stages consume the same actual normalized receipt and selected paths. a7ef/9fbc/11ab body, original caps/author/deadline/gates remain unchanged. ordinaryextra once then three once; any missing real kill/wait stops before main62; threepassed then separate Root GO required.',
        'new_product_CLI_calls': 0, 'new_driver_calls': 0, 'new_HTTP_requests': 0,
        'Native_plan_generation': 'prepare_operator.py has only been AST parsed here; execute the no-subprocess generator separately to freeze the bundle. No Native PowerShell parse or product execution is claimed.',
        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': capture(Path(__file__).absolute())[1]},
    }
    save(HERE / 'actual.json', (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode())
    print(json.dumps({'status': report['status'], 'actual_pin': capture(HERE / 'actual.json')[1],
                      'templates': changes}))


if __name__ == '__main__':
    main()
