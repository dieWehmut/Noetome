"""Static review of new templates and immutable helper copies. No product run."""
from pathlib import Path
import ast
import hashlib
import json

REPO = Path('/home/lyinn/project/Noetome')
HERE = Path(__file__).parent
LINUX = REPO / '.artifacts/b07-t02-linux-registered-identity-full-launch-01-20261107/launch.py'
NATIVE = REPO / '.artifacts/b07-t02-native-registered-identity-plan-01-20261107'


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino,
                 'mtime_ns': after.st_mtime_ns, 'nlink': after.st_nlink}


class NormalizeConstants(ast.NodeTransformer):
    def visit_Constant(self, node):
        return ast.copy_location(ast.Constant(value='prepared-source-label-or-pin'), node)


def shape(raw):
    return ast.dump(NormalizeConstants().visit(ast.parse(raw)), include_attributes=False)


def main():
    old_linux = capture(HERE / 'linux-previous-original.py')[0]
    old_native = capture(HERE / 'native-previous-original.py')[0]
    new_linux, linux_pin = capture(LINUX)
    new_native, native_pin = capture(NATIVE / 'prepare_operator.py')
    assert shape(old_linux) == shape(new_linux)
    assert shape(old_native) == shape(new_native)
    linux_text = new_linux.decode()
    assert linux_text.count("'--full'") == 1
    assert "b07-t02-linux-registered-identity-pair-01-20261107" in linux_text
    assert "b07-t02-request-linux-registered-identity-full-01-20261107" in linux_text
    assert 'no extra3Linux targets or pass-count reuse' in linux_text
    plan_raw, plan_pin = capture(NATIVE / 'plan.json')
    plan = json.loads(plan_raw)
    assert plan['status'] == 'prepared_only_registered_identity_native_handoff_pending_not_executed'
    for key in ('future_native_build_root', 'actual_selected_FP', 'actual_original_CLI', 'actual_original_driver',
                'source_member_count_actual', 'source_zip_member_count_actual', 'actual_runtime_PIDs'):
        assert plan[key] is None
    assert plan['author_limits_unmodified'] == {'unit_a_elapsed_ms': 1500, 'backoff_ms': 1000,
                                              'API_timeout_ms': 200, 'expired_wait_ms': 1700, 'R': 8310}
    helpers = {}
    for name, digest in [('normalize_build.py', '9fbc7c68c60c7f06bbd286d65b275fc26df99bc56326ce6ef4d91bda3cdd40af'),
                         ('narrow.py', 'a7ef5424797ec59d5aebc8382ae26acb91a0885c3ff40ccb07e492b4d7d8bff3'),
                         ('run_stage.py', '11ab48b314f2ac95eed0c507d7fca13f318ec0b012f093442a56e5dc932d19ae')]:
        raw, pin = capture(NATIVE / 'frozen-bundle' / name)
        assert pin['sha256'] == digest
        ast.parse(raw)
        helpers[name] = pin
    stages = {}
    for stage in ('normalize', 'ordinary', 'three', 'full'):
        raw, pin = capture(NATIVE / 'frozen-bundle' / (stage + '.ps1'))
        text = raw.decode()
        assert '[Parameter(Mandatory=$true)][string]$NativeBuildRoot' in text
        assert 'native-registered-identity' in text
        assert "Join-Path $NativeBuildRoot 'selected\\noetome.exe'" in text
        assert "Join-Path $NativeBuildRoot 'selected\\noetome-cli-testdriver.exe'" in text
        if stage == 'normalize':
            for parameter in ('Fingerprint', 'CliSha', 'DriverSha'):
                assert "[Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$" + parameter in text
            for flag in ('--expected-fingerprint', '--expected-cli-sha', '--expected-driver-sha'):
                assert flag in text
        if stage == 'full':
            assert 'all3 passed,3 actual own-PID kills and waits' in text
        stages[stage] = pin
    for key in ('new_Native_processes', 'new_CLI_calls', 'new_driver_calls', 'new_HTTP_requests'):
        assert plan[key] == 0
    report = {
        'status': 'static_template_shape_helper_bytes_pending_handoff_review_passed_no_execution',
        'Linux_template': linux_pin, 'Native_generation_template': native_pin, 'Native_pending_plan': plan_pin,
        'original_vs_new_AST_equal_after_only_constant_values_normalized': {'Linux': True, 'Native': True},
        'preserved_three_helper_original_bytes': helpers, 'prepared_PowerShell_templates': stages,
        'mandatory_new_handoff_tuple': 'NativeBuildRoot required for every stage; actual newFP/CliSha/DriverSha required for normalization. No tuple is guessed or filled. Later stages use the exact normalized receipt and selected paths of the same actual build root.',
        'syntax_limit': 'Python AST and literal PowerShell parameter checks only. No Native PowerShell parser, product CLI, driver or HTTP has run.',
        'new_product_CLI_calls': 0, 'new_driver_calls': 0, 'new_HTTP_requests': 0,
        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': capture(Path(__file__).absolute())[1]},
    }
    with (HERE / 'static-review.json').open('xb') as stream:
        stream.write((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'status': report['status'], 'actual_pin': capture(HERE / 'static-review.json')[1]}))


if __name__ == '__main__':
    main()
