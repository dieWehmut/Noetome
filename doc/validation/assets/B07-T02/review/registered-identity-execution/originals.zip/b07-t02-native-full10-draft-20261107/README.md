# B07-T02 full10 current-source debug regression draft

当前冻结的四份输入为 Run e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e /74943B、Store 57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646 /165922B、checker 3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7 /169966B、tests 42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348 /50420B。

executor.py SHA256为f464591b3934bdaf80a2f74857eefd34c4b83bf74307141d41ff7aafef90426e，14789B。直接父件为已冻结full09 1ece8fe6df2732bc97656ddecbf0430bb71d3803a3c8ed359aa15ff51df69059 /14789B。只改Run/Store SHA和长度，以及全Rust成功literal802→807。逐字节倒回这些literal即恢复父件；prepare/native的四份SHA+长度exact校验、固定metadata、八control、所有命令与guards原码保留。

Store新增五个common registered-identity测试定义，Run新增测试定义为零。Windows Store45、Linux Store47、全Windows807为预期；不得把Linux47当作Windows47，也不得把driver --list当执行测试。Root当前Linux47结果不代替此新Windows全套。

此刻只有Home本地AST/help与静态源规则验证，未prepare、创建Native根、启动Cargo/Native/产品/HTTP或全Python。旧C2 Native的合法NoFit全部保持历史，不能作为当前e4d/57c1/新FP的通过证明。

prepare接口保持，只有当前release来源、三个目标和Native全62真实通过、全部PIDs闭合、Root另行GO后才执行：

```text
/tmp/noetome-b05-t03-python/bin/python executor.py prepare --repo /home/lyinn/project/Noetome --native-base <Root明确选定的不存在新D盘full根> --original-runner /home/lyinn/project/Noetome/.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py --freeze-label b07-t02-registered-identity-full10 --cache-target /mnt/d/Noetome/.artifacts/b07-t02-windows-native-01-20261107/build-target
```

cache仅原已闭合Native01依赖target，不是release01 target，不复用旧程序、测试或FP。原3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1 runner仍执行全部当前debug fmt/check/cleanbuild/CLI/driver/workspace Rust/fullPython。debug完整回归FP与release行为FP分别保存，不接管旧FP Run根。

全Rust807/0failed/0ignored、全Python527=519pass8skip是静态成功门槛。PS5.1实际which/samefile与工具body、已选cachePS7.6.5实际which/版本/body以及两个引擎各39真实discover/通过仍必须由原stdout/stderr证明。仅PATH两值或文件存在不代表通过。current默认APITest只synthetic/明确localhost，executor不自行运行T02 HTTP矩阵或读取真实凭据/累计授权账本。

StrongFiles原固定baseline保护源码、八control、新selected与aliases actual fileID/mtime/length/nlink/SHA，各父组件先拒reparse；不刷新baseline，不额外声称目录ID或runtime工具ID保护。实际完整Cargo/Python结果、Source/工具/元数据守卫和最外wait以后继新原件为准。

实际本地验证：AST通过，help PID834650 exit0且wait闭合；四个Home源码SHA/length前后完全相同；回退literal后whole-byte恢复full09。相邻static-preparation目录保存先落盘脚本、PID834648实际exit0、原stdout/stderr和首artifact import失败历史。没有运行807/527、Native或任何产品。
