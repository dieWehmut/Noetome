from pathlib import Path
import ast,hashlib,json,difflib,importlib.util,subprocess,time,copy
ROOT=Path('/home/lyinn/project/Noetome')
OUT=ROOT/'.artifacts/b07-t02-release07-full10-static-preparation-20261107'
RELEASE_OLD=ROOT/'.artifacts/b07-t02-release-builder-draft-06-20261107/executor.py'
FULL_OLD=ROOT/'.artifacts/b07-t02-native-full09-draft-20261107/executor.py'
RELEASE_NEW=ROOT/'.artifacts/b07-t02-release-builder-draft-07-20261107'
FULL_NEW=ROOT/'.artifacts/b07-t02-native-full10-draft-20261107'
OLD_RUN='b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c'
NEW_RUN='e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'
OLD_STORE='2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184'
NEW_STORE='57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha(RELEASE_OLD.read_bytes())=='83d34e42602b78b5438f90ad70766c17a3d33227d1fa4961a95a1d80a1d20c15'
assert sha(FULL_OLD.read_bytes())=='1ece8fe6df2732bc97656ddecbf0430bb71d3803a3c8ed359aa15ff51df69059'
RELEASE_NEW.mkdir(exist_ok=False);FULL_NEW.mkdir(exist_ok=False)
raws=[]
for prev,out,isfull in [(RELEASE_OLD,RELEASE_NEW,False),(FULL_OLD,FULL_NEW,True)]:
 before=prev.read_text()
 after=before.replace(OLD_RUN,NEW_RUN).replace(OLD_STORE,NEW_STORE).replace("'byte_length': 74782","'byte_length': 74943").replace("'byte_length': 151556","'byte_length': 165922")
 if isfull:after=after.replace("'passed': 802","'passed': 807")
 restored=after.replace(NEW_RUN,OLD_RUN).replace(NEW_STORE,OLD_STORE).replace("'byte_length': 74943","'byte_length': 74782").replace("'byte_length': 165922","'byte_length': 151556")
 if isfull:restored=restored.replace("'passed': 807","'passed': 802")
 assert restored==before
 ast.parse(after)
 (out/'executor.py').write_text(after)
 (out/'parent-to-current.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=prev.name+'.frozen-parent',tofile='executor.py.current')))
 raws.append((out,before,after))
def mod(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
r=mod(RELEASE_NEW/'executor.py','new_release07');r_old=mod(RELEASE_OLD,'old_release06');f=mod(FULL_NEW/'executor.py','new_full10')
assert r.SOURCE_PINS==f.SOURCE_PINS
source_before={}
for n,want in r.SOURCE_PINS.items():
 b=(ROOT/n).read_bytes();pin={'sha256':sha(b),'byte_length':len(b)};assert pin==want;source_before[n]=pin
assert r.SOURCE_PINS['crates/noetome-cli/src/request_run.rs']=={'sha256':NEW_RUN,'byte_length':74943}
assert r.SOURCE_PINS['crates/noetome-cli/src/request_budget_store.rs']=={'sha256':NEW_STORE,'byte_length':165922}
assert r.PRIOR_FIXED_PINS==r_old.PRIOR_FIXED_PINS and r.CACHE_RECEIPT_NAMES==r_old.CACHE_RECEIPT_NAMES and len(r.CACHE_RECEIPT_NAMES)==7
assert r.CONTROL_NAMES==r_old.CONTROL_NAMES and len(r.CONTROL_NAMES)==8
assert r.CACHE_TARGET_NATIVE==r_old.CACHE_TARGET_NATIVE and r.CACHE_BASE_NAME==r_old.CACHE_BASE_NAME
assert r.SCOPE_KEYS==r_old.SCOPE_KEYS
for n,d in r.ALLOWED_SOURCE_DELTA.items():assert d['old']==r_old.ALLOWED_SOURCE_DELTA[n]['old'] and d['new']==r.SOURCE_PINS[n]
prior={k:{**{n:copy.deepcopy(v['old']) for n,v in r.ALLOWED_SOURCE_DELTA.items()},'Cargo.lock':{'sha256':'a'*64,'byte_length':1}} for k in r.SCOPE_KEYS}
current={k:{**{n:copy.deepcopy(v['new']) for n,v in r.ALLOWED_SOURCE_DELTA.items()},'Cargo.lock':{'sha256':'a'*64,'byte_length':1}} for k in r.SCOPE_KEYS}
assert r.check_source_delta(current,prior)['same_names_and_all_other_file_SHA_lengths_exact']
negative=[]
for case in ['stale_previous_Run','stale_previous_Store','third_mutation','missing_name','extra_name','wrong_Run_length','wrong_Store_length']:
 now=copy.deepcopy(current);run='crates/noetome-cli/src/request_run.rs';store='crates/noetome-cli/src/request_budget_store.rs'
 if case=='stale_previous_Run':
  for k in r.SCOPE_KEYS:now[k][run]=copy.deepcopy(r_old.ALLOWED_SOURCE_DELTA[run]['new'])
 elif case=='stale_previous_Store':
  for k in r.SCOPE_KEYS:now[k][store]=copy.deepcopy(r_old.ALLOWED_SOURCE_DELTA[store]['new'])
 elif case=='third_mutation':
  for k in r.SCOPE_KEYS:now[k]['Cargo.lock']['sha256']='b'*64
 elif case=='missing_name':now[r.SCOPE_KEYS[0]].pop('Cargo.lock')
 elif case=='extra_name':now[r.SCOPE_KEYS[1]]['extra.rs']={'sha256':'c'*64,'byte_length':2}
 elif case=='wrong_Run_length':
  for k in r.SCOPE_KEYS:now[k][run]['byte_length']+=1
 else:
  for k in r.SCOPE_KEYS:now[k][store]['byte_length']+=1
 try:r.check_source_delta(now,prior)
 except RuntimeError:negative.append({'case':case,'actual':'rejected'})
 else:raise AssertionError(case)
help_rows=[]
for out,before,after in raws:
 args=['/tmp/noetome-b05-t03-python/bin/python','-B',str(out/'executor.py'),'--help'];t=time.time_ns()
 with (out/'help.stdout.bin').open('wb') as stdout,(out/'help.stderr.bin').open('wb') as stderr:
  child=subprocess.Popen(args,cwd=ROOT,stdout=stdout,stderr=stderr);rc=child.wait()
 assert rc==0
 help_rows.append({'argv':args,'PID':child.pid,'exit_code':rc,'started_ns':t,'finished_ns':time.time_ns(),'actual_wait_closed':True})
source_after={n:{'sha256':sha((ROOT/n).read_bytes()),'byte_length':(ROOT/n).stat().st_size} for n in r.SOURCE_PINS};assert source_before==source_after
for i,(out,before,after) in enumerate(raws):
 body={'schema_version':1,'producer':'artifact_only_next_executor_static_checks','executor':{'sha256':sha((out/'executor.py').read_bytes()),'byte_length':(out/'executor.py').stat().st_size},'parent_executor':{'sha256':sha((RELEASE_OLD if i==0 else FULL_OLD).read_bytes()),'byte_length':(RELEASE_OLD if i==0 else FULL_OLD).stat().st_size},'AST':True,'whole_byte_restore_to_exact_parent':True,'only_changed_literals':'Run/Store SHA and lengths; full Rust802->807 only for full10','all_other_guards_cache_commands_unchanged':True,'exact_four_current_SourcePins':r.SOURCE_PINS,'source_before_after_equal':source_before==source_after,'help':help_rows[i],'static_source_delta_negatives':negative,'old_two_cache_pins_and_seven_evidence_names_unchanged':True,'old_physical01_evidence02_controls_unchanged':True,'expected_counts_not_run':{'Windows_full':807,'Windows_Store':45,'Linux_Store':47,'Run_new_tests':0,'Store_new_common_tests':5,'Windows_Python':527,'PS_each_credential_tests':39},'prepare':'not_run','Native':'not_run','Cargo':'not_run','HTTP':'not_run'}
 (out/'static-checks.json').write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'drafts':[{ 'root':str(out),'executor_sha256':sha((out/'executor.py').read_bytes()),'byte_length':(out/'executor.py').stat().st_size,'static_sha256':sha((out/'static-checks.json').read_bytes())} for out,_,_ in raws],'help':help_rows,'four_source_before_after_equal':True,'prepare':'not_run','Native':'not_run','Cargo':'not_run','HTTP':'not_run'},indent=2))
