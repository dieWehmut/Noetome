from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path('/home/lyinn/project/Noetome')
base = root / '.artifacts/b07-t02-release07-full10-static-preparation-20261107'
script = base / 'prepare-static-drafts.py'
before = script.read_bytes()
argv = ['/tmp/noetome-b05-t03-python/bin/python', '-B', str(script)]
started = time.time_ns()
with (base / 'actual.stdout.bin').open('wb') as stdout, (base / 'actual.stderr.bin').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=root, stdout=stdout, stderr=stderr)
    rc = child.wait()
actual = {
    'schema_version': 1,
    'producer': 'artifact_only_static_draft_operator',
    'argv': argv,
    'PID': child.pid,
    'exit_code': rc,
    'started_ns': started,
    'finished_ns': time.time_ns(),
    'actual_wait_closed': True,
    'saved_script': {
        'path': str(script),
        'sha256': hashlib.sha256(before).hexdigest(),
        'byte_length': len(before),
        'existed_before_Popen': True,
        'before_after_byte_equal': before == script.read_bytes(),
    },
    'Native': 'not_run',
    'prepare': 'not_run',
    'Cargo': 'not_run',
    'HTTP': 'not_run',
}
(base / 'actual.json').write_text(json.dumps(actual, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(actual, ensure_ascii=False, indent=2))
raise SystemExit(rc)
