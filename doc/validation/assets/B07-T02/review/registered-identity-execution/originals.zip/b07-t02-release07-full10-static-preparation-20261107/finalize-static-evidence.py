from pathlib import Path
import hashlib
import json
import zipfile

root = Path('/home/lyinn/project/Noetome')
base = root / '.artifacts/b07-t02-release07-full10-static-preparation-20261107'
drafts = [root / '.artifacts/b07-t02-release-builder-draft-07-20261107',
          root / '.artifacts/b07-t02-native-full10-draft-20261107']

def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

result = json.loads((base / 'actual.json').read_text())
assert result['exit_code'] == 0 and result['actual_wait_closed']
saved = base / 'prepare-static-drafts.py'
assert pin(saved.read_bytes()) == {k: result['saved_script'][k] for k in ('sha256', 'byte_length')}
sources = None
records = []
for draft in drafts:
    checks = json.loads((draft / 'static-checks.json').read_text())
    assert checks['AST'] and checks['whole_byte_restore_to_exact_parent']
    assert checks['help']['exit_code'] == 0 and checks['help']['actual_wait_closed']
    assert checks['source_before_after_equal']
    assert checks['expected_counts_not_run']['Windows_full'] == 807
    assert checks['expected_counts_not_run']['Windows_Store'] == 45
    assert checks['expected_counts_not_run']['Linux_Store'] == 47
    assert checks['executor'] == pin((draft / 'executor.py').read_bytes())
    assert checks['exact_four_current_SourcePins'] == (sources or checks['exact_four_current_SourcePins'])
    sources = checks['exact_four_current_SourcePins']
    records.append({'path': str(draft.relative_to(root)),
                    'executor': pin((draft / 'executor.py').read_bytes()),
                    'README': pin((draft / 'README.md').read_bytes()),
                    'static_checks': pin((draft / 'static-checks.json').read_bytes())})
current = {name: pin((root / name).read_bytes()) for name in sources}
assert current == sources
summary = {'schema_version': 1,
           'producer': 'artifact_only_release07_full10_static_summary',
           'drafts': records,
           'exact_four_current_source_pins': current,
           'operator_actual': pin((base / 'actual.json').read_bytes()),
           'saved_script': pin(saved.read_bytes()),
           'only_current_Run_Store_literals_and_full802_to807_changed': True,
           'whole_byte_parent_restore_and_AST_passed': True,
           'all_help_and_operator_actual_wait_closed': True,
           'expected_Windows_counts_not_run': {'workspace': 807, 'Store': 45},
           'expected_Linux_Store_count': 47,
           'Root_reported_Linux47_not_a_Windows_result': True,
           'artifact_bootstrap_failure_retained': True,
           'prepare': 'not_run', 'Native': 'not_run', 'D_read': 'not_run',
           'Cargo': 'not_run', 'HTTP': 'not_run',
           'source_standards_checker_authors_old_drafts': 'not_modified'}
(base / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
files = []
for folder in (base, *drafts):
    for item in folder.iterdir():
        if item.is_file() and item.suffix != '.zip' and item.name != 'manifest.json':
            files.append(item)
        elif item.name == 'operator-bootstrap-failure-01':
            files.extend(x for x in item.iterdir() if x.is_file())
parents = [root / '.artifacts/b07-t02-release-builder-draft-06-20261107/executor.py',
           root / '.artifacts/b07-t02-native-full09-draft-20261107/executor.py']
inventory = {}
archive = base / 'originals.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for item in sorted(files):
        member = str(item.relative_to(root))
        raw = item.read_bytes(); z.writestr(member, raw)
        inventory[member] = pin(raw)
    for i, item in enumerate(parents):
        member = f'parents/{i}-{item.parent.name}-executor.py'
        raw = item.read_bytes(); z.writestr(member, raw)
        inventory[member] = pin(raw)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(inventory)
    for member, wanted in inventory.items():
        assert pin(z.read(member)) == wanted
manifest = {'schema_version': 1, 'archive': pin(archive.read_bytes()),
            'member_count': len(inventory), 'members': inventory,
            'CRC_SHA_length_readback': True,
            'contains_current_product_source_bodies': False,
            'scope': 'static executor parent/current bodies, saved scripts, raw AST/help/operator receipts, README and bootstrap failure'}
(base / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'summary': pin((base / 'summary.json').read_bytes()),
                  'archive': pin(archive.read_bytes()), 'members': len(inventory),
                  'manifest': pin((base / 'manifest.json').read_bytes()),
                  'all_CRC_SHA_length_readback': True}, indent=2))
