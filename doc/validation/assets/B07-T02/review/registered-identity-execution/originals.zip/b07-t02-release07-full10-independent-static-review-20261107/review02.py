"""Only parse and compare the saved Home drafts; do not import or launch them."""
from pathlib import Path, PureWindowsPath
import ast
import difflib
import hashlib
import json
import os
import stat
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PINS = {}
CURRENT = {
    'crates/noetome-cli/src/request_run.rs': {'sha256': 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 'byte_length': 74943},
    'crates/noetome-cli/src/request_budget_store.rs': {'sha256': '57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646', 'byte_length': 165922},
    'scripts/verify_request_budget.py': {'sha256': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 'byte_length': 169966},
    'tests/test_verify_request_budget.py': {'sha256': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 'byte_length': 50420}}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    shape = lambda m: (m.st_dev, m.st_ino, m.st_mode, m.st_size, m.st_mtime_ns, m.st_nlink)
    with path.open('rb') as stream:
        actual = os.fstat(stream.fileno())
        raw = stream.read()
        final = os.fstat(stream.fileno())
    after = path.lstat()
    assert shape(before) == shape(actual) == shape(final) == shape(after)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': before.st_dev,
           'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'mode': before.st_mode, 'nlink': before.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

def assignments(tree):
    out = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                out[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    return out

old_run = 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c'
old_store = '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184'
records = []
for kind, old_dir, new_dir, expected_old, expected_new in [
    ('release', 'b07-t02-release-builder-draft-06-20261107', 'b07-t02-release-builder-draft-07-20261107',
     '83d34e', '0bed092e1e54705ebb5b977c21acc0debd663f402024705516f8799c0820e53f'),
    ('full', 'b07-t02-native-full09-draft-20261107', 'b07-t02-native-full10-draft-20261107',
     '1ece8f', 'f464591b3934bdaf80a2f74857eefd34c4b83bf74307141d41ff7aafef90426e')]:
    old_path = ROOT / '.artifacts' / old_dir / 'executor.py'
    new_path = ROOT / '.artifacts' / new_dir / 'executor.py'
    before = read(old_path)
    after = read(new_path)
    assert PINS[str(old_path)]['sha256'].startswith(expected_old)
    assert PINS[str(new_path)]['sha256'] == expected_new
    restored = after.decode().replace(CURRENT['crates/noetome-cli/src/request_run.rs']['sha256'], old_run)
    restored = restored.replace('74943', '74782').replace(CURRENT['crates/noetome-cli/src/request_budget_store.rs']['sha256'], old_store).replace('165922', '151556')
    if kind == 'full':
        restored = restored.replace('807', '802')
    assert restored.encode() == before
    tree = ast.parse(after)
    values = assignments(tree)
    assert values['SOURCE_PINS'] == CURRENT
    assert values['RUNNER_SHA'] == '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1'
    text = after.decode()
    assert 'all(context.expected.get(name) == expected for name, expected in SOURCE_PINS.items())' in text
    assert 'for name, expected in SOURCE_PINS.items():' in text
    if kind == 'release':
        assert values['CACHE_BASE_NAME'] == 'b07-t02-windows-release-pair-02-20261107'
        assert PureWindowsPath(values['CACHE_TARGET_NATIVE']) == PureWindowsPath(r'D:\Noetome\.artifacts\b07-t02-windows-release-pair-01-20261107\build-target')
        assert 'release-cli-build.json' in text and 'release-driver-build.json' in text
        assert text.count("'old':") == 2
    else:
        assert "result['rust_totals'] == {'passed': 807, 'failed': 0, 'ignored': 0}" in text
    for suffix, raw in [('before.py', before), ('after.py', after)]:
        with (OUT / (kind + '-' + suffix)).open('xb') as stream:
            stream.write(raw)
    difference = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), kind+'-old', kind+'-new'))
    with (OUT / (kind + '.patch')).open('x') as stream:
        stream.write(difference)
    records.append({'kind': kind, 'old_original': str(old_path), 'new_original': str(new_path),
                    'before_pin': PINS[str(old_path)], 'after_pin': PINS[str(new_path)],
                    'reverse_only_two_source_SHA_lengths_and_full807_to802_exact_whole_byte_equal': True,
                    'AST_parsed_without_import_or_help_execute': True,
                    'all_other_metadata_controls_cache_source_FP_selected_outerwait_code_byte_equal': True})

# The five added definitions are common-platform tests; Windows-only setup is
# inside their bodies. This supports planned +5, not an execution count.
store = read(ROOT / '.artifacts/b07-t02-registered-identity-source-independent-review-20261107/request_budget_store.rs.after-e4-57c1')
assert hashlib.sha256(store).hexdigest() == CURRENT['crates/noetome-cli/src/request_budget_store.rs']['sha256']
start = store.index(b'    #[test]\n    fn budget_registered_identity_checks_known_file_directory_without_byte_binding(')
end = store.index(b'    fn literal_database_header(', start)
definitions = store[start:end]
assert definitions.count(b'    #[test]\n') == 5
assert b'    #[cfg(windows)]\n    #[test]' not in definitions and b'    #[cfg(unix)]\n    #[test]' not in definitions
static_root = ROOT / '.artifacts/b07-t02-release07-full10-static-preparation-20261107'
operator = json.loads(read(static_root / 'actual.json'))
assert operator['PID'] == 834648 and operator['exit_code'] == 0 and operator['actual_wait_closed'] is True
assert operator['Native'] == operator['prepare'] == operator['Cargo'] == operator['HTTP'] == 'not_run'
program = Path(operator['saved_script']['path'])
program_raw = read(program)
assert hashlib.sha256(program_raw).hexdigest() == operator['saved_script']['sha256'] and len(program_raw) == operator['saved_script']['byte_length']
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_Home_only_release07_full10_draft_static_review', 'status': 'passed_static_review',
          'records': records, 'source_pins_literal_exact': CURRENT,
          'unchanged_scope': ['93/129/129/1913 complete named-map algorithm', 'physical01 object cache distinct from immutable02 evidence7 anchors',
                              '8 controls and 4 full source SHA/length guards', 'metadata before initial source/control reads and after actual commands',
                              'selected registration and aliases before first command', 'fresh dual Cargo/FP/probes and actual outer waits',
                              'full Native fresh fmt/check/tests/build/Python/PowerShell execution; no old test result reuse'],
          'five_added_common_test_definitions': True, 'planned_full_Native_Rust_count': 807,
          'planned_Linux_budget_module_count': 47, 'planned_Windows_budget_module_count': 45,
          'planned_counts_are_not_actual_results': True, 'actual_compile_FP_and_new_selected_programs': 'pending_actual_execution',
          'peer_static_operator_actual_PID': operator['PID'], 'peer_static_operator_exit_code': operator['exit_code'],
          'all_original_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal': True,
          'specific_blocking_findings': [], 'initial_collector_failure': 'review.py used an overescaped manual expected string for the unchanged Windows cache path. AssertionError before report/source copies; review02 compares canonical PureWindowsPath. Original script/stdout/stderr retained; no product or draft changed.', 'new_D_reads_product_HTTP_Cargo_Native_invocations': 0, 'original_pins': PINS}
with (OUT / 'actual.json').open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
raw = read(OUT / 'actual.json')
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}))
