"""Freeze artifact stage operators before actual Native pair handoff. No subprocess."""
from pathlib import Path,PureWindowsPath
import hashlib,json,ast
REPO=Path('/home/lyinn/project/Noetome')
HERE=Path(__file__).parent
COPY=HERE/'frozen-bundle'
ORIGINAL=REPO/'.artifacts/b07-t02-shared-header-native-preparation-20261107'
NATIVE=PureWindowsPath('D:/Noetome/.artifacts')
PYTHON=NATIVE/'b03-t02-python312/Scripts/python.exe'
WRAPPER=NATIVE/'b07-t02-native-registered-identity-wrapper-01-20261107'
NORMALIZED=NATIVE/'b07-t02-native-registered-identity-normalized-source-01-20261107'
ROOTS={
 'ordinary':NATIVE/'b07-t02-request-native-registered-identity-ordinary-elapsed-01-20261107',
 'three':NATIVE/'b07-t02-request-native-registered-identity-three-target-01-20261107',
 'full':NATIVE/'b07-t02-request-native-registered-identity-full-01-20261107',
}
PINNED={
 'normalize_build.py':'9fbc7c68c60c7f06bbd286d65b275fc26df99bc56326ce6ef4d91bda3cdd40af',
 'narrow.py':'a7ef5424797ec59d5aebc8382ae26acb91a0885c3ff40ccb07e492b4d7d8bff3',
 'run_stage.py':'11ab48b314f2ac95eed0c507d7fca13f318ec0b012f093442a56e5dc932d19ae',
}
FOUR={
 'crates/noetome-cli/src/request_run.rs':'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e',
 'crates/noetome-cli/src/request_budget_store.rs':'57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646',
 'scripts/verify_request_budget.py':'3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7',
 'tests/test_verify_request_budget.py':'42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348',
}


def capture(path):
 before=path.stat();assert path.is_file() and not path.is_symlink() and before.st_nlink==1
 raw=path.read_bytes();after=path.stat()
 fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)
 assert fields(before)==fields(after)
 return raw,{'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'WSL_device':before.st_dev,'WSL_inode':before.st_ino,'mtime_ns':before.st_mtime_ns,'nlink':before.st_nlink,'metadata_captured_before_first_read':True}


def save(path,raw):
 with path.open('xb') as f:f.write(raw)


def ps_quote(value):return "'"+str(value).replace("'","''")+"'"


def write_stage(stage):
 params=['    [Parameter(Mandatory=$true)][string]$NativeBuildRoot']
 if stage=='normalize':
  params += ["    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$Fingerprint", "    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$CliSha", "    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$DriverSha"]
 lines=['# Prepared only; execute after explicit Root closed-pair/preflight GO. Actual pins are mandatory parameters.', 'param(\n'+',\n'.join(params)+'\n)', "$ErrorActionPreference = 'Stop'",
        "$repo = Join-Path $NativeBuildRoot 'repo'", "$cli = Join-Path $NativeBuildRoot 'selected\\noetome.exe'", "$driver = Join-Path $NativeBuildRoot 'selected\\noetome-cli-testdriver.exe'",
        "$runtime = [ordered]@{ PID = $PID; PSVersion = $PSVersionTable.PSVersion.ToString(); Platform = 'actual_native_PowerShell'; Stage = "+ps_quote(stage)+"; StartedUtc = [DateTime]::UtcNow.ToString('o') }",
        '[System.IO.File]::WriteAllText('+ps_quote(WRAPPER/('powershell-'+stage+'-runtime.json'))+", ($runtime | ConvertTo-Json -Depth 8), [System.Text.UTF8Encoding]::new($false))"]
 stage_root=NATIVE/('b07-t02-native-registered-identity-'+stage+'-stage-01-20261107')
 runtime_record=NORMALIZED/'primary-readback.json' if stage=='normalize' else ROOTS[stage]/('runtime.json' if stage=='full' else 'native-wrapper-runtime.json')
 parts=['&',ps_quote(PYTHON),ps_quote(WRAPPER/'run_stage.py'),ps_quote('--new-stage-root'),ps_quote(stage_root),ps_quote('--runtime-record'),ps_quote(runtime_record),ps_quote('--'),ps_quote(PYTHON)]
 if stage=='normalize':
  parts += [ps_quote(WRAPPER/'normalize_build.py'),ps_quote('--native-build-root'),'$NativeBuildRoot',ps_quote('--new-root'),ps_quote(NORMALIZED),ps_quote('--expected-fingerprint'),'$Fingerprint',ps_quote('--expected-cli-sha'),'$CliSha',ps_quote('--expected-driver-sha'),'$DriverSha']
 elif stage in ('ordinary','three'):
  parts += [ps_quote(WRAPPER/'narrow.py'),ps_quote('--mode'),ps_quote('ordinary-elapsed' if stage=='ordinary' else 'three-targets'),ps_quote('--repo'),'$repo',ps_quote('--source-pins'),ps_quote(NORMALIZED/'source-before.json'),ps_quote('--cli'),'$cli',ps_quote('--driver'),'$driver',ps_quote('--build-receipt'),ps_quote(NORMALIZED/'actual.json'),ps_quote('--new-root'),ps_quote(ROOTS[stage])]
 else:
  lines += ["# Mandatory sequencing: the saved three-target actual.json must show all3 passed,3 actual own-PID kills and waits before executing this full stage.", "$checker = Join-Path $repo 'scripts\\verify_request_budget.py'", "$fixture = Join-Path $repo 'fixtures\\run-api-budget-v1'"]
  parts += ['$checker',ps_quote('--cli'),'$cli',ps_quote('--test-driver'),'$driver',ps_quote('--build-receipt'),ps_quote(NORMALIZED/'actual.json'),ps_quote('--fixture'),'$fixture',ps_quote('--new-root'),ps_quote(ROOTS[stage]),ps_quote('--full')]
 lines += [' '.join(parts),'exit $LASTEXITCODE']
 raw=('\n'.join(lines)+'\n').encode()
 assert b'4650f37' not in raw and b'89136b36' not in raw and b'38a1377c' not in raw
 save(COPY/(stage+'.ps1'),raw)
 return {'stage':stage,'script':str(COPY/(stage+'.ps1')),'pin':capture(COPY/(stage+'.ps1'))[1],'native_stage_root':str(stage_root),'runtime_record':str(runtime_record)}


assert not COPY.exists()
COPY.mkdir()
originals={}
for name,sha in PINNED.items():
 raw,pin=capture(ORIGINAL/name);assert pin['sha256']==sha
 save(COPY/name,raw);ast.parse(raw)
 originals[name]={'original':str(ORIGINAL/name),'pin':pin,'copied_pin':capture(COPY/name)[1]}
source_pins={}
for name,sha in FOUR.items():
 _,pin=capture(REPO/name);assert pin['sha256']==sha
 source_pins[name]=pin
author=REPO/'fixtures/run-api-budget-v1/frozen-sha256.json'
_,author_pin=capture(author);assert author_pin['sha256']=='ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272'
stages=[write_stage(stage) for stage in ('normalize','ordinary','three','full')]
for item in originals.values():
 _,after=capture(Path(item['original']));assert after==item['pin']
for name,pin in source_pins.items():
 _,after=capture(REPO/name);assert after==pin
_,author_after=capture(author);assert author_after==author_pin
plan={'status':'prepared_only_registered_identity_native_handoff_pending_not_executed',
      'future_native_build_root':None,'actual_selected_FP':None,'actual_original_CLI':None,'actual_original_driver':None,
      'source_member_count_actual':None,'source_zip_member_count_actual':None,'actual_runtime_PIDs':None,
      'frozen_current_four_source_pins':source_pins,'frozen_author_manifest':author_pin,
      'frozen_bundle_originals':originals,'source_ID_mtime_bytes_before_after_equal':True,
      'future_native_wrapper_root':str(WRAPPER),'future_normalized_root':str(NORMALIZED),
      'new_owned_roots':{stage:str(root) for stage,root in ROOTS.items()},'stages':stages,
      'required_before_normalize':['Root actual new registered-identity closed pair receipt and actual release Cargo/CLI/driver FP agreement',
                                  'AuditLive completed current two whole MZ bodies SHA/len and before-first-read native volume/index/mtime/len/singlelink/no-reparse identity proof',
                                  'All explicit source members/five auxiliary source ZIP originals,8primary controls and four named maps actually pinned to e4d598e2/57c1d73b/3b/428',
                                  'Source guards and originalPE/FP exact new handoff; Root explicit GO and sole Native/D timing ownership'],
      'primary_controls':['selected-build-receipt.json','release-build-receipt.json','snapshot.json','source-after.json','source-originals.zip','precise-source-scopes.json','strong-metadata-before.json','strong-metadata-after.json'],
      'four_named_maps':['direct_build_rs_input_files','cli_cargo_and_test_files','all_workspace_rust_files','conservative_rust_dependency_files'],
      'expected_source_counts_not_actual_results':{'repo':2056,'source_zip':2061},
      'ordinary_extra_rule':'Run once; preserve every actual product/script failure or natural0kill NoFit as history. Final failed status expected3 is the independently proven one-argument artifact correction only. Does not count in main62.',
      'three_rule':'Fixed backoff/elapsed/accepted sequence once. Require all3 passed with real own alive PID force-kill nonzero exit and wait plus complete preserved originals. Natural exit is not OSkill. Any miss stops without repeat or main62.',
      'full_rule':'Full62 once only after three real kill/wait passes and Root GO; no oldLinux/currentSource Native or extra-target pass reuse.',
      'author_limits_unmodified':{'unit_a_elapsed_ms':1500,'backoff_ms':1000,'API_timeout_ms':200,'expired_wait_ms':1700,'R':8310},
      'new_Native_processes':0,'new_CLI_calls':0,'new_driver_calls':0,'new_HTTP_requests':0,
      'syntax_scope':'Python AST parse only; PowerShell templates are written but have not been parsed/executed by native PowerShell. No body pins/FP/PID are invented.'}
save(HERE/'plan.json',(json.dumps(plan,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'status':plan['status'],'plan_pin':capture(HERE/'plan.json')[1],'stages':[(x['stage'],x['pin']['sha256']) for x in stages]}))
