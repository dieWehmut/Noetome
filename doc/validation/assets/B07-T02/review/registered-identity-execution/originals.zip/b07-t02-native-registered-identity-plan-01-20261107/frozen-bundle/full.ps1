# Prepared only; execute after explicit Root closed-pair/preflight GO. Actual pins are mandatory parameters.
param(
    [Parameter(Mandatory=$true)][string]$NativeBuildRoot
)
$ErrorActionPreference = 'Stop'
$repo = Join-Path $NativeBuildRoot 'repo'
$cli = Join-Path $NativeBuildRoot 'selected\noetome.exe'
$driver = Join-Path $NativeBuildRoot 'selected\noetome-cli-testdriver.exe'
$runtime = [ordered]@{ PID = $PID; PSVersion = $PSVersionTable.PSVersion.ToString(); Platform = 'actual_native_PowerShell'; Stage = 'full'; StartedUtc = [DateTime]::UtcNow.ToString('o') }
[System.IO.File]::WriteAllText('D:\Noetome\.artifacts\b07-t02-native-registered-identity-wrapper-01-20261107\powershell-full-runtime.json', ($runtime | ConvertTo-Json -Depth 8), [System.Text.UTF8Encoding]::new($false))
# Mandatory sequencing: the saved three-target actual.json must show all3 passed,3 actual own-PID kills and waits before executing this full stage.
$checker = Join-Path $repo 'scripts\verify_request_budget.py'
$fixture = Join-Path $repo 'fixtures\run-api-budget-v1'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-registered-identity-wrapper-01-20261107\run_stage.py' '--new-stage-root' 'D:\Noetome\.artifacts\b07-t02-native-registered-identity-full-stage-01-20261107' '--runtime-record' 'D:\Noetome\.artifacts\b07-t02-request-native-registered-identity-full-01-20261107\runtime.json' '--' 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' $checker '--cli' $cli '--test-driver' $driver '--build-receipt' 'D:\Noetome\.artifacts\b07-t02-native-registered-identity-normalized-source-01-20261107\actual.json' '--fixture' $fixture '--new-root' 'D:\Noetome\.artifacts\b07-t02-request-native-registered-identity-full-01-20261107' '--full'
exit $LASTEXITCODE
