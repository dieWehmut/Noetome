"""Actual final06 source/program/server and special-phase original readback."""
from pathlib import Path
import sys,json,hashlib,stat,sqlite3,importlib.util
sys.dont_write_bytecode=True
REPO=Path('/home/lyinn/project/Noetome')
ROOT=REPO/'.artifacts/b07-t02-request-full-06-20261107'
OUT=Path(__file__).parent
pins={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 fp={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns};assert pins.setdefault(str(p),fp)==fp;return b
def copy(p,n):
 b=read(p);q=OUT/n
 if not q.exists():q.write_bytes(b)
 assert read(q)==b;return b
a=json.loads(read(ROOT/'actual.json'));assert len({c['PID'] for c in a['commands']})==397
bind=json.loads(read(ROOT/'source-build-binding.json'));pair=Path(bind['explicit_build_receipt']).parent
programs={}
for name,key in [('noetome','cli'),('request-test-driver','test_driver')]:
 b=read(pair/name);read(pair/name);p=pins[str(pair/name)];assert all(p[k]==bind['receipt_original'][key][k] for k in ['sha256','byte_length']);programs[str(pair/name)]={**p,'complete_original_body_double_read_equal':True}
source=[]
for name,p in bind['source_members'].items():
 b=read(REPO/name);assert hashlib.sha256(b).hexdigest()==p['sha256'] and len(b)==p['byte_length'];source.append({'path':name,'actual':pins[str(REPO/name)],'matches_actual_compiled_source_member':True})
assert len(source)==130
incoming=receipts=0
for p in sorted(ROOT.glob('*/server/server-receipts.json')):
 s=json.loads(read(p));assert not s['errors'] and len(s['incoming'])==len(s['receipts'])==s['observed_HTTP_request_count'] and all(r['body_complete'] for r in s['incoming']);incoming+=len(s['incoming']);receipts+=len(s['receipts'])
assert incoming==receipts==70
sys.path[:0]=[str(ROOT/'checker-source'),str(REPO/'scripts')];spec=importlib.util.spec_from_file_location('final06_special',ROOT/'checker-source/verify_request_budget.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
case=ROOT/'unknown-remote-completion-retained--OS-kill-after-accepted';pre=json.loads(copy(case/'actual-prekill-chain.json','accepted-actual-prekill-chain.json'));old=json.loads(read(case/'independent-audit.json'));kill=next(c for c in a['commands'] if c.get('explicit_request_test_selection',{}).get('NOETOME_REQUEST_TEST_RUN_ROOT')==str(case/'run-main') and c['wait_action']=='actual_OS_force_kill_and_wait')
assert pre['observed_before_kill_utc_ns']<kill['kill_requested_utc_ns']<kill['finished_utc_ns'] and kill['exit_code']==-9
ledger,e=m.read_authority(case/'budget',fixture=REPO/'fixtures/run-api-budget-v1',authority_config=case/'authority-config.json',expected_fingerprint=bind['receipt_original']['actual_cli_fingerprint'],selected_run_roots=[case/'run-main'])
with sqlite3.connect((case/'budget/control/budget.sqlite').as_uri()+'?mode=ro&immutable=1',uri=True) as conn:rows=list(conn.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
length=len(pre['pre_release_chain']);assert [json.loads(r[2]) for r in rows[:length]]==pre['pre_release_chain'];before=m.reconstruct_events(ledger.authority,rows[:length]);b=m.settled_success_attempts(before,'unit-b');assert len(b)==1
key,bp=next(iter(b.items()));assert ledger.attempts[key]==bp
assert all(m.verify_attempt_originals(attempt,before.runs[k[0]],REPO/'fixtures/run-api-budget-v1') for k,attempt in before.attempts.items())
aa_key,aa=next((k,v) for k,v in before.attempts.items() if k[1]=='unit-a');assert aa['state']=='may_send' and aa['receipt'] is None and not aa['transport_sealed']
server=json.loads(read(case/'server/server-receipts.json'));assert len([r for r in server['receipts'] if r['unit_id']=='unit-b'])==1
hand=pre['actual_selected_A_handshake'];assert hand['pid']==kill['PID'] and hand['will_wait'] is True and hand['event']=='dispatch_intent_commit' and hand['unit']=='unit-a' and hand['attempt']==1 and hand['compiler_fingerprint']==bind['receipt_original']['actual_cli_fingerprint']
assert kill['explicit_request_test_selection']['NOETOME_REQUEST_TEST_EVENT']=='dispatch_intent_commit'
assert hand['sequence']<length and rows[hand['sequence']-1][0]==hand['sequence']
held_event=json.loads(rows[hand['sequence']-1][2]);assert held_event['event']['kind']=='may_send' and m.validate_key(held_event['event']['key'])==aa_key
command=ROOT/'commands'/f"{kill['number']:04d}";releases=list(command.glob('release-*.json'));assert len(releases)==1
release=json.loads(copy(releases[0],'accepted-actual-release.json'));assert release['handshake']==hand and release['release_bytes']=='release LF'
assert len(pre['B_actual_server_receipt'])==len(pre['A_actual_server_acceptance'])==1
bserver=next(r for r in server['receipts'] if r['unit_id']=='unit-b');aserver=next(r for r in server['receipts'] if r['unit_id']=='unit-a' and r['attempt_no']==1)
assert bserver==pre['B_actual_server_receipt'][0] and all(aserver.get(k)==v for k,v in pre['A_actual_server_acceptance'][0].items())
assert aserver['response_before_write_utc_ns']>kill['finished_utc_ns'] and aserver['response_flush_utc_ns']>kill['finished_utc_ns'] and aserver['response_byte_length']==0
assert not (case/'run-main/attempts/unit-a/attempt-0001/response.bin').exists() and not (case/'run-main/attempts/unit-a/attempt-0001/transport-receipt.json').exists()
assert bserver['response_flush_utc_ns']<release['release_utc_ns']<=aserver['request_received_utc_ns']<pre['observed_before_kill_utc_ns']<kill['kill_requested_utc_ns']<kill['finished_utc_ns']
bsettle=next(r for r in before.rows if r['event']['kind']=='receipt_settled' and m.validate_key(r['event']['key'])==key)
assert m.utc_ns(bsettle['at_utc'])<release['release_utc_ns']
pre_audit=pre['pre_release_full_original_audit'];post_audit=pre['stable_postkill_full_original_audit']
assert pre_audit['sequence']==length and pre_audit['last_sha256']==rows[length-1][3] and pre_audit['totals']==before.totals() and pre_audit['before']==pre_audit['after']
post_length=post_audit['sequence'];post_before=m.reconstruct_events(ledger.authority,rows[:post_length]);assert post_audit['last_sha256']==rows[post_length-1][3] and post_audit['totals']==post_before.totals() and post_audit['before']==post_audit['after']
assert post_before.attempts[aa_key]['state']=='may_send' and post_before.attempts[aa_key]['receipt'] is None and not post_before.attempts[aa_key]['transport_sealed']
assert post_before.attempts[key]==bp and ledger.attempts[aa_key]['state']=='unknown' and ledger.attempts[aa_key]['receipt'] is None
assert before.totals()==post_before.totals()=={'accounted_tokens':700,'held_tokens':8310,'dispatched_requests':2,'held_requests':0}
accepted={'actual_killed_PID':kill['PID'],'actual_wait_exit_code':-9,'actual_A_selected_handshake':hand,'actual_release':release,'B_Known700_settled_before_release_utc_ns':m.utc_ns(bsettle['at_utc']),'A_actual_server_accept_utc_ns':aserver['request_received_utc_ns'],'pre_observation_utc_ns':pre['observed_before_kill_utc_ns'],'kill_requested_utc_ns':kill['kill_requested_utc_ns'],'release_to_A_actual_accept_ms':(aserver['request_received_utc_ns']-release['release_utc_ns'])/1e6,'A_actual_accept_to_kill_ms':(kill['kill_requested_utc_ns']-aserver['request_received_utc_ns'])/1e6,'pre_release_original_chain_sequence':length,'stable_postkill_original_chain_sequence':post_length,'pre_release_B_actual_unit_terminal':next(r['units']['unit-b']['outcome'] for r in before.runs.values()),'post_B_unit_terminal':next(r['units']['unit-b']['outcome'] for r in ledger.runs.values()),'B_same_original_key_plan_receipt_files_exact':True,'B_full_original_source_body_wire_gold_before_after_revalidated':True,'B_HTTP_before_and_after_total':1,'A_before_state':'may_send','A_before_trusted_receipt':None,'A_before_transport_seal':False,'A_postresume_state':'unknown','A_postresume_original_R_retained':8310,'totals_after':ledger.totals(),'pre_release_SQL_chain_equals_real_current_prefix':True,'controlled_test_schedule_not_natural_network_concurrency':True,'A_late_server_empty_200_response_after_client_kill_utc_ns':aserver['response_flush_utc_ns'],'A_pre_accept_snapshot_fields_unchanged_final_server_metadata_added_after_kill':True,'A_API_original_response_and_transport_remain_absent':True}

special=[]
for short,error in [('synchronized-known-usage','原wire独立用量与结算不等'),('synchronized-candidate-wrapper','已批准候选与原wire/请求绑定不等')]:
 croot=ROOT/('protection-'+short);attempt=next((croot/'run-main/attempts/unit-a').iterdir());j=copy(attempt/'validation.json',short+'-actual-validation.json');md=copy(attempt/'validation.md',short+'-actual-validation.md');embedded=md.split(b'```json\n',1)[1].split(b'\n```\n',1)[0];assert j==embedded and b'\r\n' not in md
 commands=[]
 for c in a['commands']:
  label=c.get('label') or ''
  if short in label and 'artifact protection' in label:
   d=ROOT/'commands'/f"{c['number']:04d}";r=copy(d/'stderr.bin',short+f"-PID{c['PID']}-stderr.bin");copy(d/'receipt.json',short+f"-PID{c['PID']}-receipt.json");assert error in r.decode() and '双报告原字节不等' not in r.decode() and c['exit_code']==3;commands.append({'PID':c['PID'],'exit_code':3,'specific_actual_diagnostic':r.decode().strip(),'stderr':c['stderr']})
 assert len(commands)==2;special.append({'case_id':croot.name,'JSON_and_embedded_MD_byte_length':len(j),'exact_original_byte_equal_LF':True,'actual_specific_refusals':commands})
r={'producer':'independent_final06_actual_program_source_special_phase_readback','status':'passed','397_actual_PIDs_unique':True,'all_70_actual_incoming_complete_UUID_receipts_equal':True,'all_actual_program_complete_bodies_double_readback':programs,'all_current_130_compiled_source_files_byte_equal':source,'actual_compiled_source_archive':bind['source_archive'],'accepted_special_actual_original_evidence':accepted,'specific_Core_forgery_gates':special,'no_product_HTTP_Cargo_invocations_by_auditor':True,'native_acceptance_not_claimed':True,'original_actual_pins':pins}
for p in list(pins):
 if not p.startswith(str(OUT)):read(Path(p))
(OUT/'special-pair-and-source-readback02.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':'passed','actualSHA':hashlib.sha256((OUT/'special-pair-and-source-readback02.json').read_bytes()).hexdigest(),'length':(OUT/'special-pair-and-source-readback02.json').stat().st_size,'accepted':accepted,'Core_targets':special}))
