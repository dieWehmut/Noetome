# B07-T02 current Linux06 独立原件审查

本包直接重新读取 current2931 checker、helper4235、Root clean-build pair05/FP58ed 的 Linux06 原件，不复用旧 eb6/pair04 完成结论。主 actual.json 实际通过：62组，364ordinary CLI+33driver=397唯一PID，23次真实SIGKILL/wait全部-9；70incoming/UUIDreceipt；39有效流程账本511完整SQL事件及独立算术，23保护组另行原库存/CLI拒绝检查。原来源、44作者payload+freeze、原请求5238B/预留8310、原wire/Core/gold、明确opening、两单元/跨Run近cap、同SHA不同request各700、未知held、原deadline、退避100/200与explicitREQUEST_INTERRUPTED、新attempt而非同key重发均复算。原完整root文件/目录身份、mtime、SHA前后相等，无bytecode写入。

special-pair-and-source-readback02.json 独立实读完整168867688B CLI及198828640B driver各两遍，全部130编译源码与当前实际文件相等，并核397实际PID唯一、70incoming完整。原大ELF本体不在本审查ZIP；保留Rootpair05明确路径和SHA，主checker原件ZIP亦独立核所有3895 CRC/SHA/长度/原identity/mtime/bytes，包外来源路径和pin明确记录。

accepted场景是受控调度，不据此宣称无扰动网络并发。真实driver PID749925、A dispatch_intent_commit seq6/将wait；B Known700/full200/validated/sealed seq9且原件完整审查之后记录精确release LF；A在release后31.891174ms被服务接收、实际接收后5.157259ms SIGKILL/wait -9。真实SQL前9条与pre_release_chain完全相同；B该时尚无unit_terminal，后续同key/plan/receipt/files与原wire/gold相等，B实际HTTP始终1。A旧MaySend无API response/transport/receipt，显式resume后保守Unknown8310，新request独立Known700，最终Known1400+held8310/dispatch3。

第一次supplement把accept时的server快照误要求与之后最终server整对象相等而失败，原script/stdout/stderr保留。实际差别仅A服务在client已SIGKILL之后约500ms新增空200 response元数据；旧快照所有已有字段相等，迟到元数据时间严格晚于client退出。second supplement按这条真实时间关系核对，且A API response.bin/transport-receipt.json始终不存在，不以服务之后能写header推成API可信framing或退款。原运行与判据源码都未修改。

Root-build-production-prefix-readback.json另从Root实际pair04/pair05原源ZIP读取完整成员，独立来源于修改者before/after副本，生产prefix68173字节相等；删除唯一3行/68B cfg(test)插入恢复旧完整606ec字节。helper由此代理修改，其作者范围证据与Root/Store代理的独立源码复核分别记录，不冒充第三方修改审查。

包内specific Core forgery原件核到 compact JSON与MD内嵌原byte精确相同，四个真实ordinary CLI分别被『原wire独立用量与结算不等』或『已批准候选与原wire/请求绑定不等』门禁拒绝，不把更早MD字节不等替代这些门禁。

本审查没有执行产品、Cargo或HTTP，不读取生产凭据/累计账本/Vault。Native05完整回归及Native03全矩阵仍由实际Windows结果单独验收，本包不推定原生通过。
