from pathlib import Path
import hashlib,json,stat,zipfile
ROOT=Path(__file__).parent
OUT=ROOT/'package';OUT.mkdir(exist_ok=False)
main=json.loads((ROOT/'actual.json').read_bytes())
special=json.loads((ROOT/'special-pair-and-source-readback02.json').read_bytes())
peer=json.loads((ROOT/'peer-archive-readback.json').read_bytes())
assert main['status']=='passed_independent_final_Linux_original_behavior_audit' and special['status']==peer['status']=='passed'
members={p.name:p for p in sorted(ROOT.iterdir()) if p.is_file() and not p.name.startswith('package')}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
manifest={};archive=OUT/'originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in members.items():
  body,pin=read(p);z.writestr(name,body)
  manifest[name]={'original_path':str(p),'original_pin':pin,'sha256':pin['sha256'],'byte_length':len(body)}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)
 for name,p in members.items():
  body,pin=read(p);assert pin==manifest[name]['original_pin'] and z.read(name)==body
  manifest[name]['full_CRC_SHA_length_actual_original_identity_mtime_bytes_before_after_equal']=True
(OUT/'manifest.json').write_bytes(json.dumps({'members':manifest},ensure_ascii=False,indent=2).encode()+b'\n')
actual={'producer':'independent_current_Linux06_budget_original_review_archive','status':'passed','members':len(manifest),'archive':read(archive)[1],'manifest':read(OUT/'manifest.json')[1],'all_CRC_SHA_length_original_before_after_passed':True,'actual_scope':{'ordinary_CLI':364,'explicit_driver':33,'distinct_actual_PIDs':397,'real_SIGKILL_wait_exit_minus9':23,'groups':62,'actual_complete_HTTP_incoming_and_UUID_receipts':70,'valid_flow_SQL_events':511,'valid_flow_ledgers':39,'protection_groups':23,'compiled_source_members':130,'checker_original_archive_members_independently_read':peer['member_count']},'original_actual_main_sha256':read(ROOT/'actual.json')[1]['sha256'],'source_special_readback_sha256':read(ROOT/'special-pair-and-source-readback02.json')[1]['sha256'],'frozen_checker_SHA':'2931ab990222ba3fa3eda3441563b69e124001da659e025c27de3849e7225968','helper_SHA':'4235b2cfcd2344e7cfc57b7432a2182997532c19f7f9e32f98936931b1354469','actual_Linux_FP':'58ed50aab2a57014d04fceb0e533ad348d3c28b3e6273b8b90b552dde981aec4','native_or_full_workspace_acceptance_not_claimed':True,'product_HTTP_Cargo_invocations':0,'large_program_source_peerZIP_bodies_not_in_reviewer_ZIP':True}
(OUT/'actual.json').write_bytes(json.dumps(actual,ensure_ascii=False,indent=2).encode()+b'\n')
print(json.dumps({'status':actual['status'],'members':len(manifest),'archive':actual['archive'],'manifest':actual['manifest'],'actual':read(OUT/'actual.json')[1]}))
