# B07-T02 actual Native release06 operator closure

本次只实际完成两条release构建、driver列举及CLI/driver编译FP探针，不执行全Rust802、全Python527或HTTP行为62。新源码Run b393 /Store2e97 /checker3b /test428固定；full09仍未prepare/launch。

prepare operator822108/child822109实际wait0，54.996s，source2056 names/actualID/mtime/size/singlelinks前后一致。archive2061的所有CRC/SHA/length和repo/native/currentHome/5aux原byte相等；snapshot f3e2925a...629330B、sourceZIP4c2b2fc1...8237137B。八controls fixed metadata均保持。

launch operator822798/child822799实际wait0，interop822802由原launcher actualwait退出0，总400.64375s。原argv、环境名称白名单、stdoutstderr、PIDs/时间均在prepare/launch start/actual及outer-native-launch/result。没有读取真实凭据或运行外部服务。

11实际command全部exit0、无timeout、源/声明资产/sentinel guard true，完整argv/开始结束UTC/输出pins见native-commands.json及逐命令原receipt：

- rustup-which-cargo66740 /1.703s
- rustup-which-rustc66848 /2.093s
- rustup-which-rustfmt81332 /1.891s
- rustup-which-rustdoc25292 /1.766s
- rustc-version39492 /1.860s
- cargo-version46548 /1.750s
- release-cli-build78648 /112.343s
- release-driver-build60524 /129.734s
- test-driver-list71324 /1.875s
- actual-cli-compiler-probe50132 /1.844s
- actual-driver-compiler-probe31968 /2.609s

两个实际CargoJSON及程序探针FP一致 `c2f1d498cb7c9da53a768c978ba01ea2b16837855a7a2304dc9cea63513f9e00`，opt_level3/debug_assertionsfalse。CLI完整body09535d63b995673af12ac2a4fd101076bce82806cb2a26e2d72e9dcad0250325 /16489472B；driver4cfaa3cde16ea473a1da8b2cd81a647dfbd0b44b2f05f003b7fc3718bec03e68 /22838784B。原selected都ordinary singlelink/MZ且actual body==receipt，metadata读回前后相等。所附operator WSL stat是补充，Native实际固定metadata original保存在strong-metadata before/after，不混称不同OS的stat dev/ino为同个表示。

Native固定metadata2065→2067只新增两selected程序，其余ID/mtime/len/nlink逐项相等。四个完整具名scope独立为93 direct、129 CLI/Cargo/test、129 allworkspaceRust、1913 conservative；129两表的文件集合不同，不能混称编译指纹129。exact两source old/new delta及七份旧cache evidence保持，physicalrelease01与独立evidence02，不复用测试/旧程序。

实际driver --list BudgetStore40定义已保存原输出和budget-module-list.json；列举不是执行40测试，也不是Windows全802通过。新program/schema主入口仍selected-build-receipt.json的原nested结构（source_snapshot/source_archive/cli/test_driver/actual_compiler_fingerprint）；release-build-receipt.json附双Cargo/context守卫。独立checker需要flat adapter时只能从这些实际原件派生，不能猜来源或改公开schema。

所有记录程序阶段成功只证明此source-bound release候选构建及探针；原Native4650 NoFit历史不复用，此新Native ordinary/3targets/62等待Root独立preflight后统一GO。此操作器没有授权这些HTTP场景，全部由独立owner在唯一机器窗口执行。最后完整生产/std/source没有被操作器改写。
