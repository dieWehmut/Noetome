"""Package closed reviewer-local preflight originals only; no D reads after GO."""
from pathlib import Path
import hashlib,json,os,stat,zipfile,binascii
R=Path('/home/lyinn/project/Noetome/.artifacts/b07-t02-native-release05-independent-preflight-20261107')
O=Path(__file__).parent/'package'
def capture(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 with p.open('rb') as f:a=os.fstat(f.fileno());b=f.read();z=os.fstat(f.fileno())
 t=p.lstat();shape=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mtime_ns,q.st_nlink);assert shape(s)==shape(a)==shape(z)==shape(t)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
def save(p,d):
 with p.open('x') as f:f.write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
main=json.loads(capture(R/'actual.json')[0]);supp=json.loads(capture(R/'runtime-cache-supplement.json')[0]);native=json.loads(capture(R/'actual-native-metadata.json')[0])
assert main['status']=='passed_independent_closed_Native_release05_initial_preflight' and supp['status']==native['status']=='passed'
assert main['actual_compiler_fingerprint']=='4650f37f3a11299739f8ace768ca6cb5317d3ecb6957d9d0edba26b9981fe680'
assert main['source_ZIP_member_count']==2061 and len(main['source_members2056'])==2056 and native['native_file_count']==2067
assert not O.exists();O.mkdir()
(O/'README.md').write_text('本包只保存已关闭的 Native release05 独立初始预检原件。11实际命令及outer0、FP4650双Cargo release opt3与两个原探针、两完整selected PE、2056源与2061成员源ZIP及当前Root、2067原生Windows文件ID/mtime/nlink、四具名整表93/129/129/1913和严格physical01/evidence02、8控制原件与一个精确派生schema均已实际独审。全原PE/sourceZIP/命令原stdoutstderr由Windows release原根和Root主归档保留，本审查包不重复巨型原件；main中的all_read_original_pins精确绑定这些真实原件。\n\n本轮沿用已确认的repo/源ZIP布局首次完整读回退出0；未发生当前collector失败，也不将旧release04的KeyError说成当前发生。旧失败在旧独立包保存，不修改任何原数据/产品/作者/金标。Windows原生只读Python仅核元数据，PID和输出在actual-native-metadata中，没有运行产品/HTTP/Cargo。原执行器没有目录身份持有、工具身份持有保证，审查不增加这些声明。\n\nGO以后本收集器只读Linux reviewer缓存，没有D大读；本包是构建预检，不能证明793全Rust、527全Python或Native62行为通过。\n',encoding='utf-8',newline='\n')
files=[('review/'+p.name,p) for p in sorted(R.iterdir()) if p.is_file()]+[('README.md',O/'README.md'),('collector/collect.py',Path(__file__).absolute())]
originals=[{'member':n,'original':str(p),'pin':capture(p)[1]} for n,p in files]
with zipfile.ZipFile(O/'originals.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for v in originals:z.writestr(v['member'],capture(Path(v['original']))[0])
with zipfile.ZipFile(O/'originals.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(originals)
 for v in originals:
  raw=z.read(v['member']);source,pin=capture(Path(v['original']));assert raw==source and pin==v['pin'] and (binascii.crc32(raw)&0xffffffff)==z.getinfo(v['member']).CRC
scope='Independent closed release05 preflight only, FP4650/source8e4d-4ca30/checker3b-tests428; no full current Rust798/fullPython527/Native62 inference. Package collector reads only Linux reviewer-local originals after GO; large native source/PE/build raw are referenced by the actual read pins and not duplicated.'
save(O/'manifest.json',{'members':originals,'member_count':len(originals),'scope':scope})
save(O/'actual.json',{'status':'passed','members':len(originals),'all_CRC_SHA_length_original_identity_mtime_bytes_equal':True,'source2056':2056,'ZIP2061':2061,'actual_commands11':11,'actual_native_metadata2067':2067,'no_current_preflight_collector_failure':True,'no_D_reads_by_package_collector':True,'ZIP':capture(O/'originals.zip')[1],'manifest':capture(O/'manifest.json')[1],'scope':scope})
print(json.dumps({'status':'passed','members':len(originals),'ZIP':capture(O/'originals.zip')[1],'manifest':capture(O/'manifest.json')[1],'actual':capture(O/'actual.json')[1]}))
