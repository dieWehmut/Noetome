"""Additional explicit runtime/derived-asset/prior-scope pins; readonly, no product invocation."""
from pathlib import Path, PureWindowsPath
import hashlib,json,os,stat
R=Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-05-20261107')
O=Path(__file__).parent
P={}
def host(p):
 w=PureWindowsPath(p);assert w.is_absolute() and w.drive in ['C:','D:'];return Path('/mnt/'+w.drive[0].lower()).joinpath(*w.parts[1:])
def read(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 with p.open('rb') as f:
  s=os.fstat(f.fileno());b=f.read();t=os.fstat(f.fileno())
 z=p.lstat();shape=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mtime_ns,q.st_nlink)
 assert shape(a)==shape(s)==shape(t)==shape(z)
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink};assert P.setdefault(str(p),v)==v;return b
def verify(raw,pin):assert hashlib.sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['byte_length']
m=json.loads(read(R/'native-final.json'));runtime=json.loads(read(R/'native-runtime.json'));cache=json.loads(read(R/'compiler-cache-scope.json'));prepared=json.loads(read(R/'prepared-source.json'));snapshot=json.loads(read(R/'snapshot.json'));current=json.loads(read(R/'precise-source-scopes.json'))
assert runtime['selected_environment']['CARGO_TARGET_DIR']==snapshot['release_cache_physical_target']==cache['target']
assert runtime['selected_environment']['RUSTUP_TOOLCHAIN']=='1.98.1-x86_64-pc-windows-msvc'
assert runtime['selected_environment']['RUSTFLAGS'] is None and runtime['selected_environment']['CARGO_ENCODED_RUSTFLAGS'] is None
assert runtime['python'].startswith('3.12.14')
tools=[]
for name,item in runtime['compiler_tools'].items():
 b=read(host(item['path']));verify(b,item)
 actual_path=read(R/('rustup-which-'+name+'.stdout.bin')).decode().strip();assert actual_path==item['path']
 tools.append({'name':name,'recorded':item,'actual_current_whole_body_pin':P[str(host(item['path']))]})
verify(read(host(runtime['python_executable'])),runtime['python_pin'])
assert b'1.98.1' in read(R/'rustc-version.stdout.bin') and b'1.98.1' in read(R/'cargo-version.stdout.bin')
assets=json.loads(read(R/'declared-build-assets.json'));assert len(assets)==1
derived=[]
for name,record in assets.items():
 raw=read(R/'repo'/name);source=read(R/'repo'/record['derived_from']);assert raw==source;verify(raw,record['pin']);verify(source,record['source_pin'])
 derived.append({'name':name,'actual':P[str(R/'repo'/name)],'derived_from':record['derived_from'],'source_actual':P[str(R/'repo'/record['derived_from'])],'exact_byte_equal':True})
for name,key in [('snapshot.json','snapshot'),('source-originals.zip','source_archive'),('runner.py','runner'),('launch-native.ps1','launcher'),('precise-source-scopes.json','precise_scopes'),('rust-dependency-subset.json','rust_dependencies'),('release-executor.py','release_executor')]:verify(read(R/name),prepared[key])
prior=host(snapshot['release_cache_evidence_root']);old=json.loads(read(prior/'precise-source-scopes.json'))
delta=cache['source_delta']['allowed_source_delta'];assert set(delta)=={'crates/noetome-cli/src/request_run.rs','crates/noetome-cli/src/request_budget_store.rs'}
tables=[]
for key in ['direct_build_rs_input_files','cli_cargo_and_test_files','all_workspace_rust_files','conservative_rust_dependency_files']:
 assert set(old[key])==set(current[key]);changed={n for n in current[key] if current[key][n]!=old[key][n]};assert changed==set(delta)
 for name in changed:assert old[key][name]==delta[name]['old'] and current[key][name]==delta[name]['new']
 tables.append({'name':key,'named_files':len(current[key]),'exact_names_equal':True,'exact_two_source_deltas':sorted(changed),'all_other_named_file_pins_equal':True})
listed=[line for line in read(R/'test-driver-list.stdout.bin').decode().splitlines() if line.startswith('request_budget_store::tests::') and line.endswith(': test')]
assert len(listed)==len(set(listed))==36
for p in list(P):read(Path(p))
result={'status':'passed','scope':'Additional readonly release05 explicit runtime current body SHA/length, actual version outputs, source-derived schema exact bytes, prepared8control/auxiliary pins, and all four prior/current complete named scope tables. Runtime tool ID was not held during original build and directory identity guard was not implemented; this readback does not add those guarantees. No product/HTTP/Cargo invocation.', 'current_runtime_tools':tools,'current_python_body_pin':P[str(host(runtime['python_executable']))],'declared_derived_asset':derived,'four_prior_current_named_scope_tables':tables,'physical_target':cache['target'],'independent_previous_evidence_root':snapshot['release_cache_evidence_root'],'actual_Windows_budget_module_listed_not_executed':{'count':36,'names':listed},'all_original_read_pins':P}
raw=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode();(O/'runtime-cache-supplement.json').write_bytes(raw)
print(json.dumps({'status':'passed','actual_sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'tables':[t['named_files'] for t in tables],'derived_asset':len(derived),'runtime_tools':len(tools)}))
