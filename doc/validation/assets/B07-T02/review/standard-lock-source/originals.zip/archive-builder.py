"""Archive explicit closed Home reviewer files; no Native or product execution."""
from pathlib import Path
import binascii
import hashlib
import io
import json
import os
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path(sys.argv[1]).resolve()
SCOPE = sys.argv[2]
BUILDER = Path(__file__).resolve()
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1
    key = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_nlink)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        after_open = os.fstat(stream.fileno())
    last = path.lstat()
    assert key(first) == key(opened) == key(after_open) == key(last), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
           'device': first.st_dev, 'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns,
           'mode': first.st_mode, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

files = sorted(path for path in ROOT.iterdir() if path.is_file())
assert ROOT / 'README.md' in files and not any(path.name == 'archive-builder.py' for path in files)
members = [(path.name, path) for path in files] + [('archive-builder.py', BUILDER)]
package = ROOT / 'package'
package.mkdir(exist_ok=False)
manifest = {'producer': 'independent_small_review_original_archive', 'scope': SCOPE, 'members': []}
zip_path = package / 'originals.zip'
with zipfile.ZipFile(zip_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in members:
        raw = read(path)
        archive.writestr(name, raw)
        manifest['members'].append({'member': name, 'original': str(path), 'pin': PINS[str(path)]})
zip_raw = read(zip_path)
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(members)
    for row in manifest['members']:
        raw = archive.read(row['member'])
        item = archive.getinfo(row['member'])
        assert item.file_size == len(raw) == row['pin']['byte_length']
        assert (binascii.crc32(raw) & 0xffffffff) == item.CRC
        assert hashlib.sha256(raw).hexdigest() == row['pin']['sha256']
        assert raw == read(Path(row['original']))
for path in list(PINS):
    read(Path(path))
manifest['member_count'] = len(members)
with (package / 'manifest.json').open('x') as stream:
    stream.write(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
read(package / 'manifest.json')
result = {'producer': 'independent_small_review_archive_readback', 'status': 'passed_original_preservation',
          'scope': SCOPE, 'members': len(members), 'archive': PINS[str(zip_path)],
          'manifest': PINS[str(package / 'manifest.json')], 'standalone_builder': PINS[str(BUILDER)],
          'all_members_CRC_SHA_length_exact_original_equal': True,
          'all_original_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal': True,
          'big_program_or_primary_archive_body_duplicated': False, 'new_product_HTTP_Cargo_Native_invocations': 0}
with (package / 'actual.json').open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
actual_raw = read(package / 'actual.json')
print(json.dumps({'status': result['status'], 'members': len(members), 'archive': PINS[str(zip_path)],
                  'manifest': PINS[str(package / 'manifest.json')],
                  'actual_sha256': hashlib.sha256(actual_raw).hexdigest(), 'actual_byte_length': len(actual_raw)}))
