"""Home-only exact two-test-call/source/author review; no product or Native run."""
from pathlib import Path
import binascii
import difflib
import hashlib
import io
import json
import os
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PINS = {}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, str(path)
    shape = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_nlink)
    with path.open('rb') as stream:
        actual = os.fstat(stream.fileno())
        raw = stream.read()
        final = os.fstat(stream.fileno())
    after = path.lstat()
    assert shape(before) == shape(actual) == shape(final) == shape(after)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': before.st_dev,
           'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'mode': before.st_mode, 'nlink': before.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

def short(pin):
    return {k: pin[k] for k in ['sha256', 'byte_length']}

archive_path = ROOT / '.artifacts/b07-t02-linux-registered-identity-pair-01-20261107/source-originals.zip'
archive_raw = read(archive_path)
assert hashlib.sha256(archive_raw).hexdigest() == '45cae7385a3302fdf2e9f56f392d49be0e0d4b8cea7818c47222f773c8a1a826'
member = 'crates/noetome-cli/src/request_budget_store.rs'
with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
    before = archive.read(member)
    assert (binascii.crc32(before) & 0xffffffff) == archive.getinfo(member).CRC
after = read(ROOT / member)
assert hashlib.sha256(before).hexdigest() == '57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646' and len(before) == 165922
assert hashlib.sha256(after).hexdigest() == 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a' and len(after) == 165884
old_lock = b'fs2::FileExt::try_lock_exclusive(&held).unwrap();'
old_unlock = b'fs2::FileExt::unlock(&held).unwrap();'
new_lock = b'held.try_lock().unwrap();'
new_unlock = b'held.unlock().unwrap();'
assert before.count(old_lock) == before.count(old_unlock) == 1
assert after.count(new_lock) == after.count(new_unlock) == 1
assert before.replace(old_lock, new_lock).replace(old_unlock, new_unlock) == after
marker = b'\n#[cfg(test)]\n'
assert before.count(marker) == after.count(marker) == 1
before_prefix, before_tests = before.split(marker, 1)
after_prefix, after_tests = after.split(marker, 1)
assert before_prefix == after_prefix
assert before.index(old_lock) > before.index(marker) and before.index(old_unlock) > before.index(marker)
assert after.index(new_lock) > after.index(marker) and after.index(new_unlock) > after.index(marker)
old_names = re.findall(rb'^    fn ([a-zA-Z0-9_]+)\(', before_tests, re.M)
new_names = re.findall(rb'^    fn ([a-zA-Z0-9_]+)\(', after_tests, re.M)
assert old_names == new_names
assert after_tests.count(b'    #[test]\n') == before_tests.count(b'    #[test]\n')
for label, raw in [('Store-before57.rs', before), ('Store-afterc87.rs', after), ('production-prefix-before57.bin', before_prefix), ('production-prefix-afterc87.bin', after_prefix)]:
    with (OUT / label).open('xb') as stream:
        stream.write(raw)
patch = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), 'Store-before57', 'Store-afterc87'))
with (OUT / 'two-test-calls.patch').open('x') as stream:
    stream.write(patch)

unchanged = {}
for name, expected in {
    'crates/noetome-cli/src/request_run.rs': ('e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 74943),
    'scripts/verify_request_budget.py': ('3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 169966),
    'tests/test_verify_request_budget.py': ('42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 50420)}.items():
    raw = read(ROOT / name)
    assert hashlib.sha256(raw).hexdigest() == expected[0] and len(raw) == expected[1]
    unchanged[name] = PINS[str(ROOT / name)]
fixture = ROOT / 'fixtures/run-api-budget-v1'
author_raw = read(fixture / 'frozen-sha256.json')
assert hashlib.sha256(author_raw).hexdigest() == 'ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272'
author = json.loads(author_raw)
assert len(author['files']) == 44 and author['request_reservation_tokens'] == 8310
author_files = []
for name, expected in author['files'].items():
    path = Path(name)
    assert not path.is_absolute() and '..' not in path.parts
    read(fixture / path)
    assert short(PINS[str(fixture / path)]) == expected
    author_files.append({'member': name, 'actual_pin': PINS[str(fixture / path)]})
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_c87_two_cfg_Windows_test_calls_exact_source_review', 'status': 'passed_static_scope_review',
          'before_Source': {'sha256': hashlib.sha256(before).hexdigest(), 'byte_length': len(before), 'original_130_sourceZIP': PINS[str(archive_path)]},
          'after_Source': PINS[str(ROOT / member)], 'whole_reverse_two_calls_exact_byte_equal': True,
          'two_replacements': [{'old': old_lock.decode(), 'new': new_lock.decode()}, {'old': old_unlock.decode(), 'new': new_unlock.decode()}],
          'production_cfg_test_prefix_byte_equal': {'sha256': hashlib.sha256(before_prefix).hexdigest(), 'byte_length': len(before_prefix)},
          'only_windows_branch_test_calls_changed': True, 'test_definitions_and_count_unchanged': True,
          'all_other_guards_caps_deadlines_scheduling_runtime_source_exact_byte_equal': True,
          'Run_checker_Python_tests_whole_file_unchanged': unchanged, 'frozen_author_44_payload_files_and_manifest_unchanged': author_files,
          'all_original_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal': True,
          'Native07_failure_scope_from_Root_message_not_independently_read_here': 'CLI built exit0; driver compile exit101 due to two unresolved cfg-Windows fs2 test calls; probes/HTTP/three/full807 not_run. Failure raw/program originals preserved by execution owner; no D read here.',
          'old57_Linux47_and62_result_reused_as_c87_whole_source_acceptance': False,
          'c87_new_compile_behavior_and_full_Native807': 'not_run_by_this_reviewer',
          'new_D_Native_product_Cargo_HTTP_invocations': 0, 'original_pins': PINS}
with (OUT / 'actual.json').open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
raw = read(OUT / 'actual.json')
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                  'production_prefix_sha256': hashlib.sha256(before_prefix).hexdigest(), 'production_prefix_byte_length': len(before_prefix)}))
