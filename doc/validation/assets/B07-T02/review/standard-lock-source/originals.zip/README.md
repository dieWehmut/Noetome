# c87 两个Windows测试调用的独立源码审查

before整件Store从已冻结cb137程序对的130成员来源ZIP读取，SHA为57c1/165922B；after整件实际源码为c87/165884B。独立程序先保存后执行，对原ZIP、当前源码、Run/Python/作者原件均以实际read handle fstat、路径ID、mtime、普通单link和完整字节前后核对。

只有两个Windows测试分支调用变化：`fs2::FileExt::try_lock_exclusive(&held).unwrap()`改为`held.try_lock().unwrap()`，`fs2::FileExt::unlock(&held).unwrap()`改为`held.unlock().unwrap()`。逆向替换后整件字节精确等于旧57。`#[cfg(test)]`前97558字节生产prefix完整相等，SHA `486e2d6161f9b6dacc43de10e92cb530152db94bf53b94aa652b8a8a4a5f2431`；生产与其余测试代码、test定义/数量、cap/guard/schedule/runtime逻辑均没有其他改动。

Run e4/74943、checker3b/169966、tests428/50420全部实际SHA/长度相等。ef04作者manifest及44个payload文件逐原SHA/长度和实际身份mtime前后相等，R8310及gold未改。

本审查没有执行编译、产品或Native，也未读取D盘。Native07的CLI成功、driver缺fs2的实际失败由根代理提供并由执行代理保全原件；本包不伪称独立读过其D盘raw。源码相等范围不替代新c87的实际编译、测试和新FP原件绑定，旧57 Linux47/62与旧Native07CLI结果没有被宣称为c87整件来源验收。
