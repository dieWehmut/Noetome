# B07-T02 guarded raw-file map 后备方案及共享 stamp 审查

本轮仅只读源审查，无 Rust 编辑、Cargo、Native、HTTP 或性能测试。原 Native FP4650 elapsed 在原绝对期限内合法 NoFit、0 kill，accepted/main62 未运行；这份设计不改变 1500ms / 1000ms / 200ms、作者预留 R8310 或金标。

本文件的实际源快照是 Store `52e83c55e17ad49ad74890c29b5aed8d2afde6b2fb968da8a432493f98c11eb5` / 142623B 与 Run `29f370b8cc7eaf79a6b7551d794eacb65a660974c814809dfcfbfd40fa2576be` / 74699B。读取过程中 Root 已把 Store `stamp_mode` 增加可见性并把 Run helper 委托给它；计数依据的 witnesses / request / transport / receipt / candidate 流程与此前 4ca 完全相同。不是把这两份新文件冒充旧 4ca / 8e 整件。

## 当前重复路径及确切计数

`witnesses` 先逐 sealed_files 调用 stamp，然后 `verify_request` 又读 request.json；`transport_files` 又读 transport-receipt.json 和 response.bin；`receipt_files` 又读报告、MD、响应、可选候选/transport，transport 还有一次单独 DTO 读取；Validated 时 `validate_candidate` 再读 request.json 和 candidates.json。原请求 body 的 SHA/长度来自 sealed 文件与 AttemptPlan，不能删这项核对。

| 具体形状/范围 | 当前 stamp 次数 | 所有涉及原件首尾各读一次 | 限定 |
| --- | ---: | ---: | --- |
| Prepared/Reserved/MaySend witness，无 transport，3 个 sealed 文件 | 4 | 6 | 不含 Run owner/worker/目录 |
| transport-sealed witness，有 response，无最终 receipt，5 文件 | 8 | 10 | 无最终报告 |
| 普通最终 report，有 response，candidate 非 Validated 且 candidates 缺省，7 文件 | 15 | 14 | transport 已 seal |
| 普通 Validated 最终 report，8 文件 | 19 | 16 | transport、response、candidates 均存在 |
| 首次 prepare 的 decision 体 | 4 | 6 | 不含原 authority 的 witnesses |
| 对 3-file MaySend 的 seal_transport 整个目标 attempt 校验 | 6 | 10 | 包含旧 witness + 新 transport 原件 |
| 对 transport-sealed 的首次 Validated settle 目标 attempt | 16 | 16 | 假设同一个 transaction-local map 可跨该 witness 与 decision 复用 |

Validated witness 中：`.owner.json` 1、request-body.json 1、request.json 3、validation.json 2、validation.md 2、response.bin 3、candidates.json 3、transport-receipt.json 4，总计19。表格统计函数 stamp 调用，不是 Windows Open 调用次数、运行耗时或所有合法分支的统一公式。layout、SQL 全链、其它 attempt、Run owner/lock、输入原件仍需独立完整保护。

所以只把所有文件改为两读，并不保证发送/结算的关键路径获益。若只优化已有多次消费者的 raw 原件，owner/body 单次校验保持原实现，Validated witness 可为14次；这是另一种更窄方案，需要写明单次文件不进入字节缓存，不能声称全部原件都首尾二读。当前 Root 优先共享 Run stamp，map 暂不实现。

## 最小接口形状

建议把 map 设为私有、单次 callback 内的 `AttemptRawWitness`，不作为 BudgetStore 字段、不进入 BudgetView、不持久化、更不按 SHA 合并。索引为已经证明的 attempt root 加严格 allowed_file 相对名称；一个 entry 始终绑定同一 owned/external mode、实际 FileStamp、不可变原 bytes 和首次实际读句柄。

```rust
struct RawImage { stamp: FileStamp, bytes: Arc<[u8]> }
struct AttemptRawWitness { /* root/dirs/inventory, images, live handles */ }

fn with_attempt_raw<T>(
    run: &RunView,
    attempt: &AttemptView,
    check: impl FnOnce(&mut AttemptRawWitness) -> Result<T, ProjectError>,
) -> Result<T, ProjectError>;

impl AttemptRawWitness {
    fn image(&mut self, name: &str) -> Result<RawImage, ProjectError>;
    fn expect_stamp(&mut self, name: &str, expected: &FileStamp)
        -> Result<RawImage, ProjectError>;
    fn expect_pin(&mut self, name: &str, expected: &FilePin)
        -> Result<RawImage, ProjectError>;
    fn require_absent(&mut self, name: &str) -> Result<(), ProjectError>;
    fn finish(self) -> Result<(), ProjectError>;
}
```

这是接口建议，未编译。RawImage 只廉价复制 Arc 和 FileStamp，避免借用 response bytes 时又要可变借用 map 读取 request/candidates 的 Rust 冲突，也避免重复复制64MiB Vec。首次 image 必须使用现有 actual read-handle stamping 全路径，并保留初始实际读句柄；已有 stamp_mode 可增加私有返回 live handle 的底层形式，公共二元组 wrapper 仍丢弃句柄。不建议在 stamp 后重新从路径打开一个未经同次比对的句柄当作首次见证。

每次 expect_stamp 都对账本的完整 ID/modified/SHA/length 比较；expect_pin 对新原件固定 SHA/length，然后把同一次 actual FileStamp 返回用于新的 explicit event。两次消费者即使给同 SHA、不同 UUID/路径/预期 FileStamp，也不能互相认证。文件不能因第一次读取后出现就自动进入 sealed_files。

`json` / `verify_request` / `transport_files` / `receipt_files` / `validate_candidate` 改为消费 map 提供的原 bytes；transport DTO 可在同一次验证中解析后交给 receipt 对照，仍保留两处既有判断集合。report prefer-validation 分支、双报告字面 LF/JSON字节、raw wire usage/model/tier、request binding/units、候选保存 schema/producer/UUID/payload、Core validate_candidates 全保留。不要让 JSON parse 成功代表 framing complete，不删除 network0 / omission / elapsed / transport seal 的逻辑。

finish 为显式 fallible 调用：所有成功语义校验后，再次逐 cached 文件通过原 stamp_mode 完整读取，将 actual ID/modified/SHA/length 和 bytes 与首次 image 都相等；再复核祖先/attempt identity、单link、components、allowed inventory、已记录 absence 条件。只有 finish 成功才可返回给 witness caller 或构造/追加资金事件。不能把检查放在 Drop 后忽略错误，也不能先 COMMIT 再 finish。

## 生命周期、并发和内存边界

首选逐 attempt：其原目录/库存检查 -> 首次全部需要的 strong 原件 -> 所有原语义检查 -> finish -> 释放 bytes/句柄 -> 下一个 attempt。witnesses 的 finish 完成后才执行 update_checked 的 caller guard、真实 now、admission decide，保持原输入检查与 UTC/限额顺序。open_readonly/view 也每次重新完整 load + witnesses，不复用上次结果。

若未来需要跨同一次 witnesses 与 settle decision 复用，只可保留当前 mutation target 的 map，其它 attempt 立即 finish 和释放。仍是 fresh BEGIN IMMEDIATE、全 load/apply/hashchain/caps、全其它 witness、caller 输入和 stop guard，事务/HTTP/下一次 view 外无缓存。要注意最终 heavy raw recheck 与 event UTC/absolute deadline 的位置；不能先取 now 授予发送，新增耗时复核后仍拿旧 now 声称刚通过时限。这个较大版本应另做时序分析，当前不建议顺手实现。

原合法并发允许一个 MaySend attempt 的 allowed unsealed response/report 在别的 unit 审计期间出现。不能要求所有目录初始 names == 最终 names 从而拒绝合法传输追加。初始和末尾都验证 actual allowed 普通文件/单link；所有已 sealed/cached 文件不可消失或替换；require_absent 在 receipt/transport 明确禁止实际 response、或已选择 recovery 分支时末尾重验。允许未知时刻出现的 allowed extras 只属于库存，绝不从 map/报告自述自动登记或结算，必须后续 explicit Prepared/TransportSealed/ReceiptSettled 捕获。未知文件、reparse、hardlink、祖先替换仍立即拒绝。

保持0B worker.lock 的 metadata/actual ID 路径，不能走 raw-file read。source input_pins 继续 external read_guard，并保留每次 verify_inputs，不把同事务 attempt map 扩成全源材料缓存。

现有上限是64 Run × 4 unit × 4 attempt × 9 allowed names ×64MiB，全部理论字节持有量达576GiB；events4096并不让一个全事务缓存足够小。逐 attempt 最多9原件 =576MiB，再加终末一文件 re-read/解析分配；通常8-file path为512MiB。若新增更小 aggregate cap，会改变此前合法输入的接纳范围，需要明确契约/作者测试，不能悄悄加额度。先逐 attempt/只缓存必要重复项可以限制范围，但不等于证明内存风险或紧期限性能已验收。

## 必要负例和区分力

1. first image 后将同一路径同 bytes/mtime 替换成新 handle，最后拒绝，DB bytes/events 不变；保留首次句柄避免 ID reuse 给出虚假一致。
2. first image 后同 inode 改 bytes并恢复mtime、保留长度，full second bytes/SHA 拒绝。
3. first image 后增长/缩短并恢复mtime，或读取结束才换 hardlink，最后 len/nlink/actual ID 拒绝。
4. leaf/ancestor symlink或 Windows junction/reparse 替换，原首尾 components 和 actual handle 属性必须拒绝。
5. 开始/结束加入未知文件拒绝；相邻 unit 合法追加 allowed report 成功，但不被其它 map 自动 seal；已 sealed 文件丢失拒绝。
6. require_absent 的 response 在校验末尾出现拒绝；final validation.json/recovery分支不能被新文件悄悄改变。
7. DTO 同步伪造 transport/report usage/network/header/elapsed、候选 request/binding/payload、双报告同步hash：原完整语义校验仍逐类拒绝。
8. 同 bytes/SHA 两不同真实 request UUID 均收费，map 不按SHA共用身份；same key 不同 FileStamp 同bytes也拒绝。
9. 两个连续 view/transaction 之间修改原件，下一次重新读并拒绝；失败/成功后 cache 不留存。
10. 确认 max64MiB+1 拒绝、多个最大文件受明确内存策略控制；不使用 cache eviction 导致漏 final。
11. cfg(test) 用实际 map read counter 验证表格关键形状，以新 CLI 实际 tight profile测耗时；计数测试不是性能通过。
12. 原真实 opening/global caps、Prepared/Reserved/MaySend/Unknown/Known、Known700候选失败收费、退款后再调度、samekey幂等、kill恢复必须继续当前 independent author CLI验收。缓存单元测试不能替代这些产品实测。

## Run stamp 共享候选的独立结论

已读落盘 Run `stamp_with`：owned bool 原传给共享 Store helper，只有 REQUEST_BUDGET_INTEGRITY 映射 REQUEST_RUN_INTEGRITY，PROJECT_IO_ERROR、PROJECT_UNSAFE_PATH/exit2、PROJECT_DATABASE_BUSY、COMPILE_IDENTITY_UNSUPPORTED 原样传播。共享 false 仍原 Win share1/read_guard，true 仍 share3/OPEN_REPARSE；完整64MiB/SHA/epoch纳秒保留，actual opened ID、成功modified、首尾 components/nlink/len 保护比旧Run更严格。未见此委托本身的阻断。

建议补实际 namespace/外部 writer拒绝/owned原 Artifact ShareRead兼容/同bytesmtime替换/祖先link/0B worker不触及等测试。不能把静态源码审查或 Store38测试推为 Native1500已通过。

layout Owner 的另 identity 可用同一次 stamp 返回 identity+原bytes取代，必须在原 canonical root/parent/control/DB identity 的门槛之后读取 owner，不提前从未经证明的 owner路径读自述。DB header 只读100B有不同契约，应单独保持同实际 read handle、前后path身份/普通文件/DELETE journal header，不能直接套完整SHA stamp后改变SQLite并发规则；本轮未实现或测试此项。
