# B07-T02 layout owner / DB header narrow implementation

仅实现授权的 Store 改动，没有运行 Cargo、Native、HTTP 或产品行为。当前源 `2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184` /151556B。原完整4ca、Root52e共享可见性文件、新完整源和两diff全部保存。

layout 先确认 schema/producer/FP格式、规范根/root-parent-control身份、原LOCK及严格root/control库存；随后 DB100B helper 通过 initial-path / actual-read / current-path 三个活句柄，核登记DB身份、实际普通singlelink/reparse属性、100B..64MiB长度、前后及当前成功mtime/长度一致、首尾组件，再核 SQLite magic 与 DELETE header18/19。实际只 read_exact(100)，没有读/缓存全DB、修改schema/SQLload/事务/预算/输入/未知承诺/重试/期限策略。owner随后一次stamp取 actual identity+完整原bytes，替代分开的identity与stamp；policy原件/typed caps/opening/authority仍完整校验。

上述DB-before-owner原文保证仅属于layout阶段；open_mode仍先安全读取/解析选定owned owner来获取已有登记ID，不声明整个入口第一读取前已有新增外部身份锚。EMPTY LOCK、compile_identity、原external/owned share规则均未修改。

四个新共同测试：

- `budget_db_header_accepts_registered_identity_and_size_boundaries`: 相同登记ID且100B、64MiB边界成功，只读header。
- `budget_db_header_rejects_same_bytes_mtime_identity_replacement`: private after_snapshot中真实rename替换，同bytes/mtime而新ID仍拒绝；Windows仅该cfgtest读句柄share7允许构造真实replacement，production仍share3。
- `budget_db_header_rejects_post_snapshot_links_lengths_and_mtime`: 真实新hardlink、读间长度增长/缩短且恢复mtime、只变mtime均拒绝。
- `budget_db_header_rejects_wal_short_over_limit_and_wrong_identity_before_owner`: WAL2/2、99B、64MiB+1、wrongID拒绝；真实layout中把owner同allowed名称变目录，仍先报DB DELETE/header拒绝并保存DB bytes/no-sidecar。

新增测试均未运行，Linux/Windows各+4个定义；本文件预计module Linux38→42、Windows36→40，本文件贡献workspaceWindows798→802，Root Run新增测试另计。不能把本文件的预计数当最终实际总数。

实际验证仅选定工具链 Rust1.98.1 的 rustfmt 1.9.0-stable：format PID815222 exit0、format-check PID815223 exit0，version PID815221 exit0，stdout/stderr全保存。首选不存在的 `/home/lyinn/.local/bin/rustfmt` exit127原错误保存；随后按实际Cargo wrapper定位其selected toolchain绝对rustfmt路径。未用cargo fmt或任何Cargo构建。

局部diff精确重建证明：把新layout+helper替回原layout，并移除 literal_header helper+四测试后，文件逐byte恢复Root52e；其它源、BudgetStore cap/hashchain/nullable/body/transport/receipt/witness/UTC代码没有变化。Root `pub(super) stamp_mode`保持。

独立静态审查 audit_scan_live 已只读实际新源，报告无阻断；其消息不作为运行测试证据。后继实际Cargo/OS行为及Native tight deadline结果由Root统一source freeze后执行，本包不声称性能通过。guarded raw-file map仍为后备只读设计，没有实现。
