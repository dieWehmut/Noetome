# B07-T02 release06 guarded build-only draft

当前冻结：Run b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c /74782B；Store 2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184 /151556B；checker 3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7 /169966B；tests 42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348 /50420B。

Root没有新增Run测试。Run仅共享stamp委托、同一次owner stamp identity+bytes和unused Read/MAXFILE删除。原初稿Root Run后变使source-after-equality false是授权owner校验变更，不是新增tests；旧raw和说明不重写，另附 run-test-scope-clarification.json。Store新增4common tests，预计Linux module42、Windows40、Windows workspace802；实际总数必须以后继真实--list/测试原件为准，不能从Linux42推Windows42。

原 original runner仍3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1，原先全测试结果均不复用。源/8controls/selected及aliases的固定actual fileID/mtime/length/nlink+SHA检查、reparse父组件前验、4external SHA无cycle保持；不声称目录ID或runtime-tool fileID有额外guard。

本草稿只AST/help和源规则本地验证，没有prepare、新Native根、Cargo、产品CLI、HTTP或全Python运行。旧4650 Native NoFit全部保留为历史，不能用作此新源码/FP的行为通过。

从 frozen release05 d3984fb4 修改：两new源码SHA/length，仍仅允许 prior02 的 old Run2e735/74989 + Store726267/128653 → current b393/74782 + 2e97/151556。四个scope逐完整名字/旧新SHA/length核对，第三个变更或多/少name立即拒绝；计数恰相同不代表集合相同。新增完整 SOURCE_PINS 四表，在prepare和Native入口都比exact SHA+length。其余函数/StrongFiles/cache/controls/两Cargo/profile/dualFP代码AST全等旧d398。

物理缓存严格选真实release01/build-target，独立闭合来源严格固定release02：snapshot、precise-scopes、outer、primary、compiler-cache-scope五固定SHA/length，加primary内两actualCargo row原件，七份原缓存证据全保留。physical target与固定cache-scope实际路径、Native CARGO_TARGET_DIR字符串相等；绝不从target.parent猜evidence或制造不存在的release02/build-target。仅依赖/对象缓存；两个current Cargo命令必须重跑，临时Cargo可有正nlink但ID/mtime/linkcount原值复制前后相等，fresh selected普通singlelink+完整body/FP实探，旧程序/结果不作acceptance。

之后Root明确GO才可使用以下prepare接口：

```text
/tmp/noetome-b05-t03-python/bin/python executor.py prepare   --repo /home/lyinn/project/Noetome   --native-base /mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-06-20261107   --original-runner /home/lyinn/project/Noetome/.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py   --freeze-label b07-t02-shared-stamp-dbheader-release06   --cache-target /mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-01-20261107/build-target   --cache-evidence-root /mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-02-20261107
```

真实prepare完成/所有guard和Root后继launch GO后，`executor.py launch --native-base <同新根>`。此刻两者都未执行。run子命令仍由外部snapshot/runner/sourcearchive/executor四SHA绑定的native launcher调用。

两个必须实际命令为 `cargo build -p noetome-cli --bin noetome --release --locked --offline --message-format=json` 和 `cargo test -p noetome-cli --lib --release --no-run --locked --offline --message-format=json`。同release PROFILE/OPT_LEVEL、实际CargoJSON挑出的CLI/driver、两个NOETOME_RUN_COMPILER_FINGERPRINT、wholePE、真实probe/实际outerwait必须闭合；driver --list仅列举不是运行tests。该executor不执行全Rust/全Python/HTTP。Native普通1500/三个目标/全62由独立owner，在preflight/RootGO后独占机器窗口。

实际本地静态：AST通过、help PID818566 exit0；实际check_source_delta函数内存输入11类拒绝，Native新四SourcePins guard实际AST表达式四wrong-length均false。未读取或声称实际七份旧D缓存原件已在本轮独立复读；该读取属于未来prepare/Native。
