# B07-T02 full09 current-source debug regression draft

当前冻结：Run b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c /74782B；Store 2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184 /151556B；checker 3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7 /169966B；tests 42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348 /50420B。

Root没有新增Run测试。Run仅共享stamp委托、同一次owner stamp identity+bytes和unused Read/MAXFILE删除。原初稿Root Run后变使source-after-equality false是授权owner校验变更，不是新增tests；旧raw和说明不重写，另附 run-test-scope-clarification.json。Store新增4common tests，预计Linux module42、Windows40、Windows workspace802；实际总数必须以后继真实--list/测试原件为准，不能从Linux42推Windows42。

原 original runner仍3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1，原先全测试结果均不复用。源/8controls/selected及aliases的固定actual fileID/mtime/length/nlink+SHA检查、reparse父组件前验、4external SHA无cycle保持；不声称目录ID或runtime-tool fileID有额外guard。

本草稿只AST/help和源规则本地验证，没有prepare、新Native根、Cargo、产品CLI、HTTP或全Python运行。旧4650 Native NoFit全部保留为历史，不能用作此新源码/FP的行为通过。

此文件从 frozen full08 71c58e126d19ef56d6b1115c48115a4b2639e2880d262cae1e38205e4bd91541 仅改Run/Store两个源码SHA/length和full Rust成功literal798→802。回退这些literal可逐byte恢复旧文件；SOURCE_PINS四个完整SHA/length、prepare/Native两处explicit exact check仍在，其它源码/guard/command AST不变。

prepare接口保持：

```text
/tmp/noetome-b05-t03-python/bin/python executor.py prepare   --repo /home/lyinn/project/Noetome   --native-base <Root明确选定的不存在新D盘full根>   --original-runner /home/lyinn/project/Noetome/.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py   --freeze-label b07-t02-shared-stamp-dbheader-full09   --cache-target /mnt/d/Noetome/.artifacts/b07-t02-windows-native-01-20261107/build-target
```

此刻未prepare/launch。Root仅在新release来源/三个目标/当前全62真实通过且全部PIDs闭合后可另GO实际full执行。cache只原已closed Native01依赖target，不是release01 target，不复用旧测试/程序/FP。所有当前 debug fmt/check/cleanbuild/CLI/driver/全workspace Rust/fullPython实际重跑。debug完整回归FP与release行为FP必须分列，不能同名复用旧ROOT或旧编译指纹。

预期Windows全Rust802/0fail/0ignored与全Python527=519pass8skip只是静态门槛；PS5.1原路径which/samefile与实际工具pin、已选cachePS7.6.5原路径which/版本/body、两个引擎各39真实discover与通过仍须实际raw证明。不能只PATH配两值或文件存在推计数。current default APITest仅synthetic/明确localhost；executor不自行运行T02 HTTP矩阵或读取真实credentials/累计授权账本。

实际本地静态：AST通过、help PID818567 exit0；完整四SourcePins与current Home源码逐SHA/length相等；倒回literalwhole-byte恢复full08。没有运行802/527或任何Native，LinuxRoot42通过不代替Windows40/module或全workspace。
