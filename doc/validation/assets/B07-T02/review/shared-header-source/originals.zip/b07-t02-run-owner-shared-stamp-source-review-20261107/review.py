"""Check the two exact Run changes against the immutable source130 ZIP."""
from pathlib import Path
import difflib
import hashlib
import io
import json
import os
import stat
import zipfile

OUT = Path(__file__).parent
WORK = Path('/home/lyinn/project/Noetome')
PINS = {}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        after_opened = os.fstat(stream.fileno())
    after = path.lstat()
    shape = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert shape(before) == shape(opened) == shape(after_opened) == shape(after)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': before.st_dev,
           'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'nlink': before.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

source_zip = WORK / '.artifacts/b07-t02-linux-stamp-pair-01-20261107/source-originals.zip'
zip_raw = read(source_zip)
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    assert len(archive.namelist()) == 130
    old_raw = archive.read('crates/noetome-cli/src/request_run.rs')
assert hashlib.sha256(old_raw).hexdigest() == '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc'
new_path = WORK / 'crates/noetome-cli/src/request_run.rs'
new_raw = read(new_path)
assert hashlib.sha256(new_raw).hexdigest() == 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c'
assert len(new_raw) == 74782
old = old_raw.decode()
new = new_raw.decode()

def block(source, start, end):
    first = source.index(start)
    last = source.index(end, first)
    return source[first:last]

old_stamp = block(old, 'fn stamp_with(', 'pub(super) fn write_new(')
new_stamp = block(new, 'fn stamp_with(', 'pub(super) fn write_new(')
old_verify = block(old, '    fn verify(&self)', '    fn inputs(&self)')
new_verify = block(new, '    fn verify(&self)', '    fn inputs(&self)')
assert old.replace(old_stamp, '').replace(old_verify, '') == new.replace(new_stamp, '').replace(new_verify, '')
assert old[old.index('#[cfg(test)]'):] == new[new.index('#[cfg(test)]'):]
expected_verify = old_verify.replace('            || identity(&self.root.join(OWNER))? != o.owner_identity\n', '')
expected_verify = expected_verify.replace('            || stamp(&self.root.join(OWNER))?.1 != self.owner_bytes\n', '')
expected_verify = expected_verify.replace('        let names = |p: &Path|',
    '        let (owner, bytes) = stamp(&self.root.join(OWNER))?;\n'
    '        if owner.identity != o.owner_identity || bytes != self.owner_bytes {\n'
    '            return Err(invalid("Run原owner身份或字节变化。"));\n'
    '        }\n'
    '        let names = |p: &Path|')
assert expected_verify == new_verify
assert 'crate::request_budget_store::stamp_mode(path, owned)' in new_stamp
assert 'if e.code() == "REQUEST_BUDGET_INTEGRITY"' in new_stamp
assert 'invalid(format!("明确选取原件校验失败：{e}"))' in new_stamp
assert new_verify.index('identity(Path::new(&o.budget_root))') < new_verify.index('stamp(&self.root.join(OWNER))')
for name, raw in [('before-8e.rs', old_raw), ('after-b393.rs', new_raw)]:
    with (OUT / name).open('xb') as stream:
        stream.write(raw)
patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='immutable-source130/Run8e', tofile='new-Run-b393'))
(OUT / 'whole-source.patch').write_bytes(patch.encode())
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_two_point_Run_source_review', 'status': 'passed_static_scope_review',
          'before_source': {'origin_zip': str(source_zip), 'zip_pin': PINS[str(source_zip)], 'member': 'crates/noetome-cli/src/request_run.rs',
                            'sha256': hashlib.sha256(old_raw).hexdigest(), 'byte_length': len(old_raw)},
          'after_source': {'path': str(new_path), 'pin': PINS[str(new_path)]},
          'outside_two_functions_exact_byte_equal': True, 'cfg_test_section_exact_byte_equal': True,
          'owner_guard_exact_transformation': 'Remove separate owner path identity and repeated owner byte stamp; root/parent/control/attempts/emptylock/budget checks still precede one actual-handle owner stamp, whose ID and complete bytes are both compared.',
          'shared_stamp_scope': 'Store stamp_mode supplies the same owned/external3/1 sharing, initial/read/current live-handle identity, bounded full-byte and mtime/link/component checks. Run integrity namespace is remapped; other errors are returned unchanged.',
          'inputs_inventory_before_after_and_Fingerprint_deadline_budget_send_guards_unchanged': True,
          'findings': [], 'performance_result': 'not_measured', 'new_behavior_Rust_HTTP_tests': 'not_run',
          'old_Linux528_matrix_and_Python466_not_reused_as_b393_source_validation': True}
with (OUT / 'actual.json').open('xb') as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(),
                  'byte_length': (OUT / 'actual.json').stat().st_size}))
