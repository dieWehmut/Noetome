"""Read-only candidate Run stamp delegation review; no build, CLI, HTTP or tests."""
from pathlib import Path
import hashlib
import json
import difflib

REPO = Path('/home/lyinn/project/Noetome')
HERE = Path(__file__).parent
OLD = REPO / '.artifacts/b07-t02-native-stamp-fresh-guard-readonly-review-20261107/compiled-source'
EXPECTED_RUN = 'b393ff'


def read(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)
    assert fields(before)==fields(after), str(path)
    return raw, {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),
                 'WSL_device':before.st_dev,'WSL_inode':before.st_ino,'mtime_ns':before.st_mtime_ns,
                 'nlink':before.st_nlink,'before_first_read_metadata_captured':True}


def save(path, raw):
    with path.open('xb') as f:f.write(raw)


def section(text,start,end):
    a=text.index(start);b=text.index(end,a+len(start));return text[a:b]


def main():
    captured={}
    for label,path in [('old-run',OLD/'request_run.rs'),('old-store4ca',OLD/'request_budget_store.rs'),
                       ('candidate-run',REPO/'crates/noetome-cli/src/request_run.rs'),
                       ('candidate-store',REPO/'crates/noetome-cli/src/request_budget_store.rs'),
                       ('project',REPO/'crates/noetome-cli/src/project.rs'),
                       ('compile-identity',REPO/'crates/noetome-cli/src/compile_identity.rs')]:
        raw,pin=read(path)
        save(HERE/(label+'.rs'),raw)
        captured[label]={'original':str(path),'pin':pin,'raw':raw.decode('utf-8')}
    old=captured['old-run']['raw'];new=captured['candidate-run']['raw']
    assert captured['old-run']['pin']['sha256']=='8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc'
    assert captured['old-store4ca']['pin']['sha256']=='4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e'
    assert captured['candidate-run']['pin']['sha256'].startswith(EXPECTED_RUN)
    assert captured['candidate-run']['pin']['byte_length']==74782
    old_stamp=section(old,'fn stamp_with(', 'pub(super) fn write_new(')
    new_stamp=section(new,'fn stamp_with(', 'pub(super) fn write_new(')
    assert 'request_budget_store::stamp_mode(path, owned)' in new_stamp
    assert 'if e.code() == "REQUEST_BUDGET_INTEGRITY"' in new_stamp
    assert 'invalid(format!' in new_stamp and 'else {\n            e\n' in new_stamp
    expected=old.replace('io::{Read, Write},','io::Write,').replace('const MAX_FILE: u64 = 64 * 1024 * 1024;\n','')
    expected=expected.replace(old_stamp,new_stamp)
    assert expected.count('            || identity(&self.root.join(OWNER))? != o.owner_identity\n')==1
    expected=expected.replace('            || identity(&self.root.join(OWNER))? != o.owner_identity\n','')
    expected=expected.replace('            || stamp(&self.root.join(OWNER))?.1 != self.owner_bytes\n','')
    insertion='''        let (owner, bytes) = stamp(&self.root.join(OWNER))?;
        if owner.identity != o.owner_identity || bytes != self.owner_bytes {
            return Err(invalid("Run原owner身份或字节变化。"));
        }
'''
    location='''            return Err(invalid("Run/authority/原owner身份或字节变化。"));
        }
'''
    assert expected.count(location)==1
    expected=expected.replace(location,location+insertion)
    assert new==expected,'Unapproved changes outside the named delegation/owner proof/import changes'
    old_store=captured['old-store4ca']['raw'];store=captured['candidate-store']['raw']
    old_stamp_range=section(old_store,'fn stamp_mode(', 'fn matches_pin(')
    new_stamp_range=section(store,'pub(super) fn stamp_mode(', 'fn matches_pin(')
    assert new_stamp_range.replace('pub(super) fn stamp_mode(', 'fn stamp_mode(')==old_stamp_range
    assert section(old_store,'fn read_identity(', 'fn stamp_mode(')==section(store,'fn read_identity(', 'pub(super) fn stamp_mode(')
    for expression in ['project::check_components(path)?;', 'project::checked_file(path)?;',
                       'same_file::Handle::from_path(path)', 'share_mode(3).custom_flags(0x00200000)',
                       'project::read_guard(path)?','same_file::Handle::from_file(file.try_clone()',
                       'initial != opened','Read::by_ref(&mut file)','take(BYTE_LIMIT + 1)',
                       'before.len() != bytes.len() as u64','read_identity(path, &file, &after)? != id',
                       'current != opened','current_metadata.len() != before.len()',
                       'current_metadata.modified()', 'sha256: sha256(&bytes)']:
        assert expression in new_stamp_range,expression
    assert '64 * 1024 * 1024' in store
    project=captured['project']['raw'];identity=captured['compile-identity']['raw']
    assert 'options.share_mode(1).custom_flags(0x00200000)' in project
    assert 'metadata.nlink() != 1' in store and 'information.number_of_links() != 1' in store
    assert 'information.volume_serial_number()' in store and 'information.file_index()' in store
    assert 'metadata.dev()' in store and 'metadata.ino()' in store
    input_old=section(old,'    fn inputs(&self)', '    fn authority_binding(')
    input_new=section(new,'    fn inputs(&self)', '    fn authority_binding(')
    assert input_old==input_new
    save(HERE/'candidate-run.diff', ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='compiled-Native4650-run8e',tofile='candidate-runb393')).encode())
    report={'status':'read_only_Run_stamp_delegation_scope_and_safety_review_passed',
            'source_pins':{k:{'original':v['original'],'pin':v['pin']} for k,v in captured.items()},
            'approved_delta_exact':True,
            'delta':['Run stamp_with delegates unchanged actual-read-handle Store4ca proof; ownership mode is preserved',
                     'Only REQUEST_BUDGET_INTEGRITY is mapped to REQUEST_RUN_INTEGRITY; IO, unsafe path, busy and unsupported identity errors pass through',
                     'Owner identity and original bytes are compared from one returned FileStamp/byte pair, removing a separate pathname identity open',
                     'Unused Read import and local duplicate MAX_FILE constant are removed'],
            'guards_preserved':['Initial/current ordinary components and no-reparse path checks',
                               'Initial/read/current SameFile handles remain alive through identity and metadata comparison',
                               'Actual bytes and platform identity originate from the same read handle',
                               'Read-handle and current-path before/after single-link, identity, length and modification time',
                               '64MiB full-byte read bound and exact SHA/length FileStamp',
                               'Owned ShareRead|ShareWrite=3; external ShareRead=1 remains deny-write/delete',
                               'Run SourceRoot complete input inventory before and after pinned-file reads, plus exact compiler fingerprint',
                               'Fresh prepared guard, BEGIN IMMEDIATE, all chain/witness/state/clock/retry/callback code byte-identical'],
            'static_path_open_sites':{'old_stamp':7,'new_delegated_stamp':3,'old_owner_identity_plus_stamp':10,'new_owner_stamp_pair':3,
                                      'scope':'Explicit pathname-open sites only. File try_clone is an additional live handle, not an omitted check. No syscall or latency benchmark is claimed.'},
            'no_cross_transaction_or_cross_call_cache':True,
            'performance_or_native_behavior_tested':False,'product_CLI_calls':0,'test_driver_calls':0,'HTTP_requests':0,
            'limitations':['Snapshot-only read-only review. Candidate Store is still being edited; this does not grant a complete-source or build freeze.',
                           'No new Linux/Windows run, tests, OS kill, timing-fit or budget behavior acceptance is inferred.',
                           'Future builds must bind their actual complete source, CLI/driver fingerprint and new owned Run roots before behavior checks.']}
    for label,value in captured.items():
        _,after=read(Path(value['original']));assert after==value['pin'],label
    report['selected_snapshot_original_ID_mtime_bytes_after_equal']=True
    save(HERE/'actual.json',(json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps({'status':report['status'],'actual':read(HERE/'actual.json')[1],
                      'candidate_run':captured['candidate-run']['pin']}))


if __name__=='__main__':main()
