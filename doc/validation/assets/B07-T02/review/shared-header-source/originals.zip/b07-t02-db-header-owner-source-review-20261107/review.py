"""Read the exact Store layout/header delta; do not run Cargo or a product."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import stat

WORK = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        last = os.fstat(stream.fileno())
    current = path.lstat()
    shape = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert shape(first) == shape(opened) == shape(last) == shape(current)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
           'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

baseline = WORK / '.artifacts/b07-t02-handle-stamp-source-independent-review-20261107/after-4ca.rs'
current = WORK / 'crates/noetome-cli/src/request_budget_store.rs'
old_raw = read(baseline)
new_raw = read(current)
assert hashlib.sha256(old_raw).hexdigest() == '4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e'
assert hashlib.sha256(new_raw).hexdigest() == '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184'
old, new = old_raw.decode(), new_raw.decode()

def block(source, start, end):
    first = source.index(start)
    return source[first:source.index(end, first)]

old_layout = block(old, 'fn layout(', 'fn compact(')
new_layout = block(new, 'fn layout(', 'fn compact(')
new_tests = block(new, '    fn literal_database_header()', '    #[test]\n    fn budget_checked_reserve_requires_the_original_prepared_plan()')
old_other = old.replace(old_layout, '').replace('fn stamp_mode(', 'pub(super) fn stamp_mode(')
new_other = new.replace(new_layout, '').replace(new_tests, '')
assert old_other == new_other
layout = block(new, 'fn layout(', 'fn database_header(')
header = block(new, 'fn database_header(', 'fn compact(')
assert layout.index('identity(root)?') < layout.index('database_header(&root.join(DB)') < layout.index('stamp(&root.join(OWNER))') < layout.index('stamp(&root.join(POLICY))')
assert 'owner_stamp.identity != owner.owner_identity || owner_bytes != bytes' in layout
assert layout.rstrip().endswith('policy(&policy_bytes, &owner.authority)\n}')
assert block(new, 'fn policy(', 'pub(crate) struct BudgetStore').rstrip().endswith('authority(spec)\n}')
for guard in ['project::check_components(path)?', 'project::checked_file(path)?', 'initial != opened', '&id != expected',
              '(100..=BYTE_LIMIT).contains(&before.len())', 'file.read_exact(&mut header)', 'read_identity(path, &file, &after)? != id',
              'after.len() != before.len()', 'after.modified()', 'current != opened',
              'read_identity(path, current.as_file(), &current_metadata)? != id', 'current_metadata.len() != before.len()',
              'header[18] != 1', 'header[19] != 1', 'options.share_mode(3).custom_flags(0x00200000)']:
    assert guard in header, guard
assert header.count('project::check_components(path)?') == header.count('project::checked_file(path)?') == 2
assert not any(word in header for word in ['write_all(', 'set_len(', 'set_times(', 'fs::remove_file', 'unsafe {'])
assert new_tests.count('    #[test]') == 4
assert 'options.share_mode(7)' in new_tests and 'options.share_mode(7)' not in header
for name, raw in [('before-4ca.rs', old_raw), ('after-2e97.rs', new_raw), ('header-tests.rs', new_tests.encode())]:
    with (OUT / name).open('xb') as stream:
        stream.write(raw)
patch = ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='frozen-Store4ca', tofile='new-Store2e97'))
(OUT / 'whole-source.patch').write_bytes(patch.encode())
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_DB_header_and_single_owner_read_source_review', 'status': 'passed_static_scope_review',
          'before_source': {'path': str(baseline), 'pin': PINS[str(baseline)]}, 'after_source': {'path': str(current), 'pin': PINS[str(current)]},
          'outside_layout_two_new_header_helpers_four_common_tests_and_stamp_visibility_exact_byte_equal': True,
          'root_inventory_before_DB_before_owner_policy_layout_order_checked': True,
          'DB_identity_from_actual_read_handle_and_initial_read_current_handles_held': True,
          'DB_before_after_current_ID_singlelink_regular_reparse_length_mtime_and_component_checks': True,
          'DB_100B_magic_DELETE_versions_length100_to64MiB_checked': True,
          'owner_one_complete_stamp_compares_identity_and_bytes': True,
          'policy_fullstamp_SHA_caps_opening_and_authority_validation_preserved': True,
          'cross_transaction_cache_or_DB_fullbyte_immutable_pin_added': False,
          'open_mode_first_owner_read_scope': 'open_mode still obtains initial owner bytes before layout to learn the original identity. The new before-owner guarantee is specifically layout DB/header before its owner/policy text reads and before SQLite open/query.',
          'new_common_test_definitions': 4, 'new_tests_executed_by_this_reviewer': False,
          'findings': [], 'performance': 'not_measured', 'new_source_Linux_or_Native_behavior_acceptance': 'not_run',
          'old4ca_FP528_passed_results_not_reused_as_new2e97_validation': True}
with (OUT / 'actual.json').open('xb') as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(), 'byte_length': (OUT / 'actual.json').stat().st_size}))
