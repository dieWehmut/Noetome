    fn literal_database_header() -> [u8; 100] {
        let mut bytes = [0_u8; 100];
        bytes[..16].copy_from_slice(b"SQLite format 3\0");
        bytes[18] = 1;
        bytes[19] = 1;
        bytes
    }

    #[test]
    fn budget_db_header_accepts_registered_identity_and_size_boundaries() {
        let f = Fixture::new(100_000);
        let path = f.base.join("header-original");
        let header = literal_database_header();
        fs::write(&path, header).unwrap();
        let expected = identity(&path).unwrap();
        for len in [100, BYTE_LIMIT] {
            OpenOptions::new()
                .write(true)
                .open(&path)
                .unwrap()
                .set_len(len)
                .unwrap();
            database_header(&path, &expected).unwrap();
            assert_eq!(fs::metadata(&path).unwrap().len(), len);
        }
    }

    #[test]
    fn budget_db_header_rejects_same_bytes_mtime_identity_replacement() {
        let f = Fixture::new(100_000);
        let path = f.base.join("header-original");
        let header = literal_database_header();
        fs::write(&path, header).unwrap();
        let expected = identity(&path).unwrap();
        let modified = fs::metadata(&path).unwrap().modified().unwrap();
        let initial = same_file::Handle::from_path(&path).unwrap();
        let mut options = OpenOptions::new();
        options.read(true);
        #[cfg(windows)]
        {
            use std::os::windows::fs::OpenOptionsExt;
            // Test-only deletion sharing permits a real pathname replacement;
            // production database_header keeps the stricter owned share3.
            options.share_mode(7);
        }
        let file = options.open(&path).unwrap();
        let result = database_header_opened(&path, &expected, file, initial, || {
            fs::rename(&path, f.base.join("header-original-retained"))
                .map_err(|e| ProjectError::io(&path, e))?;
            fs::write(&path, header).map_err(|e| ProjectError::io(&path, e))?;
            OpenOptions::new()
                .write(true)
                .open(&path)
                .map_err(|e| ProjectError::io(&path, e))?
                .set_times(fs::FileTimes::new().set_modified(modified))
                .map_err(|e| ProjectError::io(&path, e))
        });
        assert!(result.is_err());
        assert_eq!(fs::read(&path).unwrap(), header);
        assert_eq!(fs::metadata(&path).unwrap().modified().unwrap(), modified);
        assert_ne!(identity(&path).unwrap(), expected);
    }

    #[test]
    fn budget_db_header_rejects_post_snapshot_links_lengths_and_mtime() {
        let f = Fixture::new(100_000);
        for mutation in ["hardlink", "grow", "shrink", "mtime"] {
            let path = f.base.join(format!("header-{mutation}"));
            fs::write(&path, literal_database_header()).unwrap();
            let expected = identity(&path).unwrap();
            let modified = fs::metadata(&path).unwrap().modified().unwrap();
            let initial = same_file::Handle::from_path(&path).unwrap();
            let file = File::open(&path).unwrap();
            let result = database_header_opened(&path, &expected, file, initial, || {
                if mutation == "hardlink" {
                    return fs::hard_link(&path, f.base.join("header-second-link"))
                        .map_err(|e| ProjectError::io(&path, e));
                }
                let writer = OpenOptions::new()
                    .write(true)
                    .open(&path)
                    .map_err(|e| ProjectError::io(&path, e))?;
                if mutation == "mtime" {
                    writer
                        .set_times(
                            fs::FileTimes::new().set_modified(UNIX_EPOCH + Duration::from_secs(20)),
                        )
                        .map_err(|e| ProjectError::io(&path, e))
                } else {
                    writer
                        .set_len(if mutation == "grow" { 101 } else { 99 })
                        .and_then(|_| writer.set_times(fs::FileTimes::new().set_modified(modified)))
                        .map_err(|e| ProjectError::io(&path, e))
                }
            });
            assert!(result.is_err(), "mutation {mutation}");
        }
    }

    #[test]
    fn budget_db_header_rejects_wal_short_over_limit_and_wrong_identity_before_owner() {
        let f = Fixture::new(100_000);
        let path = f.base.join("header-invalid");
        for (name, len, wal) in [
            ("short", 99, false),
            ("over-limit", BYTE_LIMIT + 1, false),
            ("wal", 100, true),
        ] {
            let mut header = literal_database_header();
            if wal {
                header[18] = 2;
                header[19] = 2;
            }
            fs::write(&path, header).unwrap();
            OpenOptions::new()
                .write(true)
                .open(&path)
                .unwrap()
                .set_len(len)
                .unwrap();
            let expected = identity(&path).unwrap();
            assert!(database_header(&path, &expected).is_err(), "{name}");
        }
        fs::write(&path, literal_database_header()).unwrap();
        let other = f.base.join("other-header");
        fs::write(&other, literal_database_header()).unwrap();
        assert!(database_header(&path, &identity(&other).unwrap()).is_err());

        let store = f.store();
        let owner = store.owner.clone();
        let owner_bytes = store.owner_bytes.clone();
        drop(store);
        let db = f.authority.join(DB);
        let mut original = fs::read(&db).unwrap();
        original[18] = 2;
        original[19] = 2;
        fs::write(&db, &original).unwrap();
        // Keep the same allowed name but make opening owner unsafe. A DB/WAL
        // failure must be observed before any read of that owner pathname.
        let owner_path = f.authority.join(OWNER);
        fs::remove_file(&owner_path).unwrap();
        fs::create_dir(&owner_path).unwrap();
        let rejected = layout(&f.authority, &owner, &owner_bytes).unwrap_err();
        assert_eq!(rejected.code(), "REQUEST_BUDGET_INTEGRITY");
        assert!(rejected.to_string().contains("DELETE journal"));
        assert_eq!(fs::read(&db).unwrap(), original);
        assert_eq!(
            names(&f.authority.join("control")).unwrap(),
            BTreeSet::from([
                "budget.sqlite".into(),
                "owner.json".into(),
                "authority.lock".into(),
                "policy.json".into(),
            ])
        );
    }

