from pathlib import Path
import json,hashlib,zipfile,stat
BASE=Path('/home/lyinn/project/Noetome/.artifacts')
PEER=BASE/'b07-t02-linux-final-independent-checker-20261107'
OUT=Path(__file__).parent
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1;b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
manifest=json.loads(read(PEER/'manifest.json')[0]);actual=json.loads(read(PEER/'actual.json')[0]);archive=PEER/'originals.zip';before=read(archive)[1];members=manifest['members'];assert len(members)==actual['members']==4327
records=[]
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())=={r['member'] for r in members}
 for row in members:
  member=z.read(row['member']);p=Path(row['original']);original,pin=read(p);assert member==original and pin==row['pin'] and hashlib.sha256(member).hexdigest()==row['pin']['sha256'] and len(member)==row['pin']['byte_length']
  records.append({'member':row['member'],'sha256':pin['sha256'],'byte_length':pin['byte_length'],'actual_original_identity_mtime_byte_equal':True})
after=read(archive)[1];assert before==after and before['sha256']==actual['archive']['sha256']
r={'producer':'independent_final05_peer_archive_full_readback','status':'passed','archive_before':before,'archive_after':after,'manifest':read(PEER/'manifest.json')[1],'member_count':len(records),'all_full_CRC_SHA_length_actual_original_readback_passed':True,'original_file_current_ID_mtime_byte_equal':True,'records':records,'no_product_HTTP_Cargo_invocations_by_auditor':True}
(OUT/'peer-archive-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':'passed','members':len(records),'peer_archive_sha256':before['sha256'],'actualSHA':hashlib.sha256((OUT/'peer-archive-readback.json').read_bytes()).hexdigest(),'length':(OUT/'peer-archive-readback.json').stat().st_size}))
