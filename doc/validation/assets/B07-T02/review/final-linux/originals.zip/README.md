# Independent final05 Linux evidence audit

This package contains the independent read-only audit of the actual final05
matrix. All original runtime/source/body/response/DB roots and the earlier
review packages remain unchanged. No product, HTTP or Cargo invocation is
performed by this auditor. Native and full-workspace regression are separate.

The full actual matrix is 364 ordinary CLI processes plus 33 explicit drivers,
397 distinct PIDs, 23 real OS kill requests followed by wait/exit -9, 62 groups,
70 actual complete server incoming bodies and 70 UUID-bound receipt rows. The
511 independently checked SQL events belong to 39 valid flow ledgers; the
23 protection groups are checked separately, not counted as valid SQL events.
Each original command receipt/launch and physical stdout/stderr is rehashed.
Original before/after inventories, source fingerprints and author bytes match.

The frozen 14 core expected values and actual request source/body/wire/Core/gold
are checked. R is 5238 + 1024 + 2048 = 8310. Two distinct requests sharing the
same response SHA each cost 700. Persisted Known/Unknown balances, original
opening/spend, near-limit atomic admission, real observe-mode worker threads
and cross-Run PIDs, exact backoff, original absolute deadlines, NotSent release,
typed input invalidation and all protection refusals are independently checked.
Rust ThreadId evidence is not called an OS thread ID.

The accepted interruption has an actual original nine-event live chain before
PID737238 is killed. B already has original transport-sealed Validated/Known700
receipt while its unit terminal is absent. A remains MaySend with no trusted
receipt or sealed transport. Stable originals are checked after actual death
and before ordinary resume. The current original SQL prefix equals that live
chain, and B's key/plan/receipt/file witnesses remain exact after recovery; B
only completes its terminal, with one total HTTP. A's old unknown R8310 remains.
The final balance is Known1400 plus held8310, three dispatched requests.

The two synchronized forgery scenarios now embed exact current report bytes
with LF. JSON/embedded lengths are 2407/2413 bytes. Four actual ordinary CLI
stderr files specifically reject raw-wire usage or candidate/request binding,
rather than stopping at the prior Markdown byte mismatch. Historical failed
or incomplete runs and prior coverage-gap reports remain separately retained.

The complete fixed pair04 CLI and driver bodies are read twice and compared
with the actual build receipt; all current 130 compiled source files equal the
actual source ZIP, whose 130 CRC/SHA/length members are independently checked.
The large ELF bodies remain at their original fixed paths and are not included
in this small reviewer ZIP. Full product-run originals are contained in the
separate checker evidence package; all 4327 members of that package are also
read with CRC/SHA/length and actual original identity/mtime/byte equality.

`actual.json` is the complete audit result. `special-pair-and-source-readback.json`
records the real pair/source/server and special-boundary evidence.
`peer-archive-readback.json` records the independent full member audit of the
checker package. Scripts, physical auditor stdout/stderr and the selected
actual special report/diagnostic originals are included. Python bytecode writes
are disabled throughout, and the full original before/after inventory matches.
