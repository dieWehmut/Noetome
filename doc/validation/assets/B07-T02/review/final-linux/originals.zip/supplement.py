"""Actual final05 source/program/server and special-phase original readback."""
from pathlib import Path
import sys,json,hashlib,stat,sqlite3,importlib.util
sys.dont_write_bytecode=True
REPO=Path('/home/lyinn/project/Noetome')
ROOT=REPO/'.artifacts/b07-t02-request-full-05-20261107'
OUT=Path(__file__).parent
pins={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 fp={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns};assert pins.setdefault(str(p),fp)==fp;return b
def copy(p,n):
 b=read(p);q=OUT/n;q.write_bytes(b);assert read(q)==b;return b
a=json.loads(read(ROOT/'actual.json'));assert len({c['PID'] for c in a['commands']})==397
bind=json.loads(read(ROOT/'source-build-binding.json'));pair=Path(bind['explicit_build_receipt']).parent
programs={}
for name,key in [('noetome','cli'),('request-test-driver','test_driver')]:
 b=read(pair/name);read(pair/name);p=pins[str(pair/name)];assert all(p[k]==bind['receipt_original'][key][k] for k in ['sha256','byte_length']);programs[str(pair/name)]={**p,'complete_original_body_double_read_equal':True}
source=[]
for name,p in bind['source_members'].items():
 b=read(REPO/name);assert hashlib.sha256(b).hexdigest()==p['sha256'] and len(b)==p['byte_length'];source.append({'path':name,'actual':pins[str(REPO/name)],'matches_actual_compiled_source_member':True})
assert len(source)==130
incoming=receipts=0
for p in sorted(ROOT.glob('*/server/server-receipts.json')):
 s=json.loads(read(p));assert not s['errors'] and len(s['incoming'])==len(s['receipts'])==s['observed_HTTP_request_count'] and all(r['body_complete'] for r in s['incoming']);incoming+=len(s['incoming']);receipts+=len(s['receipts'])
assert incoming==receipts==70
sys.path[:0]=[str(ROOT/'checker-source'),str(REPO/'scripts')];spec=importlib.util.spec_from_file_location('final05_special',ROOT/'checker-source/verify_request_budget.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
case=ROOT/'unknown-remote-completion-retained--OS-kill-after-accepted';pre=json.loads(copy(case/'actual-prekill-chain.json','accepted-actual-prekill-chain.json'));old=json.loads(read(case/'independent-audit.json'));kill=next(c for c in a['commands'] if c.get('explicit_request_test_selection',{}).get('NOETOME_REQUEST_TEST_RUN_ROOT')==str(case/'run-main') and c['wait_action']=='actual_OS_force_kill_and_wait')
assert pre['observed_before_kill_utc_ns']<kill['kill_requested_utc_ns']<kill['finished_utc_ns'] and kill['exit_code']==-9
ledger,e=m.read_authority(case/'budget',fixture=REPO/'fixtures/run-api-budget-v1',authority_config=case/'authority-config.json',expected_fingerprint=bind['receipt_original']['actual_cli_fingerprint'],selected_run_roots=[case/'run-main'])
with sqlite3.connect((case/'budget/control/budget.sqlite').as_uri()+'?mode=ro&immutable=1',uri=True) as conn:rows=list(conn.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
length=len(pre['live_validated_chain']);assert [json.loads(r[2]) for r in rows[:length]]==pre['live_validated_chain'];before=m.reconstruct_events(ledger.authority,rows[:length]);b=m.settled_success_attempts(before,'unit-b');assert len(b)==1
key,bp=next(iter(b.items()));assert ledger.attempts[key]==bp
assert all(m.verify_attempt_originals(attempt,before.runs[k[0]],REPO/'fixtures/run-api-budget-v1') for k,attempt in before.attempts.items())
aa=next(v for k,v in before.attempts.items() if k[1]=='unit-a');assert aa['state']=='may_send' and aa['receipt'] is None and not aa['transport_sealed']
server=json.loads(read(case/'server/server-receipts.json'));assert len([r for r in server['receipts'] if r['unit_id']=='unit-b'])==1
accepted={'actual_killed_PID':kill['PID'],'actual_wait_exit_code':-9,'pre_observation_utc_ns':pre['observed_before_kill_utc_ns'],'kill_requested_utc_ns':kill['kill_requested_utc_ns'],'pre_live_original_chain_sequence':length,'pre_B_actual_unit_terminal':next(r['units']['unit-b']['outcome'] for r in before.runs.values()),'post_B_unit_terminal':next(r['units']['unit-b']['outcome'] for r in ledger.runs.values()),'B_same_original_key_plan_receipt_files_exact':True,'B_full_original_source_body_wire_gold_before_after_revalidated':True,'B_HTTP_before_and_after_total':1,'A_before_state':'may_send','A_before_trusted_receipt':None,'A_before_transport_seal':False,'totals_after':ledger.totals(),'original_SQL_pre_chain_equals_real_current_prefix':True}
special=[]
for short,error in [('synchronized-known-usage','原wire独立用量与结算不等'),('synchronized-candidate-wrapper','已批准候选与原wire/请求绑定不等')]:
 croot=ROOT/('protection-'+short);attempt=next((croot/'run-main/attempts/unit-a').iterdir());j=copy(attempt/'validation.json',short+'-actual-validation.json');md=copy(attempt/'validation.md',short+'-actual-validation.md');embedded=md.split(b'```json\n',1)[1].split(b'\n```\n',1)[0];assert j==embedded and b'\r\n' not in md
 commands=[]
 for c in a['commands']:
  label=c.get('label') or ''
  if short in label and 'artifact protection' in label:
   d=ROOT/'commands'/f"{c['number']:04d}";r=copy(d/'stderr.bin',short+f"-PID{c['PID']}-stderr.bin");copy(d/'receipt.json',short+f"-PID{c['PID']}-receipt.json");assert error in r.decode() and '双报告原字节不等' not in r.decode() and c['exit_code']==3;commands.append({'PID':c['PID'],'exit_code':3,'specific_actual_diagnostic':r.decode().strip(),'stderr':c['stderr']})
 assert len(commands)==2;special.append({'case_id':croot.name,'JSON_and_embedded_MD_byte_length':len(j),'exact_original_byte_equal_LF':True,'actual_specific_refusals':commands})
r={'producer':'independent_final05_actual_program_source_special_phase_readback','status':'passed','397_actual_PIDs_unique':True,'all_70_actual_incoming_complete_UUID_receipts_equal':True,'all_actual_program_complete_bodies_double_readback':programs,'all_current_130_compiled_source_files_byte_equal':source,'actual_compiled_source_archive':bind['source_archive'],'accepted_special_actual_original_evidence':accepted,'specific_Core_forgery_gates':special,'no_product_HTTP_Cargo_invocations_by_auditor':True,'native_acceptance_not_claimed':True,'original_actual_pins':pins}
for p in list(pins):
 if not p.startswith(str(OUT)):read(Path(p))
(OUT/'special-pair-and-source-readback.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':'passed','actualSHA':hashlib.sha256((OUT/'special-pair-and-source-readback.json').read_bytes()).hexdigest(),'length':(OUT/'special-pair-and-source-readback.json').stat().st_size,'accepted':accepted,'Core_targets':special}))
