from pathlib import Path
import json,hashlib,stat,zipfile
ROOT=Path(__file__).parent
OUT=ROOT/'package02';OUT.mkdir(exist_ok=False)
members={p.name:p for p in sorted(ROOT.iterdir()) if p.is_file() and p.name not in {'package02-stdout.bin','package02-stderr.bin'}}
for name in ['actual.json','manifest.json']:
 members['package01-original-'+name]=ROOT/'package'/name
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1;b=p.read_bytes();t=p.lstat();assert(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
archive=OUT/'originals.zip';before={};manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in members.items():
  b,pin=read(p);before[name]=pin;z.writestr(name,b);manifest[name]={'original_path':str(p),'original_pin':pin,'sha256':pin['sha256'],'byte_length':len(b)}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)
 for name,p in members.items():
  b,pin=read(p);assert pin==before[name] and z.read(name)==b
  manifest[name]['full_CRC_SHA_length_actual_original_identity_mtime_bytes_before_after_equal']=True
(OUT/'manifest.json').write_text(json.dumps({'members':manifest},indent=2)+'\n')
actual={'producer':'independent_final05_Linux_review_package','status':'passed','members':len(manifest),'archive':read(archive)[1],'manifest':read(OUT/'manifest.json')[1],'all_CRC_SHA_length_actual_original_before_after_readback_passed':True,'actual_scope':{'ordinary_CLI':364,'explicit_driver':33,'distinct_actual_PIDs':397,'real_kill_wait_exit_minus9':23,'groups':62,'actual_complete_HTTP_incoming_and_UUID_receipts':70,'valid_flow_SQL_events':511,'valid_flow_ledgers':39,'protection_groups':23,'compiled_source_members':130,'checker_original_package_members_independently_read':4327},'native_or_full_workspace_acceptance_not_claimed':True,'no_product_HTTP_Cargo_invocations_by_auditor':True,'large_ELF_bodies_not_in_reviewer_ZIP':True}
(OUT/'actual.json').write_text(json.dumps(actual,indent=2)+'\n');print(json.dumps({'members':len(manifest),'archive':actual['archive'],'manifest':actual['manifest'],'actual':read(OUT/'actual.json')[1]}))
