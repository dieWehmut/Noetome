"""Closed 6dd historical release89 and preflight19 originals; no new-source acceptance."""
from pathlib import Path
import binascii,hashlib,io,json,os,stat,zipfile
REPO=Path('/home/lyinn/project/Noetome')
PUBLIC=REPO/'doc/validation/assets/B07-T02'
OUT=Path(__file__).parent
PINS={}
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1,str(p)
 with p.open('rb') as f:a=os.fstat(f.fileno());b=f.read();z=os.fstat(f.fileno())
 t=p.lstat();shape=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mtime_ns,q.st_nlink)
 assert shape(s)==shape(a)==shape(z)==shape(t),str(p)
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink};assert PINS.setdefault(str(p),v)==v;return b
def check(raw,pin):assert hashlib.sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['byte_length']
r=PUBLIC/'windows-release';manifest=json.loads(read(r/'manifest.json'));receipt=json.loads(read(r/'receipt.json'));copy=json.loads(read(r/'copy-receipt.json'));root=Path(receipt['source_root']);raw=read(r/'originals.zip');check(raw,receipt['archive']);assert len(manifest)==receipt['members']==89
ordinary=[];nested=[]
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert len(z.namelist())==len(set(z.namelist()))==89 and set(z.namelist())==set(manifest)
 for name,pin in manifest.items():
  b=z.read(name);check(b,pin);assert (binascii.crc32(b)&0xffffffff)==z.getinfo(name).CRC;assert read(root/name)==b
  actual=PINS[str(root/name)];m=pin['original_metadata'];assert actual['device']==m['device'] and actual['inode']==m['inode'] and actual['mtime_ns']==m['mtime_ns'] and actual['byte_length']==m['size'];assert stat.S_IMODE((root/name).lstat().st_mode)==m['mode']
  ordinary.append({'member':name,'original':str(root/name),'pin':actual,'CRC':z.getinfo(name).CRC,'exact_equal':True})
 snapshot=json.loads(z.read('snapshot.json'));source_bytes=z.read('source-originals.zip');main=json.loads(z.read('native-final.json'))
 assert main['actual_cli_and_driver_compiler_fingerprint']=='6dd8c9cab44153af6ec7234ad4ee9bb321b7405d61a77b84ef4a3c6f39b6383f'
 assert main['status']=='passed_release_build_and_probes_only' and len(main['commands'])==11 and all(x['exit_code']==0 for x in main['commands'])
 for name in ['release-build-receipt.json','selected-build-receipt.json','outer-native-result.json']:
  b=read(r/name);assert b==z.read(name)==read(root/name);check(b,copy['copies'][name]);assert json.loads(z.read('outer-native-result.json'))['exit_code']==0
  c=copy['copies'][name];p=PINS[str(root/name)];assert p['device']==c['original_WSL_device'] and p['inode']==c['original_WSL_inode'] and p['mtime_ns']==c['original_mtime_ns']
 with zipfile.ZipFile(io.BytesIO(source_bytes)) as src:
  assert len(src.namelist())==len(set(src.namelist()))==2061 and len(snapshot['files'])==2056
  for name,pin in snapshot['files'].items():
   member='repo/'+name;b=src.read(member);check(b,pin);assert (binascii.crc32(b)&0xffffffff)==src.getinfo(member).CRC;assert read(root/'repo'/name)==b
   nested.append({'member':member,'pin':pin,'native_frozen_source_original':PINS[str(root/'repo'/name)],'CRC':src.getinfo(member).CRC})
  aux=set(src.namelist())-{'repo/'+name for name in snapshot['files']};assert len(aux)==5
  for name in sorted(aux):
   b=src.read(name);assert b==z.read(name) and (binascii.crc32(b)&0xffffffff)==src.getinfo(name).CRC
   nested.append({'member':name,'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'CRC':src.getinfo(name).CRC})
 assert snapshot['files']['crates/noetome-cli/src/request_budget_store.rs']['sha256']=='f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349'
 assert snapshot['files']['crates/noetome-cli/src/request_run.rs']['sha256']=='8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc'
p=PUBLIC/'review/windows-release-preflight';pre_manifest=json.loads(read(p/'manifest.json'));pre_actual=json.loads(read(p/'actual.json'));assert pre_actual['status']=='passed' and pre_manifest['member_count']==19
pre=[]
with zipfile.ZipFile(io.BytesIO(read(p/'originals.zip'))) as z:
 assert len(z.namelist())==len(set(z.namelist()))==19
 for entry in pre_manifest['members']:
  b=z.read(entry['member']);check(b,entry['pin']);assert (binascii.crc32(b)&0xffffffff)==z.getinfo(entry['member']).CRC;assert read(Path(entry['original']))==b and PINS[entry['original']]==entry['pin']
  pre.append({'member':entry['member'],'original':entry['original'],'pin':entry['pin'],'CRC':z.getinfo(entry['member']).CRC})
 for name in ['review/readback-attempt01.py','review/attempt01.stderr.bin']:assert name in z.namelist()
 assert b'KeyError' in z.read('review/attempt01.stderr.bin') and b'.gitattributes' in z.read('review/attempt01.stderr.bin')
for path in list(PINS):read(Path(path))
result={'status':'passed_independent_6dd_historical_release_and_preflight_archive_readback','scope':'Closed6dd release build/source/wholePE89 and prior preflight19 original readback only. Nested sourceZIP2061 independently CRC/SHA/length and frozen Native source bytes checked. Current Root stamp optimization may change production source; no current-Root equality or future-source Rust/Python/Native62 acceptance inferred. Original native elapsed/three targets did not complete main62; their separate execution results are preserved elsewhere.',
        'new_product_HTTP_Cargo_Native_invocations':0,'main_archive_members':89,'preflight_archive_members':19,'nested_source_members':2061,'total_CRC_SHA_length_members_including_nested':2169,'main_members':ordinary,'nested_members':nested,'preflight_members':pre,'first_preflight_repo_prefix_parser_failure_preserved':True,'all_original_read_pins':PINS}
b=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode();(OUT/'actual.json').write_bytes(b)
print(json.dumps({'status':'passed','main':89,'preflight':19,'nested':2061,'total_members':2169,'actual_sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'main_zip':PINS[str(r/'originals.zip')]}))
