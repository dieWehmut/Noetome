"""Package reviewer-local source/old6dd readback proof, no D rereads or products."""
from pathlib import Path
import hashlib,json,os,stat,zipfile,binascii
REPO=Path('/home/lyinn/project/Noetome');HERE=Path(__file__).parent;OUT=HERE/'package'
def capture(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 with p.open('rb') as f:a=os.fstat(f.fileno());b=f.read();z=os.fstat(f.fileno())
 t=p.lstat();shape=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mtime_ns,q.st_nlink);assert shape(s)==shape(a)==shape(z)==shape(t)
 return b,{'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
def save(p,d):
 with p.open('x') as f:f.write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
sources=[('handle-source',REPO/'.artifacts/b07-t02-handle-stamp-source-independent-review-20261107'),('historical6dd89-and19',REPO/'.artifacts/b07-t02-native6dd-history-public-readback-20261107'),('release05-full08-static',REPO/'.artifacts/b07-t02-release05-full08-static-independent-review-20261107')]
source_review=json.loads(capture(sources[0][1]/'actual.json')[0]);hist=json.loads(capture(sources[1][1]/'actual.json')[0]);guard=json.loads(capture(sources[0][1]/'guard02-independent-readback.json')[0])
assert source_review['status']=='passed_independent_handle_stamp_source_review' and hist['total_CRC_SHA_length_members_including_nested']==2169 and guard['raw_module_passed38']==38
assert not OUT.exists();OUT.mkdir()
scope='Current4ca handle-stamp source exact-delta independent review and Root actual Linux38 module raw/source130 readback; historical6dd release89+preflight19 with nested2061 full original archive readback. These are separate scopes: old6dd failure history is not reused as new4ca Native acceptance. No products/HTTP/Cargo/Native or D reads by this package collector.'
(OUT/'README.md').write_text('本包保存独立句柄读取源码审查：旧f765→新4ca只有stamp/read_identity/stamp_opened及7新test定义改变，移除批准块后整文件字节相等；元数据regular/reparse/单link、before/after/current实际read handle身份与成功mtime/len、bounded full bytes、share3/share1、组件首尾重查均保留，没有跨调用cache。Root guard02真实Linux PID801707/exit0/raw38pass及130源码前后/current绑定原件一并保存。7新增定义的实际增量Linux+6/Windows+5；全39defs中3Unix-only/1Win-only，所以Linux38/Windows36。原早先message的Windows37估计已在后续clarification更正，未改原source审查结果。Windows36列举和全798期待不能当测试执行。\n\n另保存旧6dd release89+preflight19及其nested2061的2169完整CRC/SHA/长度与原件ID/mtime/bytes独审；只当历史构建/预检，old Native elapsed NoFit/accepted和main62未运行另有原件。早期NativeRelease01的2156成员失败包已经独立保存，CLI只取早已保存6560本体、driver notbuilt/selectedruntime0、prepare03 partial2056/0Cargo。这里仅保留其直接copyreceipt/parser说明，不重复完整PE、SourceZIP、主失败/回归巨包。\n',encoding='utf-8',newline='\n')
pairs=[]
for prefix,root in sources:pairs += [(prefix+'/'+p.name,p) for p in sorted(root.iterdir()) if p.is_file()]
pub=REPO/'doc/validation/assets/B07-T02/windows-release-failures-history'
pairs += [('release01-prepare03-failure-proof/'+name,pub/name) for name in ['actual.json','copy-receipt.json','collector-parser-note.json']]
pairs += [('README.md',OUT/'README.md'),('collector/collect.py',Path(__file__).absolute())]
before=[{'member':n,'original':str(p),'pin':capture(p)[1]} for n,p in pairs];assert len({v['member'] for v in before})==len(before)
with zipfile.ZipFile(OUT/'originals.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for v in before:z.writestr(v['member'],capture(Path(v['original']))[0])
with zipfile.ZipFile(OUT/'originals.zip') as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(before)
 for v in before:
  b=z.read(v['member']);raw,pin=capture(Path(v['original']));assert b==raw and pin==v['pin'] and (binascii.crc32(b)&0xffffffff)==z.getinfo(v['member']).CRC
save(OUT/'manifest.json',{'member_count':len(before),'members':before,'scope':scope})
save(OUT/'actual.json',{'status':'passed','members':len(before),'all_CRC_SHA_length_original_ID_mtime_bytes_equal':True,'Root_actual_Linux_module_pass38':38,'source130_before_after_current_bound':True,'historical_6dd_original_archive_readback_members_including_nested':2169,'no_D_reads_or_new_product_invocations':True,'scope':scope})
print(json.dumps({'status':'passed','members':len(before),'ZIP':capture(OUT/'originals.zip')[1],'manifest':capture(OUT/'manifest.json')[1],'actual':capture(OUT/'actual.json')[1]}))
