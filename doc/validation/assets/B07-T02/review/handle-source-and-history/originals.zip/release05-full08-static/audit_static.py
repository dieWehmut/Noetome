from pathlib import Path
import ast,hashlib,json
ROOT=Path(__file__).parent
a=(ROOT/'release-before04.py').read_bytes();b=(ROOT/'release-after05.py').read_bytes()
assert b.replace(b'4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e',b'f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349').replace(b"'byte_length': 142612",b"'byte_length': 133950")==a
x=(ROOT/'full-before07.py').read_bytes();y=(ROOT/'full-after08.py').read_bytes();ta=ast.parse(x);tb=ast.parse(y)
fa={n.name:ast.dump(n,include_attributes=False) for n in ta.body if isinstance(n,ast.FunctionDef)};fb={n.name:ast.dump(n,include_attributes=False) for n in tb.body if isinstance(n,ast.FunctionDef)}
changed=[n for n in fa if fa[n]!=fb[n]];assert set(changed)=={'prepare','native'}
for n in tb.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCE_PINS' for t in n.targets):pins=ast.literal_eval(n.value)
assert len(pins)==4
for name,pin in pins.items():
 raw=Path('/home/lyinn/project/Noetome',name).read_bytes();assert hashlib.sha256(raw).hexdigest()==pin['sha256'] and len(raw)==pin['byte_length']
r={'status':'passed_static_only','release05_sha256':hashlib.sha256(b).hexdigest(),'full08_sha256':hashlib.sha256(y).hexdigest(),'release05_restoring_only_Store_SHA_and_length_equals_actual04_whole_file':True,'full08_changed_functions_only':changed,'all_other_full_helper_function_AST_identical':True,'full08_four_current_source_pins_exact':pins,'fullRust_expected_Native':798,'Windows_budget_module_active_definitions':36,'prepare_Cargo_HTTP_Native_invocations_by_auditor':0,'scope':'Static ready draft only; all current native release builds/fullRust/fullPython/behavior must actually run. No previous test results reused.'}
raw=(json.dumps(r,indent=2)+'\n').encode();(ROOT/'actual.json').write_bytes(raw);print(json.dumps({'status':'passed','actual_sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}))
