# B07-T02 持久预算预留、有界重试与隔离验收

本项仍在执行，尚未完成日志或推送。依据[任务账本](../../dev-log/tasks.json)、[执行方案](../execution/B07-T02_BUDGET_PLAN.md)和[请求预算契约](../technical/REQUEST_BUDGET_CONTRACT.md)。本文记录实际结果与失败历史；未运行项不从代码、编译或文件存在推定通过。

## 范围与先验作者

只复用既有单请求Responses适配器，通过人工凭据和数字环回HTTP运行至多两个并发工作线程。明确新的synthetic项目、authority和Run根；真实模型/付费调用0，不读取真实累计10000000授权账本、真实凭据、生产Vault或未经选取的私人资料。候选始终知识pending、科学not_run、published=false。

[作者包](../../fixtures/run-api-budget-v1/README.md)的45个原件、14个核心case及5个明列变体先于实现冻结。锚为`ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272`。旧Core零请求预检确定正文5238B、输入预留6262、输出上限2048，即R8310；近限额9009使真实700结算后只余8309，不能接纳第二个R。只有六个36字节UUID槽可变化，其余正文逐字核对。合法用量坏候选与同SHA两个不同请求分别计量，不把自造故障case计成独立科学样本。

作者先验原件与审查保存在[原件包](assets/B07-T02/author/originals.zip)。作者静态169检查不作为产品行为通过；普通旧CLI的`run api init`实际退出2、未建预算根、HTTP0，作为新入口真实RED保存于[诊断原件](assets/B07-T02/diagnostic-originals/originals.zip)。

## 实现

新增`run api init/start/resume/status`，使用独立Schema1 SQLite authority和严格追加事件链。原policy文件固定opening与上限，Run登记在其外部保存owner/worker及原目录、文件身份。Prepared封存正文，Reserved原子占R和请求slot，MaySend只准入一次；Unknown保留R及已派发次数，Known按真实Token结算，同attempt重复交付不重复累计。

原单请求Noop路径保留原库存与计时。新hooks在传输原件sync并由预算事件封存后提供真实终止边界；原HTTP framing和用量与候选核验分别保存。输入变化时可只恢复已封存用量并使Run失效，不通过读取变更凭据或再次HTTP完成候选。预留等待与候选验证受原Unit/Run剩余期限约束，通过MaySend门槛后HTTP才启动冻结200ms计时，仍取原期限剩余的较小值。

普通重试限定五类实际HTTP/传输故障，且用量未知、不是完整HTTP200。退避先持久保存，次数、retry Token及原绝对期限分别限制。REQUEST_INTERRUPTED为明确恢复分类，旧Unknown承诺保留；候选、认证、来源或输出失败不借同名TIMEOUT进入网络重试。未MaySend的Prepared/Reserved到期以协议证明NotSent释放；MaySend/Unknown退款须有已封存零发送证据。

## 当前候选与实际验证

当前冻结Run为 `b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c`/74782B，Store为 `2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184`/151556B；checker仍为3b263fca、Python测试仍为42825f8a。共享读取与DB头核验已单独提交为`29afa5c`，当前分支尚未推送。作者45件锚、1500ms原单元期限、1000ms退避、200ms API计时、预算expected与真实强杀验收门槛均未改。

Run的原件读取委托给已经验证的实际句柄函数；Run及预算owner均使用一次stamp同时证明身份与完整字节。SQLite头读取先核对登记身份，再以同一实际读取句柄核对100字节头部、长度、mtime、单链接及首尾路径身份；仍要求DELETE头标记并在每次新事务中重建完整链与witness，不缓存数据库内容或余额。布局验证中的DB头先于owner/policy文本读取；初次open仍须读取owner才能取得登记身份。全局身份、零字节锁、输入库存及所有原持久阶段保留。

| 当前b393/2e97范围 | 实际结果 | 可复核原件 |
| --- | --- | --- |
| Linux精确预算模块/格式/检查 | 42模块通过/0失败/476过滤；Cargo PID815761/exit0/14.272833秒，fmt PID816931与all-targets check PID816959均exit0 | [41件诊断与130来源原件](assets/B07-T02/diagnostic-shared-header/originals.zip)；新增4个共同DB头实质测试，Run新增测试0，Windows模块40及完整Rust802此时尚未运行 |
| Linux新release配对 | CLI Cargo PID817163/59.656106秒、driver no-run Cargo PID818030/77.419095秒，实际CLI probe PID818637均exit0 | FP `89136b36bc30a77c5e7a1a54fd480c8d06be89e060377f1482954fbed12433b0`，130输入身份/mtime/字节前后相同；no-run不计测试通过 |
| Linux完整预算矩阵 | 62全部通过；364普通CLI+33driver=397唯一PID全部wait，70HTTP，23真实SIGKILL均wait exit -9，server errors0 | [原执行JSON](assets/B07-T02/linux-run-shared-header/execution.json) SHA `bed3bcc92674a001a968dbeadfa46a3ee74a53ddc3bab3941d3d04a1181a4da9`/633966B；[完整3792成员包](assets/B07-T02/linux-run-shared-header/originals.zip)，没有额外三个Linux目标 |
| Linux完整Python | PID818751/exit0/80.550407秒，466项=444通过+22平台跳过 | [原执行JSON](assets/B07-T02/linux-python-shared-header/actual.json) SHA `e4e85254506ce60df37cb83e2b076d29ae7254926e3fdba7e17b742d4634b426`/6881B；2056工作区源、2058快照/别名及原CLI/两回执身份/mtime/字节前后相同；[15185成员原件包](assets/B07-T02/linux-python-shared-header/originals.zip) |
| Windows新release06 | 已授权新根prepare及真实双Cargo，最终结果待实际闭合 | [85件源码、两草稿及原静态审查](assets/B07-T02/review/shared-header-source/originals.zip)仅证明源码与执行门禁审查，不作为Windows行为或全回归通过 |

两份当前完整ELF保存于[CLI ZIP](assets/B07-T02/programs-shared-header/linux-shared-header-pair-01-noetome.zip)、[driver ZIP](assets/B07-T02/programs-shared-header/linux-shared-header-pair-01-request-test-driver.zip)及[清单](assets/B07-T02/programs-shared-header/manifest.json)。原CLI SHA `517234798788beb5cc28830d1f8d16c203341542c5bce422c9fecdcc6998391f`/17820792B，driver SHA `44591b8d9794606ac89fb5e20147b8a52075139ed7eb0fdfdbe4987126cb1cbe`/23860992B。完整Linux Rust未运行，文件与运行时目录身份守卫范围不扩大声明。

[Python直接成员说明](assets/B07-T02/linux-python-shared-header/materialization-receipt.json)证明三个便于阅读的JSON从已封存ZIP逐成员CRC/SHA/长度精确取出，manifest保留原件metadata。主矩阵3792成员为3791普通原件及1明确生成引用，standalone builder在生成前保存。以下旧4ca及更早结果各自绑定原源码，不作本次候选验收。

### 已归档4ca候选的结果

4ca候选在Windows正式三个目标中再次错过elapsed边界：B先提交使A首个settled在原clock后609.0124ms，不能容纳原1000ms退避，accepted与main62未运行；backoff真实WinKill71916/wait exit1通过。普通额外对照实际9CLI/2HTTP/1WinKill71712并按原期限恢复，最后状态正确退出3，但89d诊断包装器硬期待0使整个额外对照失败。[348成员失败原件](assets/B07-T02/deadline-stamp-history/originals.zip)均保留，不标整体通过；新增[单点期望更正](assets/B07-T02/deadline-stamp-history/diagnostic-status-expectation.json)只把后继私有诊断的最后status期望改为3，不重跑或改写旧结果。该候选Run为 `8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc`，Store为 `4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e`/142612B；以下结果均是这两份历史源码的实际记录。

新`stamp_mode`把FileStamp身份取自实际读取句柄，保留首尾`check_components`和普通叶子门槛，initial/opened/current三句柄活到最终比较。实际读取句柄前后和最终路径句柄均检查ordinary/reparse、单硬链接、持久ID、成功取得的mtime及长度；仍读取完整有界字节并计算SHA。owned Share3及external原Share1守卫不变，`empty_stamp`、全局`compile_identity`和每次事务完整重建/witness不变，没有跨调用或事务缓存。

读取优化已单独提交为`bf716ec`，当前分支尚未推送。最终4ca源码的Linux预算模块实际38通过/0失败/476过滤，Cargo PID801707/exit0/8.131620秒，130输入身份/mtime/字节前后完全相同。新增4个共同负例、2个Unix负例，另一个Windows共享模式负例尚未运行；初稿38通过后补强最终current句柄长度/mtime检查，初稿与最终两份真实运行分别保存。完整源码静态有39个测试定义，其中3个Unix-only和1个Windows-only，因此Linux实际38、Windows预计36；Windows具体执行数量仍须实际回执。

| 当前4ca源码范围 | 实际结果 | 可复核原件 |
| --- | --- | --- |
| Linux精确预算模块/格式/检查 | 38模块通过/476过滤；fmt PID802245及all-targets check PID802274均exit0 | [全部命令与130来源原件](assets/B07-T02/diagnostic-stamp/originals.zip)，完整Linux Rust未运行 |
| Linux新release CLI/driver | CLI Cargo PID802332/61.445138秒、driver no-run Cargo PID803133/67.590468秒，实际probe PID803899均exit0 | FP `528f2214e192d365a4c7c1cfef900aa2e8335bd0d829f7bcc0ac795c190f817a`；同上构建原件。no-run不计模块测试通过 |
| Linux完整预算矩阵 | 62全部通过，364普通CLI+33driver=397唯一PID全部wait，70HTTP，23真实SIGKILL均exit -9，server errors0 | [原执行JSON](assets/B07-T02/linux-run-stamp/execution.json) SHA `b92e4029716dafebb542281cb3954cf6760c0aa090f61d7a72ef54af199a7a1f`/624794B；[全部原件](assets/B07-T02/linux-run-stamp/originals.zip)，没有额外三个目标重复计数 |
| Linux完整Python | PID804331/exit0/83.678837秒，466项=444通过+22平台跳过 | [原执行JSON](assets/B07-T02/linux-python-stamp/actual.json) SHA `60694cab655a3f093abe774b4d0129d3445d232cb6efe3d28e5f2028b808b064`/6873B；2056工作区源与2058快照/别名、原CLI及回执身份/mtime/字节均不变；[全部原件](assets/B07-T02/linux-python-stamp/originals.zip) |
| Windows新release构建 | prepare PID805489、CLI Cargo PID83432/93.750秒、driver Cargo PID67280/116.484秒，11命令及外层PID806281实际wait均exit0 | 新FP `4650f37f3a11299739f8ace768ca6cb5317d3ecb6957d9d0edba26b9981fe680`；[构建原回执](assets/B07-T02/windows-release-stamp/release-build-receipt.json)、[外层原等待](assets/B07-T02/windows-release-stamp/outer-native-result.json)、[全部程序/源/命令原件](assets/B07-T02/windows-release-stamp/originals.zip)；未运行完整Windows Rust/Python或受控中断 |

两份当前完整ELF为[CLI ZIP](assets/B07-T02/programs-stamp/linux-stamp-pair-01-noetome.zip)、[driver ZIP](assets/B07-T02/programs-stamp/linux-stamp-pair-01-request-test-driver.zip)，[清单](assets/B07-T02/programs-stamp/manifest.json)固定同一FP。CLI SHA `3b4c7610dae7bee9144d2b708cc747bb71471bd7ede0d54ca3ede11ec48e1c48`/17866000B；driver SHA `a377cb6c15382b473a584de4198bab3c8ad6a8544f9d4dccfbe38961814360ea`/23697200B。

当前两份完整Windows PE包含在上述89成员包：CLI SHA `38a1377c9cb9876244c2151299e8d91e539dfa7c0ff22ecdc0878b7c6ccbfcb1`/16047104B，driver SHA `dbf668a4816c7c738462c02bc5ccdfa9a6124a27cc02f26aaaa86d4bbb9c25ac`/22861312B；两Cargo及运行probe同FP。2056源/2061 ZIP全读回，2065旧guard全部保持原ID/mtime/单链接，仅注册两selected成2067；Windows模块实际`--list`36只作为列举。当前完整源码审查与后续wrapper静态检查见[47件源审原件](assets/B07-T02/review/stamp-source/originals.zip)、[Rust实现与当前构建执行原件](assets/B07-T02/review/stamp-rust-implementation/originals.zip)。

初稿guard01源未额外保存为独立原文件，后补重建9a703515…/142421B精确匹配当时source-before记录；它仅删除最终新增current句柄len/mtime条件。报告明确原FileID/mtime没有恢复、初稿test executable没有保存，不把后补源码冒充原副本；当前验收用真实guard02和4ca的新CLI/driver。

新Linux矩阵3793成员=3792普通原件+1明确生成引用；standalone builder在生成前已留源。[Python直接成员说明](assets/B07-T02/linux-python-stamp/materialization-receipt.json)证明三个便于阅读的JSON从已封存ZIP逐成员CRC/SHA/长度精确取出，保留manifest中的原件metadata，不重新拼写执行时间或计数。这些保存操作没有重跑测试。Windows受控中断与全62、完整Rust/Python仍需实际通过；以下旧源码结果均不复用为4ca的通过证据。

### 事务读优化候选的历史结果

上一候选request_run为8e4d、request_budget_store为 `f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349`，对应修复提交`36dd8c8`。其Linux完整矩阵和Python实际通过，Windowsrelease04构建与独立预检通过；随后普通对照6CLI/0driver/2HTTP/0强杀，A settled在原clock后693.9051ms而NoFit。受控三个目标实际11CLI+2driver/5HTTP，退避目标真实WinKill PID34496/wait exit1通过，elapsed driver PID81348在第一settled后508.0162ms已无法容纳原退避，随后自然exit0，未观察retry/A2、没有该目标OS强杀；accepted和主62均未启动。两阶段所有所选PID均实际wait，源/完整PE/driver/作者/checker/哨兵守卫相同；自然NoFit保留为失败诊断，不能代替真实中断恢复通过。[新旧失败原件](assets/B07-T02/deadline-handle-history/originals.zip)和[更早构建/零Cargo准备失败](assets/B07-T02/windows-release-failures-history/originals.zip)分别保存，旧release02两完整程序另见[89件历史包](assets/B07-T02/windows-release-history-02/originals.zip)。

优化保留Prepared和Reserved独立COMMIT及全部提交回调，`reserve_prepared_checked`在新IMMEDIATE完整load/witness内核对同一plan，省掉幂等prepare的无事件事务。Run owner/输入/库存/stop检查在该事务完整链重建后、重新取now之前执行，再进行原caps/deadline/due判断，postlayout不变。Hooks借用当前unit已有连接，每次事务仍重新完整校验，不缓存余额。API返回后的receipt检查绑定完整attempt四元组，放在下一轮新view中、任何终态或retry判断之前；旧错误和denial处理保留。

| 当前源码的范围 | 实际结果 | 原件与限制 |
| --- | --- | --- |
| Linux release编译来源 | CLI Cargo PID788197/59.997717秒、driver no-run Cargo PID788886/0.153825秒均exit0；CLI probe PID789153/exit0 | FP `288fa7c28897954aebe42ebbd82d328f1c72a47f7d39cd867638aa91f77ac76f`，130来源身份/mtime/字节前后相同；[构建原件](assets/B07-T02/diagnostic-transaction/originals.zip) |
| Linux完整预算矩阵 | 62案全部通过，364普通CLI+33driver共397唯一实际PID/全部wait，70实际HTTP，23实际SIGKILL均wait exit -9 | [实际执行](assets/B07-T02/linux-run-transaction/execution.json) SHA `fb5ff2b0db73a55053645f8afb3ce6d883459f51f4766e0066d7209c1f2c8f2e`；[全部原件](assets/B07-T02/linux-run-transaction/originals.zip)，elapsed/accepted已包含，不另加三个目标运行计数 |
| Linux完整Python | 466项=444通过+22平台跳过，PID791318/exit0/88.964112秒 | [实际结果](assets/B07-T02/linux-python-transaction/actual.json) SHA `5e44c75dbe9e72061f02512cb0bcbbc9fd9944b4260205ffa42f57359c410c44`；2056工作区来源/2058快照和别名、原CLI及回执身份/mtime/字节守卫通过；[全部原件](assets/B07-T02/linux-python-transaction/originals.zip) |
| Linux精确预算模块及静态检查 | 32模块测试/0失败/476过滤，PID787189/exit0/67.784169秒；fmt和all-targets check实际exit0 | 新增4个实质负例；[32测试与源护栏独审](assets/B07-T02/review/transaction-source/originals.zip)，每次事务仍全链重建；完整Linux Rust未运行 |
| Windows当前release构建 | CLI Cargo PID84924/87.813秒、driver Cargo PID79584/100.188秒及双程序探针均exit0；11实际命令与最外层等待均exit0 | FP `6dd8c9cab44153af6ec7234ad4ee9bb321b7405d61a77b84ef4a3c6f39b6383f`；[实际构建回执](assets/B07-T02/windows-release/release-build-receipt.json)、[外层实际等待](assets/B07-T02/windows-release/outer-native-result.json)、[程序及构建全部原件](assets/B07-T02/windows-release/originals.zip)；不充作完整Rust793/Python527或HTTP验收 |

当前完整ELF为[CLI ZIP](assets/B07-T02/programs-transaction/linux-transaction-pair-01-noetome.zip)、[driver ZIP](assets/B07-T02/programs-transaction/linux-transaction-pair-01-request-test-driver.zip)，[程序清单](assets/B07-T02/programs-transaction/manifest.json)绑定同一FP。CLI SHA `fa1a35006548b8e5ffd8800edc5944897950d7d90294f4c42697b0beeece0d14`/17868304B，driver SHA `cbf5d5e289b0db3b765cb490252844badd63d969c1287af6de3dcc1cd49b800b`/23676112B。主矩阵包3790成员=3789普通原件+1生成引用；本次standalone归档builder在生成前已保存，原SHA `1e6b206c5fcb5220d0f2e364ed81f480c5d2531b1c8414fdcf065d2ab55abafb`，不把旧inline builder的后补重建当原始源。

当前Windows完整PE已包含在上述windows-release原件包中：CLI SHA `3972ef561eb2c86bd3902a7682dfa5eae9c4236dcdf285c10ca4fa708929d164`/16045568B，driver SHA `57c0fb749f50221743951863469698f79f44e123a9defa432f497cd89bf11aa7`/22749696B。独立初始审查实际核对2056来源、2061 ZIP、四份93/129/129/1913整表、8控制原件、两完整程序和原生2067文件metadata；原2065条完全相同，仅新增两selected文件。该初始审查本身0HTTP，不替代后续真实中断；目录与工具未持有固定ID的范围不扩大声明。

release03准备曾误指定不存在的`release02/build-target`，实际0Cargo失败。release04把物理缓存`release01/build-target`与证明后续编译闭合的release02回执根分开固定，核对release02原cache-scope的实际CARGO_TARGET_DIR，并只允许两个明确old/new源码差异。两次当前Cargo及双指纹探针均重新执行，未从旧结果推新源码通过，也没有创建假缓存目录或改旧原件。

### 优化前release候选的历史结果

| 范围 | 实际结果 | 来源及可复核入口 |
| --- | --- | --- |
| 当前Linux release构建 | CLI Cargo PID767398/102.654秒、driver Cargo PID770426/68.826秒，均exit0；实际CLI探针PID771321与两份Cargo指纹一致 | FP `e3da041f1c0862483d352f5821fd7941bd9e633012fb1c8f22723eb47ab49b5f`，130项Rust/Cargo来源身份、mtime、字节前后相同；[构建原件](assets/B07-T02/diagnostic-release/originals.zip) |
| 当前Linux完整行为矩阵 | 62案通过；364普通CLI+33driver共397唯一实际PID，70实际HTTP，23次真实SIGKILL/wait均exit -9 | 原执行actual SHA `dd44b56761b48d0254f148f19c0212f2f453dd0724f185d8c0cbd84f292d664e`；[完整原件](assets/B07-T02/linux-run-release/originals.zip) |
| 当前Linux三个双单元目标 | 18普通CLI+3driver，8HTTP、3次真实SIGKILL/wait；backoff/elapsed/accepted均通过 | 独立补充运行，不加入主矩阵62/397/70/23；原actual SHA `67753f0fd409c102f3d17e02f353ec0d9832b47afbb57033b9a456e53bf1b940`，同上述原件包 |
| 当前Linux完整Python | 466项，444通过、22平台跳过，实际PID776536/exit0/113.426591秒 | [实际结果](assets/B07-T02/linux-python-release/actual.json) SHA `4404dd0f0b540d5b231cd7e9ba503920ac112bac909acbd8ad005ce3c818987c`；2056工作区来源与2058快照（额外2件CLI别名）、原CLI及2回执的文件身份/mtime/字节均前后相同；[完整原件](assets/B07-T02/linux-python-release/originals.zip) |
| 当前Linux针对性Rust与静态检查 | 28项request_budget_store模块release测试实际通过，cargo fmt全check、CLI all-targets check均exit0 | 28为精确模块范围；历史宽过滤30另含2项其他模块测试，不能混计；完整Linux Rust未运行 |
| 当前Linux独立核对 | 39有效流程账本、511事件、23保护组，397进程原始输出、70HTTP、23强杀及完整程序体/来源均逐项通过 | [审查结果](assets/B07-T02/review/release-linux/actual.json)、[审查原件](assets/B07-T02/review/release-linux/originals.zip)；主包4050成员=4049原件+1明确生成的历史引用 |
| 当前Windows release构建 | CLI Cargo PID8796/87.782秒、driver Cargo PID80476/100.641秒，双运行时探针及最外层wait均exit0 | FP `44a16b70f9d09212309902d1120f5eab5fe842af71cd0860f2bb50114722ac41`；2056来源、8控制原件及选定程序身份守卫通过。构建通过不作为HTTP或完整Rust/Python通过 |

两个当前Linux完整ELF单独保存于[CLI ZIP](assets/B07-T02/programs-release/linux-release-pair-01-noetome.zip)、[driver ZIP](assets/B07-T02/programs-release/linux-release-pair-01-request-test-driver.zip)和[程序清单](assets/B07-T02/programs-release/manifest.json)。CLI SHA `9089d51ef4e5e1334e650c184c13bf2476a9ac82d2c25ea00b52f87f1ed771be`/17858808B，driver SHA `1ad524e903314490dac924c9deddda89dc3511e8bcdefdd67fd81a696585cc77`/23566648B。当前Windows选定CLI SHA `08246181e7c9d2ff57387977d5d8ceb2075b7dc8c6eb520611eb43296d9d6cf5`/16041984B、driver SHA `8a65d3972ccfa08c1e81a1c993d413fb6cada4436ea0601a6c3cb615d13aa6b9`/22715904B；这两份release程序与Linux程序不互相替代。

单点driver只在选中的持久回调读取完整账本并握手；trace/observe继续保留全部回调。accepted案先在A的MaySend提交后、HTTP计时前控制等待，让B完整200/Known700及单元终态稳定并核对原件，再精确release、观察服务器实际接收A、立即OS kill/wait。backoff/elapsed案即时返回原429，A停在retry提交，B独立完成后严格核对全部原件、在原retry_at前强杀。它们证明选定调度下真实持久边界恢复；不声称自然调度下任何时限都必然取得该边界。

当前Linux完整Python守卫覆盖具名普通文件、两个CLI别名及原CLI/回执；不声称目录身份或运行时工具完整身份守卫。新增公开4ZIP共15239成员已独立检查CRC/SHA/长度及原件身份/mtime/字节；一个符号链接只核对metadata、不读取目标。主矩阵包的生成引用另保存[生成引用来源说明](assets/B07-T02/linux-run-release/generated-reference-provenance.json)：4049件原件与1件生成件分开，990字节引用可由三个已固定失败actual重建；历史inline builder未另存原始独立脚本，后补重建脚本不冒充历史builder。

## 历史版本的实际结果

Windows独占full02仍错过accepted-kill窗口，随后修改测试握手锁的68字节和accepted协调器，得到request_run `4235b2cf…`、checker `2931ab99…`，pair05/Native05分别重新编译。这组完整结果属于历史；随后request_run变为`2e735787…`并验证release配对，当前生产优化又变为`8e4d363d…`，不能复用旧789/527/62结果作为当前验收。

| 范围 | 实际结果 | 来源限制 |
| --- | --- | --- |
| 历史Linux pair05 | CLI/driver构建、全目标check及实际CLI probe均退出0，130项来源前后相同 | 编译指纹`58ed50aab2a57014d04fceb0e533ad348d3c28b3e6273b8b90b552dde981aec4`；CLI44b88d7b…、driveracbbbdb8… |
| 历史Linux完整行为full06 | 62组全部通过；364CLI/33driver、70实际HTTP、23次真实SIGKILL/wait，全部guards相同 | checker2931/request_run4235/driver实际新FP；新的独立全原件审查已完成；39有效账本/511事件、70HTTP和23真实kill逐条读回 |
| 历史Linux完整Python05 | 466项，444通过、22明确平台跳过，实际退出0、2058源快照/别名及工作区库存前后相同 | 新pair05与checker2931，原stderr/实际222.748秒/源绑定保存；完整Linux Rust未运行 |
| 历史Windows Native05完整Rust | fmt/check/build/驱动构建及双probe退出0，实际workspace297.016秒、23套件/789通过/0失败/0忽略 | 新指纹`5be72c8c62d140155efe643b825f079b64c9204e63b4f7ca140f9a299ed680d3`；新快照5959b430…，完整Python527（519通过/8跳过）、两个PowerShell各39项及外层wait0已完成；原件见windows-history-05 |
| 历史Windows接收后强杀单例 | 新驱动真实6CLI/1driver、3HTTP，Known1400+Unknown8310，所有guards相同 | A在dispatch_intent_commit等待，B实际Known700原件验证后精确release，realaccept→TerminateProcess1/wait；不作为尚未执行的新全62通过 |
| 历史Linux pair04目标检查/构建/输出守卫 | check全目标、CLI/driver构建退出0，2个输出守卫通过；130项Rust/Cargo来源前后相同 | 测试握手锁调整前源码，完整Linux Rust未运行 |
| 预算、原API及集成回归 | 30预算、43 API模块串行、7旧API集成、2输出守卫均通过；fmt全check退出0 | pair03先于status唯一29B修复，保存历史，不充作该修复最终完整回归 |
| 历史Linux完整行为矩阵full05 | 62组全部通过；364普通CLI+33driver，70实际HTTP，23次真实强制终止并wait；独立重读397进程、511有效账本事件和全部原件通过 | pair04编译指纹`8a62da0b6a1b533fdeb0dc1134b39ac28395bbaeca79ef81a9984c23ee06714f`；checker `eb6c4476c57b6ab24ccd71646045bb9b8386079bb415f677134bde9b7bddca34` |
| 预算编译指纹镜像复测 | fresh暂停Run，status/resume均退出3 `REQUEST_BUDGET_VERSION`；6普通CLI、HTTP0、所有原件无写入 | 单独复测，不并入完整矩阵397进程 |
| 历史Linux完整Python04 | 466项，444通过、22明确平台跳过；实际退出0，源码、库存和程序绑定前后相同 | pair04、checker eb6c与测试42825；完整Linux Rust未运行 |
| 历史Windows Native04完整Rust | fmt/check/build/驱动构建与实际CLI/driver probe均退出0；workspace test实际23套件/789通过、0失败、0忽略 | 编译指纹`90d7bd9a5b77232552ed1d5c654b0b5434f13e25c53ca7382e8fdd031fed0aaa`；295.359秒实际检查，未复用旧测试结果 |
| 历史Windows Native04完整Python | 527项，519通过、8明确平台/权限跳过；实际退出0；PowerShell 5和7各39项实际执行全部通过 | 源码、控制文件、完整程序体、别名、外部哨兵及原锁定依赖前后相同，外层实际wait退出0；依赖编译缓存可复用，测试结果未复用 |
| Windows原生62组 | 首轮原期限拒发，独占第二轮140CLI/7driver、19组通过后错过accepted-kill窗口；完整62未通过 | 两轮实际失败均保留，新release驱动/协调器仍需取得完整62实际通过 |

62组包含14核心+5变体+4实际工作进程观察；2条真实trace、10个通用提交边界终止、服务器实际接收终止及2个未发送期限恢复终止；16个暂停保护、1个活worker保护、7个封存或同步伪造保护。各scope分别核对，不能把静态重建或自然超时替代真实OS终止。服务器实际接收、退避时间、原deadline、request/response、原目录和文件身份、重复恢复及预算投影逐条与独立expected核对。

三组Linux完整CLI/driver分别固定f7d55c、7bdb2d、8a62da实际编译指纹。所有程序体分档保存，原编译来源和probe的PID/指纹位于[诊断包](assets/B07-T02/diagnostic-originals/originals.zip)，ZIP成员SHA、长度和CRC实际读回。程序保存不会把相应失败版本提升为通过。

历史full05主矩阵及当时聚焦、补充原件见[full05原件](assets/B07-T02/linux-run/originals.zip)和[实际封存结果](assets/B07-T02/linux-run/actual.json)。当时补充37CLI/5driver的精确双报告注入及6CLI/1driver的已结算未终态中断复测分别保存，不增加对应主矩阵的62/397/70/23计数。历史full03及中间检查器原件分别见[旧矩阵](assets/B07-T02/linux-run-history/originals.zip)、[检查器历史](assets/B07-T02/checker-history/originals.zip)。

实现入口为[request_run.rs](../../crates/noetome-cli/src/request_run.rs)，事务和完整链为[request_budget_store.rs](../../crates/noetome-cli/src/request_budget_store.rs)，传输恢复为[request_run_recovery.rs](../../crates/noetome-cli/src/request_run_recovery.rs)；独立核对入口为[verify_request_budget.py](../../scripts/verify_request_budget.py)。固定模型/预算字段由[request_budget_model.rs](../../crates/noetome-cli/src/request_budget_model.rs)定义。

| 已保存的实际产物 | 原件入口 | 用途与范围 |
| --- | --- | --- |
| 历史pair04 Linux完整程序体 | [CLI ZIP](assets/B07-T02/programs/linux-pair-04-noetome.zip)、[驱动 ZIP](assets/B07-T02/programs/linux-pair-04-request-test-driver.zip)、[原程序指纹](assets/B07-T02/programs/manifest.json) | CLI SHA f8eaef8d…、driver e13c9e34…，与实际pair04编译/运行对应；旧pair02/03程序体另档保留 |
| 历史Linux完整Python04 | [实际结果](assets/B07-T02/linux-python/actual.json)、[原件 ZIP](assets/B07-T02/linux-python/originals.zip) | 466项实际检查及2058快照/别名来源；大ELF别名原SHA对应上述完整程序体，未重复放入ZIP |
| 历史Linux full05全62独立审查 | [审查结果](assets/B07-T02/review/final-linux/actual.json)、[审查原件](assets/B07-T02/review/final-linux/originals.zip) | 39有效流程账本/511事件与23保护分别核对；额外读回对应旧主包4327成员 |
| 历史Linux完整Python | [01](assets/B07-T02/linux-python-history-01/originals.zip)、[02](assets/B07-T02/linux-python-history-02/originals.zip)、[03](assets/B07-T02/linux-python-history-03/originals.zip) | 各保留对应源码、原始输出及当时结果；01后处理失败，02/03为中间checker，不充作最终源码通过 |
| 编译、计时与版本失败及修复 | [诊断 ZIP](assets/B07-T02/diagnostic-originals/originals.zip) | 命令、实际来源清单、probe、先前错误原件，不将错误命令或旧程序通过冒充当前通过 |
| 历史独立审查与包装错误 | [审查历史 ZIP](assets/B07-T02/review-history/originals.zip) | 初始审查、原件/精确JSON复核、LF修复与原生聚焦等分别保存 |

独立Linux最终审查的首归档包装器曾把仍在写的自身stdout列入ZIP，归档时空字节与退出后输出不等；原失败包保留，公开第二包排除活跃输出并在包装器退出后再次逐成员核对。此失败只影响首审查包装包，不改变实际62组结果；第二包保留首失败诊断，不能用简单passed字段替代原件读回。

## 失败与修复历史

作者预检首次把project init文字当JSON解析失败；旧CLI仍HTTP0。首编译有Rust移动后借用错误，早期预算聚焦先遇未完成恢复模块，再有3个测试setup改cap但未重算policy SHA；原件保留，修正setup后28通过，再增加2个完整200不得重试的实质负例得到30通过。

旧API模块一次并行回归为42通过/1失败：既有100ms测试未取得预期partial字节。其传输测试源码未变；单独1项和后续完整43项串行均实际通过。一次集成命令写错不存在的target，Cargo未运行测试；改用实际`extraction_api`目标后7项通过。错误命令与原stderr保留。

pair02基准实际两个HTTP均在约40/38ms内返回完整200与已知700，但本地落盘和校验占据200ms控制器，候选被误报超时并多生成未发送attempt。修复为三阶段计时，保持作者200ms和原单元期限，pair03/04真实两单元成功、Known1400、held0。pair02另一真实RED在Reserved提交后强杀，等原5000ms期限后恢复仍保留R8310/一个slot；修复从未MaySend的到期释放后，真实同作者复测HTTP0、NotSent、Token和slot承诺0。

新程序第一次receipt选择器比较完整pin字典，因新增inode元数据而失败，普通CLI/driver/HTTP均0。检查器改为精确核对SHA与长度及原身份后重测通过。完整矩阵full01在跨Run启动观察失败：重复串行计算大driver的SHA导致第二进程晚235ms，错过冻结150ms观察窗；75CLI/4driver、10已通过组保留为历史。修复验证器并行预核对/启动，不放宽HTTP200ms或作者观察时限。

full02实际291CLI+27driver、48通过组后，预算owner及metadata同步伪造compiler仍被只读status接受；resume单独实际拒绝。原status已验证Run的当前compiler，缺少预算compiler检查；唯一29B补上同一只读版本门槛后，pair04完整重跑62组通过，不以旧48组充作新程序通过。

full03随后独立补审发现两个同步伪造case的人工Markdown嵌入JSON使用默认空格，而validation.json为compact；四次普通CLI实际先以“双报告原字节不等”拒绝。这仍是实际防伪拒绝，独立Python也核对了原wire与wrapper，但不能作为普通Core专门rawusage或candidate wrapper门槛命中的证据。人工注入改为原JSON文件的精确字节及LF，再取得针对性诊断与新完整矩阵；旧62结果和补审原件保留。

full04使用修正换行的checker后，实际140CLI/7driver、19已通过组在服务器接收后的中断协调失败。原9条事件证明B的完整HTTP200、100+600=700用量及合法候选已经结算，B的unit_terminal尚未追加；验证器额外要求125ms内先有单元终态，超出冻结OSkill变体的先决条件。保留[原失败矩阵](assets/B07-T02/interrupted-history/originals.zip)，不计成完整62通过。协调器改为快速核对B的可信已结算回执与实际服务器原件、A的MaySend后立即真正kill/wait，再在恢复前完整核对稳定原件；A若已有封存回执则仍失败。实际复测B终态未出现时成功强杀、旧A无receipt且保留R8310、B同key/原件不变且无额外HTTP，随后final full05全62通过。冻结200ms、500ms unknown服务器响应、原deadline和预算expected均未改。

历史Windows Native01绑定修复前源码，完整Rust23 suite/789通过、0失败、0忽略；旧checker完整Python实际527 tests、2 errors、8 skipped，两个错误都在新增人工Markdown夹具的CRLF与真实Rust报告LF门槛处。原stdout/stderr和退出1保留；人工夹具及故障注入的Markdown writer改为明确UTF8字节，不放宽真实报告校验。Native02只冻结了中间输入，没有启动；最终修正源码另建快照。由于后续checker、测试和Rust实际变化，Native01不作为最终验收。

Native03也仅冻结中间checker42055，未启动任何Cargo/Python/故障矩阵。最终Native04使用checker eb6c、测试`42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348`；快照锚`6585ce76951850ac206243e61afd4ee055fa7089be875d94652807d235c096a1`。独立初始审查实际读回2056源码、ZIP额外4辅助原件及7个控制文件，四份精确Rust来源范围为93/129/129/1913项；这些静态结果不代替正在执行的最终测试。旧Native01完整程序及失败结果保存于[Windows历史原件](assets/B07-T02/windows-history-01/originals.zip)。

Native04故障矩阵首轮与完整工作区回归同时运行，完整源/PE绑定通过后，前两案通过，第三案retry-exhaustion未达到作者4次HTTP预期；整轮20普通CLI、0driver、9实际HTTP，失败案自身3次HTTP。第三A在原5秒单元deadline前Prepared/Reserved，MaySend前已到期，以network_attempts=0的REQUEST_RUN_BUDGET_STOP结算NotSent并释放R/slot，原链没有第三A发送许可或服务器接收；前两次retry_at严格为+100/+200ms，B成功700保留。独立原件审查确认没有提前重试、越期发送或预留漏扣，仍把该轮作为作者矩阵失败，见[Windows故障历史](assets/B07-T02/windows-run-history/originals.zip)。完整回归结束后使用同程序、同作者参数独占重测，不放宽期限或把竞争现场视作完整通过。

历史Linux Python01框架报告466 tests、OK(skipped=22)，归档后处理因快照中没有用于重建名单的历史manifest而失败；原stdout/stderr、源码变化和postprocess失败单独保存。新的当前源码完整回归另行取得，不能把该历史包装器失败隐去。

独立审查器首次导入缺少传递helper，另一次将合法run_invalidated追加要求成数据库全等，失败均保存。动态导入还生成四个自身Python缓存，原件保存后仅清理自身新增缓存；原JSON/DB/源码/请求/响应未改，但相关目录mtime曾变化，没有宣称恢复了最初mtime。最终审查禁止缓存写入，合法失效追加与原前缀/余额保护分别核对。

## 尚未完成与边界

仍需最终Windows完整Rust/Python与原生故障矩阵及其独立审查、完整公开归档、标准和日志收束、普通提交与推送及远端HEAD核对。真实验收完成后才通过日志工具complete。

这些synthetic有界结果不证明真实网关恢复、隐藏费用或服务商账单绝对上限，不证明科学200原子/98%、通用OCR、生产Vault人工保护、任意断电修复、千页/万原子、3000笔记或24小时规模。B07-T03尚未启动。


追加的原生短期限与协调失败保留为失败，不改变先验作者：Nativefull03在20组完成后，人工125ms服务响应门先抛错，A没有实际429写入时间，最终是transport错误；缺失的字段不补默认值，该轮不计真实429或完整62。原件见[Nativefull03](assets/B07-T02/windows-run-history03/originals.zip)。之后两种选中边界策略均取得backoff真实强杀通过，但原1.5秒elapsed未取得重试提交，不能计为elapsed强杀通过。

普通Native无测试hook计时对照实际7CLI、0driver、0kill、2HTTP，A保留R8310、B确认700。原起点21:59:24.7763135Z、Run登记事件24.8236446Z、A MaySend25.3225020Z、结算25.4687448Z、单元失败25.7302004Z；原截止26.2763135Z。原1000ms退避最晚须在25.2763135Z前调度，A首次MaySend已经超过该点46.1885ms，因此实际诊断是“No retry fits the original absolute deadline”，并非越期重发。事件时间由事务decision前采集，不当作COMMIT完成时刻；没有CPU/锁/磁盘分步计时，不能把全部间隔归因到某一种开销。

为减少额外测试仪表开销，测试模块再加84字节：只有选中的单点回调进入完整账本握手；trace/observe继续记录所有事件。修改前后68173字节生产实现逐字节相同，SHA为`d69b6b76c30aebe3d5f5dffd0ad2edf8ca9153eb9babe97ad5f51ebdf1950b2a`。当时Rust整件为`2e7357871bc000afc308abc4de4db0d131bfe86cadb93471e5fe0063beb33b06`。这是测试协调修复，不作为普通CLI期限问题已解决的证据。

Linux新release CLI和driver构建均实际退出0，分别PID767398/102.654秒和PID770426/68.826秒，130项Rust/Cargo来源身份、mtime、字节一致；Cargo和真实CLI探针PID771321的指纹均为`e3da041f1c0862483d352f5821fd7941bd9e633012fb1c8f22723eb47ab49b5f`。该指纹包含PROFILE/OPT_LEVEL/DEBUG，不能用旧debug指纹替代。预算模块28项release测试及当前workspace fmt已实际退出0；完整Linux Rust仍未运行。

该release首次完整行为轮实际146CLI+8driver，20组完成后失败于只读账本前后库存不同。A实际停在retry提交握手sequence10；原链随后显示B的transport seal11、Known700结算12与合法unit_finished13，没有其他Run或写者。原异常抛出前没有保存独立before/after DB哈希，不能补造；链中B终态追加与活跃只读审计竞态相吻合。checker仅增加两个B终态稳定谓词后重新运行当前完整62并实际通过，严格账本/原件前后校验、原1500/1000ms和kill窗口保留。首轮仍为失败，保存于[release历史](assets/B07-T02/linux-release-history/originals.zip)。

Windows release01的CLI Cargo实际退出0后，包装器把Cargo临时生成的正常双硬链接误按最终选定程序的单链接规则拒绝，因此未构建driver、最外层退出1。临时Cargo output允许普通硬链接并保留其真实ID/mtime/ctime/nlink；源码、控制原件及最终选定程序仍要求单链接。新的release02从原件重新准备并真实运行两次Cargo、两次探针和全后置核对，最外层wait0；仅复用已闭合release01的依赖/object缓存，不复用测试结果。

Windows release普通CLI额外elapsed诊断02实际6CLI、0driver、2HTTP、0OSkill，所有来源和哨兵守卫相同。原Run起点22:54:43.5453955Z、A deadline22:54:45.0453955Z，A MaySend43.9863492Z、完整429网络13ms、结算44.1366277Z；B完整200网络12ms、Known700在44.2808447Z、终态44.4949318Z。A于44.5354349Z以“No retry fits the original absolute deadline”退出，没有retry_scheduled或A2。首结算已超过原deadline减1000ms的最迟重试安排点；这证明该主动2ms读链观察调度下的期限停止，不能充作真实OS中断通过，也不推定是纯网络或纯磁盘开销。首adapter遗漏binder字段在产品命令前KeyError，0CLI/HTTP，另行保留；修正artifact adapter后才取得上述实际诊断。
