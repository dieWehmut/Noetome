"""Verify Root's five wording changes only. Do not rewrite the old review or doc."""
from pathlib import Path
import hashlib,json,re,difflib
REPO=Path('/home/lyinn/project/Noetome')
HERE=Path(__file__).parent
DOC=REPO/'doc/validation/B07-T02.md'
old=(HERE/'main-report-original.md').read_bytes()
assert hashlib.sha256(old).hexdigest()=='2926126325f4d716a5e3f172c554b101ea8d2a1c465e450fadb73f828fb4c5ef'
before=DOC.stat();raw=DOC.read_bytes();after=DOC.stat()
fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)
assert fields(before)==fields(after)
assert hashlib.sha256(raw).hexdigest()=='3aa2767f627f4bcdf8a72eff5cb148797375a858729104e46f92562916e78390'
a=old.decode().splitlines();b=raw.decode().splitlines()
assert len(a)==len(b)
changed=[i+1 for i,(x,y) in enumerate(zip(a,b)) if x!=y]
assert changed==[41,47,53,69,103]
assert a[:38]==b[:38]
assert '确认末status应退出3，后继a7ef私有副本只更正该参数，旧89d及整个失败原件不改、不重跑' in b[40]
assert b[46]=='| 该4ca历史源码范围 | 实际结果 | 可复核原件 |'
assert '未运行完整Windows Rust/Python；此构建回执本身不作为受控中断验收，后续backoff强杀与elapsed NoFit见本节失败原件' in b[52]
assert b[68]=='| 该事务候选的历史范围 | 实际结果 | 原件与限制 |'
assert '事务候选再变为`8e4d363d…`。本报告当前冻结候选已是顶部b393/2e97，旧789/527/62不复用为当前验收' in b[102]
links=lambda s:re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)',s)
assert links(old.decode())==links(raw.decode()) and len(links(raw.decode()))==84
for path,body in [('main-report-Root-corrected-original.md',raw),('Root-wording-correction.diff',''.join(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='retained-original2926',tofile='Root-corrected3aa2')).encode())]:
 with (HERE/path).open('xb') as f:f.write(body)
result={'status':'five_Root_wording_corrections_readback_passed','retained_original_review_sha256':'ded74d9c7c639d5e1cf43d353e7d9432628fddbeede0df8c062e6ace0fa00d05','old_doc_sha256':'2926126325f4d716a5e3f172c554b101ea8d2a1c465e450fadb73f828fb4c5ef','corrected_doc':{'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'device':before.st_dev,'inode':before.st_ino,'mtime_ns':before.st_mtime_ns,'nlink':before.st_nlink},'changed_lines':changed,'current_numeric_source_section_byte_identical':True,'both_required_wording_corrections_resolved':True,'status_JSON_vs_a7ef_helper_distinction_corrected':True,'two_history_table_headers_corrected':True,'local_link_target_sequence_unchanged':True,'retained_prior_local_links_exist':84,'repeated_full_link_filesystem_or_packet_scan':False,'original2926_review_and_failed_history_unmodified':True,'new_CLI_calls':0,'new_HTTP_requests':0,'new_Native_processes':0,'scope':'Light readback of Root-edited main report only. Does not grant pending Native06 pair or tests.'}
assert fields(DOC.stat())==fields(before) and DOC.read_bytes()==raw
with (HERE/'correction-readback.json').open('xb') as f:f.write((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
output=(HERE/'correction-readback.json').read_bytes();print(json.dumps({'status':result['status'],'sha256':hashlib.sha256(output).hexdigest(),'byte_length':len(output),'corrected_doc_sha256':result['corrected_doc']['sha256']}))
