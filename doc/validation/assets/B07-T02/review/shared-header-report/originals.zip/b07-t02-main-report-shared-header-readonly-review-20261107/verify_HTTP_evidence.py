"""Light selected cached ZIP receipt check; no product/native request."""
from pathlib import Path
import json,zipfile,hashlib
REPO=Path('/home/lyinn/project/Noetome')
HERE=Path(__file__).parent
ROOT=REPO/'doc/validation/assets/B07-T02/linux-run-shared-header'
raw=(ROOT/'execution.json').read_bytes();value=json.loads(raw)
assert hashlib.sha256(raw).hexdigest()=='bed3bcc92674a001a968dbeadfa46a3ee74a53ddc3bab3941d3d04a1181a4da9'
case_sum=sum(c.get('actual_HTTP_requests',0) for c in value['cases'])
assert case_sum==70
manifest=json.loads((ROOT/'manifest.json').read_bytes())
by_name={x['member']:x for x in manifest['members']}
rows=[];ids=[]
with zipfile.ZipFile(ROOT/'originals.zip') as z:
 for name in z.namelist():
  if name.endswith('/server-receipts.json'):
   raw=z.read(name);pin=by_name[name]['pin']
   assert len(raw)==pin['byte_length'] and hashlib.sha256(raw).hexdigest()==pin['sha256']
   server=json.loads(raw);assert not server['errors']
   ids.extend(r['request_id'] for r in server['receipts'])
   rows.append({'member':name,'sha256':pin['sha256'],'byte_length':len(raw),'actual_receipts':len(server['receipts']),'errors':0})
assert sum(x['actual_receipts'] for x in rows)==len(ids)==len(set(ids))==70
result={'status':'reported_case_HTTP_sum_and_actual_saved_server_receipts_agree','execution_sha256':'bed3bcc92674a001a968dbeadfa46a3ee74a53ddc3bab3941d3d04a1181a4da9','reported_case_HTTP_sum':case_sum,'actual_saved_receipts':70,'unique_request_ids':70,'selected_members':rows,'scope':'Selected small already cached Home ZIP receipt JSONs only. This supplement corroborates main-report numeric70; not a repeated full raw body/OS/original audit. No new product/native/HTTP invocation.'}
with (HERE/'HTTP-evidence.json').open('xb') as f:f.write((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
raw=(HERE/'HTTP-evidence.json').read_bytes();print(json.dumps({'status':result['status'],'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'selected_members':len(rows)}))
