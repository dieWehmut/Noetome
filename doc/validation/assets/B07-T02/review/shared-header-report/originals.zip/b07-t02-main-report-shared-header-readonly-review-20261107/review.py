"""Light Home-only review of a fixed main-report snapshot. No product/native runs."""
from pathlib import Path
import hashlib,json,re,zipfile,io,urllib.parse
REPO=Path('/home/lyinn/project/Noetome')
HERE=Path(__file__).parent
DOC=REPO/'doc/validation/B07-T02.md'
ASSETS=REPO/'doc/validation/assets/B07-T02'
PINS={}


def read(path):
 assert path.is_file() and not path.is_symlink()
 before=path.stat();raw=path.read_bytes();after=path.stat()
 fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)
 assert fields(before)==fields(after)
 pin={'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'device':before.st_dev,'inode':before.st_ino,'mtime_ns':before.st_mtime_ns,'nlink':before.st_nlink,'metadata_captured_before_first_read':True}
 PINS[str(path)]=pin
 return raw


def save(path,raw):
 with path.open('xb') as f:f.write(raw)


def encode(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()


raw_doc=read(DOC);doc=raw_doc.decode();save(HERE/'main-report-original.md',raw_doc)
lines=doc.splitlines()
local=[];outside=[]
for match in re.finditer(r'\[[^\]\n]*\]\(([^)\n]+)\)',doc):
 target=match.group(1).strip()
 if target.startswith('<') and target.endswith('>'):target=target[1:-1]
 parsed=urllib.parse.urlsplit(target)
 line=doc.count('\n',0,match.start())+1
 if parsed.scheme or not parsed.path:
  outside.append({'line':line,'target':target});continue
 path=(DOC.parent/urllib.parse.unquote(parsed.path)).resolve()
 assert path.is_relative_to(REPO)
 local.append({'line':line,'target':target,'resolved':str(path),'exists':path.exists()})
assert not [x for x in local if not x['exists']]
current_exec=json.loads(read(ASSETS/'linux-run-shared-header/execution.json'))
assert current_exec['status']=='passed' and len(current_exec['cases'])==62 and all(x['status']=='passed' for x in current_exec['cases'])
assert current_exec['ordinary_CLI_count']==364 and current_exec['driver_count']==33
assert len({x['PID'] for x in current_exec['commands']})==397
kills=[x for x in current_exec['commands'] if x['wait_action']=='actual_OS_force_kill_and_wait']
assert len(kills)==23 and all(x['exit_code']==-9 for x in kills)
assert all('exit_code' in x and 'wait_action' in x for x in current_exec['commands']) and all(current_exec['guards'].values())
current_manifest=json.loads(read(ASSETS/'linux-run-shared-header/manifest.json'))
assert current_manifest['total_zip_members']==3792 and current_manifest['ordinary_original_files']==3791 and current_manifest['generated_reference_members']==1
python=json.loads(read(ASSETS/'linux-python-shared-header/actual.json'))
assert python['status']=='passed' and python['exit_code']==0 and python['tests_run']==466 and len(python['skipped_tests'])==22 and python['result_line']=='OK (skipped=22)'
assert abs(python['elapsed_seconds']-80.550407)<0.000001 and python['source_files']==2058
for key in ['snapshot_source_unchanged','worktree_source_unchanged','named_input_inventory_unchanged','snapshot_source_identity_mtime_unchanged','worktree_source_identity_mtime_unchanged','selected_original_cli_and_receipt_identity_mtime_unchanged']:
 assert python[key]
python_launch=json.loads(read(ASSETS/'linux-python-shared-header/launch.json'))
assert python_launch.get('PID',python_launch.get('pid'))==818751
programs=json.loads(read(ASSETS/'programs-shared-header/manifest.json'))
fp='89136b36bc30a77c5e7a1a54fd480c8d06be89e060377f1482954fbed12433b0'
expected_programs={'linux-shared-header-pair-01-noetome':('517234798788beb5cc28830d1f8d16c203341542c5bce422c9fecdcc6998391f',17820792),'linux-shared-header-pair-01-request-test-driver':('44591b8d9794606ac89fb5e20147b8a52075139ed7eb0fdfdbe4987126cb1cbe',23860992)}
for key,(sha,length) in expected_programs.items():
 assert programs[key]['actual_compiler_fingerprint']==fp
 assert programs[key]['original_executable']=={'sha256':sha,'byte_length':length}
diag_manifest=json.loads(read(ASSETS/'diagnostic-shared-header/manifest.json'))
diag_members=[]
with zipfile.ZipFile(ASSETS/'diagnostic-shared-header/originals.zip') as z:
 assert len(z.infolist())==41
 for member in z.namelist():
  if member.endswith('/actual.json') or ('guards' in member and member.endswith('/stdout.bin')):
   raw=z.read(member);expected=diag_manifest[member]
   assert len(raw)==expected['byte_length'] and hashlib.sha256(raw).hexdigest()==expected['sha256']
   diag_members.append({'member':member,'sha256':expected['sha256'],'byte_length':len(raw)})
   if member.endswith('/actual.json'):
    v=json.loads(raw)
    if '-guards-' in member:
     assert v['pid']==815761 and v['exit_code']==0 and abs(v['elapsed_seconds']-14.272833)<0.000001 and v['source_before_after_equal']
    elif '-fmt-' in member:assert v['pid']==816931 and v['exit_code']==0
    elif '-check-' in member:assert v['pid']==816959 and v['exit_code']==0
    elif '-cli-build-' in member:assert v['pid']==817163 and v['exit_code']==0 and abs(v['elapsed_seconds']-59.656106)<0.000001
    elif '-driver-build-' in member:assert v['pid']==818030 and v['exit_code']==0 and abs(v['elapsed_seconds']-77.419095)<0.000001
    elif '-pair-' in member:
     assert v['actual_cli_fingerprint']==fp and v['source_files']==130 and v['source_before_after_equal'] and v['cli_probe_pid']==818637
   else:assert b'42 passed; 0 failed; 0 ignored; 0 measured; 476 filtered out' in raw
 for member in z.namelist():
  if member.endswith('/source-originals.zip'):
   with zipfile.ZipFile(io.BytesIO(z.read(member))) as inner:
    expected={'request_run.rs':('b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c',74782),'request_budget_store.rs':('2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184',151556)}
    for file,(sha,length) in expected.items():
     matches=[n for n in inner.namelist() if n.endswith('/'+file)]
     assert len(matches)==1;body=inner.read(matches[0]);assert len(body)==length and hashlib.sha256(body).hexdigest()==sha
history=json.loads(read(ASSETS/'deadline-stamp-history/actual.json'))
assert history['members']==348 and history['ordinary_original_files']==347
counts=history['original_execution_counts']
assert (counts[0]['ordinary_CLI_count'],counts[0]['driver_count'],counts[0]['actual_HTTP_requests'],counts[0]['actual_OS_kills'])==(9,0,2,1)
assert (counts[1]['ordinary_CLI_count'],counts[1]['driver_count'],counts[1]['actual_HTTP_requests'],counts[1]['actual_OS_kills'])==(11,2,5,1)
assert counts[0]['actual_status']==counts[1]['actual_status']=='failed' and counts[1]['passed_case_ids']==['retry-backoff-persists-through-kill']
clarification=json.loads(read(ASSETS/'deadline-stamp-history/diagnostic-status-expectation.json'))
assert clarification['actual_exit_code']==3 and clarification['frozen_extra_wrapper_expected_exit_code']==0 and clarification['original_extra_overall_status']=='failed' and not clarification['reclassified_as_passed']
assert 'Windows模块40及完整Rust802此时尚未运行' in doc
assert '历史Windows Native05完整Rust' in doc and '历史Windows Native04完整Rust' in doc
source_facts={'current_doc_four_source_pins':'b393/2e97/3b/428 correctly scoped','Linux_budget_module':{'passed':42,'failed':0,'filtered':476,'PID':815761,'Cargo_elapsed_seconds':14.272833},'Linux_full_matrix':{'cases_passed':62,'ordinary_CLI':364,'driver':33,'unique_PIDs':397,'actual_HTTP':70,'actual_SIGKILL_wait_exit_minus9':23},'Linux_full_Python':{'tests':466,'passed':444,'skipped':22,'PID':818751,'elapsed_seconds':80.550407,'source_snapshot_files':2058},'current_FP':fp,'historical_Native4650':{'ordinary_CLI':9,'ordinary_HTTP':2,'ordinary_OSkill':1,'ordinary_overall':'failed expected0 vs actual3','three_CLI':11,'three_driver':2,'three_HTTP':5,'backoff_OSkill':1,'elapsed_OSkill':0,'accepted':'not_run','main62':'not_run'},'old_Native789_not_current802':True}
findings=[
 {'severity':'wording_correction_required','line':53,'quote':lines[52],'issue':'This historical build row says controlled interruption was not run, but the same section and preserved history actually include backoff71916 realkill and elapsed natural NoFit. The build receipt itself is not an interruption test; unqualified 未运行…受控中断 is false after the later runs.','suggested_text':'未运行完整Windows Rust/Python；此构建回执本身不作为受控中断验收，后续backoff真实强杀与elapsed NoFit见本节失败原件。'},
 {'severity':'wording_correction_required','line':103,'quote':lines[102],'issue':'Inside the historical section, 当前生产优化又变为8e4d is stale: the main current section correctly selects b393/2e97.','suggested_text':'随后request_run变为2e735并验证release配对，事务优化候选再变为8e4d；本报告当前冻结候选已是顶部的b393/2e97，旧789/527/62结果不复用为当前验收。'},
 {'severity':'clarity_suggestion','line':41,'quote':lines[40],'issue':'The linked diagnostic-status-expectation JSON is a derived explanation and does not itself change a helper. The new a7ef artifact copy applies the one-argument correction separately.','suggested_text':'新增单点期望说明确认失败Run末status应为3；后继a7ef私有诊断副本仅据此更正一个参数，旧89d源码与整体失败原件不重跑、不改写。'},
 {'severity':'historical_scope_label_suggestion','lines':[47,55,57,69,75,77,79,87,88,89,90,91,92,93,95,99],'issue':'Several old section tables and program paragraphs still say 当前. Their surrounding history headings and explicit old hashes preserve scope, but 原4ca候选/该事务候选/该优化前release候选 is clearer.','suggested_text':'仅将这些历史段落的当前改为该候选或历史，保留所有数字/SHA/结果。'}]
report={'status':'current_numeric_and_local_link_review_passed_with_two_wording_corrections','main_report_original':PINS[str(DOC)],'source_facts':source_facts,'local_link_count':len(local),'local_missing_links':[],'local_link_targets':local,'nonlocal_link_count':len(outside),'selected_diagnostic_members_CRC_SHA_length_verified':diag_members,'original_input_pins':PINS,'findings':findings,'scope':'Home lightweight document/JSON and selected small diagnostic ZIP members only. Does not repeat fullPE bodies, allmatrix HTTP/PID original review or whole large Python/archive readback. No new CLI, HTTP, tests or Native process. Link targets checked for local existence; anchors not asserted.'}
old_pin=PINS[str(DOC)].copy()
for path,pin in list(PINS.items()):
 raw=read(Path(path));assert PINS[path]==pin
report['selected_original_ID_mtime_bytes_before_after_equal']=True
assert PINS[str(DOC)]==old_pin
save(HERE/'actual.json',encode(report))
print(json.dumps({'status':report['status'],'report_sha256':hashlib.sha256((HERE/'actual.json').read_bytes()).hexdigest(),'report_bytes':(HERE/'actual.json').stat().st_size,'doc_sha256':old_pin['sha256'],'links':len(local),'findings':[(x['severity'],x.get('line',x.get('lines'))) for x in findings]}))
