"""Capture Root final Run and frozen Store, without executing their code."""
from pathlib import Path
import hashlib,json,os,stat,sys,difflib
sys.dont_write_bytecode=True
R=Path('/home/lyinn/project/Noetome');O=Path(__file__).resolve().parent
B=R/'.artifacts/b07-t02-loop-known-identity-independent-review-20261107/source-originals/crates/noetome-cli/src'
P={}
def read(p):
 for q in [p,*p.parents]:assert not q.is_symlink()
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read()
  assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
 assert P.setdefault(str(p),v)==v;return b
read(Path(__file__).resolve())
for name,old_sha in [('request_run.rs','e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'),('request_budget_store.rs','c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a')]:
 old=read(B/name);assert hashlib.sha256(old).hexdigest()==old_sha
 new=read(R/'crates/noetome-cli/src'/name)
 if name=='request_budget_store.rs':assert hashlib.sha256(new).hexdigest()=='1d4e8e6d35caf6777cfa17fc8ad8c80c9916250377524be5ba3bcaa808b41335' and len(new)==182033
 for tag,b in [('before',old),('after',new)]:
  p=O/'final-source-01'/tag/name;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
  assert read(p)==b
 d=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='before/'+name,tofile='after/'+name))
 (O/(name+'.final.diff')).write_text(d)
for p in list(P):read(Path(p))
v={'status':'passed_exact_final_Run_Store_readonly_source_capture','actual_PID':os.getpid(),'original_and_copied_source_pins':P,
 'all_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal':True,'product_HTTP_Cargo_Native_D_calls':0}
(O/'final-source-pins.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'status':v['status'],'actual_PID':os.getpid(),'new_Run':P[str(R/'crates/noetome-cli/src/request_run.rs')],'new_Store':P[str(R/'crates/noetome-cli/src/request_budget_store.rs')]}))
