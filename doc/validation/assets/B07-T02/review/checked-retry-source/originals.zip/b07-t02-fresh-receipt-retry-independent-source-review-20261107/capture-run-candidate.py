"""Save a readonly Run candidate; Store is still WIP and is not evaluated here."""
from pathlib import Path
import hashlib,json,os,stat,sys
sys.dont_write_bytecode=True
R=Path('/home/lyinn/project/Noetome')
O=Path(__file__).resolve().parent
p=R/'crates/noetome-cli/src/request_run.rs'
for q in [p,*p.parents]:assert not q.is_symlink()
a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
with p.open('rb') as f:
 assert shape(a)==shape(os.fstat(f.fileno()))
 b=f.read();assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
t=O/'run-candidate-01.rs'
with t.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
assert t.read_bytes()==b
pin={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
value={'status':'readonly_Run_candidate_capture_only_not_final_source_acceptance','actual_PID':os.getpid(),
       'original':str(p),'original_pin':pin,'copy':str(t),'original_actual_fstat_path_ID_mtime_singlelink_bytes_before_after_equal':True,
       'Store_WIP_not_read_or_accepted':True,'new_product_Cargo_Native_D_HTTP_calls':0}
(O/'run-candidate-01-pin.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
