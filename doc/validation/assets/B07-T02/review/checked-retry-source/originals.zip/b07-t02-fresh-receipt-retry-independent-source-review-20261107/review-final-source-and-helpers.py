"""Independent saved static source/draft review; never import executable helpers."""
from pathlib import Path
import ast,hashlib,json,os,stat,sys
sys.dont_write_bytecode=True
R=Path('/home/lyinn/project/Noetome');O=Path(__file__).resolve().parent
P={}
def read(p):
 p=Path(p)
 for q in [p,*p.parents]:assert not q.is_symlink(),str(q)
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
 shape=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mode,s.st_nlink,s.st_mtime_ns)
 with p.open('rb') as f:
  assert shape(a)==shape(os.fstat(f.fileno()));b=f.read()
  assert shape(a)==shape(os.fstat(f.fileno()))==shape(p.lstat())
 v={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':a.st_dev,'inode':a.st_ino,'mtime_ns':a.st_mtime_ns,'nlink':a.st_nlink}
 assert P.setdefault(str(p),v)==v;return b
def section(t,start,end):return t[t.index(start):t.index(end,t.index(start))]
read(Path(__file__).resolve())
base=O/'final-source-01'
old_run=read(base/'before/request_run.rs').decode();run=read(base/'after/request_run.rs').decode()
old_store=read(base/'before/request_budget_store.rs').decode();store=read(base/'after/request_budget_store.rs').decode()
assert hashlib.sha256(old_run.encode()).hexdigest()=='e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'
assert hashlib.sha256(old_store.encode()).hexdigest()=='c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'
assert hashlib.sha256(run.encode()).hexdigest()=='3f456b5c0623b4ca7a3239808e27647c6ef08f823a686e7f4b4a6fad9dec6cd5'
assert hashlib.sha256(store.encode()).hexdigest()=='1d4e8e6d35caf6777cfa17fc8ad8c80c9916250377524be5ba3bcaa808b41335'
for name,b in [('request_run.rs',run.encode()),('request_budget_store.rs',store.encode())]:
 assert read(R/'crates/noetome-cli/src'/name)==b

enum=section(store,'#[derive(Debug, Clone, PartialEq, Eq)]\npub(super) enum ReceiptRetryDecision {','fn error(')
method=section(store,'    /// Inspect an API\'s authoritative receipt','    pub(crate) fn finish_unit(')
tests=section(store,'    #[test]\n    fn budget_receipt_retry_checked_revalidates_inputs_after_guard_without_append()','    fn refuse_local_timeout_retry_and_rehashed_event(')
restored=store
for block in (enum,method,tests):
 assert restored.count(block)==1
 restored=restored.replace(block,'',1)
assert restored==old_store
old_loop=section(old_run,'fn unit_loop(','struct Hooks')
new_loop=section(run,'fn unit_loop(','struct Hooks')
run_restored=run.replace(new_loop,old_loop,1).replace('request_budget_store::{BudgetStore, ReceiptRetryDecision, registered_identity_matches}',
 'request_budget_store::{BudgetStore, registered_identity_matches}',1)
assert run_restored==old_run
def ordered(text,calls):
 out=[];cursor=0
 for call in calls:
  at=text.index(call,cursor);out.append({'call':call,'offset':at});cursor=at+len(call)
 return out
update=section(store,'    fn update_checked<R>(','    pub(crate) fn register_run(')
transaction=ordered(update,['lock(&self.root)', 'layout(&self.root','schema(&self.connection','transaction_with_behavior(TransactionBehavior::Immediate)',
 'load(&tx','witnesses(&view)','guard(&view)','let at = now()','decide(&view, &at)','apply(&mut view','tx.execute(','tx.commit()','layout(&self.root'])
assert update==section(old_store,'    fn update_checked<R>(','    pub(crate) fn register_run(')
guard_order=ordered(method,['self.verify_version()?','self.update_checked(', 'guard(view)?','verify_inputs(&run(view, &key.run_id)?.spec)',
 '|view, at|','let attempt = attempt(view, key)?','let receipt = attempt.receipt.as_ref()', 'unit.outcome.is_some() || attempt.retry.is_some()',
 'unit.attempts.last()', 'receipt.candidate_status == CandidateStatus::Validated','let code = receipt','code.starts_with("REQUEST_BUDGET")',
 'let retryable_receipt = receipt.usage.is_none()', 'if !retryable_receipt','view.global_stopped || run.budget_stopped','if stop_requested()',
 'let at = utc(at)?','let delay = run','let due = at','if due >= utc(&unit.spec.deadline_utc)?','validate_retry(view, key, &schedule, &at)?','Some(BudgetEvent::RetryScheduled'])
assert method.count('Some(BudgetEvent::')==1
assert 'None,' in method and 'UnitFinished' not in method
attempt=section(store,"fn attempt<'a>(",'fn attempt_mut')
assert 'if &a.plan.key != key' in attempt
validate_run=section(store,'fn validate_run(','fn verify_inputs(')
assert 'utc(&u.deadline_utc)? > deadline' in validate_run
old_unknown=section(old_loop,'            if a.receipt.is_none()','            if let Some(r) = &a.receipt')
new_unknown=section(new_loop,'            if a.receipt.is_none()','            if let Some(r) = &a.receipt')
assert old_unknown==new_unknown
assert 'store.schedule_retry_after(&a.plan.key, "REQUEST_INTERRUPTED")?' in new_unknown
assert 'g.verify()?;\n                g.inventory(view)?;\n                g.inputs()' in new_loop
assert '|| stop.load(Ordering::SeqCst)' in new_loop
assert new_loop.index('if let Err(e) = execution') < new_loop.index('store.schedule_receipt_retry_checked(')
assert new_loop.index('if let Some(scope) = denial') < new_loop.index('store.schedule_receipt_retry_checked(')
assert 'ReceiptRetryDecision::Scheduled(_) => boundary(' in new_loop
assert 'finish_unit(&mut store, &g, index, outcome, &diagnostic, key.attempt_no)?;' in new_loop

test_names=[line.strip().split('(')[0][3:] for line in tests.splitlines() if line.strip().startswith('fn budget_receipt_retry_checked_')]
assert len(test_names)==6
test_evidence={
 'input_after_guard': ['fs::write(input, b"changed after complete witness, before decision")','REQUEST_BUDGET_INPUT_CHANGED'],
 'clock_after_guard': ['while OffsetDateTime::now_utc() < threshold','No retry fits the original absolute deadline'],
 'other_SQLite_connection': ['let mut reader = BudgetStore::open(&f.authority)','writer\n            .finish_unit','writer.settle(&q.key, &overrun)'],
 'full_key_receipt_before_terminal': ['foreign.request_id = uuid::Uuid::new_v4()','without an authoritative final receipt'],
 'append_once_reopen': ['scheduled.sequence, before.sequence + 1','drop(s);','let mut s = BudgetStore::open(&f.authority)'],
 'known200_stop': ['complete 200 with known usage','REQUEST_RUN_STOPPED']}
for tokens in test_evidence.values():
 for token in tokens:assert token in tests,token

proof_path=R/'.artifacts/b07-t02-checked-retry-helper-preparation-20261107/actual.json'
proof=json.loads(read(proof_path));assert len(proof['records'])==8
helpers=[]
for row in proof['records']:
 a,b=read(row['original']),read(row['copy'])
 assert hashlib.sha256(a).hexdigest()==row['original_sha256']
 assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['byte_length']
 forward=a.decode()
 for old,new,count in row['substitutions']:
  assert forward.count(old)==count,(row['copy'],old)
  forward=forward.replace(old,new)
 assert forward.encode()==b
 reverse=b.decode()
 for old,new,count in reversed(row['substitutions']):
  assert reverse.count(new)==count,(row['copy'],new)
  reverse=reverse.replace(new,old)
 assert reverse.encode()==a
 ast.parse(a);ast.parse(b)
 # Entire executable source restoration is stricter than any boolean flag or
 # an AST comparison that silently ignores changed string constants.
 helpers.append({'original':row['original'],'copy':row['copy'],'original_pin':P[row['original']], 'copy_pin':P[row['copy']],
                 'declared_substitution_occurrences_independently_exact':row['substitutions'],
                 'full_forward_and_reverse_actual_bytes_equal':True,'AST_parsed_without_import_execute':True})
new_pins={
 'crates/noetome-cli/src/request_run.rs':{'sha256':hashlib.sha256(run.encode()).hexdigest(),'byte_length':len(run.encode())},
 'crates/noetome-cli/src/request_budget_store.rs':{'sha256':hashlib.sha256(store.encode()).hexdigest(),'byte_length':len(store.encode())},
 'scripts/verify_request_budget.py':{'sha256':'3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7','byte_length':169966},
 'tests/test_verify_request_budget.py':{'sha256':'42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348','byte_length':50420}}
for row in helpers:
 if 'release-builder' in row['copy'] or 'native-full12' in row['copy']:
  tree=ast.parse(read(row['copy']))
  value=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCE_PINS' for t in n.targets))
  assert value==new_pins
for name,pin in new_pins.items():
 b=read(R/name);assert hashlib.sha256(b).hexdigest()==pin['sha256'] and len(b)==pin['byte_length']
for p in list(P):read(p)
result={'status':'passed_independent_static_fresh_receipt_retry_source_and_eight_helpers_review','actual_PID':os.getpid(),
 'current_source_pins':new_pins,'all_original_source_and_copy_fstat_path_ID_mtime_singlelink_fullbytes_before_after_equal':True,
 'Store_three_inserted_regions_removed_restores_exact_c87':True,'Run_only_import_and_unit_loop_removed_restores_exact_e4':True,
 'existing_update_checked_original_exact_order':transaction,'new_guard_input_then_clock_receipt_decision_order':guard_order,
 'full_key_receipt_before_terminal_or_existing_retry_Unchanged':True,'only_latest_attempt_can_create_new_retry':True,
 'ordinary_five_HTTP_classes_require_usage_none_and_not_complete200':True,
 'stop_only_retry_branch_no_suppression_of_confirmed_success_known_failure':True,
 'NoFit_and_other_Finish_decisions_do_not_append_terminal_event':True,
 'new_RetryScheduled_commit_and_old_finished_settle_unit_terminal_boundaries_separate':True,
 'Run_deadline_extra_check_equivalent_under_accepted_unit_deadline_le_Run_contract':True,
 'old_Unknown_REQUEST_INTERRUPTED_explicit_resume_path_exact_bytes':True,
 'six_new_common_test_definitions_source_reviewed_only':test_names,'actual_file_SQLite_connection_wallclock_negative_source_evidence':test_evidence,
 'new_source_tests_not_executed_by_reviewer':True,'Root_reported_module53_pass_not_independently_read_raw_in_this_static_package':True,
 'eight_helpers':helpers,'helper_full_reverse_preserves_all_existing_guard_metadata4maps_controls8_cache7_source2056_and_813_527_dualPS39_expected':True,
 'no_native_FP_program_or_runtime_result_fabricated':True,'all_selected_original_pins':P,
 'source_edits_product_Native_D_Cargo_HTTP_calls':0}
b=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode();(O/'actual.json').write_bytes(b)
print(json.dumps({'status':result['status'],'actual_PID':os.getpid(),'actual_sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'helpers':len(helpers),'test_defs':len(test_names)}))
