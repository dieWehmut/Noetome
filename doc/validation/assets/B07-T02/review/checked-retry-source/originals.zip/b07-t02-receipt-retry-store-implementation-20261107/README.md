# B07-T02 Store receipt retry implementation

This is a source implementation and review record, not a behavioral acceptance report.

The pre-change Store is c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a / 165884 bytes. The candidate is 1d4e8e6d35caf6777cfa17fc8ad8c80c9916250377524be5ba3bcaa808b41335 / 182033 bytes. Root owns the separate Run integration. This agent changed only request_budget_store.rs, formatted that file, and did not run Cargo, Windows programs, HTTP, full Rust or full Python.

The new entry performs a fresh BEGIN IMMEDIATE load and full witnesses through the existing update_checked. Its guard wrapper runs the caller guard and then independently verifies the current registered Run.spec inputs. The existing update_checked samples event UTC only after this wrapper succeeds. No stored or caller receipt/total is reused across transactions.

The decision locates the full Run/unit/attempt/request key and requires its authoritative receipt before considering unit outcome. Existing outcome or retry returns Unchanged. A new decision requires the latest key. Validated candidates retain the original success reason; budget, non-retryable receipt, maximum attempts, global/Run stop and absolute deadline branches retain the Run classifications/reasons. The stop callback runs only in the remaining retry-eligible branch. A complete 200 or any known usage cannot become an HTTP retry because of a local timeout. Eligible retries still call the existing validate_retry and append the existing unique RetryScheduled event; no new event format was introduced.

Finish decisions append no unit terminal event. The Run caller must continue to use the separate terminal commit, and settlement remains a separate earlier commit. Prepared, Reserved and MaySend were not merged. No raw-file map, balance cache, sharing relaxation, cap change, clock extension or author fixture change was made.

Six common inline test definitions cover input mutation inside the external guard before decision, real guard waiting past the latest fitting retry boundary, another connection committing a terminal/overrun, full-key or receipt absence despite a terminal unit, one retry event across repeated calls/reopen, and known complete-200/non-retry versus a requested stop in the HTTP retry branch. Linux Store53, Windows Store51 and complete Windows813 are predicted definition counts only. Actual Cargo results must be supplied by Root.

implementation.json records the source pin and the exact restoration proof: removing only the new enum, entry and six tests restores the entire original Store bytes. static-first-failure.json retains a static collector regex assertion that omitted a test name containing 200; the corrected collector changed no Rust source. No source test or product failure was hidden by this collector correction.

The observed NoFit terminal event time includes cleanup. In the old c87/e4 loop the retry-fit sample preceded release_unsent and finish_unit fresh revalidation; event-to-settlement elapsed is not a direct measurement of the decision latency. Source inspection shows one complete readonly view can be removed on the API-return path by the new checked entry, but no latency improvement or Windows hard-gate result is claimed here.
