from pathlib import Path
import ast, hashlib, json, os

ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).resolve().parent
OLD_RUN = 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'
NEW_RUN = '3f456b5c0623b4ca7a3239808e27647c6ef08f823a686e7f4b4a6fad9dec6cd5'
OLD_STORE = 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'
NEW_STORE = '1d4e8e6d35caf6777cfa17fc8ad8c80c9916250377524be5ba3bcaa808b41335'
OLD_EXE = '2c1f409c09d6e04519117b50a962b4adeacb64ef653100866b309140ebc24f0a'
records = []

def metadata(path):
    s=path.lstat()
    assert path.is_file() and not path.is_symlink() and s.st_nlink == 1
    return {k:getattr(s,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_nlink')}

def clone(source, target, substitutions):
    before=metadata(source)
    raw=source.read_bytes()
    assert metadata(source)==before
    text=raw.decode('utf8'); observed=[]
    for old,new in substitutions:
        count=text.count(old)
        assert count>0, (source,old)
        text=text.replace(old,new); observed.append((old,new,count))
    reverse=text
    for old,new,count in reversed(observed):
        assert reverse.count(new)==count, (source,new)
        reverse=reverse.replace(new,old)
    assert reverse.encode()==raw
    ast.parse(text)
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as stream: stream.write(text.encode())
    assert target.read_bytes()==text.encode() and metadata(source)==before
    sha=hashlib.sha256(text.encode()).hexdigest()
    records.append({'original':str(source),'original_metadata':before,'original_sha256':hashlib.sha256(raw).hexdigest(),
                    'copy':str(target),'copy_metadata':metadata(target),'sha256':sha,'byte_length':len(text.encode()),
                    'substitutions':observed,'reverse_complete_bytes_equal':True,'AST_passed':True})
    return sha

pins=[(OLD_RUN,NEW_RUN),(OLD_STORE,NEW_STORE),('74943','75421'),('165884','182033')]
new_exe=clone(ROOT/'.artifacts/b07-t02-release-builder-draft-08-20261107/executor.py',
              ROOT/'.artifacts/b07-t02-release-builder-draft-09-20261107/executor.py',pins)
for name in ('prepare-operator.py','launch-operator.py','readback-operator.py','run-readback-operator.py'):
    subs=[('execution-08','execution-09')]
    original=ROOT/'.artifacts/b07-t02-native-release-execution-08-20261107'/name
    original_text=original.read_text()
    for old,new in [('draft-08','draft-09'),('pair-08','pair-09'),('release08','release09'),
                    ('registered-identity-release09','checked-retry-release09'),(OLD_EXE,new_exe)]:
        if old in original_text or old=='registered-identity-release09' and 'registered-identity-release08' in original_text:
            subs.append((old,new))
    clone(original,ROOT/'.artifacts/b07-t02-native-release-execution-09-20261107'/name,subs)
clone(ROOT/'.artifacts/b07-t02-native-full11-draft-20261107/executor.py',
      ROOT/'.artifacts/b07-t02-native-full12-draft-20261107/executor.py',pins+[('passed\': 807','passed\': 813')])
clone(ROOT/'.artifacts/b07-t02-linux-python-standard-lock-draft-01-20261107/run.py',
      ROOT/'.artifacts/b07-t02-linux-python-checked-retry-draft-01-20261107/run.py',[('standard-lock','checked-retry')])
clone(ROOT/'.artifacts/b07-t02-root-archive-tools-20261107/programs-standard-lock.py',
      ROOT/'.artifacts/b07-t02-root-archive-tools-20261107/programs-checked-retry.py',[('standard-lock','checked-retry')])
(OUT/'actual.json').write_text(json.dumps({'PID':os.getpid(),'status':'prepared_source_bound_helpers_only',
    'records':records,'Cargo':'not_run','Native':'not_run','HTTP':'not_run','real_model_calls':0,'paid_calls':0},indent=2)+'\n')
print(json.dumps({'PID':os.getpid(),'copies':len(records),'release09_executor_sha256':new_exe,'all_reverse_bytes_AST_readback_passed':True}))
