"""Package the closed historical528 stamp review; no product is invoked."""
from pathlib import Path
import binascii
import hashlib
import io
import json
import os
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
WORK = Path('/home/lyinn/project/Noetome')
ROOT = Path(__file__).parent
ORIGINAL = WORK / '.artifacts/b07-t02-independent-linux-stamp-current-review-20261107'
PACKAGE = ROOT / 'package'
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final_opened = os.fstat(stream.fileno())
    final = path.lstat()
    shape = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert shape(first) == shape(opened) == shape(final_opened) == shape(final)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
           'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

main = json.loads(read(ORIGINAL / 'actual.json'))
special = json.loads(read(ORIGINAL / 'special-pair-and-source-readback02.json'))
peer = json.loads(read(ORIGINAL / 'peer-archive-readback.json'))
python = json.loads(read(ORIGINAL / 'full-python-source-and-archive-readback.json'))
assert main['status'] == 'passed_independent_current_Linux_stamp_original_behavior_audit'
assert special['status'] == peer['status'] == python['status'] == 'passed'
assert peer['total_CRC_SHA_length_members'] == 3793
assert python['raw_tests_run'] == 466 and python['raw_passed'] == 444 and python['raw_skipped'] == 22
assert python['public_archive_CRC_SHA_length_members'] == 15193
inputs = {f'review/{path.name}': path for path in ORIGINAL.iterdir() if path.is_file()}
inputs['builder/build_archive.py'] = Path(__file__)
assert all(path.suffix != '.pyc' for path in inputs.values())
rows = []
raws = {}
for name, path in sorted(inputs.items()):
    raws[name] = read(path)
    rows.append({'member': name, 'original': str(path), 'pin': PINS[str(path)]})
assert not PACKAGE.exists()
PACKAGE.mkdir()
archive_path = PACKAGE / 'originals.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in raws.items():
        archive.writestr(name, raw)
archive_raw = read(archive_path)
with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(rows)
    for row in rows:
        raw = archive.read(row['member'])
        assert raw == raws[row['member']] == read(Path(row['original']))
        assert hashlib.sha256(raw).hexdigest() == row['pin']['sha256'] and len(raw) == row['pin']['byte_length']
        assert (binascii.crc32(raw) & 0xffffffff) == archive.getinfo(row['member']).CRC
for path in list(PINS):
    read(Path(path))
scope = 'Passed historical4ca/Run8e/FP528 Linux stamp source, before the later b393/DB-header optimization. This package contains review originals, not duplicate ELF bodies, source130 ZIP or original matrix/Python archives.'
manifest = {'member_count': len(rows), 'members': rows, 'scope': scope}
actual = {'producer': 'independent_closed_stamp_Linux_review_package_readback', 'status': 'passed',
          'scope': scope, 'member_count': len(rows), 'archive': PINS[str(archive_path)],
          'all_member_CRC_SHA_length_and_original_ID_mtime_bytes_before_after_equal': True,
          'main_Linux_groups': 62, 'main_ordinary_CLI': 364, 'main_driver': 33,
          'main_unique_waited_PIDs': 397, 'main_actual_HTTP': 70, 'main_SIGKILL_waited_minus9': 23,
          'valid_budget_groups': 39, 'valid_SQL_events': 511, 'protection_groups': 23,
          'peer_matrix_archive': {'ordinary': 3792, 'generated_reference': 1, 'total': 3793},
          'full_Python': {'run': 466, 'passed': 444, 'skipped': 22, 'snapshot': 2058, 'compiler_source': 130, 'archive_members': 15193},
          'retained_negative_multilink_test_files': 2,
          'collector_failure_history': 'full_python.py/stdout/stderr preserve first overstrict singlelink assertion on deliberate retained hardlink test fixture; full_python02 retains source/CLI singlelink gates and only archives negative files with stable actual link count. No test or source expected was altered.',
          'whole_selected_ELF_bodies_preserved_separately': ['.artifacts/b07-t02-linux-stamp-pair-01-20261107/noetome', '.artifacts/b07-t02-linux-stamp-pair-01-20261107/request-test-driver'],
          'new_Root_b393_source_pass_claimed': False, 'Native_main62': 'not_run', 'full_Linux_Rust': 'not_run',
          'scientific_quality': 'not_run', 'new_product_Cargo_HTTP_calls': 0, 'paid_or_real_model_calls': 0}
for name, value in [('manifest.json', manifest), ('actual.json', actual)]:
    with (PACKAGE / name).open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())
readme = 'Independent readback of the closed Linux4ca/528 stamp candidate.\n\nThe main behavior audit, real70 HTTP/397 PID/23 SIGKILL originals,39 valid SQL-ledger cases and23 protection cases, ELF/source130 pins, real B-terminal conditions,3793-member matrix package, and466-test Python raw/source/15193-member archive are independently read. Their results apply to preserved4ca/Run8e/FP528 only. Current b393 and later Store changes require new testing.\n\nThis review package preserves the first full-Python archive collector failure and the corrected collector. Two deliberate retained hardlink attack fixtures are archival originals, not trusted Source/Owner/ledger inputs. Every trusted source and selected executable remains singlelink. No product/HTTP/Cargo is executed by this review.\n'
(PACKAGE / 'README.md').write_bytes(readme.encode())
print(json.dumps({'status': 'passed', 'members': len(rows), 'archive': PINS[str(archive_path)],
                  'manifest': {'sha256': hashlib.sha256((PACKAGE / 'manifest.json').read_bytes()).hexdigest(), 'byte_length': (PACKAGE / 'manifest.json').stat().st_size},
                  'actual': {'sha256': hashlib.sha256((PACKAGE / 'actual.json').read_bytes()).hexdigest(), 'byte_length': (PACKAGE / 'actual.json').stat().st_size}}))
