"""Read closed current transaction archive, its ordinary originals and generated provenance.

No product execution, HTTP, archive rewriting or Python bytecode is performed.
"""
from pathlib import Path
import ast
import binascii
import hashlib
import io
import json
import os
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
REPO = Path('/home/lyinn/project/Noetome')
PUBLIC = REPO / 'doc/validation/assets/B07-T02/linux-run-stamp'
OUT = Path(__file__).parent
PINS = {}


def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1, str(path)
    with path.open('rb') as stream:
        held = os.fstat(stream.fileno())
        raw = stream.read()
        final_held = os.fstat(stream.fileno())
    final = path.lstat()
    ident = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert ident(first) == ident(held) == ident(final_held) == ident(final), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
           'device': first.st_dev, 'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw


def matches(actual, recorded):
    return all(actual[key] == value for key, value in recorded.items())


manifest_bytes = read(PUBLIC / 'manifest.json')
manifest = json.loads(manifest_bytes)
zip_bytes = read(PUBLIC / 'originals.zip')
assert PINS[str(PUBLIC / 'originals.zip')]['sha256'] == '8b0d93f01a095cb111abb4b464ed7a1a6c141e59e0df1fbb0d68a28549172957'
assert len(zip_bytes) == 4872928
assert manifest['ordinary_original_files'] == 3792 and manifest['generated_reference_members'] == 1 and manifest['total_zip_members'] == 3793
assert len(manifest['members']) == 3792
copy_receipt = json.loads(read(PUBLIC / 'copy-receipt.json'))
copies = []
for record in copy_receipt['copy_records']:
    source = Path(record['original'])
    public_path = Path(record['public_copy'])
    source_raw = read(source)
    public_raw = read(public_path)
    assert source_raw == public_raw
    assert matches(PINS[str(source)], record['original_before'])
    assert matches(PINS[str(public_path)], record['public_copy_pin'])
    copies.append({'name': public_path.name, 'source': str(source), 'original_pin': PINS[str(source)], 'public_pin': PINS[str(public_path)], 'equal': True})
assert len(copies) == 5
members = []
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) == 3793
    assert set(names) == {member['member'] for member in manifest['members']} | {manifest['embedded_reference']['name']}
    for member in manifest['members']:
        raw = archive.read(member['member'])
        item = archive.getinfo(member['member'])
        assert binascii.crc32(raw) & 0xffffffff == item.CRC
        assert hashlib.sha256(raw).hexdigest() == member['pin']['sha256'] and len(raw) == member['pin']['byte_length']
        original = Path(member['original'])
        assert read(original) == raw and PINS[str(original)] == member['pin']
        members.append({'member': member['member'], 'original': str(original), 'pin': PINS[str(original)], 'CRC': item.CRC, 'byte_equal': True})
    embedded = manifest['embedded_reference']
    reference_bytes = archive.read(embedded['name'])
    assert binascii.crc32(reference_bytes) & 0xffffffff == archive.getinfo(embedded['name']).CRC
    assert hashlib.sha256(reference_bytes).hexdigest() == embedded['sha256'] and len(reference_bytes) == embedded['byte_length'] == 2412
    reference = json.loads(reference_bytes)
    actual_refs = {}
    for path, recorded in reference['referenced_original_files'].items():
        read(Path(path))
        actual_refs[path] = PINS[path]
        assert actual_refs[path] == recorded
    builder = Path(reference['generation_program_original']['path'])
    builder_raw = read(builder)
    assert PINS[str(builder)] == reference['generation_program_original']['pin']
    assert builder_raw == archive.read(embedded['generation_program']) == read(PUBLIC / 'build_archive.py')
    ast.parse(builder_raw)
    assert PINS[str(builder)]['sha256'] == '1c279d376d37c39019a2016638ec17d58ec1daa82ed893b6f8ecd231abd3df5b'
    zip_original = Path(next(record['original'] for record in copy_receipt['copy_records'] if Path(record['public_copy']).name == 'originals.zip'))
    assert PINS[str(builder)]['mtime_ns'] < PINS[str(zip_original)]['mtime_ns']
    expected = {'referenced_original_files': actual_refs,
                'generation_program_original': {'path': str(builder), 'pin': PINS[str(builder)]},
                'scope': reference['scope']}
    reconstructed = (json.dumps(expected, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    assert reconstructed == reference_bytes
    reference_detail = {'name': embedded['name'], 'sha256': embedded['sha256'], 'byte_length': len(reference_bytes),
                        'not_an_ordinary_original': True, 'actual_reference_file_count': len(actual_refs),
                        'references': actual_refs, 'standalone_generation_program': {'path': str(builder), 'pin': PINS[str(builder)],
                        'exact_in_zip_and_public': True, 'mtime_precedes_archive': True, 'AST_passed_without_executing_builder': True},
                        'canonical_UTF8_LF_reconstruction_byte_equal': True, 'scope': reference['scope']}
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_current_stamp_archive_original_readback', 'status': 'passed',
          'scope': 'Current Linux stamp4ca matrix archive 3792 ordinary originals plus one generated reference; old release matrices retain their historical results, current native testing is separate.',
          'new_product_HTTP_Cargo_invocations': 0, 'ordinary_original_members': 3792, 'generated_members': 1,
          'total_CRC_SHA_length_members': 3793, 'all_ordinary_original_identity_mtime_bytes_before_after_equal': True,
          'all_five_public_copy_sources_identity_mtime_bytes_equal': copies, 'members': members,
          'generated_reference_provenance': reference_detail, 'all_original_read_pins': PINS}
output = OUT / 'peer-archive-readback.json'
with output.open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'ordinary': 3792, 'generated': 1, 'members': 3793,
                  'actual_sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'byte_length': output.stat().st_size}))
