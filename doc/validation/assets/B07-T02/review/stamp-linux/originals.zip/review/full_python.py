"""Read the closed 4ca/528 Linux full-Python originals; execute no product."""
from pathlib import Path
import ast
import binascii
import hashlib
import io
import json
import os
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
WORK = Path('/home/lyinn/project/Noetome')
ROOT = WORK / '.artifacts/b07-t02-linux-python-stamp-final-01-20261107'
PUBLIC = WORK / 'doc/validation/assets/B07-T02/linux-python-stamp'
OUT = Path(__file__).parent
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1, str(path)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final_opened = os.fstat(stream.fileno())
    final = path.lstat()
    shape = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert shape(first) == shape(opened) == shape(final_opened) == shape(final), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
           'inode': first.st_ino, 'mode': first.st_mode, 'mtime_ns': first.st_mtime_ns, 'links': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin, str(path)
    return raw

def data(path):
    return json.loads(read(path))

def short(pin):
    return {key: pin[key] for key in ['sha256', 'byte_length']}

actual = data(ROOT / 'actual.json')
launch = data(ROOT / 'launch.json')
assert actual['status'] == 'passed' and actual['exit_code'] == 0
assert actual['tests_run'] == 466 and actual['result_line'] == 'OK (skipped=22)'
assert actual['argv'] == launch['argv'] and launch['pid'] == 804331
assert launch['cwd'] == str(ROOT / 'repo')
assert actual['real_model_calls'] == actual['paid_calls'] == 0
assert actual['full_linux_rust'] == actual['scientific_quality'] == 'not_run'
stderr_raw = read(ROOT / 'stderr.bin')
stdout_raw = read(ROOT / 'stdout.bin')
assert short(PINS[str(ROOT / 'stderr.bin')]) == actual['stderr']
assert short(PINS[str(ROOT / 'stdout.bin')]) == actual['stdout']
stderr = stderr_raw.decode('utf8')
rows = re.findall(r'^(test_\S+ \(.+?\)) \.\.\. (ok|skipped .+|FAIL|ERROR)$', stderr, re.M)
assert len(rows) == len({name for name, outcome in rows}) == 466
assert sum(outcome == 'ok' for name, outcome in rows) == 444
assert sum(outcome.startswith('skipped ') for name, outcome in rows) == 22
assert not any(outcome in ['FAIL', 'ERROR'] for name, outcome in rows)
assert re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', stderr, re.M) == [('466', '80.835')]
assert stderr.rstrip().endswith('OK (skipped=22)')
assert actual['skipped_tests'] == [[name, outcome.removeprefix('skipped ')] for name, outcome in rows if outcome.startswith('skipped ')]
runner = read(ROOT / 'run.py')
ast.parse(runner)
assert b'code=p.wait()' in runner and b'pid\':p.pid' in runner
before = data(ROOT / 'source-before.json')
after = data(ROOT / 'source-after.json')
before_ids = data(ROOT / 'source-identities-before.json')
after_ids = data(ROOT / 'source-identities-after.json')
assert before == after and before_ids == after_ids
assert len(before) == len(before_ids) == actual['source_files'] == 2058
snapshot = []
for name, expected in before.items():
    path = ROOT / 'repo' / name
    read(path)
    assert short(PINS[str(path)]) == expected
    assert PINS[str(path)] == before_ids[name]
    snapshot.append({'name': name, 'actual_pin': PINS[str(path)]})
work_before = data(ROOT / 'worktree-source-before.json')
work_after = data(ROOT / 'worktree-source-after.json')
work_before_ids = data(ROOT / 'worktree-source-identities-before.json')
work_after_ids = data(ROOT / 'worktree-source-identities-after.json')
assert work_before == work_after and work_before_ids == work_after_ids
assert len(work_before) == len(work_before_ids) == 2056
assert set(before) - set(work_before) == {'target/debug/noetome', 'target/debug/noetome.exe'}
for name in work_before:
    assert work_before[name] == before[name]
    assert short(work_before_ids[name]) == work_before[name]
pair = Path(actual['source_build_receipt']).parent
pair_before = data(ROOT / 'selected-pair-identities-before.json')
pair_after = data(ROOT / 'selected-pair-identities-after.json')
assert pair_before == pair_after and set(pair_before) == {'actual.json', 'noetome', 'source-before.json'}
for name, expected in pair_before.items():
    read(pair / name)
    assert PINS[str(pair / name)] == expected
cli = read(pair / 'noetome')
assert cli.startswith(b'\x7fELF') and short(PINS[str(pair / 'noetome')]) == launch['binary']
assert read(ROOT / 'repo/target/debug/noetome') == cli == read(ROOT / 'repo/target/debug/noetome.exe')
binding = data(ROOT / 'compiler-source-binding.json')
assert binding['source_build_receipt'] == actual['source_build_receipt']
assert binding['receipt_pin'] == short(PINS[str(pair / 'actual.json')])
source130 = data(pair / 'source-before.json')
source130 = {name: short(pin) for name, pin in source130.items()}
assert source130 == binding['rust_cargo_sources'] and len(source130) == 130
assert all(before[name] == pin for name, pin in source130.items())
assert source130['crates/noetome-cli/src/request_budget_store.rs']['sha256'] == '4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e'
assert source130['crates/noetome-cli/src/request_run.rs']['sha256'] == '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc'
zip_raw = read(PUBLIC / 'originals.zip')
manifest = data(PUBLIC / 'manifest.json')
receipt = data(PUBLIC / 'receipt.json')
assert short(PINS[str(PUBLIC / 'originals.zip')]) == receipt['archive']
assert receipt['members'] == len(manifest) == 15193
member_rows = []
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == 15193
    assert set(archive.namelist()) == set(manifest)
    for name, expected in manifest.items():
        raw = archive.read(name)
        item = archive.getinfo(name)
        assert hashlib.sha256(raw).hexdigest() == expected['sha256'] and len(raw) == expected['byte_length']
        assert (binascii.crc32(raw) & 0xffffffff) == item.CRC
        original = WORK / '.artifacts' / name
        assert read(original) == raw
        pin = PINS[str(original)]
        meta = expected['original_metadata']
        assert (pin['device'], pin['inode'], pin['mtime_ns'], pin['byte_length'], stat.S_IMODE(pin['mode'])) == (meta['device'], meta['inode'], meta['mtime_ns'], meta['size'], meta['mode'])
        member_rows.append({'member': name, 'original': str(original), 'pin': pin, 'CRC': item.CRC})
    materialization = data(PUBLIC / 'materialization-receipt.json')
    assert materialization['archive'] == receipt['archive']
    for row in materialization['rows']:
        assert read(PUBLIC / row['output']) == archive.read(row['member'])
links = data(PUBLIC / 'links.json')
assert len(links) == receipt['symlinks_recorded_without_target_read'] == 1
for name, recorded in links.items():
    path = WORK / '.artifacts' / name
    metadata = path.lstat()
    assert stat.S_ISLNK(metadata.st_mode)
    meta = recorded['original_metadata']
    assert (metadata.st_dev, metadata.st_ino, metadata.st_mtime_ns, metadata.st_size, stat.S_IMODE(metadata.st_mode)) == (meta['device'], meta['inode'], meta['mtime_ns'], meta['size'], meta['mode'])
    assert os.readlink(path) == recorded['target']
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_closed_stamp_Linux_full_Python_source_and_raw_readback', 'status': 'passed',
          'scope': 'Historical passed source4ca/Run8e/FP528 fullPython; later two-module optimization is not covered by this result. Snapshot originals and actual before/after maps are bound to the preserved 130-file compiler source, not current mutable Root source.',
          'test_PID': launch['pid'], 'argv': actual['argv'], 'exit_code': actual['exit_code'],
          'raw_tests_run': 466, 'raw_passed': 444, 'raw_skipped': 22, 'raw_errors': 0, 'raw_failures': 0,
          'actual_wrapper_elapsed_seconds': actual['elapsed_seconds'], 'raw_unittest_elapsed_seconds': 80.835,
          'runner_records_real_Popen_PID_and_wait_before_source_checks': True,
          'snapshot_files': 2058, 'original_worktree_before_after_files': 2056, 'compiler_source_files': 130,
          'snapshot_and_selected_CLI_actual_ID_mtime_singlelink_bytes_before_after_equal': True,
          'original_worktree_capture_maps_before_after_equal_at_test_execution': True,
          'current_Root_source_equality_claimed': False, 'current_Root_optimized_modules_not_retested_here': ['request_run.rs', 'request_budget_store.rs'],
          'raw_test_outcomes': rows, 'snapshot_original_pins': snapshot, 'public_archive_CRC_SHA_length_members': 15193,
          'public_original_member_readback': member_rows, 'link_metadata_only_no_target_read': links,
          'all_read_file_ID_mtime_bytes_before_after_equal': True, 'selected_pair': pair_before,
          'full_Linux_Rust': 'not_run', 'current_Native_main62': 'not_run', 'scientific_quality': 'not_run',
          'new_product_Cargo_HTTP_invocations': 0, 'real_model_or_paid_calls': 0}
output = OUT / 'full-python-source-and-archive-readback.json'
with output.open('xb') as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'status': 'passed', 'run': 466, 'pass': 444, 'skip': 22, 'snapshot': 2058,
                  'archive_members': 15193, 'actual_sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'byte_length': output.stat().st_size}))
