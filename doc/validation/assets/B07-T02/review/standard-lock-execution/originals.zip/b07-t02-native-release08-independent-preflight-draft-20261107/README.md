# Native08 c87 独立预检草稿

此目录尚未读取D盘、调用Native Python、Cargo、产品CLI或HTTP。实际新FP、两个MZ、snapshot、sourceZIP全部pending；九个required外部Root原锚参数保留，缺参时任何D读取前退出，不能填旧C2或Native07值。

父程序是已静态修正叙述的Native07 c077-final。本稿仅改07→08路径/标签、Store57c1/165922→c87/165884及相应来源叙述，反向逐字节精确还原父稿。Runtime补充程序只改路径标签。Run e4/74943、checker3b/169966、tests428/50420及全部核验逻辑不变。

保留实际read-handle fstat/pathID/mtime/单link/fullbyte前后核对与2067个NativeVolume/Index元数据、Source2056/ZIP2061、四份完整具名来源清单、8control/7cache、physical01与immutable evidence02区分、11命令raw、双Cargo/probe实际FP、两MZ双读、derived schema和runtime完整body。它不增加目录/runtime在原构建期间持有完整文件IDguard的保证。

父Native07的CLI构建成功和driver未解析fs2的失败均是旧57源码历史事实。c87只修改两个Windows测试调用且生产prefix相等，仍需新来源实际编译/回归；不得把旧57 Linux47/62、Native07CLI或旧预检当c87整件源码验收。未来Windows模块45只指listing，完整807/Python527与主62仍not_run。
