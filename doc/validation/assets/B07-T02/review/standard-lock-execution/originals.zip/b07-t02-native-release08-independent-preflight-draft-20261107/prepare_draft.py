"""Prepare c87 Native08 preflight source only; do not access Native or D:."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import stat

OUT = Path(__file__).parent
OLD = OUT.parent / 'b07-t02-native-release07-independent-preflight-draft-20261107'
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1
    shape = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_nlink)
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final = os.fstat(stream.fileno())
    after = path.lstat()
    assert shape(first) == shape(opened) == shape(final) == shape(after)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
           'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'mode': first.st_mode, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

before = read(OLD / 'readback-final.py')
assert hashlib.sha256(before).hexdigest() == 'c077f4714d03069fde03fc46aa0f523cee5b90647adacbefedae129cf9ee090e'
text = before.decode()
after = text.replace('release07', 'release08').replace('pair-07-', 'pair-08-')
old_sha = '57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646'
new_sha = 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'
assert after.count(old_sha) == 1 and after.count('165922') == 1
after = after.replace(old_sha, new_sha).replace('165922', '165884').replace('Store57c1', 'Storec87')
restored = after.replace('release08', 'release07').replace('pair-08-', 'pair-07-').replace(new_sha, old_sha).replace('165884', '165922').replace('Storec87', 'Store57c1')
assert restored == text
tree = ast.parse(after)
assert 'c2f1' not in after
required_args = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                 and node.func.attr == 'add_argument' and any(key.arg == 'required' and isinstance(key.value, ast.Constant) and key.value.value is True for key in node.keywords)]
assert len(required_args) == 2  # two loops: five SHA/FP and four length arguments
assert "FP = args.expected_fp" in after
assert "current FPc2" not in after and "actual release08 FP{FP}" in after
with (OUT / 'readback.py').open('x') as stream:
    stream.write(after)
with (OUT / 'parent-to-current.patch').open('x') as stream:
    stream.write(''.join(difflib.unified_diff(text.splitlines(keepends=True), after.splitlines(keepends=True), 'parent-c077-Native07', 'current-c87-Native08')))
supp_before = read(OLD / 'runtime-cache-supplement.py')
assert hashlib.sha256(supp_before).hexdigest() == '4c2ff2390b0dad830d9c192b8d809ac26da1f1ac14dc7627f55707622de05e48'
supp_after = supp_before.decode().replace('release07', 'release08').replace('pair-07-', 'pair-08-')
assert supp_after.replace('release08', 'release07').replace('pair-08-', 'pair-07-').encode() == supp_before
ast.parse(supp_after)
with (OUT / 'runtime-cache-supplement.py').open('x') as stream:
    stream.write(supp_after)
for path in list(PINS):
    read(Path(path))
result = {'status': 'prepared_Home_only_c87_no_execution', 'parent_readback_source': PINS[str(OLD / 'readback-final.py')],
          'current_readback_source': {'sha256': hashlib.sha256(after.encode()).hexdigest(), 'byte_length': len(after.encode())},
          'parent_runtime_supplement_source': PINS[str(OLD / 'runtime-cache-supplement.py')],
          'current_runtime_supplement_source': {'sha256': hashlib.sha256(supp_after.encode()).hexdigest(), 'byte_length': len(supp_after.encode())},
          'reverse_only_release_label_and_StoreSHA_length_scope_exact_parent_bytes': True,
          'current_source': {'Run_SHA': 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 'Run_bytes': 74943,
                             'Store_SHA': new_sha, 'Store_bytes': 165884,
                             'checker_SHA': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 'checker_bytes': 169966,
                             'tests_SHA': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 'tests_bytes': 50420},
          'future_actual_FP': None, 'future_actual_CLI': None, 'future_actual_driver': None, 'future_actual_sourceZIP': None,
          'nine_required_external_Root_anchor_arguments_unchanged': True,
          'Source2056_ZIP2061_Native2067_metadata_fourmaps_controls8_cache7_11raw_dualFP_MZ_double_runtime_body_guards_unchanged': True,
          'Windows45_is_only_future_module_listing_not_pass': True,
          'full_Native807_Python527_Windows_main62': 'not_run', 'old57_results_reused_as_current_c87_acceptance': False,
          'all_original_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal': True,
          'new_D_Native_Cargo_product_HTTP_invocations': 0}
with (OUT / 'prepared.json').open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'readback_source': result['current_readback_source'],
                  'runtime_supplement_source': result['current_runtime_supplement_source']}))
