import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).resolve().parent
OLD_SHA = '57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646'
NEW_SHA = 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'
PINS = {
    'crates/noetome-cli/src/request_run.rs': {'sha256': 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 'byte_length': 74943},
    'crates/noetome-cli/src/request_budget_store.rs': {'sha256': NEW_SHA, 'byte_length': 165884},
    'scripts/verify_request_budget.py': {'sha256': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 'byte_length': 169966},
    'tests/test_verify_request_budget.py': {'sha256': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 'byte_length': 50420},
}

def m(s):
    return dict(device=s.st_dev, inode=s.st_ino, mode=s.st_mode,
                nlink=s.st_nlink, byte_length=s.st_size, mtime_ns=s.st_mtime_ns)

def read(path):
    p = Path(path)
    for c in [p, *p.parents]:
        if c.is_symlink():
            raise AssertionError(f'linked component {c}')
    initial = p.lstat()
    assert stat.S_ISREG(initial.st_mode) and initial.st_nlink == 1
    with p.open('rb') as f:
        opened = os.fstat(f.fileno())
        assert m(initial) == m(opened)
        data = f.read()
        assert m(opened) == m(os.fstat(f.fileno())) == m(p.lstat())
    assert len(data) == initial.st_size
    return data, {**m(initial), 'sha256': hashlib.sha256(data).hexdigest()}

all_files = {}

def keep(p):
    p = Path(p)
    b, pin = read(p)
    if str(p) in all_files:
        assert all_files[str(p)] == pin
    all_files[str(p)] = pin
    return b

rows = []
for name, old_dir, new_dir, old_pin, new_pin in (
    ('release08', 'b07-t02-release-builder-draft-07-20261107', 'b07-t02-release-builder-draft-08-20261107',
     '0bed092e1e54705ebb5b977c21acc0debd663f402024705516f8799c0820e53f',
     '2c1f409c09d6e04519117b50a962b4adeacb64ef653100866b309140ebc24f0a'),
    ('full11', 'b07-t02-native-full10-draft-20261107', 'b07-t02-native-full11-draft-20261107',
     'f464591b3934bdaf80a2f74857eefd34c4b83bf74307141d41ff7aafef90426e',
     '8826ee9a4d0945c1a0793e21b985839f3c0a6d3f98833fc134ad244313eab717'),
):
    old_path, new_path = ROOT/'.artifacts'/old_dir/'executor.py', ROOT/'.artifacts'/new_dir/'executor.py'
    old, new = keep(old_path), keep(new_path)
    assert hashlib.sha256(old).hexdigest() == old_pin
    assert hashlib.sha256(new).hexdigest() == new_pin
    reverse = new.replace(NEW_SHA.encode(), OLD_SHA.encode()).replace(b'165884', b'165922')
    assert reverse == old
    old_ast, new_ast = ast.parse(old), ast.parse(new)
    old_funcs = {n.name: ast.dump(n, include_attributes=False) for n in old_ast.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    new_funcs = {n.name: ast.dump(n, include_attributes=False) for n in new_ast.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    assert old_funcs == new_funcs
    values = {}
    for n in new_ast.body:
        if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            try:
                values[n.targets[0].id] = ast.literal_eval(n.value)
            except (ValueError, TypeError):
                pass
    assert values['SOURCE_PINS'] == PINS
    keep(ROOT/'.artifacts'/new_dir/'README.md')
    keep(ROOT/'.artifacts'/new_dir/'static-checks.json')
    diff = ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True), fromfile=str(old_path), tofile=str(new_path)))
    (OUT/(name+'-independent.diff')).write_text(diff, encoding='utf-8')
    rows.append(dict(name=name, parent=all_files[str(old_path)], current=all_files[str(new_path)],
                     exact_reverse_Store_SHA_length_to_parent=True,
                     all_function_class_AST_exact_parent=True,
                     exact_four_source_pins=values['SOURCE_PINS'],
                     full807_and_all_commands_cache_controls_guards_unchanged=True,
                     actual_execution_claim='not executed by independent static reviewer'))

for rel, pin in PINS.items():
    b = keep(ROOT/rel)
    assert hashlib.sha256(b).hexdigest() == pin['sha256'] and len(b) == pin['byte_length']

keep(Path(__file__).resolve())
before = dict(all_files)
for p, expected in before.items():
    b, actual = read(p)
    assert actual == expected

result = dict(status='passed_independent_Home_only_release08_full11_static_review',
              scope='Current e4/c87/3b/428 draft only; no Native preparation, D read, Cargo, HTTP, runtime probe or full807 result inferred.',
              actual_PID=os.getpid(), rows=rows, input_originals_before_after=before,
              all_actual_fstat_path_ID_mtime_singlelink_full_bytes_before_after_equal=True,
              no_new_tests_or_budget_deadline_gold_guard_scheduler_runtime_change=True,
              expected_Windows_Store45_full807_Python527_are_not_test_results=True,
              new_product_HTTP_Cargo_Native_D_invocations=0)
(OUT/'actual.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(status=result['status'], rows=len(rows), originals=len(before), actual_PID=os.getpid()), ensure_ascii=False))
