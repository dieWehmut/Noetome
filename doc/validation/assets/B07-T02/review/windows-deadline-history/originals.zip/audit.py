"""Read-only native deadline/history audit; no product execution or HTTP."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import sqlite3
import sys
import traceback
import zipfile

sys.dont_write_bytecode = True
ROOT = Path('D:/Noetome/.artifacts/b07-t02-request-native-full-01-20261107')
REPO = Path('D:/Noetome/.artifacts/b07-t02-windows-native-04-20261107/repo')
FIXTURE = REPO / 'fixtures/run-api-budget-v1'
OUT = Path(__file__).parent
FP = '90d7bd9a5b77232552ed1d5c654b0b5434f13e25c53ca7382e8fdd031fed0aaa'
pins = {}
result = {'producer': 'independent_native_request_deadline_original_readback',
          'status': 'running', 'OS': os.name, 'audit_PID': os.getpid(),
          'product_invocations': 0, 'generated_HTTP_requests': 0,
          'scope': 'Nativefull01 real failure, retained author oracle; native full62 remains unpassed'}

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def require(value, message):
    if not value:
        raise AssertionError(message)

def read(path):
    path = Path(path)
    pin, raw = checker.observed_stamp(path)
    require(pins.setdefault(str(path), pin) == pin, 'unchanged original ' + str(path))
    return raw

def js(path):
    return json.loads(read(path))

def copy(path, name):
    raw = read(path)
    dest = OUT / name
    dest.write_bytes(raw)
    require(dest.read_bytes() == raw, 'copy exact original')
    return raw

try:
    require(os.name == 'nt', 'actual Windows Python process required')
    sys.path.insert(0, str(REPO / 'scripts'))
    sys.path.insert(0, str(ROOT / 'checker-source'))
    spec = importlib.util.spec_from_file_location('frozen_native_budget', ROOT / 'checker-source/verify_request_budget.py')
    checker = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = checker
    spec.loader.exec_module(checker)
    before = checker.paths.inventory(ROOT)
    actual = json.loads(copy(ROOT / 'actual.json', 'original-actual.json'))
    runtime = json.loads(copy(ROOT / 'runtime.json', 'original-runtime.json'))
    binding = json.loads(copy(ROOT / 'source-build-binding.json', 'original-source-build-binding.json'))
    require(actual['status'] == 'failed' and actual['failure']['text'] == 'author actual observed HTTP count', 'retain actual author-count failure')
    require(actual['ordinary_CLI_count'] == 20 and actual['driver_count'] == 0, 'actual first native scope')
    require(all(actual['guards'].values()), 'actual original frozen guards')
    for prefix in ('author', 'checker'):
        require(js(ROOT / (prefix + '-source-before.json')) == js(ROOT / (prefix + '-source-after.json')), 'frozen ' + prefix)
    for source, expected in js(ROOT / 'checker-source-before.json').items():
        raw = read(ROOT / 'checker-source' / Path(source).name)
        require(sha(raw) == expected['sha256'] and len(raw) == expected['byte_length'], 'actual copied frozen checker')
    read(REPO / 'scripts/verify_fixture_compile.py')
    author = checker.author_check(FIXTURE)
    copy(FIXTURE / 'frozen-sha256.json', 'original-author-freeze.json')
    copy(FIXTURE / 'cases.json', 'original-author-cases.json')
    archive = Path(binding['source_archive'])
    archive_raw = read(archive)
    require(sha(archive_raw) == binding['receipt_original']['source_archive']['sha256'], 'normalized selected source ZIP')
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None, 'full ZIP CRC')
        for name, expected in binding['source_members'].items():
            raw = z.read(name)
            require(sha(raw) == expected['sha256'] and len(raw) == expected['byte_length'], 'frozen compiled/native/checker source member ' + name)
        result['source_archive'] = {'path': str(archive), 'pin': pins[str(archive)], 'CRC_members': len(z.infolist()), 'selected_source_members': len(binding['source_members']), 'all_selected_member_SHA_length_equal': True, 'body_not_copied_to_this_audit': True}
    cli = Path(runtime['selected_cli'])
    cli_raw = read(cli)
    require(cli_raw[:2] == b'MZ' and pins[str(cli)] == binding['selected_CLI'] == runtime['cli_before'], 'real full selected PE bytes and WinAPI identity')
    result['selected_native_CLI'] = {'path': str(cli), **pins[str(cli)], 'compiler_fingerprint': FP, 'body_not_copied_to_this_audit': True}
    commands = []
    for c in actual['commands']:
        command_root = ROOT / 'commands' / f"{c['number']:04d}"
        receipt = js(command_root / 'receipt.json')
        launch = js(command_root / 'launch.json')
        require(c == receipt and all(c[k] == v for k, v in launch.items()), 'physical command receipt/launch exact')
        require(c['command_kind'] == 'ordinary_cli' and c['wait_action'] == 'ordinary_exit', 'no forced kill/driver in this failed first native scope')
        require(c['selected_executable_sha256'] == pins[str(cli)]['sha256'], 'actual command selected PE')
        require(c['started_utc_ns'] <= c['finished_utc_ns'] and c['started_monotonic_ns'] <= c['finished_monotonic_ns'], 'actual PID wait ordering')
        for stream in ('stdout', 'stderr'):
            raw = read(command_root / (stream + '.bin'))
            require(sha(raw) == c[stream]['sha256'] and len(raw) == c[stream]['byte_length'], 'physical stream exact')
        commands.append({'number': c['number'], 'PID': c['PID'], 'label': c['label'], 'exit_code': c['exit_code'], 'wait_action': c['wait_action'], 'duration_ms': (c['finished_monotonic_ns'] - c['started_monotonic_ns']) / 1_000_000})
    require(len(commands) == len({c['PID'] for c in commands}) == 20, 'actual unique ordinary PIDs')
    result['actual_commands'] = commands
    case_results = []
    total_HTTP = 0
    for name in ('baseline-two-independent', 'transient-429-503-success', 'retry-exhaustion-isolates'):
        case = ROOT / name
        ledger, evidence = checker.read_authority(case / 'budget', fixture=FIXTURE, authority_config=case / 'authority-config.json', expected_fingerprint=FP, selected_run_roots=[case / 'run-main'])
        server = js(case / 'server/server-receipts.json')
        traffic = checker.verify_server_receipts(ledger, server['receipts'], case / 'server')
        require(server['observed_HTTP_request_count'] == len(server['incoming']) == len(server['receipts']), 'actual real incoming/UUID receipts count')
        for incoming in server['incoming']:
            body = read(case / 'server' / incoming['request_body_file'])
            require(sha(body) == incoming['request_body_sha256'] and len(body) == incoming['request_body_byte_length'], 'actual incoming bytes')
        total_HTTP += len(server['incoming'])
        case_results.append({'case_id': name, 'HTTP_incoming': len(server['incoming']), 'sequence': ledger.sequence, 'totals': ledger.totals(), 'traffic': traffic, 'complete_source_owner_original_usage_reconstruction': evidence})
        if name != 'retry-exhaustion-isolates':
            continue
        config = js(case / 'run-main-config.json')
        with sqlite3.connect(checker.paths.sqlite_file_uri(case / 'budget/control/budget.sqlite'), uri=True) as conn:
            sql_rows = list(conn.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
        previous = '0' * 64
        for seq, prev, payload, digest in sql_rows:
            row = json.loads(payload)
            require(seq == row['sequence'] and previous == prev == row['previous_sha256'] and sha(payload.encode()) == digest, 'independent exact raw SQL hash chain')
            previous = digest
        rows = ledger.rows
        run = next(iter(ledger.runs.values()))
        deadline = checker.utc_ns(run['units']['unit-a']['spec']['deadline_utc'])
        creation = deadline - config['units'][0]['max_elapsed_ms'] * 1_000_000
        require(config['units'][0]['max_elapsed_ms'] == config['units'][1]['max_elapsed_ms'] == 5000, 'original frozen 5-second units')
        require(checker.utc_ns(run['spec']['deadline_utc']) - creation == 10000 * 1_000_000, 'original Run deadline shared creation, no reset')
        key = next(k for k in ledger.attempts if k[1:3] == ('unit-a', 3))
        attempt = ledger.attempts[key]
        selected = [r for r in rows if r['event'].get('key') and checker.validate_key(r['event']['key']) == key or r['event']['kind'] == 'prepared' and checker.validate_key(r['event']['plan']['key']) == key]
        require([r['event']['kind'] for r in selected] == ['prepared', 'reserved', 'receipt_settled'], 'A3 never MaySend/transport/retry, only NotSent completion')
        require(attempt['state'] == 'not_sent' and attempt['receipt']['network_attempts'] == 0 and attempt['receipt']['error_code'] == 'REQUEST_RUN_BUDGET_STOP', 'A3 true NotSent accounting')
        require(checker.utc_ns(selected[0]['at_utc']) < checker.utc_ns(selected[1]['at_utc']) < deadline < checker.utc_ns(selected[2]['at_utc']), 'Prepared/Reserved before original deadline, settlement after missed gate')
        require(all(r['request_id'] != key[3] for r in server['receipts']), 'zero real A3 incoming HTTP')
        retry = []
        for row in rows:
            event = row['event']
            if event['kind'] != 'retry_scheduled':
                continue
            k = checker.validate_key(event['key'])
            delay = min(config['retry']['base_delay_ms'] * 2 ** (k[2] - 1), config['retry']['max_delay_ms'])
            when = checker.utc_ns(event['schedule']['retry_at_utc'])
            require(when - checker.utc_ns(row['at_utc']) == delay * 1_000_000, 'exact persisted exponential backoff')
            following = [r for r in rows if r['event']['kind'] == 'prepared' and r['event']['plan']['key']['unit_id'] == k[1] and r['event']['plan']['key']['attempt_no'] == k[2] + 1]
            require(len(following) == 1 and checker.utc_ns(following[0]['at_utc']) >= when, 'next logical attempt not before persisted retry_at')
            retry.append({'key': k, 'scheduled_at': row['at_utc'], 'retry_at': event['schedule']['retry_at_utc'], 'delay_ms': delay, 'next_prepared_at': following[0]['at_utc']})
        require([r['delay_ms'] for r in retry] == [100, 200], 'actual two bounded backoffs')
        require(ledger.totals() == {'accounted_tokens': 700, 'held_tokens': 16620, 'dispatched_requests': 3, 'held_requests': 0}, '700 B confirmed + two unknown A reservations; A3 full8310/slot released')
        require([r['unit_id'] for r in server['receipts']].count('unit-b') == 1, 'independent B actual one HTTP')
        timeline = [{'sequence': r['sequence'], 'at_utc': r['at_utc'], 'elapsed_from_original_creation_ms': (checker.utc_ns(r['at_utc']) - creation) / 1_000_000, 'kind': r['event']['kind'], 'key': r['event'].get('key', r['event'].get('plan', {}).get('key')), 'receipt': r['event'].get('receipt'), 'schedule': r['event'].get('schedule')} for r in rows]
        result['failed_case_deadline_readback'] = {'original_creation_utc_ns': creation, 'original_unit_deadline_utc_ns': deadline, 'deadline_utc': run['units']['unit-a']['spec']['deadline_utc'], 'A3_key': key, 'A3_state': attempt['state'], 'A3_receipt': attempt['receipt'], 'A3_phase_rows': selected, 'reserved_remaining_before_deadline_ms': (deadline - checker.utc_ns(selected[1]['at_utc'])) / 1_000_000, 'settlement_after_deadline_ms': (checker.utc_ns(selected[2]['at_utc']) - deadline) / 1_000_000, 'persistent_backoff': retry, 'timeline': timeline, 'server_receipts': server['receipts'], 'original_typed_counts_expected_4_observed_3_failure_preserved': True, 'finding': 'original deadline admission refused A3 before any MaySend or observed HTTP; NotSent released all8310 and its request slot. Two remote429 remain Unknown full8310 each. B valid200 retained Known700. No dispatch-safety or accounting defect demonstrated; deadline miss under concurrent native regressions does not prove idle native62.'}
        for original, name_out in [(case / 'budget/control/budget.sqlite', 'original-failed-budget.sqlite'), (case / 'budget/control/owner.json', 'original-failed-budget-owner.json'), (case / 'run-main/control/owner.json', 'original-failed-run-owner.json'), (case / 'run-main-config.json', 'original-failed-run-config.json'), (case / 'server/server-receipts.json', 'original-failed-server-receipts.json'), (case / 'run-main/attempts/unit-a/attempt-0003/validation.json', 'original-A3-validation.json'), (case / 'run-main/attempts/unit-a/attempt-0003/validation.md', 'original-A3-validation.md')]:
            copy(original, name_out)
        (OUT / 'original-failed-raw-sql-events.json').write_bytes(json.dumps(sql_rows, ensure_ascii=False, indent=2).encode() + b'\n')
    require(total_HTTP == 9, 'first Native matrix total actual incoming2+4+3=9')
    result['native_case_scope'] = case_results
    result['actual_observed_HTTP_requests'] = total_HTTP
    result['native_full_62_passed'] = False
    result['independent_dispatch_safety_and_budget_deadline_audit_passed'] = True
    for filename in ('launch.json', 'receipt.json', 'stdout.bin', 'stderr.bin'):
        copy(ROOT / 'commands/0020' / filename, 'original-command20-' + filename)
    after = checker.paths.inventory(ROOT)
    require(before == after, 'all original root files/directories identities/mtime/SHA unchanged by native audit')
    for path in list(pins):
        read(Path(path))
    result['actual_original_root_before_after_equal'] = True
    result['original_pins'] = pins
    result['status'] = 'passed'
except Exception as exc:
    result['status'] = 'failed'
    result['failure'] = {'type': type(exc).__name__, 'text': str(exc), 'traceback': traceback.format_exc()}
(OUT / 'actual.json').write_bytes(json.dumps(result, ensure_ascii=False, indent=2).encode() + b'\n')
print(json.dumps({'status': result['status'], 'actual_sha256': sha((OUT / 'actual.json').read_bytes()), 'byte_length': (OUT / 'actual.json').stat().st_size, 'failure': result.get('failure')}, ensure_ascii=False))
sys.exit(0 if result['status'] == 'passed' else 1)
