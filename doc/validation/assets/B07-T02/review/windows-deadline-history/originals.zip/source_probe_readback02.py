from pathlib import Path
import hashlib, importlib.util, json, os, sys, traceback, zipfile
sys.dont_write_bytecode = True
ROOT=Path('D:/Noetome/.artifacts/b07-t02-request-native-full-01-20261107')
NATIVE=Path('D:/Noetome/.artifacts/b07-t02-windows-native-04-20261107')
OUT=Path(__file__).parent
sys.path.insert(0,str(NATIVE/'repo/scripts'))
sys.path.insert(0,str(ROOT/'checker-source'))
spec=importlib.util.spec_from_file_location('native_source_probe_audit',ROOT/'checker-source/verify_request_budget.py')
checker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=checker;spec.loader.exec_module(checker)
pins={}
def read(p):
 p=Path(p);pin,b=checker.observed_stamp(p);assert pins.setdefault(str(p),pin)==pin;return b
def js(p):return json.loads(read(p))
def cp(p,n):
 b=read(p);dest=OUT/n
 if not dest.exists():dest.write_bytes(b)
 assert dest.read_bytes()==b;return json.loads(b)
result={'producer':'independent_native_build_probe_and_actual_command_FP_readback','status':'running','product_invocations':0,'generated_HTTP_requests':0}
try:
 assert os.name=='nt'
 binding=js(ROOT/'source-build-binding.json')
 normalized=cp(Path(binding['explicit_build_receipt']),'original-normalized-build-receipt.json')
 assert normalized==binding['receipt_original'] and pins[binding['explicit_build_receipt']]==binding['original_receipt_stamp']
 primary_path=Path(normalized['primary_native_receipt'])
 primary=cp(primary_path,'original-primary-native-build-receipt.json')
 assert {k:pins[str(primary_path)][k] for k in ('sha256','byte_length')}==normalized['primary_native_receipt_pin']
 fp=normalized['actual_cli_fingerprint']
 assert fp==primary['actual_compiler_fingerprint'] and normalized['cargo_build_script_fingerprints']==primary['cargo_build_script_fingerprints']==[fp]
 raw_probe=cp(NATIVE/'actual-cli-compiler-probe.json','original-native-cli-probe-receipt.json')
 raw_handshake=cp(NATIVE/'actual-driver-compiler-probe.json','original-native-driver-probe-receipt.json')
 cli_out=read(NATIVE/'actual-cli-compiler-probe.stdout.bin')
 driver_out=read(NATIVE/'actual-driver-compiler-probe.stdout.bin')
 assert json.loads(cli_out)['compiler_fingerprint']==fp
 assert any(json.loads(line).get('compiler_fingerprint')==fp for line in driver_out.splitlines() if line.startswith(b'{'))
 (OUT/'original-native-cli-probe.stdout.bin').write_bytes(cli_out)
 (OUT/'original-native-driver-probe.stdout.bin').write_bytes(driver_out)
 actual=js(ROOT/'actual.json');actual_fp=[]
 for c in actual['commands']:
  if c['argv'][1:3]!=['run','api']:continue
  stdout=json.loads(read(ROOT/'commands'/f"{c['number']:04d}"/'stdout.bin'))
  assert stdout['compiler_fingerprint']==fp and stdout['real_model_calls']==stdout['paid_calls']==0 and stdout['published'] is False and stdout['scientific_quality']=='not_run'
  actual_fp.append({'number':c['number'],'PID':c['PID'],'compiler_fingerprint':stdout['compiler_fingerprint']})
 assert len(actual_fp)==6
 original_archive=NATIVE/'source-originals.zip'
 archive_bytes=read(original_archive)
 assert hashlib.sha256(archive_bytes).hexdigest()==primary['source_archive']['sha256']==normalized['primary_source_archive_pin']['sha256']
 with zipfile.ZipFile(original_archive) as z:
  assert z.testzip() is None
  archive_members=len(z.infolist())
 result.update(status='passed',compiler_fingerprint=fp,actual_run_api_stdout_FP_records=actual_fp,
               actual_Cargo_CLI_driver_fingerprint_same=True,
               primary_source_archive={'path':str(original_archive),'pin':pins[str(original_archive)],'CRC_members':archive_members,'body_not_copied':True},
               normalized_binding_receipt_exact_original=True,primary_receipt_exact_pin=True,
               raw_primary_probe_receipts={'CLI':raw_probe,'driver':raw_handshake},native_full62_passed=False)
 for p in list(pins):read(p)
 result['original_pins']=pins
except Exception as e:
 result.update(status='failed',failure={'type':type(e).__name__,'text':str(e),'traceback':traceback.format_exc()})
(OUT/'source-probe-readback02.json').write_bytes(json.dumps(result,ensure_ascii=False,indent=2).encode()+b'\n')
print(json.dumps({'status':result['status'],'sha256':hashlib.sha256((OUT/'source-probe-readback02.json').read_bytes()).hexdigest(),'byte_length':(OUT/'source-probe-readback02.json').stat().st_size,'failure':result.get('failure')}))
sys.exit(0 if result['status']=='passed' else 1)
