# Native 首轮原期限审查原件

此包是 B07-T02 原生首轮失败的独立只读审查，不是最终 Windows 62 组通过记录。审查使用实际 Windows Python 3.12.14 与 WinAPI 文件身份，没有运行产品、发送 HTTP 或访问生产凭据、实际累计账本。

`actual.json` 首次审查通过，直接重读原生首轮 20 个 ordinary CLI 的 PID、物理 stdout/stderr、退出和 wait 记录，三案 64 条真实 SQLite 事件、完整已选来源/owner/请求/响应/用量与作者 gold，以及 9 次服务器 incoming 与 9 个 UUID 回执。来源与编译指纹绑定 native FP90d7，不从 Linux 的 62 组推定原生通过。

第三案仍是作者预期 4 次、实际 3 次 HTTP 的真实失败。原单元绝对期限为 2026-11-06T20:53:52.1145648Z。A3 Prepared 在 51.3456223、Reserved 在 51.8119819；预留时剩余 302.5829ms。全链无 A3 MaySend、transport 或服务器请求，只有期限后 52.426048 的 network_attempts=0 / REQUEST_RUN_BUDGET_STOP 结算，独立重建为 NotSent，8310 Token 与一个 slot 均释放。A1/A2 的两个远端 429 保守保持 Unknown，各占8310，B 原完整200/有效候选保留 Known700。最终 Known700+held16620/dispatched3/heldslots0。已保存退避严格为100/200ms，后续 Prepared/MaySend不早于原 retry_at。完成报表晚于期限不被用来证明允许晚发 HTTP；没有延长作者期限或修改 cap。

`source-probe-readback03.json` 独立读实际 primary/normalized build receipts 与原文件 SHA/长度，原 Native04 2060 成员 ZIP CRC、所选 normalized 2056 成员 ZIP CRC/SHA/长度，完整 29,852,672 字节 PE 与 WinAPI身份，Cargo/实际 CLI probe/driver握手/五个 start/status stdout 的 FP 全部90d7。这些大 source ZIP 和 PE 本体保留在 JSON 指定的明确原路径，**本小审查 ZIP 不含它们**。冻结作者、checker 与原构建源已在原生历史包/实际源包，包内附明确只读复算所需 checker/helper 副本。

两个 supplement collector 失败如实保留：首次把 SHA/长度二字段来源 pin 错当完整 FileStamp 比较而触发 AssertionError；第二次对 init 的实际 stdout 错要求其没有承诺的 compiler_fingerprint 字段而触发 KeyError。两次脚本/物理stdout/stderr/失败JSON均在包内，第三版只按真实 pin 字段比较并对实际 start/status 检查FP。首次主 deadline 审查一直通过，这些 supplement 失败不是产品失败，不改原运行原件或失败结论。

所有原件属于明确新 synthetic 测试根。完整首轮 root 的普通文件、目录身份、mtime与SHA在审查前后相等。原生测试与全回归同时运行的负载是上下文；此审查只证实到期准入与资金处理正确，不承诺空闲时限或完整原生矩阵。后续需要相同源和固定 PE 在独占新根的真实完整矩阵。
