from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
ROOT = Path('/home/lyinn/project/Noetome')
PUBLIC = ROOT / 'doc/validation/assets/B07-T02'
OUT = Path(__file__).parent


def require(condition, why):
    if not condition:
        raise AssertionError(why)


def read(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), str(path))
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        body = stream.read()
        final_open = os.fstat(stream.fileno())
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mtime_ns', 'st_ctime_ns', 'st_mode', 'st_size', 'st_nlink')
    require(all(getattr(before, field) == getattr(opened, field) == getattr(final_open, field) == getattr(after, field) for field in fields), 'original changed: ' + str(path))
    return body, {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body), 'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'ctime_ns': before.st_ctime_ns, 'mode': stat.S_IMODE(before.st_mode), 'nlink': before.st_nlink}


def match_pin(body, expected, why):
    require(hashlib.sha256(body).hexdigest() == expected['sha256'] and len(body) == expected['byte_length'], why)


def archive_group(label):
    folder = PUBLIC / label
    archive_body, archive_pin = read(folder / 'originals.zip')
    manifest_body, manifest_pin = read(folder / 'manifest.json')
    receipt_body, receipt_pin = read(folder / 'receipt.json')
    links_body, links_pin = read(folder / 'links.json')
    manifest, receipt, links = json.loads(manifest_body), json.loads(receipt_body), json.loads(links_body)
    match_pin(archive_body, receipt['archive'], label + ' archive pin')
    records = {}
    with zipfile.ZipFile(io.BytesIO(archive_body)) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) == receipt['members'] == len(manifest), label + ' members')
        require(set(names) == set(manifest), label + ' manifest names')
        allowed = set(receipt['selected_artifact_roots'])
        for name, expected in manifest.items():
            relative = PurePosixPath(name)
            require(not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] in allowed, 'undeclared path ' + name)
            original = ROOT / '.artifacts' / name
            original_body, before_pin = read(original)
            meta = expected['original_metadata']
            for field in ('device', 'inode', 'mtime_ns', 'mode'):
                require(before_pin[field] == meta[field], label + ':' + name + ':' + field)
            require(before_pin['byte_length'] == meta['size'], name + ':size')
            zipped = archive.read(name)  # Every member's CRC is checked by zipfile.
            match_pin(zipped, expected, label + ':' + name)
            require(zipped == original_body, label + ':' + name + ':source bytes')
            after_body, after_pin = read(original)
            require(before_pin == after_pin and original_body == after_body, name + ':original beforeafter')
            records[name] = {'original_path': str(original), 'actual_original_pin': before_pin, 'CRC_SHA_length_actual_original_ID_mtime_bytes_before_after_equal': True}
        require(sum(record['byte_length'] for record in manifest.values()) == receipt['original_byte_length'], label + ' byte total')
    link_records = {}
    for name, entry in links.items():
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] in allowed and name not in manifest, 'link path scope')
        original = ROOT / '.artifacts' / name
        before = original.lstat()
        require(stat.S_ISLNK(before.st_mode), name + ':link')
        target = os.readlink(original)  # Metadata only; the linked content is never read.
        after = original.lstat()
        for field, attr in (('device', 'st_dev'), ('inode', 'st_ino'), ('mtime_ns', 'st_mtime_ns'), ('size', 'st_size')):
            require(getattr(before, attr) == entry['original_metadata'][field] == getattr(after, attr), name + ':link ' + field)
        require(target == entry['target'], name + ':link target')
        link_records[name] = {'target': target, 'linked_content_not_read': True, 'actual_ID_mtime_metadata_equal': True}
    require(len(links) == receipt['symlinks_recorded_without_target_read'], label + ':links')
    for name, body, pin in [('originals.zip', archive_body, archive_pin), ('manifest.json', manifest_body, manifest_pin), ('receipt.json', receipt_body, receipt_pin), ('links.json', links_body, links_pin)]:
        after_body, after_pin = read(folder / name)
        require(after_body == body and after_pin == pin, label + ':public files changed')
    return {'archive': archive_pin, 'manifest': manifest_pin, 'receipt': receipt_pin, 'members': records, 'symlink_metadata': link_records, 'original_member_bytes': receipt['original_byte_length']}


def programs():
    folder = PUBLIC / 'programs-release'
    manifest_body, manifest_pin = read(folder / 'manifest.json')
    manifest = json.loads(manifest_body)
    pair = ROOT / '.artifacts/b07-t02-linux-release-pair-01-20261107'
    pair_actual, pair_pin = read(pair / 'actual.json')
    records = {}
    for name, expected in manifest.items():
        archive_body, archive_pin = read(folder / (name + '.zip'))
        match_pin(archive_body, expected['archive'], name + ':archive')
        filename = 'request-test-driver' if name.endswith('request-test-driver') else 'noetome'
        original_body, before_pin = read(pair / filename)
        require(before_pin['nlink'] == 1 and original_body[:4] == b'\x7fELF', name + ':full ordinary original ELF')
        match_pin(original_body, expected['original_executable'], name + ':program')
        for field in ('device', 'inode', 'mtime_ns'):
            require(before_pin[field] == expected['original_identity_mtime'][field], name + ':' + field)
        with zipfile.ZipFile(io.BytesIO(archive_body)) as archive:
            require(len(archive.infolist()) == len(set(archive.namelist())) == 2 and set(archive.namelist()) == {filename, 'pair-actual.json'}, name + ':two members')
            require(archive.read(filename) == original_body and archive.read('pair-actual.json') == pair_actual, name + ':full CRC/body/readback')
        after_body, after_pin = read(pair / filename)
        require(after_body == original_body and before_pin == after_pin, name + ':original beforeafter')
        require(read(folder / (name + '.zip')) == (archive_body, archive_pin), name + ':public beforeafter')
        records[name] = {'archive': archive_pin, 'actual_full_original_ELF_pin': before_pin, 'pair_receipt': pair_pin, 'full_CRC_SHA_length_two_members_equal': True, 'FP': expected['actual_compiler_fingerprint']}
    require(read(pair / 'actual.json') == (pair_actual, pair_pin) and read(folder / 'manifest.json') == (manifest_body, manifest_pin), 'program receipts stable')
    return records


def python_result():
    source = ROOT / '.artifacts/b07-t02-linux-python-release-final-01-20261107'
    actual_body, actual_pin = read(source / 'actual.json')
    actual = json.loads(actual_body)
    stdout, stdout_pin = read(source / 'stdout.bin')
    stderr, stderr_pin = read(source / 'stderr.bin')
    match_pin(stdout, actual['stdout'], 'actual raw stdout')
    match_pin(stderr, actual['stderr'], 'actual raw stderr')
    combined = (stdout + b'\n' + stderr).decode('utf-8')
    ran = re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', combined, re.M)
    skips = re.findall(r'^OK \(skipped=(\d+)\)$', combined, re.M)
    require(len(ran) == len(skips) == 1 and int(ran[0][0]) == actual['tests_run'] == 466 and int(skips[0]) == len(actual['skipped_tests']) == 22, 'real unittest summary')
    require(actual['exit_code'] == 0 and actual['status'] == 'passed' and not re.search(r'^(FAILED|ERROR:|FAIL:)', combined, re.M), 'real test failures')
    paired = {}
    for prefix in ('source', 'source-identities', 'worktree-source', 'worktree-source-identities', 'selected-pair-identities'):
        before_body, before_pin = read(source / (prefix + '-before.json'))
        after_body, after_pin = read(source / (prefix + '-after.json'))
        before, after = json.loads(before_body), json.loads(after_body)
        require(before == after, prefix + ':actual source identity and bytes beforeafter')
        paired[prefix] = {'items': len(before), 'before_pin': before_pin, 'after_pin': after_pin, 'actual_equal': True}
    require(paired['source']['items'] == paired['source-identities']['items'] == actual['source_files'] == 2058, 'snapshot source2058')
    require(paired['worktree-source']['items'] == paired['worktree-source-identities']['items'] == 2056, 'Root source2056')
    snapshot = json.loads(read(source / 'source-before.json')[0])
    worktree = json.loads(read(source / 'worktree-source-before.json')[0])
    require({name: snapshot[name] for name in worktree} == worktree, 'actual Root2056 exact subset of snapshot2058')
    added_aliases = sorted(set(snapshot) - set(worktree))
    require(len(added_aliases) == 2 and all(snapshot[name]['sha256'] == '9089d51ef4e5e1334e650c184c13bf2476a9ac82d2c25ea00b52f87f1ed771be' and snapshot[name]['byte_length'] == 17858808 for name in added_aliases), 'two exact release CLI aliases')
    require(paired['selected-pair-identities']['items'] == 3, 'original CLI/receipt/source-before three identities')
    launch_body, launch_pin = read(source / 'launch.json')
    launch = json.loads(launch_body)
    require(launch['argv'] == actual['argv'] and launch['pid'] == 776536 and launch['binary']['sha256'] == '9089d51ef4e5e1334e650c184c13bf2476a9ac82d2c25ea00b52f87f1ed771be', 'actual launched process and release CLI')
    binding_body, binding_pin = read(source / 'compiler-source-binding.json')
    binding = json.loads(binding_body)
    with zipfile.ZipFile(ROOT / '.artifacts/b07-t02-linux-release-pair-01-20261107/source-originals.zip') as archive:
        require(len(archive.infolist()) == len(set(archive.namelist())) == len(binding['rust_cargo_sources']) == 130, 'compiler source130')
        for name, pin in binding['rust_cargo_sources'].items():
            match_pin(archive.read(name), pin, 'actual compiler source:' + name)
    return {'actual_original': actual_pin, 'raw_stdout': stdout_pin, 'raw_stderr': stderr_pin, 'tests_run': 466, 'passed': 444, 'skipped': 22, 'elapsed_unittest_seconds': float(ran[0][1]), 'actual_process_PID': launch['pid'], 'launch_pin': launch_pin, 'source_guards': paired, 'compiler_source_binding_pin': binding_pin, 'snapshot_alias_paths': added_aliases, 'compiled_source_members_CRC_SHA_length': 130, 'scope': 'Actual final Linux Python snapshot2058=Root2056 plus two explicit release CLI aliases beforeafter and release CLI/receipt actual identity guard. No full Linux Rust, Native or directory identity guarantee claimed; current public docs added later are outside this recorded execution scope.'}


result = {'producer': 'independent_closed_current_Linux_release_public_archive_delta_readback', 'status': 'passed', 'diagnostic_release': archive_group('diagnostic-release'), 'programs_release': programs(), 'linux_python_release': archive_group('linux-python-release'), 'actual_full_python_readback': python_result(), 'new_product_HTTP_Cargo_D_heavy_reads': 0}
result['total_new_archives'] = 4
result['total_full_CRC_SHA_length_members'] = len(result['diagnostic_release']['members']) + len(result['linux_python_release']['members']) + 4
result['total_metadata_links_without_target_content_read'] = len(result['linux_python_release']['symlink_metadata'])
with (OUT / 'actual.json').open('x', encoding='utf-8') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'status': result['status'], 'archives': result['total_new_archives'], 'members': result['total_full_CRC_SHA_length_members'], 'metadata_only_links': result['total_metadata_links_without_target_content_read'], 'Python': '466=444passed+22skipped', 'actual_sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(), 'actual_byte_length': (OUT / 'actual.json').stat().st_size}, ensure_ascii=False))
