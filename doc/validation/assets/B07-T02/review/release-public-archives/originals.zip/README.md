# Current Linux release public archive independent readback

This audit reread four closed public archives: diagnostic-release (51 members), both programs-release ZIPs (two full members each), and linux-python-release (15184 regular members). All 15239 members passed actual ZIP CRC/SHA/length and ordinary original device/inode/mtime/bytes before-after comparisons. One separately declared symlink was checked through lstat/readlink metadata only; its target content was not read.

Full original release ELF bodies are in programs-release and are not duplicated in this reviewer package. Actual source130 compiled archive members, both full ELF bytes, the pair receipt and current source fingerprints were independently bound. Program preservation is separate from test acceptance.

The saved full Python raw output reports Ran466/OK(skipped22), so 444 passed and22 skipped, real PID776536 and exit0. Snapshot source2058 is Root2056 plus two explicit byte-exact release CLI aliases. Each complete before/after source pin and identity map is equal. The separate original selected CLI, actual.json and source-before.json three-file identity witness is equal. This does not claim full Linux Rust, native Windows or arbitrary directory identities.

The initial independent collector incorrectly required both Root and snapshot to have2058 items. All four archive body reads had completed; its final source-count assertion then failed. readback-attempt01.py/attempt01-stdout.bin/attempt01-stderr.bin preserve the actual collector failure. readback02.py separates Root2056 and snapshot2058, requires the exact named subset and the two release CLI alias hashes, and completed with0. Original package and product bytes were never changed.

No product, Cargo, HTTP or D-drive heavy read was executed by this review. Current Native release timing and full acceptance remain separate pending evidence. Source paths in actual.json are explicit owned .artifacts originals, no recursive unknown/private scan.
