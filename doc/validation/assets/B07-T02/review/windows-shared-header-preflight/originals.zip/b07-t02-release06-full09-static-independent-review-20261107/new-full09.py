"""Full native debug regression wrapper draft; no release result reuse."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import zipfile

sys.dont_write_bytecode = True
RUNNER_SHA = '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1'
RUST_SHA = 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c'
PYTHON_SHA = '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7'
TESTS_SHA = '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348'
SOURCE_PINS = {'crates/noetome-cli/src/request_run.rs': {'sha256': 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c', 'byte_length': 74782}, 'crates/noetome-cli/src/request_budget_store.rs': {'sha256': '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184', 'byte_length': 151556}, 'scripts/verify_request_budget.py': {'sha256': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 'byte_length': 169966}, 'tests/test_verify_request_budget.py': {'sha256': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 'byte_length': 50420}}
EXECUTOR_NAME = 'native-full-executor.py'
CONTROL_NAMES = ('snapshot.json', 'source-originals.zip', 'runner.py', 'launch-native.ps1',
                 'precise-source-scopes.json', 'rust-dependency-subset.json',
                 'prepared-source.json', EXECUTOR_NAME)


def ordinary(path):
    path = Path(path)
    for part in (path, *path.parents):
        info = part.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise RuntimeError('linked/reparse path before read: ' + str(part))
    return path


def metadata(path):
    path = ordinary(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise RuntimeError('source/control/program is not an ordinary single-link file: ' + str(path))
    return {key: getattr(info, key) for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')}


class StrongFiles:
    """Fixed initial metadata; never refresh the baseline for an old path."""
    def __init__(self):
        self.initial = {}

    def register(self, path):
        path = Path(path)
        observed = metadata(path)
        key = str(path)
        if key in self.initial and self.initial[key] != observed:
            raise RuntimeError('attempt to refresh changed original metadata: ' + key)
        self.initial.setdefault(key, observed)

    def check(self):
        for path, expected in self.initial.items():
            if metadata(path) != expected:
                raise RuntimeError('original actual ID/time/length/link changed: ' + path)

    def capture_sources(self, base, source_root):
        for name in CONTROL_NAMES:
            self.register(base / name)
        snapshot = load(base / 'snapshot.json')
        self.check()
        for name in snapshot['files']:
            if name.startswith(('/', '\\')) or '\\' in name or ':' in name or any(p in {'', '.', '..'} for p in name.split('/')):
                raise RuntimeError('unsafe selected source relative path')
            self.register(source_root / name)
        self.check()

    def receipt(self):
        return {'files': self.initial, 'fixed_initial_metadata': True,
                'file_actual_ID_mtime_length_singlelink_guard': True,
                'ancestor_reparse_checked_before_reads': True,
                'directory_actual_identity_guard': False,
                'runtime_tool_actual_identity_guard': False}


def pin(path):
    h = hashlib.sha256()
    length = 0
    with Path(path).open('rb') as stream:
        for raw in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(raw)
            length += len(raw)
    return {'sha256': h.hexdigest(), 'byte_length': length}


def load(path):
    return json.loads(Path(path).read_bytes())


def module(path):
    before = metadata(path)
    if pin(path)['sha256'] != RUNNER_SHA:
        raise RuntimeError('original reviewed full runner differs')
    if metadata(path) != before:
        raise RuntimeError('original runner metadata changed while hashing')
    spec = importlib.util.spec_from_file_location('native_full_original_runner', path)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    return old


def controls(base, old):
    prepared = load(base / 'prepared-source.json')
    expected = prepared['full_executor']
    old.require(pin(base / EXECUTOR_NAME) == expected, 'sealed full executor differs')
    return {**old.controls(base), EXECUTOR_NAME: expected}


def prepare(args):
    ordinary(args.original_runner)
    ordinary(args.repo)
    old = module(args.original_runner.resolve())
    for name, expected in SOURCE_PINS.items():
        before = metadata(args.repo / name)
        old.require(pin(args.repo / name) == expected, 'current exact selected freeze differs: ' + name)
        old.require(metadata(args.repo / name) == before, 'selected source metadata changed before prepare: ' + name)
    # Only an explicit previously closed Native01 target may be selected by Root.
    # The original prepare/run code checks its ownership and terminal receipt.
    old.prepare(argparse.Namespace(repo=args.repo, native_base=args.native_base,
                                   freeze_label=args.freeze_label, cache_target=args.cache_target))
    base = args.native_base
    shutil.copyfile(Path(__file__), base / EXECUTOR_NAME)
    with zipfile.ZipFile(base / 'source-originals.zip', 'a', zipfile.ZIP_DEFLATED) as archive:
        archive.write(base / EXECUTOR_NAME, EXECUTOR_NAME)
    with zipfile.ZipFile(base / 'source-originals.zip') as archive:
        names = archive.namelist()
        old.require(archive.testzip() is None and len(names) == len(set(names)) == len(load(base / 'snapshot.json')['files']) + 5,
                    'extended full source archive inventory/CRC differs')
        old.require(archive.read(EXECUTOR_NAME) == (base / EXECUTOR_NAME).read_bytes(), 'archived full executor differs')
    native = 'D:\\' + base.relative_to(Path('/mnt/d')).as_posix().replace('/', '\\')
    quote = lambda v: "'" + v.replace("'", "''") + "'"
    launch = "$ErrorActionPreference='Stop'\n$env:PSExecutionPolicyPreference='Bypass'\n& " + quote(old.PDF_PYTHON)
    launch += ' -X utf8 ' + quote(native + '\\' + EXECUTOR_NAME) + ' run --base ' + quote(native)
    for flag, name in [('snapshot', 'snapshot.json'), ('runner', 'runner.py'),
                       ('source-archive', 'source-originals.zip'), ('executor', EXECUTOR_NAME)]:
        launch += ' --' + flag + '-sha256 ' + quote(pin(base / name)['sha256'])
    (base / 'launch-native.ps1').write_text(launch + '\nexit $LASTEXITCODE\n', encoding='utf8')
    prepared = load(base / 'prepared-source.json')
    prepared.update({'source_archive': pin(base / 'source-originals.zip'),
                     'launcher': pin(base / 'launch-native.ps1'), 'full_executor': pin(base / EXECUTOR_NAME),
                     'status': 'frozen_full_debug_regression_not_executed'})
    old.save(base / 'prepared-source.json', prepared)
    controls(base, old)
    print(json.dumps({'status': prepared['status'], 'base': str(base), 'source_count': prepared['source_count'],
                      'snapshot': prepared['snapshot'], 'source_archive': prepared['source_archive'],
                      'executor': prepared['full_executor']}), flush=True)


def launch(args):
    ordinary(args.native_base)
    base = args.native_base.resolve()
    old = module(base / 'runner.py')
    fixed = StrongFiles()
    for name in CONTROL_NAMES:
        fixed.register(base / name)
    snapshot = load(base / 'snapshot.json')
    fixed.check()
    fixed.capture_sources(base, Path(snapshot['source_root']))
    before = controls(base, old)
    old.require(pin(Path(__file__)) == before[EXECUTOR_NAME], 'current full executor differs from the prepared copy')
    inherited_files = old.files

    def guarded_files(root, names):
        fixed.check()
        result = inherited_files(root, names)
        fixed.check()
        return result

    old.files = guarded_files
    fixed.check()
    old.launch_native(argparse.Namespace(native_base=base))
    fixed.check()
    old.require(old.files(base, before) == before, 'full executor/control originals changed across actual native wait')
    old.save(base / 'outer-strong-metadata-guard.json', fixed.receipt())


def native(args):
    ordinary(args.base)
    fixed = StrongFiles()
    for name in CONTROL_NAMES:
        fixed.register(args.base / name)
    old = module(args.base / 'runner.py')
    fixed.check()
    old.require(pin(args.base / 'snapshot.json')['sha256'] == args.snapshot_sha256,
                'external snapshot SHA differs before selected source names are read')
    old.require(pin(args.base / EXECUTOR_NAME)['sha256'] == args.executor_sha256, 'external full executor SHA differs')
    fixed.capture_sources(args.base, args.base / 'repo')
    fixed.check()
    context = old.NativeRun(args)
    fixed.check()
    context.control_before = controls(context.base, old)
    old.require(all(context.expected.get(name) == expected for name, expected in SOURCE_PINS.items()), 'native sealed source SHA/length differs from this exact Store/Run/Python/test freeze')
    for name in context.build_assets:
        fixed.register(context.repo / name)
    inherited_guard = context.guards

    def strong_guard():
        # Original execute creates fresh selected files and a fresh fallback.
        # Register each once before the next guard reads its bytes or command
        # uses it. A changed old path can never refresh the metadata baseline.
        for name in context.selected:
            fixed.register(context.base / 'selected' / name)
        for path in context.binary_aliases:
            fixed.register(Path(path))
        fixed.check()
        result = inherited_guard()
        fixed.check()
        return result

    context.guards = strong_guard
    old.save(context.base / 'strong-metadata-before.json', fixed.receipt())
    for name in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_BUILD_TARGET',
                 'CARGO_PROFILE_DEV_OPT_LEVEL', 'CARGO_PROFILE_DEV_DEBUG',
                 'CARGO_PROFILE_DEV_DEBUG_ASSERTIONS', 'CARGO_PROFILE_TEST_OPT_LEVEL',
                 'CARGO_PROFILE_TEST_DEBUG', 'CARGO_PROFILE_TEST_DEBUG_ASSERTIONS'):
        context.env.pop(name, None)
    # These are the actual original full commands, not summaries of a prior run:
    # clean CLI package, fmt, workspace check/build/test, libdriver build/probes,
    # full Python, both PowerShell39 suites, source/registry/runtime guards.
    context.execute()
    fixed.check()
    raw_final = context.base / 'native-final.json'
    result = load(raw_final)
    old.require(result['status'] == 'passed', 'actual full native regression did not pass')
    old.require(result['rust_totals'] == {'passed': 802, 'failed': 0, 'ignored': 0}, 'current full Rust summaries differ')
    old.require(result['python_tests_run'] == 527 and len(result['python_skips']) == 8, 'current full Python scope differs')
    old.require(len(result['actual_modern_powershell_credentials']) == len(result['actual_legacy_powershell_credentials']) == 39,
                'actual two PowerShell scopes differ')
    artifacts = load(context.base / 'compiler-artifacts.json')
    drivers = [v for v in artifacts if v['target']['name'] == 'noetome_cli' and v['profile']['test'] and v.get('executable')]
    old.require(len(drivers) == 1 and drivers[0]['profile']['opt_level'] == '0'
                and drivers[0]['profile']['debug_assertions'] is True,
                'full debug driver actual Cargo profile differs from this declared scope')
    old.save(context.base / 'strong-metadata-after.json', fixed.receipt())
    result = {**result, 'scope': 'Actual full native debug regression of current sources. Release behavior/pair timing belongs to separate evidence; no old Native05 results reused.',
              'original_native_final': pin(raw_final), 'full_executor': pin(context.base / EXECUTOR_NAME),
              'strong_metadata_guard': {'before': pin(context.base / 'strong-metadata-before.json'),
                                        'after': pin(context.base / 'strong-metadata-after.json'),
                                        'fixed_initial_file_metadata': True,
                                        'selected_and_alias_paths_registered_once_before_commands': True,
                                        'directory_actual_identity_guard': False,
                                        'runtime_tool_actual_identity_guard': False},
              'full_regression_profile': 'debug', 'release_HTTP_behavior': 'not_run_by_this_executor',
              'previous_test_results_reused': False}
    # Preserve the original NativeRun final receipt unchanged as its own raw.
    old.save(context.base / 'full-regression-receipt.json', result)
    print(json.dumps({'status': result['status'], 'source_count': result['source_count'],
                      'actual_compiler_fingerprint': result['actual_cli_and_driver_compiler_fingerprint'],
                      'rust': result['rust_totals'], 'python': result['python_tests_run']}), flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    modes = p.add_subparsers(dest='mode', required=True)
    q = modes.add_parser('prepare')
    q.add_argument('--repo', type=Path, required=True)
    q.add_argument('--native-base', type=Path, required=True)
    q.add_argument('--original-runner', type=Path, required=True)
    q.add_argument('--freeze-label', required=True)
    q.add_argument('--cache-target', type=Path)
    q = modes.add_parser('launch')
    q.add_argument('--native-base', type=Path, required=True)
    q = modes.add_parser('run')
    q.add_argument('--base', type=Path, required=True)
    for name in ('snapshot', 'runner', 'source-archive', 'executor'):
        q.add_argument('--' + name + '-sha256', required=True)
    args = p.parse_args()
    if args.mode == 'prepare':
        return prepare(args)
    if args.mode == 'launch':
        return launch(args)
    try:
        native(args)
    except Exception as error:
        if args.base.exists():
            old = module(args.base / 'runner.py')
            old.save(args.base / 'native-full-failure.json', {'status': 'failed_current_full_debug_regression',
                     'error_type': type(error).__name__, 'error': str(error),
                     'scope': 'Current full execution failed; original raw and old final receipts preserved.'})
        raise


if __name__ == '__main__':
    main()
