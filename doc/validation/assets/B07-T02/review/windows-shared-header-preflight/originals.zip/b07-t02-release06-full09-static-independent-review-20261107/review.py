"""Small Home-only static proof of the two closed draft deltas; no execution."""
from pathlib import Path
import ast
import hashlib
import json
import os
import stat

WORK = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PINS = {}

def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final_opened = os.fstat(stream.fileno())
    after = path.lstat()
    shape = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert shape(before) == shape(opened) == shape(final_opened) == shape(after)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': before.st_dev,
           'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns, 'nlink': before.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw.decode()

paths = {
    'old-release05.py': WORK / '.artifacts/b07-t02-release-builder-draft-05-20261107/executor.py',
    'new-release06.py': WORK / '.artifacts/b07-t02-release-builder-draft-06-20261107/executor.py',
    'old-full08.py': WORK / '.artifacts/b07-t02-native-full08-draft-20261107/executor.py',
    'new-full09.py': WORK / '.artifacts/b07-t02-native-full09-draft-20261107/executor.py'}
sources = {name: read(path) for name, path in paths.items()}
current = {'crates/noetome-cli/src/request_run.rs': {'sha256': 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c', 'byte_length': 74782},
           'crates/noetome-cli/src/request_budget_store.rs': {'sha256': '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184', 'byte_length': 151556},
           'scripts/verify_request_budget.py': {'sha256': '3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 'byte_length': 169966},
           'tests/test_verify_request_budget.py': {'sha256': '42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 'byte_length': 50420}}
for name in ['new-release06.py', 'new-full09.py']:
    tree = ast.parse(sources[name])
    item = next(node for node in tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'SOURCE_PINS' for target in node.targets))
    assert ast.literal_eval(item.value) == current

def restore_pins(source):
    return source.replace(current['crates/noetome-cli/src/request_run.rs']['sha256'], '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc').replace(current['crates/noetome-cli/src/request_budget_store.rs']['sha256'], '4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e').replace("'byte_length': 74782", "'byte_length': 75784").replace("'byte_length': 151556", "'byte_length': 142612")

full = restore_pins(sources['new-full09.py']).replace("== {'passed': 802, 'failed': 0, 'ignored': 0}", "== {'passed': 798, 'failed': 0, 'ignored': 0}")
assert full == sources['old-full08.py']
release = restore_pins(sources['new-release06.py'])
release = '\n'.join(line for line in release.split('\n') if not line.startswith('SOURCE_PINS = '))
release = release.replace('    for name, expected in SOURCE_PINS.items():\n        metadata(args.repo / name)\n        old.require(pin(args.repo / name) == expected, \'current selected source SHA/length freeze differs: \' + name)',
    "    for name, expected in [('crates/noetome-cli/src/request_run.rs', RUST_SHA), ('crates/noetome-cli/src/request_budget_store.rs', STORE_SHA), ('scripts/verify_request_budget.py', PYTHON_SHA), ('tests/test_verify_request_budget.py', TESTS_SHA)]:\n        metadata(args.repo / name)\n        old.require(pin(args.repo / name)['sha256'] == expected, 'current selected source freeze differs: ' + name)")
release = release.replace("    old.require(all(context.expected.get(name) == expected for name, expected in SOURCE_PINS.items()), 'native sealed source SHA/length differs from this exact Run/Store/Python/test freeze')\n", '')
assert release == sources['old-release05.py']
for name, source in sources.items():
    with (OUT / name).open('xb') as stream:
        stream.write(source.encode())
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_Home_only_release06_full09_static_scope_review', 'status': 'passed_static_review',
          'release06_exact_byte_restore_to_closed_d398_release05': True,
          'full09_exact_byte_restore_to_closed_71c58_full08': True,
          'strict_current_four_SHA_length_literals': current,
          'release06_changes': 'Current Run/Store SHA/length; add four explicit SOURCE_PINS, compare full SHA/length before prepare and against sealed Native expected after fixed metadata-before-init checks. All prior cache/source-map/build/runtime guards unchanged.',
          'full09_changes': 'Only current Run/Store SHA/length and expected fullRust798 to802. Actual fresh original execute,527 Python and both PowerShell39 remain required; no old test result reuse.',
          'expected_platform_counts_not_execution': {'Linux_budget_module': 42, 'Windows_budget_module': 40, 'Windows_full_Rust': 802},
          'physical01_cache_independent02_evidence_sevenpins_fourmaps_eightcontrols_unchanged': True,
          'findings': [], 'prepare_launch_product_tests_HTTP_Native_or_D_reads': 0,
          'scope': 'Static source/draft proof only. Independent current Native06 release preflight was reported separately; this proof does not run full regression or behavior.',
          'original_draft_pins': PINS}
with (OUT / 'actual.json').open('xb') as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(), 'byte_length': (OUT / 'actual.json').stat().st_size}))
