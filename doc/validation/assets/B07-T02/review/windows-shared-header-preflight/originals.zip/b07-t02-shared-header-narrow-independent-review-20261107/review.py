"""Read the single status-exit expectation correction; execute no Native code."""
from pathlib import Path
import ast
import binascii
import hashlib
import io
import json
import os
import stat
import zipfile

WORK = Path('/home/lyinn/project/Noetome')
SOURCE = WORK / '.artifacts/b07-t02-shared-header-native-preparation-20261107'
OLD = WORK / '.artifacts/b07-t02-native-release-narrow-wrapper-20261107'
OUT = Path(__file__).parent
PINS = {}

def read(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        raw = stream.read()
        final_opened = os.fstat(stream.fileno())
    final = path.lstat()
    shape = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_nlink)
    assert shape(first) == shape(opened) == shape(final_opened) == shape(final)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw), 'device': first.st_dev,
           'inode': first.st_ino, 'mtime_ns': first.st_mtime_ns, 'nlink': first.st_nlink}
    assert PINS.setdefault(str(path), pin) == pin
    return raw

old = read(OLD / 'narrow.py')
assert old == read(SOURCE / 'old89d-narrow.py')
new = read(SOURCE / 'narrow.py')
assert hashlib.sha256(old).hexdigest() == '89d397ec4922a850531b9f7130b32e889199ebe8edabf580665e41cb17053310'
assert hashlib.sha256(new).hexdigest() == 'a7ef5424797ec59d5aebc8382ae26acb91a0885c3ff40ccb07e492b4d7d8bff3'
assert len(old) == len(new) == 14081
changes = [(index, a, b) for index, (a, b) in enumerate(zip(old, new)) if a != b]
assert len(changes) == 1 and changes[0][1:] == (ord('0'), ord('3'))
original_tree = ast.parse(old)
new_tree = ast.parse(new)
selected = []
for node in ast.walk(original_tree):
    if isinstance(node, ast.Call) and any(keyword.arg == 'label' and isinstance(keyword.value, ast.Constant)
                                         and keyword.value.value == 'ordinary elapsed terminal readonly status' for keyword in node.keywords):
        selected.append(node)
assert len(selected) == 1
expected = next(keyword for keyword in selected[0].keywords if keyword.arg == 'expected')
assert isinstance(expected.value, ast.Constant) and expected.value.value == 0
expected.value.value = 3
assert ast.dump(original_tree, include_attributes=False) == ast.dump(new_tree, include_attributes=False)
for name, sha in [('normalize_build.py', '9fbc7c68c60c7f06bbd286d65b275fc26df99bc56326ce6ef4d91bda3cdd40af'),
                  ('run_stage.py', '11ab48b314f2ac95eed0c507d7fca13f318ec0b012f093442a56e5dc932d19ae')]:
    raw = read(SOURCE / name)
    assert raw == read(OLD / name) and hashlib.sha256(raw).hexdigest() == sha
public_proof_path = WORK / 'doc/validation/assets/B07-T02/deadline-stamp-history/diagnostic-status-expectation.json'
proof_raw = read(public_proof_path)
assert proof_raw == read(SOURCE / 'status-expectation-proof-original.json')
proof = json.loads(proof_raw)
assert proof['actual_exit_code'] == proof['correct_derived_exit_for_failed_Run_status'] == 3
assert proof['actual_diagnostic'] == 'REQUEST_RUN_FAILED' and proof['actual_run_status'] == 'failed'
assert proof['original_extra_overall_status'] == 'failed' and not proof['reclassified_as_passed']
history = WORK / '.artifacts/b07-t02-deadline-stamp-history-20261107/package/originals.zip'
history_raw = read(history)
with zipfile.ZipFile(io.BytesIO(history_raw)) as archive:
    prefix = 'b07-t02-request-native-stamp-ordinary-elapsed-01-20261107/commands/0009/'
    selected_raw = {}
    for name in ['receipt.json', 'stdout.bin', 'stderr.bin']:
        raw = archive.read(prefix + name)
        assert (binascii.crc32(raw) & 0xffffffff) == archive.getinfo(prefix + name).CRC
        kind = {'receipt.json': 'receipt', 'stdout.bin': 'stdout', 'stderr.bin': 'stderr'}[name]
        assert hashlib.sha256(raw).hexdigest() == proof['inputs'][kind]['sha256']
        assert len(raw) == proof['inputs'][kind]['byte_length']
        selected_raw[name] = raw
    receipt = json.loads(selected_raw['receipt.json'])
    stdout = json.loads(selected_raw['stdout.bin'])
    assert receipt['exit_code'] == 3 and receipt['PID'] == 41836
    assert stdout['operation'] == 'api_run_status' and stdout['run_status'] == 'failed'
    assert b'REQUEST_RUN_FAILED' in selected_raw['stderr.bin']
author = WORK / 'fixtures/run-api-budget-v1'
author_manifest_raw = read(author / 'frozen-sha256.json')
assert hashlib.sha256(author_manifest_raw).hexdigest() == 'ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272'
author_manifest = json.loads(author_manifest_raw)
assert len(author_manifest['files']) == 44
for name, recorded in author_manifest['files'].items():
    raw = read(author / name)
    assert hashlib.sha256(raw).hexdigest() == recorded['sha256'] and len(raw) == recorded['byte_length']
for path in list(PINS):
    read(Path(path))
result = {'producer': 'independent_narrow_failed_status_expected_exit_single_parameter_review', 'status': 'passed_static_review',
          'one_ASCII_byte_and_one_AST_expected_keyword_0_to3': True, 'old_narrow_pin': PINS[str(OLD / 'narrow.py')],
          'new_narrow_pin': PINS[str(SOURCE / 'narrow.py')], 'normalizer9fbc_stage11ab_exact_byte_equal': True,
          'frozen_author44_payloads_and_manifest_unchanged': True, 'original_status_PID': 41836,
          'original_real_failed_Run_status_exit3_from_saved_receipt_stdout_stderr_and_CRC': True,
          'original_failed_extra_not_reclassified_as_passed': True,
          'author_deadlines_backoff_HTTP_expected_OSkill_and_readonly_inventory_checks_unchanged': True,
          'scope': 'Preparation-only correction for the extra ordinary failed Run readonly status. Main62/three targets and all source/author policies remain untouched. New shared-header source behavior requires future real source-bound execution.',
          'Native_CLI_HTTP_Cargo_invocations': 0, 'D_disk_reads': 0, 'findings': [], 'all_original_read_ID_mtime_bytes_before_after_equal': True,
          'original_read_pins': PINS}
with (OUT / 'actual.json').open('xb') as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
print(json.dumps({'status': result['status'], 'actual_sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(), 'byte_length': (OUT / 'actual.json').stat().st_size}))
