# 当前 Linux release 全矩阵独立审查

本审查重新读取 current `3b263fca…` checker、`2e735787…` helper、`42825f8a…` tests 和实际 Linux release FP `e3da041f…` 的正式 full02 原件。没有执行 CLI、driver、HTTP、Cargo 或改动原矩阵/作者字节；审查解释器明确禁写 pyc。结果不证明 Native、完整 Linux workspace Rust、科学质量或生产Vault恢复。

主矩阵实际62组、364普通CLI+33driver、397唯一PID及70次完整真实HTTP接收/UUID回执逐原件核对。23次实际SIGKILL均记录kill与wait(-9)，不存在用自然exit代替杀进程。39个有效预算流程重建511条完整SQL原事件并独立标量复算；23个保护场景按真实普通CLI拒绝/保留现场或明确输入invalidated审查，没有把攻击库作为有效账本。

原请求正文5238B与1024+2048确定R8310。相同响应SHA对应两实际UUID各700、未知全R保留、原global opening/跨Run近限、发送与结算幂等、五类retry及显式Unknown恢复、原deadline与1000ms持久退避、Prepared/Reserved到期NotSent、四个同步伪造Core诊断都从实际原件重验。候选成功与真实用量分开，价格/tokenizer未知，knowledge pending/scientific not_run。

实际CLI与libtest两个release Cargo原命令的PID/exit0/stdout/stderr、130文件ID/mtime/字节前后原库存、真实CargoJSON profile3/debug_assertions=false、两个build-script FP及CLI探针重新核对；完整两个ELF原体读取并核SHA/长度，130个当前Root原文件与编译原ZIP成员CRC/SHA/长度一致。此两构建是build与libtest no-run，不把它们写成完整Linux Rust测试通过。

三种主矩阵中的新协调点单独核对：accepted场景在真实B succeeded/Known700/full200/seal后release原A，实际服务器接收后4.249936ms请求SIGKILL并wait(-9)；A原MaySend无response/transport/final receipt，恢复保持R8310并只用新UUID。retry/elapsed场景真实A完整429、原1000ms retry COMMIT后持有，B真实succeeded已不再追加终态，kill在原not-before内；B同key/plan/receipt/files保持精确相同且额外BHTTP为0。elapsed原1700ms等待有单独原记录，原1500ms期限不重启，A不再HTTP。

执行者的当前checker包真实4050 ZIP成员独立全CRC/SHA/长度核对，其中4049对应普通original文件，逐项实际ID/mtime/字节与manifest相等；另1个`prior-release-failure-reference.json`是manifest的embedded_reference明确声明的990B生成引用，其SHA/长度与三份旧153f失败包真实来源pin独立相等。原生成器是inline工具代码，没有另存独立生成脚本；后来来源说明不冒充原脚本。首peer collector错误假设4050都有普通original行而assert失败，原脚本/stdout/stderr保留，修正版按实际schema区分后通过，原产品和包未变化。

执行者三份额外dual target的18CLI/3driver/8HTTP仍是独立scope，未加进主矩阵计数。本审查读取其归档字节一致性；主预算全fold统计只包含正式62组。

审查包保存自身代码、实际结果、必要raw和完整130源码ZIP。两个ELF原体保留于固定release pair目录，checker4050 ZIP保留于其独立原目录；本小包绑定它们的完整SHA/长度/实际来源，明确不重复包含两大ELF或整个checker包。已有所有旧成功与失败包保持不变。
