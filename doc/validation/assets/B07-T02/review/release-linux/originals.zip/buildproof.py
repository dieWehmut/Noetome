from pathlib import Path
import hashlib
import json
import stat
import zipfile

ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PAIR = ROOT / '.artifacts/b07-t02-linux-release-pair-01-20261107'
FP = 'e3da041f1c0862483d352f5821fd7941bd9e633012fb1c8f22723eb47ab49b5f'
observed = {}


def read(p):
    s = p.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
    body = p.read_bytes()
    t = p.lstat()
    assert (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) == (t.st_dev, t.st_ino, t.st_size, t.st_mtime_ns)
    pin = {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body),
           'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns}
    assert observed.setdefault(str(p), pin) == pin
    return body


def copy(p, name):
    body = read(p)
    target = OUT / name
    assert not target.exists()
    target.write_bytes(body)
    return body


pair = json.loads(copy(PAIR / 'actual.json', 'release-pair-original-actual.json'))
assert pair['actual_cli_fingerprint'] == FP
commands = []
for label, directory in [('cli', 'b07-t02-root-release-build-01-20261107'),
                          ('driver', 'b07-t02-root-release-driver-01-20261107')]:
    base = ROOT / '.artifacts' / directory
    actual = json.loads(copy(base / 'actual.json', f'release-{label}-build-actual.json'))
    launch = json.loads(copy(base / 'launch.json', f'release-{label}-build-launch.json'))
    before = json.loads(copy(base / 'source-before.json', f'release-{label}-build-source-before.json'))
    after = json.loads(copy(base / 'source-after.json', f'release-{label}-build-source-after.json'))
    assert before == after and len(before) == actual['source_count'] == 130
    assert actual['exit_code'] == 0 and actual['source_delta'] == {}
    assert '--release' in actual['argv'] and '--locked' in actual['argv'] and '--offline' in actual['argv']
    if label == 'driver':
        assert '--no-run' in actual['argv']
    stdout = copy(base / 'stdout.bin', f'release-{label}-build-stdout.bin')
    stderr = copy(base / 'stderr.bin', f'release-{label}-build-stderr.bin')
    for raw, expected in [(stdout, actual['stdout']), (stderr, actual['stderr'])]:
        assert hashlib.sha256(raw).hexdigest() == expected['sha256'] and len(raw) == expected['byte_length']
    rows = [json.loads(line) for line in stdout.decode().splitlines()]
    build_fps = {value for row in rows if row.get('reason') == 'build-script-executed'
                 for name, value in row.get('env', []) if name == 'NOETOME_RUN_COMPILER_FINGERPRINT'}
    assert build_fps == {FP}
    artifacts = [v for v in rows if v.get('reason') == 'compiler-artifact' and v.get('executable')
                 and v['target']['name'] == ('noetome' if label == 'cli' else 'noetome_cli')]
    assert len(artifacts) == 1
    record = artifacts[0]
    assert record['profile']['opt_level'] == '3' and record['profile']['debug_assertions'] is False
    assert record['profile']['test'] is (label == 'driver')
    assert record['executable'] == pair['original_cli' if label == 'cli' else 'original_test_driver']
    commands.append({'kind': label, 'actual_argv': actual['argv'], 'PID': actual['pid'], 'exit_code': 0,
                     'actual_elapsed_seconds': actual['elapsed_seconds'], 'source_count': 130,
                     'actual_full_source_ID_mtime_bytes_before_after_equal': True,
                     'actual_Cargo_build_script_FP': sorted(build_fps), 'actual_artifact': record,
                     'tests_executed_by_build_command': False})
archive = PAIR / 'source-originals.zip'
copy(archive, 'release-compiled-source130-originals.zip')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 130
    for name in z.namelist():
        body = z.read(name)
        assert hashlib.sha256(body).hexdigest() == before[name]['sha256'] and len(body) == before[name]['byte_length']
for filename, key in [('noetome', 'cli'), ('request-test-driver', 'test_driver')]:
    body = read(PAIR / filename)
    assert body.startswith(b'\x7fELF') and hashlib.sha256(body).hexdigest() == pair[key]['sha256']
    assert len(body) == pair[key]['byte_length']
probe = json.loads(copy(PAIR / 'cli-probe.stdout.bin', 'release-cli-probe-stdout.bin'))
copy(PAIR / 'cli-probe.stderr.bin', 'release-cli-probe-stderr.bin')
copy(PAIR / 'cli-probe.launch.json', 'release-cli-probe-launch.json')
assert probe['compiler_fingerprint'] == FP and pair['cli_probe_exit_code'] == 0
result = {'status': 'passed_actual_current_release_pair_build_source_and_ELF_readback',
          'actual_Cargo_commands': commands, 'actual_CLI_probe_fingerprint': FP,
          'actual_source_ZIP130_CRC_SHA_length_equal': True,
          'actual_selected_ELF_complete_bodies': {n: observed[str(PAIR / n)] for n in ['noetome', 'request-test-driver']},
          'selected_program_bodies_not_copied_into_reviewer_package': True,
          'driver_runtime_source_FP': 'All actual33 driver PID handshakes independently checked by current main audit against this FP.',
          'scope': 'Actual release CLI and libtest no-run builds/probe; full Linux Rust not run and not inferred. Native remains separate.',
          'auditor_product_Cargo_HTTP_invocations': 0, 'observed_originals': observed}
(OUT / 'release-build-source-proof.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'status': result['status'], 'actualSHA': hashlib.sha256((OUT / 'release-build-source-proof.json').read_bytes()).hexdigest(),
                  'byte_length': (OUT / 'release-build-source-proof.json').stat().st_size}))
