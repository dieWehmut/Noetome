from pathlib import Path
import hashlib
import json
import stat
import zipfile

PEER = Path('/home/lyinn/project/Noetome/.artifacts/b07-t02-linux-release-final-independent-checker-20261107')
OUT = Path(__file__).parent


def read(p):
    s = p.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1
    b = p.read_bytes()
    t = p.lstat()
    assert (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) == (t.st_dev, t.st_ino, t.st_size, t.st_mtime_ns)
    return b, {'sha256': hashlib.sha256(b).hexdigest(), 'byte_length': len(b),
               'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns}


manifest = json.loads(read(PEER / 'manifest.json')[0])
actual = json.loads(read(PEER / 'actual.json')[0])
archive = PEER / 'originals.zip'
before = read(archive)[1]
members = manifest['members']
embedded = manifest['embedded_reference']
assert len(members) == 4049 and actual['members'] == 4050
assert before['sha256'] == '629f09ab3212bddc00eef3905e21b6bceefd374e4432fd73b084047828a7e48e'
records = []
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 4050
    assert set(z.namelist()) == {r['member'] for r in members} | {embedded['name']}
    for row in members:
        body = z.read(row['member'])
        original, observed = read(Path(row['original']))
        assert body == original and observed == row['pin']
        records.append({'member': row['member'], 'sha256': observed['sha256'], 'byte_length': len(body),
                        'ordinary_original_ID_mtime_bytes_equal': True})
    generated = z.read(embedded['name'])
    assert hashlib.sha256(generated).hexdigest() == embedded['sha256'] and len(generated) == embedded['byte_length']
    reference = json.loads(generated)
    old_root = Path(reference['prior_failed_release01_package'])
    assert old_root == Path('/home/lyinn/project/Noetome/.artifacts/b07-t02-linux-release-readonly-race-history-20261107')
    assert set(reference['files']) == {'originals.zip', 'manifest.json', 'actual.json'}
    source_records = []
    for name, expected in reference['files'].items():
        body, observed = read(old_root / name)
        assert observed == expected
        source_records.append({'original': str(old_root / name), 'actual_pin': observed})
    records.append({'member': embedded['name'], 'sha256': embedded['sha256'], 'byte_length': len(generated),
                    'generated_reference': True, 'declared_in_manifest_embedded_reference': True,
                    'actual_source_files_verified': source_records,
                    'standalone_original_generated_file_exists': False,
                    'generation_provenance': 'Pythonowner confirms inline functions.exec Python builder in conversation; no standalone original builder script was saved.'})
after = read(archive)[1]
assert before == after and before['sha256'] == actual['zip']['sha256']
result = {'producer': 'independent_current_release_peer_archive_full_readback', 'status': 'passed',
          'archive_before': before, 'archive_after': after, 'manifest': read(PEER / 'manifest.json')[1],
          'member_count': len(records), 'ordinary_original_member_count': len(members), 'generated_reference_member_count': 1,
          'all_4050_member_CRC_SHA_length_passed': True, 'all_4049_ordinary_original_ID_mtime_byte_equal': True,
          'generated_reference_provenance_separately_verified': True, 'records': records,
          'collector_history': 'Attempt01 incorrectly assumed every ZIP member had an ordinary source row. Its script/stdout/stderr remain preserved; this is a collector schema assumption failure, not a product or package defect.',
          'no_product_HTTP_Cargo_invocations_by_auditor': True}
(OUT / 'peer-archive-readback.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'status': result['status'], 'members': len(records), 'ordinary': len(members), 'generated': 1,
                  'peer_archive_sha256': before['sha256'], 'actualSHA': hashlib.sha256((OUT / 'peer-archive-readback.json').read_bytes()).hexdigest(),
                  'length': (OUT / 'peer-archive-readback.json').stat().st_size}))
