$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-09-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-09-20261107' --snapshot-sha256 '76d627212e7760e8b39c650aa620a1960ecdb8234cd6139bd3f26adbe40f77ad' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '28e44ee58d3580e8528d82ba9d79d5bcf14cd7575f766589ff3e6c241f26f6af' --executor-sha256 'c574120ec94b7d90e87687004a2c3be872fdd3dfcb69cd633c9a99b69549a9cb'
exit $LASTEXITCODE
