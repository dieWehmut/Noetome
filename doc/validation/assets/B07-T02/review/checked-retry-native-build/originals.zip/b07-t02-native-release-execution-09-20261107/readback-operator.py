"""Read only the selected release09 prepared inputs; never launch Native or Cargo."""
from pathlib import Path, PureWindowsPath
import hashlib
import io
import json
import os
import stat
import sys
import time
import types
import zipfile

ROOT = Path('/home/lyinn/project/Noetome')
OUT = ROOT / '.artifacts/b07-t02-native-release-execution-09-20261107'
BASE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-09-20261107')
EXE = ROOT / '.artifacts/b07-t02-release-builder-draft-09-20261107/executor.py'
EXE_PIN = {'sha256': 'c574120ec94b7d90e87687004a2c3be872fdd3dfcb69cd633c9a99b69549a9cb', 'byte_length': 27263}
RUNNER = ROOT / '.artifacts/b07-t02-windows-runner-draft-03-20261107/runner.py'
RUNNER_PIN = {'sha256': '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1', 'byte_length': 43402}
PRIOR = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-02-20261107')
CACHE = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-01-20261107/build-target')
FREEZE = 'checked-retry-release09'
CONTROL_NAMES = ('snapshot.json', 'source-originals.zip', 'runner.py', 'launch-native.ps1',
                 'precise-source-scopes.json', 'rust-dependency-subset.json', 'prepared-source.json', 'release-executor.py')
META_KEYS = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def pin(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def ordinary_components(path):
    for item in (path, *path.parents):
        info = item.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not (getattr(info, 'st_file_attributes', 0) & 0x400),
                'linked/reparse path before selected read: ' + str(item))


def file_meta(info):
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1
            and not (getattr(info, 'st_file_attributes', 0) & 0x400),
            'selected original must be an ordinary single-link file')
    return {name: getattr(info, name) for name in META_KEYS}


def metadata(path):
    ordinary_components(path)
    return file_meta(path.lstat())


def read_guarded(path, wanted=None, baseline=None):
    """Path-before, actual-opened, after-read and independent-current handles agree.

    This process runs under selected Home Python on /mnt/d. Its actual fstat
    identities are WSL readback observations, not later Native runtime IDs.
    Both opened handles stay live until the last path/component comparison.
    """
    before = metadata(path)
    require(baseline is None or before == baseline, 'fixed original metadata changed before read: ' + str(path))
    flags = os.O_RDONLY | getattr(os, 'O_BINARY', 0) | getattr(os, 'O_NOFOLLOW', 0)
    first = os.open(path, flags)
    current_fd = None
    try:
        opened = file_meta(os.fstat(first))
        require(opened == before, 'actual opened identity/time/length differs: ' + str(path))
        chunks = []
        remaining = before['st_size'] + 1
        while remaining:
            body = os.read(first, min(1024 * 1024, remaining))
            if not body:
                break
            chunks.append(body)
            remaining -= len(body)
        raw = b''.join(chunks)
        require(len(raw) == before['st_size'], 'selected file length changed during bounded read: ' + str(path))
        after = file_meta(os.fstat(first))
        ordinary_components(path)
        current_fd = os.open(path, flags)
        current = file_meta(os.fstat(current_fd))
        path_after = metadata(path)
        require(before == opened == after == current == path_after,
                'selected original identity/mtime/length/nlink changed across actual handles: ' + str(path))
        if wanted is not None:
            require(pin(raw) == wanted, 'selected original SHA/length differs: ' + str(path))
        return raw, {'metadata_before': before, 'actual_opened_fstat': opened,
                     'after_read_fstat': after, 'actual_current_fstat': current,
                     'path_after': path_after, 'full_byte_pin': pin(raw),
                     'all_equal': True, 'observer': 'Home selected Python fstat; not Native runtime ID'}
    finally:
        if current_fd is not None:
            os.close(current_fd)
        os.close(first)


def relative_name(name):
    require(isinstance(name, str) and name and not name.startswith(('/', '\\'))
            and '\\' not in name and ':' not in name
            and not any(part in {'', '.', '..'} for part in name.split('/')),
            'unsafe prepared relative source name')
    return name


def decoded(raw):
    return json.loads(raw)


def trusted_module(raw, path, name):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def native_path(path):
    return str(PureWindowsPath('D:/') / path.relative_to(Path('/mnt/d')).as_posix())


def expected_scope_maps(files):
    names = set(files)
    direct = sorted(name for name in names if name in {'Cargo.toml', 'Cargo.lock', 'crates/noetome-cli/Cargo.toml', 'crates/noetome-cli/build.rs'}
                    or name.startswith('crates/noetome-cli/src/') and name.endswith('.rs'))
    cli = sorted(set(direct) | {name for name in names if name.startswith('crates/noetome-cli/tests/') and name.endswith('.rs')})
    workspace = sorted(name for name in names if name.startswith('crates/') and name.endswith('.rs'))
    conservative = sorted(name for name in names if name.startswith(('crates/', 'apps/', 'fixtures/', 'sidecars/'))
                          or name in {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'scripts/cargo_local.ps1'})
    return {'direct_build_rs_input_files': {n: files[n] for n in direct},
            'cli_cargo_and_test_files': {n: files[n] for n in cli},
            'all_workspace_rust_files': {n: files[n] for n in workspace},
            'conservative_rust_dependency_files': {n: files[n] for n in conservative}}, cli, workspace


def current_selected_names(old, baseline_names):
    # Consume the already guarded, safe, subset-checked baseline key set. The
    # original source_names helper would reopen that JSON before validating
    # its relative keys. No file path from untrusted JSON is touched here.
    names = set(baseline_names)
    names.update(old.current_source_names(ROOT))
    names.update(old.DOCS)
    for area in ('doc/technical', 'doc/standards', 'doc/execution', 'doc/requirements'):
        names.update(path.relative_to(ROOT).as_posix() for path in (ROOT / area).glob('*.md') if path.is_file())
    names.update(('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'AGENTS.md', '.gitattributes', '.gitignore'))
    return sorted(relative_name(name) for name in names if not name.startswith('target/'))


def selected_source_read(root, names, expected):
    observed, identities = {}, {}
    for name in names:
        raw, proof = read_guarded(root / relative_name(name), expected[name])
        observed[name] = pin(raw)
        identities[name] = proof['metadata_before']
    return observed, identities


def selected_source_end(root, names, expected, identities):
    observed = {}
    for name in names:
        raw, _ = read_guarded(root / name, expected[name], identities[name])
        observed[name] = pin(raw)
    return observed


def exact_native_copy_names():
    repo = BASE / 'repo'
    ordinary_components(repo)
    names = []
    for path in repo.rglob('*'):
        info = path.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not (getattr(info, 'st_file_attributes', 0) & 0x400),
                'linked/reparse member in the fresh prepared copy')
        if stat.S_ISREG(info.st_mode):
            require(info.st_nlink == 1, 'prepared source copy has a hardlink')
            names.append(path.relative_to(repo).as_posix())
        else:
            require(stat.S_ISDIR(info.st_mode), 'unexpected non-file object in prepared source copy')
    return sorted(names)


def check_inputs():
    exe_raw, exe_proof = read_guarded(EXE, EXE_PIN)
    runner_raw, runner_proof = read_guarded(RUNNER, RUNNER_PIN)
    release = trusted_module(exe_raw, EXE, 'reviewed_release09_readback')
    old = trusted_module(runner_raw, RUNNER, 'reviewed_original_source_names')
    prepare_raw, _ = read_guarded(OUT / 'prepare-actual.json')
    prepare = decoded(prepare_raw)
    require(prepare['exit_code'] == 0 and prepare['actual_wait_closed']
            and prepare['original_source_names_ID_mtime_size_singlelinks_equal']
            and prepare['source_guard_error'] is None,
            'prepare actual wait/source guards have not closed successfully')

    # Capture all eight fixed actual metadata records before decoding any D input.
    initial_controls = {name: metadata(BASE / name) for name in CONTROL_NAMES}
    raw_controls, control_proofs = {}, {}
    for name in CONTROL_NAMES:
        raw_controls[name], control_proofs[name] = read_guarded(BASE / name, baseline=initial_controls[name])
    frozen = decoded(raw_controls['snapshot.json'])
    prepared = decoded(raw_controls['prepared-source.json'])
    require(frozen['schema_version'] == 1 and frozen['producer'] == 'b07_t02_native_source_freeze'
            and frozen['source_root'] == str(ROOT) and frozen['freeze_label'] == FREEZE,
            'wrong prepared source root/producer/freeze identity')
    require(prepared['status'] == 'frozen_release_build_not_executed', 'prepared status must not claim build execution')
    names = sorted(relative_name(name) for name in frozen['files'])
    require(len(names) == len(set(names)) == prepared['source_count'] == 2056, 'selected prepared source inventory differs')
    selection_path = ROOT / 'doc/validation/assets/B06V-T03/windows-python/final/source-before.json'
    selection_raw, selection_proof = read_guarded(selection_path)
    selection_names = decoded(selection_raw)
    require(isinstance(selection_names, dict)
            and {relative_name(name) for name in selection_names} <= set(names),
            'selected prior inventory contains a path outside the prepared input set')
    require(current_selected_names(old, selection_names) == names, 'current Home selected source names differ from sealed inventory')
    require(exact_native_copy_names() == names, 'fresh native source copy has a missing/unknown file')
    expected_controls = {'snapshot.json': prepared['snapshot'], 'source-originals.zip': prepared['source_archive'],
                         'runner.py': prepared['runner'], 'launch-native.ps1': prepared['launcher'],
                         'precise-source-scopes.json': prepared['precise_scopes'],
                         'rust-dependency-subset.json': prepared['rust_dependencies'],
                         'release-executor.py': prepared['release_executor']}
    require(set(expected_controls) == set(CONTROL_NAMES) - {'prepared-source.json'}, 'prepared control inventory differs')
    for name, wanted in expected_controls.items():
        require(pin(raw_controls[name]) == wanted, 'prepared control pin differs: ' + name)
    require(pin(raw_controls['runner.py']) == RUNNER_PIN and raw_controls['runner.py'] == runner_raw,
            'prepared original runner differs from reviewed Home body')
    require(pin(raw_controls['release-executor.py']) == EXE_PIN and raw_controls['release-executor.py'] == exe_raw,
            'prepared release09 executor differs from reviewed Home body')
    for name, wanted in release.SOURCE_PINS.items():
        require(frozen['files'].get(name) == wanted, 'four-source frozen SHA/length differs: ' + name)

    home_before, home_meta = selected_source_read(ROOT, names, frozen['files'])
    native_before, native_meta = selected_source_read(BASE / 'repo', names, frozen['files'])
    require(home_before == native_before == frozen['files'], 'full Home/native source bytes differ from sealed input')
    save(OUT / 'readback-source-before.json', home_before)
    save(OUT / 'readback-source-Home-metadata-before.json', home_meta)
    save(OUT / 'readback-source-native-copy-metadata-before.json', native_meta)

    archive_members = {}
    aux = ('snapshot.json', 'rust-dependency-subset.json', 'precise-source-scopes.json', 'runner.py', 'release-executor.py')
    with zipfile.ZipFile(io.BytesIO(raw_controls['source-originals.zip'])) as archive:
        require(archive.testzip() is None, 'source ZIP CRC error')
        require(len(archive.namelist()) == len(set(archive.namelist())) == 2061,
                'source ZIP duplicates or wrong member count')
        require(set(archive.namelist()) == {'repo/' + name for name in names} | set(aux),
                'source ZIP full selected inventory or five auxiliary members differ')
        for name in names:
            raw = archive.read('repo/' + name)
            require(pin(raw) == frozen['files'][name], 'archived full source pin differs: ' + name)
            archive_members['repo/' + name] = pin(raw)
        for name in aux:
            raw = archive.read(name)
            require(raw == raw_controls[name], 'archived auxiliary control bytes differ: ' + name)
            archive_members[name] = pin(raw)
    save(OUT / 'source-archive-inventory.json', archive_members)

    maps = decoded(raw_controls['precise-source-scopes.json'])
    expected_maps, cli, workspace = expected_scope_maps(frozen['files'])
    for key, expected in expected_maps.items():
        require(maps[key] == expected, 'complete named scope differs: ' + key)
    require(maps['cli_scope_only'] == sorted(set(cli) - set(workspace))
            and maps['workspace_scope_only'] == sorted(set(workspace) - set(cli)),
            'two similarly sized source scope differences are not accurately recorded')
    subset = decoded(raw_controls['rust-dependency-subset.json'])
    require(subset['files'] == expected_maps['conservative_rust_dependency_files']
            and len(subset['files']) == prepared['rust_dependency_count'], 'conservative named subset differs')

    ordinary_components(CACHE)
    cache_meta = CACHE.lstat()
    require(stat.S_ISDIR(cache_meta.st_mode), 'physical cache is not the selected ordinary directory')
    require(native_path(CACHE) == release.CACHE_TARGET_NATIVE
            and frozen['compiler_cache_target'] == frozen['release_cache_physical_target'] == native_path(CACHE)
            and frozen['release_cache_evidence_root'] == native_path(PRIOR)
            and frozen['cache_prior_native_base'] == str(CACHE.parent),
            'physical release01 cache and independent closed release02 evidence are not exact')
    require(set(frozen['release_cache_evidence']) == set(release.CACHE_RECEIPT_NAMES)
            and len(release.CACHE_RECEIPT_NAMES) == 7, 'seven cached original receipt names differ')
    prior_raw, prior_proofs = {}, {}
    for name in release.CACHE_RECEIPT_NAMES:
        wanted = frozen['release_cache_evidence'][name]
        if name in release.PRIOR_FIXED_PINS:
            require(wanted == release.PRIOR_FIXED_PINS[name], 'fixed old receipt pin differs: ' + name)
        prior_raw[name], prior_proofs[name] = read_guarded(PRIOR / name, wanted)
    primary = decoded(prior_raw['release-build-receipt.json'])
    outer = decoded(prior_raw['outer-native-result.json'])
    cache = decoded(prior_raw['compiler-cache-scope.json'])
    require(primary['compiler_cache_scope']['receipt'] == release.PRIOR_FIXED_PINS['compiler-cache-scope.json']
            and cache['target'] == native_path(CACHE) and cache['previous_test_results_reused'] is False,
            'fixed old primary does not bind this physical cache receipt')
    require(primary['status'] == 'passed_release_build_and_probes_only'
            and primary['source_before_after_equal'] and primary['previous_test_results_reused'] is False
            and outer['exit_code'] == 0 and outer['worktree_before_after_equal']
            and outer['worktree_named_inventory_equal'] and outer['control_originals_equal'],
            'fixed prior actual Cargo/source/outer closure is not valid')
    command_rows = {row['name']: row for row in primary['commands']}
    for name in ('release-cli-build', 'release-driver-build'):
        row = decoded(prior_raw[name + '.json'])
        require(row == command_rows[name] and row['exit_code'] == 0 and row['guard_error'] is None
                and row['source_before_after_equal'] and row['declared_build_assets_equal']
                and row['external_sentinel_before_after_equal'] and row['timed_out'] is False,
                'old actual Cargo row is not bound to fixed primary: ' + name)
    source_delta = release.check_source_delta(maps, decoded(prior_raw['precise-source-scopes.json']))
    require(source_delta == frozen['release_cache_source_delta'], 'exact two named source delta is not sealed accurately')
    for name, raw in prior_raw.items():
        repeated, _ = read_guarded(PRIOR / name, pin(raw), prior_proofs[name]['metadata_before'])
        require(repeated == raw, 'cached receipt bytes changed during readback: ' + name)

    def quote(value):
        return "'" + value.replace("'", "''") + "'"
    launch = "$ErrorActionPreference='Stop'\n$env:PSExecutionPolicyPreference='Bypass'\n& " + quote(old.PDF_PYTHON)
    launch += ' -X utf8 ' + quote(native_path(BASE) + '\\release-executor.py') + ' run --base ' + quote(native_path(BASE))
    for flag, name in (('snapshot', 'snapshot.json'), ('runner', 'runner.py'),
                       ('source-archive', 'source-originals.zip'), ('executor', 'release-executor.py')):
        launch += ' --' + flag + '-sha256 ' + quote(pin(raw_controls[name])['sha256'])
    require(raw_controls['launch-native.ps1'] == (launch + '\nexit $LASTEXITCODE\n').encode(),
            'launcher complete bytes do not contain the exact four external original hashes')

    require(current_selected_names(old, selection_names) == names, 'current Home source names changed during readback')
    require(exact_native_copy_names() == names, 'fresh native source copy inventory changed during readback')
    selection_again, _ = read_guarded(selection_path, pin(selection_raw), selection_proof['metadata_before'])
    require(selection_again == selection_raw, 'explicit prior source-name selection config changed during readback')
    home_after = selected_source_end(ROOT, names, frozen['files'], home_meta)
    native_after = selected_source_end(BASE / 'repo', names, frozen['files'], native_meta)
    require(home_before == home_after == native_before == native_after == frozen['files'],
            'full selected source bytes are not conserved before/after readback')
    save(OUT / 'readback-source-after.json', home_after)
    for name in CONTROL_NAMES:
        repeated, proof = read_guarded(BASE / name, pin(raw_controls[name]), initial_controls[name])
        require(repeated == raw_controls[name], 'fixed original control bytes changed: ' + name)
        control_proofs[name]['end_of_readback'] = proof
        (OUT / ('prepared-' + name)).write_bytes(repeated)
    read_guarded(EXE, EXE_PIN, exe_proof['metadata_before'])
    read_guarded(RUNNER, RUNNER_PIN, runner_proof['metadata_before'])
    return {'status': 'passed_prepared_inputs_only', 'source_count': 2056, 'archive_member_count': 2061,
            'all_CRC_SHA_lengths': True, 'all_archived_source_matches_native_copy_and_current_Home': True,
            'all_five_archived_aux_match_controls': True,
            'source_whole_bytes_and_names_before_after_equal': True,
            'source_Home_and_native_copy_actual_ID_mtime_nlink_before_after_equal': True,
            'eight_control_metadata_before_after_equal': True,
            'eight_control_actual_fstat_before_open_after_current_and_full_bytes': control_proofs,
            'all_four_complete_named_scope_maps_equal': True,
            'precise_scope_counts': {key: len(value) for key, value in expected_maps.items()},
            'four_current_source_pins': release.SOURCE_PINS,
            'seven_cache_receipts_full_bytes_fixed_pins_and_actual_metadata_equal': True,
            'seven_cache_receipts': {name: pin(raw) for name, raw in prior_raw.items()},
            'snapshot': pin(raw_controls['snapshot.json']), 'source_archive': pin(raw_controls['source-originals.zip']),
            'executor': EXE_PIN, 'source_delta': source_delta,
            'physical_cache': native_path(CACHE), 'independent_cache_evidence_root': native_path(PRIOR),
            'identity_observer': 'actual Home selected Python /mnt/d readback fstat; not Native runtime identity',
            'not_a_Native_Runtime_Identity_receipt': True,
            'source_name_selection_config': {'path': str(selection_path), 'pin': pin(selection_raw),
                                            'only_safe_relative_keys_within_selected2056': True},
            'read_scope': 'selected2056 Home/native-copy inputs,8controls,7prior receipts,selected cache-directory metadata,explicit Home prior-name selection config',
            'Native': 'not_run', 'Cargo': 'not_run', 'HTTP': 'not_run'}


def main():
    started = time.time_ns()
    try:
        result = check_inputs()
        code = 0
    except Exception as error:
        result = {'status': 'failed_prepared_input_readback', 'error_type': type(error).__name__,
                  'error': str(error), 'Native': 'not_run', 'Cargo': 'not_run', 'HTTP': 'not_run'}
        code = 1
    result.update({'schema_version': 1, 'producer': 'release09_standalone_prepared_input_readback',
                   'PID': os.getpid(), 'parent_PID': os.getppid(), 'exit_code': code,
                   'started_utc_ns': started, 'finished_utc_ns': time.time_ns()})
    save(OUT / 'prepared-input-readback.json', result)
    print(json.dumps({'status': result['status'], 'PID': result['PID'], 'exit_code': code,
                      'receipt': str(OUT / 'prepared-input-readback.json')}, ensure_ascii=False), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
