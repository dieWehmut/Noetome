"""Save current-source global-after reader before running it."""
from pathlib import Path
import ast

OUT = Path(__file__).parent
OLD = OUT.parent / 'b07-t02-independent-linux-shared-header-current-review-20261107'
source = (OLD / 'global_after.py').read_text()
mapping = ast.literal_eval(next(node.value for node in ast.parse((OUT / 'prepare_readers.py').read_text()).body
                               if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'replacements' for t in node.targets)))
for before, after in mapping.items():
    source = source.replace(before, after)
source = source.replace('15185', '15184').replace('3792', '3796').replace('19022', '19025')
source = source.replace("'budget_module': 42", "'budget_module': 47")
source = source.replace('Frozen historical b393/Store2e97/FPcb1378', 'Current frozen e4/Store57c1/FPcb1378')
source = source.replace('This is not new e4/57c1 helper acceptance or Windows main62 acceptance.', 'This is current Linux acceptance of e4/57c1 only; Windows main62 is separate and not proved here.')
ast.parse(source)
with (OUT / 'global_after.py').open('x') as stream:
    stream.write(source)
print('Current global-after reader saved before execution.')
