"""Save source-specific closed-original auditors before executing any reader."""
from pathlib import Path
import ast

OUT = Path(__file__).parent
OLD = OUT.parent / 'b07-t02-independent-linux-shared-header-current-review-20261107'
replacements = {
    'shared-header': 'registered-identity',
    'shared_header': 'registered_identity',
    'Shared-header': 'Registered-identity',
    'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c': 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e',
    '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184': '57c1d73bb103ea2d94fa5ea015d86b1d81e77525ed631f721fbbfcd1ae388646',
    '89136b36bc30a77c5e7a1a54fd480c8d06be89e060377f1482954fbed12433b0': 'cb137897b122411e02bf42f67ad1484d8a77fd3efde62a8d402baa3f207ebcc4',
    '3ff0d5211fbe7f119302387e1f2d36a3e5b9a5865ad70280f50c3c43be4216ef': '45cae7385a3302fdf2e9f56f392d49be0e0d4b8cea7818c47222f773c8a1a826',
    '891': 'cb1378',
    'b393/Store2e97': 'e4/Store57c1',
    'sourceb393/Store2e97': 'sourcee4/Store57c1',
}
for name in ['full_python.py', 'public_archives.py']:
    source = (OLD / name).read_text()
    for before, after in replacements.items():
        source = source.replace(before, after)
    if name == 'full_python.py':
        source = source.replace('818751', '835867').replace('77.660', '84.496').replace('15185', '15184')
        source = source.replace('Historical passed ', 'Current frozen passed ')
        source = source.replace('later registered-identity optimization is not covered by this result', 'future source changes are not covered by this result')
        source = source.replace("'current_Root_optimized_modules_not_retested_here': ['request_run.rs', 'request_budget_store.rs']", "'current_Root_optimized_modules_not_retested_here': []")
    else:
        source = source.replace('2d308c9fe23cfa234bb2eb202bf00878a45bb2cb26ac9c4cb27f0bcc8c440072', '3cba9df8a06625216accb3a76a27c8860ea55732b0f7269102026b965731d949')
        source = source.replace('847025', '850048').replace('720437', '722613')
        source = source.replace("== 42", "== 47").replace("'module_actual_passed': 42", "'module_actual_passed': 47")
        source = source.replace('raw_42_unique_passed_test_rows', 'raw_47_unique_passed_test_rows')
        source = source.replace("assert re.findall(r'^test result: (.+)$', stdout, re.M) == ['ok. 42 passed; 0 failed; 0 ignored; 0 measured; 476 filtered out; finished in 1.77s']", "summary = re.findall(r'^test result: ok\\. (\\d+) passed; (\\d+) failed; (\\d+) ignored; (\\d+) measured; (\\d+) filtered out; finished in ([0-9.]+)s$', stdout, re.M)\n        assert len(summary) == 1 and summary[0][:5] == ('47', '0', '0', '0', '476')\n        item['actual_module_elapsed_seconds'] = float(summary[0][5])")
        source = source.replace('new registered-identity helper is not tested by these results', 'future source changes are not tested by these results')
    ast.parse(source)
    with (OUT / name).open('x') as stream:
        stream.write(source)
print('Two closed-current readers saved and AST parsed; no product execution.')
