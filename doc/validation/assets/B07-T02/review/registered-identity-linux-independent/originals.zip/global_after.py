"""Final cross-pack original readback after five closed frozen-cb1378 audits."""
from pathlib import Path
import hashlib
import json
import os
import stat
import sys

sys.dont_write_bytecode = True
REPO = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
PAIR = REPO / '.artifacts/b07-t02-linux-registered-identity-pair-01-20261107'
FLOW = REPO / '.artifacts/b07-t02-request-linux-registered-identity-full-01-20261107'
PYROOT = REPO / '.artifacts/b07-t02-linux-python-registered-identity-final-01-20261107'
EXPECTED = {}
OBSERVED = {}
REPORTS = {}

def read(path, previous=None):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink >= 1, str(path)
    shape = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_nlink)
    with path.open('rb') as stream:
        actual = os.fstat(stream.fileno())
        raw = stream.read()
        final = os.fstat(stream.fileno())
    after = path.lstat()
    assert shape(before) == shape(actual) == shape(final) == shape(after), str(path)
    pin = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
           'device': before.st_dev, 'inode': before.st_ino, 'mtime_ns': before.st_mtime_ns,
           'mode': before.st_mode, 'links': before.st_nlink}
    if previous:
        for key in ['sha256', 'byte_length', 'device', 'inode', 'mtime_ns', 'mode']:
            if key in previous:
                assert pin[key] == previous[key], (str(path), key)
        expected_links = previous.get('links', previous.get('nlink', 1))
        assert pin['links'] == expected_links, str(path)
    OBSERVED[str(path)] = pin
    return raw

def merge(path, pin):
    path = str(path)
    existing = EXPECTED.setdefault(path, dict(pin))
    for key in ['sha256', 'byte_length', 'device', 'inode', 'mtime_ns', 'mode']:
        if key in existing and key in pin:
            assert existing[key] == pin[key], (path, key)
    for key in ['sha256', 'byte_length', 'device', 'inode', 'mtime_ns', 'mode', 'nlink', 'links']:
        if key in pin:
            existing[key] = pin[key]

def report(name):
    path = OUT / name
    raw = read(path)
    REPORTS[name] = OBSERVED[str(path)]
    value = json.loads(raw)
    assert value['status'] == 'passed' or value['status'].startswith('passed_')
    return value

main = report('actual.json')
special = report('special-pair-and-source-readback02.json')
peer = report('peer-archive-readback.json')
python = report('full-python-source-and-archive-readback.json')
diagnostic = report('diagnostic-programs-source-readback.json')
for source, field in [(main, 'all_read_original_pins'), (special, 'original_actual_pins'),
                      (peer, 'all_original_read_pins'), (diagnostic, 'all_original_pins')]:
    for path, pin in source[field].items():
        merge(path, pin)
for row in python['public_original_member_readback']:
    merge(row['original'], row['pin'])
for row in python['snapshot_original_pins']:
    merge(PYROOT / 'repo' / row['name'], row['actual_pin'])
for name, pin in python['selected_pair'].items():
    merge(PAIR / name, pin)
negative_paths = {row['original'] for row in python['retained_negative_test_multilink_members']}

# Current copied public full-Python controls were each compared to their ZIP
# originals during the previous audit; reread those exact controls here too.
py_public = REPO / 'doc/validation/assets/B07-T02/linux-python-registered-identity'
materialized = json.loads(read(py_public / 'materialization-receipt.json'))
for name in ['originals.zip', 'manifest.json', 'receipt.json', 'links.json', 'materialization-receipt.json']:
    path = py_public / name
    read(path)
    merge(path, OBSERVED[str(path)])
for row in materialized['rows']:
    path = py_public / row['output']
    raw = read(path)
    original = REPO / '.artifacts' / row['member']
    assert hashlib.sha256(raw).hexdigest() == EXPECTED[str(original)]['sha256']
    assert len(raw) == EXPECTED[str(original)]['byte_length']
    merge(path, OBSERVED[str(path)])

for path, pin in EXPECTED.items():
    read(Path(path), pin)
    if OBSERVED[path]['links'] > 1:
        assert path in negative_paths, path

# Full matrix inventory is metadata-only for directories and deliberate links.
# No target of a symlink or unselected/private path is read.
inventory = main['full_original_inventory']['before']
current_inventory = {}
for path in FLOW.rglob('*'):
    s = path.lstat()
    current_inventory[str(path.relative_to(FLOW))] = {
        'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns,
        'mode': s.st_mode, 'byte_length': s.st_size}
assert set(current_inventory) == set(inventory)
for name, expected in inventory.items():
    assert current_inventory[name] == {k: expected[k] for k in current_inventory[name]}, name
for name, pin in REPORTS.items():
    read(OUT / name, pin)

result = {'producer': 'independent_frozen_cb1378_five_archive_global_after_readback', 'status': 'passed',
          'scope': 'Frozen historical e4/Store57c1/FPcb1378; all touched actual originals reread after all five archive/behavior checks. This is current Linux acceptance of e4/57c1 only; Windows main62 is separate and not proved here.',
          'archive_outer_members': {'diagnostic': 41, 'program_CLI': 2, 'program_driver': 2,
                                    'main_matrix': 3796, 'full_Python': 15184},
          'total_five_archives_outer_CRC_SHA_length_members': 19025,
          'nested_compiler_source_members_separately_verified': 130,
          'unique_ordinary_original_and_public_files_global_after_rechecked': len(EXPECTED),
          'full_matrix_inventory_entries_global_after_equal': len(inventory),
          'source130': 'exact frozen source-originals.zip and all five diagnostic source before/after maps; no current Root equality claimed',
          'actual_tests': {'budget_module': 47, 'matrix_groups': 62, 'strict_valid_budget_groups': 39,
                           'protection_refusal_groups': 23, 'ordinary_CLI': 364, 'driver': 33,
                           'unique_waited_PIDs': 397, 'HTTP_incoming_and_UUID_receipts': 70,
                           'SIGKILL_waited_negative9': 23, 'full_Python': 466, 'Python_passed': 444,
                           'Python_skipped': 22, 'Python_errors_or_failures': 0},
          'retained_negative_multilink_files_are_archive_evidence_not_accepted_inputs': sorted(negative_paths),
          'all_originals_actual_fstat_path_ID_mtime_links_full_bytes_global_after_equal': True,
          'new_product_HTTP_Cargo_Native_invocations': 0, 'real_model_or_paid_calls': 0,
          'full_Linux_Rust': 'not_run', 'current_Native_main62': 'not_run',
          'previous_independent_report_pins': REPORTS,
          'original_global_after_pins': {path: OBSERVED[path] for path in EXPECTED}}
path = OUT / 'global-after-five-archives-readback.json'
with path.open('x') as stream:
    stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'outer_archive_members': 19025, 'unique_global_after_files': len(EXPECTED),
                  'matrix_inventory_entries': len(inventory), 'actual_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'byte_length': path.stat().st_size}))
