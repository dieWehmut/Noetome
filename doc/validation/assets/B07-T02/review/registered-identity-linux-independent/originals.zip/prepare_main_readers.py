"""Save current stable matrix readers; no product calls or mutable originals."""
from pathlib import Path
import ast

OUT = Path(__file__).parent
OLD = OUT.parent / 'b07-t02-independent-linux-shared-header-current-review-20261107'
mapping = ast.literal_eval(next(node.value for node in ast.parse((OUT / 'prepare_readers.py').read_text()).body
                               if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'replacements' for t in node.targets)))
for name in ['audit.py', 'supplement.py', 'peer_archive.py']:
    source = (OLD / name).read_text()
    for before, after in mapping.items():
        source = source.replace(before, after)
    source = source.replace('bed3bcc92674a001a968dbeadfa46a3ee74a53ddc3bab3941d3d04a1181a4da9', '10cd542c0580fbb7c0166a31dff41a60ad507789b36fc817a9e8756136ba79c5')
    if name == 'peer_archive.py':
        source = source.replace('97e9503997c88f93ed59251e6322c2be1bcb3208834dfa07cea4da1c0759c137', '2d91df6335bc74dd574b0ee995a814741ceb22770aa539d9f9583da4bb9a4a89')
        source = source.replace('4945569', '5004745').replace('3791', '3795').replace('3792', '3796').replace('2480', '2504')
        source = source.replace("copy_receipt = json.loads(read(PUBLIC / 'copy-receipt.json'))", "copy_receipt = json.loads(read(PUBLIC / 'copy-receipt.json'))\ncopy_rows = [{**row, 'public_copy': row['destination'], 'public_pin': row['destination_pin']} for row in copy_receipt['files'].values()]")
        source = source.replace("copy_receipt['copies']", 'copy_rows')
        source = source.replace("assert PINS[str(builder)]['sha256'] == '70618b517bfe6eafa12c9f7a606ff11aaa14b7a39eade0d59a2ed2b46e073c72'", "assert PINS[str(builder)]['sha256'].startswith('afc49')\n    assert builder.is_relative_to(REPO / '.artifacts/b07-t02-linux-registered-identity-final-independent-checker-20261107')")
        source = source.replace('old release matrices retain their historical results, current native testing is separate', 'prior C2 Native failures retain their historical results; current Native testing is separate')
    ast.parse(source)
    with (OUT / name).open('x') as stream:
        stream.write(source)
print('Current matrix readers saved and AST parsed before execution.')
