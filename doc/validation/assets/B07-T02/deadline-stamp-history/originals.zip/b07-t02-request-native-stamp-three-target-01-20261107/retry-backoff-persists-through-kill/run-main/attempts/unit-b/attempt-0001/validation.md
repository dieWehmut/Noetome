# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9224efa5073f1fe95ccbfe73a09a737acddc1e44570a6a13fb1502382fb7d3d3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "71fd2378aae67cd167f9efb5672088a9f177fcff22ffe055ac3e41ff6cccc73e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c5f3df75d046ca444ee2cbc5a223f8e616393ee94729be797443c6ef31355912"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "d1b641fc90f50691e3cc78f7ec72a288898b2821413de57914b555d0fc3a9cc3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e20193559e8db55438d03bba739467f2e8a4f14658af39ee7646bd2954fb9bbd"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "669266a899423f2ffe017437cb81f7a1f23f59ca0cdbc1f06c396e6e2cc8ab07"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "854426b9-cb7f-446b-986c-9a3d30ccdff3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "73673f66-a6ce-4117-a62f-b4279911de13",
    "source_id": "2030f990-d973-4cc0-a9b0-2e15217c0f97",
    "version_id": "c841a277-5deb-4fd0-939b-4fb2c7505434"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63564/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "34dfff5b-8705-459a-bb5f-ee69dccbad47",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e20193559e8db55438d03bba739467f2e8a4f14658af39ee7646bd2954fb9bbd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
