# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e328f143001900c3c87d8bd51d8ee026207288c2df0c55500c988b71c84a5430"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1011c5eaea37674a4ba3f5310b110a6acb98cfb64a1275b83b19eef31d48b254"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "377e43077d258feff647c1624921aeeaad200152fe1a436ffe494c096f0aca3d"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "743bcaffd300f8e21a1a004d875977e184abb9b064869a9585df0e2107ab098a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "906d9c886d5919df1f0669f037b1cb6b76b8e00a8b772d8090b5c25bfa2b4067"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "20a95415520b4934693b338cb71e7001ef291ce160312c3d8a365da7ad8b4c2a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "aef50a38-abf2-4f1c-8791-e07289fcf489",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "04321e9f-ec4a-4805-a9d5-1f8d34a37b99",
    "source_id": "4532ae80-8a42-4986-981e-639127c60283",
    "version_id": "50ecc15f-d6b7-497e-944e-70618c3945ff"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63564/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fa1c4160-d615-4ea9-a7a8-b02c21f878db",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "906d9c886d5919df1f0669f037b1cb6b76b8e00a8b772d8090b5c25bfa2b4067"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
