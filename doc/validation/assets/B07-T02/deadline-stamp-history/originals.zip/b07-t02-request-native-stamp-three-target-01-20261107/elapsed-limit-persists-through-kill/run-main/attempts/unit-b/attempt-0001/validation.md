# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "157081fff6a3491be9a6620da2638554c765654081050373d4fea7980bb2107c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e552d266c087dc2fae03cddfea6af9caadf4780481dad025752b7b5c579ecbda"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fff9caa10bb25d96ba55e766f88b2347a01902c7a43e9c207f8ca3a0123d2454"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "b8c8a8825f965073092ae57562c0f7706dd939e48a7e36b66098917d98cfaf45"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "03d2d5c2567ba044dc33c09e0ef23403875895432f4a34fe574aa4efd038c323"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1861598d294d1c523898efa7e250df32c927431042e4e0fd14bae827ea3c71ff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "81667efe-0c01-4f03-9586-caaba868ce10",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "636bfec1-20c9-4c7c-893a-461bf82a129c",
    "source_id": "cc3bb68d-cecb-4fbe-b6be-5de8936927c2",
    "version_id": "fc856046-b5ed-4985-9951-94d2c8d612ab"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62538/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5be214d5-5a49-4ff8-9fbf-fde57dd8ede0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "03d2d5c2567ba044dc33c09e0ef23403875895432f4a34fe574aa4efd038c323"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
