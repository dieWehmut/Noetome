# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fdf925d02155db151638c8d42095e4a02ec3b04259c2d9c6d288b37759d7f8c4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f3a030d475d03aad919df2e63357fe46647bfeae3f3af95afb5f55da13b3481d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "037eeaa6a5e8a05268fbddbfe2447b0144d9a98b9684c591ed9bb1c932ce1c92"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "3408c57c5efe180a502cd52da6f74a82c3291bde5244265d1b6d7e7f37efe130"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ee9d1d5fce88a68ce57e9b5433fbbd14f836305fda86d19352f87891e5fb1635"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "33b156bb8ebb46fb7e117920d6ac837b11ddb77f2ceee1c4ed615b98f2c405c7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "844154b7-33cc-445e-a4ae-6c9b3ffcc54c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2627b85c-04b6-471c-b995-e9fe99654cb6",
    "source_id": "9cc3543e-811b-4c3b-9518-f7794aec9512",
    "version_id": "bb4db14c-8b31-475b-8cbb-b7c668bc1ebb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62913/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "811e7aa3-e3b9-4588-b076-3ae558aa2dcf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ee9d1d5fce88a68ce57e9b5433fbbd14f836305fda86d19352f87891e5fb1635"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
