"""Read-only existing Native4650 rows, final status and fresh-guard design.

No Native process, product, HTTP server, Cargo or test driver is started.
The actual failure and timestamps remain originals rather than revised gold.
"""
from pathlib import Path
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import sqlite3


HERE = Path(__file__).parent
ART = Path('/mnt/d/Noetome/.artifacts')
FP = '4650f37f3a11299739f8ace768ca6cb5317d3ecb6957d9d0edba26b9981fe680'
ORD = ART / 'b07-t02-request-native-stamp-ordinary-elapsed-01-20261107'
THREE = ART / 'b07-t02-request-native-stamp-three-target-01-20261107'


def pin(path):
    a = path.stat()
    raw = path.read_bytes()
    b = path.stat()
    fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_nlink)
    assert fields(a) == fields(b)
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
            'WSL_capture_device': b.st_dev, 'WSL_capture_inode': b.st_ino,
            'mtime_ns': b.st_mtime_ns, 'nlink': b.st_nlink}


def utc_ns(text):
    value = text[:-1]
    date, fraction = value.split('.') if '.' in value else (value, '')
    seconds = int(datetime.fromisoformat(date).replace(tzinfo=timezone.utc).timestamp())
    return seconds * 1_000_000_000 + int((fraction + '0' * 9)[:9])


def rows(root):
    path = root / 'elapsed-limit-persists-through-kill/budget/control/budget.sqlite'
    before = pin(path)
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
        originals = list(db.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
    assert before == pin(path)
    parsed = []
    previous = None
    for n, (seq, prior, raw, digest) in enumerate(originals, 1):
        assert seq == n and hashlib.sha256(raw.encode()).hexdigest() == digest
        if previous is not None:
            assert previous == prior
        r = json.loads(raw)
        assert r['sequence'] == seq and r['previous_sha256'] == prior
        parsed.append(r)
        previous = digest
    first = parsed[0]['event']['spec']
    deadline = utc_ns(next(u['deadline_utc'] for u in first['units'] if u['unit_id'] == 'unit-a'))
    clock = deadline - 1_500_000_000
    timeline = []
    for r in parsed:
        e = r['event']
        timeline.append({'sequence': r['sequence'], 'event_at_utc': r['at_utc'],
                         'kind': e['kind'], 'unit_id': e.get('unit_id', e.get('key', e.get('plan', {}).get('key', {})).get('unit_id')),
                         'ms_from_original_A_clock': (utc_ns(r['at_utc']) - clock) / 1_000_000,
                         'diagnostic': e.get('diagnostic'), 'receipt': e.get('receipt')})
    run = json.loads((root / 'actual.json').read_bytes())
    assert run['status'] == 'failed' and all(run['guards'].values())
    assert all('wait_action' in c and 'exit_code' in c for c in run['commands'])
    return {'root': str(root), 'database_pin_before_after_equal': before,
            'original_rows': parsed, 'timeline': timeline, 'original_A_clock_utc_ns': clock,
            'original_A_deadline_utc_ns': deadline, 'actual_execution': run}


def main():
    compiled = {p.name: pin(p) for p in sorted((HERE / 'compiled-source').iterdir())}
    assert compiled['request_run.rs']['sha256'] == '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc'
    assert compiled['request_budget_store.rs']['sha256'] == '4ca30cb98b1fd1af70264f4a6373d8946ec4478acf54461babb97e7c376a677e'
    ordinary, selected = rows(ORD), rows(THREE)
    assert any(r['event']['kind'] == 'retry_scheduled' for r in ordinary['original_rows'])
    assert not any(r['event']['kind'] == 'retry_scheduled' for r in selected['original_rows'])
    command = ordinary['actual_execution']['commands'][-1]
    assert command['number'] == 9 and command['exit_code'] == 3 and command['argv'][3] == 'status'
    stdout = ORD / 'commands/0009/stdout.bin'
    stderr = ORD / 'commands/0009/stderr.bin'
    assert {k: pin(stdout)[k] for k in ('sha256', 'byte_length')} == command['stdout']
    assert {k: pin(stderr)[k] for k in ('sha256', 'byte_length')} == command['stderr']
    output = json.loads(stdout.read_bytes())
    assert output['operation'] == 'api_run_status' and output['run_status'] == 'failed'
    assert output['compiler_fingerprint'] == FP
    assert b'REQUEST_RUN_FAILED' in stderr.read_bytes()
    observation = json.loads((ORD / 'elapsed-limit-persists-through-kill/actual-ordinary-retry-observation.json').read_bytes())
    kill = observation['actual_OS_force_kill_and_wait_receipt']
    assert kill['wait_action'] == 'actual_OS_force_kill_and_wait' and kill['exit_code'] != 0
    assert kill['kill_requested_utc_ns'] < observation['retry_at_utc_ns'] < observation['original_A_deadline_utc_ns']
    result = {
        'status': 'read_only_current4650_phase_status_and_fresh_guard_design_review_completed',
        'selected_native_FP': FP, 'compiled_originals': compiled,
        'ordinary_original_case': ordinary, 'selected_original_case': selected,
        'ordinary_status_diagnostic': {
            'actual_command_9_exit': 3, 'actual_stdout_pin': pin(stdout), 'actual_stderr_pin': pin(stderr),
            'actual_status': 'failed', 'compiled_source_rule': 'request_run.rs envelope sets REQUEST_RUN_FAILED when run.outcome Failed; main.rs api_run_result prints that failure and sets exit3.',
            'artifact_frozen_rule': '89d narrow.py final readonly status command hardcodes expected0. This first successful extra OS path reaches that previously unreached last assumption.',
            'classification': 'extra artifact final expected-exit mismatch, not incorrect Core status or failed budget preservation. Original extra overall remains failed; no request is rerun and no source/gold is changed.',
            'true_original_ordinary_kill_receipt': kill,
            'kill_before_due_ms': (observation['retry_at_utc_ns'] - kill['kill_requested_utc_ns']) / 1_000_000,
            'due_before_original_deadline_ms': (observation['original_A_deadline_utc_ns'] - observation['retry_at_utc_ns']) / 1_000_000,
        },
        'prepare_checked_readonly_design': {
            'actual_duplicate': 'Hooks.prepared first guard()->store.view/full witness, then Store.prepare starts a fresh BEGIN IMMEDIATE and repeats complete witness.',
            'bounded_change': 'Add a checked prepare entry accepting guard(view). Keep compatibility prepare as checked with a no-op external guard. New Hook builds the same exact plan, then calls checked prepare with the original RunGuard verify/inventory/input/stop checks inside that new transaction.',
            'preserve': ['Fresh lock/layout/schema/full load/history/witness before external guard; never caller-cached BudgetView.', 'Both new and idempotent prepare must run the current guard before any decision; same key different plan remains refused.', 'Original exact three API bytes/owner, original Run/unit/ancestor identity, Source/input pins, compiler/policy anchors and all request-plan checks remain.', 'One Prepared event COMMIT remains separate from Reserved and MaySend; the original request_body_original_sync callback remains after successful COMMIT.', 'Request-body/metadata reads before the in-transaction guard remain selected owned safe paths with existing handle/reparse/identity checks; failed guard produces no Prepared/charge/send.', 'No global or Run limit, deadline, Known/Unknown/NotSent rule or source expected is changed.'],
            'removed_duplicate': 'One pre-Prepared readonly full view/witness only. This is a static opportunity, not measured latency or a promised deadline fit.',
        },
        'fresh_completed_attempt_advance_readonly_design': {
            'actual_duplicate': 'After typed settled COMMIT/callback, next unit loop does RunGuard verify/inputs + readonly full store.view/witness/inventory, then schedule_retry_after repeats a fresh complete mutation transaction/witness/input verification.',
            'bounded_change': 'For the authoritative just-finished AttemptKey, a typed checked advance method can take one fresh BEGIN IMMEDIATE view, verify original final receipt/key and the original current guard, then decide exactly one retry-scheduled/unit-finished/no-change action. Resume/Prepared/Reserved/unsealed recovery paths can keep their existing separate guarded logic.',
            'clock_order': 'Acquire current writer/OS lock, layout/schema/load complete chain, full artifacts and all Run/Source/input/stop guards (including store verify_inputs) first; obtain the decision/event clock only afterwards. Never calculate retry from the prior readonly view, receipt elapsed_ms, callback at, pre-lock timestamp or saved schedule context. Preserve original absolute deadlines and exact1000/2000 minimum delay.',
            'preserve': ['Settled COMMIT and retry COMMIT are separate, with every original callback still after the corresponding actual new commit.', 'If the new helper returns an old idempotent schedule, do not emit a new event, charge or falsely repeat a commit callback.', 'Fresh current Run/global stopped/overrun flags, retry class usageNone-and-not-complete200, attempt/retryToken/deadline caps and source guards decide admission; B concurrency remains independent.', 'A typed key from the hook is not proof of a final receipt: require the fresh authoritative original receipt/key/files in the chain, rejecting absent/mutated/sealed forged bytes.', 'Failed-unit cleanup must preserve each genuine never-sent ReservedReleased event and callback separately before UnitFinished. Do not fold multiple durable phases into one event or refund MaySend Unknown.', 'After a selected hold/release, interruption or next dispatch, use the existing fresh checks again; do not reuse an old budget/snapshot across COMMIT/HTTP/lock release.'],
            'removed_duplicate': 'The separate readonly next-loop complete view/input pass before an equally strict fresh checked retry decision. No stronger performance claim is made.',
        },
        'needed_actual_regressions_before_acceptance': ['Guard-rejected Prepared/no-event idempotence and synchronized input/owner/plan forgeries remain refused/preserved.', 'Fresh retry transaction sees concurrent B overrun/terminal and actual changed input; no cached balance/classification bypass.', 'Hold immediately before/inside the guard past the original deadline and show no preguard clock credit, with no Author deadline reset.', 'Known700/full200 local timeout is still nonretry, five pure faults/REQUEST_INTERRUPTED rules stay exact, NotSent refund needs true sealed0 or never-MaySend proof.', 'All declared Prepared/Reserved/MaySend/transport/settled/retry/terminal interruption callbacks and same-key recovery remain real; new source requires new pair/FP/fresh roots/full matrix.'],
        'new_invocations': {'Native': 0, 'CLI': 0, 'HTTP': 0, 'Cargo': 0, 'test_driver': 0},
        'limitations': ['event.at occurs inside update before INSERT/COMMIT and is not measured function or COMMIT-finish time.', 'The selected elapsed B-first failure is safe NoFit, not an OS acceptance pass. Ordinary extra remains failed due to its final expectation, despite real prior kill/recovery evidence.', 'Proposals are source evaluation only. No implementation, timing improvement, Native62/fullRust/fullPython or production/scientific acceptance is inferred.'],
    }
    assert compiled == {p.name: pin(p) for p in sorted((HERE / 'compiled-source').iterdir())}
    with (HERE / 'actual.json').open('xb') as stream:
        stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
    print(json.dumps({'status': result['status'], 'event_rows': [len(ordinary['original_rows']), len(selected['original_rows'])], 'new_invocations': 0, 'actual': pin(HERE / 'actual.json')}))


if __name__ == '__main__':
    main()
