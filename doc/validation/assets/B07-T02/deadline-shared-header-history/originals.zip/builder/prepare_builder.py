"""Materialize a new standalone archive builder before it is executed."""
from pathlib import Path
import hashlib

HERE = Path(__file__).parent
OLD = HERE.parent / 'b07-t02-deadline-stamp-history-20261107/build_archive.py'
raw = OLD.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '19ac01848f5e321b1e7cc8578552cf0b100ea42b49cf13c95c69db36fcdca74b'
source = raw.decode('utf-8')
changes = [
    ('Capture already closed Native4650 originals', 'Capture already closed Nativec2f1 shared-header originals', 1),
    ("'b07-t02-request-native-stamp-ordinary-elapsed-01-20261107'", "'b07-t02-request-native-shared-header-ordinary-elapsed-01-20261107'", 1),
    ("'b07-t02-request-native-stamp-three-target-01-20261107'", "'b07-t02-request-native-shared-header-three-target-01-20261107'", 1),
    ("'b07-t02-native-stamp-normalized-source-01-20261107'", "'b07-t02-native-shared-header-normalized-source-01-20261107'", 1),
    ("'b07-t02-windows-release-pair-05-20261107'", "'b07-t02-windows-release-pair-06-20261107'", 1),
    ("'4650f37f3a11299739f8ace768ca6cb5317d3ecb6957d9d0edba26b9981fe680'", "'c2f1d498cb7c9da53a768c978ba01ea2b16837855a7a2304dc9cea63513f9e00'", 1),
    ('actual_counts(ORDINARY, 9, 0, 2, 1)', 'actual_counts(ORDINARY, 6, 0, 2, 0)', 1),
    ("'b07-t02-native-stamp-wrapper-01-20261107'", "'b07-t02-native-shared-header-wrapper-01-20261107'", 1),
    ("'b07-t02-native-stamp-normalize-stage-01-20261107'", "'b07-t02-native-shared-header-normalize-stage-01-20261107'", 1),
    ("'b07-t02-native-stamp-ordinary-stage-01-20261107'", "'b07-t02-native-shared-header-ordinary-stage-01-20261107'", 1),
    ("'b07-t02-native-stamp-three-stage-01-20261107'", "'b07-t02-native-shared-header-three-stage-01-20261107'", 1),
    ("HOME_REPO / '.artifacts/b07-t02-native-stamp-fresh-guard-readonly-review-20261107',", "HOME_REPO / '.artifacts/b07-t02-native-shared-header-phase-readonly-review-20261107',\n             HOME_REPO / '.artifacts/b07-t02-native-shared-header-plan-01-20261107',\n             HERE / 'code-review',", 1),
    ('windows-release-stamp/', 'windows-release-shared-header/', 3),
    ('Current4 compiled implementation originals', 'Current2 compiled implementation originals plus exact immutable integer SQL timing and source-path review', 1),
    ("scope = ('Historical failed Native stamp4650 / Run8e4d Store4ca checker3b tests428. '", "scope = ('Historical failed Native shared-headerc2f1 / Runb393 Store2e97 checker3b tests428. '", 1),
    ("'Ordinary9CLI/0driver/2HTTP/1truekill+resume with final artifact status expected0 mismatch; three11CLI+2driver/5HTTP with backoff1actualWinKill/pass, elapsedNoFit/0kill. '", "'Ordinary6CLI/0driver/2HTTP/0kill naturally NoFit; three11CLI+2driver/5HTTP with backoff PID65888 actualWinKill+wait(exit1)/pass, elapsed PID42408 natural exit0/NoFit/0kill. '", 1),
    ("'failed_Native4650_originals_CRC_SHA_length_readback_passed_not_behavior_acceptance'", "'failed_Nativec2f1_originals_CRC_SHA_length_readback_passed_not_behavior_acceptance'", 1),
    ("for name in ('build_archive.py', 'README.md'):", "for name in ('build_archive.py', 'README.md', 'prepare_builder.py', 'builder-generation-failure-01.json'):", 1),
]
for old, new, count in changes:
    assert source.count(old) == count, (old, source.count(old), count)
    source = source.replace(old, new)
with (HERE / 'build_archive.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
print('standalone builder saved before execution', len(source.encode('utf-8')))
