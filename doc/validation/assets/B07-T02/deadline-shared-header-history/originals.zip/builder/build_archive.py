"""Capture already closed Nativec2f1 shared-header originals without running any product.

This standalone builder exists before generation. Source/archive/executable
references are separate generated members, not invented ordinary originals.
"""
from pathlib import Path
import hashlib
import json
import zipfile


HOME_REPO = Path('/home/lyinn/project/Noetome')
NATIVE_ARTIFACTS = Path('/mnt/d/Noetome/.artifacts')
HERE = Path(__file__).parent
OUTPUT = HERE / 'package'
ORDINARY = NATIVE_ARTIFACTS / 'b07-t02-request-native-shared-header-ordinary-elapsed-01-20261107'
THREE = NATIVE_ARTIFACTS / 'b07-t02-request-native-shared-header-three-target-01-20261107'
NORMALIZED = NATIVE_ARTIFACTS / 'b07-t02-native-shared-header-normalized-source-01-20261107'
PAIR = NATIVE_ARTIFACTS / 'b07-t02-windows-release-pair-06-20261107'
FP = 'c2f1d498cb7c9da53a768c978ba01ea2b16837855a7a2304dc9cea63513f9e00'
AUTHOR_SHA = 'ef04e12745d16f7e10e98f53b348475bdbfaa71d60c9302c297fbf2af0e32272'


def pin(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_nlink)
    assert fields(before) == fields(after)
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
            'capture_platform': 'WSL Linux stat on source filesystem; actual native FileStamp remains inside original receipts',
            'device': after.st_dev, 'inode': after.st_ino, 'mtime_ns': after.st_mtime_ns, 'nlink': after.st_nlink}


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def save(path, value):
    with path.open('xb') as stream:
        stream.write(encode(value))


def actual_counts(root, cli, driver, http, kills):
    value = json.loads((root / 'actual.json').read_bytes())
    assert value['status'] == 'failed'
    assert value['ordinary_CLI_count'] == cli and value['driver_count'] == driver
    assert all(value['guards'].values())
    assert len(value['commands']) == cli + driver
    assert len({command['PID'] for command in value['commands']}) == cli + driver
    assert all('exit_code' in command and 'wait_action' in command for command in value['commands'])
    killed = [command for command in value['commands'] if command['wait_action'] == 'actual_OS_force_kill_and_wait']
    assert len(killed) == kills and all(command['exit_code'] != 0 for command in killed)
    servers = [json.loads(path.read_bytes()) for path in root.rglob('server-receipts.json')]
    assert all(not server['errors'] for server in servers)
    assert sum(len(server['receipts']) for server in servers) == http
    return {'execution_original': str(root / 'actual.json'), 'ordinary_CLI_count': cli,
            'driver_count': driver, 'unique_PID_count': cli + driver, 'actual_HTTP_requests': http,
            'actual_OS_kills': kills, 'all_exit_and_wait_recorded': True,
            'actual_status': 'failed', 'passed_case_ids': [case['case_id'] for case in value['cases'] if case['status'] == 'passed']}


def main():
    assert not OUTPUT.exists(), 'new package only'
    counts = [actual_counts(ORDINARY, 6, 0, 2, 0), actual_counts(THREE, 11, 2, 5, 1)]
    assert counts[1]['passed_case_ids'] == ['retry-backoff-persists-through-kill']
    three_execution = json.loads((THREE / 'actual.json').read_bytes())
    assert next(c for c in three_execution['commands'] if c['wait_action'] == 'actual_OS_force_kill_and_wait')['PID'] == 65888
    elapsed_driver = next(c for c in three_execution['commands'] if c['PID'] == 42408)
    assert elapsed_driver['exit_code'] == 0 and elapsed_driver['wait_action'] == 'ordinary_exit'
    phase = json.loads((HOME_REPO / '.artifacts/b07-t02-native-shared-header-phase-readonly-review-20261107/actual.json').read_bytes())
    assert phase['selected_FP'] == FP and phase['cases'][1]['exact_settled_to_NoFit_event_gap_ns'] == 183608900
    roots = [ORDINARY, THREE,
             NATIVE_ARTIFACTS / 'b07-t02-native-shared-header-wrapper-01-20261107',
             NATIVE_ARTIFACTS / 'b07-t02-native-shared-header-normalize-stage-01-20261107',
             NATIVE_ARTIFACTS / 'b07-t02-native-shared-header-ordinary-stage-01-20261107',
             NATIVE_ARTIFACTS / 'b07-t02-native-shared-header-three-stage-01-20261107',
             HOME_REPO / '.artifacts/b07-t02-native-shared-header-phase-readonly-review-20261107',
             HOME_REPO / '.artifacts/b07-t02-native-shared-header-plan-01-20261107',
             HERE / 'code-review',
             HOME_REPO / 'fixtures/run-api-budget-v1']
    pairs = []
    for root in roots:
        for path in sorted(root.rglob('*')):
            assert not path.is_symlink()
            if path.is_dir():
                continue
            assert path.is_file()
            pairs.append((root.name + '/' + path.relative_to(root).as_posix(), path))
    for path in sorted(NORMALIZED.iterdir()):
        if path.name != 'source-originals.zip':
            pairs.append((NORMALIZED.name + '/' + path.name, path))
    for name in ('build_archive.py', 'README.md', 'prepare_builder.py', 'builder-generation-failure-01.json'):
        pairs.append(('builder/' + name, HERE / name))
    before = [{'member': name, 'original': str(path), 'pin': pin(path)} for name, path in pairs]
    assert len({item['member'] for item in before}) == len(before)
    author_manifest = HOME_REPO / 'fixtures/run-api-budget-v1/frozen-sha256.json'
    assert pin(author_manifest)['sha256'] == AUTHOR_SHA
    normalized = json.loads((NORMALIZED / 'actual.json').read_bytes())
    assert normalized['actual_cli_fingerprint'] == FP
    assert normalized['source_before_after_equal'] is True
    assert normalized['source_files'] == 2056
    reference_paths = [NORMALIZED / 'source-originals.zip',
                       PAIR / 'source-originals.zip',
                       PAIR / 'selected/noetome.exe', PAIR / 'selected/noetome-cli-testdriver.exe',
                       HOME_REPO / 'doc/validation/assets/B07-T02/windows-release-shared-header/originals.zip',
                       HOME_REPO / 'doc/validation/assets/B07-T02/windows-release-shared-header/manifest.json',
                       HOME_REPO / 'doc/validation/assets/B07-T02/windows-release-shared-header/receipt.json']
    references = {str(path): pin(path) for path in reference_paths}
    assert references[str(PAIR / 'selected/noetome.exe')]['sha256'] == normalized['cli']['sha256']
    assert references[str(PAIR / 'selected/noetome-cli-testdriver.exe')]['sha256'] == normalized['test_driver']['sha256']
    assert references[str(PAIR / 'selected/noetome.exe')]['sha256'] == '09535d63b995673af12ac2a4fd101076bce82806cb2a26e2d72e9dcad0250325'
    assert references[str(PAIR / 'selected/noetome-cli-testdriver.exe')]['sha256'] == '4cfaa3cde16ea473a1da8b2cd81a647dfbd0b44b2f05f003b7fc3718bec03e68'
    assert references[str(PAIR / 'source-originals.zip')]['sha256'] == '4c2b2fc1230c619cd2b7d3bb2ab8609ea3fdaa3923060c434d2d37b368e693f3'
    reference = encode({'referenced_ordinary_original_files': references,
                        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': pin(Path(__file__).absolute())},
                        'scope': 'Complete selected2056 source ZIP and executable bodies are already retained as compiler originals; this package retains their actual byte pins without repeating large bodies. Current2 compiled implementation originals plus exact immutable integer SQL timing and source-path review and source-before/after2056 descriptors/primary readback are ordinary members. Generated reference has no separately existing ordinary source file.'})
    OUTPUT.mkdir()
    with zipfile.ZipFile(OUTPUT / 'originals.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for entry in before:
            archive.writestr(entry['member'], Path(entry['original']).read_bytes())
        archive.writestr('current-compiler-program-originals-reference.json', reference)
    with zipfile.ZipFile(OUTPUT / 'originals.zip') as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(before) + 1
        for entry in before:
            raw = archive.read(entry['member'])
            assert hashlib.sha256(raw).hexdigest() == entry['pin']['sha256'] and len(raw) == entry['pin']['byte_length']
        assert archive.read('current-compiler-program-originals-reference.json') == reference
    assert all(pin(Path(entry['original'])) == entry['pin'] for entry in before)
    assert references == {name: pin(Path(name)) for name in references}
    scope = ('Historical failed Native shared-headerc2f1 / Runb393 Store2e97 checker3b tests428. '
             'Ordinary6CLI/0driver/2HTTP/0kill naturally NoFit; three11CLI+2driver/5HTTP with backoff PID65888 actualWinKill+wait(exit1)/pass, elapsed PID42408 natural exit0/NoFit/0kill. '
             'Accepted and main62 not_run; original1500/1000/API200/R8310 and all45author bytes unchanged. '
             'No new product/testdriver/HTTP is invoked by archive or read-only review. No fullRust/Python or OSelapsed acceptance inferred.')
    save(OUTPUT / 'manifest.json', {'ordinary_original_files': len(before), 'generated_reference_members': 1,
                                   'total_zip_members': len(before) + 1, 'members': before,
                                   'embedded_reference': {'name': 'current-compiler-program-originals-reference.json',
                                                          'sha256': hashlib.sha256(reference).hexdigest(), 'byte_length': len(reference),
                                                          'generation_program': 'builder/build_archive.py'},
                                   'original_execution_counts': counts, 'scope': scope})
    save(OUTPUT / 'actual.json', {'status': 'failed_Nativec2f1_originals_CRC_SHA_length_readback_passed_not_behavior_acceptance',
                                 'ordinary_original_files': len(before), 'generated_reference_members': 1,
                                 'members': len(before) + 1, 'CRC_SHA_length_all': True,
                                 'ordinary_original_identity_mtime_bytes_before_after_equal': True,
                                 'zip': pin(OUTPUT / 'originals.zip'), 'manifest': pin(OUTPUT / 'manifest.json'),
                                 'generation_program': pin(Path(__file__).absolute()), 'original_execution_counts': counts,
                                 'author_frozen_manifest_sha256': AUTHOR_SHA, 'scope': scope})
    print(json.dumps({'status': 'archive_readback_passed', 'package': str(OUTPUT), 'ordinary': len(before), 'generated': 1,
                      'zip': pin(OUTPUT / 'originals.zip'), 'manifest': pin(OUTPUT / 'manifest.json'), 'actual': pin(OUTPUT / 'actual.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
