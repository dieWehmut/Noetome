# Prepared only; execute after explicit Root closed-pair/preflight GO. Actual pins are mandatory parameters.
param(
    [Parameter(Mandatory=$true)][string]$NativeBuildRoot,
    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$Fingerprint,
    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$CliSha,
    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9a-f]{64}$')][string]$DriverSha
)
$ErrorActionPreference = 'Stop'
$repo = Join-Path $NativeBuildRoot 'repo'
$cli = Join-Path $NativeBuildRoot 'selected\noetome.exe'
$driver = Join-Path $NativeBuildRoot 'selected\noetome-cli-testdriver.exe'
$runtime = [ordered]@{ PID = $PID; PSVersion = $PSVersionTable.PSVersion.ToString(); Platform = 'actual_native_PowerShell'; Stage = 'normalize'; StartedUtc = [DateTime]::UtcNow.ToString('o') }
[System.IO.File]::WriteAllText('D:\Noetome\.artifacts\b07-t02-native-shared-header-wrapper-01-20261107\powershell-normalize-runtime.json', ($runtime | ConvertTo-Json -Depth 8), [System.Text.UTF8Encoding]::new($false))
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-wrapper-01-20261107\run_stage.py' '--new-stage-root' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-normalize-stage-01-20261107' '--runtime-record' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-normalized-source-01-20261107\primary-readback.json' '--' 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-wrapper-01-20261107\normalize_build.py' '--native-build-root' $NativeBuildRoot '--new-root' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-normalized-source-01-20261107' '--expected-fingerprint' $Fingerprint '--expected-cli-sha' $CliSha '--expected-driver-sha' $DriverSha
exit $LASTEXITCODE
