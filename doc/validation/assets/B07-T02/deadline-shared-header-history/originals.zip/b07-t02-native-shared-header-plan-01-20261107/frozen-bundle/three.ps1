# Prepared only; execute after explicit Root closed-pair/preflight GO. Actual pins are mandatory parameters.
param(
    [Parameter(Mandatory=$true)][string]$NativeBuildRoot
)
$ErrorActionPreference = 'Stop'
$repo = Join-Path $NativeBuildRoot 'repo'
$cli = Join-Path $NativeBuildRoot 'selected\noetome.exe'
$driver = Join-Path $NativeBuildRoot 'selected\noetome-cli-testdriver.exe'
$runtime = [ordered]@{ PID = $PID; PSVersion = $PSVersionTable.PSVersion.ToString(); Platform = 'actual_native_PowerShell'; Stage = 'three'; StartedUtc = [DateTime]::UtcNow.ToString('o') }
[System.IO.File]::WriteAllText('D:\Noetome\.artifacts\b07-t02-native-shared-header-wrapper-01-20261107\powershell-three-runtime.json', ($runtime | ConvertTo-Json -Depth 8), [System.Text.UTF8Encoding]::new($false))
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-wrapper-01-20261107\run_stage.py' '--new-stage-root' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-three-stage-01-20261107' '--runtime-record' 'D:\Noetome\.artifacts\b07-t02-request-native-shared-header-three-target-01-20261107\native-wrapper-runtime.json' '--' 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-wrapper-01-20261107\narrow.py' '--mode' 'three-targets' '--repo' $repo '--source-pins' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-normalized-source-01-20261107\source-before.json' '--cli' $cli '--driver' $driver '--build-receipt' 'D:\Noetome\.artifacts\b07-t02-native-shared-header-normalized-source-01-20261107\actual.json' '--new-root' 'D:\Noetome\.artifacts\b07-t02-request-native-shared-header-three-target-01-20261107'
exit $LASTEXITCODE
