"""Read fixed compiled C2 source and already retained integer SQL event review.

No CLI, driver, HTTP, SQLite writer, or native process is invoked here.
This source exists before the derived review is generated.
"""
from pathlib import Path
import hashlib
import json

REPO = Path('/home/lyinn/project/Noetome')
HERE = Path(__file__).parent
PHASE = REPO / '.artifacts/b07-t02-native-shared-header-phase-readonly-review-20261107'
EXPECTED = {
    'request_run.rs': 'b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c',
    'request_budget_store.rs': '2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184',
    'actual.json': 'bd9bf3b089fa1c23a1128259aa54f4ac3fe91fe8f662896789fbd78562604db8',
}


def read(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino,
                 'mtime_ns': after.st_mtime_ns, 'nlink': after.st_nlink}


def lines(raw, start, end):
    return ''.join(raw.decode('utf-8').splitlines(keepends=True)[start - 1:end])


def save(name, value):
    with (HERE / name).open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def main():
    originals = {}
    for name, digest in EXPECTED.items():
        raw, pin = read(PHASE / name)
        assert pin['sha256'] == digest
        originals[name] = {'path': str(PHASE / name), 'pin': pin, 'raw': raw}
    phase = json.loads(originals['actual.json']['raw'])
    case = next(case for case in phase['cases'] if case['label'] == 'three')
    assert case['exact_A_first_settled_offset_ns'] == 437943600
    assert case['exact_A_NoFit_offset_ns'] == 621552500
    assert case['exact_settled_to_NoFit_event_gap_ns'] == 183608900
    assert not any(row['kind'] == 'retry_scheduled' for row in case['event_summary'])
    run, store = originals['request_run.rs']['raw'], originals['request_budget_store.rs']['raw']
    excerpts = [
        {'file': 'request_run.rs', 'start': 1707, 'end': 1713,
         'purpose': 'Hooks.finished calls settle and then the actual settled callback; the ledger event timestamp is sampled inside the transaction, before COMMIT completion.',
         'required': ['self.store.settle(&key, &r)?;', 'self.event("attempt_settled_commit")']},
        {'file': 'request_run.rs', 'start': 1459, 'end': 1463,
         'purpose': 'The API return sets expect_receipt and enters the next loop. The receipt must be checked against a fresh authoritative view.',
         'required': ['expect_receipt =', 'Some(finished_key']},
        {'file': 'request_run.rs', 'start': 1143, 'end': 1157,
         'purpose': 'Each loop starts owner/input checks, a fresh budget view and inventory checks before consuming expect_receipt.',
         'required': ['g.verify()?;', 'g.inputs()?;', 'let view = store.view()?;', 'g.inventory(&view)?;']},
        {'file': 'request_run.rs', 'start': 1285, 'end': 1329,
         'purpose': 'The retryable final receipt is subjected to absolute deadline/delay checks. The actual retained NoFit diagnostic returns through finish_unit before schedule_retry_after.',
         'required': ['"No retry fits the original absolute deadline"', 'store.schedule_retry_after(&a.plan.key, code)?;']},
        {'file': 'request_run.rs', 'start': 1113, 'end': 1132,
         'purpose': 'All failed unit finishes first call release_unsent, then commit the unit outcome.',
         'required': ['release_unsent(store, g, index, reason)?;', 'store.finish_unit']},
        {'file': 'request_run.rs', 'start': 914, 'end': 938,
         'purpose': 'release_unsent opens another full view before deciding that a settled receipt is ineligible for a Prepared/Reserved release. This view still executes for this settled A attempt.',
         'required': ['let view = store.view()?;', 'g.trusted_owner(&view)?;', 'g.verify()?;', 'a.receipt.is_none() && matches!(a.state, AttemptState::Prepared | AttemptState::Reserved)']},
        {'file': 'request_budget_store.rs', 'start': 677, 'end': 684,
         'purpose': 'Every view locks the authority, validates layout/schema, loads the complete chain, and validates original-file witnesses.',
         'required': ['let _guard = lock(&self.root)?;', 'let view = load(', 'witnesses(&view)?;']},
        {'file': 'request_budget_store.rs', 'start': 691, 'end': 752,
         'purpose': 'Each update rechecks layout/schema, begins an Immediate transaction, reloads the full chain/witnesses, then samples event time before the insert/COMMIT. A post-COMMIT layout check follows.',
         'required': ['TransactionBehavior::Immediate', 'let mut view = load(', 'witnesses(&view)?;', 'let at = now()?;', 'tx.commit().map_err(database)?;']},
        {'file': 'request_budget_store.rs', 'start': 1130, 'end': 1151,
         'purpose': 'Store.finish_unit calls a fresh update rather than reusing the preceding read-only view.',
         'required': ['self.update(|v, _| {', 'BudgetEvent::UnitFinished']},
        {'file': 'request_budget_store.rs', 'start': 1964, 'end': 2021,
         'purpose': 'The full view witness includes registered directories, sealed file stamps, raw request, sealed transport and receipt-file validation for all attempts in all runs.',
         'required': ['for run in &v.runs', 'for (name, expected) in &a.sealed_files', 'verify_request(&root, &a.plan)?;', 'receipt_files(&root, &a.plan, receipt)?;']},
    ]
    for excerpt in excerpts:
        excerpt['source_text'] = lines(run if excerpt['file'] == 'request_run.rs' else store, excerpt['start'], excerpt['end'])
        for literal in excerpt.pop('required'):
            assert literal in excerpt['source_text'], (excerpt['file'], excerpt['start'], literal)
    report = {
        'status': 'fixed_C2_source_path_review_completed_no_measured_function_breakdown',
        'actual_compiler_fingerprint': phase['selected_FP'],
        'source_originals': {name: {key: value for key, value in record.items() if key != 'raw'} for name, record in originals.items()},
        'exact_retained_event_gap_ns': 183608900,
        'actual_A_settled_offset_ns': 437943600, 'actual_A_NoFit_offset_ns': 621552500,
        'actual_A_retry_scheduled_events': 0,
        'identified_path': ['settle transaction event timestamp, remaining transaction/COMMIT/layout and callback',
                            'remaining original API validation/return',
                            'next unit loop: Run owner/input/inventory + first fresh budget view/full witnesses',
                            'NoFit comparison against original absolute deadline before any RetryScheduled call',
                            'finish_unit failure cleanup: release_unsent second fresh view/full witnesses, then sees a settled receipt and releases nothing',
                            'Store.finish_unit third full chain/witness traversal in a new Immediate transaction before UnitFinished event timestamp'],
        'independent_concurrent_changes': [row for row in case['event_summary'] if row['unit_id'] == 'unit-b' and 437943600 < row['exact_offset_from_original_clock_ns'] < 621552500],
        'possible_optimization_review': 'The two prior views and the final update repeat full authoritative/raw-file proofs. A future protected single-transaction decision may be evaluated, but must preserve fresh BEGINIMMEDIATE ownership/input/original-file proof, original deadline sampled after guards, all independent durable event boundaries and callbacks, NotSent proof and Known/Unknown accounting. This review authorizes no code change or cache across HTTP/COMMIT. No individual function or IO cost was measured.',
        'excerpts': excerpts,
        'limits': 'Original event.at is not COMMIT completion or callback time. The total interval also includes API guards and concurrent B work/authority serialization. The retained SQL proves B receipt was committed between the A events; it does not measure B lock duration. No schedule_retry_after path executed for this A attempt. The interval cannot be assigned entirely to IO, witnesses, one function or a particular optimization.',
        'new_product_CLI_HTTP_Native_processes': 0,
        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': read(Path(__file__).absolute())[1]},
    }
    assert all(read(Path(record['path']))[1] == record['pin'] for record in report['source_originals'].values())
    save('actual.json', report)
    markdown = ('C2 current Native history: source path review\n\n'
                'The A settled event was at +437.9436 ms and the NoFit UnitFinished event at +621.5525 ms, an exact 183.6089 ms interval. The original 1500 ms unit deadline and 1000 ms retry minimum remained unchanged. No RetryScheduled event or A2 existed.\n\n'
                'The compiled path first checks the API final receipt in the next loop after owner/input checks and a full budget view. It then decides NoFit before schedule_retry_after. Failure finish calls release_unsent, which performs another full view before discovering that settled A cannot be released. Store.finish_unit then opens a fresh Immediate transaction and replays all witnesses before its event timestamp. This identifies repeated proof traversals, including one release check that produces no release for this settled attempt.\n\n'
                'The 183.6089 ms includes time after the earlier event timestamp inside its original transaction, callback/API return checks, concurrent B receipt work and the later guards. SQL event.at is sampled before COMMIT completes. No function-level timings were captured; this review does not attribute the interval to a function, filesystem or number of syscalls, and does not demonstrate that any proposed optimization meets the deadline.\n\n'
                'All source excerpts and original integer event times are bound in actual.json. This read-only generation invoked zero product CLI, HTTP, drivers or Native processes.\n')
    with (HERE / 'README.md').open('xb') as stream:
        stream.write(markdown.encode('utf-8'))
    print(json.dumps({'status': report['status'], 'actual': read(HERE / 'actual.json')[1]}))


if __name__ == '__main__':
    main()
