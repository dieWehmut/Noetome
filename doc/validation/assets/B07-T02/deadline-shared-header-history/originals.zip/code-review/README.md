C2 current Native history: source path review

The A settled event was at +437.9436 ms and the NoFit UnitFinished event at +621.5525 ms, an exact 183.6089 ms interval. The original 1500 ms unit deadline and 1000 ms retry minimum remained unchanged. No RetryScheduled event or A2 existed.

The compiled path first checks the API final receipt in the next loop after owner/input checks and a full budget view. It then decides NoFit before schedule_retry_after. Failure finish calls release_unsent, which performs another full view before discovering that settled A cannot be released. Store.finish_unit then opens a fresh Immediate transaction and replays all witnesses before its event timestamp. This identifies repeated proof traversals, including one release check that produces no release for this settled attempt.

The 183.6089 ms includes time after the earlier event timestamp inside its original transaction, callback/API return checks, concurrent B receipt work and the later guards. SQL event.at is sampled before COMMIT completes. No function-level timings were captured; this review does not attribute the interval to a function, filesystem or number of syscalls, and does not demonstrate that any proposed optimization meets the deadline.

All source excerpts and original integer event times are bound in actual.json. This read-only generation invoked zero product CLI, HTTP, drivers or Native processes.
