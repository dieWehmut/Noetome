# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ee653ba7a520a3eea45d5c654f271f40494a9177d8ef35f0a4f494c3701b63bd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9c68292eec5148e93e75425cc57da9748130502f29c618483336f65bc4ad7c11"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3afdf266592964be74452a71187c8cd0ad1f7e1ba2d2eea86427be86c40f04b6"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "17122beb0dc9215b8589302dddb3e36403e9bb14de2b7323b6050916af426c37"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4adcaf0a282431382bd53138c0842a82d1b94c0fe8033c9da5e42ecf6571d7c4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "14eecf5d3c63a8febbb8ce6781f882e4026ae50417db9a5bd74bd33b4d38ff24"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8e29b7f6-1b8f-4e40-9b60-910c69f9f608",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4b3926bc-2d5b-4cbb-8b13-350d2ecb1800",
    "source_id": "6deae99e-46ad-4174-9d70-de18a6b817c4",
    "version_id": "31cb6d51-f689-4866-a656-597b5ff86bd8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59423/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f021ae54-6a83-4559-8f67-2662fabf25c4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4adcaf0a282431382bd53138c0842a82d1b94c0fe8033c9da5e42ecf6571d7c4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
