# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3d08b9e04ef9de5673922e8f7e7bb47eb4d1503bee77682015327f12b1ecbca4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "598605ca72117d6867eeb7dcbc5ce31e111304265c3733aefb172dc55ee0046f"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "56a216c3f644186e6815e393457b315ddbbb1a71656f7baf4706b6d401309a83"
    },
    "response.bin": {
      "byte_length": 122,
      "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
    },
    "transport-receipt.json": {
      "byte_length": 502,
      "sha256": "a745f69cc7ce892e21d4ccdbbda338761394a0ada536a52a58432f7b94d9d732"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8e29b7f6-1b8f-4e40-9b60-910c69f9f608",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4b3926bc-2d5b-4cbb-8b13-350d2ecb1800",
    "source_id": "6deae99e-46ad-4174-9d70-de18a6b817c4",
    "version_id": "31cb6d51-f689-4866-a656-597b5ff86bd8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59423/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "21141601-d56a-4ce3-918a-8420226282b3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 122,
    "omission_reason": null,
    "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
