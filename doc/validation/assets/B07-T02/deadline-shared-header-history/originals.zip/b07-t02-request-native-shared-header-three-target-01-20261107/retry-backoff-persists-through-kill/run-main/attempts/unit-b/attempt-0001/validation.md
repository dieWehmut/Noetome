# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "74c121104df98bf39ac3ebd81d990fd1b126c180f6b3b5a92d11f486410a1a98"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5e469917d7fc3b2b7f61a17825987c9398ce11304c3cbfc552a246c1db01cc2b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "777a84d25133b8be545f5dc8758f7cf4507d0bfb3aa0961f44ec7d1a8541362e"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "1b808d35f18582ee11a532a0acf6f72c0bf948511f0cfd6905e402f9a5deebd3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "eaaf15aeb4980a66a803b11f1f29bc1701bb6caa3954f92eb9916bea267e99f0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "45ec9a4d93a271eda79d1bb805a423be83c7b8c256c6297282a56e007bc594d3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "17938358-b713-406c-8519-ba456b6056b1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6b228335-9a95-4228-b54f-6243d1b1b428",
    "source_id": "a5df975b-03f5-4855-acac-9cd45ce06e02",
    "version_id": "b6700b0e-c2aa-4107-9eb6-d338379a5eb6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59423/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4c9175fc-ad68-4cd3-94c0-2d123b5ab41d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "eaaf15aeb4980a66a803b11f1f29bc1701bb6caa3954f92eb9916bea267e99f0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
