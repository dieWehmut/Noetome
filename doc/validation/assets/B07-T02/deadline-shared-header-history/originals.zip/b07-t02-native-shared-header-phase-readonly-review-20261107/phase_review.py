"""Exact integer UTC review of already closed Nativec2f1 originals; no product runs."""
from pathlib import Path
import json,hashlib,sqlite3,contextlib,calendar,datetime
REPO=Path('/home/lyinn/project/Noetome')
HERE=Path(__file__).parent
NATIVE=Path('/mnt/d/Noetome/.artifacts')
FP='c2f1d498cb7c9da53a768c978ba01ea2b16837855a7a2304dc9cea63513f9e00'


def pin(path):
 before=path.stat();assert path.is_file() and not path.is_symlink() and before.st_nlink==1
 raw=path.read_bytes();after=path.stat()
 fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_nlink)
 assert fields(before)==fields(after)
 return raw,{'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw),'WSL_device':before.st_dev,'WSL_inode':before.st_ino,'mtime_ns':before.st_mtime_ns,'nlink':before.st_nlink}


def ns(text):
 assert text.endswith('Z')
 base,_,fraction=text[:-1].partition('.')
 seconds=calendar.timegm(datetime.datetime.strptime(base,'%Y-%m-%dT%H:%M:%S').timetuple())
 assert len(fraction)<=9
 return seconds*1000000000+int(fraction.ljust(9,'0') or '0')


def save(name,value):
 with (HERE/name).open('xb') as f:f.write((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())


results=[]
for label,name,counts in [('ordinary','b07-t02-request-native-shared-header-ordinary-elapsed-01-20261107',(6,0,2,0)),('three','b07-t02-request-native-shared-header-three-target-01-20261107',(11,2,5,1))]:
 root=NATIVE/name
 actual_raw,actual_pin=pin(root/'actual.json');actual=json.loads(actual_raw)
 assert actual['status']=='failed' and actual['ordinary_CLI_count']==counts[0] and actual['driver_count']==counts[1]
 assert all(actual['guards'].values()) and all('exit_code' in c and 'wait_action' in c for c in actual['commands'])
 assert len({c['PID'] for c in actual['commands']})==sum(counts[:2])
 killed=[c for c in actual['commands'] if c['wait_action']=='actual_OS_force_kill_and_wait']
 assert len(killed)==counts[3] and all(c['exit_code']!=0 for c in killed)
 servers=[json.loads(pin(p)[0]) for p in root.rglob('server-receipts.json')]
 assert sum(len(s['receipts']) for s in servers)==counts[2] and all(not s['errors'] for s in servers)
 db=root/'elapsed-limit-persists-through-kill/budget/control/budget.sqlite'
 raw,before=pin(db)
 with contextlib.closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)) as c:
  sql=list(c.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
 previous='0'*64;rows=[]
 for sequence,prev,payload,digest in sql:
  assert sequence==len(rows)+1 and prev==previous and hashlib.sha256(payload.encode()).hexdigest()==digest
  value=json.loads(payload);assert value['sequence']==sequence and value['previous_sha256']==prev
  rows.append(value);previous=digest
 spec=rows[0]['event']['spec'];deadline=next(u['deadline_utc'] for u in spec['units'] if u['unit_id']=='unit-a')
 start=ns(deadline)-1500000000
 summary=[]
 for row in rows:
  e=row['event'];key=e.get('key',e.get('plan',{}).get('key',{}))
  summary.append({'sequence':row['sequence'],'at_utc':row['at_utc'],'kind':e['kind'],'unit_id':e.get('unit_id',key.get('unit_id')),'outcome':e.get('outcome'),'diagnostic':e.get('diagnostic'),'exact_offset_from_original_clock_ns':ns(row['at_utc'])-start})
 settled=next(x for x in summary if x['kind']=='receipt_settled' and x['unit_id']=='unit-a')
 failed=next(x for x in summary if x['kind']=='unit_finished' and x['unit_id']=='unit-a')
 assert failed['outcome']=='failed' and failed['diagnostic']=='No retry fits the original absolute deadline'
 assert not any(x['kind']=='retry_scheduled' for x in summary)
 _,after=pin(db);assert before==after and raw==pin(db)[0]
 results.append({'label':label,'execution_original':str(root/'actual.json'),'execution_pin':actual_pin,'actual_CLI':counts[0],'actual_driver':counts[1],'actual_HTTP':counts[2],'actual_OS_kill_wait':counts[3],'every_owned_PID_exit_wait_recorded':True,'guards':actual['guards'],'failure':actual['failure'],'database_original':str(db),'database_pin_before_after_equal':before,'original_A_deadline_utc':deadline,'original_A_clock_unix_ns':start,'exact_A_first_settled_offset_ns':settled['exact_offset_from_original_clock_ns'],'exact_A_NoFit_offset_ns':failed['exact_offset_from_original_clock_ns'],'exact_settled_to_NoFit_event_gap_ns':failed['exact_offset_from_original_clock_ns']-settled['exact_offset_from_original_clock_ns'],'event_summary':summary,'accepted_not_run':label=='three','main62_not_run':True})
assert results[0]['exact_A_first_settled_offset_ns']==502922200
assert results[1]['exact_A_first_settled_offset_ns']==437943600 and results[1]['exact_A_NoFit_offset_ns']==621552500
assert results[1]['exact_settled_to_NoFit_event_gap_ns']==183608900
compiled=[]
for file,expected in [('request_run.rs','b393ff1887430569a59a96201c38be95cea96dc3e7b9b84ecf5654af7c179e5c'),('request_budget_store.rs','2e97ac1dc33692fad676b5403d7b61a287cc557fe6dbda6069646d63f4e83184')]:
 path=NATIVE/'b07-t02-windows-release-pair-06-20261107/repo/crates/noetome-cli/src'/file
 raw,p=pin(path);assert p['sha256']==expected
 with (HERE/file).open('xb') as f:f.write(raw)
 compiled.append({'original':str(path),'pin':p})
report={'status':'closed_current_Nativec2f1_NoFit_history_exact_phase_review_completed','selected_FP':FP,'compiled_originals':compiled,'cases':results,'integer_UTC_precision':'RFC3339 fraction padded to9 and integer epoch seconds; exact100ns source timing retained, no floating timestamp conversion','earlier_tool_display_limit':'The temporary first phase print used datetime float arithmetic; this retained result uses exact integer timestamps and does not treat those approximate offsets as originals. Original event strings were unchanged.','scope':'Closed failure history only. Ordinary0kill NoFit; backoff1actualkill/pass; elapsed0kill NoFit; accepted/main62 not_run. Event.at is before SQL commit completion, not commit/function duration, and the event gap cannot be assigned to one IO class. All database reads immutable/ro and explicitly closed; original bytes/IDmtime beforeafter equal. No new CLI, HTTP, tests, models or Native process.'}
save('actual.json',report)
raw,p=pin(HERE/'actual.json');print(json.dumps({'status':report['status'],'actual_pin':p,'counts':[{'CLI':x['actual_CLI'],'drivers':x['actual_driver'],'HTTP':x['actual_HTTP'],'OSkill':x['actual_OS_kill_wait']} for x in results]}))
