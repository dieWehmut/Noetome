# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d53b7343306f5b7d631854c57e61a9faf2d2e06578a6af9ff16640e2d824a4c5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "37ca848cfb3a8bfd837bd3dd61a7dbd9010326d6f6497eecef2c45a4952a69f8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "320129baaaf4cee1d3ce675629d8b61e4b73818e3e2a2aefe635d4a7f2f6dde5"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "18d20f86d50517dd929cd9cceb990405517640d067188e437601e95129e38744"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b19e0faf6ac289f58a502311184763cc190a9465c5355ec4076dcfe6934a2ad6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "22e5e6cefe1dbd582fa6ccb4a4acc8814a9d7b1067725a5580fde9cea2acdddb"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f5e591b4-1695-47fd-9bec-a27075531873",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "42307927-c5f2-43bf-b025-06105ea3fa62",
    "source_id": "4c3b2525-2dd8-4669-9e39-5172f4eaf06f",
    "version_id": "4e9d4a9a-2c44-411e-a3f0-833944001d59"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62743/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "47b1b36a-d24f-426d-8b42-caad95532e62",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b19e0faf6ac289f58a502311184763cc190a9465c5355ec4076dcfe6934a2ad6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
