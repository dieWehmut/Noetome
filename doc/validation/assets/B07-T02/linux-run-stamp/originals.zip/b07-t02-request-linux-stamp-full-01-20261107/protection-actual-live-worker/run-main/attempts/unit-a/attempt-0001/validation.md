# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "966ba252d4c66723d00887201a5aad2fb7aace7c47ad2627159e7dc32897dc88"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "206440e960dce4cb0685bdb933ad78ab6edcab50d14c766f6ca7ba6d21e2d3ee"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f79bb651147225203d953fdd8139be5cffc59a38a9b7c71fb36820a8d1e87791"
    },
    "request.json": {
      "byte_length": 2218,
      "sha256": "a3477133018f9ab0201d0517004155b42b7daf5e7be538b30dea91af27e0017f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2aac12ccd0a3605a5f79b10358f54c9c370550ba5d921656b1f8a444d09e00bb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9f71d2ab483faa7ee9ae6ea76b97bc0eade08059f85440feda6038e318827c6e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4e645ab7-3065-48c8-9117-ef800a4a91c5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c63821cc-d769-493d-8808-e0da213a550f",
    "source_id": "28c4b7bf-bf28-4798-ba58-aebbbae37d6b",
    "version_id": "251dc596-939a-4b5e-ae32-f22030309dbb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37749/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "39becb6e-6427-4276-ab47-1107d9cf4ac8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2aac12ccd0a3605a5f79b10358f54c9c370550ba5d921656b1f8a444d09e00bb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
