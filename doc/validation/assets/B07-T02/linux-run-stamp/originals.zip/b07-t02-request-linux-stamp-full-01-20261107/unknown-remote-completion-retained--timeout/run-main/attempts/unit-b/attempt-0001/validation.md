# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f0841f2437c30498fc19a1dc66ed6ec0af705f2f107e9b2b3b67e7cfe4ab4af8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "869addf3dab969083043810761b7dcf4b62284c7c2aeb6888c27b2bb7e90ae65"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "07a37b5eef9da9126f3139f413ed1ab2de514cf5662c3c646fdae22932e49cfd"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "8a6751912cb4a7ec508aa3fb03579326add063ef69048fd40554151844e3f056"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7306259bc0f46025f3460dbb7be30485cb1e5e812b86b09a56a0cf4da6474837"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "733d4d67fbda3a7c5592c90b2384f3966d3924b6f42c8d0eb8c1ecf3b88d4d23"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bee0dfda-08e5-4724-9000-78c4d58dff4b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2de52e62-8c2c-4efd-92c4-873bb8e77d8f",
    "source_id": "0dcc5c52-8573-4d87-8150-ad229eddf078",
    "version_id": "6e212e1b-94b9-4efb-a904-9b4116c2ea5e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37069/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "61a5c053-2d50-4939-bbb2-ff35f3cce663",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7306259bc0f46025f3460dbb7be30485cb1e5e812b86b09a56a0cf4da6474837"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
