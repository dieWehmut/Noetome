# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "94c5ac4b60d388e6645ef5bba4d075450c76e916428e8039d0ef0d4fd7f66bfe"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ad5b654b9568d8984249cf37178d405f87b0aa827899339beb3e07bcebbd68d9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9dc14d96c2c475b155fe4e78f5196ddc3869823dc596b5f985d5915681c34a26"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "49663f953d085f874c990cbbb62e19268ec29beaddc7d1419964644cd52e8230"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bed6d585fadbe129ce8a81cc738230a8dc611c238708ae11564a96638c15caa9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "494539906eccc86af3746e2916189a0a5a93650a03457c01cbcf684e85523286"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f1608877-0188-412b-a54e-da00964dc6e2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "790d4d63-c2b6-4a35-946d-d3cba3713dfd",
    "source_id": "fbe0e7eb-551f-4ccd-a1c7-bf92f0eece26",
    "version_id": "d6e2e097-6db3-4a30-b49c-ed6840304ffe"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37069/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b8149fdb-1956-43a2-b4c8-f63ccc6cb24c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bed6d585fadbe129ce8a81cc738230a8dc611c238708ae11564a96638c15caa9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
