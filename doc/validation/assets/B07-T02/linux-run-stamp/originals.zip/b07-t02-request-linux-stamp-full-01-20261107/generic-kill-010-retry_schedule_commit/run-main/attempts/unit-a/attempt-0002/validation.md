# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1ab62b714b3d0419a1befba2df5f996c43663c5e1ed41da19ab9bd14577cff08"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b32fdaff3e23d5a16e8fc8d229269a70a3fe963d5623ef5137d2a88fec5cd812"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ec8a20ce9a9dda00956c1578bf42c0f6bd09d1706be224b9491345f56779cb82"
    },
    "request.json": {
      "byte_length": 2227,
      "sha256": "1175411b1f82486d1cdafdcf1d88503b21a8093cb725ea37f8b177be19cbb851"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3afbfe9a186e2e5ce985008eaa3c069d58e72be85ed5335213140e96e30b08b2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a461b272e8f80681e09b5f683b92efedfc7b2ee7c614b119f9682bdd416a211b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b00ed59a-48fd-4372-b472-d08c6513c5f4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8ff3a704-56b3-4ab1-bf14-fd98ab314506",
    "source_id": "7d699fd6-f458-4a5b-a113-a3408db6bd12",
    "version_id": "68d719f2-e102-49c3-9f79-86eebd893bab"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36469/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "603892ce-ae55-4f3a-b919-c6527674e207",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3afbfe9a186e2e5ce985008eaa3c069d58e72be85ed5335213140e96e30b08b2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
