# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e29f322752246adfd223c55a6371c2c08f975fc1c83e9e60c04d08850cdfc994"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6c34da5c4caf9ff8e8436dc34d04ac1ed7b8e115367456116617b3f24e4ab0c9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a5c67d0d43cb5d6072ff6dec21ca4b08e4e938451933b2c93210e9f55180f5b2"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "39ccf611bd17b696c8e69cc3a8657a1bfd5040afd3b2cf2e06711c20291cdade"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2eadfd8a8a48cbd1ecaf8f67de804409b0b0dd972cdc9f03a916bac7718fd3e8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d9ac8a71e103b86b6b82ec481a166816e1a76e7d834abf7c88ed8da576fe69da"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "df89e857-29d7-4f8f-8162-b0443a97c533",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3b2411c1-8ca0-4ec3-92ed-4037a978071d",
    "source_id": "0d0fba97-e9f6-471a-98ee-ca4a1903cb0b",
    "version_id": "33f143d7-57a0-45a0-9d54-046c0c92d513"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36531/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "82709f86-22da-4b46-a3a1-9f520c800751",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2eadfd8a8a48cbd1ecaf8f67de804409b0b0dd972cdc9f03a916bac7718fd3e8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
