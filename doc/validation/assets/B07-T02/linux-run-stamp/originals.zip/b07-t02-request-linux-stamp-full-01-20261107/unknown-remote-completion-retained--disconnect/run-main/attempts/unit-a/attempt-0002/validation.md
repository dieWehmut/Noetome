# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d61aac0f7edf8ac8355b3292b4deb194edec8f26683ff38aa378b8c3bfd9b81f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8cabfbdd93486332445d0814f07044172c2e917dc3afd74c762fc5d23d540ac7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3da883ccbca183902c108eb50e52c3eb5e0ad4891a4818ab399c5a2aa001bd82"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "c89f1fa87f50fa707e217f87ca4af5a55a3ecdb19742b91709c06d0b2dfc60c8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2afaa43c8d40ff9caa83fbd5c6dc7a591662beb465243ae5931dca274d7aa572"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "84df73c6ccb1a9dfd92ec4a8b6d63d7d4ee0eaf4798706910ab1e44bfb977df0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "efc4bcb4-6e13-4641-9da4-646f23ef6af8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3f884437-9f41-44d8-a14b-936c22beda53",
    "source_id": "2bdc6527-b1b1-474a-a817-31e3a1ba9918",
    "version_id": "9059984b-76d7-43d6-a4bb-5428849d80b8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36531/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "eb4faf31-3278-495d-8326-5470c28623b4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2afaa43c8d40ff9caa83fbd5c6dc7a591662beb465243ae5931dca274d7aa572"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
