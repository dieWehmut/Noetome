# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fa7cafc16b4cc1c04f79ccf1e97fcd0ecca507d08085512e5ac5fd3b4e1d30c1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6b4c1bb1f62086df14901dd12d7411a537cae4617f3f630a4488c521b091e554"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3afa192e64b8aae3d1b1c6cfaa974e7c1777f039604312067506e0f35f7249ca"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "79a09a325b8bf1f50ec1b392766197208414743085c03f293ea3b205261b17d9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "09df34711a42f2f33e5da49d5ee4a6e3f2e9128b3bb6f58eabd40722f9a88a74"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "564441305c522f01794a750d4d51f047eea35a62288f4c46077bd62d5b01b440"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "706816c9-a927-453b-9ad8-f85536e9be4a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "39f53479-6a20-41e6-a756-0a2208f43d51",
    "source_id": "b9081881-a5a7-486d-ba24-0b58440ff1ac",
    "version_id": "bbd4beac-0111-4f77-a144-a2d1da4cc7c0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ffcd3530-338e-4f2b-9717-c47e11145a96",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "09df34711a42f2f33e5da49d5ee4a6e3f2e9128b3bb6f58eabd40722f9a88a74"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
