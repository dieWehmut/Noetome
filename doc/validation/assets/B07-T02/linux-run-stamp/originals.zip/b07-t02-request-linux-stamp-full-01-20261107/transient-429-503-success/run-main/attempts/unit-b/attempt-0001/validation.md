# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ccb986f4d63b189420401ca8327076eeeee6e22fa909491d83fe33fb6c677f3e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "022ac7a9f417b3d69e2e970e715fd66a874367737f492782924a01341fd80564"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "64e643c74502e2339cecfc4ac27bb3b17fe9c1187d8dce63440855691c7fdd52"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "cf6ff8a782dde03fa90351aff58a9ad861bc2c306272a32a994d02dbcb72aebf"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f96c61b675078f16eb41f4bc0880b791654017326edd1545f8b1f322c76b70f5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "69568b3afc6442d0d7fc823c2109f4e0224e986f8f9456396cd2483b3a6d7433"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3a780e45-ee5d-4c3b-add6-7a2c24fc8cff",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2d115fb5-d272-4dd2-bc5a-838738f753ca",
    "source_id": "d4cff056-4691-4a48-9bb3-ac7daba5214d",
    "version_id": "3031e62d-64b2-4b10-8735-cf25244be17f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bf067f2c-8871-4dd3-b3b7-a2163367bc4a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f96c61b675078f16eb41f4bc0880b791654017326edd1545f8b1f322c76b70f5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
