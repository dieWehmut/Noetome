# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e4d6109631c71d9b7f298cfb300c635443f44a0abe4b92ea2b1f08caaac63644"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "05305b6d4a31f7d4567197ae9202efe7c44c89ef5f5b82a69e8c6b9f7f95cf59"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ef0d2a356715dae3694122486ede50a15727558dcf756e5f995b11ba48911c36"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "991b13fccd8661f0d60d7e46dad116a9256c0e6719a5e05a582927a8927de8ee"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fd4b452cf631cb9273b6e51af5818e45cd1d7b96ace38791a352d4cf94540230"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3c6d20f7943651163ef61c4fe0b5ee4288569b88a70c340aceee985befb58358"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4285f5a7-bfc0-448c-a489-eb43d0b007db",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "da01e28d-8fcd-4940-b8e5-8bba0f2f5556",
    "source_id": "740da3e2-96d0-476b-9c2a-337034fe7b35",
    "version_id": "62148218-c0c0-43fc-b83f-6a10c8c56974"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37527/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5976ac95-f15f-49ae-9f3b-f4e85f660166",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fd4b452cf631cb9273b6e51af5818e45cd1d7b96ace38791a352d4cf94540230"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
