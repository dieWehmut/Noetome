# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b7165c580446aae734e998b0f84ba57695cf23993aeff89efc2be2cc2f099d98"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ad2d1724c2013fb1a0ac4e7479c7996c4ba858c2f4d53f182a992ae8dfd5b38d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f2c126a36e845c459a9c9d1b3daf3608428e4a05f6e9f2fe10896ac979963cb5"
    },
    "request.json": {
      "byte_length": 2229,
      "sha256": "a177e5937d71c169041802eccdf53eafc32187e472e338ae4e913c8c701825c1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c94ae57822665ba3e9bd7d95cd7941e1c22c806d37ae5e8539f51e972f327e7a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bcf36db7c2856937ec67fdfbd260e9191a8e4969f38072b14467884279224c55"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4525bfff-0b8e-416e-b76a-87d2af5e767a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "24bd9f2c-8794-427c-bb66-201bae88f561",
    "source_id": "caf15b20-905b-4456-9d51-e1377df79413",
    "version_id": "058f325c-0292-4997-a5f0-4f287a868ac8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37077/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a262c900-e825-48cd-a9e8-1a711106c57e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c94ae57822665ba3e9bd7d95cd7941e1c22c806d37ae5e8539f51e972f327e7a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
