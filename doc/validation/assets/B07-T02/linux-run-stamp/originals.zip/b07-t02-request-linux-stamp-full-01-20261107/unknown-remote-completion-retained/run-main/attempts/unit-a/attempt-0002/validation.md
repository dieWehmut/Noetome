# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "af32db53f5e40b6fb3c8994283528d4752c565dfe75b832fac35add12f3b1022"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3449bdde677165da1610a431de41e160809bd9c83a889013e23dcdfe865ac425"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7f4c940e7a16ff330da2dc2b0fcacd795d906cd296a5bcec9b31e24203dfec79"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "ecf42e8f9be86b0ecc91f8a4353e6ae22323a3c7d3a638969fdd39c4f8827777"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "45c6bfca0b9690d950245a3da1431b4e79a3ac13966d3fc66faf23040b8fd210"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9487fbcc95ab36b705a186cc8d863c17afc1c2fc42a4dc507b20df8ae9403ca7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8a0585a8-d859-471f-870b-e6eac7040ea2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1190ac74-fc72-4b0d-a5d8-d8568a7b8bad",
    "source_id": "111dc42a-a279-41a6-8dbe-a584537fc373",
    "version_id": "d4859e24-1b7e-4658-9494-999b48036e84"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37401/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4fadfde1-0271-4a10-8a23-268791c88898",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "45c6bfca0b9690d950245a3da1431b4e79a3ac13966d3fc66faf23040b8fd210"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
