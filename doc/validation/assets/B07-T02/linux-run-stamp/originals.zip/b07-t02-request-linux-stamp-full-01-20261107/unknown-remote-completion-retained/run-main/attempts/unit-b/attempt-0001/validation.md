# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "13a9787758c2e296b24534e8ed40b2f614f84c858efcf1873ac8ef8f4fa09034"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9137e239e6311c58b9612eba6effd946893a29f03c657b86253eb35f47971334"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0fe71d6e29d447309defe928ba2867f7bd50ff8e50d63f0cdb80eac656e0ed37"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "02a85d6503523eba941ade34ca713863589eb037611271509e48512591a444e7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e211de3873fb9fe9863394849c347a265222d36834e2b50f9560164d01b2216a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2c9233cdfe67ec03f6d40bc699e9e9266f2107a69005af4f93895c20eb056a81"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d9343527-a547-4f7a-9ec1-2a839dc8c2c7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "02933267-3067-4baa-adb9-89d6c5a2b4e7",
    "source_id": "3ce40ac4-a4fd-4339-b05f-a0f27aaf1e7e",
    "version_id": "4b63a656-1056-4da2-b2ca-ec45caf10e92"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37401/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "622c0261-00f5-4917-b1d5-d7ec235fe9a3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e211de3873fb9fe9863394849c347a265222d36834e2b50f9560164d01b2216a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
