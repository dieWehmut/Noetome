# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6aeb57fad49ed90174291cbf99fabf0d52ca1f868be50b0cae11ff4a7fbb8c1f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "43fd581e843687a2d50a4ff0cbdf6e1679627cb61bacb4958197b6ce251ea3c1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "db582faa654114e58263b3ed0eac7c8fcab25c2215db100cb1f798b8063d9e94"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "3a6668586fecf8d31016d85bb8b16f95d1f14bed4bf850d5c83b5f940fc69c11"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7dc57f14d82d732a51db859eab23f512bd2a73b9e2162b2b452d7c69e8bdad97"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f9169f966573556a98308806bb9ea164df82644cece2bf81c6971af992a03359"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bbef6ed8-c3bd-433e-aaf2-ee8799bc2dcc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3e69a8cd-593d-41e1-a5af-72ccaba41b52",
    "source_id": "8bf0c77c-ed4c-458e-b86f-378039779410",
    "version_id": "f45ea1d1-a24f-49ee-9446-12cc7a6fada7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37747/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "370e39e3-faf8-424a-90a7-4f8b6ef8b1c0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7dc57f14d82d732a51db859eab23f512bd2a73b9e2162b2b452d7c69e8bdad97"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
