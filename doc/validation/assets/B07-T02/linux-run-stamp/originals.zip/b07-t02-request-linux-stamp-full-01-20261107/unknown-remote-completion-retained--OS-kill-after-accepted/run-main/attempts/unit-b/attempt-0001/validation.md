# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3c3e016ab163dd4b3fb69b9deacd847bb6f8c527b7d651c3971370f4ac815104"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b0238532b85cfb0c7bcb8a6a9915d2f30c65393ed6fdde2efd017ce2c40e8cab"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0fb29e8dc136f939bbbda0cc65734bc76ccf7888e0bb7c37cc444e8bc27aa168"
    },
    "request.json": {
      "byte_length": 2247,
      "sha256": "56342df852fb9b2533dd2d92806e7e21154d54c86ac73f851b4ddc126dc54933"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "458fa1b2a96198bd7256ff5a9b4853a8f3ee83a5d45c4a01e7315e8694a6ad2f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9728d56c66baacd6fb552d9becf47720fd054520044a3e263a32e347ad3f7ee1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2d08499b-aa07-4582-ad14-dc8e6e13a87b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "106c6b51-c82d-4115-97b4-c6d5548b0b6e",
    "source_id": "9352a172-67f6-4982-aae4-e90ad3bc2069",
    "version_id": "16363311-edc6-4f93-99c5-4aedd25b0070"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37393/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ae31b180-fa3b-48dd-b253-09796e8f6cd8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "458fa1b2a96198bd7256ff5a9b4853a8f3ee83a5d45c4a01e7315e8694a6ad2f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
