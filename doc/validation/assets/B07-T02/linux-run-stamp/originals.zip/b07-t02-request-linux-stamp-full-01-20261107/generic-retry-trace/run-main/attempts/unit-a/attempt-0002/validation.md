# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "29c55fb792bb211dec7db5dad9211184aa969df331757f90db088dd4049c4f0a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "de76452d01f8eb36273214075cc339c3c02e974c12343e7a8d18c9f23f617e10"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "01222097f517058b6c5ee1ddfcbd7a89f014156559c27d75c88ad51e4698bbc7"
    },
    "request.json": {
      "byte_length": 2208,
      "sha256": "8847089bf86a75349910c04b9323429a5370842dc6953b3228ec9c1c380a6123"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bbfe12d870ffe09b157f9d2d303420e8d59d611f7176c3536758926ef3876f9c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1822192ed02f3aded671eafacaced6766491dd0ce9c178a3d6b388a9bc880f0a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fb76aa93-f0f3-4a6b-bff7-af58a94a9487",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0f4d7cad-9f21-481a-93cc-6217d0332b30",
    "source_id": "d94fea4f-de30-4e76-93ab-fa85c1c041e5",
    "version_id": "20ad69cf-9748-462d-b77d-96ed62a7ee74"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37455/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ed6fdf2c-36db-466e-936c-65296d77bcdc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bbfe12d870ffe09b157f9d2d303420e8d59d611f7176c3536758926ef3876f9c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
