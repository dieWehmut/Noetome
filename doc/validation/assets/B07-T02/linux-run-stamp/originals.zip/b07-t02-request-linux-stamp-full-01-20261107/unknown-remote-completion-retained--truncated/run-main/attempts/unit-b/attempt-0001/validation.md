# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8efb7272d65dea7a9ffbbaebeecc9ad3a534a9480aba8b282c0ec8764707a334"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a2842af12b624117a56a8337d0d2091861c0fbe422cc2f4f1af361ed781d51ec"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "479c6ae4fb5bb8c7d4abe7be8e23a6d725b7a753a00f9805a24cbfb132549100"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "bdb077a270098996e4e38658a8b2b49dc90588a9f2cd675a5280e5e36884282e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e66d4b6553d26914f3f25f0fc70c13b2f65b427ba40ade9fafecb07a6a59264f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "670812c04cf8ae1039976519ae005bf4585bc318f8b27f9f2ea6b3807611e5f7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2bc4885c-6347-4c21-8e13-711c3e00b6cc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2f5a2825-5c95-4c5f-bd51-6ec81b1d72ca",
    "source_id": "4cbb3d6d-7dc7-4de6-bd12-951329c78196",
    "version_id": "e371641d-dea5-490d-b392-ef8e3af0c88f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37257/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fef14c7a-2840-4e70-abd8-84fc5308c1f4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e66d4b6553d26914f3f25f0fc70c13b2f65b427ba40ade9fafecb07a6a59264f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
