# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "72a59f08c069b2b1094471ba2022c6ea064a8918a0b4f9725e307537bf257784"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4c6a0db175da98525ef53d8f4a21c5293e5ccdbf9d8dbe3683f33c1aafa12f6e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ce9bbdb5c2b0f8ee164b4ff941c6b471774b58347c98a28734fdfdb89be1f14e"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "20af53cda375eb957722b28ee9e2fd173ee08ccb7aa8a548af1015f0573b6989"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2ea62b003ed9862d374ed34ba435d2c26c5282d3026e4b1693017133925a3614"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5b3be5cc25356cdf298a75f970c2898bd3316bb5015c77bcce609395d83e4ded"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a4e21fa7-f8a8-47ac-a3b6-acc4f69092e4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "deb4a77f-d27b-4581-9af6-9650287ba8ab",
    "source_id": "cb235326-abfc-40b6-a48e-f4c3886c9cdb",
    "version_id": "947e5641-784a-4d2f-8e62-0185b00e5586"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37257/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "87167311-cfd3-4d2c-935e-e6d514c427dc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2ea62b003ed9862d374ed34ba435d2c26c5282d3026e4b1693017133925a3614"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
