# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "05c9b0ae446d0370c25bf4f6400110cd7a1cdfb841b92014dfd1b8da38026e6a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5660aba93c5e559b5d5c2a68188831901105dbf2af622a10a4a61ad34a2b29d1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6ffb72ad172d9ef780284b457ae05a24d68919c094e37abd89d4174ad46f51b7"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "edb100e3ba0442ac09bb6fa4d2265b20bf687823b00e0e7958c0a73b65dbc7f4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2a7ac0d293409ad7f926352f36ec2f122a002dbbfdede67ba49aa3081bf148da"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a8fc0cb31f196da5423b26ddfe1b2746265cd69b88596d9e075e1fc841b685fe"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e9190583-815f-4406-8604-5ac43c247f3c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e9b81f96-6c04-46cf-91f4-1ae6c7f8e9fb",
    "source_id": "1567d2c0-ff5a-4345-ae6c-b375a4954ce6",
    "version_id": "2f050b55-9f6e-4de7-bea6-cff66870673c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0d75374e-39b0-40ae-a0bf-649b5efb257a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2a7ac0d293409ad7f926352f36ec2f122a002dbbfdede67ba49aa3081bf148da"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
