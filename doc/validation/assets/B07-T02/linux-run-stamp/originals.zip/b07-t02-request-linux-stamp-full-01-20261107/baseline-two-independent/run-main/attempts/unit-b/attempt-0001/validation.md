# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c861ced6e8148a71ccb2b1057ab1827301e4d3e63371c68e0b2d4690438aa9c4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "663a482785c38894b5a8a413c053be423dd1dff7706ae2e115ba20e8dd010b5e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2b579379803c4c02ddf2a60cbb6613af6d629fda90f9745eb84dfdedd502caaf"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "5c554aadaf625d90d794e5095c0d4b50e4e0932cc162c0fa7098200a952714e5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f6f526ce34c56d2affa9e41a82a7827ad340508cd580711abdf08fd28f9e72d4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5ed91ddf2e731436c3ccaf1a3b5f26c589fedb8c5c4c3bf2c85260e920879cb4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4093b1f8-b7c5-4dc4-8153-80c6c0f44de4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dbe3e747-c07e-4870-ac17-615e3888cfeb",
    "source_id": "2a5b2fe2-027f-485c-b2d9-9b5f06fafdbb",
    "version_id": "8b999e17-9484-4081-bc04-d76e06943473"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c09f4fa3-b5d6-4efd-905a-60fb5518dcfe",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f6f526ce34c56d2affa9e41a82a7827ad340508cd580711abdf08fd28f9e72d4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
