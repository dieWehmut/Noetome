# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7bc783e55f1718532ebf2f1cb14de6560e1694ab1a17660f3f6f4eece00a8b8b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a67cc1dd1cd7bc1c6803758e79857afaa007573455deb0c89bb6618de0f9efed"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c521471f1dccaca0b8c010b75d78b647d9232b15e56a74d3d647b1ca6d265f44"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "0648b9d08bc723cc582c5023232dd74423ce0a1a8c447d6505bf8850374ef449"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "175070e55862c7010814e55ab3c913ea0b59291f7ca0e6e9f4007ec924e14cbc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7a50a80e0c83ba53c0d620650d49a4638b1211622ffb521ee6603d7a7f40afd3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "049bc43c-1af6-4ca5-8b4d-3398c00d0c6b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "035eb2a1-d184-4932-bc66-87a022b66286",
    "source_id": "7a371599-ee11-4393-8018-789b40ec00a1",
    "version_id": "dd9f6175-75ac-4950-b618-77b28e5bdd0e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37745/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "831df693-3739-46af-aae3-37a441ff4978",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "175070e55862c7010814e55ab3c913ea0b59291f7ca0e6e9f4007ec924e14cbc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
