# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ec20a43dbf960ebd14371c6d1a7b8294831721ace7e005b407b0c8a4d3c61ce1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fbc210767f84799fabd25b64a7a8352333796ec7708bc3393d7883789b8fa7b9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "522acec1306e34b81bc5a4dbab295074480e90b21d2121c0ffb3110f47b0f902"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "c8ff0f02b2e6c04fa6445550047e28d3ebfdecf5a66da70a8e2f92e85dd799b3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "56cb0d64286fedb5048b6bc8578014d352029500737832db0e09b9c98a816d43"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9fc28fc4fa1be89637ea7a87a5d7c78b25b93a8c91bc7684c10b05b7a47c8eaf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d5864aab-14b0-4455-9a02-74150ec46cc8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a645d5b5-ea2f-4185-be60-bc7c97b952dc",
    "source_id": "28fc9aeb-f858-4f26-976b-f6bc2896be4e",
    "version_id": "ab8abd84-01c8-4e15-9cd2-635793a0311f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37999/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "36ffbecc-fef1-4959-afcb-ae9b9309da40",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "56cb0d64286fedb5048b6bc8578014d352029500737832db0e09b9c98a816d43"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
