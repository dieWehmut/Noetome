# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "51555545e60eb52209dfe1c69b3a8a026733ce93325fb39ccbcd34d63283deab"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "557147413afc19f2c7c35dc4357d56bf03b61edcffd00f8471892df704641d20"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1f1efb2e537422fb15cab3c0d75628ff0939472ec331d65da22fbfee17b6a7b6"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "b762421b3ca2bd5f105726c663e396964c5396adbd9026d3ec2b22fff8098e2c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0878311c00cbb77d06aca62fc1b87a7abe67c81f7c56f8e6489fe878ddc07b2d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "557ab681ba776e77aef3248bc1b434c80467d491ffaa42c8ebfcc62f35b0a5a8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "60a5ca37-6cb9-4adc-8bd6-ec90c619a2c4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a3360f75-3c76-4e15-87cd-bfb207948640",
    "source_id": "5330ffc6-6b44-4d7c-83a2-032b78f42ab7",
    "version_id": "7efc0684-a68d-46c8-a232-0f11ca8f7cb5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37233/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d59c913a-e9b0-4ccb-8295-b3c5cd16d496",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0878311c00cbb77d06aca62fc1b87a7abe67c81f7c56f8e6489fe878ddc07b2d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
