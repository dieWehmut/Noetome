# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5b374cc8fb23c72fa8dc85e3685469479a4498a947c7267ae43ca89a1eaceb32"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5b93ac8c87a39cb5e2040105c6715b3b5a2c14338918913c99dda01d5dbdf400"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f6c29eb1e26907a4116fd6027ca2cd5fde79f72baf05c08d1e95fa9be2ce10cb"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "cb05fb986c3470f307114174afcc91998b5a218e920c6e31c3589aaddfd15751"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3e418d706afbe2f11662b792f3bbc62959ef98b1e3875f13e69fcd8393ba38b4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "eef440efcdb0c5f57d0139d6e90597c9bd56bc2614257889d13e6a3d561ad5e5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1d0c20a6-4dbf-4e1e-a599-2c95f2246e62",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "793b9f2f-0157-487a-a26d-f94929f443ae",
    "source_id": "c016b036-5074-415a-8236-b4141171d40b",
    "version_id": "e3afbc1f-157d-44b9-ae13-5889dad2b2c0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37537/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "85101ffd-f756-4022-86b1-1a8e7bfc37e9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3e418d706afbe2f11662b792f3bbc62959ef98b1e3875f13e69fcd8393ba38b4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
