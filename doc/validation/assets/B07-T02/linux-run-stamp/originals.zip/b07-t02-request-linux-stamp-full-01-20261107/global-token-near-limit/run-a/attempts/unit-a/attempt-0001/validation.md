# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "957b90a5160eb83e6876575b760145ed7f336ac922acc43c6849a71a458dd56a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "acc69bb57107406d179339e005a5634e6b823a92d9eb4c42172583b8e9ce7edd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "37b250ab78bfd1e714969b9c4392de3efc2426e4efe78c6e8d08efbae5792376"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "bace2f41839f6082947e048f6f794ae46ca3906613f00d67ef73abb2b762f34a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b4ed6c90daae13c4a7b2ee08f3615927475cb876684600cd7c3807c0b4311da6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b3f77471c0a9e48258f37b4eb83de97d59124875d077f94ece41ec31a45c0b6e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ba956fcc-f657-402c-ade4-2c70f0436af5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "62fa3f22-f071-4ea7-9add-97cf5c3a27cf",
    "source_id": "f0d2fdbb-68c9-4ea5-ac63-467159734407",
    "version_id": "60375362-2b88-485a-ba81-d2fddf565f53"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36873/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "50748ad0-c491-474d-9f13-83cba4850dbe",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b4ed6c90daae13c4a7b2ee08f3615927475cb876684600cd7c3807c0b4311da6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
