# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5a6ad0aa63d09cfe7d5f2e0a80e91cc313501d0fb2f197ac0b778bd656f4b4c8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "94aa8b91b51c505c4348a9b090acfc187be4eed52e0942d7584a47d0d1274737"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e8ef3aa8365dd957e3411f59270f0bc7b70b9660317fd62723fe289a2684050a"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "fdf99bd672c2161181717c07c978a101479d34037b768e0441e20f0db74b758f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4e34a1db2caf384c2c1da1f41271f369c63d3c2df9216fbd8608903ee5714cc0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9eb833fe5222b4bcb532a45652face7962b1de4bd6c20f8cf6859e07d1cb8d15"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1d5a4e87-28ba-49a7-aa58-d68cb7dd8dbc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "243eb2e1-7862-4dcb-a8a5-84ed63bd12e7",
    "source_id": "6f3f187a-795f-4940-a953-401d5803dd99",
    "version_id": "58fa962d-8b24-4298-a984-7050067f6151"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37873/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0e1b2476-85a1-4b5e-b1ee-0e33e237960b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4e34a1db2caf384c2c1da1f41271f369c63d3c2df9216fbd8608903ee5714cc0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
