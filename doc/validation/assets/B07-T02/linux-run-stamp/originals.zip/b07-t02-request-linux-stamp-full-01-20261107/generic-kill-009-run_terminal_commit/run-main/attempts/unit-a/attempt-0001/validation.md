# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a0cb1cb28203dd26d3ba9844e1bc9b55b1ef456b2ba26cd6e76c16a144f48f31"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5e0b46b3d74220a72469de18a0f388a4de78c735f6535d1f833c0db44e3bd53d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4d9d77d1b72af0d25737f28be48b0f285d9f791ba39f3028232255b707c72492"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "8535551c0846f5096f5b397d73a4ce77e4a5504d7f64e379a5c9fc42896d70fc"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2c8db0123c87e7cb61d3a880554b03e555db7ddd27c04525c5e2114dd1129d0b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "28ca955fbe0f85c62cdbf62d7291fdbf98308f7c92be34bf337ad6ecf0cb84dc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "25ad671c-a7cc-491b-8897-58875f0bf341",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d1913548-9b58-4cf2-8b70-e254541e33e7",
    "source_id": "e4158a70-773f-4cea-b8fa-5d6bd7d7b716",
    "version_id": "ff14b165-7531-41f4-9b21-62f1aa318c94"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38357/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7ede29f1-6470-498d-a942-99d2efe37039",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2c8db0123c87e7cb61d3a880554b03e555db7ddd27c04525c5e2114dd1129d0b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
