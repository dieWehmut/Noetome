# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "72ca9e925d8237d7772f8a8dfbc2af04ff2c584d58af6d219a68e9dc1f38d82e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7ea86720ef563172c3c2d0f06b691b5352e176efb69e1d9cca30f2a826f75871"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1e2a9f350e8578d82373ce062f875af2c2df9c4741eded72db02fdea75bca4c7"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "0bb8a255a6e380d15638ba0b0ed1a23cf8f4c1012975aab809228de9c1f30ea7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "aa4146376c64839c4afb23a58a3380f21964d3f572315e661fd9ebc3213092c5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "673913eafdd19297a11be6e7ff9d8b8abf7d7edf349d0f3dea2c960ed395bc66"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f05a2db3-3ad5-4380-872a-1cae64cfeb56",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f6620d7c-4526-4a3a-8371-4103ee1b8399",
    "source_id": "2f9783bf-db50-4932-9102-d0e90eca83c4",
    "version_id": "d2846c8a-e3f9-4b1d-8ac1-23929630206d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37919/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "93197383-ee41-4965-b0fb-cc1519fd076b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "aa4146376c64839c4afb23a58a3380f21964d3f572315e661fd9ebc3213092c5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
