# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a1ebb8136b1cc73cf2e3bd123d9c8dc9e500a1e060ea4fe4608b3e0ff5a638df"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4ea2da354bf433195ae2865ec026ba612f2d0f7877cf52adfbccf2307888a1b1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8ac045ca2738b43bc27791545cb954249aa474e1b669a27d838a45255b45685d"
    },
    "request.json": {
      "byte_length": 2209,
      "sha256": "565a53e437762c9f46ddb5cb16989df96b01973d06e9a5b4ba836da1787e3735"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "573ee143f456a50de97945189f88599e9a269a94a8ab09762ca1cf34d1c21519"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "563999d03c26136d064b87409b8c9530fd4f646e4b9a22bb3a14407c9e56923a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "04a2bf17-4291-4173-84ab-53023296c8fd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1756a38c-20c0-4e13-8575-3283a5008d11",
    "source_id": "f930de42-e6b7-4231-adca-fd31e3d0e8c3",
    "version_id": "7c290353-4109-45b5-a9e3-a90691768e82"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37577/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1bdee1c3-5364-4755-aa00-8fc8c62b9104",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "573ee143f456a50de97945189f88599e9a269a94a8ab09762ca1cf34d1c21519"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
