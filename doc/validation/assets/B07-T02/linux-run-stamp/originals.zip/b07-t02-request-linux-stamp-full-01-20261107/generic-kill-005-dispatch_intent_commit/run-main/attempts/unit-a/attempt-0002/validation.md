# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "020b9ca90068a7dbd51dff923cc711b3e9cf97495036d3879bc6b20b7c61d356"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ff70b89e8f0a57f5c677e3704f8993cc4bf17fbf9904ffdc13668138da3e45d0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f1347c3d79618f10534162746c79e281af5542e1b1846f5ae733601f810d2bae"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "d7dd2d48531e8420e67d660648a2d401ff0aac58be28bafee05a6b44319e1cfe"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6e8c534d856ef0735612952b50e9003c26d445bf739c417982e3a8d3de243740"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7b25baa0329e5dfc2b05b08a19abe0e39a96ba8731599092b6e0e0f9a72c998b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "da93e1b3-1d8f-4a06-ba75-15790516a94d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8ec93bd3-3f7f-4808-8281-475895ae2bee",
    "source_id": "98652cb2-69f2-4ba4-94a3-3f94f1d96ed4",
    "version_id": "d26f248d-03ff-4f74-bae3-62d3f5f7bf4e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36611/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dc8c4fe5-66fa-4747-b19e-36b9050df91a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6e8c534d856ef0735612952b50e9003c26d445bf739c417982e3a8d3de243740"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
