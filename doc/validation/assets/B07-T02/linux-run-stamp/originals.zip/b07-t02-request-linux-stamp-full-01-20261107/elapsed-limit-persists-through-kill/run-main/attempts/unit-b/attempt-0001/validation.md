# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "511b5b2cf973d22fe38c6fb496226df2b9c7335642296de3ca6592d4c94c57c8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ab0837d00abee49d4775ffdf3847b53e983b21976a3116a722890357ac17b15e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2e16202e31403deb88c9f010b5ce9abd6fc7a4b0e4594a4cacdf2f6379409ef6"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "18839f24e5a0eec12052746e5e25ba261b12d0da26b9ac8bb8626fd685938694"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "24d2a636b71ebefefabeae7ebf5acee4ea67272bccdfcd3adb8336c3c4ab33fa"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "dc335df908b2bf617440c3900265f71d4af89b8f90580f690b34572d5e34cc66"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7ceb012f-d94d-4bdc-8590-097bbb54a8fc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1ff1bd64-0282-4668-aeb0-4f6663e4367d",
    "source_id": "ab1d91ba-546c-4e32-a4c4-3b96b53a38a1",
    "version_id": "bd297055-35ca-4f18-b009-3e9f45b94f61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37253/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5a4109d0-34ae-4cd8-9182-f60b2a1faa23",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "24d2a636b71ebefefabeae7ebf5acee4ea67272bccdfcd3adb8336c3c4ab33fa"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
