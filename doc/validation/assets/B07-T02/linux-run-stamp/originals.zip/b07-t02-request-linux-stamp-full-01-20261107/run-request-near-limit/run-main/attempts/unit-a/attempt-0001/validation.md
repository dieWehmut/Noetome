# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "756200d83f43d49e6cc15c7190d5ff939581c8d429283cd75496afd58a28cd82"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "852f4076b3fd3521b06fb4d14d0e81548aadd77012d9873e1bbfdd5528ccb59e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a1695d0f544943ddbc624c515c5ea39efc534af0cdc1c0a91e092adccd79ba1c"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "45ad3ce3a76782141e651d2d511969bb3bda8437490c98b954d33550e846f796"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "798c299f1ebc7422863d2064ba49d9d40626e17c30dea12284fa693b5a4ecf5f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "18106c60b10ad99e8e03e5f1be84898b18e03a4fc375fee8e9ca7d3904bc08a4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8fccd1d2-41e5-435b-ae79-ac45445627b1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "95182f74-3e56-4a77-a86e-7bcaf5389713",
    "source_id": "a5b09232-e6be-401e-8876-f1499b2280bf",
    "version_id": "aad07be5-d138-4980-9ea3-5f3785983e70"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36489/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a7beb8e7-7341-445e-89c0-3d93725f5448",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "798c299f1ebc7422863d2064ba49d9d40626e17c30dea12284fa693b5a4ecf5f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
