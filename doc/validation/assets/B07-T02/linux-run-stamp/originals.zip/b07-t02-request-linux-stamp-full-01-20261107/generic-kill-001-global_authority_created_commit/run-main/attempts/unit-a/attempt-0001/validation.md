# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b72c52668aebff15da0063df24dfd77e152891064a49262420d60d060bdf9c1e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "63804a95479b616b214f665e3d426faffd4c06ff991a761df08ad1920651d12d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "002071078567f5e0ea9dbf26133e2856b408823ca52eb88657441b9621933143"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "9c27f01731d23e9143028e0df7a5738133274fbf45a6ddd38c108ce1e6cfe1bf"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7ecb6ffea20226d86cead6c46159ad3e8235dce15908dc7663a15f5f33bfc256"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "68f3b9503d45014d45a50ba789aa7924acde91c0a7b4ed68eba99f12ff08a898"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6cf2a5cc-95c9-4f29-96a8-4b91766875ed",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8a100c38-52a4-47d6-9904-411b87694a55",
    "source_id": "5e822bac-92e3-4def-9a76-e97d6623825a",
    "version_id": "106ef764-4dd0-4b37-90e5-ef438598eb4f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38099/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a621acc6-ea81-4b82-9d9b-30e589aa3eaf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7ecb6ffea20226d86cead6c46159ad3e8235dce15908dc7663a15f5f33bfc256"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
