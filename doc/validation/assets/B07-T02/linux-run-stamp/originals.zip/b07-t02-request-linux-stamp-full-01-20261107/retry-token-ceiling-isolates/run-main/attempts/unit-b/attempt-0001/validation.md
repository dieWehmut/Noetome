# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e1356be247d6da274ce008a3c00f9628e8d3ae854c3cc4c48a1acd6c1e8f2d03"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6e52782bdfb310079fb2b6acb554129ee1a7f6bfd0564b169319c7c309d1348e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4a00cf6e299be9c3bb6e300b6434251bc930a4c7afe4bf32363a513cca8d1b31"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "eed1e2059fbb1db137ca64ac01ae3ced23dd6d2eff67538da8ec1774dd7109a1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e6e0314f53fdce7bfce9296d2e3288172ac4a874979042ee2e86289d91a587eb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "738495df19f7a5d9607ace5fcfb5c1c11c3b376150973c423e4f079ca095d4fb"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "148959bc-8d4b-4cff-9f70-99e14ecc4738",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a6d62007-c67b-4b24-a953-6b4a1f970af0",
    "source_id": "9079f35a-ad24-4bba-87df-851ad1ea0554",
    "version_id": "f9b6f9b5-582e-4c0f-a317-5ceaf837b0fa"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37135/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "35310837-aae3-4aa4-9e5e-ffd89dbb789e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e6e0314f53fdce7bfce9296d2e3288172ac4a874979042ee2e86289d91a587eb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
