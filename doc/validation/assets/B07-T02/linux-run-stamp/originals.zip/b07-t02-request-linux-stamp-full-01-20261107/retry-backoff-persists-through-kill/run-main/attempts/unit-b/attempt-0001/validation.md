# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "68f54cc5584ae777070689be843c95b0f79d0cc6d4c03053688cdffa9ea54ccd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "694a6c9587a729ed6b071710b42a93f42a0dc20a9f7cb40789b8272978d3e1fe"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ff4c2f5c3b2b71c15e2bc4cfe71564c13203c3234b6686b5a058586fa8568837"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "00f3c73e874b287f5c10a16ff673d579594d684b72f8368e4ab3f0f1ae09a6b0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ac28c11f652c5e5a9eea49d7a5eff643c8cf3f6862868fcc7dadb6b7f0aac7ab"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "97f4312a01abba840bc129b6c0c30f26373003d29d7a98697d7f6fd3793f4f2c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3e50f278-24df-4cbe-9ecf-ddae37144756",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0e7794a9-8559-49ee-b8dd-02b92e1b6802",
    "source_id": "2db1961f-63cf-4484-a0ab-7d1eb0156723",
    "version_id": "1fbe58bf-b472-4434-a2d4-a2b1ff52bd45"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36887/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6dbe9055-f6c6-4656-867a-4caea176a675",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ac28c11f652c5e5a9eea49d7a5eff643c8cf3f6862868fcc7dadb6b7f0aac7ab"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
