# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0291110be8cb2ed203e10c6b65cd8274553d88be0a649a07807b65da666cca52"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3ff6e69692d1dcb13d39fa37400fb4493293925c8553b3c864863f74cdcfba3a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0c04c1aa64081db4671540d8428a34d1922497cf77a3413f7991bf8c0a5d693d"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "9de4f41e78564399dab984cd1fe63d00f644eef818504e510bfc491aea644bf9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bc589fa77685b6780b63c50d8821c3988314388c56cb009ea2fa15322c390be8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bf31ce70bfde34913d2ab1050932a0821563be29223faae0417587b09f1447bf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0e702d83-7bf9-47fc-b724-954cd786c464",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fab05f7e-a193-4401-848a-3f5538300896",
    "source_id": "5fbbf8aa-6aff-4f43-a61c-53e8caa37458",
    "version_id": "c52056f6-ae64-4147-9b72-c2f0f7cc8a04"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37609/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "66e50db5-dc98-4de7-afad-11a4cc4c8e6f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bc589fa77685b6780b63c50d8821c3988314388c56cb009ea2fa15322c390be8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
