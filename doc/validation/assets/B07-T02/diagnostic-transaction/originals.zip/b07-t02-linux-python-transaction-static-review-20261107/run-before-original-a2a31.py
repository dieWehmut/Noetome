from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,re,sys,importlib.util

WORK=Path('/home/lyinn/project/Noetome');ROOT=WORK/'.artifacts'/sys.argv[1];ROOT.mkdir();REPO=ROOT/'repo'
PYTHON=Path('/tmp/noetome-b05-t03-python/bin/python')
CLI=WORK/'.artifacts/b07-t02-linux-release-pair-01-20261107/noetome'
def pin(raw):return {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
spec=importlib.util.spec_from_file_location('native_source_selection',WORK/'.artifacts/b07-t02-windows-runner-draft-02-20261107/runner.py')
selection=importlib.util.module_from_spec(spec);spec.loader.exec_module(selection)
names=set(selection.source_names(WORK))
names={n for n in names if not n.startswith('target/')}
for folder in ['scripts','tests','fixtures','crates/noetome-cli/src','crates/noetome-cli/tests','dev-log','doc/technical','doc/execution','doc/standards','doc/templates']:
    names.update(p.relative_to(WORK).as_posix() for p in (WORK/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and not p.name.startswith('.'))
names.update(['README.md','AGENTS.md','.gitattributes','.gitignore','doc/README.md','Cargo.toml','Cargo.lock','crates/noetome-cli/Cargo.toml','crates/noetome-cli/build.rs'])
def pins(base,selected):return {n:pin((base/n).read_bytes()) for n in sorted(selected)}
def source_identities(base,selected):
    result={}
    for n in sorted(selected):
        p=base/n
        for parent in (p,*p.parents):
            assert not parent.is_symlink(),str(parent)
        before=p.lstat()
        assert p.is_file() and before.st_nlink==1,n
        with p.open('rb') as stream:
            opened=os.fstat(stream.fileno())
            assert (opened.st_dev,opened.st_ino)==(before.st_dev,before.st_ino),n
            body=stream.read()
            after=os.fstat(stream.fileno())
        current=p.lstat()
        fields=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_nlink)
        assert fields(before)==fields(opened)==fields(after)==fields(current),n
        result[n]={'device':before.st_dev,'inode':before.st_ino,'mode':before.st_mode,'mtime_ns':before.st_mtime_ns,'links':before.st_nlink,**pin(body)}
    return result
work_ids_before=source_identities(WORK,names);save(ROOT/'worktree-source-identities-before.json',work_ids_before)
before=pins(WORK,names);save(ROOT/'worktree-source-before.json',before)
pair_guard_names={'noetome','actual.json','source-before.json'}
pair_ids_before=source_identities(CLI.parent,pair_guard_names);save(ROOT/'selected-pair-identities-before.json',pair_ids_before)
CLI_SHA=json.loads((CLI.parent/'actual.json').read_bytes())['cli']['sha256']
pair_source=json.loads((CLI.parent/'source-before.json').read_bytes())
current_pair={n:{'sha256':v['sha256'],'byte_length':v['byte_length']} for n,v in pair_source.items()}
assert pins(WORK,current_pair)==current_pair,'current Rust source differs from actual selected CLI pair'
save(ROOT/'compiler-source-binding.json',{'source_build_receipt':str(CLI.parent/'actual.json'),'receipt_pin':pin((CLI.parent/'actual.json').read_bytes()),'rust_cargo_sources':current_pair,'current_exact_equal':True,'scope':'actual release pair01 Rust/Cargo input bytes; full Linux Rust not run'})
shutil.copy2(Path(__file__),ROOT/'run.py')
for n in sorted(names):
    path=WORK/n;assert path.is_file() and not path.is_symlink(),n
    raw=path.read_bytes();assert pin(raw)==before[n],n
    target=REPO/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
raw=CLI.read_bytes();assert pin(raw)['sha256']==CLI_SHA
for n in ['target/debug/noetome','target/debug/noetome.exe']:
    target=REPO/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);target.chmod(0o555)
    names.add(n)
(ROOT/'temp').mkdir();(REPO/'target/compiler-temp').mkdir()
snapshot_ids_before=source_identities(REPO,names);save(ROOT/'source-identities-before.json',snapshot_ids_before)
snapshot=pins(REPO,names);save(ROOT/'source-before.json',snapshot)
env={n:os.environ[n] for n in ['PATH','USER','LOGNAME','LANG','LC_ALL','TZ'] if n in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TMPDIR=str(ROOT/'temp'),NOETOME_TEST_BINARY=str(REPO/'target/debug/noetome'),NOETOME_TEST_PYTHON=str(PYTHON),NOETOME_PDF_PYTHON=str(PYTHON),NO_PROXY='localhost,127.0.0.1',no_proxy='localhost,127.0.0.1')
argv=[str(PYTHON),'-m','unittest','discover','-s','tests','-p','test_*.py','-v'];started=time.time()
with (ROOT/'stdout.bin').open('wb') as out,(ROOT/'stderr.bin').open('wb') as err:
    p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=out,stderr=err)
    save(ROOT/'launch.json',{'argv':argv,'cwd':str(REPO),'pid':p.pid,'environment_names':sorted(env),'selected_binary':str(CLI),'binary':pin(raw),'started_unix':started,'real_model_calls':0,'paid_calls':0})
    code=p.wait()
snapshot_ids_after=source_identities(REPO,names);save(ROOT/'source-identities-after.json',snapshot_ids_after)
after=pins(REPO,names);save(ROOT/'source-after.json',after)
related=names-{'target/debug/noetome','target/debug/noetome.exe'}
work_ids_after=source_identities(WORK,related);save(ROOT/'worktree-source-identities-after.json',work_ids_after)
work_after=pins(WORK,related);save(ROOT/'worktree-source-after.json',work_after)
pair_ids_after=source_identities(CLI.parent,pair_guard_names);save(ROOT/'selected-pair-identities-after.json',pair_ids_after)
named_equal=set(selection.source_names(WORK))<=related and selection.current_source_names(WORK)==selection.current_source_names(REPO)
stderr=(ROOT/'stderr.bin').read_text(errors='replace');matched=re.search(r'^Ran (\d+) tests? in ([0-9.]+)s$',stderr,re.M)
result={'status':'passed' if code==0 and after==snapshot and work_after==before and named_equal and snapshot_ids_before==snapshot_ids_after and work_ids_before==work_ids_after and pair_ids_before==pair_ids_after else 'failed','argv':argv,'exit_code':code,'elapsed_seconds':time.time()-started,'tests_run':int(matched[1]) if matched else None,'result_line':next((l for l in reversed(stderr.splitlines()) if l.startswith(('OK','FAILED'))),None),'skipped_tests':re.findall(r'^(.+?) \.\.\. skipped (.+)$',stderr,re.M),'stdout':pin((ROOT/'stdout.bin').read_bytes()),'stderr':pin((ROOT/'stderr.bin').read_bytes()),'source_files':len(names),'snapshot_source_unchanged':snapshot==after,'worktree_source_unchanged':before==work_after,'named_input_inventory_unchanged':named_equal,'snapshot_source_identity_mtime_unchanged':snapshot_ids_before==snapshot_ids_after,'worktree_source_identity_mtime_unchanged':work_ids_before==work_ids_after,'selected_original_cli_and_receipt_identity_mtime_unchanged':pair_ids_before==pair_ids_after,'identity_scope':'actual selected ordinary source files, two CLI aliases, original release CLI and its actual/source receipts; no directory identity or full Linux Rust claim','ordinary_binary_aliases':True,'source_build_receipt':str(CLI.parent/'actual.json'),'real_model_calls':0,'paid_calls':0,'scientific_quality':'not_run','full_linux_rust':'not_run'}
save(ROOT/'actual.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='passed' else 1)
