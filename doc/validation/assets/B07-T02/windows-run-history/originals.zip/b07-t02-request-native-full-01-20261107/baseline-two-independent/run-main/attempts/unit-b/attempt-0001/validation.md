# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "17418a6911760ad77fc898cb91ebf6132e70e376c982b19ce84eb7cf78a9f409"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9bf670a1e02ccf30d25b67fd97938e6311cbcb507d6393d8c7e77c43843b0972"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "40876d785108425e2355497ff4f0019687095811dcfe98ccb2286b1d96a128f8"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "fa7c9bcabd34ba8c3abab6d28bdb9aa215004a9558be4a32c9d2057946f7f9e5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7db9ed827f585931298a38d17f38943aac946fed8771fcead048aa83e21ee2f0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2f05650749db5acff68b32c5024340b634b63ebc0e273618fe92fbfe415ff108"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d376fab0-b42c-4f1d-8d9a-ca37b2a0ae84",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8303db1a-3c6a-4188-a91e-a70fd474c86d",
    "source_id": "6001c996-2afc-43e0-b1c3-b763b7af9780",
    "version_id": "ed919c76-6591-478d-8124-b0a1771bd201"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55509/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8b19f33c-8ab0-44fb-9a9b-d5a8e9471984",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7db9ed827f585931298a38d17f38943aac946fed8771fcead048aa83e21ee2f0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
