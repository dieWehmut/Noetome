# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f7b90d7477dfb62d2216801ab8fce96dff035442ab9f00f45952a10b0fc4e311"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "95e9ac4cbaadaf046449fd0447296fc317054e61625d3811955d4d6e21089be0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "417e2074130f749ef32228bc677e641c64c129cab13aa1e77737c041682c2520"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "bd11d0b8f5dcc30e2bfa1e1c6be421b2d652c5754224fe5735f935ca9dc04d59"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "95a91bef13f9ebe4f4885b5734af6ffddd71b497414b2b2f19eb43c94e57a400"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f47f12eb97fdbc5439d9cdf40a77bf89a646c3ef2e692eda4867718fe97bb2ef"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d1f731ad-f3c7-4ea3-a1d7-53420051658b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6345e486-3f23-4aad-b8e1-7ef1b1bae3f4",
    "source_id": "baa7f377-05a6-47d2-a9d7-f4e368bd6dc0",
    "version_id": "2a6edc9a-1ae6-491a-a26b-cbbba870800d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55509/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8242473a-bd76-4f30-97d5-3274f1ad7294",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "95a91bef13f9ebe4f4885b5734af6ffddd71b497414b2b2f19eb43c94e57a400"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
