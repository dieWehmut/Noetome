# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6626d5e8f1d4e245b7ef04711af83a74c3b5c06573a7417812d52f6448eb6608"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6e302ad0e4fb5a319c4d8ea3d7b6c0e444d2265f599ffe350ef96689fdaa8bef"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "49bc98a8a70b385a2fc15d0a8f359e0ab9f5c5f85a3dd7ad75e5a25288a22695"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "2f51c8b82b67df287ae9ea7a31e4b6d81096a2fd55890b55b42f98152fdaec30"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ef9c89e044edc5e0502f7b0745ff0811a28ee8080e9f5572ccb2a9d7365f1afa"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "834e5c1a62518c56241effb24b1d1fa720e8baeff340262e4c0cf849476119df"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "efdf342b-145c-436e-acc4-8cdc7490aa07",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b91814ed-ed45-42f7-91e3-a944b21036c6",
    "source_id": "bfc3703d-da64-4f3d-a47f-da3726886a3a",
    "version_id": "bff7f91d-4e1a-4b0b-8685-75ecedf5cc46"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55520/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7231e1eb-5c42-40c6-84e8-b164dfddcdc3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ef9c89e044edc5e0502f7b0745ff0811a28ee8080e9f5572ccb2a9d7365f1afa"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
