# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "844ef26d987c25d5ce06767b423f2a8e7d30f1e86ca4a39e01b4cf15ce514be6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "00e00a03d858eec9fcaf41a29df7ce72c607dd6b8b1971b5985cfe761a131130"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "34364539446da11e2a19e10c5bf0e1485b7ff5804b484888c5052c61bb8d40e1"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "ba8d6333394355cafa820e253564f9c5ccc73ca0cd03174ad1c072ffe8537e32"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e79a4738a37f73d7ce24963d66b49b260154398a129ce5f8067c35253f4f6050"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0a1a93d50637c1a8246ac8046df2b5dcf73cdd10e2d84c26d6e622583f8f5625"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "075e30df-d530-43a9-be5f-de2271ca5483",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0348b199-9065-4de6-9c9d-d901c70504da",
    "source_id": "42cfc952-12dc-435f-b2b4-bcaec465c071",
    "version_id": "d2662eaa-ba3f-42ed-a3a7-b7f0b6118fd5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55520/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "52a3fb6a-2d19-43cf-966f-2efb84a0106b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e79a4738a37f73d7ce24963d66b49b260154398a129ce5f8067c35253f4f6050"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
