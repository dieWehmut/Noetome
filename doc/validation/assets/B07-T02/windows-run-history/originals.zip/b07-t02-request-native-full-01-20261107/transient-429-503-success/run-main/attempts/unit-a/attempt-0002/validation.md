# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：503；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2d885d10a251f6c9da376ff5ea92ceded54291de2bfd857eb886508547f50b3c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4d7ff2dcb082af26de210dc9d8b8ddc5cb9d408a5189480e4afb2064c2070ae6"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "8482d35cb793c170fa5ff5d827a4dc297487b196c59b593c56976a71bd8cd497"
    },
    "response.bin": {
      "byte_length": 131,
      "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
    },
    "transport-receipt.json": {
      "byte_length": 498,
      "sha256": "f14a600f3ff1a7c319ad27b7b28a6ea2eba803510dd9eb6ec51c5636d2b9a5ea"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "efdf342b-145c-436e-acc4-8cdc7490aa07",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b91814ed-ed45-42f7-91e3-a944b21036c6",
    "source_id": "bfc3703d-da64-4f3d-a47f-da3726886a3a",
    "version_id": "bff7f91d-4e1a-4b0b-8685-75ecedf5cc46"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55520/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_SERVER",
      "message": "EXTRACT_API_HTTP_SERVER：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 503,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3aab21f0-8243-4176-9155-3eb1cd3d4b0b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 131,
    "omission_reason": null,
    "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
