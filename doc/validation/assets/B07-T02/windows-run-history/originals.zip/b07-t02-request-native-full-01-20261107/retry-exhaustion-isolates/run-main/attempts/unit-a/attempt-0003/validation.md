# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0f0cf8940f68d3d2abbe8d277a95a1fedef667f56c8930f54376bef3991ee85a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b4f261b779dd6e48709facea1311e7fe81ded592127e703fe68e1b490a2e0f6d"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "38d8317b683cc4460520ea96d338fea033c2a35cb9bb5a31bea1a484c65157fa"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2887b1b5-b399-477f-8b02-3cfed70d9022",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7948b2dd-1d7e-4545-9be1-8bf77e2b9896",
    "source_id": "41de4347-f964-447e-a7c2-c0a136dc32f6",
    "version_id": "5f7ead72-98c8-431a-b1a7-3fa26ca59368"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:64707/v1/responses",
  "errors": [
    {
      "code": "REQUEST_RUN_BUDGET_STOP",
      "message": "REQUEST_RUN_BUDGET_STOP：原期限/预算已停止，未取得发送许可。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d16a27e8-2d0c-4e52-99da-66be18072a20",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
