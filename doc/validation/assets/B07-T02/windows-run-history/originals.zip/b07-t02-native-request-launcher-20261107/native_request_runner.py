"""Artifact-only native launcher; preserve primary native build evidence.

This bridge copies original archived source bytes into the public checker's
explicit build-receipt layout. It does not assert that a build ran: every claim
remains linked to the native builder's original receipt, probes and archive.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def pin(path):
    state = path.stat()
    hashed = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hashed.update(block)
    require((state.st_size, state.st_mtime_ns) == (path.stat().st_size, path.stat().st_mtime_ns), "selected original changed while hashing")
    return {"sha256": hashed.hexdigest(), "byte_length": state.st_size}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


parser = argparse.ArgumentParser()
parser.add_argument("--native-build-root", type=Path, required=True)
parser.add_argument("--new-launch-root", type=Path, required=True)
parser.add_argument("--new-matrix-root", type=Path, required=True)
args = parser.parse_args()
require(os.name == "nt", "this runner must execute under actual native Windows Python")
require(not args.new_launch_root.exists() and args.new_launch_root.parent.is_dir(), "new launcher root and existing parent required")
require(not args.new_matrix_root.exists() and args.new_matrix_root.parent.is_dir(), "new public matrix root and existing parent required")
args.new_launch_root.mkdir()
root = args.new_launch_root
native = args.native_build_root
primary = native / "selected-build-receipt.json"
primary_pin = pin(primary)
receipt = json.loads(primary.read_bytes())
require(receipt["platform"] == "windows" and receipt["status"] == "built_runtime_identity_bound_not_full_validation", "actual native built/runtime-bound receipt required")
cli, driver = Path(receipt["cli"]["path"]), Path(receipt["test_driver"]["path"])
require(pin(cli) == {k: receipt["cli"][k] for k in ("sha256", "byte_length")}, "actual selected PE body pin")
require(pin(driver) == {k: receipt["test_driver"][k] for k in ("sha256", "byte_length")}, "actual selected native driver body pin")
fp = receipt["actual_compiler_fingerprint"]
require(receipt["cargo_build_script_fingerprints"] == [fp] and receipt["cli_probe"]["compiler_fingerprint"] == fp and receipt["driver_handshake"]["compiler_fingerprint"] == fp, "actual native Cargo/CLI/driver fingerprints must all agree")
require(pin(native / "snapshot.json") == {k: receipt["source_snapshot"][k] for k in ("sha256", "byte_length")} and pin(native / "source-originals.zip") == {k: receipt["source_archive"][k] for k in ("sha256", "byte_length")}, "primary source snapshot/archive anchors")
snapshot = json.loads((native / "snapshot.json").read_bytes())
source_pins = snapshot["files"]
before, after = {}, {}
archive_members = []
with zipfile.ZipFile(native / "source-originals.zip") as original, zipfile.ZipFile(root / "source-originals.zip", "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as selected:
    names = original.namelist()
    require(len(names) == len(set(names)), "primary archive duplicate member refused")
    # Read every primary member: ZipFile independently checks CRC. The selected
    # source subset below retains every explicit repository source, including
    # manifests/dependencies and Python/author input, rather than using counts
    # to infer equality between different Rust source inventories.
    for name in names:
        raw = original.read(name)
        archive_members.append({"name": name, "sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)})
    for name, original_fields in source_pins.items():
        expected = {k: original_fields[k] for k in ("sha256", "byte_length")}
        require(not Path(name).is_absolute() and ".." not in Path(name).parts, "safe explicit source-relative member")
        raw = original.read("repo/" + name)
        actual = {"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)}
        require(actual == expected, "archived original source matches pre-build snapshot: " + name)
        current = pin(native / "repo" / name)
        require(current == expected, "selected native repository source remains byte-identical after actual build/probes: " + name)
        selected.writestr(name, raw)
        before[name], after[name] = expected, current
require(before == after, "whole explicit source byte scope before/after native build")
save(root / "source-before.json", before)
save(root / "source-after.json", after)
save(root / "actual.json", {"status": "normalized_original_native_build_receipt_not_behavior_acceptance", "source_files": len(before), "source_before_after_equal": True, "source_archive": pin(root / "source-originals.zip"), "cli": pin(cli), "test_driver": pin(driver), "actual_cli_fingerprint": fp, "cargo_build_script_fingerprints": [fp], "primary_native_receipt": str(primary), "primary_native_receipt_pin": primary_pin, "primary_source_archive_pin": receipt["source_archive"], "original_native_build_receipt": receipt, "normalization_scope": "original native snapshot bytes compared to actual post-build repository; primary compiler/build/probe records retained and separately referenced; no source-build ancestry inferred from binary receipt alone"})
save(root / "native-primary-readback.json", {"receipt_before": primary_pin, "receipt_after": pin(primary), "primary_archive_members_CRC_SHA_length": archive_members, "actual_native_platform": os.name, "launcher_PID": os.getpid(), "python": sys.executable, "python_version": sys.version})
require(pin(primary) == primary_pin, "primary selected receipt preserved")
repo = native / "repo"
require(pin(repo / "scripts/verify_request_budget.py")["sha256"] == "eb6c4476c57b6ab24ccd71646045bb9b8386079bb415f677134bde9b7bddca34", "frozen public checker original required")
require(pin(repo / "tests/test_verify_request_budget.py")["sha256"] == "42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348", "frozen tests original required")
argv = [sys.executable, str(repo / "scripts/verify_request_budget.py"), "--cli", str(cli), "--test-driver", str(driver), "--build-receipt", str(root / "actual.json"), "--fixture", str(repo / "fixtures/run-api-budget-v1"), "--new-root", str(args.new_matrix_root), "--full"]
env = {name: os.environ[name] for name in ("PATH", "SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "TEMP", "TMP") if name in os.environ}
env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", NO_PROXY="127.0.0.1,::1", no_proxy="127.0.0.1,::1")
started = time.time_ns()
with (root / "matrix.stdout.bin").open("wb") as out, (root / "matrix.stderr.bin").open("wb") as err:
    child = subprocess.Popen(argv, cwd=repo, env=env, stdout=out, stderr=err)
    save(root / "matrix-launch.json", {"argv": argv, "PID": child.pid, "outer_native_PID": os.getpid(), "started_utc_ns": started, "native_OS": os.name, "environment_keys": sorted(env), "selected_CLI": pin(cli), "selected_driver": pin(driver)})
    try:
        code = child.wait(timeout=600)
        wait_action = "ordinary_exit"
    except subprocess.TimeoutExpired:
        child.kill()
        code = child.wait(timeout=30)
        wait_action = "timeout_own_process_force_kill_and_wait"
save(root / "matrix-result.json", {"PID": child.pid, "wait_exit_code": code, "wait_action": wait_action, "finished_utc_ns": time.time_ns(), "stdout": pin(root / "matrix.stdout.bin"), "stderr": pin(root / "matrix.stderr.bin"), "matrix_root": str(args.new_matrix_root), "selected_CLI_after": pin(cli), "selected_driver_after": pin(driver), "primary_native_receipt_after": pin(primary), "scope": "actual native Python/public CLI/driver matrix invocation; acceptance only according to original matrix result, no Linux behavior reuse"})
raise SystemExit(code if wait_action == "ordinary_exit" else 1)
