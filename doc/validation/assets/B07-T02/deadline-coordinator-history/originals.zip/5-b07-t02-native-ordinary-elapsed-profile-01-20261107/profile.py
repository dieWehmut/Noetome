from pathlib import Path
import hashlib,json,os,sys,time
root=Path(__file__).parent
repo=Path(r'D:\Noetome\.artifacts\b07-t02-dual-dispatch-native-target-05-20261107\repo')
sys.path.insert(0,str(repo/'scripts'))
import verify_request_budget as a
expected=json.loads((repo.parent/'source-pins.json').read_bytes())
def inventory():
    return {name:{'sha256':hashlib.sha256((repo/name).read_bytes()).hexdigest(),'byte_length':(repo/name).stat().st_size} for name in expected}
a.require(inventory()==expected,'current checker mini source original bytes')
cli=Path(r'D:\Noetome\.artifacts\b07-t02-windows-native-05-20261107\selected\noetome.exe')
driver=cli.parent/'noetome-cli-testdriver.exe'
receipt=Path(r'D:\Noetome\.artifacts\b07-t02-request-native-launch-06-20261107\actual.json')
a.require(a.streaming_pin(cli)['sha256']=='1b6d533e3f434116c1dd9c02ccd795905b5a7f4a1475da13f459a227a5c0cd9f','actual Native05 selectedCLI')
a.require(a.streaming_pin(driver)['sha256']=='2f39b7627543543560149cfbab2ce621a721d3d59b2b37b255abab7739b7a990','actual Native05 selecteddriver')
target=Path(r'D:\Noetome\.artifacts\b07-t02-request-native-ordinary-elapsed-profile-matrix-01-20261107')
r=a.Recorder(target,cli,repo/'fixtures/run-api-budget-v1')
start=time.time_ns()
try:
    r.bind_build_receipt(receipt,driver)
    case=next(c for c in a.author_check(r.fixture)['cases'] if c['case_id']=='elapsed-limit-persists-through-kill')
    case=a.copy.deepcopy(case)
    case['case_id']='elapsed-limit-persists-through-kill--ordinary-no-hook-profile'
    a.run_http_case(r,case)
    result=r.finish('ordinary_profile_completed_not_OSkill_acceptance')
    a.require(inventory()==expected,'current mini source beforeafter bytes')
    (root/'target-after.json').write_bytes((json.dumps({'status':'ordinary_profile_completed_not_OSkill_acceptance','actual_OS_kills':0,'explicit_test_driver_calls':0,'actual_observer_PID':os.getpid(),'start_utc_ns':start,'end_utc_ns':time.time_ns(),'source_before_after_equal':True,'newCurrentChecker':'153f31dc3fdf6c0a23f547764612ac4b486c19207fcdbaddb2cadc5e05d9b51b','RustScope':'Native05 original compiled sources and FP unchanged; current Python source separately copied/guarded, no new Rustbuild claimed','ordinaryCLI':result['ordinary_CLI_count'],'driver':result['driver_count'],'cases':result['cases']},ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'status':result['status'],'ordinaryCLI':result['ordinary_CLI_count'],'driver':result['driver_count'],'cases':len(result['cases'])}))
except BaseException as e:
    r.finish('failed',{'type':type(e).__name__,'text':str(e)})
    (root/'target-after.json').write_bytes((json.dumps({'status':'failed','actual_observer_PID':os.getpid(),'source_before_after_equal':inventory()==expected,'failure':{'type':type(e).__name__,'text':str(e)}},ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    raise
