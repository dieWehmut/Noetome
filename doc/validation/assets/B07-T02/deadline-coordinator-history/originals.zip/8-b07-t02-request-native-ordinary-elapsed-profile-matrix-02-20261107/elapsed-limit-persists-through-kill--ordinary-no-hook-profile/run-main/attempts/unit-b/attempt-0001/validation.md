# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ad09a141fdd303061f2d371b4f96d035f19def4de295bce67f1c13d07e99609f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f59f41fb57675d24c88f91519d7a2021b82d2e4c71b4894d2a6ef8c65861ba3d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d2baedefb968ec060f5944bffc3b4aa4e48cd172f215870dab6e745fff7b7919"
    },
    "request.json": {
      "byte_length": 2267,
      "sha256": "7d58afce825e4d30065aaa49085e8315686c6366400796d359fd15c60d0cba5e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "19c965f90b4601acd80c2123927965d3dc22403a4f6cf50fc2472f409f349cde"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "a6b818f9e4745c12972a01df673ebcaafb83886863e76f877d14b81497d8e68e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7e200d48-b2ae-4115-b2a7-351af42f8b77",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "30171b3e-99fa-4094-8ca9-e51a42ad8da4",
    "source_id": "1904f0d4-d862-404f-a076-4f75052b842d",
    "version_id": "21f851b0-7e7d-4d73-b040-b63d81ee5766"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:61494/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "060fe03f-1277-444c-8981-fe3e43b4b9ed",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "19c965f90b4601acd80c2123927965d3dc22403a4f6cf50fc2472f409f349cde"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
