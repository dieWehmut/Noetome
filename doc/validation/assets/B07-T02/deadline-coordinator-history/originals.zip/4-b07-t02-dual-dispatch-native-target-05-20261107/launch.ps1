$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:NO_PROXY='127.0.0.1,::1'
$env:no_proxy='127.0.0.1,::1'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-dual-dispatch-native-target-05-20261107\target.py' 1> 'D:\Noetome\.artifacts\b07-t02-dual-dispatch-native-target-05-20261107\target.stdout.txt' 2> 'D:\Noetome\.artifacts\b07-t02-dual-dispatch-native-target-05-20261107\target.stderr.txt'
exit $LASTEXITCODE
