# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c6f0967ba2086b519eb172fec62432f33fa254824e5e9b7df3d1fedef0f04779"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "421c9d18e474246ce02b81b3b3b768baeb27225c467630e6b350a442f85075b6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bfcceba3f0eb123a6c4e0415c6f823cea932fb4d3a3abb6dac5bf40705bd879a"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "8076b683ffa7e28c67ba030a95d928d67916fdf362be7af4727a53970b330c98"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "64552c17335d974c799f7762204f6ba9d88b9f8b23fc65f4424dba3ad7f607b6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ae6bbf2099b9067cb2d4846d882eea27988ecb77b88914fd4202f22fcad452aa"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ba44d92d-a394-4468-a718-af5bbbbb6469",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d942fc45-d09d-4ff5-b5ef-d6532dcb8a8a",
    "source_id": "3cb4fd99-5b2d-4061-ab79-c99440c86876",
    "version_id": "3b45490d-5627-4748-9450-70bf7b7d7ef3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52197/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "02b26b88-8ab4-48d5-817d-edf080d83541",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "64552c17335d974c799f7762204f6ba9d88b9f8b23fc65f4424dba3ad7f607b6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
