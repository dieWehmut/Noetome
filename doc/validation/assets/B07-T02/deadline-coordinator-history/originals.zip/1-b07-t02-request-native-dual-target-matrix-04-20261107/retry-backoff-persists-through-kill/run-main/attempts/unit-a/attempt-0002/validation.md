# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "195df6b7a676ea9beaa5491004d4fc659431a90ba01fb94630819023c1bb069f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8cf3e74cb150dfd952bed7e1155f23a1b3a527b750b8cee897c2f479b847d40b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "749aa3a9d5579214dc72af297a8f27108aff91323db5c72096dff013cb1f3a37"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "13d607bbd64cba95a95d6c5d8cc1f10deb7f2e7ef289060f3bd15327f137f9f7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8ef3d0bc10ab0cde59941983a350dbdafe8bae879b493414dcb9b6af1afb1421"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b4ec068046bd67f1df407344717507ac255be855209b2c90c5edcd57d11a0273"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a7a4b7be-db6e-4cb3-a914-60db7442f81e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fde99cb9-6062-4496-b6ae-149f573fa153",
    "source_id": "a9075551-e549-4f74-9ec3-eb3ca506a713",
    "version_id": "a22efe47-1b06-4ab4-a795-9e8c2fbe2198"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52197/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d7f64bf4-e265-4b2c-a6ef-3863f8f3adda",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8ef3d0bc10ab0cde59941983a350dbdafe8bae879b493414dcb9b6af1afb1421"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
