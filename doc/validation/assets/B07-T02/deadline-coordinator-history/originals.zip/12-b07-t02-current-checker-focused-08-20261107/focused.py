from pathlib import Path
import hashlib,json,os,sys,time,unittest
root=Path(sys.argv[1]);repo=Path(sys.argv[2]);binary=Path(sys.argv[3])
root.mkdir()
files=['scripts/verify_request_budget.py','scripts/verify_run_checkpoint.py','scripts/verify_fixture_compile.py','tests/test_verify_request_budget.py']
def pins():
    return {n:{'sha256':hashlib.sha256((repo/n).read_bytes()).hexdigest(),'byte_length':(repo/n).stat().st_size,'mtime_ns':(repo/n).stat().st_mtime_ns,'device':(repo/n).stat().st_dev,'inode':(repo/n).stat().st_ino} for n in files}
before=pins()
for n in files:(root/Path(n).name).write_bytes((repo/n).read_bytes())
os.environ['NOETOME_TEST_BINARY']=str(binary)
sys.path.insert(0,str(repo/'scripts'));sys.path.insert(0,str(repo/'tests'));sys.dont_write_bytecode=True
start=time.time_ns()
with (root/'stdout.bin').open('w',encoding='utf-8',newline='\n') as out,(root/'stderr.bin').open('w',encoding='utf-8',newline='\n') as err:
    oldout,olderr=sys.stdout,sys.stderr;sys.stdout,sys.stderr=out,err
    try:
        suite=unittest.defaultTestLoader.discover(str(repo/'tests'),pattern='test_verify_request_budget.py')
        result=unittest.TextTestRunner(stream=err,verbosity=2).run(suite)
    finally:sys.stdout,sys.stderr=oldout,olderr
after=pins()
record={'status':'passed' if result.wasSuccessful() and before==after else 'failed','actual_PID':os.getpid(),'python':sys.executable,'python_version':sys.version,'actual_tests_run':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),'skip_reasons':result.skipped,'source_before':before,'source_after':after,'source_before_after_equal':before==after,'start_utc_ns':start,'finish_utc_ns':time.time_ns(),'scope':'actual50 independent checker tests/source-init-import and artificial local HTTP; no full budget matrix acceptance inferred','test_binary':str(binary)}
(root/'actual.json').write_bytes((json.dumps(record,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
print(json.dumps({k:record[k] for k in ['status','actual_PID','actual_tests_run','errors','failures','skips']}))
raise SystemExit(0 if record['status']=='passed' else 1)
