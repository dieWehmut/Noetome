# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2ad6c4eb3ca168406ee811773e68cfecd1eaefe23f109ff765ec0f3f552bd9f2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "63fdd2373f346d76159668afefcd0c4041c1d4537271aa90c8e48c2db7c99434"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "f71b17a542f565794ea3038f65e8223c2030f0f3a6819bb0603ac6f66b6f6568"
    },
    "response.bin": {
      "byte_length": 122,
      "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
    },
    "transport-receipt.json": {
      "byte_length": 502,
      "sha256": "84edf77ab086bb1f4ee95ecedb5fdf719833b1584954649d6edae350bbe66e04"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "41d69828-a975-4593-9606-b3609131b35d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cb462d9a-bb71-4d3b-b93f-110ea8b1ccae",
    "source_id": "e9e244c5-aa5b-4db6-8957-6e4facf4f3ac",
    "version_id": "37b4703d-4985-49d9-8094-cfd7edb8860c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63667/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "49e343d5-0c96-4f3b-87c5-c4eca4c32295",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 122,
    "omission_reason": null,
    "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
