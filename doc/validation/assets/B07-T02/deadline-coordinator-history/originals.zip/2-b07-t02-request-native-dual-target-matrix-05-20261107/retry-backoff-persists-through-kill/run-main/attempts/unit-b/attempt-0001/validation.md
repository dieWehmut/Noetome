# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "55c239da01166b47b15f01ba58e611498780f274c5eeb34a0a21d41197813fe4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b942811f5961b3b2d1eafd310ffe7277cf609bb138ed5e0ed73bf3e483628755"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d5ef15bf38be0412fed13752c0e96ae5fa47f1ec61815a3e6f5bbace8055ac23"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "0ebbc702a722c2d7b9aaa11778c4a639e7e4af9f5a654cc9e1f6991bbfe04b7f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "792b2e161c251e72fbcbf378ef652813a6320fd325c62be1d403d05279c4f6ad"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fa5acab4a1f74e6a9177a74fd5358a2e895ff5b7ddfa939fcc0a4824b3ecd5c7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "104f305d-aea7-499c-8d8a-345a396bde56",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6d5499ec-bf86-42f0-8891-b09dd4f1decd",
    "source_id": "a50611f0-6322-497c-a12a-8f8f0f944b1e",
    "version_id": "269a3654-04cc-4dc7-ac6c-c473e0432150"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:61652/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d1822c0f-4cd7-4b4a-b9ba-b31cfa4cba8e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "792b2e161c251e72fbcbf378ef652813a6320fd325c62be1d403d05279c4f6ad"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
