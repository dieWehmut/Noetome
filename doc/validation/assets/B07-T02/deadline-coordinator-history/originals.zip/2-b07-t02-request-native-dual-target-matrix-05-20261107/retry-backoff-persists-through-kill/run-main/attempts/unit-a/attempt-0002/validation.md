# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "be05d82b67b1f79acef9cd9d2e79b869f26ef6a5ca47156a5d48d3087b2dd31c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "93f9e17fc357583e2f020ca3699520394f562587f089dc4fe74ee1fb5dc3f4d6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1fa438f56c34517e9945c6f6a040166f3d03b1a12985bdeebf4dd52adb9bfbc6"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "838253e1a8cccc79f50a257c2b64be575552d4bd05fc180de6f83d6861bc7f33"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b0bcce8b6c4cab59337bfab595d88096a105dfc3e07716c7e2578d0fde6a9130"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ce4efd1dbdb6b66f0320c94c0121189a312a1cac20bff0c39c6a0162ffbc3e72"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9ef3f846-60e4-4c25-bb23-15338e227ac5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "52cde66f-98da-4c68-9ac0-01b998c4d15b",
    "source_id": "8b639389-310d-4b94-9b94-b91c6de7780c",
    "version_id": "2cfb7daa-df55-4ccc-825a-dd90b10c3e72"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:61652/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "de934bea-f9df-4b76-bd31-9853d0df8c5e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b0bcce8b6c4cab59337bfab595d88096a105dfc3e07716c7e2578d0fde6a9130"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
