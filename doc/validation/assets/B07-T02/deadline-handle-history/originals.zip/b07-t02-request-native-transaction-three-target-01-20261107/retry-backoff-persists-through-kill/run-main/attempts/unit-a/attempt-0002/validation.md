# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f25faf54daa071a7e4de9eaeff7364421f52c53c456c72a32750c347101a969e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f69c6a795da695153d402016560031865c070180fd873165e831beefad5e79f7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d635eb1d5fd5ee7b7af8fecdf4d7e22c43ec349bd4f6509c55bf3f76e6a903a7"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "faa36036d202bd9528a67bd9b9f33033fd1710cd19a58b2efc3bc0f8edf68b5e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2145a84565b0b10be83cddc7229d8549a5048c440859a7466462885e20025739"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "75d51325a6c0aee03878bb2cb3964dc6b3a2e6b027e39300a2e9b2e5674dd901"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b30d0489-6fd5-45ac-a549-520e1a9f4758",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9b4322e7-fcd7-4324-86fb-c287c365d325",
    "source_id": "a53c4a56-91a0-4c89-affe-63328d86e947",
    "version_id": "813da3c7-7236-4178-a2e1-bec638682ad7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58517/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "55dcdd8a-df0f-4bec-8225-c5e33dc2ce0d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2145a84565b0b10be83cddc7229d8549a5048c440859a7466462885e20025739"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
