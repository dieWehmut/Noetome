# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0370dedf97bd2c26c9d2dd326b873572ffbb305075e95afba764007604dc25f6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "73886c24909c5ab0ecdb5a1f2f917f0a1c257d17ae283fde445f48603e3eb59d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "77d559e89ac7d31ea24b23187eb2d97378673b21dc0f8e846b69ee6f06e48797"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "cca4a1f3326cacff805deee93693fc81fd57cbbf9243c8ba2d99224210c73df5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0d1b6011ffac7d1a0d9ad6f164e8e89780b3ba6e18bdb0515f7ca1246b4c681c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0f659c158c1a6936576e7c00ec1e0e3fcda2b9adaebd382669a4bc12ea9000f3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c59d9270-857c-41c8-86a6-d4122ef66183",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "43872153-70fd-4d5b-915a-3d916b56d4e3",
    "source_id": "83f4cfb7-58cb-489d-87f0-327176f52fe0",
    "version_id": "393e4aa0-3bf6-4270-834a-3d8328adc695"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62517/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e0f410ef-e650-4209-85ba-1859532bb05d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0d1b6011ffac7d1a0d9ad6f164e8e89780b3ba6e18bdb0515f7ca1246b4c681c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
