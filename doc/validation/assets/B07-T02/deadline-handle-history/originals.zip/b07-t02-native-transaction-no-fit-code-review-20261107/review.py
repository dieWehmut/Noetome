"""Read-only review of already closed native runs and archived compiled source.

No product, test driver, HTTP server, or native auxiliary process is started.
Event timestamps are not labeled as COMMIT-completion timestamps.
"""
import hashlib
import json
from pathlib import Path
import sqlite3
from contextlib import closing


ROOT = Path(__file__).parent
SOURCE = ROOT / "source"
NATIVE_ARTIFACTS = Path("/mnt/d/Noetome/.artifacts")
EXPECTED = {
    "request_run.rs": '8e4d363d017d5e954aae71ffb327a6c917250908f8bf61b19bf2561ea41e61cc',
    "request_budget_store.rs": 'f76587ed687d47f9c2d44523f16f8f4dcad3ef4eefef7be5768a56061b404349',
    "extraction_api.rs": "e937de215338b192bb99aadec5dce669153614ffb6834123ab3cba95ccfc8c1e",
}


def pin(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return {"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw), "read_platform_device": after.st_dev, "read_platform_inode": after.st_ino, "mtime_ns": after.st_mtime_ns}


def utc_ns(text):
    from datetime import datetime, timezone
    date, fraction = text[:-1].split(".")
    seconds = int(datetime.fromisoformat(date).replace(tzinfo=timezone.utc).timestamp())
    return seconds * 1_000_000_000 + int((fraction + "0" * 9)[:9])


def case_review(name, root_name):
    run = NATIVE_ARTIFACTS / root_name
    case = run / "elapsed-limit-persists-through-kill"
    database = case / "budget/control/budget.sqlite"
    before = pin(database)
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)) as db:
        rows = list(db.execute("SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence"))
    assert before == pin(database)
    parsed, previous = [], None
    for index, (sequence, prev, raw, digest) in enumerate(rows, 1):
        assert index == sequence and hashlib.sha256(raw.encode("utf-8")).hexdigest() == digest
        if previous is not None:
            assert prev == previous
        record = json.loads(raw)
        assert record["sequence"] == sequence and record["previous_sha256"] == prev
        parsed.append(record)
        previous = digest
    registered = parsed[0]["event"]
    assert registered["kind"] == "run_registered"
    unit = next(unit for unit in registered["spec"]["units"] if unit["unit_id"] == "unit-a")
    deadline = utc_ns(unit["deadline_utc"])
    clock = deadline - 1_500_000_000
    timeline = []
    for record in parsed:
        event = record["event"]
        row = {"sequence": record["sequence"], "original_event_at_utc": record["at_utc"], "milliseconds_from_original_A_clock": (utc_ns(record["at_utc"]) - clock) / 1_000_000, "kind": event["kind"]}
        for key in ("key", "unit_id", "outcome", "diagnostic", "schedule"):
            if key in event:
                row[key] = event[key]
        if event["kind"] == "receipt_settled":
            receipt = event["receipt"]
            row["actual_receipt_transport"] = {key: receipt[key] for key in ("http_status", "network_attempts", "response_complete", "error_code", "elapsed_ms", "usage")}
        timeline.append(row)
    a_settlement = next(row for row in timeline if row["kind"] == "receipt_settled" and row["key"]["unit_id"] == "unit-a")
    assert a_settlement["actual_receipt_transport"]["http_status"] == 429 and a_settlement["actual_receipt_transport"]["response_complete"] is True and a_settlement["actual_receipt_transport"]["error_code"] == "EXTRACT_API_HTTP_RATE_LIMIT"
    assert not any(record["event"]["kind"] == "retry_scheduled" for record in parsed)
    assert any(record["event"].get("diagnostic") == "No retry fits the original absolute deadline" for record in parsed)
    server_path = case / "server/server-receipts.json"
    actual_server = json.loads(server_path.read_bytes())
    assert len(actual_server["receipts"]) == 2 and not actual_server["errors"]
    actual = json.loads((run / "actual.json").read_bytes())
    assert all(actual["guards"].values())
    assert all("exit_code" in command and "wait_action" in command for command in actual["commands"])
    return {
        "name": name, "actual_root": str(run), "database_original_read_before": before,
        "database_original_read_after": pin(database), "event_rows": len(parsed),
        "original_event_rows": parsed, "timeline": timeline,
        "original_A_clock_utc_ns": clock, "original_A_deadline_utc_ns": deadline,
        "original_retry_delay_ms": 1000,
        "earliest_required_retry_schedule_window_from_A_clock_ms": 500,
        "A_settlement_event_ms_from_A_clock": a_settlement["milliseconds_from_original_A_clock"],
        "settlement_event_already_after_latest_possible_1000ms_retry_window": a_settlement["milliseconds_from_original_A_clock"] >= 500,
        "actual_server_receipts": actual_server,
        "actual_closed_command_receipts": actual["commands"], "original_run_guards": actual["guards"],
        "scope": "Existing native originals only. Event.at is generated inside the SQLite update before INSERT/COMMIT and is not an actual COMMIT-finish or individual function duration. These rows prove NoFit with complete429/B200, not OS recovery acceptance.",
    }



source_pins = {name: pin(SOURCE / name) for name in EXPECTED}
assert all(source_pins[name]["sha256"] == digest for name, digest in EXPECTED.items())
result = {
    "producer": "native_transaction_no_fit_archived_source_review",
    "status": "read_only_existing_phase_and_compiled_call_path_review_completed",
    "selected_compiled_FP": "6dd8c9cab44153af6ec7234ad4ee9bb321b7405d61a77b84ef4a3c6f39b6383f",
    "compiled_source_files": source_pins,
    "compiled_source_extraction_pins": json.loads((ROOT / "compiled-source-pins.json").read_bytes()),
    "cases": [
        case_review("ordinary external2msobserver no cfgtest", "b07-t02-request-native-transaction-ordinary-elapsed-01-20261107"),
        case_review("selected actual8e4d helper; no unmatched callbacks", "b07-t02-request-native-transaction-three-target-01-20261107"),
    ],
    "first_attempt_explicit_static_store_scopes_before_MaySend": {
        "scope": "Source-derived explicitly listed first successful Prepared/Reserved/MaySend path only. Not measured calls, syscall totals, function durations, startup, SourceSession, or test callback costs.",
        "open": ["request_run.rs:1177 unit_loop"],
        "view": ["request_run.rs:1182 first unit loop", "extraction_api.rs:155 selected_credential -> request_run.rs:1568 guard ->1512 store.view", "request_run.rs:1605 prepared.guard ->1512 store.view"],
        "update_checked_transactions": ["request_run.rs:1646 prepare -> store.rs:685 Prepared", "request_run.rs:1654 reserve_prepared_checked -> store.rs:754 Reserved", "request_run.rs:1713 mark_may_send_checked -> store.rs:787 MaySend"],
        "explicit_scope_count": 7,
        "RunGuard_inputs_calls": ["unit_loop first iteration", "selected_config.guard", "prepared.guard", "reserve_prepared_checked.guard_view", "mark_may_send_checked.guard_view"],
        "Store_verify_inputs_calls": ["prepare", "reserve_prepared_checked", "mark_may_send_checked"],
        "old_readonly_review_count_clarification": "Old2e review's ten scopes listed two open, four view, four update sites; it omitted selected_config.guard's extra view. With that path explicitly included old2e has eleven scopes in this bounded list. Old report bytes remain immutable; neither figure is measured I/O latency or syscall count.",
    },
    "remaining_readonly_optimization_candidates": [
        {
            "candidate": "prepare_checked with original RunGuard inside its fresh BEGIN IMMEDIATE witness",
            "actual_current_path": "Hooks.prepared first invokes guard/view, then prepare invokes another full protected load/witness.",
            "preserve": "Prepared retains its independent COMMIT and callback, exact new request bytes/identity and Source/Owner/input checks. Guard runs after fresh load/witness in the same transaction as prepare, analogous to existing reserve_prepared_checked and mark_may_send_checked. No cached balance or authority is accepted.",
            "potential_removed_scope": "One pre-Prepared readonly full store.view/witness, replaced by the same guard on current transaction view.",
        },
        {
            "candidate": "Fresh checked retry-decision transaction instead of separate complete readonly loop view then schedule update",
            "actual_current_path": "After typed settle and durable callback the next loop performs g.verify/inputs, store.view/witness and inventory; schedule_retry_after opens a second full current protected update/witness.",
            "preserve": "Settled and retry remain separate COMMITs with all declared hooks. Kill/hold elapsed counts in original clock. The retry decision uses current full chain, current owner/input and exact artifacts inside BEGIN IMMEDIATE; current deadline and retry classification are recalculated there, never from a caller's cached snapshot. B still has an independent worker/connection.",
            "potential_removed_scope": "One extra readonly full store.view, plus duplicate external input pass when exact same checks execute inside the new fresh checked transaction.",
        },
        {
            "candidate": "Bounded per-operation guarded observed-original map",
            "actual_current_path": "witnesses stamps sealed_files then verify_request/transport_files/receipt_files stamp and parse several of the same paths again; receipt_files also rereads original response for actual usage/candidate validation.",
            "preserve": "Every admitted file must still have exact actual metadata/FileID/singlelink/reparse/SHA and full before/after directory inventory; parse only observed raw bytes. A deny-write handle or full ending byte/identity check must cover the complete observation interval. Cache never crosses a COMMIT, HTTP exchange, lock release, another witness operation, or changed inventory/identity. Missing/unsealed newly produced files cannot be guessed from the prior map.",
            "potential_removed_scope": "Repeated raw ReadFile/SHA/JSON parse inside one protected witness only. No promise of fitting author deadline follows from static code.",
        },
    ],
    "confirmed_prior_transaction_optimizations": [
        "Hooks borrows the current unit's BudgetStore; no second inner open.",
        "reserve_prepared_checked no longer commits a redundant already-Prepared transaction.",
        "Reservation and MaySend guard use current transaction view rather than extra preguard views.",
        "Typed expected receipt is checked in the next fresh loop; immediate post-API readonly view was removed.",
    ],
    "acceptance": {"ordinary_elapsed": "failed_NoFit_zero_kill", "selected_backoff": "passed_true_Windows_kill_and_resume", "selected_elapsed": "failed_NoFit_zero_kill", "selected_accepted": "not_run", "full62": "not_run"},
    "protection_requirements": ["No skipped BEGIN IMMEDIATE/current complete chain/atomic Run+global admission", "No source/owner/policy/identity weakening or mtime-only shortcut for SHA", "Keep all durable boundaries and SamePrepared request UUID", "Preserve original 1500ms unit, 1000ms retry, 200ms API, UnknownR8310 and Known700", "Reject same-inode byte or mtime change, replacement, path/authority/version mismatch; no self-certified witnesses"],
    "new_product_invocations": 0,
    "new_test_driver_invocations": 0,
    "new_HTTP_requests": 0,
    "limitations": ["Event.at is calculated inside update before INSERT/COMMIT, not measured commit completion or per-function duration.", "Complete429 Known/Unknown accounting and safe NoFit are real facts; neither failed elapsed case proves OS recovery acceptance.", "The static optimization candidates have not been implemented or performance-tested by this read-only reviewer."],
}
assert source_pins == {name: pin(SOURCE / name) for name in EXPECTED}
with (ROOT / "actual.json").open("xb") as stream:
    stream.write((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"status": result["status"], "event_rows": [case["event_rows"] for case in result["cases"]], "output": str(ROOT / "actual.json"), "new_product_calls": 0}))
