# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f6877d28962e5699bd32557901ef31ec51f640baa04213351949700c96b751aa"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0df851e6088b08ffb160126e1b49e6521c60c7ff99108f7cae5bb8e5cb3eaded"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fdbecc401c8f98adf646b284e6d02227a8b5dcd068e67e6e20bf77eb3e19398d"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "40a42f2bb050c9d5679ada84d4c4296cd7e95dfa6595dfe8d009ce2722b201ce"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c797d532aff6a86576b72638a5010dfb0904f62a19dcb4e2a8528f6bd0e4e83a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c1b9de8349bc959f789bb6a93c0aa20877bdb9d9f6ed1a0688b249d018728334"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "83edd129-6cfb-4dc7-8bdf-255632b0cbb3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "217eb577-cd51-4827-925e-787f076b089a",
    "source_id": "c5131d73-6884-4f25-9ec9-0f727fddd760",
    "version_id": "f2053c71-898b-470b-9c73-9cae381bc4bd"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52285/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b65621e7-7eb0-4e5f-bbb7-064ef6bcb68d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c797d532aff6a86576b72638a5010dfb0904f62a19dcb4e2a8528f6bd0e4e83a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
