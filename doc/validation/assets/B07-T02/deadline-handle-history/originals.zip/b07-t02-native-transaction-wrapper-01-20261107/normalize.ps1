$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:NO_PROXY='127.0.0.1,::1'
$env:no_proxy='127.0.0.1,::1'
$runtime = @{powershell_PID=$PID;version=$PSVersionTable.PSVersion.ToString();stage='normalize';scope='actual outer PowerShell process; Native Python stage retains child binary streams'} | ConvertTo-Json
[System.IO.File]::WriteAllText('D:\Noetome\.artifacts\b07-t02-native-transaction-wrapper-01-20261107\powershell-normalize-runtime.json',$runtime,[System.Text.UTF8Encoding]::new($false))
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-transaction-wrapper-01-20261107\run_stage.py' --new-stage-root 'D:\Noetome\.artifacts\b07-t02-native-transaction-normalize-stage-01-20261107' --runtime-record 'D:\Noetome\.artifacts\b07-t02-native-transaction-normalized-source-01-20261107\primary-readback.json' -- 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-transaction-wrapper-01-20261107\normalize_build.py' --native-build-root 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-04-20261107' --new-root 'D:\Noetome\.artifacts\b07-t02-native-transaction-normalized-source-01-20261107' --expected-fingerprint '6dd8c9cab44153af6ec7234ad4ee9bb321b7405d61a77b84ef4a3c6f39b6383f' --expected-cli-sha '3972ef561eb2c86bd3902a7682dfa5eae9c4236dcdf285c10ca4fa708929d164' --expected-driver-sha '57c0fb749f50221743951863469698f79f44e123a9defa432f497cd89bf11aa7'
exit $LASTEXITCODE
