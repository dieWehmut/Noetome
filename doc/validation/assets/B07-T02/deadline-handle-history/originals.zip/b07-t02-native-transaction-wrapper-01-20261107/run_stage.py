"""Actual native binary-stream launcher for one explicitly selected new stage."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("--new-stage-root", type=Path, required=True)
parser.add_argument("--runtime-record", type=Path, required=True)
parser.add_argument("argv", nargs=argparse.REMAINDER)
args = parser.parse_args()
if os.name != "nt" or args.new_stage_root.exists() or not args.new_stage_root.parent.is_dir():
    raise RuntimeError("actual native Python/new stage/existing parent required")
argv = args.argv[1:] if args.argv[:1] == ["--"] else args.argv
if not argv:
    raise RuntimeError("explicit child argv required")
args.new_stage_root.mkdir()
environment = {key: os.environ[key] for key in ("PATH", "SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "PATHEXT", "TEMP", "TMP") if key in os.environ}
environment.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1", NO_PROXY="127.0.0.1,::1", no_proxy="127.0.0.1,::1")
def save(name, value):
    with (args.new_stage_root / name).open("xb") as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
def pin(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)}
started = time.time_ns()
with (args.new_stage_root / "stdout.bin").open("wb") as out, (args.new_stage_root / "stderr.bin").open("wb") as err:
    child = subprocess.Popen(argv, stdout=out, stderr=err, env=environment)
    save("launch.json", {"argv": argv, "native_outer_runtime_PID": os.getpid(), "child_launcher_PID": child.pid, "native_Python": sys.executable, "native_version": sys.version, "started_utc_ns": started, "environment_keys": sorted(environment), "runtime_record": str(args.runtime_record)})
    try:
        code = child.wait(timeout=900)
        action = "ordinary_exit"
    except subprocess.TimeoutExpired:
        child.kill()
        code = child.wait(timeout=30)
        action = "timeout_own_launcher_force_kill_and_wait"
runtime = json.loads(args.runtime_record.read_bytes()) if args.runtime_record.exists() else None
save("result.json", {"native_outer_runtime_PID": os.getpid(), "child_launcher_PID": child.pid, "exit_code": code, "wait_action": action, "started_utc_ns": started, "finished_utc_ns": time.time_ns(), "stdout": pin(args.new_stage_root / "stdout.bin"), "stderr": pin(args.new_stage_root / "stderr.bin"), "actual_child_native_runtime_record": runtime, "scope": "Child launcher PID and actual native runtime PID are separate when a venv redirector is involved. Real stdout/stderr original bytes retained; actual inner product command outcomes are in the independent Recorder roots."})
print(json.dumps({"exit_code": code, "wait_action": action, "stage": str(args.new_stage_root), "native_outer_runtime_PID": os.getpid(), "child_launcher_PID": child.pid}))
raise SystemExit(code if action == "ordinary_exit" else 1)
