$ErrorActionPreference='Stop'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONDONTWRITEBYTECODE='1'
$env:NO_PROXY='127.0.0.1,::1'
$env:no_proxy='127.0.0.1,::1'
$runtime=@{powershell_PID=$PID;version=$PSVersionTable.PSVersion.ToString();stage='ordinary-elapsed-real-OSkill'} | ConvertTo-Json
[System.IO.File]::WriteAllText('D:\Noetome\.artifacts\b07-t02-native-transaction-wrapper-01-20261107\powershell-ordinary-runtime.json',$runtime,[System.Text.UTF8Encoding]::new($false))
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-transaction-wrapper-01-20261107\run_stage.py' --new-stage-root 'D:\Noetome\.artifacts\b07-t02-native-transaction-ordinary-stage-01-20261107' --runtime-record 'D:\Noetome\.artifacts\b07-t02-request-native-transaction-ordinary-elapsed-01-20261107\native-wrapper-runtime.json' -- 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' 'D:\Noetome\.artifacts\b07-t02-native-transaction-wrapper-01-20261107\narrow.py' --mode ordinary-elapsed --repo 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-04-20261107\repo' --source-pins 'D:\Noetome\.artifacts\b07-t02-native-transaction-normalized-source-01-20261107\source-before.json' --cli 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-04-20261107\selected\noetome.exe' --driver 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-04-20261107\selected\noetome-cli-testdriver.exe' --build-receipt 'D:\Noetome\.artifacts\b07-t02-native-transaction-normalized-source-01-20261107\actual.json' --new-root 'D:\Noetome\.artifacts\b07-t02-request-native-transaction-ordinary-elapsed-01-20261107'
exit $LASTEXITCODE
