# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "485f992a0eedf2a74c2765df73965ce9027d1810f5c1de71ed1def2d3762da26"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4c60db3a035923e6236c3bb8fe027e7b6299ce9fd1558ac4e67a7afdf234554c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ea734e0710086f06af7bc5c1b724a1d3ab0515c1c37ca7e41cb5e5692b0d3783"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "1c36f5426735192ef49548436f9fb94db9defee7fd04b830f4399884389fb95d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f30e1ddee66ec2d6e9fe0a61a1264c8ada7e7c7056624d4a92142d5015249497"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a596c35b2536814a538f477b9135406111bb0a2e8eb7c0b0f55c35d33aad7552"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8a4b526d-9d7e-44d4-b9d6-88ca432e61bd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "303d26ac-fcdf-4e8c-91ec-437ce4ebc087",
    "source_id": "288f09b8-269e-43dc-9a37-abd86e1dd44d",
    "version_id": "d799e695-b6bd-47a4-8d0b-a1eef9da0141"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38003/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "df9be2ec-79ce-4f7a-b7db-1c9da62fb38c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f30e1ddee66ec2d6e9fe0a61a1264c8ada7e7c7056624d4a92142d5015249497"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
