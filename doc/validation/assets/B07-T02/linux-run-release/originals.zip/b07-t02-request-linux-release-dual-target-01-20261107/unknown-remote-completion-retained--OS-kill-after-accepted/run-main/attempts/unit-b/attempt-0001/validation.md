# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e8f103f00e5140c88e3acdeb8fc420fd09343a72c48c8bd2fe0817c24f7802a9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a625ac14836713a904b43bff8d3aa2006f7dec9c44ad0480c85fc82c8ccadfe0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b2abe8208b391062879957b70d412a6baeabd731702cd16f368c6df996ac3786"
    },
    "request.json": {
      "byte_length": 2256,
      "sha256": "e7c6d47e48639471205234edc0e5109766acdfcd57c83f12cb8f0a2411e099da"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8f23696084731f7fcd682d740c136a6373b1050bdd4d09b7afe4841ed932465c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b0e1636257eec1a54fa309e7ce7a076f07a6e62fbd07f32ccb84f07de8a7d424"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "10519569-4887-4227-aea5-0a2400b1adc4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "60992004-af1a-48ae-b3cd-38149dcde189",
    "source_id": "0f008269-9dbe-45d1-9a62-2d402ede353d",
    "version_id": "4947d5b1-9776-4c70-93a8-f36d10837cbf"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36479/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ecb9ab6d-9ecd-437f-a106-426f00bfec91",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8f23696084731f7fcd682d740c136a6373b1050bdd4d09b7afe4841ed932465c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
