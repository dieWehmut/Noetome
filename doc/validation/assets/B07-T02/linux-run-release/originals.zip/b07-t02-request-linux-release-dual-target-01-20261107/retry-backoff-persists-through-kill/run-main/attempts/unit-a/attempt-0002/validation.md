# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5835d9c8b87a004b584ed88c56cf4f6ed273c8a0a57fabdaba53718d446ac2f3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fec7cf4b815baf1b879bfb1bb99df1dba778e156055ea0d59b732643b6008914"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d82e3b53eb8eb24fb91a877abc60c8a7f923a2f5ef6517f4755a9b41534bb60b"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "6b45d8fe66e283c0eb8c12601ef5b5e223566363324ab362528f5c8ea8de45ad"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0833eac8180ab5b075d0fc9067a1b5aea28cf449f0899fae94719df252e60ac0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "989efad3b77803ac6438ff63b18b58557d3199dfa0ad47ff610b3f59d886b270"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "59e53df4-324c-4f14-9a7b-5cdc88e9bb7e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9057b054-3442-4fdb-8555-065e4f5e1c03",
    "source_id": "5aad4d7f-f14e-41c7-86fa-4195b69673b7",
    "version_id": "0203e44c-59b6-47a4-a74e-5ae225434b84"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37275/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "82357f06-f424-433e-ad35-3c9c79eec33d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0833eac8180ab5b075d0fc9067a1b5aea28cf449f0899fae94719df252e60ac0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
