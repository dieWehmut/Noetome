# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "db33a2cc6944ed101673bfe348049333d3ff911de1ce92e53f60842003f0d0ee"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9debc076217de1cbc3e99ea863730a8575e37727bddcfa0634d423102d925b4a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8638a4920d82521c93c9e1c06437cdfdeb60d1ba58939caef88495bcefb86e6c"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "f3dc57962ae4a5ea06e02ad799753442ef084ce2d9caf2e2b596b48da0052e2e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3f02b37dbab6a5b4711c12430d6eb31d4af2789afbaaa9b57ef117a26a8bd27d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "11d0186d5f39499a6cf1125770c41a1f41a9c3bd1b6bd9612456c75b43630034"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "26ce99cd-cd47-4d17-94b9-6b1e747f5623",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "aadcfabe-c8c6-47ff-96c9-c5d16a1c431a",
    "source_id": "27b2e818-aa9e-4d72-99c6-825365ebfae1",
    "version_id": "e8fdd416-b57f-41cd-bad0-30b917f11bb4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37275/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f26d2377-be22-4a33-9b72-6f1495e9ac6e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3f02b37dbab6a5b4711c12430d6eb31d4af2789afbaaa9b57ef117a26a8bd27d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
