# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e1cf9c7fb0c3b4d83cd41afc467191505426974c3e84029ac734672782fce935"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9426a36908ccef02bcf0c0b69c83d09175dc36f5c76cd0dbe50bb23ecb49e130"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e9da6f88867e5aa4b3e95bbaafe8d18c27ed2a2b30dccb53f24c559f4f66d053"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "29bdc4a5844d9db62b94054c7e4aaf4e743d865970b8b50ed6f9558fdea22423"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4811b87a45d5fba929d83a74723a140d664f8b2b5ecba96651e4d00929f7fa11"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "639c08e2918eba1039dad71c11745c31c614c539cb84c74ff67ccaa82ae96c0f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "dec7b2b8-906b-4761-af5a-f5eae751a17f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c685a16a-134d-4dc3-b2cb-85988ef8754f",
    "source_id": "71762261-c736-45bc-8fb8-64e651b5ad58",
    "version_id": "35c179e9-b655-4203-9e25-386045e59671"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38141/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "886f66f2-dc89-4ab2-9673-9feecf0eb748",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4811b87a45d5fba929d83a74723a140d664f8b2b5ecba96651e4d00929f7fa11"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
