# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5a47239170e13748e52bd4fa44058e6be802a2aed2087317b190750e36fb190a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e179a82f43d1756f171eebc0a34c1e376d73fc2994fa9154cfc9e02d17513917"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d75fb16828ec00436e768fd140ceccff6afbafd2bfb6b0c4fd27cc27e29d460c"
    },
    "request.json": {
      "byte_length": 2239,
      "sha256": "e24b7069a966515fadfc81cccf11635060a57669cffdcd17e39160ee6f6c4cd6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a6ca08f17f50386346c34794ee6fe6c2c82b1f230214e68350ed47a751c8429d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "aa395e9c5d92df9864d41d6dcb5086ad13ee46287352817e0ba0ca8fb6e924fd"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9aa6b516-c2c5-4f02-a0fe-044a5b329cae",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9b7f9efc-00a8-4c33-9ad5-bebbdfd739f8",
    "source_id": "21fdb269-798c-44db-aa9c-54a8803c11ff",
    "version_id": "c738de38-d3eb-4c45-9e39-64d65896ec23"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37703/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7d5d3882-b881-4041-b0b5-4812b7718058",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a6ca08f17f50386346c34794ee6fe6c2c82b1f230214e68350ed47a751c8429d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
