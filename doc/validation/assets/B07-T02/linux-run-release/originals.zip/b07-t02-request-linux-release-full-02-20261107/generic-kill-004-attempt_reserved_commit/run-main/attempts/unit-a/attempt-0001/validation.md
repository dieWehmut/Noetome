# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "00149eb15c869cf7f73e13d79db884cdb2b3f0911deabf122e42af01118105ec"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1aaa14213062234fd2e5591de0586793bd259e94ebfc1bbe28f21a63b6ed4921"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e0d48ee13624f3f4d183b1181fd4485201f80441bd54c4b0ee711b7d67e93beb"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "6b5ba831e1aa71e2a2a0e4e42698d966d59b1671b4a905fd648cba6635c0d83c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a1bc53c372eda52b4fbf055c7c82416e366ad109fc364f8ec90fd0c5f6a7c128"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5fa0798f177a69402d94b49ef7e38c2c70f8aaf4a234345815f87c3b0a6150c5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "14997f62-3705-4383-ac94-de30acabaa89",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c30e66cf-01e1-46fb-a530-a3a6326ace98",
    "source_id": "51b2eb96-e26d-4a1e-8588-057840535265",
    "version_id": "dfa787f5-ad79-46cd-b2d9-71e7c40ca924"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38111/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "63ceca6c-58b7-4294-b000-fadfa0182c33",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a1bc53c372eda52b4fbf055c7c82416e366ad109fc364f8ec90fd0c5f6a7c128"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
