# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1632d8db9d8cf3fc8c9b3069f130d8784dfa69e428c135165eb3d52beadd125f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f8c60dd7afa525e7422a261589e4bb52e469335bdac9bce7442a7d2c3fc11d41"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6d4d0a51b2c7d345240f23b2c3301ba578395f594002cdaab6bb16d589aaff15"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "9ca2d8c94096bb614d32d196b86dc5fee2fa8424a5d46b54c9b52236889965ca"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "439b2cb141ebc1a1b8f4056b8fb55fef2da3766bb4f6ef0431acf9fe2a044293"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9931846397b82b5ad339527d8b13fe79e20baaf2f82e755703a0df9d721b79ca"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f5656e23-94db-42fd-9677-1fff9102a2ca",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7b9a49a0-4c18-452c-af2e-523feee5ef60",
    "source_id": "8157e0d1-6c71-406c-a89e-a07e4cef8040",
    "version_id": "9497fcb6-e58f-43ea-8a65-e3fbabf3983f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37453/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d617788b-7d1f-4b9d-814e-5fd193034ab9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "439b2cb141ebc1a1b8f4056b8fb55fef2da3766bb4f6ef0431acf9fe2a044293"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
