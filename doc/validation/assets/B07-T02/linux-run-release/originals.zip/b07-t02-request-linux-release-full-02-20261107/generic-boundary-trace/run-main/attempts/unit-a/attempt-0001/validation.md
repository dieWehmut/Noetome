# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "59e64d6ad0d27cdc45815bd60f469fefc2f9d513ecec6bb7c40c585728a9c109"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6cfe724915f691dc0beced0156ca3db369265e3aac04e7cb04c055747ca9e0d7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1a406f59ce5a53cc7f83ba24e02aa1a29bd5d3131f3788f95b58ab7a94ed9ff1"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "4be3e836e8be291ca39a38e54f1d87665b9de1ac1e87044681a30febd0a53278"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2fd4a0e7540d6ad75ab123bacb7333e0fab18c0c69ac586f5b1cf357f11bf9e4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "40fe04f07f2e2015b5d364babe5af21e07484318b951e92d49b821ca418b2086"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d56cf6cd-2dba-47a6-aff3-fd81cc573711",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "37a9fb21-4d92-4e11-8e0e-0c3cab508536",
    "source_id": "7d45afe4-c5a3-42f4-be48-0991b681fecb",
    "version_id": "c3f72578-d04b-458d-a68b-21ce17e76b7b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37991/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8465616c-82c3-4389-8e20-678230fb94de",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2fd4a0e7540d6ad75ab123bacb7333e0fab18c0c69ac586f5b1cf357f11bf9e4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
