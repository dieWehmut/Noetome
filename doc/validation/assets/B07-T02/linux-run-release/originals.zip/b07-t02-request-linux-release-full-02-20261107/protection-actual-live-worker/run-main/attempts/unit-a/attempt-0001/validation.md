# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ba1562e0e15d48786dd575adf063ba5b03bb83c06b2be240d399582fe1e6b089"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a6b16e7b933436bc468b5023d483907dac258eef7fef61c026d3661dcc553379"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "585a0e6d24de00b12b0e543e95de9e1b6117839203d5d66965f64f0435a17137"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "61b731ce6912e7aa5d439de4ceb4cfcc6f872afa1cd14824b090b659334564cc"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a20cff9f2ba567133aed4b91d0a25c2bd6b909a74fc083e1d23d3df5adb089db"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6b779de106ae7687978f4bf7a927a7acbc45a5fabdff496569242089c2cb03be"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3c12889d-4b40-4df1-b076-19387052180d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "18dcbe4f-d3c9-4e77-9594-5bdec9e7780d",
    "source_id": "dffe6d0f-1e7d-469c-b2bd-6bd4795c5bba",
    "version_id": "cf48cb20-5da5-46d2-b3ac-b9abe644de85"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37067/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "89a7c59a-a2a3-4165-8b7b-f7b42cf651b3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a20cff9f2ba567133aed4b91d0a25c2bd6b909a74fc083e1d23d3df5adb089db"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
