# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e71dd163b844b7dcd6a770b42341021b407e733fd2edaa6bd5e20d6d79061f69"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3683289c055e201d562ff9fb7a12096e65b9a19312485f5a94d8f43adb255d17"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a7a62a83b09d7531874252f3962f41fe3f34238f9aa884ff4f03828adaeda341"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "0aacb480005ab1bd7fab52105417c90ab4090f9982259bb0a7abe1d0406e82eb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "765f22a6bacc5b6340e9b8e039183115f7a82f1b3119fe5aff3a4d986c8c90ab"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f19abafb8db2b310909e1dd673281e0da958b2d960be0a206de730aea6e386c2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "115e9d6e-6b35-4172-8bbf-0d3ab405cf99",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b6383683-7b28-42a1-9df4-152c6d941d11",
    "source_id": "5f30fbbb-3644-4f1a-ab69-63016361b1fb",
    "version_id": "cc4e0df4-3b10-4cf1-8a9c-08c94d4c1125"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38469/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "adf74981-c217-4f76-a727-0357c858e2de",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "765f22a6bacc5b6340e9b8e039183115f7a82f1b3119fe5aff3a4d986c8c90ab"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
