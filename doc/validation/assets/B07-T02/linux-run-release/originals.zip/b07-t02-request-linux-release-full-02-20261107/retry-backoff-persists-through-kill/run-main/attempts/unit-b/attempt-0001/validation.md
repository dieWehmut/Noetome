# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "29023b3218102160ad18f1d012fa4631e63f4120999271ad1ced23a59c767824"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "43f430c7d3ef6562d06725db9555ca981b7fc73839c6b10d11866924ea7da1a0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cfeefcb10328e79faed7c632d8b6978cc87bf480694b33b867121a0719e5a7ac"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "26f14366d7b254787e0ce91e78d0b075f41ad8fc0ce2075a12ab790004d1a63b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "badb6689964e1c895adcf32890bf33b610f6c976bf04fc379f2dfea349f99deb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "43ba1d94024aee229681fd2e7a69608866ecfda6b2e0d496b136819b016126f2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "81dbba98-0959-4971-bc78-4dec9e6ade30",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "da39fd64-c4b8-4e95-b214-11587d2a0b4d",
    "source_id": "3b8de2da-dd7c-44b4-a9c3-8ed1c0cd8504",
    "version_id": "037b0b45-4354-43ff-804f-c4eda10b1aed"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ecef131d-c4ed-48a0-a55a-7652c938e2f4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "badb6689964e1c895adcf32890bf33b610f6c976bf04fc379f2dfea349f99deb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
