# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "29616552947501fe873d3387b233a740d5545dfb6f3bb65c77b3d1c89ebcd50c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "663b47c4b39306f72c21af31eb0e126489445d75282556a69d02b33f736611c1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5f135443fbd4c6968ef653ad9db019be32b5aec5a1a2644e129cf7382e6e369a"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "d5eefdc43d7d4439ff25af8a21d959483270f17c50305d1c5efd29b5a0daf172"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "94844e2b456b31f415a84496c31b50c59d1d694ebb0e4b02ecc64060c898c8d1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "293e650246ee7e867ada6648c3417c3fde0841c291fb5953d9a82fa708aa79c4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "eec5255d-49a7-4322-b795-97801eb7bc9a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fcc00772-c445-4184-a325-91fd4a6609ec",
    "source_id": "a29b3099-95dd-423c-bad5-cb968cb48a42",
    "version_id": "bbccb32e-7657-4e13-bcf4-d510067fa49b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "347b75a8-ab45-4f37-824b-d96d5d5949dc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "94844e2b456b31f415a84496c31b50c59d1d694ebb0e4b02ecc64060c898c8d1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
