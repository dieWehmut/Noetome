# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6f9b556768cb43a3e15d5711604623f2ac5ee06d320b0acf9b135ec58ad39d68"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "49015b257b251d1fbc3b1d6ac36f135bdce1ef9ba466afd7d6e18862ba046d88"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ed41818c38c2054d307e47ba1182b09030622d62bde3d6e52c9d1b66d720f14b"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "d83a58a0ba0eb12c6af2d56f9233fd27119b712ad6d71963fe7db20601db5b45"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0c981f7f90e4b489822943d037e9c596dfe339f6eb75d6764603c744097d19e0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0df37fbb1798b6bdbb4747bae394a347dbe9bc696b9f48b9c5f63abf134af43b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8acf53ac-ab13-4823-a5cf-5184e0c4fbe3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "82a60aed-fe3e-4024-b6b2-07ee9d45ab4d",
    "source_id": "e589eba2-507b-402e-9bc7-c25fdbeab355",
    "version_id": "28b23d52-1c8c-49d2-9c70-ac5a4948ce29"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38189/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "56f8f269-abfa-49b6-ba7d-54f4725f5ca1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0c981f7f90e4b489822943d037e9c596dfe339f6eb75d6764603c744097d19e0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
