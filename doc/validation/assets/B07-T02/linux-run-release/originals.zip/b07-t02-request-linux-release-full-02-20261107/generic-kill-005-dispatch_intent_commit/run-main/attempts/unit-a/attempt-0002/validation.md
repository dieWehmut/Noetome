# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "305f04641c5ff3aac79837e8133fa46dc7f7f10044d5c871198a903a9119f0c6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c70217649ab6f405826ebf904a34143b54356585e18be9bfce381bde57e62b14"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dfcc6f43272f24ee18f04f38f2a665cb0e2deec7d48c306a3f1222788f52a532"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "9966deabfed8024a1711988416a82d1f0d503ebf9bd4dc3c88881cea29ef48dc"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7fab0a9df4cc6f1152ce3b25770f99837caca90f93039d72fedc9c32a5772971"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3d2d0861c27854583b45a157dcf7b978e28f44830e9ea87de804f91b9b7ad59d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "783550f5-26da-47f0-a585-4306d1e67ae8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "42df0d97-a5e7-4f12-8e6d-7894adbdf842",
    "source_id": "4b5d70ea-2faa-4cf5-be43-4c1c689046a6",
    "version_id": "9e6e13b6-a1b7-4c58-95d5-819aa7c89434"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37987/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "334333dc-8d87-44f5-aa17-ab3a36d2ea36",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7fab0a9df4cc6f1152ce3b25770f99837caca90f93039d72fedc9c32a5772971"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
