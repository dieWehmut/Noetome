# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9e3042e38cdb18f5fe922e8833486265a8060ffec600a4d1e826f68d474f02d9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ed89532e30de6e712e046f1d793d0925835363282b8c09417f02547896d524b5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3f3f6512ee876128e50250ed085e603e219b560d76b76413feda128d5a0b7061"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "d0ab095b708919cfddbc7797a0f3850f16323f7a31c13b9ef63301e23a3eb4f0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "df46d78f54f77d4f57f47b76f439aa1f72c5427e4ababdde99ea97680ba7cd07"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "675fb7b071e56fb80c5fc3c228281f695ebcf8f8d9d58fc689e211140f7f708a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9756676b-083a-42b8-b80b-ef0b07fc4a92",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bb6d72da-cb1f-41f9-bb8d-c5daf8685fd8",
    "source_id": "647540ce-3110-4494-91ea-3f42e5c90895",
    "version_id": "62afc998-ecb5-4314-8a5b-9edad942f527"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38299/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5939fae4-b530-4380-8557-c3f5b24fc6d4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "df46d78f54f77d4f57f47b76f439aa1f72c5427e4ababdde99ea97680ba7cd07"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
