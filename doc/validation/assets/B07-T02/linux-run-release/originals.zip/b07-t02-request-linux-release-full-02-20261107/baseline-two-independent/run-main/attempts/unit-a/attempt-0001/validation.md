# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0ebc37388ae1414da2e82605b3184a440042e79c91c0ca2ac599e158debfb78e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "85c010ffabe7fb204c250e5d7957cc51a4dbb482b391868dc0f853cb2a360635"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1164189f1e2460c6a722e9dc172ecd11b731b110036f9c18b662fad39559a6a3"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "10ac6acb2699d3870e3a1c0e79da3c922aef212f477571c8c7adc5d71eea0606"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "79809fff6b652b6219142e3ca47e2098bbc09adb64f09e2428132de71ea03d14"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d332b848f70e7ad6739438f0f5227dcb1c6d0e1b0b251f07dc8583e873ca490b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0e4b8384-5915-430b-8ea0-f2d00d3f0490",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "619371ae-69fe-423e-9658-196d87cb0207",
    "source_id": "e709ce07-0f0e-4e1d-8ec1-2c6d0aebd19f",
    "version_id": "158a9606-0b54-4380-9fdf-62aa417b1709"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37495/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "51b68cf6-8ca4-45b1-9a23-2f0555ace4b3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "79809fff6b652b6219142e3ca47e2098bbc09adb64f09e2428132de71ea03d14"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
