# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b5f24d6c61cead7b7096899e601d876163a2ef71f68dd52cd62ac8f6f96bcc44"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5651d9ee6c64e29985f4771639007cb79b440f5b309a97b0c874fabc93c212ea"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "160e16f545ea293df79b2790ec7bf321c0e3858b6464042a5c6f49c3a35110e7"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "04ca3c7890ea0442f5595efa8eeca0d98f753aeccdbec0c29ff6374d08fb76c5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "91f7f6a9a562d4270b6dd704141c955764dec9c64f8c656d0e46bb475e2b44e7"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "df9f66593fb321272e6166ee6fa61ea572fb6dc66536279092f41e914a48b1ea"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "55288a86-b79a-4413-a1bd-372c81214643",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "70c4614a-75c1-4ac6-96cf-121531db23aa",
    "source_id": "befe35d2-1aad-4460-ae70-01716173f8ec",
    "version_id": "1f769461-da06-41c7-8dcc-689d1f461829"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37495/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "aeebe7bf-d950-42b0-be7d-24b7f398d882",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "91f7f6a9a562d4270b6dd704141c955764dec9c64f8c656d0e46bb475e2b44e7"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
