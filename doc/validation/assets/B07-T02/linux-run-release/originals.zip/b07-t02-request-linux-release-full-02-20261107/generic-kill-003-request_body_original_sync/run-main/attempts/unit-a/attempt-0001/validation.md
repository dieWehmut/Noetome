# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6c3a6b7ec77b8a714795f220b6425be8d601f2164521740310dfdaef8903ca12"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "13ff98bd5d5eb1f25692b287c03b0b48c6128dda92d5ec879cc5cce5be2f0e8e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e831c45f96e3994acd32614ce6093941a2bc3daceed60ac3dc05598b73ffeda7"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "128fa654edf34ed3dd6f06d03485f377a8422e87bab0158d4ff7deee73ff8638"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "df57f688266e97b94ed34de061fbbef3a31fe474dfab94e470b3940c30829da1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b5d43be24ef6400d2b56fd30f42e4666b3798ed4ffe604195ff912a8556bb7ed"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "869fa7fe-5f99-4f61-a02f-3593f9097e55",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "15a3dcc1-6e14-4cf7-8065-fea8fd6cabff",
    "source_id": "87e91ad1-94e5-47e6-b526-bc6613466991",
    "version_id": "b1f10dea-4a87-4447-b593-53b7b2aa959b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37337/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1c6c829c-4f44-43de-87f0-d80691e6608e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "df57f688266e97b94ed34de061fbbef3a31fe474dfab94e470b3940c30829da1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
