# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b54d6ee3af35f67c2b0a937192647dbb149d6803982f4ab8a26545411cf8c84b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "322ababe47882d515dff0e17ddf83835f3fcba81c45b8dbc0c3c021ca8bc087a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "75ac42d9c8da8640a9cfb42180a7b6b68c730f7445d9f76e5b4602fca99208e7"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "68c8894101581ad90aaba79bb05f19ba5b5c2020ab8f81ff5e9b347f03ced8d2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b16bbdc091ecf2ea792957c516c12422f9d1104260b3a6775caffe7584a89276"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "daa3e93bcd2129c5b46c1d26b03fe6b5c8770f9ee98073e9bf126dc545f138af"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3241595c-e48a-4d6a-b98d-d71c80bd48d5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "db121abd-4ea4-465a-b617-f53eb221cb2d",
    "source_id": "ab295e6f-9d3a-40e3-9a9a-4bdcd648f2d7",
    "version_id": "7e517a62-40d9-430d-923a-0b84eb3cd560"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37629/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9740d486-ee32-4a5b-9c04-91f72438191c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b16bbdc091ecf2ea792957c516c12422f9d1104260b3a6775caffe7584a89276"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
