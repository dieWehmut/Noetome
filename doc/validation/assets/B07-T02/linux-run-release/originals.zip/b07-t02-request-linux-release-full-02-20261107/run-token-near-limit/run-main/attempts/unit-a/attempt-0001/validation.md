# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c0b4fb4e893b6e7b39e640685aada76d361c4edb24796289025fd1ee1088cef8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "afc49485aaceb62b98552674b173d259f466de85a3e53e9628d573e35a6f1544"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1452f2cc37ede8871750eddf57510748cfbe0af34cff1185060b5ba653fb47a3"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "4d1a03d76113ae103805f7aae297d0a1659c80d7bf6a4de280b18457648ee8fe"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b4d0af2edacd109f4e3590a7f9fa51562bd74ea7958f007098dab3569c9f3e17"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4fb1a98af7e155b8300d4b973297ffcc5d5364caa3ff858ecb6ca893dbb30062"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "40ff2185-377f-430c-9d0d-4016d27b54f4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2677c3da-11f0-4f11-a1b8-2e05d51f34f9",
    "source_id": "ee7a7a4c-ebea-49cd-9396-12b11f8e1018",
    "version_id": "bd7e888d-37db-4eb8-86f2-5cbe422fbe95"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36759/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "225ce47e-151a-49e5-a5d9-1dd842fa94fe",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b4d0af2edacd109f4e3590a7f9fa51562bd74ea7958f007098dab3569c9f3e17"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
