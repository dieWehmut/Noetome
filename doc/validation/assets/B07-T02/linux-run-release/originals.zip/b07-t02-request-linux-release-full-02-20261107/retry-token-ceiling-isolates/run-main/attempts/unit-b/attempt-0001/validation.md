# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fdba27f56199cc0b891c740b0d9f10d4d128ef6538da45599f552298c9a2fb65"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b88f1141e86fe98b9cba0e6f9f539be88ee3a2bb97d5aa6fc001319b6155abb4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bb9835e3157a897a726f89d15d1af1ad57b522792983fc9c2ac7ab95f96446e7"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "d93847fdaaca2eeb2fca426c185fd24d41784f8359f0406eca8c54c3be426672"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1412e8c508349f6b9da25c6daff12e9a205760733e7877d2107b0e2b75cb359a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1adce239f8c266ab14f6cd2d5c683e3702e94cdea3cabf6234bcefa8c957df59"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4169f1ac-fa19-4ad6-b5b1-6e1a5daa68e2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c7628537-ffb0-4fdc-83b6-7421b45770ff",
    "source_id": "2384bcf4-a7e8-47ad-bd87-47eb2b842605",
    "version_id": "d7fe4016-07a5-41cb-8baa-47c561d02e03"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37979/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fd3f19ef-aed9-48c1-9214-21da891b8a8c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1412e8c508349f6b9da25c6daff12e9a205760733e7877d2107b0e2b75cb359a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
