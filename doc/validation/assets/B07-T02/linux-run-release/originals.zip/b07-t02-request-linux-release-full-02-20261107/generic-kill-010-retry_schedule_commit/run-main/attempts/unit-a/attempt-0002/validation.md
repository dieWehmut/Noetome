# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e7a746ed537431a634143af7c64fc282768271a41baad5f4c969c4732c810e94"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cf8c799dd67efb4c8af5338b59983c037ed641cf1b9ed7c478eace77c529eba3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "201e1f51184b335a0a1612289e5c310c5ff9052b5c2aac5d17c3c7f88c99ada2"
    },
    "request.json": {
      "byte_length": 2229,
      "sha256": "1891d7a90f504c9bd3b0e23f97d34eae1f15cec58e8424e3e47f3d8f81765c02"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9b71526b854f6b1a9ceec888fc535b79ad029881560a97cb3eaa8703ddc104e8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e6ae60e20fd2704dbd245d417ddb067714fd1793c47702e7e8af52ad310086f4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ce6ed522-de11-4b8e-b1b6-c2b4e8a5420a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "68106daf-b84a-49c7-bb84-05a8db71f916",
    "source_id": "1fc36581-8d81-4133-bd69-632e82cab502",
    "version_id": "4ccf3575-b0a3-4729-b458-9f80e1a8e58b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36973/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b00c715a-5193-48bc-a321-b86724c8a1ce",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9b71526b854f6b1a9ceec888fc535b79ad029881560a97cb3eaa8703ddc104e8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
