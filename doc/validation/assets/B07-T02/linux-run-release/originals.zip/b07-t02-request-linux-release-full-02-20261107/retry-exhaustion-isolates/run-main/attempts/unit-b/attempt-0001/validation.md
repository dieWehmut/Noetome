# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "69136c425f07df46a261b00a5f8f9d112f62159453b932c55adc2bd18c291e16"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b44e010986c685aafd62fa91d86dd8c00fcad7c1f1ece821906a94565542d824"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b7c20544dec5ed4f6e332b4a77153d61685b3046dd87252f66897d1e14c97758"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "a23c5c4da85b0955c1b555d7b924f48c53a349ffa937d31fa4593e0d47ccede7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4a8cb2bf389e66fe938c7f031c377082a33765d0981ce4193b96f384b0f3c838"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0393294af9fc2c5807a611d297bcc7db83bf06efc1a701b4c8509fc6eae6f695"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9e4023fe-dff8-4f17-96d6-16267d2b29a8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3edfa1a3-924f-440a-be07-00f0f5d1782b",
    "source_id": "b4893c2e-5d89-4fff-9fda-de0abf41b3d1",
    "version_id": "facb6635-f69f-4167-8065-9f1127b1ae31"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37737/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "24403dc3-0da5-463d-b30f-16f9154436de",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4a8cb2bf389e66fe938c7f031c377082a33765d0981ce4193b96f384b0f3c838"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
