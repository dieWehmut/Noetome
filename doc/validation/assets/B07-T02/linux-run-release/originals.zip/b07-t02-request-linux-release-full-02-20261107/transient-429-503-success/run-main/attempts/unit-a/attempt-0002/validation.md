# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：503；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "202c3b549d5c2af145d15f0df9868d302f401c86dfa7865caa361a0c9177f738"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fb11a25a978402d0d11e9b0eeb8086add8bc46f26e46cd320089a11df16ae1fe"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "9b43ced04f1a03b5d33ee751f2ec57640cb6dd52e31c4f64d6550e895c1246c4"
    },
    "response.bin": {
      "byte_length": 131,
      "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
    },
    "transport-receipt.json": {
      "byte_length": 498,
      "sha256": "aff01402f60017df5a3432d8787b57e9519b533361c360f7956fce0f9b17f3d7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a1033b34-c817-451e-b98c-29ae0f75f7f9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4af0ab27-dab7-4eb9-a3cc-16b3104c8954",
    "source_id": "894455af-458b-4080-8164-4461f7ace515",
    "version_id": "b845dc1f-2451-4029-9c25-6e4858db4ee4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38193/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_SERVER",
      "message": "EXTRACT_API_HTTP_SERVER：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 503,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1accdb8e-dea4-416e-9399-238627e57132",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 131,
    "omission_reason": null,
    "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
