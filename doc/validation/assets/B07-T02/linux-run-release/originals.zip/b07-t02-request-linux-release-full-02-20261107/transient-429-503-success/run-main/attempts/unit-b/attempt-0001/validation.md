# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2a0b9bca285f790e8e3fb04443952b6d4a4a5dd348f024640b14c91205578d88"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6a1dd0f4a788a2506eb4db3fb3fe53979463e28e9883441a61068f496c418370"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "07a9b072f40233bc9ad47b13f41daea7ca66cfda25adbcc69e61e8843786c3b2"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "e88861ef9c1f4ddca1a3b0720a40c209b96789b2e063cdafe25cf760b89710c1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e0d336243144426b75c897f509140b8ddc36f15c54c32e9bce1e8b762a7b356e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0738233f310397b04ff8d16bbec572c9b2132bf001d17e0271ee8ef74814da2d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "849532f9-b21e-4062-91ee-797a9af67159",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d6629450-e1a4-4938-8328-1785d5acdb50",
    "source_id": "96083c35-24aa-4db6-a2c9-2c5d179a0679",
    "version_id": "5a070794-058d-47c6-ad22-db9341a629d6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38193/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2ab70211-ec44-4fc0-b8a0-65b5cc6402df",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e0d336243144426b75c897f509140b8ddc36f15c54c32e9bce1e8b762a7b356e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
