# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5345617f0ad04c992cd8d19ce4b4de0c1b65ce758579c3811e6aa07ec215a4fa"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ec2ecf9495a253202967b3d9c65fe867d725d6434c4cbf4ce6f43e9841453dd5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "78cea5a46a71da438800242c870fcc9f66ea992361200ac705d75ccc43f62566"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "2a93f012d760640acba8cb00b369676462db3266c0df975c361ed0886e480eb1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6afd30ce6414ba7f67ee5719acf49d77b7fced5f2349c59c34d5531fd896cfef"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4451b5d6bb8f552b5235995e68805480de8e4445addf5a34e57582e65b483312"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "be372282-967e-41a4-877b-cf05d11104a9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f45dc044-e94c-4dce-be6c-3e0e4a881b7a",
    "source_id": "a4f5c915-7eed-490d-a4b5-db04520446bb",
    "version_id": "c59d8fa3-cd06-464c-9fb5-d415e998e5b1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37081/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f0e40c3c-2fc7-4013-996b-3f256b606e25",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6afd30ce6414ba7f67ee5719acf49d77b7fced5f2349c59c34d5531fd896cfef"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
