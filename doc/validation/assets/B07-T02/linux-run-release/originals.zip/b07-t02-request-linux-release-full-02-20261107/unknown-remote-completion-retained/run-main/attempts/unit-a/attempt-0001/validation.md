# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1bccc24365b174b2f16c72b20652786d3c9b673f9669355c04bcd55b76585b73"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3286e0f21cb3e6a556da4bac0e8e9ef2de3a02d06f07509ba4223b102af683c7"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "30936060f39158651e63eb0cdcb2a1f48a9f02915fc31accd847d08d79a3c4c8"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "ba692df155b856d36d2d8c7972330bd44119138accec6c7c7888d971a22dd54a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "36980552-689f-457c-b5b7-4e370c163e61",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ddcf166-0409-4e93-8360-4b3982b73834",
    "source_id": "8ae42990-99fe-499d-a0db-aa124c755d98",
    "version_id": "aa608395-8ebe-4136-9d17-7bea0c4ce30c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37603/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2e9436e0-0f10-493c-a463-1f4c824070bb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
