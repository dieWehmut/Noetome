# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "306b2970581ed43b4e4ab01ee795963a3597ee3cee15eaa494def9c5dc256aa8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "989b206680a5a6baa2e1ecce4001da0e5f7d85f549dc826795ed513b539217e5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "197401528e5436c7fe53cbee853d29ec966341b8ae65e6288fc6179f0613a506"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "4adcfba55545352a30d0d2289f0677e8b73a4b2a3e9a76a08fb63e958695c152"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c091f928bc0f032af2abcd477419e8b4fc513fbcb0f2eb53dedac46eeee683ca"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4435d78f62ff052b97b17981de6e4414310b83205da4c3b2417d18cc96927fb7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1266dd05-3286-4633-a8ef-0bfe67b36033",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dcbf18af-ba12-45c6-a692-15d3cfd11b54",
    "source_id": "82ff900a-ca3f-4018-b739-d5904ab020e7",
    "version_id": "a6d703f1-701f-4a43-9215-cb3e1304b02e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37603/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a8a7d496-6a65-46b0-a648-4b39665a589c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c091f928bc0f032af2abcd477419e8b4fc513fbcb0f2eb53dedac46eeee683ca"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
