# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ef1a25c5f7b7842e85ef6fea4febddac453343a51821689769da2112d668aaf5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "dfc35e7fe581577ce5e6122644d3fb64bd7345b251d63dcf305f4a72ad638e4a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9b26c198f6f0109ee0da3a6c7d05275fc87ea6d9ee37e5935fb08a83833c225e"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "2ad5f07cf702ae31e36387d7ec487ac8be9a7e75ce97ae33420ac64c672cefb0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7f7e812c80976a02953acd3c47bf5d8874a0593ebc61c370976b9571dd4a5137"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "702256ea27e3b6c97a1f61077c4389c7288195397af6e42a694e4f1845ce8f17"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "36980552-689f-457c-b5b7-4e370c163e61",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ddcf166-0409-4e93-8360-4b3982b73834",
    "source_id": "8ae42990-99fe-499d-a0db-aa124c755d98",
    "version_id": "aa608395-8ebe-4136-9d17-7bea0c4ce30c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37603/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b04076ad-585a-4b2b-8450-32886accaf30",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7f7e812c80976a02953acd3c47bf5d8874a0593ebc61c370976b9571dd4a5137"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
