# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f162919958904cea3d79913412236ee1b6ce0e88e14aec4a59cf56019da18836"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f51dd09be69338a899a9e1f785ee279a25d8c8004bcb117508104b717f9e9b5c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1f8b786106fda3124a9919aaf1b199b954031b7c7ce1a4a035b68bf09d9bedb3"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "96d2b99a50a7091a684f1f436a7cb2534379eabf931aee76ca59e4fb75842ccd"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f5f33b3af66b85e4f2acb73cd70d9d3a92d2772da9c4b301c61b9458183c9a45"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3bc0d3f9b202107d032006cc42c5284e1e4a4e7ebedc2ccc830939e939f97300"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c0685ae1-f5be-48db-8a7d-b394398b50f7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "644a91ba-00fc-4593-9e23-025a2d7b3027",
    "source_id": "9eeb7c7c-8d56-4e00-8e48-11f645368e22",
    "version_id": "b16af649-87dd-4fe8-a2e0-ad290ae2506e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37469/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2987f413-b2a9-456f-bb76-4974a545577c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f5f33b3af66b85e4f2acb73cd70d9d3a92d2772da9c4b301c61b9458183c9a45"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
