# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c32b58b17c3c27b899719782918500548f5e99c3f58dd012e4f360814e08b548"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5d03b0abe4eac772bbfd11ff9d73d2cd8c9db429be52478ae5775e339eaccf51"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "68e77f3467b222903ba1e1ccb66799127ad0168c3bbe10f810e8440ac2af9489"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "216f3a6a76e0e78165e21c0cb6bbed7fb49db0a6b2851201ba58896e37030829"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9601a76e47da7b034b1b66a891f827e416410efbf5cacb366168cd077d22520b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "93f475cd4c52305a1cddbf9f66e5e30d5007d25815aec2d24c4a232a75e3de2b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c37b5892-2ff2-47b1-8aa4-81fa2ee1b112",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "309f36cd-4f42-4e8c-ac79-825cefc4c7f2",
    "source_id": "de7cda04-4860-4708-987e-33c3542cec8a",
    "version_id": "deca0751-8d7b-4796-8707-6767daceb358"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37469/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4a21b0d4-aa3d-4640-875b-fc2461b5ec46",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9601a76e47da7b034b1b66a891f827e416410efbf5cacb366168cd077d22520b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
