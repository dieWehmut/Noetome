# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d7719cdc4d6d2413d9ff746db82d1bb811675436639770d80cb46557cd36490f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "91c216d0f6e0a200a59407e5f010a4c84ec4478c2ccf737a7dfece23540278c5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "753fb103e961ae72380cd74ab8c24c0eba86a02a26be30eece1d708ef761e537"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "b9e1aa038304c4851945fa917ccbfd0686a2dd4de1f880bd1b2292ad5ba42808"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "987f03d88517162dab34a81177d6f5db7a7b9f8b1e7df42788b478a588785ee2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ef8f63d67d235a5fff1d29521d65c3e7e08ff9771626768711f8f3c445c3ccb1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1dc178da-35e2-45dd-87aa-d29f57bc2c5f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e81b759b-fb25-43e1-8487-5401294a839d",
    "source_id": "e0849ee1-0d57-4773-86d6-ffa97ea7444a",
    "version_id": "cac0e53c-ff60-4dcd-86f4-25b43875f84c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38253/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "efe7821a-c5be-4ae6-a28a-99815f46040c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "987f03d88517162dab34a81177d6f5db7a7b9f8b1e7df42788b478a588785ee2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
