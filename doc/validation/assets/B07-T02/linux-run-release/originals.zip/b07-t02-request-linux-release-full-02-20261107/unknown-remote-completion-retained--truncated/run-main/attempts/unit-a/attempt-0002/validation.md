# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7488eeb0ed6bcef2173413b6d350b81252c0a4d82857a38e3a5ba5f44bb1868c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5443dc26b69e626afcc980965c60695318089acddac3ca96ffd0257f38c20a8e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b926554185b51993a93f75bf9c087083ae92238635e50c530a8c2ebce236fc3f"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "f289f7a122c8860e4c71a528d8b520d1b74113b625ef30f1e55034693cc3fc42"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a491f0d4e0923858861984a213442b48977b42c4b8e1220901e26b14a2faa6eb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "15b30678bb56a882311e278ad7a19afec2ae7bbdc368a0a6d517cfe2b2a86536"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f9e03d05-cbf9-4ca9-bf89-714f00b755ad",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "30f997bc-3a5c-4461-aece-e054d042bb99",
    "source_id": "5a933e82-d1d7-4e14-80fc-87d8f27b967d",
    "version_id": "6ee0eb4d-b05d-4443-b3d1-1747d5dde8e7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38253/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1becc50f-c7cb-4cd2-9014-3d237c644b74",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a491f0d4e0923858861984a213442b48977b42c4b8e1220901e26b14a2faa6eb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
