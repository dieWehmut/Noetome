# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bb8673511b8631ec7e54474889b7682e4a62dcfb6116cd0d5b4b436a8764dcc5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6aecb2af695ce609594e72e0030095886b783a9cce5276afbfe2790a2f324889"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4a4b282fe52fbf42b63df3ece1ed135ad8d1387bb340026c5b500a8dda6f0583"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "2cee86f3acd06f34e0f2399abb4043e149f9bdaeaeb48d414935ddf138890a36"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5e7e41b1f6bcca33fa3b057954af92c6a8b2c0ca1c472c80ecff115d67b7e02b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bcc54f0707a73cdaf6ecfccbcefebe20cca635362bcacbc4971b1258bc1a7e80"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d7532a72-19c5-4aac-94b1-418fcf729f0a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "41a7c145-ffae-4b03-b359-e0468843fb70",
    "source_id": "a96dfa47-4ff9-44c1-9acd-bec232daa82b",
    "version_id": "4044423b-fa01-4e66-b92d-b61e58ea638a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37879/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7dd65f8c-b821-4c7a-822c-9ef952d3c2a1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5e7e41b1f6bcca33fa3b057954af92c6a8b2c0ca1c472c80ecff115d67b7e02b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
