# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f0289387e2f5e7dcc7e46918852939ba9be6282bd7a5072ef6c1998a8421b878"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3d96bc8d1f70d434beab1e7bbb2c0733ce9e15f6858368f31eeaf4f57e53d784"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "291b800a653ec4bf6a4dae2b29a2c275ad61a2775c64c133b4b09db8640babf0"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "4a5133b087e7ee03f0e5ff45c16026bad04091fdcd6858adf41c2ff49bb3adde"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ae2084c2f3fce602c9721ed0679660a6e34c74e4361331167a49f211ddb08c57"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "efbaeae5191c56c437af9b294ed203c48689d1e6b0b0606660b86eba420e1b17"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1b03cce3-df74-402f-9090-ba64790424cc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "57f465e3-fc8a-4f10-96fe-421fce721631",
    "source_id": "dd02f9d2-4f3e-458a-b668-c355533e19f9",
    "version_id": "8f089a46-53bb-4dd6-bf77-9ae6a9754e85"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37727/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fb9bc4dc-f6a1-4edf-a956-86afd802ed58",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ae2084c2f3fce602c9721ed0679660a6e34c74e4361331167a49f211ddb08c57"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
