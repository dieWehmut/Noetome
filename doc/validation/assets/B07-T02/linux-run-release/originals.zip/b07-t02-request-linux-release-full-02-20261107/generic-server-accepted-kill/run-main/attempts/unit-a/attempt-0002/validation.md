# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f80293d0c973fb5f36309928c8e3a4276888b1a887bfda0d7a97cbf80ea1522a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "082f7e3f3d047d7be6923fd648e3e15882b5a8098798865bd2faeb8635f9b543"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b6b84be0154e6bac71a3019ebd636c9a561889a4cc95da0bc597ed776b478bc6"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "4dd200ae602881120404b1232949f8795179236e8c34335d19b60900e790cd99"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "77f02f88eb2a2133bc532e011a31a46e8f3d9b9a3b0cb5d4cc5403f5e722896f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "615331e8fee1c008bc415b296abdd16c6391e10767fcfa66308ac94414ec1e7d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8efb9bc2-c0be-48a6-a5d9-ceba92e650bf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1bc8f6d1-ddf2-4e16-ba97-8a40e0310d43",
    "source_id": "26269e2f-44ba-47d3-8491-42c1e4ad0575",
    "version_id": "8a7d0ae6-a691-47e8-b0dd-4be5014f0e95"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37407/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4a88b6fe-b563-47ab-a167-f877508d329f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "77f02f88eb2a2133bc532e011a31a46e8f3d9b9a3b0cb5d4cc5403f5e722896f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
