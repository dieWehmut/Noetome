# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "df58c1b049e2081d407d309ae4b8b4310adabec837ec67ed5690e39bb62f4b48"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "19ef88d246ea29b808273f43816d3a3aa0de51f8bfb3c5f36abcaada9ca3cc8a"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "f2fbcbf32100ef04e794cdfa3c7bd2bc3c2f0af4d10794184bc4ce077a46cf9e"
    },
    "response.bin": {
      "byte_length": 513,
      "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "d4037cb65d9d519057fee0737d2a13511627b17ef8e955b0770241a93924f2e1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7b2edb9b-1e4e-464f-b13e-84a6cd7e7910",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8b5e3d25-fac8-4238-99b8-abd71061a412",
    "source_id": "ca3dc1a7-4aa1-4175-bf63-a3446da6cc91",
    "version_id": "cd454866-7198-4dfc-bfd4-d1a26034b9fa"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36495/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_CANDIDATES",
      "message": "EXTRACT_API_CANDIDATES：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "90a900d7-7b57-4059-af72-91f88906ea46",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 513,
    "omission_reason": null,
    "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
