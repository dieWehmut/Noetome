# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "68ddc60ca8e42bb1af0c14ee47ba12e9ec979d3eb4e207a67e4d169f7e8384b6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "815d011afe06807e8f77a55b9d98a5cbb1894f13af3a06d7071bcf74c0bc4e73"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4744b6da6386caa4776805e32563e1e20a8dd7445a4145bc736f2a428384e062"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "d0df70a0360858756dcc9aed7d9b3fdc804a6d9d8d6eaa446b04e1fa1e7fbf1b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4fd97f896db97f3649d4fe90a5ee05e9e64342fe004c5f8d53dcbc49fe8d8516"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "57b396b8642aff6ce16c51b55f88c591bbf27437471f027890090a73ec1d3648"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a76b7a39-4d27-4185-a361-d7871c86e8c7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "badec827-bbcc-4696-b64e-5b1bbfd5327b",
    "source_id": "a4548dc4-bd6b-43a7-8d59-7c71ce50ffd7",
    "version_id": "bcc61143-9855-4746-becb-2f3173f0f3d1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36495/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "65d79077-0261-437b-9d6c-155536a16238",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4fd97f896db97f3649d4fe90a5ee05e9e64342fe004c5f8d53dcbc49fe8d8516"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
