# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "acd1e8d37fc528e9b7ce430f7bcdb85dfb8bc7f0b73760c8fe86e41b0bfb52c0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "80feece85c6043d61d54f9cf3948ac71a834fee47689421c0e121108bcb18ebe"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dd34d9646c1f741890525aa52b7f3989e08b61ff4562bd435e1129b5c7ecaf10"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "6a3fe0967995bdfb51209f1cc8803d50ac788c54e3dd016a35e184a9603a095c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "173f182315662bcae58b79512509d47ee0b236e38b59ea8a34074cf01ba4611a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "981109605944713cbb21848d57e95faddefab35f3c60c3f0fe12ec2b86763e3e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8ab84aeb-e691-4727-8456-3f7278cb87f4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a4585a0b-1881-41a1-9722-9529d400d652",
    "source_id": "54196310-e25d-4a78-91e6-19d2da81bb6c",
    "version_id": "9dd6bb97-835d-4fb5-b428-49ed2a535339"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37145/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8d3877a1-e363-4a6b-9e33-22b4fb9a7443",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "173f182315662bcae58b79512509d47ee0b236e38b59ea8a34074cf01ba4611a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
