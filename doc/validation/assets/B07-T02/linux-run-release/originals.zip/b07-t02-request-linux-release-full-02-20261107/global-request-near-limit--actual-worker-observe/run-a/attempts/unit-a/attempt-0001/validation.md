# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f5ab611ce505dc5a1900383f43c64a4d4d46aa8697800d139d58d143be2ef880"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4eaf627d910b13b958bca24412a456527daa40cb71361955022312e5a804f22a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "703bd65595d15c8d8e794b8bd34e720722e97d69e5d5543c9ba45f57c45c8835"
    },
    "request.json": {
      "byte_length": 2239,
      "sha256": "7554f3bdfdd404932c47be7fec049320483d6b04102a9d5cc352b1abd04c3549"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "61a0c08ea4393d7dcf97f16da8f4c08debe5f4e6a05737bacd7e24252c0413a6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "766d7cbe3ff3e92cf95280528e653a05ff75c80804f20fbaf187c115c273fed6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bf58034f-0b77-4dc1-8ef7-997aa441dd6e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "01daf148-1d23-43da-a65e-f6f4e7c62de0",
    "source_id": "48fee896-8ec6-4788-b37f-0a571a7a717a",
    "version_id": "00346cb1-8de1-46d7-950d-0cbdd11c8f2e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38027/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "75c93e05-1c2a-4bd9-a983-5b25c5d8be27",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "61a0c08ea4393d7dcf97f16da8f4c08debe5f4e6a05737bacd7e24252c0413a6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
