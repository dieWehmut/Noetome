# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "661bc71702693fb4a5d66327b14614e8020a98a34f4b77c406d2ca399b4d311a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "134ab521e86be44c50c1748957c1e80a0aadc7808b980915a287e8c9abeaa4a2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bb5bdfba2f9e4ffa38014bbdac37855e822571cdf52c9f29bd68c366640aa1aa"
    },
    "request.json": {
      "byte_length": 2227,
      "sha256": "ac41300f63f0c800032ed65242f0093375c36e965df2407bb66520cb0c587dd2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "92afc7e9e6bae9a8b68784b227923a4f928207d9ac7a6710b5c7482cc0ce69db"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c8bbb876a3015be682495bed032b4888f732c8bf5054f290f5c11191fd960502"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "702f8303-3376-4ca6-a0cf-e842a4ab8cc3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2ee1e87a-6c6e-44d0-aabd-65f68a555e85",
    "source_id": "300c2ad6-6734-4546-a0ad-d01c2abd3319",
    "version_id": "198fbf52-e6da-4b82-8533-339ac7686942"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38333/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b4fa56e1-2915-42c7-83f8-d7272b670d82",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "92afc7e9e6bae9a8b68784b227923a4f928207d9ac7a6710b5c7482cc0ce69db"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
