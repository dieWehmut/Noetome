# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9a61c20cf9e4e7be3f8bd88986b8620813132a2c5f3d9e4b7f1d84ec02cf04d4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ca3d9b6a219483df33ac69f8db4120fafd1d6760e1ea5d860b88c3be1f55f708"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e6c52340a6cc4c1908860e3401aa59feb721f2e5333cf37dc631c02d78740d55"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "51498bbe3117182981dd28c02482665a8fc619df43694f7249733b505306c4ac"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "df639b847ad5cbb7f79293d31202994114ae2fd752859238a0946eea124dd3c9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "24eb00866240fa923d40eb8111da111f47fbda57194e2e9ec3f661277b23764c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "602a6094-b962-4ebd-be3d-2ae3b9f5e172",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9028ecab-7e35-4c44-a155-6ef6a17cf44e",
    "source_id": "13072806-1841-4c84-aee4-a63f496dced9",
    "version_id": "cd7f0b26-adc1-44fa-913e-2b889532ba08"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36647/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ed69773c-ff3e-44df-a327-dadc9192f026",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "df639b847ad5cbb7f79293d31202994114ae2fd752859238a0946eea124dd3c9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
