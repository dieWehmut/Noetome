# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dfd97a69a96f3dd1313a53e36caca6c4354e7c24a95c1cb6b4dbfae6f71b81ba"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "949186fab0ff2c05f91007abe45b50cb57d8e3653e93f028b657b92fa3f5f518"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3ba7300c172bc01b71d21c5fe790bc19463a07e6f82f7001689d13296a5bb0ca"
    },
    "request.json": {
      "byte_length": 2249,
      "sha256": "0106358c03f25f72930ec08d4ae0d6a0aa306e6f2a9408e90c2d2769bfff6f25"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9164cc9945e0c12a5240f173107848a02d1010d8ec4656a8ff4fb39d17713a96"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "47162539950e8d9696c2d947fdb997a46436474cd8e712877db4e8131db1a305"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "620b0295-43ef-455d-b273-e4be953f08f2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "28193d0a-9c2a-4f88-ad1a-62d4772ca662",
    "source_id": "8d3026bf-51e6-4861-8372-0090b66707fa",
    "version_id": "48d18c33-b4e2-4532-82bd-f8cdecc5b19a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37967/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "80ec2f18-6f07-46b1-9e4d-fd0baad8aee8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9164cc9945e0c12a5240f173107848a02d1010d8ec4656a8ff4fb39d17713a96"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
