from pathlib import Path
import json,sys,time,os,hashlib
repo=Path('/home/lyinn/project/Noetome');sys.path.insert(0,str(repo/'scripts'));sys.dont_write_bytecode=True
import verify_request_budget as a
root=Path(__file__).parent
pair=repo/'.artifacts/b07-t02-linux-release-pair-01-20261107'
r=a.Recorder(repo/'.artifacts/b07-t02-request-linux-release-dual-target-01-20261107',pair/'noetome',a.FIXTURE)
try:
    r.bind_build_receipt(pair/'actual.json',pair/'request-test-driver')
    cases=a.author_check(a.FIXTURE)['cases']
    for name in ['retry-backoff-persists-through-kill','elapsed-limit-persists-through-kill']:
        a.dual_unit_kill_case(r,next(c for c in cases if c['case_id']==name),pair/'request-test-driver')
    original=next(c for c in cases if c['case_id']=='unknown-remote-completion-retained')
    variant=next(v for v in original['variants'] if v['name']=='OS-kill-after-accepted')
    a.dual_unit_kill_case(r,a.parameter_case(original,variant),pair/'request-test-driver',accepted=True)
    result=r.finish('passed')
except BaseException as e:
    result=r.finish('failed',{'type':type(e).__name__,'text':str(e)})
    (root/'outer.json').write_bytes((json.dumps({'actual_PID':os.getpid(),'status':'failed','failure':result['failure']},indent=2)+'\n').encode())
    raise
(root/'outer.json').write_bytes((json.dumps({'actual_PID':os.getpid(),'status':result['status'],'ordinaryCLI':result['ordinary_CLI_count'],'drivers':result['driver_count'],'cases':len(result['cases'])},indent=2)+'\n').encode())
print(json.dumps({'status':result['status'],'ordinaryCLI':result['ordinary_CLI_count'],'drivers':result['driver_count'],'cases':len(result['cases'])}))
