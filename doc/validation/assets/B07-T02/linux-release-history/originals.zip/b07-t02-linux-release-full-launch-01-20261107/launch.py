from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path(__file__).parent
repo=Path('/home/lyinn/project/Noetome')
source=repo/'scripts/verify_request_budget.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='153f31dc3fdf6c0a23f547764612ac4b486c19207fcdbaddb2cadc5e05d9b51b'
pair=repo/'.artifacts/b07-t02-linux-release-pair-01-20261107'
argv=[sys.executable,str(source),'--cli',str(pair/'noetome'),'--test-driver',str(pair/'request-test-driver'),'--build-receipt',str(pair/'actual.json'),'--fixture',str(repo/'fixtures/run-api-budget-v1'),'--new-root',str(repo/'.artifacts/b07-t02-request-linux-release-full-01-20261107'),'--full']
env={key:os.environ[key] for key in ['PATH','LANG','LC_ALL','TMPDIR'] if key in os.environ}
env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',NO_PROXY='127.0.0.1,::1',no_proxy='127.0.0.1,::1')
with (root/'stdout.bin').open('wb') as out,(root/'stderr.bin').open('wb') as err:
    child=subprocess.Popen(argv,cwd=repo,env=env,stdout=out,stderr=err)
    (root/'launch.json').write_text(json.dumps({'argv':argv,'PID':child.pid,'outer_PID':os.getpid(),'utc_ns':time.time_ns(),'child_environment_keys':sorted(env)},indent=2)+'\n',encoding='utf-8')
    try:code=child.wait(timeout=600);action='ordinary_wait'
    except subprocess.TimeoutExpired:child.kill();code=child.wait();action='own_timeout_force_kill_wait'
(root/'actual.json').write_text(json.dumps({'PID':child.pid,'outer_PID':os.getpid(),'exit_code':code,'wait_action':action,'utc_ns':time.time_ns(),'scope':'current153f actualLinuxRelease source-bound full62; no reuse of priorLinux06 debugpasses'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'PID':child.pid,'exit':code,'wait_action':action}))
raise SystemExit(code if action=='ordinary_wait' else 1)
