# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fdb918f027f223a51dc98041a4412e7d6127fc2ccb875df73865261a30d6da48"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "48712a2531b841ad8363abdfddd82f9cd6988261e06713e403a22ef60ec8513c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "80baf0c3c7345accaeacc817856376ebe601f79fc9a3c382d96b4c92d3d4c65a"
    },
    "request.json": {
      "byte_length": 2239,
      "sha256": "20c03824847f149d8243100254616a7104c2602c9f3e615358263ec13e6aa8ac"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e146dae0d1052a6e58be14adda298960068faf8e0db44b0aa72d7e718fe0a855"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d4212dc21b1cf1fa30f2150f038b8b9062dfc6b88778412361ae93d293534454"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b11cce83-5a60-4a16-acae-97d9e45edf64",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8ae3b740-8c66-4875-9e6c-ae5becf3249d",
    "source_id": "76e51605-d9e7-46ae-95e2-6dc9af2cea28",
    "version_id": "c52f7af3-482b-4469-94b5-d7f8cf81ceaf"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36597/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cfd1f11c-4511-4941-a041-79414c51ceaf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e146dae0d1052a6e58be14adda298960068faf8e0db44b0aa72d7e718fe0a855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
