# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dda1455d44a9c9205f6aee7e00a2cefde0c2899a9cdfa07cbaa4c608ce8caeb4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "61e8cb98a4a23ec5bcf13b7f96748aa4be768e527916f17720e8495753b3622e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7ae843de7ea7ac3b9d4f0b2de36ad98892aae6e60137e3a1a17885595b37e2ac"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "c60c27b09c26563d2e796314530f1f0bfea2c744b2ba39620f6c799253e5e476"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e6b9921753a8d3f16a77276f653785f524bed7ca757ec861e3b63064ab0a442e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "87ef3a49262ed9b03a2108dd805e8b22f5e3c0341c136b4bb85567be3ba4ca71"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e1ca30f6-aacc-4f5c-919e-5700b45b3147",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1e58a16c-f8c1-4157-b597-3212def8a28d",
    "source_id": "98c7ddd5-8e76-40c1-a34a-644ebe57a400",
    "version_id": "4dbade2f-f247-4b24-9067-b256c0354c16"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37841/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7b843f69-f7dd-4e21-ba4e-65d0c61ccb3d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e6b9921753a8d3f16a77276f653785f524bed7ca757ec861e3b63064ab0a442e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
