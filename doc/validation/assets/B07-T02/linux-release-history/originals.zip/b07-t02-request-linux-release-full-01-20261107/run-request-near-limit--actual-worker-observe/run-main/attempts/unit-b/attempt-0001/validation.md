# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5a9464a752960dbd535b1f853a04da50449bc7eaa2079df5cace58c6c76a0879"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "122552d78465338a8d4ad3026360ba64dae4cab781ac854aeac3b8aa5cd366a5"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "ac09e29ea029ea0237dc7b04b663a89251ed4cdeb475567aca81f5e2e1561df9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0ad2486a-8b6c-4506-a6ee-b1e3b30ba24c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c455f0ba-00f2-4699-afab-dd87f399819e",
    "source_id": "3cd6942a-1db7-4567-ac5e-979d474b50ff",
    "version_id": "05a8c410-ced1-4b10-93fa-edeedc230596"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37841/v1/responses",
  "errors": [
    {
      "code": "REQUEST_RUN_BUDGET_STOP",
      "message": "REQUEST_RUN_BUDGET_STOP：准入拒绝；未发送并保留Prepared审计。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2c45fb48-ebb1-48ea-9d1e-d15c16ef277e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
