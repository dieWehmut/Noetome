# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fc16c3dab2ebe6fe32c4cfff6009858345f2ff472a2e74ae248f98bd60ce8b2d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f1c4492f9c3d3c1ca3c47a3e1119bb5a90a83633e72b6109387f571829ae1ee0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2001a4fa3161fd4a803a607753e836cdd337350d17e6527c9238155e55d968e9"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "da34f682cf39e4fc12e091563bef17399e646a4e21fe8a22c89230c1528c06f5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d919c5087e986db1e7faefca9c089b455341f73e2cf856374f41f8cbf168b88d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1d5bf54aef91ced7200b6a0b3727a1a3d0f26701d0b3c458d724c6db6846eec1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "699cb640-8e76-462e-aaba-9afa48339cb1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a04df27c-c55b-4a85-9541-55d99452c84f",
    "source_id": "cd5737ae-6456-4083-8fc4-a3e14cfd19a5",
    "version_id": "e020b8f5-6781-48fd-b8b7-c5d5a4d0544a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f1ac793e-7a06-4127-8745-7bccf2222aae",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d919c5087e986db1e7faefca9c089b455341f73e2cf856374f41f8cbf168b88d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
