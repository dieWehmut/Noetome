# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2636104096b8c4330dd00eaf1b920c59d929f4b311fb1130542314b73fe9bee0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8f7f58cb44e6844bd7713c6e988c2b661630fb627c9a13c22a67bc5dd77b3a22"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2649a845f0413515e4267f1fc189185fb51ab68a445439655d5476e0c9e45c12"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "cb3bc3403c787244d094a85bb5632d79d91a4c662628897bf8776712634ffa75"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8eef04df38d9c8d084493ed19d8c187f9a4b119f705767c80f90509f8fe092ac"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c2877dcf6881174dffcc3b670d8a25d5a56743f90a22f585a803178a6f0be5dc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d843e7b0-ab61-4f7c-aa67-627bbf28acb7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c1590969-7354-4150-880f-71612d2373f1",
    "source_id": "1cc5cfef-4b6e-4f0b-9f2d-61e322185331",
    "version_id": "c3394e68-9311-45e0-9d83-eb87307fceb8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "49a82c1e-eb3e-4e37-ae1c-0c05e8770856",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8eef04df38d9c8d084493ed19d8c187f9a4b119f705767c80f90509f8fe092ac"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
