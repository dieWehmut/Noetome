# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "02a49f1762710626e5282082d8e442cb6a9abbb7b8bcfb625ac6bdb0c1e3dd09"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "23be287c311c319fa2a7cf5ba5787df49da1471d19a427443cc53c7270dc76d3"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "71b690b1ceb970f47b435852d4d696f30b7245f57ca0e52b65103cd87eaff08e"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 482,
      "sha256": "92bddd25f311ca966ad6cf8a791340248e10803648ed7b871977da49e34e6794"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "699cb640-8e76-462e-aaba-9afa48339cb1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a04df27c-c55b-4a85-9541-55d99452c84f",
    "source_id": "cd5737ae-6456-4083-8fc4-a3e14cfd19a5",
    "version_id": "e020b8f5-6781-48fd-b8b7-c5d5a4d0544a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRANSPORT",
      "message": "EXTRACT_API_TRANSPORT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a4c03526-e5be-4600-bd18-2705a6b40cd3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
