# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "49f6723e26400b814fb01355824190238a141eeab03854699f1751bead764b86"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6059bbad0c0509edadcb91175d282f5d212630499ee4cc2007d126598e93cc8f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "73e7f4589a113b37dfcf26b4d071f38a50a9985c50761c074d98876b36f5a783"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "7ec715c216cf1719c20af3bbe7d69e0976b15234d411d4c8f4e5e9e882cd3fd2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3e951fd306b23da1ca0bb7b6811afe8f20ab6ca4dbd9143b1d8532935910ad9f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1b6c03fd4f38cd6cf201bd43de1164b9085bfc282c6c561769dec7b28601f474"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "17c4f221-1712-4e27-bd3c-f128c0d24333",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "63514c40-31a4-46ce-9075-d9bab6a67b9e",
    "source_id": "bc3f15fc-bc47-4a54-89a4-c43330383494",
    "version_id": "527c5590-ef5b-43fb-93ec-cb3bddd01807"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37487/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8983651b-048d-407c-a142-ec83ccb2fe19",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3e951fd306b23da1ca0bb7b6811afe8f20ab6ca4dbd9143b1d8532935910ad9f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
