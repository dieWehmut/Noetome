# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "030137d89041785f430c4cc519f578313b7fb4ad56cfd8774a00e74cfe673c8c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "de9cf7ae016fe38ae9fd7ba60e7a6bd95b743a6ad62eb2365e96c8b731aa1806"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "14659226583453ed4943ed8db99bfc944896359e07317ddeb3cfff6c4d57ee50"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "30f243ef843e5e8f606aca12041bad3de99476dc0c96e0d714b3734e26cfa025"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "196b521ea447c331bfa7b929f15118a2e506442014106ec2a3649c0b0bd004fd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1f0c40da0359e7675d04b2a9d2b9e614fcd1ed8fdca1786a052864ab96a6b37e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "99c46a50-faf9-488e-b8b3-4366f61aca45",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "80f0adcc-b84e-4ae7-83eb-6b5e556b719a",
    "source_id": "b09a06e1-0533-43ae-9b21-e9be3d05db96",
    "version_id": "22ae4540-0f19-4e7f-b9a0-461ceee64dda"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38335/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0c1fb9d5-4611-458d-ad94-bddae90ebb99",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "196b521ea447c331bfa7b929f15118a2e506442014106ec2a3649c0b0bd004fd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
