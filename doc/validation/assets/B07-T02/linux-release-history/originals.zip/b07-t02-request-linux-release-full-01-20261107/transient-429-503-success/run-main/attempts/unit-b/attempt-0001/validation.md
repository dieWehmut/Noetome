# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a5606360bc49cd958c30dedbdfaa0699d48630e287fffce8d1e6453ec063c095"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b667d7df27b1b99ea84746864f3947957cd71394c7de3142fb9691b7a6524f1f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "36b60e0671d5c2af6da7a1721e8854b17cb47d2fac6b48f7602e614601d8a55f"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "3fe03e8cd2880ad4d72b0993aef01700250ef535d6916ea3b66b68cc310fdca8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c6d328d2a6f5f3774ce99f33b3f4ce96c3324303bfe8ef2a182c753c5ef0cd5b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4e3ad34ebe6c2795591501a08142d8c568934b36dbeda105d7005e9be6fdcd69"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cab45443-0c99-403c-be26-623149ae6f5e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "51afe784-5c1e-4059-bc9a-41162907d664",
    "source_id": "4badce45-4626-4523-8a39-e0ba4267f041",
    "version_id": "5b8fcc7d-3dd6-470e-9279-342d29012b85"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37727/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d1a687c3-2226-4019-a93d-b083772b206b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c6d328d2a6f5f3774ce99f33b3f4ce96c3324303bfe8ef2a182c753c5ef0cd5b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
