# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3b72dd87b36e6355608ae91aed2ccdbe08d3c8b7042667f1e5b0da595096c089"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "19f46c766a714f1b01a977356355a0fe8efb6741847b02bd949b54a4f970f0ed"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b2daa532603f940ad6937e5f142f510645036c80d90e1ecb3e1ad8f1ad6b0b02"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "7c1800ab2a2178a6b42a7cb8cfb249d8e313899769f2291a415fd341053d464c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "31999c271ab835e95a0f743d4ab5d16a040885e9e73ddd9e2f7afcbb17347dad"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4d208c5d04050fc8592840b320ea9e1ee9f76014e6e1a31042579f5caa8dde68"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b20a3e44-b69b-4650-ba00-e3a924ac59cb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f559cb45-c562-4233-b764-869b71476380",
    "source_id": "4021fcf1-a6d8-4d56-af54-f62ff9d563d2",
    "version_id": "d6b20a7d-5e1b-49ba-922a-64cf15f11a71"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37727/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "08072591-23c4-4bdf-92f3-be7c7ab2051d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "31999c271ab835e95a0f743d4ab5d16a040885e9e73ddd9e2f7afcbb17347dad"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
