# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "676187e43c7468493ec313f8f0abfe1c66b47d9300ee56924794a2ca36ff0ada"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4dd7e1090b23dbbcfc9c3c65ac8d2b37d3a3379fc96cfb1098c8d52b9c1befd9"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "a82ff83b1ab900bb70ed2157e2742b9c145ff09acbbbfa36a26620130782df19"
    },
    "response.bin": {
      "byte_length": 513,
      "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "14860f33f44eb50bce751aace16be32f66cd4ce79ddb706a3a25f525bcf89099"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "07cfe63e-ece3-4a31-b358-6dca20e99510",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "79194e84-9aa5-4e6a-adbc-8c31a1621fb7",
    "source_id": "7b1b9a37-92bb-4ac3-bb76-b2a9948c71fb",
    "version_id": "7d77e484-df82-40c7-b8c1-256e8834829a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37879/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_CANDIDATES",
      "message": "EXTRACT_API_CANDIDATES：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a088e572-060a-4688-b91a-51d940b42c18",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 513,
    "omission_reason": null,
    "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
