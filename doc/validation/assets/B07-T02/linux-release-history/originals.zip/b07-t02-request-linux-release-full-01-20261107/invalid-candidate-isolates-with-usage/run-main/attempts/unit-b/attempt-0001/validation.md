# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a0f724c17b69985b1193c7c3d5e68a5d8737bb7186da2a8a715b03f3dc5cb65e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ac1e76ba08b563aaf8ee02773b2bc492266d0812a89abbf920267d4c2ce4ccb9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "21121289f9ba2bc31bfa80ef81f2fe95918c5b511e4af92b73d3f20aa1269b36"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "17295b7ec2af4a80f3c53486a701d0c2875329e7847498bbaf3852ce1555406f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "cc2eb7627051d41b9a577a9229f30634d3cf11903bc085c57cfe06a00031c00f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "be05d943c6a10418827bfc4ba696c2680444257a6d30d988aafd0f4a6bc9bbe5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8a3e8296-7aa6-43c1-b47a-74b10e5f3742",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5df42624-a6e3-4d2b-9b89-2cfbd9563383",
    "source_id": "d716cad4-e3e9-41bb-a892-740177f7af23",
    "version_id": "932f87af-0515-46e1-9989-6ecef2e042c2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37879/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dbb9f2bf-4f1a-41e7-bc48-2da8a0a5744b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "cc2eb7627051d41b9a577a9229f30634d3cf11903bc085c57cfe06a00031c00f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
