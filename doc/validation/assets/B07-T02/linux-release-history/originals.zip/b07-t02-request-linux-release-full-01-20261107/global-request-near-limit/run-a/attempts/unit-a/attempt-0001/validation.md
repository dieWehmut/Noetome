# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5410afa9bb274f39d1ca60df78365650ea697f07ad890a1517dac01c1e372585"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c7ffdd2ba80dc6a09702457ffb53349bef6ddff4570af70718c10a786769f94f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1697a31b9b6e6b97ab5a8c5a2b64f9316ebe57b00f9d8f2ad21e77d1942b6393"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "26ad75d5e742719a32f14365dc03631f76e0b3e84923bf5ffecd83e56846a94f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "66e7b10b484b36adef1fe687971236b72db1ae0ad687f4c64cb6c5f907a24cf0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9f554f134d16140bf0432b0d3d1c7f747083e1b423b4d8ea7c89e513c0d34cd7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d3c1ec57-db12-4797-bf84-9f0de0191cbd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1630febc-1d97-490d-80e0-b6d1c989a7c0",
    "source_id": "132e594c-c4d1-41d7-a689-c7f392b51299",
    "version_id": "c16db8d6-bdcc-4a5c-8207-f028f1a12f4f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36541/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "518cc1b9-88d4-4fb0-826f-6b510cdb0d12",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "66e7b10b484b36adef1fe687971236b72db1ae0ad687f4c64cb6c5f907a24cf0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
