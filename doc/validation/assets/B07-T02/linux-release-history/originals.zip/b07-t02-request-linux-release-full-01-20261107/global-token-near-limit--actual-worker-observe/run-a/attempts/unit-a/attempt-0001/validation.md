# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ff73083f7c57008e9ff88d1d655a0118fe6f2f8a2a7968ad699e0cd7bfd00ebf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ba3b5f17866c9952b8566da3fa1ed3c1af489579b93e0a4b2bb7694d72792188"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bccbda42283e0eb8696c13857b81ee9c91d1276f21f213bd4b721b157303c2ea"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "1daca9087c162206065f8f8d57d024cecd0866258c75839e12e41c07cd9edb1a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "aceb70be6d5cca34ef65aab4be2ded1381e1c01cb76cb243dfd3d319cd8e1dab"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cb058c4785622e6672a92ae3ed2204762193cf416e1e368c9bdbcf9e0d0a0814"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "46e423ac-ad92-44e7-8a68-b75a452b7ae5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a343685d-6088-4134-aaab-948ab41e6bee",
    "source_id": "31f009df-dacc-4884-907a-189d3f708333",
    "version_id": "eff4e9d4-6bce-4fd3-868e-477cd6e25681"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36811/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "99f55660-580a-47a9-bbd1-e86b8d8909b8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "aceb70be6d5cca34ef65aab4be2ded1381e1c01cb76cb243dfd3d319cd8e1dab"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
