# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7cf096729313beb81a976bbe34750c184b0356ffa34679965e53c412d0a43f2f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "da30847fd0c2251ab6704641538a257352fcac9661d8c03708677160a0fe5d8d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1750d56f0414c08545c8ffb81ed65b080ecda5347b1f05bace4fe30242216f2e"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "164624e9f7139ed992aa953a59f38bf095b02d16507adb069ebc42ed205d4261"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e04383605e39acefeeffbd78e62c55370a2fd26368115d7707af9583c992734e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9155e5aa2a4445a82a82bd8307dcadf52fab1ca8a322963d8c3b23a55783bf64"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a588d917-bb1d-4767-9b5d-ca7293ee844e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dcc89d14-cf0b-466d-8edd-7cf3b6ce6e2d",
    "source_id": "0b2ea6d8-5e40-4453-99c3-2a52da004770",
    "version_id": "cd90e1bb-fb54-4c7d-871c-af9356a34d95"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37891/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7b3a3bb0-2034-4bdf-a4bc-fd664ea1cc7e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e04383605e39acefeeffbd78e62c55370a2fd26368115d7707af9583c992734e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
