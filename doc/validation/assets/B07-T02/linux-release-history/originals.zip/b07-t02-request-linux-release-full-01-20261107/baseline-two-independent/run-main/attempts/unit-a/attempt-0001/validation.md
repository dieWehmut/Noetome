# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0357152c28046221e4828bc0b872a5cb0bf69d828cfe151deab8a62856717bf4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b01699763cfc78724ab7edf198617a98af1e26fd64fa0b7bb5f34f7a865507b2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "73f717a1521639e6eb372d097197ebdadf2bd5174dfce638fa613ceea9a1fc2e"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "a33881c84085d4815ebedd0a56bb201a21ffa004f581ee64aa7f697d8095b0be"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6630843683d2d0e416be8bfaf24281ce43203d387ba414e749b52bbeb949bbb4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9b5002cc470cbab9a6f6ccafaf2295c32322bd10d6190012b04c7c8f28b6210f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b880a5bc-0f46-4076-87c6-6f030de651eb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bfa597ff-302f-475f-9e60-0add631421d5",
    "source_id": "edadf66b-83bf-40d0-985b-537d8ff66f91",
    "version_id": "b9541448-ae44-493d-8fab-e1db6dd2c618"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37891/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cadeef97-6796-4212-a13c-5d5d1149d900",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6630843683d2d0e416be8bfaf24281ce43203d387ba414e749b52bbeb949bbb4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
