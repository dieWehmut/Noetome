# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c11497f0076f9a1464d3a790d374fd118d50aac0c7cbd6127ed56cccd7569144"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5d57c32b3bf722dc9f0b133adb710d30c8c1f2fe6cf0c1b9b183ef8abbc20007"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "596f76844a791264f830af1c94c955aed65a7338686aab09d71e5c0c6d1a01dd"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "22cd7ac55294eb4d3f643ae9ddcc9b237182205955b803e9da95fafc46784ccb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ab2a3be5af6b4bf946c50f1cc305ae8e43ecae443cfbf7236d92282192fa1ab6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "27e4f7fcfd6b2971a8982f295156eba6e7512f55afb940ba39219d1d364a6de8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e9b9305f-d752-4cf3-b064-73579c7203c5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "62b70478-0761-480d-a66e-074f3a059b3f",
    "source_id": "9a72b176-ea04-4716-807f-5278f9545e21",
    "version_id": "f0d1d311-fd33-455b-97eb-745fb2498848"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36815/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4aa6ba69-c414-4da8-ac7d-6c0dac61b6b2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ab2a3be5af6b4bf946c50f1cc305ae8e43ecae443cfbf7236d92282192fa1ab6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
