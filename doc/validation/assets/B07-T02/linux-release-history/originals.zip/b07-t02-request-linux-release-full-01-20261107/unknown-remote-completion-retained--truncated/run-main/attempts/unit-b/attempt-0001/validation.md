# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "65aa1c346f78a84aaa58e77c6e35ef72a8e18d09e598622734a35e3c7c51b0a5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d0da25e2b14ae1810b4005478f8e174ff540a695dd59a255a2a1c21a2fa4cb21"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "21246e4ed96fcca59c274ac6e4ee81ccf8076a782959b7c6096040c77681ee20"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "7c1f44fc409ed4b5ca59aef49412d99740394c57d0ca2d1cf5959775754b9544"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5b7d266914f7ff0124ebb0338d8f4ee2bb9eed2ae34a768aefb76e02efe8df6b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9154c58c5978c87c12ff40ae9aa6ce5360d27202fb54f4033c95761e1d1ddfeb"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0f6d2068-43f1-483f-a536-870742f49193",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "24a64d73-2d95-4102-aa5b-f1e38a448d79",
    "source_id": "f98e48c7-605f-46f7-ac1c-05d0bee0b41b",
    "version_id": "e8f6cd4e-d3f5-48db-9143-354326dd233b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36933/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "56422576-4f3c-430e-a7f6-c9bcb1462840",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5b7d266914f7ff0124ebb0338d8f4ee2bb9eed2ae34a768aefb76e02efe8df6b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
