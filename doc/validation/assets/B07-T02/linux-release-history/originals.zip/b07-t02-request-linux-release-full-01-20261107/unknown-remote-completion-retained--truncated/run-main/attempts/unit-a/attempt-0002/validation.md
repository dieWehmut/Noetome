# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1fe60ae8565b9e70c4f022dea768c513c1986994f5b710c7dab6c5c339745717"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c77eac99eb787d4971bc1c7c3ba54479f8316ed35bad86f539da9377945583a1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7e0421fe37c2bfd65de4d78fcb184de04ff5fa65a468fb55183f96daaf0025d1"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "9dfeb1d31bca54d158ed0714d5ac1a40bf4dccd1581f1d286b4a5e829cd49488"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4c43e2e74d49bbe4f83b5808951e3fd737a82c367956bd70af6321479bbba8f5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cd26021d55edbf3e0a1082950e2fd81fd0894d791873d392905d5943e57f3a2a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c27a9436-43f8-4a59-a9ad-b2e1b0a95c28",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "12057efe-b2a6-4ba8-8e13-62f576684112",
    "source_id": "2bd50f4a-a5ce-4790-af7e-05a18d03c276",
    "version_id": "a6d20909-763a-422d-8f0e-06287dc5bd1a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36933/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "58e611aa-13a1-4513-bbf1-3a9d3bbf1f67",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4c43e2e74d49bbe4f83b5808951e3fd737a82c367956bd70af6321479bbba8f5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
