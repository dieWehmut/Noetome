# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "133f85d11a748b45ac055fde18dba86c11c9fd2e5c4ec200fd4acdd42bf4a4a6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "68c4782e46bb32bc3fd790823b8b836adc993adeeac94b0b2fb9e875d86bc8d7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "99cffc2a7fe6b91aaf43a76772786c467331c182bf5b6d95d1aae8fca77603c1"
    },
    "request.json": {
      "byte_length": 2249,
      "sha256": "0a5c69abe709d1a4fb9ca0e781d9c9226f9291aca71571f23e1797b04be9e3fa"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "23e1f9f694359ccca668149cb8154407a6644fdeb9772f2a76e1c04a46f86d9c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2454e12801e964f21b44c54025b839e30ee1d16a11a6e7667862080235b8fecf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8a0b22c1-9368-4734-b3c2-ccb41f3ec183",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f9c64330-d628-4402-a319-c153fbf6d769",
    "source_id": "8bbefb7e-d999-4958-87bc-4d90581a4176",
    "version_id": "6714f6b3-013c-4877-8edf-a98481ab2ed6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38279/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ba1e06dd-3258-453d-8f63-8a1bcf0b1578",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "23e1f9f694359ccca668149cb8154407a6644fdeb9772f2a76e1c04a46f86d9c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
