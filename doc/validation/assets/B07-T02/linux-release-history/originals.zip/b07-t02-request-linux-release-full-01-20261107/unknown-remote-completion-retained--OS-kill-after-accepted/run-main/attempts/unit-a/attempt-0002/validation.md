# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4a87f311d6f84e56c34fdee1ead4de9af14405e9edbc1fe6e430b35b29af41cf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e11921a88d8a2460a04327e48f1be153175b93027013a6b250de4d4a4a91ff1b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "04d631b0aa657d5ebc102bf9c92e003099c2228c47aebb88c5445fcd7773b6ef"
    },
    "request.json": {
      "byte_length": 2249,
      "sha256": "0a69816fddc3acee7af9371715e1c3fa25a5915297c4cb7704a552ce60c00cdd"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6a3acb55ad1ba7daa8ebc1677849e946db631768bec909b5645b926db33c47da"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8fd7cd16e819c1d14a90e6faee02617a657a1ee48f5109261627b68b702d0c03"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d13fc020-8704-4106-bc63-1a23d63d1e46",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "24ff8be4-7f20-40fc-a6a7-8588e84d69cc",
    "source_id": "87a5d714-8d20-481e-a08e-70bfe065290c",
    "version_id": "5e07d0c7-19da-4aa7-9a3e-826c029f7bbe"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38279/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "23cefba5-dc2d-4aea-b5de-7875f638f429",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6a3acb55ad1ba7daa8ebc1677849e946db631768bec909b5645b926db33c47da"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
