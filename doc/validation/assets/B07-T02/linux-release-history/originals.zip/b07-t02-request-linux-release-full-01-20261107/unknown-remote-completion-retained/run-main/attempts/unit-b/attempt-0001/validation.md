# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "acc51bf73ff021beb3573d5cec54beed17790ad3fa3c2129a148061d0fad3401"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5fd0ed86c55609b480e17e0da2409847ecfa9407624efc8c9fa5ba72b5166476"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6c6d5c9dc4f10c25ea0f690ee6611026953970c7c48ecf82a86ae836950f2f47"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "4481acea66475426e0621f7f4eb3bfc2c35eaf1fd65886b70d1577466d214b6a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e3111d1bda22c809e8d7d7cc4527205ea2daf110cbdbebe8905e1f1e09d83b4e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "08537932dd0647f72aebe5bd6f8c57809d1b769def5cadaaf0a9630a92cee293"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5044db55-c17b-4020-9a2b-ea61c19a30ed",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ef2ac4a-3861-47ac-b37e-e2357a5546d4",
    "source_id": "6b0272f3-134d-43b1-bf08-2c898285bb52",
    "version_id": "85559111-d342-4285-892d-bab8e92eda41"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38169/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "57840da1-1d53-44e6-9eb6-5060148a0e5f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e3111d1bda22c809e8d7d7cc4527205ea2daf110cbdbebe8905e1f1e09d83b4e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
