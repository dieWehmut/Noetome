# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1965f436b83301db993e2a162a5d8a2e395881b6822799c56cf4116113b4fbc3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5841495a9b9a18a866eb72e3b82bba2e823d666c0b15812384ba3ba9d3fd2379"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a84cfa888f9416acc9e725c5e985c185ed30b6291754834d6631ed13edc65308"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "8981aeee56656514e6e0fa287753d01c3bdf5b567cd54660c6e74dac7a131719"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "42b89c8fcf0a01748d80a2dcaa3bbae9dc4e02af1dd39b8a0dc609a3a05f56ed"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "39f8ba9ae721ea634263ec61f054334f7356148b36ce2cfde64a2dd942149f0d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3b6dec8b-fdfd-407c-bf61-f81f0dde1f4e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b0326419-67b8-460b-9379-54b2017e19ee",
    "source_id": "e75cc846-8f54-471b-ab46-724e60ef4e17",
    "version_id": "3a0351cc-49e3-426a-b8e4-3e1eec8a0518"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37027/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ab146cbb-498f-4adf-a64e-79efb4e1b720",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "42b89c8fcf0a01748d80a2dcaa3bbae9dc4e02af1dd39b8a0dc609a3a05f56ed"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
