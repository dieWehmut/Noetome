# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9aed23961a05b786162a25439c58a92d825bed0519cefd3cd5b94b5918c734d8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "df78615be0fd6996ed80d6e74777d6b386b959da15f2269e224ae2f5d0384365"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "93ccc5ce196369c4993a9a87d1e0fb9c00edade48c414cee924f8ab83875b372"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "1f6c1a71f23a5b56ce883f2824289f4d45ce7a7a7c86b693708f42c3ec784a73"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3e6736c577e7fa9dcf8f444eb9b1e0f3862d66006480e5aa977d7a9a41a71450"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9be31c4b17e6e808ed82418ad94262370a34c341dbf8c8fc2e00a7b75c9b8ee9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7a04e82c-1873-460d-beb0-ca5d758ff77b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fa7f9adf-c119-4661-b7f6-7bff8a572a6b",
    "source_id": "82a1e336-6599-49d9-94ab-81018a10710f",
    "version_id": "c62c25c8-9ee0-4aea-9480-8e3315304dc9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37027/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "90bb07d6-1fdc-42dd-be21-5d51f29a504d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3e6736c577e7fa9dcf8f444eb9b1e0f3862d66006480e5aa977d7a9a41a71450"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
