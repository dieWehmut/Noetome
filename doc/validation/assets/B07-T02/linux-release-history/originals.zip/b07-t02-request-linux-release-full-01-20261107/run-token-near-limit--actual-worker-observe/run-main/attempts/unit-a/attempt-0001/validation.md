# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b9840ff508d6ae115d9dc02fdc8686d244ba9766e56c6a67b973fe53b37fd46a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5f71eaaddcd0f9fe8b57aef32a7af48235e01eaff6504ed144d2e63ab89071e5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d397c0756bf5a511fecd3a2e3e24f2b1c7386868e227ce5c2c995744d5feab13"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "554894a21e847796bc634e0100e26d405726a18714be66b5d4062e6ddd345bb9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c42af74d615b9e3e00d891e80a4c6a0ec26b270234e203d0a2d69d64cc5528c5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3ff7524974787ea9142b92ad0d632d17dbb31f328b038b823f7b710af2752e0d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0b507380-48cc-48bc-bdd3-536dd679079a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3ba52270-034b-492a-9e7d-825adea1235e",
    "source_id": "40593d25-a722-4b2e-af04-a74a3e80ad00",
    "version_id": "3a5b808f-43b4-4f01-a99e-a2c1251335f7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37563/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "27d1dab6-121f-4234-90cc-4d602b76ff1c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c42af74d615b9e3e00d891e80a4c6a0ec26b270234e203d0a2d69d64cc5528c5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
