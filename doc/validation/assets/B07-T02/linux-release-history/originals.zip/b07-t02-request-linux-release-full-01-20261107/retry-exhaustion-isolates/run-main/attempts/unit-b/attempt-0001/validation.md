# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "24c60682ded412120fe3feb774305ec340814b3a7a5a4cf65a10b46702bf8fd5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3de6cf24b3abc01d7af0f89f4fb778c6a28c035918ccaa52dfec6553a85ca7ab"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e316bebe3556ee2817f56db68dd0f5b875cabe6b1b565d6c0199f3cd6ea8707f"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "8fac854de769fd3dd450b770d796abb8a2e6faa5258877b969de59c08a7ada8c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "06e3157aae0f548c1b57f132b09e5a4499d16f74496ab074f00154a3fde38b85"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0ca95b9bc503b620de32c7503c96bc3556879fdb708ae495d8fa04d7883be8fb"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "afa00707-1a4e-4f97-9f0a-64f617d774d2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8f5d71fb-ee14-4eb3-87d7-5da2c1bb6a2e",
    "source_id": "aeb4258b-5b77-4601-a7ce-e36d6e47ca06",
    "version_id": "14468a6f-e4b2-465c-aa9e-98279bd68e9f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37231/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0243b2d6-c6fd-4ca9-a44d-f997aba69ad2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "06e3157aae0f548c1b57f132b09e5a4499d16f74496ab074f00154a3fde38b85"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
