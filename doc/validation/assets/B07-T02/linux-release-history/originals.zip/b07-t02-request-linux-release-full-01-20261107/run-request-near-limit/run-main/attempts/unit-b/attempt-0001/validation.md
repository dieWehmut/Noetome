# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7cd9bcb1fc061f9a0357a3747a1e0ad364ad1f9fa6abb68b14f606b4b66ecca6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f6b41b5423c1c3bdd8ba9c8bb8e22d82a592bd5edafac7f03e045cce81085a4c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "93029a9b3c843624c7de00935a066e07898050854fdde4fa628c81dcd200f14a"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "660fb74c3110ca6c7495956c3f6dd882c629e9e5701c77bd0f5643202b893da5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "182a915032c8b7e88b589f410c59f87a9755e5d5b0390460eb63f2dc60d39cef"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "02c65642f590d18d2cdb3b026d0d4eb46ba004a8f74a4ed2aba3ae003abdf897"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8d45a785-2ba2-4b7c-aa52-2841b868ee48",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6486c92e-54c0-4915-ba6f-25d980ec9f02",
    "source_id": "5ce41187-7d69-47c3-9042-5ee8265c870b",
    "version_id": "c2fb0d73-26d7-4883-91a2-1b00d5ecf9b1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37267/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "54763aa1-bc1b-40dd-afaf-86f20448dd65",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "182a915032c8b7e88b589f410c59f87a9755e5d5b0390460eb63f2dc60d39cef"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
