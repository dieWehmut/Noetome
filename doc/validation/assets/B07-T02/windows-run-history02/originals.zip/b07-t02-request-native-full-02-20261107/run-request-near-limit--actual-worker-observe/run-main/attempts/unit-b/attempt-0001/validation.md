# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "36e018eb69fa3ba5c5d27efefb0573105961dd922f99f7f370477b15123a968e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "eb26910e54c58e0f9a2fd3731c26e9ca81c258cd06ec3243a01faa68212cd03e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1c77d6c1365ad8df35e721c517fc5ab41b38289ffb78a9ee77eab521a33bf09c"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "5dbdd702d63660e95c56e819f6b99f89e14297b83db00a16c822db05f01d84ca"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "644b52491ca5f9178107dffc9fc3ed8eaa1c2261cdc331ce5c371ac1a6949bfe"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "70e0877942d4598ea5f4164e19fa41cbada08470168fa46deb03c61534baac10"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c854b439-e25b-4845-8662-9cdc389c8eb7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "483cecb0-b24b-4321-8f7b-682b7a9bb3cd",
    "source_id": "71e8916e-cf54-4955-ad94-6afab8a1c19c",
    "version_id": "34ca25ab-b8e1-4ff4-a09b-03d4075a05af"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63955/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "40d37128-7dbc-43fd-9208-2e974b9657ac",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "644b52491ca5f9178107dffc9fc3ed8eaa1c2261cdc331ce5c371ac1a6949bfe"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
