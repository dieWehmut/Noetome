# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8d026ff243fa747e4672f2b9c58517ba3ed7c092b37f1d537bda591260910143"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b950186b752cd4caae4281ac954b0ea19277638b6d6bcc5f90cf4841ae70e966"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9c790dd0c4ba1845e284b1d2100c65801625fcdcdab93c7a15b698b6e5fb5e9a"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "b046fe1aee86614263ebfaba99820fe5778a5b499e563cf561b752d153291218"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f3e30efda077100cca0a5c90cb5a057c930f7f2bfba75137cd7c7a557ed0bd38"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d8b4b47e1f19e6c193084fe334197eea0b2a4c46d3711fc96b9c6d84f71d1a90"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "58c5e2e0-7d01-4259-bf0f-53dea564ae70",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d63eb446-7d3c-407d-9eba-81bbbbca3161",
    "source_id": "eff6d92c-76eb-4f80-b6c1-df040204ed50",
    "version_id": "2c93f688-77f2-441b-aa44-7f045f586c89"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52176/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ebca41f4-647b-41a9-9379-1aded5320f9a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f3e30efda077100cca0a5c90cb5a057c930f7f2bfba75137cd7c7a557ed0bd38"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
