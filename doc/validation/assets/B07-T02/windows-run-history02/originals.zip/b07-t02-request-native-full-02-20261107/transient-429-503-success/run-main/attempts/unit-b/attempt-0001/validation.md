# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3dae7ceb71d173518e9e8e2295a7705bce3e3d18f5ed95acd2c7b2366c3523b5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4a2d3020ac25e3e195b0ec1285605ac1663766ee01935ca7e4144f717d6f7226"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a6e2abee62913d3418b8e56731431d543eaf13802336d9e5555cc504fc8dc26d"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "6dee2ba6fbf1a0a6aa7c50caf188cac4dab4fa8c60408ebd91f097214fcbe0c6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fb1adf23dca2b9293f67aa4e4908595afc4eefef66756a403a3a6a8505fd214a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bc390e20cb79f57987bcda63d0049a2baed0b98ada30d4bf19258cab08848fbf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cc62ccbf-0c3e-4cbe-85ad-9cd18c9103ea",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8e2142fe-ca3f-4d0c-a718-d89252876d3e",
    "source_id": "46b858a1-4655-4be1-9728-88a89711137d",
    "version_id": "35c74abd-9acf-4447-9e29-a20d7c95b288"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58405/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "66f8f98c-b33b-43d2-8422-68525e767ca9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fb1adf23dca2b9293f67aa4e4908595afc4eefef66756a403a3a6a8505fd214a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
