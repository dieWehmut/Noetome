# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5b59fdf12d01ab50b0f82113f1f9336828a590c83ab36bfb2b4e06a265e9d35e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e5c0b9d0594a919afd7e208248f803a6e1a0986b4358c54ff756cdb10b71ac91"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "210582adb6db051589871ccae3c1938c3608021de02c965781557a3cdc9dec96"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "a6a85888738e747284fbcd63caa2324514152db9d1fda92d86641a8ad6018545"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "41539f51eeb0ccac2cf268c9c3e5a23e3db39d8c532e5cbf380737b577c8bd2b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4bc678e80117b887e4d69f9fa1683da9d2c08666c981fd7fb658378b94245f3b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e523c45c-731f-4274-8bb5-ac085cb5ce55",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "65bf41b9-75ce-4bd3-bced-c03a915a4a94",
    "source_id": "df2cbb25-1c97-4df9-8fe3-8980ad6e47b4",
    "version_id": "b68e124f-77d0-4721-9042-7c4c7f68b8a8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58405/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dc575848-01eb-4103-a235-b9804b1f681a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "41539f51eeb0ccac2cf268c9c3e5a23e3db39d8c532e5cbf380737b577c8bd2b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
