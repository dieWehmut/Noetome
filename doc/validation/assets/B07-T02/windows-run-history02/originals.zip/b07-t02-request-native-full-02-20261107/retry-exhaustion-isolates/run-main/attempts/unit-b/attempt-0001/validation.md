# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "135f2a002556b89e80b37d42fd78e9d57c521810789f906bf88a9e5b673cbfba"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "63796db1b2fedbdb9d0fec970f03b39d398fa593155d217f73e420ec669f78d8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5e4fd37c8f7f0f9c9ae1cd35f5c8bf5676d8e333c6bd793ec105be937725e1b1"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "fbc0389dd3489d3143788f090337765bf2abb9f6581922a4d83e0078b4521c1a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "afa1e8029fd903eebc7e0d9c84c8f10f71a5f423df0eb703e467bd0be3823009"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e8cb59858e80f6f536e7dcb3819b6b487d31dfe3d2e302419c90f1c5204ca728"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "62d2057c-b6f4-47e4-acef-49a5e0213a8a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bf957ae5-5233-4fa4-a243-bc050b007e65",
    "source_id": "d47cac65-3837-4c00-a787-b949c34f6d43",
    "version_id": "d696f657-67a9-4ca6-9faf-4eaafa578df8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58428/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1e770a43-d0ef-42b3-a56f-e74c0fd011e6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "afa1e8029fd903eebc7e0d9c84c8f10f71a5f423df0eb703e467bd0be3823009"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
