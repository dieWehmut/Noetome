# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fee31fc23f1933375b16670aac6da2a24fa323401e86c0bbdd343bd3b458cd79"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0e884be1f38584ee863782f8570e26bd0cf6a369c5d342ebf7831038c83f0097"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "d1060c1a867fb3a5b5878ccc6645b55bb28c647319fb369ecbcb09119b648830"
    },
    "response.bin": {
      "byte_length": 122,
      "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
    },
    "transport-receipt.json": {
      "byte_length": 502,
      "sha256": "9fcbecd3be2dbb2e7b76b3a97854dff6b63a2fc602514afa6708811e7cc78177"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ab070bca-6bee-46e8-9bcc-34b7674c62a3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4a9eba1b-f23a-4014-a76c-fda72c4d88b0",
    "source_id": "bcc700dd-be80-48c1-9536-9f21178811a1",
    "version_id": "96bc0df3-6756-486e-a312-188473251951"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58428/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1b2a6905-f590-4c3d-9149-83dacdb89753",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 122,
    "omission_reason": null,
    "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
