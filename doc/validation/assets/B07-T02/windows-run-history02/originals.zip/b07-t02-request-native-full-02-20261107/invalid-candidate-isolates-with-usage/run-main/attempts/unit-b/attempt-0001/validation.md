# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7a4129487d23e22f46a286fac0bb2ea511f7f3161a8d88c65df36440e74c7f39"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f18b02ef1fb749287e3eaa6f0347d9e17eaab63e39eb3b51854f042c48cda352"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "539ebc086864e3058f398f2da2bd40591cd205403f744aad95fcc551545d8cf5"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "0d44bd568bec8339444faf284c01f43766398e674592eeb72bb99626ac402210"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3fcd6b48b737da70343d56c80a2c53bcf5e97ea91fac246cce474c112148bebd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "998369147e211f9e8c39309b6ca629a1dc22994bc1b8b47fe3bed539821a312e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0d95241a-0a23-4426-a6d9-c897a6273f85",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "36a2ff72-31c2-47f0-8307-39ce485931c0",
    "source_id": "fb5f05eb-5d83-4a97-862b-5c2e09e91c91",
    "version_id": "0ed6060f-2390-4296-9dac-ef23573ee5ea"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58448/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d5ec703a-af61-46b8-9e9d-a87bd7a5693b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3fcd6b48b737da70343d56c80a2c53bcf5e97ea91fac246cce474c112148bebd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
