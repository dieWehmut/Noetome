# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d94238b9b4a4365543d533bfed8e3148191dde086bfd4cd5167a2be3a90671d8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3ffba4e6fe1f32f1a57a8769b68898c792b3809a09192173e3b14fa9f2384a5d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a0e88abe3ebb7210378b449faf4dbbf7ccc4937113e0efd190c45e9e5a783374"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "b262d06e5931133ae4a1126f82fd6503ea6d0e27a1515c95e80455a66c891595"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7732689b2421ce84cab78a0692ff8b5e348a9577f0d4c0555560da883602a5ff"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bc4c726c429bd3fc78db07825c7832da68e451465b2d81446a94dbd05849e363"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f9998cde-c59e-4566-90c3-d1f409922927",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9352d431-ad81-4cef-b222-7641b000506a",
    "source_id": "f6d62488-9c4c-4276-adbb-c401918f3ea8",
    "version_id": "c7f99c3c-8161-4195-b502-3220174852ec"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49323/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "560e1b29-6e5c-405d-bc32-c6c8a1a0e681",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7732689b2421ce84cab78a0692ff8b5e348a9577f0d4c0555560da883602a5ff"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
