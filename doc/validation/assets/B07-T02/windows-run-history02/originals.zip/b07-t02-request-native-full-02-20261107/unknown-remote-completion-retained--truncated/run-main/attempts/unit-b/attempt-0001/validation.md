# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6a1eb11b32b10fbbe0ee0f9ef4e0087a1d2b1b6ac91293986ec09c962795668d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9136efb88521debfcce352d41d41271b3e26eb289009100680e1fd9965a55c24"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "caff417a3e25915e11849f1380b858ba172d192b01b1d567f5565d842153b7e9"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "7e81d39302b93b370d8f7ed24c04a2904b77a7199b2530c77b6ff6a3c5e717b8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bb847ab1db51386db83e472faa472dfd8c6aedaa46873c7e20f53bda26b3c774"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "18a1310de0e80ebbb77723afb010cbb4723c61907b165b6155a6fd816ad81d65"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d19466bb-202b-4278-a579-6a7344c80282",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2743ddd6-b857-4947-a5ad-425f7c83f02b",
    "source_id": "f82b8961-79d2-4bdf-8f51-0212ffb54380",
    "version_id": "6d5e6746-3765-4165-9b0a-dd4d64100d42"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49323/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "03ca4f76-2916-45a6-90d9-fc8d89c3b277",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bb847ab1db51386db83e472faa472dfd8c6aedaa46873c7e20f53bda26b3c774"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
