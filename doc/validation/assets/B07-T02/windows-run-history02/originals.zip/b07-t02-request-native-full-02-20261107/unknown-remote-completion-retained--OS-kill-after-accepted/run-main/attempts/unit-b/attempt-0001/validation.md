# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5ba7cc60a164fcbe43a316623d20472ea7f04468ffa05391af1be01a58493ba1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "642a75e04602e90be64b9ce193b55818470c1f17a9ace2b8b0779b1c01d3ef45"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a7a65f957a43ac1f138470561d4dca5789797ca1d184633b194d33abc40b6fda"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "79fcdb55ec8fe65db64d34bef7e0766149062948ab93cb9521680c138222fcc3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3d04c57152eba7c6318f0d9f0a43e3d36c00d797fbc38a7ecfcba09d8c72cba8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "84405bbfa3c795da52aa25b4444052da8540016e68a4781763e5fc40723bea46"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4991589c-13d1-4426-a740-667df7793857",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "603b5e71-7d22-4598-88c7-33b0eefb1ee3",
    "source_id": "dfc7a12a-87b3-4304-be09-30579885ba0f",
    "version_id": "46a45b38-5439-46cc-8224-cf5633aaa9b7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49343/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "18e12647-8184-4da4-87f9-d3c2364639a7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3d04c57152eba7c6318f0d9f0a43e3d36c00d797fbc38a7ecfcba09d8c72cba8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
