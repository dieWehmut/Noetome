# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e5198174890e1929dfc7e2703635332a1569233157e5c45486366651eeb928fd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ee86b69c0143bf4fb05e0f69133fb9157bef97580828360dd8d7018bab9145da"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3609b585f2378cb4f57b1e11358bc44b739c7b9b9feb605052ac751bc28b8927"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "a95f404bc9fe454b10273696946d14f837293002f0c383176c242075830a3059"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7ac5fd7f22779521215f085c917848f6c0d6f6e89c0151e9759284b342663095"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ad389f8e26686533e27feb6b7542720cd6dec3319f9b90b291bd9787a258e514"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9e60f3c6-2076-4c7f-a3b0-6bb0ca9b1096",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "39d3ea01-25d3-40f7-be3c-4f70b2062a56",
    "source_id": "799e4075-2365-441d-a4fd-8234f2902545",
    "version_id": "ef3ee70d-3b82-4035-b858-07e3befda0b3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49269/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d1abb5dc-d380-4fa7-a204-6c605d020455",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7ac5fd7f22779521215f085c917848f6c0d6f6e89c0151e9759284b342663095"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
