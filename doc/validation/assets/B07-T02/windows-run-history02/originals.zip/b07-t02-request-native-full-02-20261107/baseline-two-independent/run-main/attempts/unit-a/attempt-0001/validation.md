# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1f5e511d6d220ec4e339f6c660f2b8a5bac9217acbd2491ccac7c0296da2525f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e084df7ae4a22e30d084e2c7e80f0161c67f0d24715b5190efbcea9c2de4fa65"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d18c6c85b8be40d64c084a7cc042724191e539a262c8cf34a10e550fb27e6942"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "b7997a889675f4d1936b83ec2d6716ccf78695f6b9eac4df84d71f637f2d00c5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "47a995ccb0bd3b082414b16fee560879d3870524811f72711fae61949ed4e37d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d6ea84b500f0eedc11ef47505cbdd9acd2078a402832618ae91c717aabf418db"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4582d225-da45-4447-93f8-a6d64978368a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9264233c-000c-42ff-aba8-5c5ebfe0048f",
    "source_id": "d0a88142-fc1a-4d6f-90d3-223f9d7b60c9",
    "version_id": "5f462558-4322-4fa0-88aa-2cf783b48096"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58395/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d7205dff-524b-45c1-a463-2857f2de9fd6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "47a995ccb0bd3b082414b16fee560879d3870524811f72711fae61949ed4e37d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
