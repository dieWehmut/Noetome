# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cc71c812f7ef0b29aeaa0e83eeca06a04b1a669dbce843fb3ac4e5bb2c7f240b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b61794351d2a031f81461867b6e7488b585bcc68a77f5748fdcdfcd4febceead"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "123ab1196b9fc8b96407596cf6e101756ceb8bf3837b4ccdeb6edfd23b102626"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "8c66fdbac29309e1651745877700a0528aa1cdf1f0d037d3bbd0c2420ed07fe1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7661bf470d50d1d0f17f4f0aa333eb768b4de5971fc72501a51d0001304ebece"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "31986b8d1264daedc220c4a9d958722d2335977d1ea40728161c79155938471f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5f6d03de-696c-458d-96f3-9b36b1d4f63b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "791c6aa0-5e96-480d-9215-4a369d8bf3ac",
    "source_id": "3b58e7f8-ae25-4c4a-905f-0f27e029e125",
    "version_id": "e37455e8-5e63-4514-974c-884329cabfc4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58395/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1d792049-9621-4c70-aaa5-22b24797beee",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7661bf470d50d1d0f17f4f0aa333eb768b4de5971fc72501a51d0001304ebece"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
