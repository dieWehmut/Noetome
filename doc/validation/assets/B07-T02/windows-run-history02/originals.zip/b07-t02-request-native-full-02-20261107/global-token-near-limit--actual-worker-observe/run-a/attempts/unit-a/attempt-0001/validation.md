# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fc52d8a9b91ea272583516867febce1b7bca369d430c3b106a942cfae640a745"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2fdcc40f158a0386bbe3ff321ef9a900ce8306261e002c3b50770bfdeacd6fd1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c935a6f7e934301080c9d2e81759b7fdb8ecac71325742b2a679205a79836149"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "fca2601fa189ca40b60434a11c2014742fb017a2aed42903dfa87ec3b793bbb0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8b0896a86189e764366ec97b2d8eb637acdca23e43a137330edc7f238d89a195"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c54658917a65ad527f6544709691b64e4e02168fd35f4bbe1dd1260f1b397285"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "daa8c409-a1bf-426d-acb3-c6903b5ee5a6",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7a9f5932-67d2-4a96-9171-c3e5437c34d5",
    "source_id": "952b1f5a-c757-4d2f-b5ce-cdaabc905288",
    "version_id": "99082409-d68a-452d-ac00-e98abb34295a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52188/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "042bee1c-c575-4454-a26a-bf15474aefdb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8b0896a86189e764366ec97b2d8eb637acdca23e43a137330edc7f238d89a195"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
