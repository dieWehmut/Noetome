# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d442e25def3ca2b4a9643e2a64e5c44f138334f5bddaf531bbf59e7d32bd9a68"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a84ff168e92ebbfe479d8c80d4b661e342b9da19b4f22d7404f2a8ca837ed85d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a310a50d1e1161c2ce41c744433c1042d09bc706012bdb25d7c5da7a000bc121"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "d22a9bfa1224e782d30a39870393fc8bda08b1b106467ef55314f0c8f25d61bd"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2ae3b86c48b2a8a348433e4392977b3aebf34360d9f5a3230cba89224a4a4492"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "93a46aebfc6d6e1e43eb6f88e8d3ebcff99b0e3c88df7dd66d371ac7755d0e5e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f6d3f7fa-5302-44fe-80c3-aebca4aa0ad7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a6ac6a5b-8441-45ae-807a-aceedec493fd",
    "source_id": "2c42509d-a1e4-416d-aa0c-c554d8f0b331",
    "version_id": "7435917f-c257-4770-91b8-8608996caf95"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63943/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0773d0f8-e6f2-4ab5-bb48-df136b8bda3f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2ae3b86c48b2a8a348433e4392977b3aebf34360d9f5a3230cba89224a4a4492"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
