# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ba0ffc1c67c3b560752ca9481750edd7e10fa10b427d7f249870e50fa3475384"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "125007d193a2209463c3f57ee67a1559d43a301f349e1d224facfc73d855eaf5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d76abc3ae05146147cf0b17964acdbefd28de8e75a85ea83de17ad9f3d13a2f8"
    },
    "request.json": {
      "byte_length": 2227,
      "sha256": "7c41f7b42e132fb36b862e461bbb3991079137c34d83ea05ab67f9c1062f7b23"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e325d095c224f51e7d145f245e568fa8e1fbc71d9c333bf5c1fa87d4241c5017"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5ba401b5d7226b82e44f96888a90644ccf834a6cceaccd790a83eeb36a024b8c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "359d13c3-87f9-4b5d-9e90-bc6e101bcbdd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9124068c-341e-4102-8165-f2c7a443ad1d",
    "source_id": "a2e3386b-9823-48e4-89fd-019c56c770dc",
    "version_id": "361dbca8-82ec-4d0f-89d6-de86c73d8cb9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52164/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a9369d12-739f-4dd6-94a1-24c1726757e8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e325d095c224f51e7d145f245e568fa8e1fbc71d9c333bf5c1fa87d4241c5017"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
