# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f8eea00335fb48279fbdf28337376b9ecd30dce0a9d922b2979afc44d44275dd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9c5f28ffd4acb90a91ef500c4aca90ad9e1217f9169732530d15d10d1402a9ce"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "34403739e006cf9f52cbaf16cf53e149be469be3bbaacf5175cd00af0061499b"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "85a27e895e722cb882e5fa98759f0372b19be819371e7529f12e50dad3fa19a4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6953935fea63f34e7acaff9104241a90d3d7edbb41799b7ada16e5229c0a57a4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4342a48aa3695f10e1f3195672cbe2164c5e5d7673f4ba317165c50e680459f6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "519cd807-0ba5-4a70-baca-d7f39bc0f04a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "da06946d-7aff-4fab-83fe-b1d7832b7489",
    "source_id": "f969e2f1-1a60-41a0-afed-013a21ae3921",
    "version_id": "074338f7-01ce-4cc0-bb5f-86dfada1f0f6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63967/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8580183f-8160-488e-8e5d-48b0ab682483",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6953935fea63f34e7acaff9104241a90d3d7edbb41799b7ada16e5229c0a57a4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
