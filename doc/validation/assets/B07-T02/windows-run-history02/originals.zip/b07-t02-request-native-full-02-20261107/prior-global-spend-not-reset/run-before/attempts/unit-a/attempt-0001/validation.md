# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7d4bf6d1c4d037d9ad90e5ea995c0f5639bfc799b590b5aaf269952d92a7182d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "41ce2a415100c05cbd139fb91a3060db388251c0d8aae07cdfe2f7cfbff128cf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "210cc4bb920626053500a924bd74331ed061ec1c2e550881493cbf589325a45a"
    },
    "request.json": {
      "byte_length": 2207,
      "sha256": "29e6e72fd0d159a894197fe77591646460b3b7fb900111db858676d6db406999"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "33b7a2253a18ed37e11896226eb99d98accab1f816ae42228e021040f48fada1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "94af0e2ed19c69ebdd7688be09a7f57b279942c0ef74d4c985f0f4e66f146890"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4749cb87-b073-4907-87b4-71f3c5b5deb3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6774c6ed-df20-47df-b23b-ed3f6f13b60f",
    "source_id": "4791024d-93e5-449a-8833-052d6a2dbe8d",
    "version_id": "71911000-a05a-435f-8d91-97c77fbb981c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49240/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d881f016-d22c-4971-bbf1-a641d0c66857",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "33b7a2253a18ed37e11896226eb99d98accab1f816ae42228e021040f48fada1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
