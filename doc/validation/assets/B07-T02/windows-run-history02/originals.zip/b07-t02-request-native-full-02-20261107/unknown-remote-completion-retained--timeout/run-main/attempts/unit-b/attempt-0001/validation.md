# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cd3493d3317c870a04f7e42c00c049699aec6e2cb283171cca8607fd0ed53c1a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4ab0f40c45b2cfd1078865e2b212a2b51aa630f849c2db1542f6792058ee22be"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ec5fa46c888edb5dc6b464ef075e9a46ce0975c286d10b411ffab0b1e25547c2"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "e5060991c9604ccadb736274888bcbf995d0b0ea903d44f633972c931173b1ab"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1941e42381d09d16968b06b5a949669e145c837ca6fc01b6dd74ea061a825ffd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f00f9fe43a66d76b07bbdc4dec7d9e435b501398db23e43947b6f9962bac9b13"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4bf15262-7611-40dc-b12e-8562df6900cd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3d8e7de5-3340-4156-a7ce-b361338e6785",
    "source_id": "5102cc52-190c-4d96-862b-c4c8248dbb63",
    "version_id": "a18ec730-f4c4-4c64-b09a-569c8c46f446"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49294/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5bfe72bc-7e8d-4f86-89fc-40cee396cdf0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1941e42381d09d16968b06b5a949669e145c837ca6fc01b6dd74ea061a825ffd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
