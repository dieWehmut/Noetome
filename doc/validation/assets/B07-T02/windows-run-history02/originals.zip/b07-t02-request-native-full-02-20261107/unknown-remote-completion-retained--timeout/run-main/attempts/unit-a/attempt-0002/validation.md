# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "19ee076ce3e3c9255f9631375a78d4a8c08e33c9b058ea7f8ba5b01fb0ceef56"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e7ef3063d003b5b11de9428de891fb33be617c5c10f25ef2a5bb771e4d944aea"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bee52cd5a49464523e9eadfcd81bcd8d706c6a5a7bae4dcf8ce70ed668486ec6"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "9853a65cb835dab900d7dbd0e01b44698f2da621a3dc2a4caa435625ae713f7a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d398feb515af7e8861f543bc1ec3fb524bcc781a16c5cc85bcab10075057c7be"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1abbeda62974e4a2cc318259f834eda833efbf804cc7e6c18b5a4ba060c1db1d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e3bc6d27-bdf1-4ae9-b4e0-4c3558517213",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7fefbfea-46da-463a-9647-3f117d8d4b9a",
    "source_id": "72e37d83-1f0a-4b93-b859-fd6e08c1fdba",
    "version_id": "e912d2be-6848-4c70-aa63-4ee4fb3c3da2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49294/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7ce72388-d988-4e7f-beab-b6f470aa4405",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d398feb515af7e8861f543bc1ec3fb524bcc781a16c5cc85bcab10075057c7be"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
