# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f769a8768830a385a753ef2ee6ddf768d7571668e886cc4715ae5db020020d75"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e31d6319b29acf4677e5a2a88c7fe61260a449d5fa05f351e76b8ef056591f12"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9d893d227d5a0bcd4935c18649326c89643f1e3657761ed69c0bf190aa267bc4"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "a5f3d3526c361f71876307762391054f19b1ab249a56efbd9cd5851afff80739"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3136f43aee5970785799deb977cffb8fc5479432efd45632dca18716c1a5fec8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f936555cb84f5b9a4bfe9d6f97ce54414c83eb9a6510a37fc886f3f82a46ce7b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "61dceae0-d804-44b1-a094-5ecac896e47e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c897a58b-c6ac-4a9c-af0d-7c9fd3fc4d5c",
    "source_id": "9cab81b7-84c4-4b7e-add8-98ea097d9603",
    "version_id": "176f46b5-0e8e-49c1-858c-e20e38ef15cc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:61948/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "28f55533-cc32-44b4-abe4-bf49b8036721",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3136f43aee5970785799deb977cffb8fc5479432efd45632dca18716c1a5fec8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
