# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9df0f23211e5e977a9d0356e6236e6da96e09ccf5fd1562e78f9c7c7d7aba772"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e808180f7a7ec907cf90103f39b3fb9bc1801845d3fedf9fcc9a3bef54419b84"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5899a66b8b58fb235cc0b17027704f639e15378052bce4ead900e732de16be34"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "eaa638944214d2f6204791b9fb07c8b9fc860a46bfb5d982bbabaf89ed22da8b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c70e4c7d46e0d122987eda62a946e673dc41b7fb87f91231cc833c0d0b94e808"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b93794b9982b0e0c15f617d5db7415f5eb8e8b465026b56204f7bf58566d67a5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d9a975ff-f6b7-4de4-8b7a-03d340028212",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "440dda9d-0bb6-4e9e-88ef-caebe82f4cd2",
    "source_id": "276abf50-dc38-4789-aa09-8585588d88ff",
    "version_id": "89aa4ac2-ffe5-4f01-867a-0096339b97e0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49316/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "62495c73-83e3-4fdf-8366-f9ffb3421239",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c70e4c7d46e0d122987eda62a946e673dc41b7fb87f91231cc833c0d0b94e808"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
