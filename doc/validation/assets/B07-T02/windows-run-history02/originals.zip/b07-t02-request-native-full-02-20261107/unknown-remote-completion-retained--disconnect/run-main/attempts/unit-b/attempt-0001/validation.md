# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a65dd4d1c8603f9a7d3db896289335fde648c4c60828a943bc5741dc6853c884"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "032de0d1bb8e81ea363ae6b91650a338d6f050c4d739ef4a79f4942ed2cc7bf3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "97a1c933579ad2496686cc8b11777fbc61d840870e07c03a0452739102d3ff28"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "3ac35636e40c0178bf60598191db4b1645ce78fc2715176e40fb03904caaf3b6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5bd7f8e05b2925d88ceb9ae2d2e3830057301e592a3c5a730f565d02fe2e43ca"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0c559054b83a34bafaaf42cd575ac718020b2da1e6c18b25f2303545a0890229"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a387d524-04ff-4b2a-af18-66fd81ff379c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d90cb88f-1e60-476c-90d3-7984f0337eca",
    "source_id": "e8e43d09-6a14-4a24-98fa-cbce232146f1",
    "version_id": "8dd5cba2-1ac7-410a-b294-d6eaed8bed91"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:49316/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "80a4a11b-8be6-426b-9f2e-fadcbb7e57a7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5bd7f8e05b2925d88ceb9ae2d2e3830057301e592a3c5a730f565d02fe2e43ca"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
