$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-native-05-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-native-05-20261107' --snapshot-sha256 '5959b43065853e2202cc17fe3a7402b8611752308a19312b6f88cd06cc5aa531' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 'c781fee80f45e6e964713f457bcffdedbbe777c93c208660d8c5b1a65561632f'
exit $LASTEXITCODE
