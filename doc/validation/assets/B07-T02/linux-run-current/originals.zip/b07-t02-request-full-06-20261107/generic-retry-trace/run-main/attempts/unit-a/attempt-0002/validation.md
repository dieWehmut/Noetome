# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "226d26c6ea49e40d76fb0d57da77d96c56d3ab1b939fdf4b5016f50b8bf8cb4b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4c82c7ee18c10352cb806d9ec0d4885e9ea49105e48fc49be95c2c4c77ee044f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bd5452228780818ae04f0edf6ed35e97f879c21a75f5c61536143ae792482e45"
    },
    "request.json": {
      "byte_length": 2196,
      "sha256": "515f6cf19c01bcaaf51fb54769812a8fdb6e36958b444f3c1e31923ea166d83f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4b9ded35f0b905e2d64649f5908ca5f2da795cc9cfadfdb1ac151f40b1975bd5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ee1b798354db26108c35f0262e6613c03ec9a45f59af3dbb82856e5d7a82cdac"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7bf647ae-8962-4c91-969e-850bc176f56a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fca97d83-6cdd-449d-a211-68c51751b28d",
    "source_id": "bb0b004d-f8ed-4d35-8e71-c6c6d590ee78",
    "version_id": "9b5d6704-0371-48a3-868b-b3706aecc5be"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36617/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "aa63ce74-4f79-49d7-87c8-e40d3a2828be",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4b9ded35f0b905e2d64649f5908ca5f2da795cc9cfadfdb1ac151f40b1975bd5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
