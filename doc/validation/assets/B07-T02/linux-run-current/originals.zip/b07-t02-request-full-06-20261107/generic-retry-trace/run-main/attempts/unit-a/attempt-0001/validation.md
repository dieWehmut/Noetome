# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "66aa17fd6d7c03ac6b1100458409d2d6a1b711a8950448e4947e7318ebb179eb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e2f91370596856137ea86b172cac0abf5100e9856962f6d8c25c1e1183ec1b97"
    },
    "request.json": {
      "byte_length": 2196,
      "sha256": "b082ec90b13c25a1f36dac207cfb3dddf75ffc56b41ac7d36dfcd19d6f92dc5f"
    },
    "response.bin": {
      "byte_length": 122,
      "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
    },
    "transport-receipt.json": {
      "byte_length": 502,
      "sha256": "9add2f2d82c2cabce815dd80974b6519b0bc88fa5bbeb5a6e547d31c9760c6e3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7bf647ae-8962-4c91-969e-850bc176f56a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fca97d83-6cdd-449d-a211-68c51751b28d",
    "source_id": "bb0b004d-f8ed-4d35-8e71-c6c6d590ee78",
    "version_id": "9b5d6704-0371-48a3-868b-b3706aecc5be"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36617/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f0f39967-9eaa-40ef-b75c-461bf22b3b34",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 122,
    "omission_reason": null,
    "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
