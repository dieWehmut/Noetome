# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "54e426e3eed32411ea3eb55bed3554a98bacb89c14adf5ec4fbfce448d110821"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "098f540bdf86e7f3d9759f5230120f368ecc93b405f960e33268bbde4d7b4ae8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7e65f34ec08b4a9586ba5681f6d5ca36dba255acc89e6e8d227f419d044db60f"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "dffaaa20436591e2917434c0cbec1bb878fb5f61d0ef556eb8c37692aa4989a4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d55aabe2f00e7c92c5b5aa1b6d5459aa52c66f1e59b2ff2f75d1ac38d5e595ac"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ba8c18c3f42f16739ee92b59b6be29b914a7111dd9ff418e2293ac6dc00c2602"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9ec229fe-08bc-454b-8d63-d93ddf8d7309",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5c4e3b4c-a527-4e44-9f38-e840b261aaae",
    "source_id": "1c770be8-44bd-429f-aefa-e0c59ca83774",
    "version_id": "8bac5b14-b301-41f1-89e1-da7053cb6816"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37073/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "67821637-e199-4223-8700-dc8a058f1a86",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d55aabe2f00e7c92c5b5aa1b6d5459aa52c66f1e59b2ff2f75d1ac38d5e595ac"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
