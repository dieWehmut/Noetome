# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "614f3b520c20e541f6a96cb40cb16551edd42c164542c9ea7385cc3d117bae99"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9a577a7a5eab864254eb5575c2348df2d81cb60c53b494dfbd28c58f59ba80f6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "986d14aa3e15c56659ea1250fa48b93189a1e87bae218ff0f62ebb0b01e4ae44"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "de483b649c4f4a98ce3b9a888092a9773b582538fbae343f7b41cd6cf48d42c9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c85272abbf511701345169e299491c3a39d9b5d3540378ef346aaaac3a39f1a9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1c1856e672b19ae7f19c18a10192fe7220a822eb3be57f161b49b4420a953204"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "45a23d91-e960-4419-8de4-93518da76935",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "83133514-51c5-4d1c-aba8-8d9ba39a3781",
    "source_id": "1bddf1cf-7cfc-4b36-b973-92c726dfa539",
    "version_id": "4dc5a223-3853-42ef-9ceb-159b2836c12d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37747/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b5beea43-7819-4c4a-aae5-a8bc9f98da44",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c85272abbf511701345169e299491c3a39d9b5d3540378ef346aaaac3a39f1a9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
