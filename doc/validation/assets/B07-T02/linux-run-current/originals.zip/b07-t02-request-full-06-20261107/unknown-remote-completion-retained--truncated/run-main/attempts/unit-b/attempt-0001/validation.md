# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7845e7011177be3f1d451ee54f9065fdc7bc48c923f5591743c3085d0da1e8de"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e1b2a2d6167447c3daeff841c17b515df7d88965d9ad5862a0c79ab16b92e7eb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fb007d250f96a042e27380b5dabc594c8ec5962dd446e21f6b24f316d7217445"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "dace588ff2740c9426b9c52858ecb9cb6a12ce007ebfb94560906a6dd3a6b8d5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b85c432763cb15fa0da9253a2d35d35cd564b7ce5ee8139f9fd895e70667660c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7e8badaed7e52fb45a302939f43ac38111dcd7bcb67eef85a660cf003b1a8503"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fbf99b3b-a11b-4738-b77b-5b5001523dbc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f7afc5b3-a465-4a7d-a272-32575b8f1453",
    "source_id": "6b2cb92e-c179-4b8a-86d4-1370d9d4e987",
    "version_id": "38a69473-8301-4144-9333-3d91d5921d04"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37747/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "00c488de-ba51-4d38-a325-d69fa039bbed",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b85c432763cb15fa0da9253a2d35d35cd564b7ce5ee8139f9fd895e70667660c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
