# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "aacde9a0f7fc53c18bd5ca57a576c7acc0821ebd2fcc074b0f2daed47cba8843"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f771e0691ea62900be94178c3ba93ca7706cbbc51b78a4e493c9e0ba04c0be3c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4e407d5cc57cd63e746452591f41731c9f7a048a1a1d0bad41239f9c82e335ed"
    },
    "request.json": {
      "byte_length": 2206,
      "sha256": "707f34620654fec70f73dba2266da8911ee829ca90f246901d5aa0b311645486"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "95f8b903d0dce55d87b33fd7f36d4ba10dbe7bab5cbb7e8ae076d771b3480c8d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1660c4616c1074d6218abb79528d0ffcea9c469b5db93454e2d235af0b6e090c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "29a3d775-6964-437b-9377-f7d2cd1e5f98",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4256f859-3618-4322-abb1-5dd926786969",
    "source_id": "fb00fb29-a0ca-4ac1-b482-062cffb96dff",
    "version_id": "cff22e19-e1bf-411d-98b4-9772f534da0e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36945/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "24a99455-73f6-4ceb-a72a-753eff6c99db",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "95f8b903d0dce55d87b33fd7f36d4ba10dbe7bab5cbb7e8ae076d771b3480c8d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
