# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0177598e2e8e096cd4be1bd6ce628fb1f61ec95d36774275f6351e6c688d43e9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f0189260c95343cc6a5f8cce2cfcc10b2a84ae0170c53a69616440f4beecd9c4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5c923366546caac32bd73ea3e3c894ef7797f6d9bd4bc355b5fdfc5b816f285a"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "3875616c03be38d639e674cc9b050c3445b3715d92ddee1087e137a3b52bcf45"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5b3aee5e4a53490adf36e25934cfb0672d779d1f58abc5452544f5e229c705bf"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "616f2509975e0b0e6b722981b909ea78a12d7012d9ff687dbd9870f323f4160a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7ed7589a-2363-497c-bacd-13b5fcb9a103",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ac476c17-35bb-4017-9182-cc3c8369b232",
    "source_id": "22b1dc58-d9b7-47c1-9a44-ea6307aa9e60",
    "version_id": "086245b9-f3a8-4d8a-bdc0-5998369bfa2f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cafe5905-0c9f-427e-a2e5-ce3fabf9bf71",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5b3aee5e4a53490adf36e25934cfb0672d779d1f58abc5452544f5e229c705bf"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
