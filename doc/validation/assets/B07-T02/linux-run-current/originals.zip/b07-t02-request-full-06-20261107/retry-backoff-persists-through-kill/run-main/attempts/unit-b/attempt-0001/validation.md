# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "76051034ce2bc6161efd460418547673eed0c831a5cf490b9597ba96b02f0c3a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c0a1982e9e7ada97b1b8071b2b44b6eb4877409d2e7e2ce822ea0e9119afb7e5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2fc8dffbe838726f3b1e78e2610f8997e8c5e9cdac3b3ef41d4e8e6c7ca07e7d"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "d0bba2563f661ebd12c85a95665d11420a0f6169dcb43c1a5cc12d75ce7f33e4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "668de7cf2301cc850b089590609a1799329ec8b86b1246aebacf76a3466b85d6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a5f044cdeb5cc5a8a0b5278643fee907a7a5807b5448dbd2df68180391a49dc3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "67d9ded8-3636-4ce9-a01c-a588c8ae6ada",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8d8c5198-f5c2-40a8-81f2-e49d6127dbc1",
    "source_id": "e5fec3b9-2da5-463b-ba1c-fe9aaa27eae6",
    "version_id": "fe2269ad-f66c-4eb0-8eae-b866da02c224"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "efb9e45f-b205-4b7d-91b2-5ffc08522354",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "668de7cf2301cc850b089590609a1799329ec8b86b1246aebacf76a3466b85d6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
