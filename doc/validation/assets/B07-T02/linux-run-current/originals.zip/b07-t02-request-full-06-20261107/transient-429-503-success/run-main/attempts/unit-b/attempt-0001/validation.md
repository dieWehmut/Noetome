# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "10d4e8fb9f27dedbdd9078b25fb480db99cc0cb1dd8b8306e2ce8a0fd836590b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "222a032e028889229bde8737aa876d1016695eaf6c080227cb8dd1174a48c55d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cf0c4d421201e60a1cc1cc515493e0d5c3174fb50f6127da752e5ed57fa8e369"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "15de90295472188fed9854c32c42eea4205d92141ba6dc87761be4cabb8d9308"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c9eba88487c362a366370e295f069c2cc0feca379de71f4be5a7879ef40b65c1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d851b683fc15079a86979f5144e91f7f187b640db5bab77bb5f99e1aef49d3d0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c9a74272-6ecc-4e6c-9b06-50831b9f3407",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "477d22f7-4abc-4c2d-8870-fb84b7fc144c",
    "source_id": "703be801-fb98-4617-88dc-b5f45539916b",
    "version_id": "a3862288-0d2a-4582-b674-cbc8351b1f48"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37597/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "becd039d-1ad2-454d-b58f-2cf3e8b11077",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c9eba88487c362a366370e295f069c2cc0feca379de71f4be5a7879ef40b65c1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
