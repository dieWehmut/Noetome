# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：503；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a0a67c9a544e7371f7225a1420661cadbba58701aff09dad5afba11433b82998"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9516b7c50e06de44c991909a55338d858b7105160ca28ae846f78e4314bc1cd4"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "19cdcdaf2a3a40a1ed394a1fc4587df63c2b2dff6378c22395de2c5f0df30965"
    },
    "response.bin": {
      "byte_length": 131,
      "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
    },
    "transport-receipt.json": {
      "byte_length": 498,
      "sha256": "10f7a2bd7b30219dc2e2437c53c87653bcfb40b277bae426b4e98cd588828ec4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d4c430c0-0095-4ef2-96a4-d94f251a1511",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "97ccfe04-2398-4fda-92b6-aea442b16b66",
    "source_id": "c57313e0-977b-4a70-a332-49cbaafcccf8",
    "version_id": "2eb70b70-33c6-4001-bc84-a1321b905049"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37597/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_SERVER",
      "message": "EXTRACT_API_HTTP_SERVER：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 503,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7179cccf-cedf-474c-80b1-ab108ba2b000",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 131,
    "omission_reason": null,
    "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
