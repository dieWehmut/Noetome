# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7f3da70b33990aae919d67995991ca7becadcaed92b698c266bfe1b0f7bd5772"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f9e0006277df0b0e960e7d95499cdcc51b8f2bc9ec73b99de45233e7ab9e3b6e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c7bd486155f3a7a390d354a8bcbe8954ca1570f008596b993c51feac7ac6256e"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "0e752caa30c8806ace4670be843ac7f37a493c7ca9ac10c1e1d12108401e7899"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c1a95ba0836d9be434e7da8fb8fbff1465ce25744c20366adfa9ead874543ec5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f51ac11251cdb3c4e02d4342f0be9c374be2415e3fc5131d9b8960d2ee0db21a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d4c430c0-0095-4ef2-96a4-d94f251a1511",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "97ccfe04-2398-4fda-92b6-aea442b16b66",
    "source_id": "c57313e0-977b-4a70-a332-49cbaafcccf8",
    "version_id": "2eb70b70-33c6-4001-bc84-a1321b905049"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37597/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e3655ca7-09f6-4537-99d5-0633d8c00dc6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c1a95ba0836d9be434e7da8fb8fbff1465ce25744c20366adfa9ead874543ec5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
