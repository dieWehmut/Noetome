# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5d382b3ba74309b8d2bfb488cde442b1d33c39b768581e9f1f91a31cb07e9bb4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2f067e7bf72267b9bbe9a5fdb8c35728ad5a2dfd90fd8771535050f8f24d2b34"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c22dcb1d1d61a0f1534f5ad1dc3c929690be1f27df73138c6cbeff2dcb27d4a8"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "5f01f8e233a3ef900a545355811adfcad36fd74ba6c5b7956762d767340b12c1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "601ce675c9f062d62c8cd2bc079c298777f4e471df6844d6696d279abf71f5cc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f6cd38dbfd26bee5678c53147fc03c943fb5a26945e09d276442d2d090d2c13c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6d7d9e91-7194-4348-a5d3-23f61c895e8a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "efaafd91-b2d9-4188-9d2e-99c4b37f86a2",
    "source_id": "fd1159be-ce99-4af1-b3af-583ef0c14abd",
    "version_id": "3dd6f6f0-1665-4da8-8781-4fdfca25e33d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36727/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4ae4fa9d-0808-40bb-ba90-65fe843fe19d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "601ce675c9f062d62c8cd2bc079c298777f4e471df6844d6696d279abf71f5cc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
