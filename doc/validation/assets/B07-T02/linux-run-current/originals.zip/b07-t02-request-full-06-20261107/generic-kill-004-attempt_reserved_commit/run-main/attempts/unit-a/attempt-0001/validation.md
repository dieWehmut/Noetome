# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3d66071142632f39ed0cf7ec05004c55a9d07c9ca82791b3df15449a82d85582"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ac2dde0e604335b86a11f1f3d3bdfc211ad5105d372dded51fc7b580a2c4c7a1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c019116b6aa835684796d9b0b85386700d615128165b47857b7821d6c9bf48fe"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "cb5d08ec0c039fab1381cf53cf42d74878f91a76efebfa5b897fe059c5dba841"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "63d129f3f59d088b79f1fcc1bb06aa6adb854f353ab75e362f8144450980bf14"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "802a6e7f6239b45cc94fe01e062d53580d2236abf95958734dfe6a812fd0816e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8349c6c7-6331-464b-8a16-7a19df107386",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c979f7da-56cd-42ff-a7d8-766b630bdfa0",
    "source_id": "e2403fb2-63bd-4d59-979d-ae54f2e3d795",
    "version_id": "0f688f87-6cb1-43f7-b408-f91c5d9ba39a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36455/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d433a89d-3613-42ce-bf4a-7d155096d6fa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "63d129f3f59d088b79f1fcc1bb06aa6adb854f353ab75e362f8144450980bf14"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
