# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e8f3f329c9204b0ebaaa3c940b59d553eb910941739fdb5a8e2dc0b4bbfd933b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ac96f42475d364ea5f678fc5c5936e024659094242a6b3558df0e306fe737af8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "755e7de6a747e0365c96a84fe12824e4e8db3a077892ed239d55e653024d323f"
    },
    "request.json": {
      "byte_length": 2200,
      "sha256": "ea579907ce11c2191ed1f2d3553a8b09899ce421fb93875145a898cd4fdabcbe"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2ce0de64425939269f056a2d8b1622f69887b89c4df16729fded0ca9a33dbb9f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "559edf25afe9c2edfb57e1548c58b7e096e3eaa4e6c1f22d0833c55e26b05064"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "868c8739-d62a-4908-a1e2-e267811e21b4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "be2149bf-e1a4-43c0-8bff-0519c5bf1c05",
    "source_id": "3bdc2a1e-8bf8-4cef-bcd5-d837862c986d",
    "version_id": "044ed143-be8e-4dd7-b310-d39d1c9c9b97"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37081/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f29bcc48-d70b-43dc-8313-2a3f2cc7015a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2ce0de64425939269f056a2d8b1622f69887b89c4df16729fded0ca9a33dbb9f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
