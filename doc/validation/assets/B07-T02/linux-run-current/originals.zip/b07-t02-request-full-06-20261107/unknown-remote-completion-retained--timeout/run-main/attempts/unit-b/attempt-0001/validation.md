# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b8becd77094b1386db8774983d17ff99dd97cc61aa80189a094e136a21f0859b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a74db15945a7907ee63b10ef84de1941fe93ec465a32d6704df502e12b18c74f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a1b6927f85d5239a755abdb46e91d6e97d661c7607bb0da0b3970ff76b3c4baf"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "23b837f122d66c1960b8b389a4e2b3ac33db6dec3217beb6673508a2b78a8588"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8801c1e93f3ef8d2f2b0dd12fb44c56cd88b92149dc904d77ee863d262912193"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8c9156b2b489079f398218ee68f996636a8b0428e40005f7af1a8d1bc15b5192"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5bcb55b1-5a38-4891-a4e5-9f91ee84f894",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7f5e0a5f-6337-499f-a610-12327abb88e4",
    "source_id": "71a3182c-194b-45c6-878d-87b60d8c56fd",
    "version_id": "30e2b43f-64bb-4095-9e77-24e2c92b0cb4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37605/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "46133b5c-c00d-489d-9992-66858796df3f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8801c1e93f3ef8d2f2b0dd12fb44c56cd88b92149dc904d77ee863d262912193"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
