# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "48715c7827524741851cde75a96ec749c24ebe1add2af2bc20cfb0d09002b050"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b89acdac28c94a3b12f8cee597102a331f3ac007191748ce0268f047209069e1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4ad4d7357241835caaec542d4f2c6951b956544c1b198548b038f49ee6f0c4a5"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "081bef9a295ee451ba95addeebbd46291f3dc907594ed39448bf4a2b4e5dc192"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "00032b063dad6e4a04b64dd8d74922a876042d3353256951e9ec9f1410ec1557"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c6928d4ae38b9d4f3fe37f96f417a75807203abbf7e34df1c4b1f554d1021b06"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2e754c40-9c9a-44df-8a33-59284dc8a44d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "789f1aa8-4d3d-45c3-be30-8d5716ab3dcd",
    "source_id": "d06e109c-30cc-46ce-9f86-3ce8300a4344",
    "version_id": "fc3077d1-c6ef-41a7-a147-41af3b59050d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37605/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d47ac1fe-ec78-441e-a938-8625223a57b1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "00032b063dad6e4a04b64dd8d74922a876042d3353256951e9ec9f1410ec1557"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
