# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8d50e7cf468fb811a3ab91751ea811d5caaf42464d4294388d8aa370ca4ad852"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "638ba6b89472cdbc30b4f644464b56692671b881c2b52ef50fbc2e7ee01adcc3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9a446744fe663d2a45c7e7f17b6a7d06cc4e58b14f0bd0d253221f40152103fa"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "1e7e561bdfb7c9cf3e7841c3372fa0c8397b0b05c2c6470318bbe8db506061b2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "429daf95242b8c1b9c1dd0a6a3b2ed4ee8edf1a315713749915b2c9f2c83f253"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7f1ad343998bdd76adff5cb2f6127d9c2d81ce176abf6a742baa8c2464f06a16"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8aa50a32-3215-4ebe-b08f-9d2d846d7459",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "74f16b22-4720-47d7-adb8-29cb0cfa804e",
    "source_id": "abb0531e-0847-49aa-bb3f-da38b80f434d",
    "version_id": "f09bbf79-41ed-4675-a273-cd2fcfd5cdd8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37607/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ff297197-02f3-4ce2-8733-4cc89f62734d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "429daf95242b8c1b9c1dd0a6a3b2ed4ee8edf1a315713749915b2c9f2c83f253"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
