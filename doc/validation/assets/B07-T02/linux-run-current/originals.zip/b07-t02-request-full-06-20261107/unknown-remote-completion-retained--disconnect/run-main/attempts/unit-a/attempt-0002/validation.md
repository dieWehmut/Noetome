# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a19aa314f94af157a07263344ae02a048e37ec0f0fa595867a0a12d02b4d9363"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9301bfded0ad8e529468efc461245fa0bb1f8fe04b475841938b6ba2d6903eb6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "06d7276c2613d1bbaffc330eb499b70abd4e03803687ea2a0fe2d368267baaca"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "ad4ef8816af26d5c65cef6606772d3af9e7ddffab72280d995d32e05b78e4519"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8bcfe9ee2a63d26053d1c3e0a1fd791e8447435a79d4baa890422338547228c8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7943d8cd50b57921755aaf0259ee6bed3dd93b65485fc9651221ec19c4d49382"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8436da6a-ace4-4694-b77a-3eb3e44d7f9c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9e7da022-fd68-46a1-9887-534438683cdb",
    "source_id": "7320efd0-f2c3-4268-9f2d-d24e209056a0",
    "version_id": "baf5153c-0a9f-40ef-8874-7a8c579520b7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37607/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4cc66287-538a-4690-bddc-30b8a9c02806",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8bcfe9ee2a63d26053d1c3e0a1fd791e8447435a79d4baa890422338547228c8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
