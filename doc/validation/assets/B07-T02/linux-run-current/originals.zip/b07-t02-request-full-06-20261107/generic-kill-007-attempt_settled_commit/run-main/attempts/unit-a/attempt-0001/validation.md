# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "524a9e778d4c15bbeaf7fd2ba9f3a156e5406109557b2c78389ed676e892be48"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6d819e24948198e69764a2387c98b359afc8634681137a5c4b102cff0abc98d3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d80dcb6f4623784a211a0c4b3100e69448913e9f448954f77da3524593e9cf0c"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "3e06889ceeff8ee520db3d3f26e97739827bfee5f11c4167905354418b4c1e56"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f0af1a39f3edc386e2284a1a12df5b25ef99c766f956eaf92a9e0f7349866682"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "83f7620e204995336824f4adc24e327dab8d21bfcd639b37a0556f0a2a927a08"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a7814f1a-5837-4dab-9bb0-f836ed0bfc0a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "15b4b808-f6b9-4448-a350-cb4f18b28b57",
    "source_id": "5635a824-cd60-463e-ac8c-22f6989881f7",
    "version_id": "48938fd2-8185-45c4-8fc6-afdb5025daad"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37413/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2cf79e0b-ff6e-45ab-b382-b48a1a84a337",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f0af1a39f3edc386e2284a1a12df5b25ef99c766f956eaf92a9e0f7349866682"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
