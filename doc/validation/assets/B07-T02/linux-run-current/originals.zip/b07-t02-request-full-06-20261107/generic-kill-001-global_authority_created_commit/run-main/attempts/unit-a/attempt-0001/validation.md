# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c116f1829bf0aaea5987730ee10c108ea3066129527669c71ee27b3b3288618c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7408c47c5de4de018fcb139c12018b0f0ae708adab9ed530b826f4bf851ae522"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "54d04d1691db187cc89f7771e3f940a4d3c04bc820a8d6c34770ff3c7be32ee4"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "1c245352dda7374b91b65869ec4ba76be5eb9fc0e282d53c85314152a22795df"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "dab9dfe1c91278e0242bd4fde8da091a7193d4adf5731d27d3be03a75cfdf854"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "424073ea1b719c5e8654ff6536d89c8db85d56db324cc74b5271aa5712606537"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0c2d2d4d-0637-4f96-9ec6-e48b7bab160a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c1eab52b-55d0-41bf-9107-d42a0b54b498",
    "source_id": "4f5e0543-02d9-4411-bf2f-299aa3fe5360",
    "version_id": "9e9cd18d-ae48-4b92-be93-f0d2c22007a8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37611/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f542db42-909c-438e-a415-6de4556faeab",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "dab9dfe1c91278e0242bd4fde8da091a7193d4adf5731d27d3be03a75cfdf854"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
