# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f4dec8c55ed5f36a7f140f3f0beb65d784f596dc5093689869dbb89153cb60a5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "192bed4ea02c5c928060fd0dde72cc44c79d896ce30c498b25a61378f59365fc"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0e53f7261bd78e76bb270aab2c0559b9dd9293d6617f9e9901e4f6ee366cd76c"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "729e48cbc61fc0098cddced96ca3950f3e96ff981515ba438f883f0793f31c81"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b4edc554801d0f7cd39b015e81adba4fb02c5bc553973845af9138a0a658ff93"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0d2a724cff895d2dd1c16b1a2136efedf3ddaced0d0512ba319f86aadd879562"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8a6435ac-2e25-4928-b578-f572f17284e9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a78deef1-544e-4c90-be9f-28cf76a2c1fc",
    "source_id": "e5fe1a51-d115-4069-9c53-c10cf2473d26",
    "version_id": "e0855f79-174b-4237-b354-7c5469cf797a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36749/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "91a7d245-d73d-46d6-8c8f-6aa75821a898",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b4edc554801d0f7cd39b015e81adba4fb02c5bc553973845af9138a0a658ff93"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
