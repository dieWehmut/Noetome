# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "47642c667c40984a49da350980167b40a59779b6869de1fee7ae85ca1a39675f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "39861616107452576d3190be7cddba3ea4e0386d8f4bbd13fe81bb4bd3ec5f75"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8f5964290150519eafe6cf67be93d8961536f9572d049e13cb1d4d0329407d9d"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "2bc8cb92b560fd7b8da09305b50dbaeac1409d6c70c3a1dbb5ca982ca10aec7a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b3a06c41c27dc56520b7f7a1d88fc70b1e2c4ffcca61f21a532ce7d284c78f67"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f76763389e38f51034de44f397d96c281e93e7249212b55927c02a2cf8923671"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "790da8f3-8a43-4f80-b021-dddf04f277f1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a1998fbf-4918-4ce3-b706-8fe1cfc86ea8",
    "source_id": "83318233-3f19-498b-8704-c09c4e43bfc8",
    "version_id": "0533ac6d-d46d-447b-8a6a-524fd1a45172"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37699/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "976de2e9-5f1c-4ee9-8dce-3d9ee6cb7631",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b3a06c41c27dc56520b7f7a1d88fc70b1e2c4ffcca61f21a532ce7d284c78f67"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
