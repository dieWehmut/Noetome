# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dc8428a57a7fa4f9dd48f7ca604b4c28372ff56f4674f9f674bded1eb95c5253"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b13c326c209419abe42325acde81be68c01e88eda4289b15a6ac37df7697387a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0e61b753412cdaad814c45b6b6654ef2c092d37e453397ec6865c359258543de"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "4d57706f9ae1258c2f4ce8622f6b3ceb467781d4e896a55e1674f7b9d92e48f4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0c90cc5a55087c814910997abff16a8bb29648703013b5ce62b7acbe73caf026"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9e58b1557cfb8ab9a4830ea0aba28bef19e59aaba37c1b8dea20f63ff76feade"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9906b2fd-812a-4cd8-b62c-70a6c222b4cc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a66bee3a-b9df-4663-9e09-c1bf201e1eec",
    "source_id": "8ac351a7-3732-480c-8aec-5d4588f7c40c",
    "version_id": "8a6a4ee9-7fa4-4aa5-b2ee-5330e4c6ca03"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38351/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e0837789-f0f6-4423-bca2-5e210e5b95e1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0c90cc5a55087c814910997abff16a8bb29648703013b5ce62b7acbe73caf026"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
