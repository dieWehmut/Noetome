# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4cd444c51b2fa2941686dda69a0c529bbdb009ae3893faaa09c738bac9d097a8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1b24cff9741a8573468dee7646c5e57dbdd9eeb5010c1f2bfa01c17a98cfbbd4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "242729bd707a0f7fdf2d0993a4d81a9ab51b03ccbf1dd27d8b7d41e17999db4a"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "2b15b14a859366bdeeea3c62b55b6cd9959449b87a934850f1502154057f9462"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e1e22d1c34fc817f2a4162f299e017d6e33a938f21a465fe35f6c31af05c2723"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f63adb626751c953d3b6f01b936cc82f4c1a2f72c842e7653160d5a0b4f4e642"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f15d5035-121f-43bc-a995-a7a44142fb14",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5ea89fff-47e3-4abc-8084-fd9e4f1067aa",
    "source_id": "fbbc16a9-46cf-4460-8a33-51b07ad83dc7",
    "version_id": "1ae65ba0-6d9b-4b81-be78-dec82ccf51eb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37689/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "754cd7f8-c0c1-42f5-a083-ad2242717efc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e1e22d1c34fc817f2a4162f299e017d6e33a938f21a465fe35f6c31af05c2723"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
