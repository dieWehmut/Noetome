# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d95aef4b0b9e7b01c9500f4cb466a0af70be2c6e2fc85e53d87f3a6b43606a80"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f1102063f14bc9a3da70b6f953355c420dd680435fe90139c945892d28adfd59"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7abd11c40d9cc23b03c3f1ed23e6c2c6362024c8d359caaa1a949f366a682fe5"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "111d1867d19317e8e02d4b4a12053e772bc5f8ab6e855f9636f698025f29a1af"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f4121185b4bf1c9dce574550c08411f5657863cc9aa027440869b20a8ebd9012"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bd2b162c8265c923597001003e8d0781660213af9850d499776f62ab690ac51d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a5f68c43-6479-4109-9606-c934408b1d5b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6aabb3c5-abd6-4d3d-b4db-b3aec8fab66c",
    "source_id": "688a1cfc-5df9-4cbf-8279-13447ac45f64",
    "version_id": "ddab98f6-96f6-484a-8a66-ad7abe7fe6bd"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38139/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "164fca0b-4ff8-480d-9c64-48e6130e16d6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f4121185b4bf1c9dce574550c08411f5657863cc9aa027440869b20a8ebd9012"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
