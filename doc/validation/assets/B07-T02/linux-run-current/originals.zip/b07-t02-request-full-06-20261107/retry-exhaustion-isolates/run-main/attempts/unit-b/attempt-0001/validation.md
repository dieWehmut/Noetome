# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "081c6b5730f16b3d199af83eeb86df918bdddda6ea270fa451ecc71029debe87"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "56d701af86d5f9fd98adfa38dbb6d0ce2e8868a25102153c1922a987fa89bf71"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ae6e453ff1dd157c38865eb4f561600e965a63a956c372ad2e251419c562374c"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "c228a10d306e8b54b2ffd7ca6517bd6330461e13fed5175d0a72ecc74b7cdbbb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "418105d03c03d398c3c86ca0cccc95eeb248b3a028e0ac617cc99fe0d432e07d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "02225a00fd02f7187a7e09a8a65b0849b9b87100db2c67bc3ca7868a81bc227e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0dd39fef-bc07-4035-9ccd-bf0ddf890cf7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "17726177-9b56-4318-90fd-8f85daad7a59",
    "source_id": "002f1576-6009-4af1-89df-acca24cf9892",
    "version_id": "6633f749-5c18-4111-a46f-31d98faa3217"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37259/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b276d1f6-481b-4d2c-9a8d-76514b3584c0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "418105d03c03d398c3c86ca0cccc95eeb248b3a028e0ac617cc99fe0d432e07d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
