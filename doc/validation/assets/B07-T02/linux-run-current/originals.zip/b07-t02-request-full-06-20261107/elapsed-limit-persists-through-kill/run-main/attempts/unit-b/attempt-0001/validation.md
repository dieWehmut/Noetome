# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c68e195551baec50022213b446f5ac8d84f3061c8cbfdf7b636c54d1f884c3d3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "268f177121cb983ce58d85c0e89d5bcd0121ab8bea5cd2c219eaa134f2332bc6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9b1fad06dfad2e9a4a0d692516273d9b71c23ec729033fd2c621b07b2a51f3b5"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "094b20db61b1423fa09bf24783a87008bff98a56b18f88c9a9e4fc3f77d462c7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f9ca21253194104217dea4e3cfad6b2c0ecb0de48e0d03c8b5a4f41488c16f52"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2db6828bfb603ec20c9091f84c7d333ce08d6facb2ef89eccda2d3a29ba4f76e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "80ed2494-f2cc-4722-8f43-6669709c0a99",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ee341ddf-9b0b-4f96-af49-e415b1a5ff26",
    "source_id": "7a68a719-2e4c-4e9f-8da4-0b13d36cc1ce",
    "version_id": "f2afafa3-9db5-45c6-8619-47b86698ff68"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38305/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "562aec43-b105-455d-9daf-71c5fba5494f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f9ca21253194104217dea4e3cfad6b2c0ecb0de48e0d03c8b5a4f41488c16f52"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
