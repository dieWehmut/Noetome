# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "33d58032419108e5e77901ee14a9004c11b0c110a6eeab2ff3b2230beb90236a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b7501af6cb1a85ac8dd0419dbef352b05897d5651a80cc23b330aabccbff9bb3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "79d9fe43afe8312f0fbbb7d8189135b34ee1cad9c468ad50b600b04dd44d8484"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "99649afb8af7bd4903511380b8fcbcae3e581d8d74673f09b96b964087ffad37"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e4931ed1750f45a2b4b5093741ee31e64ccdc60058844ea9590af84a40974bb5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d206f6850952fb3535b3ed2d430f64705efa3b6038ef5fb65baec56baabd1991"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "98eeecc5-1b0c-4e1d-a637-46a942d91b21",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1e2cda95-6ef0-421c-a0b1-25b9380a8955",
    "source_id": "898341b9-9dae-46f1-a564-e9cef93e5583",
    "version_id": "363f74e6-1422-46c9-9a0d-23163bf0a5ed"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37321/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6597d92e-63d6-4360-9695-b8a8ee2b6e65",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e4931ed1750f45a2b4b5093741ee31e64ccdc60058844ea9590af84a40974bb5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
