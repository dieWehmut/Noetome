# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "310b36483a8cc1543acc56074b6a5026d0f4bf9428eff3bd15b19b7793de085b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c885fde3650f6ab663afdc0c0e92fd4cad7b489fabc4bad2ce1d9f0fb27a8e6b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "910616c635db97583728bb0173105908d864a6c83d81e1a7e18160093853ac60"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "db788e86c71a3e1bf44b2944279b57786b5bba58887b725be9e82357d5e59a63"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d694d821a0880f938030f946eea169c5b69bfebd4d9a3a42f18c7c85c1b967f1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c0e2c3098213b04f0f99413c200ed3f95ae8ee6295f4519fc16cca4c54322735"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "708bb65b-a0fc-4349-abad-f911c6a80ffe",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7e9dd0bd-b2e7-4950-a4db-151ff05b1f9a",
    "source_id": "c66bb8da-02cc-426e-b642-c1e42a962f46",
    "version_id": "e320a5d0-f832-44b4-9001-d73f79354ebc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36485/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "86533ba9-2e08-4da7-aef4-f5b8d0d8c90f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d694d821a0880f938030f946eea169c5b69bfebd4d9a3a42f18c7c85c1b967f1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
