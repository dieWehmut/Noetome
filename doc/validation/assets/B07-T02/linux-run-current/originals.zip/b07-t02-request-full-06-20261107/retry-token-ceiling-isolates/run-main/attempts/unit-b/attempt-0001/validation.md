# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e603cb846a3f04efa15cb3cbe3e71f1052d03bed55a9ebfa0776f9716b353618"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9dce29bf67531ee58b49d7ef9c068cb260813ed4afe447bace970ea1f4ff01c9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bf92504a842d0ca8944b65678f6cd2db1eb02862e46312b2ac1602f39278f5b2"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "3a8eb5e0132162fd0a277bfd5c58939ddfeac077e2fee0ebe2e5672968bf6a71"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "663604f7c859cdd127a45140811cd36303cd3687b18c7377b358913807c13400"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "753658a9697d3080287988ea37885751a143b73e31a2215b9c0e555abbae67e5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f1d0745a-b82f-420c-8bf2-a0c77a06593b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e90d4e0c-42db-4244-b13a-b58ef3135583",
    "source_id": "dac36772-f291-4f75-ada0-aa91b4f2a8cb",
    "version_id": "3fca2473-0cdc-4757-b9c0-11856df91c74"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37647/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5e86205f-535d-48a4-bff8-0c681b777063",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "663604f7c859cdd127a45140811cd36303cd3687b18c7377b358913807c13400"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
