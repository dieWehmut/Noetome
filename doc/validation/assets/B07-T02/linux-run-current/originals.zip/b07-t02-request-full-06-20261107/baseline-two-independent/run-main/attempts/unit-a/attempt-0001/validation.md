# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "acc8a6a078b47d555ee6346262b55516c3b61bb7697cc4bbf1c9289ee51fd773"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "146f15b9ff5cfec02d22e6bdac5b48bdccf958c37e98f128ecd282835770e433"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "61c71b052373146f014be8e1856135751ad62a9f176211f50ba2915e3f43b822"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "1f815540ce3acc0ca88db0cd7c69d10a846c965f06efaeb1fe2199680613f7c3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "412e0cf281a05bd395361b3c477aab166cf0bba569fb864338f19a9f09a38abe"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "687a98961f7e07c862152a3a57593578c544199b84caae8ab7f423e6969ab747"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e8b3a1b7-e9cf-463a-8172-d8e6b97874ad",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4f91acb7-6247-466d-ae65-eb236beebfa9",
    "source_id": "0df8c0cd-738e-4543-af9e-5895cb6f33e6",
    "version_id": "e2404357-0982-4dc7-8b6b-71a3d9bde6e8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37357/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ea7b2320-9d76-497f-b403-ccefbd288949",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "412e0cf281a05bd395361b3c477aab166cf0bba569fb864338f19a9f09a38abe"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
