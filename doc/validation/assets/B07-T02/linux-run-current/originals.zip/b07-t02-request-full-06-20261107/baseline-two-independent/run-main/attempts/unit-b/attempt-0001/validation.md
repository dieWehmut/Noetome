# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2909ba2e8750c50dc3b2db067cf9991c7ca36e4516a4f2752fadd196471b23a9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d030d8cb139fd42c76de8423a6124fbbf6087c9fe228f68d1fa72b35167e2b7a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "872c85007e5663e2d90ffe94bf8f56d186c84c949d08f5f0e639786c5beaed5f"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "585f6b7fa095336a5eb40162383b89f704fa34f02fa40cb67065634d8057f019"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1afeb59393582a8f409ebca9fe304dcd33ecc188a1f5d4f4a8acc5c24b3a3f7e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "63f00feda4fdfa9e727d96bfcd8595abfa14871d9a13c92d1f67ce11977bbbc2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cc4507f9-e3a0-4b05-9322-66770e1d2622",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "99de78a6-caf8-4f3b-a1ac-31014a142bd6",
    "source_id": "73fe5768-b72a-478b-802a-609eaa25f239",
    "version_id": "60377616-8e03-4c0b-8e38-280db60b75a0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37357/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a6e1a9c0-32e4-44b4-ac8f-6be146cf4a7e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1afeb59393582a8f409ebca9fe304dcd33ecc188a1f5d4f4a8acc5c24b3a3f7e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
