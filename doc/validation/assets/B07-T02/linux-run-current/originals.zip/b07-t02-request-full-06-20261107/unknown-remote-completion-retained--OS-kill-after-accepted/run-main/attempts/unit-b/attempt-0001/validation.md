# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c04fcddfbe1bca6c0bace10ebcc4d73a820918362989d20d1989e7e203480947"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6a0098bf18e88ba29275c81d8166694a79073e8aaa9a9a93604ee130ab0669ba"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "80f6197711045cf7ab8c5e9a35ca9e098c7e0f291fbc91a33094f2e93d3b326d"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "58b2b7c89533243e9856d2e58f1168ccd3ec1e5c7515ae1476a9a49485b58569"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7a4c18aa2ac68f2f9dc165c1b8a79add48e1db1c4a4d5f09d7dad8734edf2d79"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d0a0ba2007e17524f1389f27ad584edeada4256f24935568a2fae176885afa30"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "599ea186-c428-4c2c-ac1d-37461c0d81ce",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c7106f50-3f9b-46e2-8c09-916ed882a319",
    "source_id": "6fe6c933-dfaa-4212-becb-0ffaca955d28",
    "version_id": "ff5e139c-ac57-49a9-a53a-4262536205db"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37685/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7a5a8ce5-ad7f-4493-83eb-a36350b4b363",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7a4c18aa2ac68f2f9dc165c1b8a79add48e1db1c4a4d5f09d7dad8734edf2d79"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
