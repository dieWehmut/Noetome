# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6ad39e64e7c5207f9160e716270f2835d6c349ac695273dbd3c8ac6b52435539"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a8bcff2d9cfc7779f137d7c2204fcbd478ae41eabbc9f0c55d3d799a2989b733"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fe19672ee96f970102b98a67fe9a11e79f0624f649e872bb415cae2a30b7a4a7"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "09f30e8edc31254224e4cfe9f196e8a02af436fee8dd0da0cce34771b3a7f114"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0ba948ffb97e180ca710caa0adb20c193e17995cb4ba6948c5c9f9f828d3187d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7e4d5d67918151e96d22efd82da46c3585dbda62ec1dacdc666f64bc5519f81a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "97fbac4e-e679-402d-826d-ab59ac8a0524",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "eb00fe82-b1be-454d-955c-ba7b366e1502",
    "source_id": "4f45733b-d81d-434a-bbcb-889d19fe8e7d",
    "version_id": "f094039f-3031-4b13-99ba-fa54756298f8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37685/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a55b01a0-152f-463a-8a58-c8a2e20612a9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0ba948ffb97e180ca710caa0adb20c193e17995cb4ba6948c5c9f9f828d3187d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
