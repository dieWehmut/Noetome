# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "47e3cb8bc21c8e9e1ddbffd9a676639f4d76fce542bcdfdd1e7b87d52e5c362c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b9a2c1b882238b9d9210780ea5ffc2ed3ef29b9dad3b8d8bb5c6f409c8451d9a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "961db26da030aa1beb697eab71586d693f3d48a0a3a9df80908a7fb5990d6b35"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "63e99d2cea054f68b0069a299af6c9848ff1dc918edd4ea21a6bac099b3e4e05"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "12abec2dd84f6acca732775dabf67263ff66d53e19a7c1db2153e8a98a988524"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "655f7d777dd0d918939cd8dba01c97877258089d5f97d0720deb3a4df13004d6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5a42e4ce-c291-4ad3-b0e6-89585fc76000",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f4af57f6-f402-4209-8232-b123b34173db",
    "source_id": "301b8b68-5a36-4efa-aa7a-da96a17a88fb",
    "version_id": "f43a6e30-b020-4a8c-96f5-ac7b32cd0ada"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38151/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6d9890bc-b71f-4709-857e-bed1c5ff33aa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "12abec2dd84f6acca732775dabf67263ff66d53e19a7c1db2153e8a98a988524"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
