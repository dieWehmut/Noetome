# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2853bccecebaa89fdc9c20dafd0bcdf1030758fc49dcb1ad923b7a3e58ea1f16"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2e939a80676d99d16e5b5e6d7a62442b18a65d538b44ecfb9afe538d533d8e9c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "203d272485b15fb3a9703857e31099ba60d80ed0aaa344818b0c877042f9ef30"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "4cdd7f5fc4db97602a35c677528d8854fa946f17808d6e6e3e5a459e5b37fb56"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9ac38a61ffdf261af9de680c4822ee8261c2aec0af678d16beb6e11c0b495e78"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fc995f439b4567796df568a3929d337ea2a3ddde735a19d3b91bd2f160cb4a57"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ccc0e7c8-5d76-4b22-a8aa-9bc8e362a283",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b94b666d-b18c-499c-b6a2-b08b29fae714",
    "source_id": "22fec61c-ca7d-420e-a908-747a55ce9380",
    "version_id": "90b4bef1-39d1-44f8-ba96-75525563911b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38167/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2972ded3-b975-4948-a1c8-314be75eaacc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9ac38a61ffdf261af9de680c4822ee8261c2aec0af678d16beb6e11c0b495e78"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
