# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cd159922521b38d7298d1e8fd41e58410187b6f80fc20096a8eff7a417714024"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cb6479b39d2c14ae9d555300ec4cf21c871b5f23bb2179d2fa16541728fca613"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "80afe51aaac6f5e5196374347247407d0226aeae0632663305cede3e658b287b"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "6e5524f5dd3d8f2e8ef32b3cfa2107956a978e38cd605bd1aa2ea193a91fcbc0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "768dcc697d324c31121b5bebc1ac5d52fb91e72c0d8fb201ebba27c9256a1017"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b7f0a12385b07cecac3918ab9a37e2263d2cea50a295af74c93224198ce14daf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "df587986-4fc4-497c-b8d9-56ab7644b7cf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7ab67a48-be8c-4a0f-a4f1-3bcfb4f1c405",
    "source_id": "5369c559-f298-4669-9988-69baeacc1d1b",
    "version_id": "7d4d7c28-58cf-469b-a910-87b87c015f07"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38167/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0cf788af-ec1b-44bb-a2a2-64d620ca147d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "768dcc697d324c31121b5bebc1ac5d52fb91e72c0d8fb201ebba27c9256a1017"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
