# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c3c675ff2ba5784b9e3074cf528ba05958eb84c4323e6c7c483b36ae4445ebe3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a82bf8608b4048d56f86bcef08cd307348c150856635d7cbe7b828f3f488176d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4ff369da9806f66b22ecedf82f5688f47d75999b0718f1fbd1f8d02d05cd2334"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "d189dbb904d7adc3783b6586d7dc5670ac4a9ae4ade5ce0134a39737930ee2fc"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "afcbd92a692eeb8619437872efc70d2ee28afeb8ece6148fdc74bf2f114eae62"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4941e6fe79e528145b513a78305ad185aefb20aea458f059902c36210bd1644c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "16b0437e-ae03-4b43-89de-1e68257366bb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d5f9f13c-238c-4385-8fbf-de270268fde7",
    "source_id": "cc29603e-3944-4649-81a1-0c8ff012ff34",
    "version_id": "43f775ea-964a-4dab-8a9b-fc987e3f0a77"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37497/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "26748092-fc47-42c4-b613-a7103b9335b4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "afcbd92a692eeb8619437872efc70d2ee28afeb8ece6148fdc74bf2f114eae62"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
