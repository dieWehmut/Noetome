# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c0a55d62db8ec17ee9508bf58d6645dd6d4dcb6ff123ac7d225585718da6070e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "38e91cafb80fd4b5dc945b72b8a99cafc1db4f86fd727aa3c5b1b9eea3937b94"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "31a8012b9a2e015f054febf4ea451277bb547a891f3c7f481e3253c6aa7b91eb"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "333d73d08622a199ab6f2ea6e1532f88f063e63b7cf39d66116a961fe08f4d78"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4e1f2a36db580633408a126598d46feb9d17c792c722102a6f7a0eabab962fa2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9d59c0601a3b185f4fd29fcd2b2ea59132f45f975ef8df686d77d11b019651ff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "407de305-af3e-43cc-896f-a7124d44facc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d32e5742-d10f-400a-b520-569d272474c7",
    "source_id": "5b9704b9-24b8-4696-8527-56626f7ecc95",
    "version_id": "8beac815-0768-46ef-9643-e449f18ab57d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38461/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "061c098e-2427-439a-8848-0aa4be51ec5c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4e1f2a36db580633408a126598d46feb9d17c792c722102a6f7a0eabab962fa2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
