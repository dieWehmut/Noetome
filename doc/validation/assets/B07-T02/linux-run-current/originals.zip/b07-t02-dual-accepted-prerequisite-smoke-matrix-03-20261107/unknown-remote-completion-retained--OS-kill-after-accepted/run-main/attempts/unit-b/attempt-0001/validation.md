# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2838d32d3ef26781bf1be76f9607d470f49435c5bc5384abed72e5f2215e4b8f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "85c800485b030bd2b15ec851dd135173f8fa5c1bca28635f4acc20f4ffd3c207"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "33d7a7c4c6c07bf7cba92d49d219c81da0dffa6d6f2c987efa6cd3f91d479069"
    },
    "request.json": {
      "byte_length": 2262,
      "sha256": "a1ce24c54253e951e6cea8fddc320df30aec54a796ae4e17fe24701ac5185ba1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0c0d1a3157bd98dc2cec294ac0a333daaa8840af47fb2567eb628a1533a2b82d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b8d646adb0c6b0dda794252f20a62e77041233a154823ff0b0f5c1dc7d9ceaf8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fa5c9f25-f4ad-4027-ab00-354ca6541382",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9e1a14e0-0321-4acd-a3e8-584fa4afc4d5",
    "source_id": "71e3d3d4-c712-4d72-aa7c-520c176e73d5",
    "version_id": "b0a446c4-7480-4ac6-97c5-deb87a587495"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36855/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a012e799-1364-48a3-9e0c-f88b2945d096",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0c0d1a3157bd98dc2cec294ac0a333daaa8840af47fb2567eb628a1533a2b82d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
