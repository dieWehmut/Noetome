# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "272ed5826f49cbbe36b24f089049ee09a51122be8ae67e59f179fe49f93d1a0c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "182004e1853c217a8def348e24a86bc934d512cc799ea25c4fa5339277415d5a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dc564a4dfd59579027c82957db8c4cf7c0bd519d09b2af13da4b91a77e739725"
    },
    "request.json": {
      "byte_length": 2262,
      "sha256": "27fddcbfc6e7be5c32cfd5607d1a708aa83b71173412038298b1d350cfd185f3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a39f44afc72723d991c339e1fe4b721d87da2b8a112587ea58087035d407eb03"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "47f8e79a7a22c3944712deb27d7186db0368db2c5ff4492624a18fa390835e47"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6c19a43e-252e-4334-ab8f-c09833b272ce",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "36023c67-4835-458a-b8a0-46c3c5daf04b",
    "source_id": "eb611792-1171-4e89-b667-7d1ab4a9c6bb",
    "version_id": "a4e53937-5dd3-48d1-8bbc-22b93a76e3f9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36855/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6fe8d090-5771-4dde-9c2b-0bdac1eef973",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a39f44afc72723d991c339e1fe4b721d87da2b8a112587ea58087035d407eb03"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
