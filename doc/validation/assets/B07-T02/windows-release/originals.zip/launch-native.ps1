$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-04-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-04-20261107' --snapshot-sha256 '820e531021ba97d5c9db2a9838765ba8bd4abad0e967a043be3eca8ce18ceced' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 'e869c1b822b39c20bf2ce1edbf3a1ea2115c9192ee3f050122a74c6c787e8040' --executor-sha256 '286bee55f67026ee5c206202b0ec274ba9a36422f079cc1a780260a40323d043'
exit $LASTEXITCODE
