# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d343eb7791c5491fbfc64462205506dbcc0d34b30f3be42afebf40abcc6e6273"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2d78ddf720028172b4090f2d7ff302104b8c70a8982ca2b33bf210a63915d7e7"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "e415d04ea167a27772a504ef84919f4eaeafa01d05101f73f14d51815299e668"
    },
    "transport-receipt.json": {
      "byte_length": 466,
      "sha256": "cd6aa2ad70baf52f8c2331ebb5c5c62a0f81a55cbae9835f940c77ab93ba5f84"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c07b0069-b925-47a4-a9be-ddf1e98c5d8d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "62300ef7-a76b-4032-9c18-b71129330fdc",
    "source_id": "52531e47-eda5-404e-8788-d077baddd356",
    "version_id": "53f8b47b-5712-4f9c-acef-e3eabb1f09a1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "49c20d85-bce3-489b-bc67-757edcd9ffad",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
