# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c8075e9dd12fd97a74ea1d7fc07b2db34d405e7e6d06d7e4993acb17568c0a31"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "63be3f707389bf782a85a1836ceb5af442c1446e9bfd8951ec5869836a181d75"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c7dc226fa777fb2fd9eaa94ece122b5b9608d769d089002b0a4160bdaaba7e8c"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "e3cbea05a48a60d519ec296520f85291b90d7574ef3649343ccbca0e3cfc5a91"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bfeadf21d0586bad2be7fb7946e87fca7623f4bf2527cc689267ce3657af8370"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c64e9c54b8bb0079c61405260c7fa8dbb346f9266fc6c69787a42941c84c0b3c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1866f3a6-974c-48b3-80de-780b4cb617e7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "836efae3-61da-4662-9991-7e3a3e9a2c51",
    "source_id": "0a671c73-74cf-4339-af2c-08d2f9d9ba16",
    "version_id": "3967d97d-33e6-455c-85ba-27e86fdc1d17"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d2091871-0fae-43e6-8232-d883fb18ef14",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bfeadf21d0586bad2be7fb7946e87fca7623f4bf2527cc689267ce3657af8370"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
