# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9d62c3015b4fd90727b87e4e8dc13d2b1001be40ecc157b7d8dd5b2c47938702"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "297e23a2b4db4603ca411e873f9abda73ff6b0f8799bb81ad4e318fca8a2bf05"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "3351944ec493160fe895abe960445aa2ddf2a11aa5c577d65367e47597e9559f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8fbfc3c8ec50d502227d3260fb922ce49642364b8b00c34b52756188cbc8b7db"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "be4e8671e34a78c4d50757a58e537de909842ca590782f3df6047ab0d1710ebd"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c07b0069-b925-47a4-a9be-ddf1e98c5d8d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "62300ef7-a76b-4032-9c18-b71129330fdc",
    "source_id": "52531e47-eda5-404e-8788-d077baddd356",
    "version_id": "53f8b47b-5712-4f9c-acef-e3eabb1f09a1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8e7fe6d6-0979-40a2-a55f-86facd091b25",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8fbfc3c8ec50d502227d3260fb922ce49642364b8b00c34b52756188cbc8b7db"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
