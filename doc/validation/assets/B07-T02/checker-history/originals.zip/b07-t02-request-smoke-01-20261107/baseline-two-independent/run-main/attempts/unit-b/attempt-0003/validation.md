# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "20758afde18290c90f495fb26bdfdab9ff592fe345109e7e3ea860700b0e71cb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "921116d4e99b62409248610ee37a634d1926c5194e6affea381ddd214b0f5673"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "e6e22ea683023b60f76bf18fa1c0e26aa1b9295cf0e6e278f5f323c49b26f1a3"
    },
    "transport-receipt.json": {
      "byte_length": 466,
      "sha256": "c1cc92a883f66c77c53ea337ed7d0567819c73d3e3c3a96a8bacc33595873101"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c07b0069-b925-47a4-a9be-ddf1e98c5d8d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "62300ef7-a76b-4032-9c18-b71129330fdc",
    "source_id": "52531e47-eda5-404e-8788-d077baddd356",
    "version_id": "53f8b47b-5712-4f9c-acef-e3eabb1f09a1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "271cbbb9-d405-4799-93b7-997b08c9be6a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
