# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c82ebaf4925afcec2cc811689ccd88365d6cf3cca1fc7ce1b83ae91348e8baf0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7b6b6999bc3cf6d48e40216f5b55089cd6bbe9612850ced7bd0bf451e16b42ed"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d823a5c5e5764f0e766aa033ded1f8941aecb51ab1abbb3403b9cfe00d67a40c"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "d15978bb1325476fe4667fd4e8bf53c58892359e711a0cef7db1aa1fa7f57b8d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "090d6dfe1ba8467b42c896453e12e9f4095dfdd72ea1a47618ca8115305102f8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c0cea92381fc3f88f7b333226bca04a79299ec1aee4d4ff92f56fe503661e128"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1a88bb16-9570-4b26-ad2a-35689095f1b9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cf3d7827-bf58-46ac-9c5c-7e27c19166cb",
    "source_id": "8464d131-bbb8-4bf9-a340-06d0b49c224c",
    "version_id": "9d3169d0-5ea7-4887-97db-ec70ed05cf02"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37347/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "02d554d2-7553-4d4e-ac22-edeeaf363af6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "090d6dfe1ba8467b42c896453e12e9f4095dfdd72ea1a47618ca8115305102f8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
