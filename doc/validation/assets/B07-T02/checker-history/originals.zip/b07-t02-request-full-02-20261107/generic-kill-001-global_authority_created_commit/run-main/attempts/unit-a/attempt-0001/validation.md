# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ae8da7409bcdd0bd63752ba51c6a96a099478f825ec4df31b7c23bfee672f8aa"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d56bcf33171cf7ce2a401cd417f485ce2d0d290a35f5e4ea751104dc570236f8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "723e12dd22ee4c16218989b490b574b7c7fda658734874a05b18e0531f3f7034"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "ca0e9d51dd642d3ecbefa601c4d34b49f6fb520172e105a81156e0c9c340dc35"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "947d094dce6e4932089392ce3a81d6432a07c104beea3a029d3414fa891acb73"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6f06edf246e614e158dee267925fa87e5a636104550330e358e4288fa21b3e09"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0a8a4645-0f8c-49f2-ad90-3fa6e3997722",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b4b9091b-8ff2-470f-b44d-6e5d48866e8f",
    "source_id": "f86b22c3-24bc-4dfa-b659-ac6fcde1c7fc",
    "version_id": "2558f65e-9396-4ca6-8da0-229b6e1590f2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36491/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ef3950ec-7930-4a42-8dcf-46cec3b34b9c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "947d094dce6e4932089392ce3a81d6432a07c104beea3a029d3414fa891acb73"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
