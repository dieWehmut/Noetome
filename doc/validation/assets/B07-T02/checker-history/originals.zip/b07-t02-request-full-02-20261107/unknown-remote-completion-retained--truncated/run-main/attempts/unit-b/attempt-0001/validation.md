# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "49ed58b040b653683e4eda9c2139a8eea94945b42433a187e828f9e127306bf7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0df33ea03877350ceacf654dddf2c1c9f2f17cfa4f15bb916dfb381438933b3d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f347710edbb17de5586cb9e890f2596f33cef4b57bee44d8a6223c5208441db6"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "b3713c91d74fcf326551dde11063f64a9f966bfc1ce40b2189d42167850cc32b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "08b5028263ea3e8688a1bec9f8c60b541a49cda7a3a995b9226a6f3e3f9c5da3"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "243b0dc47ec71e58f60aebc350093e559851b230e37cb77f5106aa3b22a375b6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d364e080-433c-414b-960f-e24cd385347f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9789ef03-a1d6-4c08-9e1e-105141c25947",
    "source_id": "54b83392-904f-4d74-8e80-8b235d9c2162",
    "version_id": "2d92d8cf-64b1-4e51-b253-322d895fad01"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37831/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c4d8cf2e-ff66-44c8-9dd5-30c0b5c47759",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "08b5028263ea3e8688a1bec9f8c60b541a49cda7a3a995b9226a6f3e3f9c5da3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
