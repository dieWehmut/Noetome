# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "27eec67867b791139cb94387234c9c1f44fdaedf332bd112eeb690a1beee4f0f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6cd55e35688590058b3899f07f7140d7a7fc01f19693e7205e6b3db040c81715"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f8a5588928c0061f03fc00e88641578cc804061e4b54cc7e650590dbd0d80916"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "6c11dffbd0a64a673d7f44d11a960883d03e36d80456c7f9414e92c565efd544"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "defb62370510e0c8d67b8286fc8bc029ba1f38eedf5698d1f24d742e378953bc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5ba3364183a02fa3ca4882208c02471540b3e9422d562aa852e1e46f91a2aa22"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "67a8222b-d7df-4ebe-b175-59b73c4cff83",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "65276560-1659-4f10-bd1d-23f9b3fa22be",
    "source_id": "aadea5f3-91bd-4896-8627-5a4c8d636772",
    "version_id": "cc212a3f-c6a2-4902-aff1-a3e34a5b2a7d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37831/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dedda1e6-a36e-4a5a-b98a-d69fa7b14a2d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "defb62370510e0c8d67b8286fc8bc029ba1f38eedf5698d1f24d742e378953bc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
