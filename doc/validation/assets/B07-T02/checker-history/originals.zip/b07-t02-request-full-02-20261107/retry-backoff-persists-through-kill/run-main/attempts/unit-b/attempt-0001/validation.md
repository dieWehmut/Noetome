# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8f889f11c8e5a1c1d8f42a0bf51f06ea146210544ae430adbbec4da551ff56c9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "846cdc4a5ecda9ff947f7247eb88f008c6b93d3c64ebc6095f2ee99f4d50ade3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e39ffad47ac3dd1972834cdb57001feb61f48d89a5788a93dc6404fc6ce7d5bf"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "7be2b671fe56a9c1ac9bc5b59dcad8c7267a10937ad8e16a46e04d5dba911125"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0ca2ce5baeb1ddea53090da56b2e83140f90b7d0bfc198cdc37f081f22d1e80b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8cec2e6a9bc9e07c41a750fec3d4a65467be656c5b120e1e7ba81384e0e1d7db"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a70003ca-448d-480a-8251-2677e5c34871",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ca5490ac-ec2c-43c2-8f19-a8f1fb4d00fc",
    "source_id": "5bfd61a6-0bda-4676-8950-38d31fb6ecd6",
    "version_id": "3a31278b-857a-4abc-9f50-73d378206896"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36449/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "039c3484-1c3b-476d-bb89-faa99c04fa8c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0ca2ce5baeb1ddea53090da56b2e83140f90b7d0bfc198cdc37f081f22d1e80b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
