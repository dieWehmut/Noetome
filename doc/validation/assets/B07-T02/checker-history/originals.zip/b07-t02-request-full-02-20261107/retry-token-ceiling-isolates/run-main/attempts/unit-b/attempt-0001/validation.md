# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f5ee9999de0f98e1e4f43a33563865a05ce3c0f9ff6f8ce3365f46d6b2a0903e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a1eacf5b5445d8a53f6c536d44b68c7567c0ac70d80d4ee147ac645a360ca997"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b97a56b52d80ab874cd6af6981ad35c8ef92ede58a6aa403513c1c27f798ca43"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "5befb125ed3aad12dc76fb4fff711dcd2897644001308d7f9e41219445657046"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d0d815f7bc35ed6e64c4a40835f2d7544355adb10acb99bf7dde3db970b53be2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b65795ed992c5ce87147a9fe012a98867d680387023e5673380d8328a47ea954"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "81a3ee38-9003-4747-bc7e-e1666eddb424",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "013b671d-97aa-492a-bec0-038e42d3d90e",
    "source_id": "ed3c8c72-5072-4ea2-aa63-88774ff8a453",
    "version_id": "60ded399-7fa3-45d9-8173-a79176daa693"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37359/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c124e2b7-689d-44a8-8e52-dd6676f2826a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d0d815f7bc35ed6e64c4a40835f2d7544355adb10acb99bf7dde3db970b53be2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
