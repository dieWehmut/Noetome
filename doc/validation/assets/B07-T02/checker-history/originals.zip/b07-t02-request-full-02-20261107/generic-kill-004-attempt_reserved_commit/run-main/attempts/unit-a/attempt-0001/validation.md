# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "47304966663c235d78e85b7bf4793f7973d825fe75cda7e64a28a783d0752a33"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d2c7a5d65a700846132f2bc403ee702068107310ea31c260d971f9a93ae1b2dd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "94146858f6fb353fe485e62680d7cca2df4103f2e2cf85691e57b0409f85db5b"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "f0ab7cba2db905881e44304aafaffed0ffe891bd1e48169b9b6b7d1a3be0d35e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a00cbe98b18c716f49e7e0fbeac006e84d52c755fbf3582d892105c5836d1249"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8768bd9d225105ad0addeafaf19a581e359ad8c26d68f0e2d3cb4e252c3c95e5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fdc236fb-86fb-44ea-b05d-c3133e21d49e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "44854556-f4d1-4b22-a985-5c0ba71fcd48",
    "source_id": "f4bd95d7-6cae-459c-ac97-bd8ad83b63a3",
    "version_id": "f787d87e-c98b-49bc-a625-330c7666c936"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37119/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2a02f22b-182d-40a2-a5d4-36db84f4d326",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a00cbe98b18c716f49e7e0fbeac006e84d52c755fbf3582d892105c5836d1249"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
