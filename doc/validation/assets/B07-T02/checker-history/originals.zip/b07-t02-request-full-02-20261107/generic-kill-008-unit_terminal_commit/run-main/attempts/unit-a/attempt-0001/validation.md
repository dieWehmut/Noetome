# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7014f753023fdceb8c56ecde2811d23136f0c5da55dee745175a3f6e0f4f615d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fe4a5424b567abb682f645999f103ec8512e5a2be203fa2dc8e8e9c92bbc4c26"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5ab0d2e179df184fa521d487317245510f494d445d98bad69d9319e4e67d4fde"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "7f3212880f53bcae52cac0e387994d904a1fd2df5e0f40c7303def26bb3babcb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d203ff2c367156e7e4713b8fb8053c632fa9c0385c65c3052bed7c3ef37f1c80"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a46a455dee9f00aaaecdb3e0b27a236347b067e64cada563f4116035eb87cfa0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c417643e-742c-42e7-a047-8907894e638b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "25c79324-bbf5-413d-82d5-31e4463e38e5",
    "source_id": "dc8ec718-c05d-4dd5-a347-65feb88072de",
    "version_id": "e3c33832-7ad9-446e-8428-dbbc48481e01"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37093/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dc6dc16f-1440-4557-a54c-6d8c7a344818",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d203ff2c367156e7e4713b8fb8053c632fa9c0385c65c3052bed7c3ef37f1c80"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
