# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f179d968936f3df5d4a31c4a5fbd43698917641da2e30db07d560550afdad219"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0357d88f4a1b7d36a111c13a4fe4a80a5855cc9e581928a46ad5f3ac09f608b2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c49dca70df00239a70647602e31dfc1cbdc0f711206c662f093e42ea5bd340bd"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "40e348e4cd11724a382802c560bc644518f33f34a33f6fb9d658049b87a0d912"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c30bf36bfabca190934718a8c1db5af08ef53b626aded6274dd21ddefb424d56"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9c34ecb194f9537502eddd94f398e31ca149e3e8411fd938fdb7f162ec329049"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2dae9836-c48a-4ae5-9efb-bf54c16adef1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c592fdc9-b50b-455d-8a7a-32ba07b80208",
    "source_id": "755d143d-30de-4bcb-9224-9dba193e6c68",
    "version_id": "e0dd16a3-73d1-4ace-968e-d2d97f7c6d5c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37683/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "993523d4-a775-4c9c-a9d3-4a46c776c2f1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c30bf36bfabca190934718a8c1db5af08ef53b626aded6274dd21ddefb424d56"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
