# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6b1f89ed6033bc07cbb7dc06f7ab830c62a5c36c23eb1d7f44c717b208ea25e2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b24930e9b8084f2b783ddd7999124aa982c1d1404c4f561c3206009cabef07cf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "da6064fbb1c528f35e3fa687590c02c0c1fe3b7ff8f66bf00aa32848c1810139"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "10da2ebe996607a33023d554463edd54ef23e611a88191daf3a6cf69b53fa254"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fb2b4a69f65e34b75290fcc8ee8be25e9f1a4d9edf12407be792d41b6ac7ac28"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b1b789ae4b526f88830d1787537fefcbadb0493a775580cfed98d227615ff957"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2f664228-ade9-4685-8e44-049048c27e3b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7483fbe1-61a9-4b93-adf7-5dabdc504ee7",
    "source_id": "44d3c205-289a-4709-b765-4d29a1eb6e89",
    "version_id": "ec4324e3-5622-41ed-9551-8be2823ba62f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36785/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f4d3662f-84a3-4941-84a3-d204f8182b18",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fb2b4a69f65e34b75290fcc8ee8be25e9f1a4d9edf12407be792d41b6ac7ac28"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
