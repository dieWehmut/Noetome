# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7f566dcda364c78c060f54cbecab54fb082c318f63082753bfa862a01f5fcc90"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f5b402ab75203c574d5fdbb54414be04a57f94a4d6d6e43857ce062f4b033076"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d4bb3c5fbf1f450d05d46e72e6288d45716a77968e8109e4c91880e78919c3b1"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "063f08ee1dac0e93c78e4929bf743d982fc86722714d175dd234fd8116151865"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e45e9a20a77d9204db3541e64689dcc4a50f3f960d4eaa375bb1c44b534a2cf9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "23802a947784cf56cef3ed575313e3f8a554c5caa4d80f91eadcec1347984a63"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2b91f8bc-628a-4d94-8432-d395d29a80ee",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d6aa7ff4-b11a-4e61-830a-3bca07f1d782",
    "source_id": "f33f5b21-a244-41f6-addf-84216f4e31c1",
    "version_id": "9e9673db-a282-4bfa-b32a-09e38eb11acb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c0cd7f5f-7d6d-4447-81ba-45e56c1d717b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e45e9a20a77d9204db3541e64689dcc4a50f3f960d4eaa375bb1c44b534a2cf9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
