# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "402da6c3ab494acfde1d6a4e6c8a46b7bab4c147e5d55679a2647bd5ee32f2c7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "93db612e2aa20a8bbb0943ccf19127dcfe917dbbe3c7a894970b17ef8b71523d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fcce6d1545c549b84845bb748d86a31b0470096e667b95ccd2a88eec11f2d8ea"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "d4c49721ce0fc28d5cfca816a01c6dafb27369ac468dc9ea63fad5d3e0160f8b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5db664275d68c16cb809e733d1507bdde45ef660df6a15b807f53950c8cc7bdb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "73fbe479391431bc61ac6b4d64cf577570fcfc3529b0267fe4d8e40fc107a069"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2ed8c993-4d48-49b2-a898-9b5c0e9a3cba",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ceec35d8-fd7b-4c30-af7e-db7e9ab8d58f",
    "source_id": "cd287899-a111-4def-89ee-63e81365a2ea",
    "version_id": "26a7927b-3ccb-45b1-a8ad-25db5684565e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36999/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "74fb5a97-a917-4c67-bdde-3a5b3e26a11f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5db664275d68c16cb809e733d1507bdde45ef660df6a15b807f53950c8cc7bdb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
