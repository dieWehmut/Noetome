# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2497a9ddf5a1eb98a5f277bb482c414481ab6937c3b9803992523fd909e8306f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "63f507867a6357470818aa8010bf9f55a498bade9fe794c7df77a54f7af07fe0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b975d409ad5b03fd42a29736d2195bed08855c089b0a25c34c6da7185fdb3da9"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "e5ffbe5126d9e399723c0a12989130ef53059d409a918dcff3508fa74ccb34ea"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0fae24d3d0c0e1883574b77713fb8c445b0a45a9d53a8ac93865dcf79e040be2"
    },
    "transport-receipt.json": {
      "byte_length": 479,
      "sha256": "3184989df4129e1a344430ecb8d87740df4a7abf16a078e9abfe310c1293b698"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "678f8007-109f-40ce-966d-badcdb4ead31",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3627f598-7b28-4d9d-b957-b3d6dd0f633c",
    "source_id": "7ca1eb0e-c599-4959-a4b4-3f0341ec8672",
    "version_id": "fa320ec4-56d3-4e31-a999-85601b9813f3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36569/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "557524ac-b9ff-4bbb-91b5-e2f341d616e5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0fae24d3d0c0e1883574b77713fb8c445b0a45a9d53a8ac93865dcf79e040be2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
