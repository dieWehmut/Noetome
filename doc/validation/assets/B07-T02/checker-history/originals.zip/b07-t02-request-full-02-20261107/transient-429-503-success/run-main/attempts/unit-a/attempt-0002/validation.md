# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：503；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "66c78f62520475ecffb9702add7991b52dc414b32db450e76621eaa321f823e5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f427950fd246f595b1ade060b06be1b97de797d4eb8e256927267594bbba4684"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "f488b1193f2d4110a78e244b1ece101193098826d432bcf98bc33241d495e8ea"
    },
    "response.bin": {
      "byte_length": 131,
      "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
    },
    "transport-receipt.json": {
      "byte_length": 499,
      "sha256": "d896cf8d8029323ffbba0a64ee494f92b9b16003430b5c0506f50dac0a824a2d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "678f8007-109f-40ce-966d-badcdb4ead31",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3627f598-7b28-4d9d-b957-b3d6dd0f633c",
    "source_id": "7ca1eb0e-c599-4959-a4b4-3f0341ec8672",
    "version_id": "fa320ec4-56d3-4e31-a999-85601b9813f3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36569/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_SERVER",
      "message": "EXTRACT_API_HTTP_SERVER：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 503,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a90ea1d6-88df-4c90-bcb7-999a7ddf51e2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 131,
    "omission_reason": null,
    "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
