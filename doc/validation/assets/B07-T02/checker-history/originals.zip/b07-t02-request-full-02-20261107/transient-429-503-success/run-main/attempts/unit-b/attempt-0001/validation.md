# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6a1d659ab92624a03575c1fadca2a874d9a47ad2a682daf82e9c685a4484327e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "53cf040ab8012492e1e0d702c68b1570d3335158421b7aac8a53490486dc6b2b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "87c2bb1dd951c6773f9ca47562f97befa61534dcc1dc1107f546b716b0a4d3d8"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "583585cbce3ac96483b1196e707f7a0d5ed6f428c40dc3feb821505b9eae1cbf"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d1b43b80eaef9452bb06c59e3d4c368a36b9558da73a2dd497215de2b6888cb6"
    },
    "transport-receipt.json": {
      "byte_length": 479,
      "sha256": "98c9eea57aaae4925cf61006226f008d535e46ad428cc94debf12b3f97cc9d9f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "144e585b-3fc8-4d57-8791-91f967f26345",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "970a9b1b-a3f7-46a8-ac0d-a5301bef2014",
    "source_id": "70be377f-c6e7-4b98-a60f-dff31d8713b8",
    "version_id": "1ff52762-ec9c-49e8-a43d-d8dd0c196b89"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36569/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "286924c0-fdbc-422e-96f4-4ab2e428bf68",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d1b43b80eaef9452bb06c59e3d4c368a36b9558da73a2dd497215de2b6888cb6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
