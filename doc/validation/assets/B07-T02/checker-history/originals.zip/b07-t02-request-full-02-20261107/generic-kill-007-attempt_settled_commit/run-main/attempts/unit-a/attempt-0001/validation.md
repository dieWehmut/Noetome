# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7ac67e0b75e2bf85925733ec8b25324d0dacbba1fc838e113cc6a2163b3d4a4e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "09613ff99c4d231edc4904e55d479ffc81e21b95c4dab3b5d0ed8dab1bd3e8c7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0c8ac8d544c860525285395bd77f1a7b5112ee06d1c3469407a50efd137666bb"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "f7930e3e886f8820c9e17b66273bd8fb4bb82fd4b02ce3cc96867cdc07ea3574"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d01626f2cc2fb04124233c9623b9561182ab946e42ea0b4daff70b16d96a027f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4d4712d0a36867c283d7d43d840e807dd93c0e5a52d529cb789f16388cfab1c5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1b8b2db5-e6d4-476e-8208-eb6d28a05a67",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "df74eaf9-ac9e-4d05-861c-271f6d9f454d",
    "source_id": "82016682-3265-4833-b5b8-1441314d267a",
    "version_id": "063e2574-3b96-4804-80cf-4fe886bc0b2b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38137/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "48036c9e-448e-468d-af41-e286c9b76d63",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d01626f2cc2fb04124233c9623b9561182ab946e42ea0b4daff70b16d96a027f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
