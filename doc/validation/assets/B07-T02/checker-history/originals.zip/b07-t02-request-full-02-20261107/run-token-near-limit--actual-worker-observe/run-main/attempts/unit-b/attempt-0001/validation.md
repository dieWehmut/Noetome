# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d200520fa18b7019f5f739e287d212e00597f73ba4e5db1136806f869221ed1f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "465a974648a37fdabf0092e851c5d850eadb91e43fd4a3792c58c79ff11a8b29"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "05424fe4eca5ee7ebf9a016bcc233abe1c3da78555dce80b6f932f698fc76867"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "a339af3cd81282c9f4ece3df78407dc0be72515b67dbc279eae34a774c5be590"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7ee32cec166e327b9a02ba620faff82e2568d847dd8fad2055ae42a2a58375c5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "42b2ca66018f39b2de0f7549feca41e26166930bfdc75f35af1aa345c2350f64"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e17d1a41-0528-4b10-95f6-213bb202b9d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "003cfd9b-211e-47c4-8f2b-253c7c0a9d44",
    "source_id": "0b0f06d8-1b46-4a9d-93b9-628351f5b0f3",
    "version_id": "3b6dbed3-7d02-4ab4-990c-71051149121a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38367/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "91094eb1-e98b-43a4-a0a5-05aee634081d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7ee32cec166e327b9a02ba620faff82e2568d847dd8fad2055ae42a2a58375c5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
