# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4456b92cc4ea7e87ff281fe8946825a8fdfd98962b55dd856c1dcb096e9dea96"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "dc8bac6881a8a9d29d27a3377aa122d1faa45bfd74e5f46fb8e718cef8d43c3b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "eb9cac07310f924305d1cc46bb8b58cc1145c9ef85864fa8339259956af83b6f"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "c81cf62164e529e782a6c1121ecbe39792d735659c6800174b441bd15b59a011"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "92eb9045fa971dcac4e506c342ffb1ce3a277af8378cd302b40b192a4cd5d9e1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ece00dec735cc7c3f98b5ab7dec7618d39225a1da4080270999834f921ee8a24"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f2e26154-07e3-418c-924f-9bd2248c18cb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3dd370ab-def0-4871-a12c-aecef5d64443",
    "source_id": "61a92ba8-f1f5-41d7-826f-8d9656c95daa",
    "version_id": "12c2b32f-e6d1-44cd-af77-6e37685c6efa"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38069/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3a403aad-c70e-4d17-b848-0046dbe6482d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "92eb9045fa971dcac4e506c342ffb1ce3a277af8378cd302b40b192a4cd5d9e1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
