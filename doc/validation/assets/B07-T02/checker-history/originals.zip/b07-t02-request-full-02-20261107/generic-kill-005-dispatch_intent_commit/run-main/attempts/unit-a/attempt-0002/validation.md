# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b7b3138a15f36dd4ff411f053c2cc08532490c7087bf40d4def59bdb6352efc5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "916df86c36ab56fe3bb29bd3b7471b411683410703896911c4121929236cff2d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "80cb5f8e02ee4eb68da0a521a8f1e6ab68f24e4d42314546c1d49c138e301c08"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "88d8debf2578cb8910acb9db93e9e91b64a110c20a2f0ca4e492e6b8d1d96357"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e87f131ffe7f41feba8185d56901bd83aa423a7719a951a0bf78d2d34107f519"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9222e8567f53c04ef36d80935052f58b3ff7577901ab95ccc04e456dc3a13896"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "146df1b4-3781-410c-9b1a-8bef6713d0f8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "84528a98-7c2e-4d29-9681-9c8685c4e73c",
    "source_id": "e9fff8ac-46e8-4855-bbfc-318d47e9e623",
    "version_id": "a029b908-7cab-405e-a7f4-e673cf33fdb2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36519/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "052ee50c-f2cb-48c7-ba30-3a5952029dec",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e87f131ffe7f41feba8185d56901bd83aa423a7719a951a0bf78d2d34107f519"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
