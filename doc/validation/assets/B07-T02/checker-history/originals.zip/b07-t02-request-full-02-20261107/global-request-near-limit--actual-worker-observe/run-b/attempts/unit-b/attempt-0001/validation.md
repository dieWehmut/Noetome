# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "301c559e5ddd2bc2f64f3ea345245633c6b5d3ba7ca5cc1b655c28d9017f247f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a3b659282025bb51c4f82ee8e5fdc002abb6e016a5d4391ce5a6d3d2006cc9ad"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ce1e31758101876737b329d65d2f3a56193113d21a626198a60d6de547664b9f"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "8b75b62dde06c457d3b65ea559dd390a84977170c8bd78e5cc816411b7ca4722"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "41a98e0539afff21d87da63e42fc3bf9a176859f2144c87d292304411237e342"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b87882baacc58222d8ee85c353fc821c44e9c1b1370947322c464a9f107ba6b4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5fd9397f-156f-4254-ac9f-62f4284f1420",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "61bf1eb3-ce59-4d2f-bb8d-e34f685d2359",
    "source_id": "5a42a99b-e1c7-4e9a-b78d-2fff5fda9d89",
    "version_id": "57d53869-7cde-420b-9de9-f23cc654574c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37635/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "31c0a382-36fb-4876-9207-7c76fd2e68c8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "41a98e0539afff21d87da63e42fc3bf9a176859f2144c87d292304411237e342"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
