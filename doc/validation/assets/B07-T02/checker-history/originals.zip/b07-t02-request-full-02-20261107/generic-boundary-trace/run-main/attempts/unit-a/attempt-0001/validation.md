# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "32c9f2bae97e683868fba839601ffd9fda1e612d54d4a7f1e86765933d1915f6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "64da09b5bfe77e0e79b610c642c01b73e87f8477e1140e8cb061e069820fb7f4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e98d5f51f8b8265c9ef6cf3f788ef8f76cd4f036fcb33ec4fd5fe0f4fcf4d3e7"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "1a033f2fe31492c0b419ed09cef389428075173c4a0d2996b1f3968b10bcafec"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8d0a005cd88e89d4da7d61d666793da4b75e02a70484dab06474633b6ffeec82"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "567a8453d94a500a36abba16efc8b30b3a40b4c4290c32fd202ae2767b05ba42"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3e3deab0-5aab-45ef-a040-b11445a88513",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ac5a1dfa-86e5-4a13-baaf-de83e17ec09a",
    "source_id": "8734f5ff-917d-493b-8262-07b2ba9810f3",
    "version_id": "42586345-dfb0-4332-9858-3f2309741c8b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37269/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2cd15891-e151-4c92-bfdf-d92500336385",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8d0a005cd88e89d4da7d61d666793da4b75e02a70484dab06474633b6ffeec82"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
