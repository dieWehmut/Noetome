# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "17b093864e77bebe16f21c4e03d1122464b7242f33fb1cb08e30542cb3da0e6b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4028077c4e391d3939ab8dd5496a320d67519f480d8343e6a9dff276f7987f59"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3a71390256ce202c749d575f926616dbd5f4dee2a7df5e13652dfc0a4ad0e55a"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "2bf8353b5c4e598214c3e46cfe6d362f99063fe9ed0c790781fe1493a70d5023"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f68262b8f8f3ab8875cbfd8bd4b778ca74468acba5011d165817bf306041e261"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f0be399669f541da6ff8d345e394d6575f6df1d943adcebf6a8a0a3f31b7ce3f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "155bd6bb-fd4a-4bc4-a550-e4dce39ecd35",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3ddb1048-844a-4be1-8b23-871049d3d0e1",
    "source_id": "b3e12281-6904-474b-ac49-204f9d1b49e9",
    "version_id": "d29d1800-ed7f-473c-a388-4c48f186c151"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38385/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0cdad911-d660-4586-8dee-f17796b421dd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f68262b8f8f3ab8875cbfd8bd4b778ca74468acba5011d165817bf306041e261"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
