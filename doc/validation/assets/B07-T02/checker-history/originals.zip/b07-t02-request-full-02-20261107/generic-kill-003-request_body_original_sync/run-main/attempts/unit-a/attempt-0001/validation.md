# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e33a0a9c29304b6a2a30bffc61a347f71f87bf1e36ff77be5ce31643ad1732f0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "aaa68582c9c57d64d3ab80f3d089a979a03c870f1990245329d836123bda15b5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f270cc01e8625b7468bedb61b601ca866ef03468de041695c88af58be3ce84ee"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "604ea2c92037b3d860706d0e811b8ca2503677620366f5243e5a71f054965d31"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1bc4ceef3c38d6c10241da409bdec7c5be907b6c0d7de540606cf965921ecff3"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8361de7a804c25b7210b312241fc78b6c2beffce900dd501db906e26d8db60c2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "30b777f4-1cd2-4f30-ba92-dec182a26106",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4071e942-9772-4da0-9a34-cf2d09e3388f",
    "source_id": "44256f38-74ad-4235-9fc1-5dcbf41aca60",
    "version_id": "807630d5-5824-4034-bc66-7b6f654973b8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37811/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5d2ebc29-6a26-46fc-a247-132840ca041c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1bc4ceef3c38d6c10241da409bdec7c5be907b6c0d7de540606cf965921ecff3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
