# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bf2623368a2ef5e4c6366994af2319a101136ec4641b75e27fa18b7bda1b315c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6d437bcfa0a447460ce945abf36b0dad997e3ec019c863e30de9f8033d401319"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "19f6b2b4e8e92f3cce042bb66b90b16f5cf9f951f0098a9ddca7dfa4dd1f5225"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 482,
      "sha256": "aa2a5561979151ab382ee5429f475f26a547e5e2a2e650973ae26f297564ee44"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3d5847ff-1311-4e4e-96af-0b6252ae17a0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7183ad0a-75a0-421e-bc8d-45fe43682eee",
    "source_id": "5b050acb-537d-403f-9c01-ce4d6d0d6e69",
    "version_id": "92f5d782-9e23-4baa-9c2f-8e78b3d994a5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37487/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRANSPORT",
      "message": "EXTRACT_API_TRANSPORT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9a16946b-82f4-40f0-9382-b69713910e2a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
