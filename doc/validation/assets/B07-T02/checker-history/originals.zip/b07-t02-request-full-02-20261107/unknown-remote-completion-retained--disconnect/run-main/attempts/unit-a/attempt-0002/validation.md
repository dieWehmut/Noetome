# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0287f222e4eaa16b87781ced8514b2574c050e398cbaa1b7faeed45e58d26588"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "513fb2871b8177ecbbf674f8632a93f1197b6b2d75aa84137513a0fb7584125a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bf44ca0b565c3067a97a30cbf6e13dc7011f1a2b945b1c3e6974cbec845f0062"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "88069f0db8b80cd60db4e23af3aa2132b5f2cb2133a286a3c467034eb9c5f1b6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5f686612fb1f07eb9883eaa330efca7d333af099a34d07ff8610940e1de8b65d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a9d46c14a5c68835c36babf87ee5a2be75398b76059a57232998133937c99fe8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3d5847ff-1311-4e4e-96af-0b6252ae17a0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7183ad0a-75a0-421e-bc8d-45fe43682eee",
    "source_id": "5b050acb-537d-403f-9c01-ce4d6d0d6e69",
    "version_id": "92f5d782-9e23-4baa-9c2f-8e78b3d994a5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37487/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cffebb69-ef34-4518-b0f7-caa287d23b69",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5f686612fb1f07eb9883eaa330efca7d333af099a34d07ff8610940e1de8b65d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
