# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f3cfe433f754e440074b6c2d7472e155a8bc6253417fb09399a352c3926c2120"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "dc0a555dff9b34ed85caf175e3d37e580e6c86258758b9c11b97c4e2499c49ae"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9ab874c999436a5d61cc1e822bf80485a1b0c12fe6b80ed1fe98d773c2ce0dd2"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "e226bfad5952e04f935ae2f3f078a69f5ddd99095957aa7d4cf01c29289ffac9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "697c77ae9e0b3ca317d53a3ae4f0bf85ab3955aa5089cb7b03491a97fcd63b8a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6dce5a38d3886819966462e18241a1fb5c34b6c90c3197ec1544532ae6427a62"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e136f42b-9667-48b9-baae-70d602f4278f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9c33c8f2-e6d4-482c-9096-4ec14dcab021",
    "source_id": "3f05e016-5e52-4192-8428-c513dcc804a1",
    "version_id": "175b4219-abff-4608-ab79-1b942470e291"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37487/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e638c4e8-f74b-4a5b-b805-7624f149aad3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "697c77ae9e0b3ca317d53a3ae4f0bf85ab3955aa5089cb7b03491a97fcd63b8a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
