# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c7753176babb412db35f26fdd14d145cec492cda8dfa140cf68cf449a91fee1b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0872468773cf1c60e04919627c316e39ed1ad2a6a13d506033c2bb86eab00de5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "34042cc27cbc1f48cae45072fe9c4a48db2f8b487090c60118c567054f13a17f"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "2a286dd237c610eaf9ebdf06ef58fa59c68ba1c61a194eba34b6ef53c144d81c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9360148c8e099d830c126fe37c7f4efc612de1c17d7746b397e0ff5dc8b3960c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a6a23566e84f42225cf845f86cc259faf9dc7edec8dfe76aa1a8a3023b7d514e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "45d8b627-252b-4850-b6e5-c51e85ded032",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c38ad347-6953-4336-b89e-3e00c6db3d57",
    "source_id": "622c0198-0a85-4f2d-9fa0-add96722a1d1",
    "version_id": "c12d819f-efb9-4498-bfdc-0ff9053ed4b0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37977/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "832d7c54-dc77-4ba5-9fc1-db92a49e59ec",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9360148c8e099d830c126fe37c7f4efc612de1c17d7746b397e0ff5dc8b3960c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
