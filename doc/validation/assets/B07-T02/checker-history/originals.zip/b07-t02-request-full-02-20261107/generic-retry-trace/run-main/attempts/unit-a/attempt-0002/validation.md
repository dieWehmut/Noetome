# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a223eb3daeb66f7845153fde99668e84429df46951d9e5aa5fd2a148354ca87c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "92d98e49d4498e8f7c6b6ce817a7935b489e009f76b75ff8c12332bcb85f6601"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e335d0148feaecab8c1bdd886e9f7934a091e8d7e60b046e9f015deb3d299bcb"
    },
    "request.json": {
      "byte_length": 2196,
      "sha256": "02f8d9c64f6a906b5ed5c3ee6f97d83c52f30297745f16e4cf97e99625ffc26d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1555990701a09a7d7f47a6d01ce3cce5e274b03b53e70f9588c2b5d4e8e4041b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "105201b7ee494c6812ae0cea22df778b897048ff3918e2f599bab9581b7bf7ba"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5035725c-10ed-4732-8bc4-4770d0246121",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d4058aa4-eedd-47c1-b8f0-068dd9cce2f4",
    "source_id": "9393de9a-db40-443c-9fac-27ab656148ab",
    "version_id": "c725e9a7-18b5-4b15-8cae-48b1adaff87d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38457/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f9dbd4f6-965b-4c95-8a50-846702fdd03a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1555990701a09a7d7f47a6d01ce3cce5e274b03b53e70f9588c2b5d4e8e4041b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
