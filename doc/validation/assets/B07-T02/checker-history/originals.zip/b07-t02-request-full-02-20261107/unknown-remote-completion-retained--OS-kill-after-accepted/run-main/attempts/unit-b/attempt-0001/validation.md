# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "063a462670ec484784ad71694b16c21a102a56f3ab6b07e89ddb6bd64b4af789"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f456cd0624dc05b756bd7701cb1ec46d8f778db9731e5a43e97b7c95861a8bc0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cb59e8e081db16c86958d070737d2d71e08c50b62236efa6ded1334767ec97d9"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "3c92c394b34c0b461d3897e7f7ccf7257075f45145fd0fedd37d05fa7d882684"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ef297e8d91270d55c2beffa0a457d47918f8d2d9186dde29a88e0cc71c7b7001"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cd6da643fc8974a9441664391e78b5596552e0e63c51d754d8862092ff729c8d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "54c1b028-d537-4ba6-b68d-573a1aacd0bd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1130295c-04a4-421b-869c-239f5d377998",
    "source_id": "12dd2490-17e6-4eee-8581-6dc301329cee",
    "version_id": "f8dee713-fd63-4544-b9bf-fde5b5224c5c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36791/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5fb02984-70c4-4b85-b636-6f6114660234",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ef297e8d91270d55c2beffa0a457d47918f8d2d9186dde29a88e0cc71c7b7001"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
