# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5f039383cae998e57e3d595a9742e64e1819c5b18e3e9c2f6b6295dcfbbee3e3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "47975becff816f04a32d534339d914d2ba329e1b6835ba988c9b784d6c5e15d4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b4b4161cc8bca25a6af560183f0cbc72e6227bce0ab98cbbea2012f5c0f89542"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "1b1dc291ce57fc69a384b3a628407b7cc0707cc1d751defdad70f901da8545d3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5a1127eddb0007f7e00f5d386985693a76c4533a94aaf813ded0ee4217c3691f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a95fafd1de940e48fb6f8d01cfba2e912b105eb3581ff6b3b49e0d4b50e664c8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "45f9c72f-76f1-4b53-afad-a6b068922c8c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "07345975-6572-4400-89f6-3815a099ecf7",
    "source_id": "0a893712-e696-47ca-ab6c-81a333d8cc3d",
    "version_id": "0cfcf1e7-5183-4d19-a405-709a58790871"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37473/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0746328c-0cfd-47c2-8d48-3c682ecc6c35",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5a1127eddb0007f7e00f5d386985693a76c4533a94aaf813ded0ee4217c3691f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
