# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "54629947520a4241d488a4ce32e5b2a46ecba54487291b5638884031de058e89"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "475359d1ab2544fc45323de8bf219a5bca8f84f42ce1f73ee53ca7580dcc772f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fed2ed5cdad9885d403631181413090402326338fba90666dd773548bd0b71aa"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "9844459fd13a394b749e827dc3dc9e4fb56da00cfee9d400597f5fb75462e5d8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "50d710db0ecc700336f17ecd7650d244a8c16601058ca0820bc6ab0f87cbeb30"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cca11910e487c8d94461dbf97f955d52782aa0ef758a4de7f193729210ef222c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9255f25b-799b-425b-a39c-01f548c6beeb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ba2265a0-242f-4239-941a-05ef44f187e7",
    "source_id": "20fc8236-6a20-4b57-93fd-fce084342e4e",
    "version_id": "fab054d9-a5df-402e-b751-64b349bad37d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36755/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fb3b7e45-e6f9-4143-9cd8-041a3b043f1a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "50d710db0ecc700336f17ecd7650d244a8c16601058ca0820bc6ab0f87cbeb30"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
