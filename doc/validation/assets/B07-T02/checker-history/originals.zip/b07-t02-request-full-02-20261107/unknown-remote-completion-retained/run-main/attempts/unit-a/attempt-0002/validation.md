# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fe6dcbc951ffcf89b25e4dab2ba191bba79d1b12bb1c4fc5d896d96406ceb21a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a8688d4a5353edf36f6e966e60e1fdefdb7f65cb48c3ea2f77582afb794686c8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7079e07036d6a3b4112dbdecc58c79172e02e449a436b591636c5dafca7511b1"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "3d0ffbf1d855fd7add5b0bcc2a97745ecd65929941878de4e3ad6232f46f2cc7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9a97880afb9c57b6851054579f6f643ab88afc38b974463446d9fbd5f8f529bc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2a1c9bb11454086f521fe641fa5f11203a2d0a3bf2e42fe7addb5f3f63bfe65c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a30769c3-ec1c-4a6c-ab80-a10931aead43",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "77813df8-b6d3-45bc-a2cc-1ba17573e698",
    "source_id": "8e5c79bd-19ef-448b-a598-93dfbf3257de",
    "version_id": "b878f8af-d281-49a8-a96c-2ac7b45c9f9c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36755/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4ff274c8-b200-417d-933e-c92d76d2e0c5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9a97880afb9c57b6851054579f6f643ab88afc38b974463446d9fbd5f8f529bc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
