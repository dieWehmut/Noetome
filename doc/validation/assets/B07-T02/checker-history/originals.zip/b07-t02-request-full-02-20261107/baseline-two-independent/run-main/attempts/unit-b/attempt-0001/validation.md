# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9b9e5183870609b1f5e2ef6b01b3dc7e2743f1440ca704472c9976f259c71fb5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8dbe741b08fd615bf8e7650f694bc559e2d097292cc22adc4f43e5fdb1beb7c4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0b5c5688aa73019282d15ff5b1c55ea4279c1034c4e9c4d63606ef3f58001b2c"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "2e34be3977071733233c9d654a00edfe383012f10093ba35a0483091c99fdade"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "31bed75592d536e2eca6a7e7579c60971ea7878e6a7fa2185d2dc00d1efdd5d2"
    },
    "transport-receipt.json": {
      "byte_length": 479,
      "sha256": "0e5c48c021751381a66bdacdb4bfa3220027ca52cb2f15e6e06a41d086f46cc2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ea287ee4-e6b1-4203-87ba-362fb409d105",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2315a5d4-738e-4387-9ca1-fc8114703876",
    "source_id": "2644fa13-4d19-42c1-8242-b01a785863cf",
    "version_id": "994f0a4d-4263-462b-b0f2-5ebdfc932a16"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37173/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "846f18be-6fc8-44cd-9958-aa00ea910277",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "31bed75592d536e2eca6a7e7579c60971ea7878e6a7fa2185d2dc00d1efdd5d2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
