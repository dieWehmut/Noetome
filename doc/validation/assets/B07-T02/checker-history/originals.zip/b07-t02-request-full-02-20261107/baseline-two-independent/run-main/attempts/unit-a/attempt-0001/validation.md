# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cf77d3b31fd50347f3107c20651663e71932c8666eb439a12765e19e41a399d6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5b65d32a298d22607b8a06334808739e2c2b008e40ab98cf93edd5dd3799a95b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "104f9060ee01caf5ce574c3ecf6e62c9452f360495b2e058c7205fa5a98c7600"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "caf208c7cca93abcfa7a4aae9b43ef2c4a36b953d60afc5f4f1c57e8c3984802"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0acda3856721845944d850f28ff48600e2541df99bd5fd2f88ea8e9f7de38ee9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8cb97921bda84d872f71129f72d906a4103305d88c814d0226eade456c62d556"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "57b878f3-9bf0-43ad-9350-c4127064cad3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "70a80a0e-ba6e-4178-bd19-37ee857530cd",
    "source_id": "5bbe52f6-928b-486f-97d2-b1e51f1c9a55",
    "version_id": "969a3caa-c079-4b47-9cac-8f7c17139c95"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37173/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b625d9da-98d8-47a2-8c9d-7e1ed5befcb8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0acda3856721845944d850f28ff48600e2541df99bd5fd2f88ea8e9f7de38ee9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
