# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d09b6d3adfc64bbe3c2f8e1d70f033af69527e00d3e6e442cb8ec0d666b76b36"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5733e7dbd6220243731f1a31543646e64f4746787380502f563cf5ac4d105896"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d6472ec0fcb6ca435d24592dbb250733adc57ae379955e33639201bf1e15365e"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "6fe484d229d00719f30dde889f94baeb9992b658749d3252555c2bc0c13c3675"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "092dd4fa41dd57e77462e4978a170de2486940e19bfc11d89207c1aca6fc7507"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cd052e9694f9c4ded60e16783cf14e73bd0ed1b7185be458bf3dc142ded1bfda"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "210c0cf3-301a-4cc2-a731-f1519103b5a1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c2db40ae-df47-4ba9-9a53-d743e6b87ea9",
    "source_id": "b61736f4-11c7-4418-b03b-96b25fe7c5d7",
    "version_id": "43134255-2313-4b9c-be80-35ad4d104bdf"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37677/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8d0bcdef-2437-4378-b4dc-c297e60baafb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "092dd4fa41dd57e77462e4978a170de2486940e19bfc11d89207c1aca6fc7507"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
