# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4930451196c262d3608b9726196ef9f07b8238ef9f8be63edbd77c8d28c9f967"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5786965bc6595ac3096fcf8566c56790cf4200b5d710fa21969cfc3f737f5c53"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "af0b5c18cdd55a5b3c51d3b74cc317650e49d780cafd7f08c507bb0e4af5178e"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "86cf1c94e1f290aa182bedc0c5e2024a0ebf280ef387b90a070f11c4d43b61fb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e0f4cdde3b6e5717d012a696fdafdfed08a58a3befc99458c33c9489f000cb7d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "34726838889d69646f4f4708dde49edd8cc63c6a214ad69c55a0ac61654930ef"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5d4c376d-9ef3-4312-8950-6c7981a71485",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9b55eba8-56dc-49b5-98c6-3675f556a9c8",
    "source_id": "af4b5d89-5427-497d-bad6-ccd7e417f27d",
    "version_id": "7e60abf7-789e-4c3c-b41b-00b692fc8b35"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37585/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "35982496-8f6e-4e3f-9865-dd485f00d364",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e0f4cdde3b6e5717d012a696fdafdfed08a58a3befc99458c33c9489f000cb7d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
