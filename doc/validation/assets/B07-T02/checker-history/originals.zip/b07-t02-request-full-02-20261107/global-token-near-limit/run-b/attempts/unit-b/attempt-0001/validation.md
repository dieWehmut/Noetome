# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ee00417abb10bf7cf643d6af38d56c0bc0a116000c73ae02287d990825ac5ecc"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b7b0763c0ba5f663adfea9357ef861195f1e2cf5b494741ef06151001bbfc3b4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cc5a95f3d2b414addf7d8ce554f9b924303ecff261c587bffff9548080605e93"
    },
    "request.json": {
      "byte_length": 2200,
      "sha256": "f3e77900235696937f43196ca8b146de297ea765fd38af091ae0f2996845f041"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e277b93acc0d28f5776d51ceaec46f41fa78468e797315443b4996aedf125540"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "152b216be19bfcc6dedef1ce1514bc47c0e41addafae61a744e7d4d981a4a934"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a9e94a16-a4d8-4f02-b07b-242d6d6e8ac5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d32dd8a5-9364-4528-944d-dc36ce96c089",
    "source_id": "99b1a907-1267-4aef-a9b5-8484eb337829",
    "version_id": "4984e134-4db9-47f4-82b5-7524e349a193"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38333/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ffc1e405-fddb-4710-8c23-73b16a30f760",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e277b93acc0d28f5776d51ceaec46f41fa78468e797315443b4996aedf125540"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
