# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "451fd94e42cc6890531afac857dac91ff7525b83ef592ff340e367ecc7800a06"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "796a533bd0cfd4bad564cbc094e3670ffffb8b6747eb4201c81e0bbfd20eb425"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "91b0c2c1fc68d2035a335a501c61925869c8aba5e06bd23c16a46547a8b19483"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "b16ec51617209a325713b0825f9ee85bcd0c7bb6dddb2e7e1a3327d7fb80c3a4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "27c442e0ff682b36e1febb5d53335db96561415cf2ff6724cdebb811a3548b25"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "51631badb8eb9d6cc4281f6d65dddb137ace4820fd3f7540956fe75d0bea3f0f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ffe6c66b-0909-4869-b2f3-a0fa1635f746",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "873ae7d5-6341-473c-80f5-6cb4603fbe53",
    "source_id": "a49961d9-7e72-41f1-b01e-9883fae46c5d",
    "version_id": "321f22e1-dd6f-4397-9b74-7e0913e4fc21"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38311/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f9825e9a-5a76-401d-ac81-b75489513513",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "27c442e0ff682b36e1febb5d53335db96561415cf2ff6724cdebb811a3548b25"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
