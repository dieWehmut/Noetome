# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d699d5c7bbfec152cfb387e26aea96f53e5d28d1e7234f5ea07f6ee158d3f70c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1ee1f93f92957001b4ad805db9deb603216affd73c43ea92d6ea1e4c11ba0bfd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a621759d38f4b840673ddc882bfe0c7b71f6c49e954ece073d1fc11eea59c3d1"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "0c68be755cddd4013a8621d8bb8194a9f1641e661904488d1026d436b576364a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9d595b5cd0694f3c3bbbc7b323e40fecf612c30c7968eae6dd4fb0dd0289986f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8fb01525fa34a9af7aa0802d9529094f93e5eadcf0a7f14e329b1e2db55d4aef"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9f6f1dbe-22d1-4016-9983-b591da329604",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ea1abcb5-8ee4-4e77-a200-ae0e010a188f",
    "source_id": "e90cd8b7-b31e-46fa-b510-89091b0439c3",
    "version_id": "289c7ee3-3eee-43b2-b40b-40f75e936432"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38311/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2d1f9ca4-a34e-46fd-90d0-8b41284bf9f7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9d595b5cd0694f3c3bbbc7b323e40fecf612c30c7968eae6dd4fb0dd0289986f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
