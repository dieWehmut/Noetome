# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8539586f12bda7521ab53315b0cb11075d620e5560deb9f1c50587e3c8fe4a8c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "392b66643974e52ef7961b56b8173bbe0545cea2df1fefaa69cc199a38b4ae24"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "ef7526285ceae3b7e1cc47a02c7c677b8b4a3543a5eeeefebf6730ff23fe4a4d"
    },
    "transport-receipt.json": {
      "byte_length": 465,
      "sha256": "2a540f106b800f0d41e7c5da137bf1b3d20c22f2b6674abd65a895fc0dc6ca84"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "239cf9d5-dbca-401a-ad14-12704bbea448",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7cc08908-452e-4f70-ad06-14bc7a436ca5",
    "source_id": "87d7b04c-c9da-454f-b031-8b9ee7906ded",
    "version_id": "df766c25-34e4-4380-b922-d6b5394a48e0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37415/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "90799c52-221b-49d6-94bc-cc3571b3e36b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
