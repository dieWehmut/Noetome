# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f636ab4713b81e5c2b3b39073e0f237e18a6d93b1f53f573e10d79ecfc8d278f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0e541594041d7f74bccafa4bb9ada74f5ad2855950c0ba3488e9a0d1ba7f3d33"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "c4c6ca7f76504711c7956438e3b30f213a8fecbf2d758d4269bd74a84b0f8e85"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "84188829be69332c70843edd80b16ab6e49efe0a3914a8333c6c841b131d8b88"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "48e29067a432d6661cfce4d36d4be6bdb163e2b092cc91e96cb86beb95b0dc13"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c1f9daee-a421-4514-a0cd-c0d12b7b595d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f2085915-733b-496f-8a9c-08ab1d6bde7a",
    "source_id": "4a4e2abf-5cd5-4133-a015-d35e7d80c361",
    "version_id": "9f825a90-6798-479d-9d7a-1ecff3f3e14c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37415/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2682413c-d706-4a1f-87d5-9dfe730af34d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "84188829be69332c70843edd80b16ab6e49efe0a3914a8333c6c841b131d8b88"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
