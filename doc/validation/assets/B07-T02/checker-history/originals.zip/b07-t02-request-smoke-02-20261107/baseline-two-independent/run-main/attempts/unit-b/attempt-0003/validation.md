# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4869117f3b351fe81b42247cc1dd8307ccbaff93ae548360ada22d537441960a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "136aec25fba64d541b441809d91964f69e20ab4d5155ce211f37b3d123874d76"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "b90f8341f0b315e8abe70091600c605fe81512816d217eae7ecb28ef8928a166"
    },
    "transport-receipt.json": {
      "byte_length": 465,
      "sha256": "2eee6b94741ed7d3084d9d646d4bb6e5aaa5a3baf7d670997b382089a067e8cb"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "239cf9d5-dbca-401a-ad14-12704bbea448",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7cc08908-452e-4f70-ad06-14bc7a436ca5",
    "source_id": "87d7b04c-c9da-454f-b031-8b9ee7906ded",
    "version_id": "df766c25-34e4-4380-b922-d6b5394a48e0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37415/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "38377366-4c81-4769-9fdc-80790b74d78f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
