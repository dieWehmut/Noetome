# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3df3f19794fefe48d05734eeff35546091ec25eea5d006ab8b855ecd7549cc6f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "48857ef0902e4c3f8529469c4ba2bc1340e6b7331e8ef41939cf022831467693"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "29fb00a06291a34e3a07d14f6f7dd4cfca1a9f9ca2a22e8e5c89b308638c5072"
    },
    "transport-receipt.json": {
      "byte_length": 465,
      "sha256": "7fec52dc3d0b8e3f9fc383daa340685693fe89a2f647c5ba5f38e0531b1658d5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c1f9daee-a421-4514-a0cd-c0d12b7b595d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f2085915-733b-496f-8a9c-08ab1d6bde7a",
    "source_id": "4a4e2abf-5cd5-4133-a015-d35e7d80c361",
    "version_id": "9f825a90-6798-479d-9d7a-1ecff3f3e14c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37415/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：请求已超过时间上限。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ca9ac051-8b57-4531-aae8-e3ed5bd6aa81",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
