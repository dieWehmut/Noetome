# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "67e65b7a9c76606a8099ff8adc34d1e7655f0cb35b4869a4d0309374782079fa"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "870b708154c7962462e8a07ccf3bc03c6b2ff73362342a4ba31407812a9c1fe1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f30335800ca6bd63df5a39e75fcb7d1f7c435ae1f1466500d4a34006007498d7"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "03c90e115556f424ed7232580e16522e05fe5e64c6a9d25b429b9dd9ef4d86d8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ae356a57a88d787e9a594f0ff9eb585730de2f20cc06d39871e194422d1f016f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "da8cf8c8eca9254c08d206bc9d2bf0b7d2bb6c7b0e78d431aac4c50c4e862d67"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "863305a4-1c40-4f22-80ee-0590422d57dd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4d4ae68d-8761-40b2-a950-77b67cc333fa",
    "source_id": "e72baa45-2660-4cb8-b01d-d67a9cd1e6a4",
    "version_id": "acd155fb-97dc-4f3e-8c92-7dfb34088ba4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36963/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f0f31935-a9ff-4e62-838a-de32fa25ed2f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ae356a57a88d787e9a594f0ff9eb585730de2f20cc06d39871e194422d1f016f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
