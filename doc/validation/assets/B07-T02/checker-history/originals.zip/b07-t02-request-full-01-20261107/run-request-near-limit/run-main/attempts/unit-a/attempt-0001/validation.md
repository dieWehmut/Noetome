# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9205a2044c44ea49f0748eaf4ccf8100e80fa803719b9ecd1bf8d5a5b6e2e3a1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "85f1eeb95f14e9873440d18aa37cb91b5f9608a5cd58d9ea161c0a521f63b24c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d1efe3d4e4bf3b6acae8d64e87e2bdf95bef9455796bdbe4dca5704b631e5fd5"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "cfeb53a07c4f6533b3b0f8fb18b6f68e1f2ac03e5f202cee073af96c4b58cf74"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "100011ae5ce7de4a494c1b8af2d2a95f3249d7b63a2cdc941eb3ccf656c7bba0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "33372e85278c3f7dfb8300950d7b126ca3d6d4bfcb4f1721acd2b85464688fd2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "46f6b22a-fd55-421f-b3df-18ed6105f8eb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "173060e2-ac5a-432c-a6a9-06fe4999a1d2",
    "source_id": "34044c62-5e3b-421f-9f84-aded521f5bb9",
    "version_id": "182fab81-c94e-4bc2-ab6b-d8c5aee94500"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38447/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0aaede90-2686-4904-b4a7-d248a624bc8a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "100011ae5ce7de4a494c1b8af2d2a95f3249d7b63a2cdc941eb3ccf656c7bba0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
