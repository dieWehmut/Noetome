# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8d4421a512908428387772304c7db56e9bd5121c89aac32ffc29a91d19c306c3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5805c820cd590e73b90187f42226919b421720956525e117379697391f99c0f7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c6f95a2a0b5c2cc97b2a76520b4c344f993ade42bd6b69171130f6ae40a360ad"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "a7a8079868f3de2f19656dbfe01c2b496ea9ccff3bf8d10428f518fcfe37ad2f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ac771552d299948b94bc4ad76909f86f3230ab6c84102578e7e6337c70036964"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "64e50874c8b1a7f55b25dfd66b06b157e83289926e1fde4f1019d4fc82313658"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9e255ea2-b166-4c5d-8c73-5f9182271ffc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d5bc7535-d9d1-4ee0-afcb-fb50f189367a",
    "source_id": "3ae845af-b98e-40ff-8ea1-4f039d46ef39",
    "version_id": "25e2615d-60e6-4c06-93c4-de87248c189e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38149/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6371899f-62c2-48f5-870c-5b5e61143b10",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ac771552d299948b94bc4ad76909f86f3230ab6c84102578e7e6337c70036964"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
