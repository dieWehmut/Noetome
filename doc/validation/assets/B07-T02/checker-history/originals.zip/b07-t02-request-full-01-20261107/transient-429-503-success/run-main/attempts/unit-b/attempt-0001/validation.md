# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a66014a035dda52934a15e608b0002a494e05859862aff3e95bc6c8fe896230f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9c932fc4ba5953506d1d3723a3155a52364aa6c5f302b56c0874388c4ee89cf9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "df748307c3929a817d607c50ca1be871c360a2492de35a6044b29a0578d497c6"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "c7a3bb457fae03b0077adb65bfaf5f15a983760a38db13c4e251e8f96c1960fc"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3f8a3f61a7503f0f475d5740ab3948f54a6d36ba3ab3d73bc19c49995f3526ee"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bfe428a124133d02ff9f108af4856286231b747831a46b81f94aaa9ba591e485"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0f5cb204-3fe2-474b-b755-ce61d6a12e7e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0a031e3b-6925-4601-a84f-94ef999e5ae0",
    "source_id": "a0fb10c4-87b4-44c9-b0b1-64b24ecda14d",
    "version_id": "69cb5f99-19eb-40d4-8d96-f8d8ca4bb519"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38305/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "623e62d2-1c0a-4912-a360-8e761f047943",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3f8a3f61a7503f0f475d5740ab3948f54a6d36ba3ab3d73bc19c49995f3526ee"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
