# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b5e7e481ef4dd3563864fc29e92efd6648e37e5a15ddeb1e91b0153a8b4afc99"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "89ecb602ff2c23700ca1b36562ca2002d2f91bb0f8d1a9342cc11c46e7b57bb5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "88f6904ff9159aad5114e83567b29d8b679ada7c0d14471955226111703e6366"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "533e8f267a213de46ef90e9407c795a081f6a60852af3f0e34d1f19f6f6eecd6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7534b2c583bb1f985bd596124585751688dc196b316c9a3cc50deb503c25bd8d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ffdcf801679ac2749c0a89faec56b20190530866ff731ff2b8919f9febeb9846"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6add6fec-ce15-4ad7-8798-492f46b5b02a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3f2813b7-94d5-456a-9ac6-b45b6127aa95",
    "source_id": "1cb91096-891b-4b89-aba0-4343111b25d9",
    "version_id": "2603e159-4399-4dab-b68a-eb619f84cc87"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38305/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fde74127-345e-45de-ab88-e80cf392e12b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7534b2c583bb1f985bd596124585751688dc196b316c9a3cc50deb503c25bd8d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
