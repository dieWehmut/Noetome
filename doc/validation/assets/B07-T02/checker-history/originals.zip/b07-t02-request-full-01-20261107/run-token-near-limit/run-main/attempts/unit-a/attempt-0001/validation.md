# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "70e38f5212f113ed68444926ecef58dca6f7748a7b79a25ea0ce45bdf722bebf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2c8b594303c7add1bf203f502f41b40aa98c9661a2b31d56691681589fba30d1"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "b06e516ae9b3dec13fca123a5e93cdb640da4debf27ce855bb3e2f6bc03f36e9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "23c5c98a-8445-47b7-bf41-38ee0a320e75",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "705e5c94-3c60-4455-af89-18c6d9b14d30",
    "source_id": "0cd08d74-7d5f-46dc-afcf-c77a47e9d6f4",
    "version_id": "2863554d-5f80-40d3-9d4b-aeee4f78fd74"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37137/v1/responses",
  "errors": [
    {
      "code": "REQUEST_RUN_BUDGET_STOP",
      "message": "REQUEST_RUN_BUDGET_STOP：准入拒绝；未发送并保留Prepared审计。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c07e3366-86af-4990-9975-a9856455a39c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
