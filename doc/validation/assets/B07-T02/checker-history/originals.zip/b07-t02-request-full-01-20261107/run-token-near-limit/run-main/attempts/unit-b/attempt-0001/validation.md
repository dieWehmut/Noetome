# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c442b6720d172458c041c47ce2a7cdbd2544b03f973be3f3e644d96df949a571"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "adab807f90b67c928244443a86f4d982d3d507c79f49617f1066a1cad333ab2b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1c8572397112c545e4af104ee71276f305e81e154026423fdc702d48e7d31a7b"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "b3daa9a4e471788cec213a2e1c7eaeb1a3cb15d9b2a22115c4eacd06ee5f6ab0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "40667541a0256ea060032b140d435e2d81aa7c27cb1c75d30d2e0b3744a88417"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5113986ea928813ca6b69c67d5b4499d352a6e4b153cb3e936a9224419d0cb44"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cf57a707-91bf-48ee-9a7c-b2d6bedc41df",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a51be124-ff5e-44d5-aa9b-7b5fdffc24bb",
    "source_id": "efdc2032-c02d-423f-ab43-6efaa9382e15",
    "version_id": "e849d35c-b600-45d1-a247-6d77be5e4f61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37137/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f8499a98-bdac-43de-a3f1-9f896cd514d7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "40667541a0256ea060032b140d435e2d81aa7c27cb1c75d30d2e0b3744a88417"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
