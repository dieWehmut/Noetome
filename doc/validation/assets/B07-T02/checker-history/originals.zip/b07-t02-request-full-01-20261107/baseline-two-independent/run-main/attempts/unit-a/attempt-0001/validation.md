# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "529c0aca860d0d2564d8dc9145c927f22890e35a0707e43b943e80f11b3fbb72"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0485aa696d3a167da6c4511410527e1f9ec1b6852ac417802e9960264a3cb5fa"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6fc38f299a4cb7d9943a13f8538984fdfa8a9accee58ce864bd6184b79832381"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "82e743c7a2ad0bb991593c7af60876cab39cb87df201fac9c2c966dd48dffe3a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f2304af48a0ac0e2ef3e84309ead1eb3d0eb3d8f759431cb2ac2f8207de903b1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0fc7da52a8b540ec36893d5e207c1dda8b1ac860d9bc4d954029031651196d3a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0609d887-ad69-414e-b64c-90df2f775da1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fdc1d50f-1c2b-4ec3-b227-7be34c997f4e",
    "source_id": "845e7b86-a995-40a7-a318-131096ac8535",
    "version_id": "6285d069-e516-4aba-8517-de1aa082eabc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36721/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "201f432a-a25c-4c88-86b0-9ba78c0ccbad",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f2304af48a0ac0e2ef3e84309ead1eb3d0eb3d8f759431cb2ac2f8207de903b1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
