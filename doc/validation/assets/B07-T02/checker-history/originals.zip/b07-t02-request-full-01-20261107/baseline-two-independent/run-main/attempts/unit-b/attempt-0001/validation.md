# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "212ac5339ec6571c9be24f16d296a7c048bdd4e98961245830395fcbaba0e38b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "12a66797090c0fcded2549ce01f168c21d1a55ccaef77d9ea58fa11473a74a61"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b92fd83a848e1219ac6d610290cc9e280b9c06e70ce80b70d868026b68885870"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "70948056c823d472e9c5e7ad9cdae8f4873763b6e6b1a3c29217afbb615bffb1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7f2301b8b0e2d1b5475ea600ebd0fa55bb5b9d47a27db2630e2ff300a2cf433c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ef80d0d4fff910fdb2f2c95559c1801044463b02a42a6982a8cb6506f40d8459"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e10d2f0f-634e-42db-961b-bb39c8d2bead",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5af29ca5-99a4-4499-963d-06bc0b214088",
    "source_id": "f48fcfdb-abbc-4a17-9432-b87819e16b08",
    "version_id": "4e8051ab-5e90-4619-9a0e-991f7ddef817"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36721/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dae9aa61-7b08-480b-a61f-b43dfe63da95",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7f2301b8b0e2d1b5475ea600ebd0fa55bb5b9d47a27db2630e2ff300a2cf433c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
