# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0df494abaa3e58d9cddc6a9cc588fa8ff4c8233938ea71d6630503327ca5b2d5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "16d153b0979d401a0951e1f9a1bf7d9ba23468474ef1ec610eb25e9ea5fbad86"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6c968fcb872bcd4a886fb79feda682249e80411215fc92882097d0de7bcc74b0"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "c8a40773eaaea7403d914db71f9082e1a4eb9886161ce73a2b0c06b554f7e23a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "04c39968eb90f879918379652ec7d917899e2980ef602b50fed6527c6944322c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "eabec6f6e35f0287edd98cc2ae3a97a221a2c4de03e8209959d5c26f22215a39"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "47502aed-8281-493b-825b-a5c986bf9977",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ff015c86-2fc6-4d94-a914-de977e7463d3",
    "source_id": "a11d0b47-1093-4c73-8a61-ca2735f7b096",
    "version_id": "9ab74342-0453-4236-8fa1-adf6cdae8b5c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38233/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4df1965c-d522-490a-ae14-ccbc631b0d0e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "04c39968eb90f879918379652ec7d917899e2980ef602b50fed6527c6944322c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
