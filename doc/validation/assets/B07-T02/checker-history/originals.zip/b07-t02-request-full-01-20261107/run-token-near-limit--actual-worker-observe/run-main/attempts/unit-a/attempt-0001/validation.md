# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a74399f768f27c46b0abe1811abaabe131af40862459dc1ab5c8001ec06530fb"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e5484120d0b4a96118e8978176f990687513fcdf22bb9413dcc6f2152a26090b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "01569f96f9dc51373681cb5506410e495737ed95ce17534d00c477a35cf3afd0"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "1444b0b4ec4519a40995e5eeaa87771e025fa6b7ada763e17af7f549fcb84b6f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "de12c7d345d1eba289af4897a047798bbcadf6aa1f6ed37491cd393cdb3a8134"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1ba1e5ed7f9072ce965c69787559e4a2a0d3583b6ee90eda84ffbf27d32edfc7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9612b17d-25c2-4c27-8c51-bb59d5634da3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bfb1af54-15f6-432c-92df-1793f60be5dc",
    "source_id": "ac82b2aa-2de8-417a-a4e6-745a9b4ea0b0",
    "version_id": "00cdf33a-fdad-4f81-ae5a-1686c2a7a31f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37731/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e99dba88-8b8f-4407-8e2b-793112086d34",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "de12c7d345d1eba289af4897a047798bbcadf6aa1f6ed37491cd393cdb3a8134"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
