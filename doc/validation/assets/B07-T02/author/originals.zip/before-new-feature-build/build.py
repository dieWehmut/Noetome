from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,zipfile

WORK=Path('/home/lyinn/project/Noetome')
ROOT=Path(__file__).resolve().parent
def pin(raw):return {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
names=['Cargo.toml','Cargo.lock','crates/noetome-cli/Cargo.toml','crates/noetome-cli/build.rs']
for directory in ['crates/noetome-cli/src','crates/noetome-cli/tests']:
    names.extend(p.relative_to(WORK).as_posix() for p in (WORK/directory).rglob('*') if p.is_file() and p.suffix=='.rs')
names=sorted(set(names))
def source():
    out={}
    for name in names:
        p=WORK/name
        assert p.is_file() and not p.is_symlink(),name
        st=p.stat();out[name]={**pin(p.read_bytes()),'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns}
    return out
before=source();save(ROOT/'source-before.json',before)
with zipfile.ZipFile(ROOT/'source-originals.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in names:
        raw=(WORK/name).read_bytes();assert pin(raw)=={k:before[name][k] for k in ['sha256','byte_length']}
        z.writestr(name,raw)
env={name:os.environ[name] for name in ['PATH','HOME','USER','LOGNAME','LANG','LC_ALL','TZ','CARGO_HOME','RUSTUP_HOME'] if name in os.environ}
env['CARGO_ENCODED_RUSTFLAGS']=''
def run(label,argv):
    folder=ROOT/label;folder.mkdir();started=time.time()
    with (folder/'stdout.bin').open('wb') as out,(folder/'stderr.bin').open('wb') as err:
        p=subprocess.Popen(argv,cwd=WORK,env=env,stdout=out,stderr=err)
        save(folder/'launch.json',{'argv':argv,'cwd':str(WORK),'pid':p.pid,'started_unix':started,'environment_names':sorted(env),'real_model_calls':0,'paid_calls':0})
        code=p.wait()
    receipt={'argv':argv,'exit_code':code,'elapsed_seconds':time.time()-started,'stdout':pin((folder/'stdout.bin').read_bytes()),'stderr':pin((folder/'stderr.bin').read_bytes())}
    save(folder/'receipt.json',receipt);print(json.dumps({'label':label,**receipt}),flush=True)
    if code:raise SystemExit(code)
    return receipt
receipts=[run('rustc',['rustc','--version','--verbose']),run('cargo',['cargo','--version']),run('fmt',['cargo','fmt','--all','--check']),run('clean',['cargo','clean','-p','noetome-cli']),run('build',['cargo','build','-p','noetome-cli','--bin','noetome','--offline','-v']),run('driver-build',['cargo','test','-p','noetome-cli','--lib','--no-run','--offline','-v'])]
cli=WORK/'target/debug/noetome'
drivers=list((WORK/'target/debug/deps').glob('noetome_cli-*'))
drivers=[p for p in drivers if p.is_file() and p.suffix=='' and os.access(p,os.X_OK)]
assert len(drivers)==1,drivers
for name,p in [('noetome',cli),('run-test-driver',drivers[0])]:
    shutil.copyfile(p,ROOT/name);(ROOT/name).chmod(0o555)
after=source();save(ROOT/'source-after.json',after)
assert before==after,'source changed during actual compiler build'
outputs=list((WORK/'target/debug/build').glob('noetome-cli-*/output'))
build_outputs={str(p.relative_to(WORK)):p.read_text() for p in outputs if 'NOETOME_RUN_COMPILER_FINGERPRINT' in p.read_text()}
save(ROOT/'compiler-build-outputs.json',build_outputs)
result={'status':'passed','scope':'candidate exact clean Linux CLI/lib-test compilation; full Linux Rust not_run; final behavioral gates pending','source_files':len(names),'source_unchanged':True,'source_archive':pin((ROOT/'source-originals.zip').read_bytes()),'cli':pin((ROOT/'noetome').read_bytes()),'driver':pin((ROOT/'run-test-driver').read_bytes()),'original_driver':str(drivers[0]),'runs':receipts,'real_model_calls':0,'paid_calls':0}
save(ROOT/'actual.json',result);print(json.dumps(result),flush=True)
