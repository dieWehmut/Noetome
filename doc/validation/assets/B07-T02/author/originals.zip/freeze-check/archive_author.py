from pathlib import Path
import hashlib,json,zipfile,time
repo=Path('/home/lyinn/project/Noetome'); art=repo/'.artifacts/b07-t02-author-freeze-20261107'; pack=repo/'fixtures/run-api-budget-v1'
package=art/'package'; package.mkdir(exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
 s=p.stat(); b=p.read_bytes(); t=p.stat(); assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 return {'sha256':sha(b),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
selected={}
for prefix,root in [('author-pack',pack),('preflight-failed-01',repo/'.artifacts/b07-t02-author-preflight-20261107'),('preflight-zeroHTTP-02',repo/'.artifacts/b07-t02-author-preflight-02-20261107')]:
 for p in sorted(root.rglob('*')):
  if p.is_file():
   assert not p.is_symlink(); selected[prefix+'/'+p.relative_to(root).as_posix()]=p
for p in sorted(art.iterdir()):
 if p.is_file(): selected['freeze-check/'+p.name]=p
build=repo/'.artifacts/b07-t01-linux-build-05-20261107'
for n in ['actual.json','source-before.json','source-after.json','source-originals.zip','compiler-build-outputs.json','build.py']:
 selected['before-new-feature-build/'+n]=build/n
for d in ['build','driver-build','fmt','cargo','rustc','clean']:
 for p in sorted((build/d).rglob('*')):
  if p.is_file(): selected['before-new-feature-build/'+d+'/'+p.relative_to(build/d).as_posix()]=p
before={name:{'source_path':str(p.relative_to(repo)),**pin(p)} for name,p in selected.items()}
write(package/'source-before.json',before)
zip_path=package/'originals.zip'
with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in selected.items(): z.write(p,name)
after={name:{'source_path':str(p.relative_to(repo)),**pin(p)} for name,p in selected.items()}
write(package/'source-after.json',after); assert before==after
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None and set(z.namelist())==set(selected)
 for name,p in selected.items():
  b=z.read(name); assert sha(b)==before[name]['sha256'] and len(b)==before[name]['byte_length'] and b==p.read_bytes()
manifest={'schema_version':1,'producer':'independent_author_preflight_freeze_originals_archive','members':before,'archive_sha256':sha(zip_path.read_bytes()),'archive_byte_length':zip_path.stat().st_size,'members_count':len(selected),'all_members_CRC_SHA_len_exact_readback':True,'all_source_identity_mtime_bytes_before_after_equal':True,'binary_bodies':'not duplicated; old fixed ELF SHA+original build receipts/source archive bound','real_model_calls':0,'paid_calls':0,'new_product_behavior_tests':'not_run'}
write(package/'manifest.json',manifest)
result={'status':'passed','archive':str(zip_path.relative_to(repo)),'archive_sha256':manifest['archive_sha256'],'archive_byte_length':manifest['archive_byte_length'],'members_count':len(selected),'manifest':str((package/'manifest.json').relative_to(repo)),'manifest_sha256':sha((package/'manifest.json').read_bytes()),'author_freeze_manifest_sha256':sha((pack/'frozen-sha256.json').read_bytes()),'scope':'frozen author, genuine 0HTTP oldCLI preflight and failed wrapper originals, new static checks and source guards; no new product behavior claimed','created_ns':time.time_ns()}
write(package/'actual.json',result); print(json.dumps(result,ensure_ascii=False))
