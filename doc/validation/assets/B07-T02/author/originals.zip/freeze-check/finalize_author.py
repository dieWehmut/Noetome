from pathlib import Path
import hashlib,json,shutil,time
repo=Path('/home/lyinn/project/Noetome')
pack=repo/'fixtures/run-api-budget-v1'
art=repo/'.artifacts/b07-t02-author-freeze-20261107'
def sha(b): return hashlib.sha256(b).hexdigest()
def pin(p):
 s=p.stat(); b=p.read_bytes(); t=p.stat(); assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(t.st_dev,t.st_ino,t.st_size,t.st_mtime_ns)
 return {'sha256':sha(b),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'nlink':s.st_nlink}
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read(p): return json.loads(p.read_bytes())
author_names=['source.txt','expected.json','response.json']
old=repo/'fixtures/extraction-gateway-v1'
source_before={n:pin(old/n) for n in author_names}
copy_before={n:pin(pack/'source'/n) for n in ['source.txt','gold.json','candidate-template.json']}
write(art/'original-author-before.json',source_before)
write(art/'source-copy-before.json',copy_before)
pol=read(pack/'policies/author-policy.json')
pol['global_defaults'].pop('opening_requests')
pol['global_defaults'].pop('opening_known_tokens')
pol['global_defaults']['opening']={'accounted_tokens':0,'held_tokens':0,'dispatched_requests':0,'held_requests':0}
pol['accounting']['attempt_numbers']='Prepared logical attempt numbers remain monotone and are never reused, including NotSent; dispatched/may-send attempts and logical prepared high water are checked separately'
pol['retry']['classification']='The five retryable HTTP/transport classes allocate new attempts within all limits; malformed wire/candidate/output, authorization, context/source/capability failures are nonretry isolation'
pol['interrupted_process_recovery']={
 'classification':'REQUEST_INTERRUPTED','entry':'explicit ordinary resume only',
 'preconditions':['no trustworthy final receipt','old worker has actually exited or lost all sending ability','original Source/Owner/compiler fingerprint and artifacts fully rechecked'],
 'old_attempt':'original MaySend remains Unknown with the full R; never resend its request_id or lower its commitment',
 'continuation':'a distinct new attempt may proceed only within unchanged attempt, retry Token, Run/global Token/request and durable deadline limits',
 'not_ordinary_retryable_report_class':True}
write(pack/'policies/author-policy.json',pol)
authority={'schema_version':1,'producer':'synthetic_api_budget','global_budget':{'max_requests':32,'max_total_tokens':1048576,'max_cost_usd':None},'opening':{'accounted_tokens':0,'held_tokens':0,'dispatched_requests':0,'held_requests':0}}
write(pack/'policies/authority-template.json',authority)
opening=json.loads(json.dumps(authority)); opening['global_budget']['max_total_tokens']=9009; opening['opening']={'accounted_tokens':700,'held_tokens':0,'dispatched_requests':1,'held_requests':0}
write(pack/'policies/authority-opening-template.json',opening)
run={'schema_version':1,'producer':'synthetic_api_run','run_budget':{'max_requests':6,'max_total_tokens':65536,'max_cost_usd':None},'concurrency':2,'max_elapsed_ms':10000,'retry':{'base_delay_ms':100,'max_delay_ms':400},'units':[]}
for u in ['unit-a','unit-b']:
 run['units'].append({'unit_id':u,'project':'/AUTHOR_SELECTED_SOURCE_PROJECT','import_id':'00000000-0000-4000-8000-000000000001','api_config':'/AUTHOR_SELECTED_API_CONFIG','max_attempts':3,'max_retry_tokens':16620,'max_elapsed_ms':5000})
write(pack/'policies/run-template.json',run)
write(pack/'runtime-binding.json',{'schema_version':1,'producer':'independent_author_runtime_binding_windows','templates_are_not_runtime_configs':True,'run_template':'policies/run-template.json','unit_runtime_rebindings':{'project':'actual selected freshly created ordinary CLI source project absolute canonical path','import_id':'actual import UUID read from the source project; no placeholder ID accepted at execution','api_config':'actual selected local_http_test API config absolute canonical path'},'authority_overrides':'case global limits/opening only; never adopt any production ledger','run_overrides':'case run/unit/retry literal overrides only; no output-derived policy','request_body_binding':'request-binding-windows.json','invalid_or_unknown_runtime_binding':'reject and preserve; no output write or HTTP'})
cs=read(pack/'cases.json')
for c in cs['cases']:
 c['execution_layout']={'kind':'one-run-two-units','unit_to_run':{'unit-a':'run-main','unit-b':'run-main'},'shared_global':'budget-main'}
 e=c['expected']
 if c['case_id'].startswith(('run-','global-')):
  e.pop('candidate_validated_units')
  e['candidate_validated_unit_count']=1
  e['candidate_validated_unit_subset']=['unit-a','unit-b']
  c['variants']=[]
  if c['case_id'].startswith('global-'):
   c['execution_layout']={'kind':'two-concurrent-runs-one-unit-each','unit_to_run':{'unit-a':'run-a','unit-b':'run-b'},'shared_global':'budget-main'}
 if c['case_id']=='prior-global-spend-not-reset':
  e['candidate_validated_units']=['unit-a']
  c['execution_layout']={'kind':'two-sequential-runs-one-unit-each','unit_to_run':{'unit-a':'run-before','unit-b':'run-after'},'shared_global':'budget-main','order':['run-before settled known700','run-after denied new request']}
  c['variants']=[{'name':'explicit-synthetic-opening','authority_template':'policies/authority-opening-template.json','execution':'new Run only; do not dispatch preceding Run','expected':{'observed_HTTP_requests':0,'known_tokens':700,'unknown_commitment_tokens':0,'total_committed_tokens':700,'opening_dispatched_requests':1,'opening_prefix_unchanged':True,'candidate_validated_unit_count':0,'remaining_tokens':8309,'new_Run_HTTP_requests':0}}]
 if c['case_id'] in ['retry-backoff-persists-through-kill','elapsed-limit-persists-through-kill']:
  c['policy_overrides']['retry']={'base_delay_ms':1000,'max_delay_ms':2000}
 if c['case_id']=='retry-backoff-persists-through-kill':
  e.pop('second_request_at_least_base100ms_after_first_response_before_write')
  e['minimum_retry_delay_ms']=1000
  e['measurement']='server response_before_write timestamp to next request_received is a lower bound; persisted retry_not_before must independently remain unchanged after restart'
 if c['case_id']=='retry-token-ceiling-isolates':
  e.pop('unit_a_attempts')
  e['unit_a_dispatched_or_may_send_attempts']=2
  e['unit_a_logical_attempt_high_water_at_most']=3
  e['attempt_numbers_unique_never_reused']=True
 if c['case_id']=='unknown-remote-completion-retained':
  for v in c['variants']:
   if v['name']=='OS-kill-after-accepted':
    v['recovery_classification']='REQUEST_INTERRUPTED'
    v['explicit_ordinary_resume_only']=True
    v['old_worker_verified_exited_before_resume']=True
    v['old_MaySend_remains_Unknown_full_R']=True
    v['final_receipt_must_be_absent_before_resume']=True
  e['no_unknown_attempt_settlement_or_reservation_release_without_valid_original_usage']=True
write(pack/'cases.json',cs)
ex=read(pack/'expected.json')
ex['interrupted_process_recovery']='REQUEST_INTERRUPTED is an explicit resume-only recovery class under verified prior worker death and Source/Owner/compiler checks; unknown old MaySend keeps R, only a fresh bounded attempt may continue; not ordinary malformed-report retry'
ex['templates']={'authority':'policies/authority-template.json','nonzero_opening':'policies/authority-opening-template.json','run':'policies/run-template.json','runtime_binding':'runtime-binding.json'}
ex['logical_attempts']='monotone Prepared numbering never reused; NotSent release requires authoritative never-may-send proof and retained record; dispatched/may-send count is distinct'
ex['timing']='durable retry/deadline fields plus actual server response_before_write/request_received and OS process wait receipts; no fake time'
write(pack/'expected.json',ex)
pre=repo/'.artifacts/b07-t02-author-preflight-02-20261107'
for i in range(1,5):
 dst=pack/'originals/preflight-commands'/f'{i:03}'
 dst.mkdir(parents=True,exist_ok=False)
 for n in ['receipt.json','stdout.bin','stderr.bin']: shutil.copy2(pre/'commands'/f'{i:03}'/n,dst/n)
for letter in ['a','b']:
 dst=pack/'originals'/f'preflight-api-{letter}'; dst.mkdir(exist_ok=False)
 for n in ['request.json','validation.json','validation.md']: shutil.copy2(pre/f'api-prepared-{letter}'/n,dst/n)
shutil.copy2(repo/'.artifacts/b07-t01-linux-build-05-20261107/actual.json',pack/'originals/core05-build-actual.json')
pins=read(pack/'source-pins.json')
pins['old_cli']['build_receipt_original']='originals/core05-build-actual.json'
pins['old_cli']['source_archive']={'original_path':'.artifacts/b07-t01-linux-build-05-20261107/source-originals.zip','sha256':'6c79f7b7bbdab160135ae2e46bc7f932cde59b902d36ad3ca4981b820ce9df4c','byte_length':662441,'scope':'125 exact old CLI/test build inputs, before the new run API feature; not newly rebuilt here'}
pins['preflight_capture_limit']='source_author_files_unchanged in the original preflight receipt was a literal assignment; it is not accepted as historical before/after inventory. Current three exact raw copies are independently checked against original old author pins; new freeze records actual before/after file identity/hash checks.'
write(pack/'source-pins.json',pins)
(pack/'.gitattributes').write_bytes(b'* -text\n')
(pack/'README.md').write_text('''# 持久 API 预算与有界重试作者包

本包在 B07-T02 产品行为实现前声明故障、策略和预算 expected。只用于新的测试项目和数字环回 `127.0.0.1` Responses 服务；凭据为公开人工值，真实模型及付费调用为 0，价格保持 `null`。不访问旧累计授权、生产账本、私人资料或生产 Vault。

`source/source.txt`、`source/gold.json`、`source/candidate-template.json` 分别逐字节复制旧 `extraction-gateway-v1` 的 source、expected、response，来源 SHA 见 `source-pins.json`。140 字节文字是原作者工程数据；两独立单元可以各选同一原始 span0，不代表两份真实科学页面。quote、数值、单位和条件来自旧作者 gold，不能从新输出推导。成功只表示严格候选绑定/结构通过，候选仍 pending、unverified、unpublished，科学质量 `not_run`。

`cases.json` 冻结 14 核心场景：双单元成功；429/503 后成功；次数耗尽隔离；已知用量的候选失败隔离；相同响应 SHA 的不同请求分别结算；Run 请求/Token 两近限；共享全局请求/Token 两近限；前次支出与非零人工 opening 不重置；未知远端完成的超时/断连/截断/真实 OS kill 变体；退避检查点 kill 恢复；耗时截止 kill 恢复；retry Token 到限隔离。四个 near-limit 场景需要两个实际并发 worker，首响应由服务端持有，胜者身份无预设。全局场景使用两个实际 Run 共享新 authority；顺序支出场景则先真实结算再新建 Run。额外 opening 和未知完成变体有各自先验字段，不能把它们的流量合并成虚构实际测试计数。

`policies/authority-template.json`、`authority-opening-template.json` 和 `run-template.json` 使用约定配置字段；Run 模板绝对路径/UUID是明确占位符，运行前只能按 `runtime-binding.json` 从普通 CLI 新建的选定项目取得真实 project/import/API-config。API 单请求模板只允许 local_http_test/openai_responses。`request-binding-windows.json` 列出六个 36 字节真实 UUID 替换窗口，其他 body 字段和原文不变，最终完整请求 UTF-8 字节数必须仍是 5238。

旧固定 Core05 ELF `e7194fa4…c8512` 在新测试根实际执行了 4 条普通 CLI：init、import、两个 `max_requests=0` API 预检。后两条保存原 request-body，实际 exit3/EXTRACT_BUDGET_STOP、network_attempts=0；原 stdout/stderr/回执及报告保存在 `originals/`。独立按原字节计算输入预留 `5238 + 1024 = 6262`，完整预留 `R = 6262 + 2048 = 8310`。近限 cap 固定 `R + 699 = 9009`；有效完整响应已知用量 700 后剩余 `8309 = R - 1`，不能再准入完整 R。该算式是旧单请求 body 与保守预留规划证据，不是新预算实现验收。

原 preflight receipt 的 `source_author_files_unchanged:true` 是脚本字面赋值，缺少当时独立作者/项目库存，不能作为历史全过程 guard 证明。本包只认可当前三份 raw copy 与旧作者 source pins 逐字节相等、原 4 条 CLI 和零 HTTP；新的冻结过程另在 `.artifacts/b07-t02-author-freeze-20261107/` 保存实际原作者及 copy 的 before/after SHA、len、身份、mtime 核对。最初 preflight wrapper 在 init 后尝试 JSON 解码普通文本失败，原 1 条 init 和错误原件仍留在 `.artifacts/b07-t02-author-preflight-20261107/`，不计为产品故障或删除。旧 preflight 原件保持原字节。

服务端使用固定响应模板。`fixed-200-invalid-candidate.bin` 的完整 wire 有可信 input100/output600/total700，但候选文本 `{}` 不合法；两个不同请求返回同一原字节 SHA，均必须各扣 700 且隔离失败，不能按 SHA 合并或放宽候选绑定。成功模板只把实际 request/source 身份绑定进旧作者候选，不增删作者内容。HTTP 429/503、超时、断连、截断缺可信 usage，原 attempt 完整 R 保留；只有五类允许普通有限重试，每次新 attempt/request_id、新预留，失败 wire/candidate/output/auth/source 等隔离而不重试。已知 provider 超量必须保存真实数值并停止新准入，不能裁成上限或写 0。

真实进程中断独立归为 `REQUEST_INTERRUPTED`，只在显式普通 resume、旧 worker 已实际失去发送能力且 Source/Owner/compiler/原件重验后允许继续。没有可信 final receipt 的旧 MaySend 仍 Unknown 并保留 R；新 attempt 仍受次数、retry Token、Run/global 和持久截止时间限制，绝不重发旧 key。Prepared 逻辑编号不倒退；仅从未 MaySend 的协议证据允许 NotSent 释放 token/request slot，记录仍保留。一次 attempt 重启/重复交付只结算一次；不同 attempt 同 SHA 仍分别计量。

退避默认 100/200ms 有界；kill 退避案独立用 base1000/max2000ms，实际服务 `response_before_write` 到后继 `request_received` 给出延迟下界，并核对持久 retry_not_before。耗时案 unit1500ms、实际等待1700ms，Run10000ms仍容许独立 B 单元。OS kill 必须是真实平台终止和 wait 回执；不能以故障 flag 或伪造状态替代。

`expected.json` 与 cases/policy 是先验判据，未从新产品 DTO/report/SQL 镜像生成。`frozen-sha256.json` 按每个原文件 SHA/字节数冻结本包，排除自身；冻结锚为该文件完整 SHA。新增实现、独立 HTTP 时序/预算/每提交窗口 kill 与完整回归尚未运行，此包不宣称这些门槛通过，也不证明 live 网关恢复、Retry-After、供应商幂等键、真实账单或科学正确率。
''',encoding='utf-8')
source_after={n:pin(old/n) for n in author_names}
copy_after={n:pin(pack/'source'/n) for n in ['source.txt','gold.json','candidate-template.json']}
write(art/'original-author-after.json',source_after)
write(art/'source-copy-after.json',copy_after)
assert source_before==source_after
assert copy_before==copy_after
write(art/'freeze-author-guard.json',{'producer':'actual_independent_author_freeze_file_guard','original_author_before_after_equal':True,'source_copies_before_after_equal':True,'source_names':author_names,'captured_ns':time.time_ns(),'old_preflight_historical_guard_claimed':False,'real_model_calls':0,'paid_calls':0})
print(json.dumps({'draft_finalized':True,'files':len([p for p in pack.rglob('*') if p.is_file()]),'old_author_guard':True,'copy_guard':True}))
