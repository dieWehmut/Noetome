from pathlib import Path
import hashlib,json,re,zipfile,time,os
repo=Path('/home/lyinn/project/Noetome'); pack=repo/'fixtures/run-api-budget-v1'; art=repo/'.artifacts/b07-t02-author-freeze-20261107'
checks=[]
def check(name,condition):
 checks.append({'check':name,'passed':bool(condition)})
 if not condition: raise AssertionError(name)
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes())
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def dump(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
pins=read(pack/'source-pins.json')
for relative,p in pins['original_sources'].items():
 b=(pack/relative).read_bytes(); old=(repo/p['source_path']).read_bytes()
 check('raw author '+relative,b==old and sha(b)==p['sha256'] and len(b)==p['byte_length'])
 check('before-after inventory '+relative,read(art/'source-copy-before.json')[Path(relative).name]==read(art/'source-copy-after.json')[Path(relative).name])
check('original author before-after inventory',read(art/'original-author-before.json')==read(art/'original-author-after.json'))
cli=repo/pins['old_cli']['path']; check('actual selected old ELF',filehash(cli)==pins['old_cli']['sha256'] and cli.stat().st_size==pins['old_cli']['byte_length'])
check('copied original old build receipt',sha((pack/'originals/core05-build-actual.json').read_bytes())==pins['old_cli']['build_receipt_sha256'] and (pack/'originals/core05-build-actual.json').read_bytes()==(repo/'.artifacts/b07-t01-linux-build-05-20261107/actual.json').read_bytes())
archive=pins['old_cli']['source_archive']; check('actual old source archive SHA',filehash(repo/archive['original_path'])==archive['sha256'] and (repo/archive['original_path']).stat().st_size==archive['byte_length'])
bodya=(pack/'originals/core05-request-body-a.json').read_bytes(); bodyb=(pack/'originals/core05-request-body-b.json').read_bytes()
check('two actual old body lengths',len(bodya)==len(bodyb)==5238)
window=read(pack/'request-binding-windows.json'); inputa=json.loads(read(pack/'originals/core05-request-body-a.json')['input']); inputb=json.loads(read(pack/'originals/core05-request-body-b.json')['input'])
for path in window['allowed_decoded_input_uuid_paths']:
 parts=path.lstrip('/').split('/'); a=inputa; b=inputb
 for part in parts[:-1]:
  a=a[int(part)] if isinstance(a,list) else a[part]; b=b[int(part)] if isinstance(b,list) else b[part]
 key=int(parts[-1]) if isinstance(a,list) else parts[-1]
 check('36-byte UUID binding '+path,bool(re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',a[key])) and bool(re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',b[key])))
 a[key]=b[key]='<actual-uuid36>'
check('all decoded input immutable outside windows',inputa==inputb)
outera=json.loads(bodya); outerb=json.loads(bodyb); outera['input']=outerb['input']='<decoded-input-binding-windows>'
check('all other outer fields identical',outera==outerb)
check('independent reservation arithmetic',len(bodya)+1024==6262 and len(bodya)+1024+outera['max_output_tokens']==8310 and 8310+699==9009 and 9009-700==8309)
pre=read(pack/'originals/preflight-actual.json')
check('old preflight actual four commands',len(pre['commands'])==4 and [x['exit_code'] for x in pre['commands']]==[0,0,3,3])
for i,cmd in enumerate(pre['commands'],1):
 root=pack/'originals/preflight-commands'/f'{i:03}'
 check('preflight raw receipt '+str(i),read(root/'receipt.json')==cmd and cmd['pid']>0 and cmd['finished_ns']>=cmd['started_ns'] and sha((root/'stdout.bin').read_bytes())==cmd['stdout_sha256'] and sha((root/'stderr.bin').read_bytes())==cmd['stderr_sha256'])
for letter in ['a','b']:
 report=read(pack/'originals'/f'preflight-api-{letter}'/'validation.json')
 check('actual zero HTTP report '+letter,report['network_attempts']==0 and report['real_model_calls']==0 and report['paid_calls']==0)
check('zero request config',(read(pack/'originals/zero-budget-api-config.json')['budget']['max_requests'])==0)
api=read(pack/'policies/single-request-api-template.json'); zero=read(pack/'originals/zero-budget-api-config.json'); api['budget']['max_requests']=0; api['limits']['timeout_ms']=3000
check('single-request config only permitted changes',api==zero)
auth=read(pack/'policies/authority-template.json'); opening=read(pack/'policies/authority-opening-template.json')
for name,a in [('zero',auth),('opening',opening)]:
 check('authority exact top keys '+name,set(a)=={'schema_version','producer','global_budget','opening'} and a['schema_version']==1 and a['producer']=='synthetic_api_budget')
 check('authority exact limit keys '+name,set(a['global_budget'])=={'max_requests','max_total_tokens','max_cost_usd'} and a['global_budget']['max_cost_usd'] is None)
 check('authority exact opening keys '+name,set(a['opening'])=={'accounted_tokens','held_tokens','dispatched_requests','held_requests'} and all(type(v) is int and 0<=v<=2**64-1 for v in a['opening'].values()))
check('opening reserves legal literal near cap',opening['opening']['accounted_tokens']==700 and opening['opening']['dispatched_requests']==1 and opening['global_budget']['max_total_tokens']==9009)
run=read(pack/'policies/run-template.json')
check('Run exact top keys',set(run)=={'schema_version','producer','run_budget','concurrency','max_elapsed_ms','retry','units'} and run['schema_version']==1 and run['producer']=='synthetic_api_run')
check('Run ranges',run['concurrency'] in [1,2] and 1<=run['max_elapsed_ms']<=60000 and 1<=run['retry']['base_delay_ms']<=5000 and run['retry']['base_delay_ms']<=run['retry']['max_delay_ms']<=10000)
for u in run['units']:
 check('unit exact keys '+u['unit_id'],set(u)=={'unit_id','project','import_id','api_config','max_attempts','max_retry_tokens','max_elapsed_ms'} and bool(re.fullmatch(r'[A-Za-z0-9_-]{1,32}',u['unit_id'])) and 1<=u['max_attempts']<=4 and 1<=u['max_elapsed_ms']<=run['max_elapsed_ms'] and type(u['max_retry_tokens']) is int and u['max_retry_tokens']>=0 and u['project'].startswith('/') and u['api_config'].startswith('/'))
wire=(pack/'wire/fixed-200-invalid-candidate.bin').read_bytes(); w=json.loads(wire); use=w['usage']
check('fixed valid wire known700 invalid candidate',w['status']=='completed' and use['input_tokens']==100 and use['output_tokens']==600 and use['total_tokens']==700 and w['output'][0]['content'][0]['text']=='{}')
cases=read(pack/'cases.json')['cases']; check('exact14 unique core cases',len(cases)==14 and len({c['case_id'] for c in cases})==14)
for c in cases:
 e=c['expected']; check('author arithmetic '+c['case_id'],e['unknown_commitment_tokens']==e['unknown_commitment_attempts']*8310 and e['total_committed_tokens']==e['known_tokens']+e['unknown_commitment_tokens'])
 check('synthetic boundaries '+c['case_id'],e['real_model_calls']==e['paid_calls']==0 and e['price_usd'] is None and e['published'] is False and e['scientific_quality']=='not_run')
 for u in c['units']:
  check('actual unit references '+c['case_id']+'/'+u,u in ['unit-a','unit-b'])
 for u in e.get('candidate_validated_units',[])+e['isolated_failed_units']:
  check('expected unit actual names '+c['case_id']+'/'+u,u in ['unit-a','unit-b'])
 if c['case_id'].startswith('global-'):
  check('global distinct real Run layout '+c['case_id'],len(set(c['execution_layout']['unit_to_run'].values()))==2)
 if c['case_id'].startswith('run-'):
  check('Run same real Run layout '+c['case_id'],len(set(c['execution_layout']['unit_to_run'].values()))==1)
 if c['case_id']=='same-response-sha-different-attempts': check('fixed sameSHA binds raw original',e['same_response_sha256']==sha(wire) and e['known_tokens']==1400)
pol=read(pack/'policies/author-policy.json')
check('five unchanged retryable classes',pol['retry']['retryable']==['EXTRACT_API_HTTP_RATE_LIMIT','EXTRACT_API_HTTP_SERVER','EXTRACT_TIMEOUT','EXTRACT_API_TRANSPORT','EXTRACT_API_TRUNCATED'])
check('explicit interruption separate class',pol['interrupted_process_recovery']['classification']=='REQUEST_INTERRUPTED' and pol['interrupted_process_recovery']['entry']=='explicit ordinary resume only' and pol['interrupted_process_recovery']['not_ordinary_retryable_report_class'] is True)
files={p.relative_to(pack).as_posix():{'sha256':sha(p.read_bytes()),'byte_length':p.stat().st_size} for p in sorted(pack.rglob('*')) if p.is_file() and p.name!='frozen-sha256.json'}
check('all package JSON decodes',all(read(pack/p) is not None for p in files if p.endswith('.json')))
manifest={'schema_version':1,'producer':'independent_fixture_author_freeze','workflow_id':'run-api-budget-v1','case_count':14,'request_reservation_tokens':8310,'files':files,'excluded':['frozen-sha256.json'],'new_product_implementation_tests':'not_run'}
dump(pack/'frozen-sha256.json',manifest)
freeze_sha=sha((pack/'frozen-sha256.json').read_bytes())
for p,v in files.items(): check('frozen member readback '+p,sha((pack/p).read_bytes())==v['sha256'] and (pack/p).stat().st_size==v['byte_length'])
result={'status':'passed','producer':'independent_author_integrity_and_freeze_check','checks':checks,'check_count':len(checks),'freeze_manifest':'fixtures/run-api-budget-v1/frozen-sha256.json','freeze_sha256':freeze_sha,'frozen_member_count':len(files),'core_case_count':len(cases),'parameter_variant_count':sum(len(c['variants']) for c in cases),'old_cli_preflight_commands':4,'old_cli_preflight_HTTP':0,'first_wrapper_failed_after_init_commands':1,'new_feature_behavior_tests':'not_run','real_model_calls':0,'paid_calls':0,'historical_old_author_preflight_guard_claimed':False,'new_original_author_before_after_equal':True,'new_source_copies_before_after_equal':True,'created_ns':time.time_ns()}
dump(art/'actual.json',result)
print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
