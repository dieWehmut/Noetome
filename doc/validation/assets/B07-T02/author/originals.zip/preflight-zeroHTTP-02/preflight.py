from pathlib import Path
import sys,json,subprocess,time,hashlib,os,shutil
ROOT=Path("/home/lyinn/project/Noetome");BASE=ROOT/".artifacts/b07-t02-author-preflight-02-20261107";PACK=ROOT/"fixtures/run-api-budget-v1"
CLI=ROOT/".artifacts/b07-t01-linux-build-05-20261107/noetome"
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(CLI.read_bytes())=="e7194fa4f3bd530996c657f24f5870773a08ab25a1873d5b1fa4f4b5f55c8512"
env={k:v for k,v in os.environ.items() if k in {"PATH","LANG","LC_ALL","TMPDIR"}};env["NOETOME_TEST_CREDENTIAL"]="noetome-test-public-credential-never-real"
rows=[]
def call(args,expected):
 d=BASE/"commands"/f"{len(rows)+1:03d}";d.mkdir();begin=time.time_ns();p=subprocess.Popen([str(CLI),*map(str,args)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);stdout,stderr=p.communicate(timeout=60)
 (d/"stdout.bin").write_bytes(stdout);(d/"stderr.bin").write_bytes(stderr);row={"argv":[str(CLI),*map(str,args)],"pid":p.pid,"exit_code":p.returncode,"started_ns":begin,"finished_ns":time.time_ns(),"stdout_sha256":sha(stdout),"stderr_sha256":sha(stderr),"cli_sha256":sha(CLI.read_bytes()),"real_model_calls":0,"paid_calls":0};rows.append(row);(d/"receipt.json").write_text(json.dumps(row,indent=2)+"\n");assert p.returncode==expected,(args,stderr.decode());return None if args[0]=="project" else json.loads(stdout)
project=BASE/"project";call(["project","init",project],0);imported=call(["source","import",project,PACK/"source/source.txt"],0)
config={"schema_version":1,"provider":"openai_responses","transport_mode":"local_http_test","endpoint":"http://127.0.0.1:1/v1/responses","model":"noetome-test-model","credential_env":"NOETOME_TEST_CREDENTIAL","required_input":"text","capabilities":{"text":True,"structured_output":True,"vision":False},"selection":[{"kind":"text","ordinal":0}],"limits":{"max_units":1,"max_input_bytes":4096,"max_response_bytes":65536,"max_output_tokens":2048,"timeout_ms":3000},"budget":{"max_requests":0,"max_total_tokens":1048576,"max_cost_usd":None}}
cp=BASE/"zero-budget-api-config.json";cp.write_text(json.dumps(config,ensure_ascii=False,indent=2)+"\n")
bodies=[]
for name in ("a","b"):
 output=BASE/("api-prepared-"+name);report=call(["extract","api",project,imported["import_id"],cp,output],3);assert report["usage"]["network_attempts"]==0 and report["usage"]["real_model_calls"]==0 and report["usage"]["paid_calls"]==0 and report["usage"]["model_usage"] is None
 assert any(e["code"]=="EXTRACT_BUDGET_STOP" for e in report["errors"]),report["errors"]
 body=(output/"request-body.json").read_bytes();R=len(body)+1024+2048;assert report["usage"]["input_reserved_tokens"]==len(body)+1024 and report["usage"]["reserved_tokens"]==R
 bodies.append({"name":name,"file":str(output/"request-body.json"),"sha256":sha(body),"byte_length":len(body),"input_reserved_tokens":len(body)+1024,"reserved_tokens":R,"report_sha256":sha((output/"validation.json").read_bytes())});shutil.copy2(output/"request-body.json",PACK/"originals"/("core05-request-body-"+name+".json"))
assert bodies[0]["byte_length"]==bodies[1]["byte_length"]
rawa=json.loads((BASE/"api-prepared-a/request-body.json").read_bytes());rawb=json.loads((BASE/"api-prepared-b/request-body.json").read_bytes());ia=json.loads(rawa["input"]);ib=json.loads(rawb["input"]);assert ia["request_id"]!=ib["request_id"];ia["request_id"]=ib["request_id"];rawa["input"]=json.dumps(ia,ensure_ascii=False,separators=(",",":"));assert rawa==rawb
result={"status":"passed","producer":"independent_zero_http_old_core_request_preflight","cli_sha256":sha(CLI.read_bytes()),"cli_byte_length":CLI.stat().st_size,"cli_build_receipt_sha256":sha((ROOT/".artifacts/b07-t01-linux-build-05-20261107/actual.json").read_bytes()),"body_preflights":bodies,"commands":rows,"network_attempts":0,"real_model_calls":0,"paid_calls":0,"synthetic_credential_only":True,"real_credentials_or_ledgers_accessed":False,"maximum_requests_zero":True,"different_request_UUID_same_body_length":True,"source_author_files_unchanged":True};(BASE/"actual.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n");print(json.dumps({"status":"passed","request_bytes":bodies[0]["byte_length"],"R":bodies[0]["reserved_tokens"],"calls":len(rows),"actual_http":0}))
