from pathlib import Path
import json, os, subprocess, time

ROOT=Path('/home/lyinn/project/Noetome')
OUT=Path(__file__).resolve().parent
PAIR=ROOT/'.artifacts/b07-t02-linux-checked-retry-pair-01-20261107'
PYTHON='/tmp/noetome-b05-t03-python/bin/python'
argv=[PYTHON,'-B',str(ROOT/'scripts/verify_request_budget.py'),
      '--cli',str(PAIR/'noetome'),'--test-driver',str(PAIR/'request-test-driver'),
      '--build-receipt',str(PAIR/'actual.json'),'--full',
      '--new-root',str(ROOT/'.artifacts/b07-t02-request-linux-checked-retry-full-01-20261107')]
env={k:os.environ[k] for k in ('PATH','HOME','USER','LOGNAME','LANG','LC_ALL','TZ') if k in os.environ}
env.update(NOETOME_PDF_PYTHON=PYTHON,NOETOME_TEST_PYTHON=PYTHON,
           NO_PROXY='localhost,127.0.0.1',no_proxy='localhost,127.0.0.1')
started=time.time_ns()
with (OUT/'stdout.bin').open('xb') as stdout,(OUT/'stderr.bin').open('xb') as stderr:
    child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
    (OUT/'launch.json').write_text(json.dumps({'argv':argv,'operator_PID':os.getpid(),
        'PID':child.pid,'started_utc_ns':started,'environment_names':sorted(env)},indent=2)+'\n')
    code=child.wait()
actual={'argv':argv,'operator_PID':os.getpid(),'PID':child.pid,'exit_code':code,
        'actual_wait_closed':True,'started_utc_ns':started,'finished_utc_ns':time.time_ns(),
        'real_model_calls':0,'paid_calls':0}
(OUT/'actual.json').write_text(json.dumps(actual,indent=2)+'\n')
print(json.dumps(actual),flush=True)
raise SystemExit(code)
