# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "faf869515d1aedc272e161123ba5fc30d5520ee298de3c2b28512bad46d2088a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6d84b36350abf0bb965f2a6595c57d3f15d8083ee7423e3bf0efb5d087cc9b7e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "832228783d4dd7157d19d2049f03f085557a11c3583f6d62b87f9bab9022ac98"
    },
    "request.json": {
      "byte_length": 2255,
      "sha256": "4134c94a88ce32452d24f7479b12512ce0668fa2dd1740ba3085adc70d7d31ba"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b76e7e37973dc3070a46aa02c701087b85fd58efc0f6335714f584d51c2edf1f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3775ba78a8a5a358d7aa84a54b6e354ec002c070a9eb8864e238b2e4ebaefbd2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "852f7f00-d75c-4a4f-b14f-94344620dfba",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5723b2fe-d410-46ab-b2e3-05caef979274",
    "source_id": "1aa23403-b3da-4b61-a912-9f6c77b65185",
    "version_id": "1e968981-2d6e-4535-a31e-255b7cd1702e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37857/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c7d8d9a4-1b90-4643-a171-6f0ba51e0e06",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b76e7e37973dc3070a46aa02c701087b85fd58efc0f6335714f584d51c2edf1f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
