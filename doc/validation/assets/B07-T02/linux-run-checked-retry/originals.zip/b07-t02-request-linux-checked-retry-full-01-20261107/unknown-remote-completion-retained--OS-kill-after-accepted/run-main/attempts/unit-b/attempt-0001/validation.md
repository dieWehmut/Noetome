# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "00b8d7b4bd91ac696d1425fc88af38c556e4dfc39b47d293124fc6a9b067e0b0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7b7ee1b540f4a54c9d814265de5589defcc7973912c05d0bb482fad5a94c34d0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ed68518de05b2bf4c7e79c04ef7ed2f92e86e990743080db77a6888154d4e43f"
    },
    "request.json": {
      "byte_length": 2255,
      "sha256": "70c02dd7e0e27b4e8e7bacf09deed15b68bb7ff47f75e5204875f9541b3b4fe3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0929d49e64035417c7d167831a21b62925c1a4ac7a3384255322e4357ef2298b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "70e48685ffa064a7b928141deb03c63c954b75cb58690554eaa59dfbdf2f0043"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "57867ecf-a974-4894-bc19-f9ed03a4cf7c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6b89abb4-15b2-43ab-86c6-543396b4e98b",
    "source_id": "63a740c2-864d-41ef-9c8b-ab0f5b025caf",
    "version_id": "36e26317-e8a4-4995-83fc-87b3e3239d6b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37857/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "57dcdeff-7837-40fb-820f-8cbed07917e9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0929d49e64035417c7d167831a21b62925c1a4ac7a3384255322e4357ef2298b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
