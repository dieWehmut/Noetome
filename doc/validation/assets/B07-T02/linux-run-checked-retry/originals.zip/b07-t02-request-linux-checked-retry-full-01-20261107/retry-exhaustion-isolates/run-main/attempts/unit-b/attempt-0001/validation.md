# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "23a772e4e569860d590b027cb0a3e97a7475ce5b4b5188bb814de4b77adec767"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c6a10cbf6edac6f50d5be93440b8a0db2a795d14cc587c3c18ce5abb8b9d2fe8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "624b9bfaf973dbecbfafaccfbcda2876aad4bbfd5d2d4c8c215d9e83608f95f7"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "9790220ac2314c34f7c71a37d7ab295ab6177bb4a9a51162980ca8c39a4a1280"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "11b0f385aa458993f175ef7a0c455eafcd7fe79cb4ba0c39184cbb92e074ce65"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "14de499e03c47553827f8ba1a0adef43915cfbfc0b9f28b861f664dfd05a4910"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7980580e-5816-4e57-b00d-afcab7cd0f8f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f43b6429-5d21-4b01-81ba-2602f7f9c1dc",
    "source_id": "e0a43955-2f33-4eee-a32a-c9e6b697105c",
    "version_id": "9c1a962a-0278-43fd-ae5c-0ab8374f5858"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38431/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "18d7be9b-d628-4d6c-b20b-c8bfd737e231",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "11b0f385aa458993f175ef7a0c455eafcd7fe79cb4ba0c39184cbb92e074ce65"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
