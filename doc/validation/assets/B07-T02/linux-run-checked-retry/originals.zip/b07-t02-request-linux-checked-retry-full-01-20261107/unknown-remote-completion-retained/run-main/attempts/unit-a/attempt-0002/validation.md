# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "813aca3d567dc02a84cdc89fd9a869a4951f7f3f18b3f3dc03cfa091597e41c3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1432b87c06a73c32ef1a8e473d57e2a2b84dbbda659f71ca6fadfb9931f5291c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "21e4ebf06dc81cecbc108542162b954c2949fa47c94d73db873b3fa47a696b3b"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "eb928f74981bee541dd07e7c1162f8c1cbd17e72d2ef95734477caccfc7a7564"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e7766c587233cd97fc44f1e00a74f148963b89edab2df184908136e541fbfe45"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "14bb70695a32723761515a12e487cbf118b0c2762f5d2963aa8497132e35561b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "370c39bf-3687-4f1e-82de-3376b8d9a475",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "27f7501a-47e4-4c29-a248-cf2124c6fcd1",
    "source_id": "b12124ba-0a5c-4c23-a08b-7f13952febe1",
    "version_id": "d528ed0f-23f1-47c6-9369-6041f8bae3c4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38083/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e59db9be-8730-49cc-b140-bb7dffdd0e80",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e7766c587233cd97fc44f1e00a74f148963b89edab2df184908136e541fbfe45"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
