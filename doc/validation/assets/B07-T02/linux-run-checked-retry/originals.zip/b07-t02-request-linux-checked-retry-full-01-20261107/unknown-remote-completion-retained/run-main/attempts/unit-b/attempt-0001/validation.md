# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f66cb92560c4cf38fe5b81d1256fc2ae5126828ffcd1340c313050c3892df729"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5d929f03034d15f59a0eb87ce83d81f8c418fc66dd40eaf535b0022add0aa085"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3405f317d0969fcb35c93c580f540af8a04aec592c18cfbc566e149d3b63d6ac"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "bb89d91a217e9d4b240682b84dfafef492ba6ac24fecb030d029f936aa0d8f40"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "19675df484cdffc9d103dfa3e947aa05b7bbe71b02e1fe1ade447b1f9723d7c0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f77edf0cfcf751ff5ab98f839a93f37c4f6e33d56329888fdf830e9d7720a334"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bfc4e6ab-7752-4c5c-9091-a42615c6bd69",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fb63be4e-40d3-4d2b-ae80-8d5a91f2289b",
    "source_id": "de98d6ce-ff4c-4b99-9b5d-880e5f5b87fd",
    "version_id": "cddecce2-f436-42c3-9c7e-6880cad50e45"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38083/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "85089a4d-6be9-40a8-b497-ce3317949aaa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "19675df484cdffc9d103dfa3e947aa05b7bbe71b02e1fe1ade447b1f9723d7c0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
