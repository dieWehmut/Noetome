# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b1564186cc115da993ebc0dc47b46453b9087291b1e132c4e03a5cde9b985384"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "998c1cff0bc9c12a626eab2ae35577075caf22c91f3acf739bde08add71df33d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ae5d370e5eb50497e33e52559bcc80868703fc9e7feebdd14fdf737c1c89b03c"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "371131555ceb10c00980e6574572040c9178a2af2eb8c162ff77f650947ca0f3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fae47278dc4509649036e607014ff572759bbd92788218e82417e409bebcbc16"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d62f841b5f527628efab0f4684537af2ac9807ec33377e926bf685a81f30447d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a67cd53b-0bee-41af-8438-bf4d466b2520",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ebf63ac9-5ec2-4bd9-9ff2-a823f74a04ee",
    "source_id": "c50f2538-3c50-45bf-8405-5048cc974434",
    "version_id": "4d9f02e7-5c52-4e9c-9aa6-d8189c4d8823"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36811/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "44a739e7-2b8f-4c14-9a24-663b76571318",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fae47278dc4509649036e607014ff572759bbd92788218e82417e409bebcbc16"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
