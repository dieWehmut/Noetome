# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "be3d908f98be88b955638f6a3dbd5b799fd03cf20b32aa395c434577a03ebb73"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1adcca3cf822184eebaa37d06e71de0eb7fb7259f0831918f2eadabd93286625"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cef2d384f8347247d39e6e2e17816de111903e26e23c448ddc478c1813442cb9"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "ff00542668cc9ab0252aa76c9da385f2f6f075ae24cbf5583b981d1cad945f0f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c8f30bc469b02fe0aa216909770026b6b2ecfb4cec6eb63cd2f939c04433a67a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ef26d52b2a804fa6ee56ee7687ebea1da7a3ad324df11e68a3f5e72b1ff51326"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7aaf46d7-48d4-4239-9671-aba56d6f0093",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b0e18d34-86c4-40bb-88ef-6f97a99939c4",
    "source_id": "1dd7ebe5-a9ff-4a51-b35f-dcc549e1bd35",
    "version_id": "33d3447b-795b-45ee-bc08-b7602bc4826d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36691/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "838ab190-32ee-475b-bf1f-2c3973648f1c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c8f30bc469b02fe0aa216909770026b6b2ecfb4cec6eb63cd2f939c04433a67a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
