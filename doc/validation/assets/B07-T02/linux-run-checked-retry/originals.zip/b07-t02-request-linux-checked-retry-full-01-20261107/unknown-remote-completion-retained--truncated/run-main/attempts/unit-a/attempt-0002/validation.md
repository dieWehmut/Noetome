# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c32b1f1efa1f4379be1cad47ccac196bf0c1dda1607d4867df9f1ec281c5a482"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fed1ce63e167bb446a0f3848aa8543f703397ca948b12e05c0a0ba2f4e323509"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1c473dedccb2255cc8b753a45f618d9868b45ad24f4902525990b544dbe9c432"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "0cc0bed5f36005e57c8198d4bdb7f554a474fbf3cd147de208407631734f8963"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "edbbaddd8272502c6eebacaaeea47d128765aad4a83aa2e433b68d9ce3d31cb9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ecc128239354aeb3b678f180613810f95d28abd3ffa1da47cafc971fd5189a3a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "812cfa7f-bea2-4e9d-9f0b-b6560b6adb51",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76abc9e6-2eaf-418b-a816-d628c87972b5",
    "source_id": "6855245e-4479-4c1d-8aee-b2c83cffbedf",
    "version_id": "a867ccb5-533c-4b45-be47-1dbe1e537253"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36691/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4875a6c1-943b-4e36-9c99-8b293359b6b5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "edbbaddd8272502c6eebacaaeea47d128765aad4a83aa2e433b68d9ce3d31cb9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
