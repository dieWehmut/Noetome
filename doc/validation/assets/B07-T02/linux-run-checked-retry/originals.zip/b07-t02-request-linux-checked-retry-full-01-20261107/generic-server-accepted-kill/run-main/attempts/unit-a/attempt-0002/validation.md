# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3764e07eed8e0251a36245e6e8a1e42c935f20bb39f0052723fd35158abb440b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1eba0ca1661b72c58a64153e5030eaa416a8d9f13cb8c8a88bd182502dbad6c7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6988c4ad7e6f791b05cc603b7edc8ce93c40418fcd9e6a410dd2cb515afe9312"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "dba32a2562ee80bf098f6344ee5009b59e220c1a4b33fa925ac655472dd2d8e6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d5cae7195a2140a5015886b31478d9a8ebe846483d518af6a929f995494f8f75"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e6605baa63d92151bd15f1fff36ee4e57e7465e2b39df7f5149d4d508c64bf36"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2cd2ca7a-6f7a-4116-81d6-443f254e351e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ca57fa95-cd7a-470f-a099-3620984a99ee",
    "source_id": "c4eee5d2-1687-42c3-9925-229c25cace12",
    "version_id": "4d587a78-aa0d-4851-b2cd-080121bc2b3d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37795/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6f63125e-0e78-4592-924c-c5c04dca1dfa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d5cae7195a2140a5015886b31478d9a8ebe846483d518af6a929f995494f8f75"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
