# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "900a21979ffdda7cf773d40f9e745b452661dc5e1ce90ec6ed5a193de3a87305"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "528e049ffc9e929b8c51708912ac2365cb580995b5553448288bcc60cd5df9d2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c7d6a95eda26672f7804b1ea6cc9598497e07add4237b8cc7376579c97b683d1"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "b88f790360801aaba846aac77d4c5cf06f8620012e73ee664ff2a22e421de3b7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9ca0358ff926c6ef49ccc8d7b4d3f675bd808ce2dea083eb959702a00a436120"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "dd8e776cded7fe162b36035550479895e129cb65564b692cb0ec91e129b7b098"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d2210791-ba9e-480e-8f33-65839b21b7ef",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8231f8a4-4548-4d17-a00e-c453b1a820a9",
    "source_id": "e7aa7107-50c0-4b4b-8b20-c660ad1dc9fd",
    "version_id": "921e083f-0686-42a0-9d80-8d411f3c6c49"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36977/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "289908a4-975e-4897-83c6-d3c384564312",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9ca0358ff926c6ef49ccc8d7b4d3f675bd808ce2dea083eb959702a00a436120"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
