# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fd0213a8a7d2361cf5b45a627c5aa951f518a7860eefa2c2fa3e6187d441f9d8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4f0f53a33873272da4a65b90421bf4ce5790986779d49456d1bd2da4ef52c047"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6eeed1efad85a3bb0c61c3fb1eff8734db1be261b6c102d35e7955d50e3bd0f0"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "29eeaa38656aa0dcfe74235ba6f0ca3fe5f2617baa67ce03fc2b12e4d5af6070"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e4125c42ea29618ef0dbe654f5923ff5c92290a7bb64b1ccc38905fd739fe771"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "dd4c1fc649624d5822c6a46b654ab649c826d264b1241b09bfc0c6b31c58c834"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4be69ec5-5363-4e0e-ab1a-9efbf8e49b8f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a1d468f7-2da9-4b0d-922b-3300feaf0002",
    "source_id": "09699ba4-d170-428a-87ba-db857ae2387c",
    "version_id": "519f0a88-39ff-4605-bb2a-5c8697c0feb3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36651/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ada11c0a-e0e5-4cc4-99fc-d9b9132c14ee",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e4125c42ea29618ef0dbe654f5923ff5c92290a7bb64b1ccc38905fd739fe771"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
