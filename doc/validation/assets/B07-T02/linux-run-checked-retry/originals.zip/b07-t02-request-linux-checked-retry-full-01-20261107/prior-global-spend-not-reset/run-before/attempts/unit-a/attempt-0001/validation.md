# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6310fa560ac501cfdc0b21377393bee0983fa82c8d395cdcb47852374f37abf3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f1a0a4603126e168dbb734212186d64c681b0b9f5814bcc663cd586dfdc5b660"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8c43075ce43adce65554f00cf308d75dd2eefe55d9ec10b4f684ff02f6964c08"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "2709cc30db696675c39213005d42fdfc7f1b013386e8b76b238ffcb984bf1004"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7062781d81b4865da8ecb341b36ee88d6b0fbd641b66737176d69c5222417cec"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3a076c6a249d76d5d52418937c95c84fd4783daf8cd5675dbab23ab1d794c6ca"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "195048bc-d05a-438d-9132-f766390fd759",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7ddbd6e0-4293-454b-83ed-77cfe0564c5b",
    "source_id": "73de2d2d-a647-440a-b26c-e9605b78d9f1",
    "version_id": "d2daaa8b-0664-4c1d-b8f3-d1b1dc7017fb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36877/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1b44aaca-b348-4457-949a-60bd4751cdd9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7062781d81b4865da8ecb341b36ee88d6b0fbd641b66737176d69c5222417cec"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
