# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "13eb5d5140cbfa993b25665b348a1d4c0f64e95de577b615b99c2c5689fdb9c3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "51f9c28902a6b7cf3ca2636543229cae7f90b9abed6a9814429cb83c2f329ea4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d08d5571db39111b6f8fd7244fc9455f9328953337f2e7aa55d18a9c2ed1f287"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "8fc2f0212c876ceb9f1dcd48928cb30089cb9f2b615c438f6bf3f81991175bc8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3c2f5d978c705cbe39074445efb26d10dd63e1d5de3266ce959bd0c055bb8871"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4876b36daa2c40ce3bbc2bcd9b6134450970a36b2f4510c24449e2d3c2246b08"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "da22985a-fd6b-483f-a9f9-f58cc246afeb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "eaef64fe-345f-4329-b7c3-deca73210269",
    "source_id": "b31c23f3-f180-4eb7-bcc0-6ae9c350c9d3",
    "version_id": "9d057e80-7def-4c98-801b-14326faf1f41"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36569/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d59f186d-d0a1-485f-b7f3-9644edbd2681",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3c2f5d978c705cbe39074445efb26d10dd63e1d5de3266ce959bd0c055bb8871"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
