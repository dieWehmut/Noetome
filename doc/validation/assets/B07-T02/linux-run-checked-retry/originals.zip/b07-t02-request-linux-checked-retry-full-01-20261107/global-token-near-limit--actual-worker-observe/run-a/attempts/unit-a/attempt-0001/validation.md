# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2f77d03f38ac1e9cbe1690b128e41fc2e0ae5033423390d7671e813ac84462be"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "16a1ed6e1e134d3a0aad3ab755231d9edf11c01d9c51be2baaf8e0150c014a33"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3365e927d21210b658e3ed1a1aa3fa512ee4a240a7540faec9d85fc4e5d409a4"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "090c4d7ad6e0eb82237af12a874a19e0aa0de7634f078e10debbca22b01e19ee"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "123a8af6bc838dc597786a5c89dc89b8a27c07c849c0c9a4caf78e68b3560caf"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "dec8b83fcddb57fe44738900c07cc9e7b47db7067e9c096c578c1c145fa6485b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5f3c3c3b-4466-4371-bb07-b2bb1b0ef920",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c4d411fe-91b6-4873-9288-95c0b6940447",
    "source_id": "ce316d0c-29fd-46a5-b7e6-6d7f92aa79cc",
    "version_id": "164590cf-ecce-41da-b928-3f2f3a6ca561"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38179/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "48854ead-224b-4554-bdbb-c64fdf892122",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "123a8af6bc838dc597786a5c89dc89b8a27c07c849c0c9a4caf78e68b3560caf"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
