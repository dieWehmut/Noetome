# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "967fba09e3be706e265cf4637ddfd68f34fe34215ddbdc0d3ba814e4f31bf21b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d063e7f8c4972f2f935bb1c2c7c3fdebdab2eb6cfa99e5db450eaf345adbbed3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "99bde04c559c1f3b4b2ac89ed22eff4e5c08ca51d95a14aef659e505fe32b506"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "8da8c81322766c6a739d7b77c1fb788f3380b9ec91431fa33b85b335c05d483d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0f073f2e52713a68e3dee9a1e517645ae774dd6b30dffb208d5bef371753abb4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2b644eb2489136cc6ba6ad789c2fa85233d9a4db47177175090c748c24c51697"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2ca84991-f934-43f8-8488-ec5ab8cd30f8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "39d2ad09-4a0c-484a-b325-3c5942858a11",
    "source_id": "726f3394-5550-4c5d-9b3c-10800c00d959",
    "version_id": "5c1b5c56-8105-4a18-b04b-fdaa2611b093"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37869/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "302d13f1-7440-4e45-86ba-3c5b3708bd5f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0f073f2e52713a68e3dee9a1e517645ae774dd6b30dffb208d5bef371753abb4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
