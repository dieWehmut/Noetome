# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "719ea17ec28d0bdb04d5167a3a15fc78b5c6fc62abb856f37a408125468604fe"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d2ac71fd3e0d6f521edbafc415870658d85ea20cf6566a3995b9ea36f0685120"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d05d7cc5c5a0ff462fe237f32fd94e75dbb11d07e79e65d491415edb7c56e739"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "8c6dc670fd2c4bb6755411d6845396844c9154e2324d740172f3cc23ae5b1f48"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6c03943808226738050a601a7aa229388c3539139c1039767994d2ec9cea635a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bc789ab5d352837a3afdbafe7b73a241b199bd75d4359f453c305fed9c49fb96"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e5a8c0ed-5975-450b-8b2c-1e7268149b65",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "89682747-674e-41ca-b457-8a8b88fcbef9",
    "source_id": "18035837-1d66-4c3b-9d86-687c157e8d7e",
    "version_id": "a570947c-fe8c-4db1-b734-aa80b5b5fd17"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37399/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "012c7bad-a8a6-4ee8-a852-04f09dce95a3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6c03943808226738050a601a7aa229388c3539139c1039767994d2ec9cea635a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
