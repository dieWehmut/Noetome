# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1fb1543177c620ac42b9fdca7af5719b70e3524caa97e2d4e3b4635774c8fe8f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dba399aec8e078c5a1ce2cb4fc1e201a392d286de00d6cbcb24044cbb8f31218"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "784660591b9f101f264fb1abf2be4cba9892746fb2375962e0b13886566feb45"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 482,
      "sha256": "fb50dee362c86ce93b32bc9a524383cb4406d808d70dbf66a96efa7cb0cac67b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e5a8c0ed-5975-450b-8b2c-1e7268149b65",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "89682747-674e-41ca-b457-8a8b88fcbef9",
    "source_id": "18035837-1d66-4c3b-9d86-687c157e8d7e",
    "version_id": "a570947c-fe8c-4db1-b734-aa80b5b5fd17"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37399/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRANSPORT",
      "message": "EXTRACT_API_TRANSPORT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a5f3da1e-17a0-4a66-b92a-af98344fb633",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
