# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "30ca1e45731ec591ad362f227ec3a82053a442c71056f6aa175e3e0d7b4cf1c3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "554a04021e905077c9495ab333af3ae641fcae8825c3d25335a4eb9401f6c15a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "55ff76de6eb41a8e5dcad2a6c239d30336b88256f34112e1bfe855503e2d8d87"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "a7894dba87b8e289aac2b0b46ef0b609ba47218f491f0f33bfed771af25df122"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a2f89df0eeafb7c120d912b7119125cde22b5be76a494496452c3807867293f3"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1b4e5cd155dcab795882194f8523c966036a2cc41835e58d134d5ab058187a89"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ca8e0965-1ad5-4475-845e-c800a269d845",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "664292d0-0194-4ae5-a4c4-5d2e3a07e37f",
    "source_id": "08035b30-9550-493c-99c8-963ba7fba471",
    "version_id": "0ddb325e-c8d5-4fb8-b284-b6459ca04c9e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37399/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b57e9097-1747-4059-8bca-3e9dbbf54fd9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a2f89df0eeafb7c120d912b7119125cde22b5be76a494496452c3807867293f3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
