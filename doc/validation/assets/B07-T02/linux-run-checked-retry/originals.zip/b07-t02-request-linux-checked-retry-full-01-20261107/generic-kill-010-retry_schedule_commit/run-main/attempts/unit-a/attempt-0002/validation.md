# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "30dc841a12546c53b9bbf8a3974e69198f5dd559ff350648593a66f9e7d2fd2c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "efa5c0421d9934ad8bfdb516933b546a780e9682be049d95fec398bdf0d40416"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6985c94a3a28273164df24853a803de125ec98a6df112c5707494193b876d847"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "fbe30d3ca08d50b7bee06abbdc7b28a4e2b9cf207ba19dae89f069a2f35f6130"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2929792879373fd58db1b5b01bd9110de4b9f4db645ac0d62628deeab7e96abe"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3585d49a5c881cda8282781d8d3465586ec9d8b98d0c47342c569c160c1d8b45"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2abce1aa-4254-451d-8050-3becdaf5f4ee",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8e9711c3-87e1-4fc1-9c04-3999ae396877",
    "source_id": "33d43bbc-7eb2-4f1e-8bb1-a8670675d1eb",
    "version_id": "6f13674c-6c33-4235-8417-b3302ca3c802"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38239/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4c1465c2-1bf5-4b8a-8f99-ef4e9a6e58c0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2929792879373fd58db1b5b01bd9110de4b9f4db645ac0d62628deeab7e96abe"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
