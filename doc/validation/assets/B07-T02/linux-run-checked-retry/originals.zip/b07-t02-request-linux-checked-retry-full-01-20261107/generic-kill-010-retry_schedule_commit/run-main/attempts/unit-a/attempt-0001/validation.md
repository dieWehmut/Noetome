# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0fbf0a7e92f7c521dded5645e4ec1cebbec0803260e46417d8666447d0b716ef"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "97d64853c9293ec597c1a4a37f1886c69a17d6f94958f9b07108abead9ff35df"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "edc594e0b10840de9c541081f0aae1fe45d97ae01ff60a5f6a945278659de372"
    },
    "response.bin": {
      "byte_length": 122,
      "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
    },
    "transport-receipt.json": {
      "byte_length": 502,
      "sha256": "b17f20fe76d4b7096e04a9c19a14e173cc0abe9dfd7e64f75b45d16d8d4065b5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2abce1aa-4254-451d-8050-3becdaf5f4ee",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8e9711c3-87e1-4fc1-9c04-3999ae396877",
    "source_id": "33d43bbc-7eb2-4f1e-8bb1-a8670675d1eb",
    "version_id": "6f13674c-6c33-4235-8417-b3302ca3c802"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38239/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "702055b3-e7ca-43bc-963b-d5e9ebff5fe8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 122,
    "omission_reason": null,
    "sha256": "209f154516f694aefbde1d8d7a4b2c8bb8f879da7d65380da947c6ef8daa4cbd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
