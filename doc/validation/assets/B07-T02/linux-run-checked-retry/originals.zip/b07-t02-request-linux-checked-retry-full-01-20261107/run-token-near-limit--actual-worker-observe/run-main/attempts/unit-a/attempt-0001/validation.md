# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "166c4ad3b7d840de4915d7dd51851036f9ba61b890329390a010fc03e715083d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a8c855aab6f231a68d0acb70b8fae98290b53847bde3f0d8de9326570418d3b9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f093c8cc02f34569680a1f157cbb0751d3f810bdc65e7960c2a198c50a82c254"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "fadc0c1be02b4b8da9dba3d6bfa3e6373d66dc7c9becde83bbde47e84fe86d19"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f8a692c16725fd5a892927f09e5b47e007650b7829f1b30409f54ce3b4537eb1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ad5dce2ddd7b486f0ed9145d73b58be6c2412e845918adae80e471dfdb17adcc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4ee343d6-9e42-49d4-b192-30f2f239c762",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "04d7eaae-34d0-405e-9c80-d4f6757ba7a8",
    "source_id": "966f564e-4f3b-4996-aabd-68028143239a",
    "version_id": "3430f9c5-52fc-4399-b6f0-8db504ca8d6d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37127/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "83298406-74f0-48b2-ba1c-f1b0466e6382",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f8a692c16725fd5a892927f09e5b47e007650b7829f1b30409f54ce3b4537eb1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
