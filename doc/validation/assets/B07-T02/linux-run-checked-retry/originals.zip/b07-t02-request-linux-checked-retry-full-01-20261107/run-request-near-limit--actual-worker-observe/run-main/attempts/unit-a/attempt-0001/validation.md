# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6c8c1a8186411aca8012389983b7002a18a60abed93e6e4cecb8e6213fac3d8b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "96df21715bb508c3ca843f1156d2604fbcfbc0c1064c31317688d62142fa77a7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "70cd99c44361ffc2ca44fe007b06be5de61c9ddc810a47d77edd6963d32a8e10"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "ceac3af8398aa32a681765841f22f5df022f01400a9abfa23bee94fd3cb65f1a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "af33a8ad2b93e42a03d1130fd2a8514c9f3fe6a88254595846c27058283f23ba"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "809f689d9a0cecd3ae33e0115f2705651a516dcc0749c1a05c89c24c53f0ce5f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2d1c052b-712f-4f75-bbc5-248fa856361d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bd8af625-cd71-4605-b03e-36ca9c04a9f1",
    "source_id": "e34d6eb8-75dc-42bd-a57f-4854a25b4e28",
    "version_id": "f29a0778-46f2-4584-a491-074d08799704"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36839/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "adde5941-4a2a-4fa0-a5b4-3229439e73dd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "af33a8ad2b93e42a03d1130fd2a8514c9f3fe6a88254595846c27058283f23ba"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
