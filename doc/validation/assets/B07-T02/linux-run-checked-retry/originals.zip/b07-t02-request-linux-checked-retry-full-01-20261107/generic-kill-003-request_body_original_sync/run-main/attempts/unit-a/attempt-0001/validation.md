# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b0534d3d32f5cfdd072d0f2e30d178ec4e78229fe7bee335024aea69242b436b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8c5d49d1ee2c6b4b3c8a0dd6d2aabae94f8805b4bbe720a056794cee6461410c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4650359573a679e40959476892f0e896d5d6535a1b37717eafbe3b1b7f7ec700"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "9decd8edfae30ddc96549d3709590ec2744fdad4a0d4c6df1b9c30adb02edb85"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "61f7c14af7b899553ab7440fb185f6cd848c24c28956e6ca57ea82783a010a6f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "50d084f8e0e23421c9016ef956f20d58a59587e53ed3e61eebaccc77e9ed7f05"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7f366163-981d-46d2-a624-933d64114954",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "49053867-90a1-4c67-8545-a96a32b6f4bc",
    "source_id": "11fb15bf-6cc4-4079-8c8a-a2aebbc3bfd6",
    "version_id": "edd30912-5367-4afa-84fc-393eb9488a57"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36871/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cd4aa0e7-33a8-4154-98fe-063fb559c31c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "61f7c14af7b899553ab7440fb185f6cd848c24c28956e6ca57ea82783a010a6f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
