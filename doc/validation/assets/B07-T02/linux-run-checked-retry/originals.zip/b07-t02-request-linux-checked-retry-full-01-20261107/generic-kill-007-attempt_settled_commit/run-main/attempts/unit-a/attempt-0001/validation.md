# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e9a8b7a7c1231ed37cfeeaa47adc55e2f7802596385736b7b1b2c8ec50370b11"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "aed477d06ed49aff982bc8982babecc028cc3a6d162664ed2240d116ac061b7c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b462f55a407a3713272fdbaddba7361d40a52bc075824b7d5987707c258d817a"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "975a6f79b8910b32923595d88d48432626a2d7b49d9f9ee5f40a510ac7c4d268"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fd3454eb0e540f25ec1ad13c087ce08ce0edef2a22da68885f8f1be4b7fb71c6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "74ae284d12590874b33f3c4128f6781f2867737e3a3fff04d04ac93ae1caa1e7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d2a6abe8-fdeb-4a07-9307-ac1e4589f234",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0f09d53c-0508-4e60-9e17-b82eb2aaab46",
    "source_id": "ddddc62c-c67d-45ac-aa4d-4a8b7bca83b6",
    "version_id": "28dda418-844a-45a9-84d1-749e7b82c6af"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37059/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "684f1038-cebd-4e2c-b062-dba12af13ac7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fd3454eb0e540f25ec1ad13c087ce08ce0edef2a22da68885f8f1be4b7fb71c6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
