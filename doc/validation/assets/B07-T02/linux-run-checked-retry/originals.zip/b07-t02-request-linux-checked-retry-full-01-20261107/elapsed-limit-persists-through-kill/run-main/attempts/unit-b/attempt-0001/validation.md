# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d5b1be7d7c76491ba3c898d423b5f423ed415f6658b2cc64a5a29ee6f1240ff7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b399024fcabf6f309dc4f467b4dcf1f9bba4844f1b395075939819370b346f5a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b1459bce92e54f0fa81f3d4bfef06ce30e7f7310742e4ac41a9fd766926355c6"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "d9021144f1f7826652de41740b00e67396da96cf863f2e3b01fc1c184d5fbc02"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5701b59233e8c123993e52ba53fa0c022f1ee2ab2ef31df47b3576558204aefc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d6329126bda2641162b07d6c57ffe0b6b4372697c187982b5b6d80ff29b975fe"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "736df034-1349-41c0-b0c3-d26b0fb570f9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c258af44-cf09-455c-a472-a5a9e7a8a5ca",
    "source_id": "cc039626-582d-4582-a5e0-7ea717740b24",
    "version_id": "c8421bb0-f565-4105-a4fd-de5932e44011"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37305/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "96ffff44-b94e-410d-97b6-7698b1dc7805",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5701b59233e8c123993e52ba53fa0c022f1ee2ab2ef31df47b3576558204aefc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
