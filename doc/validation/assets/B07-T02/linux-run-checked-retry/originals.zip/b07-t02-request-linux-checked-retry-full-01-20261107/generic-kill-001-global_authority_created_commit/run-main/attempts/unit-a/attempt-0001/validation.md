# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "797826d3ba5ad936869e21b2e4fd94b5b421c2c70c78b25814c8bf35692d377f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "decf522e636fea4633fb846ec6f09f2babb1352f1c041681567bef32fa2b3757"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "602a257da803c6f3c457a2a2d4e74c50cf614c2cb50e27a74e1cc4e1a35f06bf"
    },
    "request.json": {
      "byte_length": 2245,
      "sha256": "c558bad8f607c1cf15d7b7369c10ad0266ada87ca8c9e64c30c630b502ce6a83"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bbd1db5184f3b4f33c7d5058511a4916c4aba287c13d30eb5c3ad1410dd9045e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "19707e72fdfb4ee41df604fd053a0fec36cd120bf4c56f024b0c5f6a3b501db9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "135ed7f0-9d5c-4c84-9696-b25912a4d086",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e826e5c3-5dcc-444b-8da2-f25b0550069a",
    "source_id": "75ee9bb6-32c1-43aa-b172-28e4120b7adf",
    "version_id": "58b27f9e-96a8-44bc-ae52-17471c965f86"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37047/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dbc9d9f4-dbef-45fc-a06c-fc42c6557cef",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bbd1db5184f3b4f33c7d5058511a4916c4aba287c13d30eb5c3ad1410dd9045e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
