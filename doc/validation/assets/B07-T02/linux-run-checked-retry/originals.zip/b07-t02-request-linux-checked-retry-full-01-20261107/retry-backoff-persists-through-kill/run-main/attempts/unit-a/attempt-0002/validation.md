# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4290d90543b1e45712e543c53c2d2da09a17ed0d17194b31eeab77e55d1d6c92"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1eec932f085a112d90b3ca91086f5ed538aa022307588d3973c09c2b3d37fc18"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d8d8f53bb39b3ed1c0249b45d9ca54153d0a15b57c6e580317ed03b0f6923ad5"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "9b6912e8b1fc0e068f3be8a6c85c561368c3938b9df646f8bb37e45171381dd5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bfdf49738d0d9e7289c8591471087d53a6b92df7545b260a422734b3afe8b41b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "864e817334e9fe51977bc3d2079e84844b90239817110a206db852b4bf8cb8a6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "17568a84-71fd-46be-9f11-52accadfe19e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4baeba68-98ed-49af-a559-b38061d69cf3",
    "source_id": "354f077b-a9ff-48e1-a52b-5ec48063b6e4",
    "version_id": "3d821682-abea-48da-9913-86ef84568f2d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37921/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0e692bf5-a66d-4852-b431-05e69580335f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bfdf49738d0d9e7289c8591471087d53a6b92df7545b260a422734b3afe8b41b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
