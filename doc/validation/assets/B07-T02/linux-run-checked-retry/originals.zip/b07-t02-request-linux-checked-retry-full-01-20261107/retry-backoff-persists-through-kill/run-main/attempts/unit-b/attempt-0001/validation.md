# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "26a00a5a7db64c1758b6bd4f11b2b532614b3d0a79caac8c2dee08d012296289"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c938ed40b1876174b8c26caa422c3dece3808ad6eacc1aece57cd9c3c16702d0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3b35fe6b30bbb1c311e283e1fec6e0c9a9a8f1755ca3c30df137330f8096f2f0"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "f051afe863b52a50ad0e602670be5ad9031ea484aba79ff15a3003fefc55d87d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "cd74664b12047b198739eb15ddbddcff597dbc12f0b8aa821ebd84f846000ec6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "97811b0fd591a4629256170ebec1c62aca9531710db9f38ab9f14fa478721135"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3578c355-47c2-4fe7-8844-27fcadd2e6e3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f315c504-610e-4131-8612-418e83e7f3e2",
    "source_id": "2ff6ad75-0f55-45fe-a17d-632e028132eb",
    "version_id": "e2d4aede-9d23-488b-870e-131aa7b3d4bd"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37921/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6a679f0b-fbb9-4d85-9b30-d74f71206b31",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "cd74664b12047b198739eb15ddbddcff597dbc12f0b8aa821ebd84f846000ec6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
