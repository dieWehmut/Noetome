# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c47c757aa43991913f5a6d541b5c25bc17150482da01fc5e447c94a326389b30"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8ae70b2e76bc02821b05ced238a87921ba0167d8049958e37e1d2487d1ebf98b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9a73785ede1921bde38ce4361d1fd5c57bd350e4d07a1191f8c46ff9c25797b5"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "63e27e10f119c7517f876ec18ce0ab43ea6b49f4d9978ab6a425bde5e0492686"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4026bd6311d3d6147f927756af050432912bb1ee77a620c65671df29c034940b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "135f1ed44b25fa58e8d7802418f2a96d36c11d97c3c497f9d830117208378b67"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f795d960-9edb-49b5-b105-84ac87270604",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d513787b-813b-4176-8ff8-cd87aca98134",
    "source_id": "563137b2-2208-4c23-b245-baa42ac8842f",
    "version_id": "4b9ab279-3eac-49c9-8248-a1f157b1aa27"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36969/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "83f72140-2c1b-4cfd-a779-790b5be35d9e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4026bd6311d3d6147f927756af050432912bb1ee77a620c65671df29c034940b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
