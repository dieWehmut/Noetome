# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b1a7b8801fa6b8b05e4f72d98fd721afe03dcb5b09927cb7357c45edbb73fce1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e0f6a171b8897955f6a6a0f819941ed618a9e95b460ab522bdb0ee1b32a76f1e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8e2b75c7b2e5b2b82cf2b122c351b69a86b9c001f70ece8d80054bf72ef1b720"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "b2ac2062dc1fc7d1834d0ccd19b2e54f66bf0ef81b5061bec352c8256793400c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "df8d38d9c04198491868d3df641c45fc070c86dc090f7b29ac2a070e8ef233cd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6c82744e36ce23a7fd50d32d2936716216bc5065c7acccf37147bb0446eb0853"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9196a69e-bfc3-4dad-bc9d-4a2bf854dccf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "30e4b348-7d77-4ca7-be78-1adf9c65cc39",
    "source_id": "1502a36c-2aed-4855-8698-a0553a1c65f9",
    "version_id": "bd6d19a1-7521-4cd9-b4b5-683af6b57954"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36683/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c8b2e202-1529-42a6-90e0-009d222bcca6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "df8d38d9c04198491868d3df641c45fc070c86dc090f7b29ac2a070e8ef233cd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
