# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a4eb5d3d1a6c0ec24d244e761014eb691b79c61bbe3b942b1b33e5aebc5c7f40"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4f48364d002dee3b2e8b84dc3c990a54d5e67b0f497021835223273766b52202"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0c0d355f6ca35fc8a90e96f87c004075543872bd2470aad3eec2bc2c4df7912c"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "11240dfe2ef26bddaead5f2ed16af3b9672d28d33c9405978255976131e9467d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "466c259e9b18e8bd284345b532e7f9a861266f471ae69d51da170c1112bda3c8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f60af65587b4ec2daa705fed39067e993b251ff6e1a0b9f0c2560fc3883161b6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a651af4f-ad50-495a-8903-0e65961ee06d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2c177068-7c0f-4f64-84e9-dc5aee6718b0",
    "source_id": "d6670934-538a-4a6e-ac1f-b98a628b25e3",
    "version_id": "9a184df7-b7ed-475c-b758-89e25236d647"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37121/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0cf2bba1-95a6-4762-9657-bfe87cf6aeef",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "466c259e9b18e8bd284345b532e7f9a861266f471ae69d51da170c1112bda3c8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
