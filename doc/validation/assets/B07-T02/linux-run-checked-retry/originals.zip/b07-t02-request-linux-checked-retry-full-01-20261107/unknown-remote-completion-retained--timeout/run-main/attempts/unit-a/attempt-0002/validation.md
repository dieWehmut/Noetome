# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dbb4c6dbf042182f39218d0a60ee9dbe7e0f5d70653897e7a0be1290351970d3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "546a6e34b4de2064c889f868aa1757a8fda4e936ab83c3e503fa0e05d08a4f1f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9eb9cd3cab8594102ec8d19883ff6a18f342b7ff78ccd00c61517de4bd646ec9"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "0038778f3cfb4a616439976c646e72d0c1d6a70486af0f07845cc32c1c850529"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8bdaa00d99408a63871e36316a8980cb4f46ee80974c1a9209ea129328417f19"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "24272c760ee081374d0d0c2744a7b24a778ee0a3be98a2e76bb947e25d80613e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "21f3cb2d-e1e6-46a0-a4a0-c8a87d228442",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "964e01bb-544e-46c9-8d2d-d0c226441c0d",
    "source_id": "8596d75c-6ebf-4359-baa1-fe1531eb35a7",
    "version_id": "d21a8961-3a28-441c-acbe-7a7fd97276f5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37121/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a7f49825-f67d-48b8-964c-0dbfa2aa7d31",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8bdaa00d99408a63871e36316a8980cb4f46ee80974c1a9209ea129328417f19"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
