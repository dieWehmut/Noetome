# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dac9e7b021970559bf7bd4deb8bde931c0a368636335406b74d6b3255fca957d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f693bfc98324e6ff0d894e658812e61866dbe2e981e2d1651fd53deb3a957364"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fbc862baba3fca7921e665caeef2bfa17b5d9bae99540e2fd9804f76becf47ee"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "99a52fde0c57f43653714a5cac7e8ff07166f0f95b8716a84da3015f0a1d6041"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7b35151edcb00ae19c7c6aef4b68ea82f08c3eb5c09f8561f1ff9567745fdb20"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fd680b2c82d035aee454c8b52d064af177c299295886517bbc05a95e34da1a6b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f289771d-9f66-4621-b431-b59a3c0e73be",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4ad91653-5da4-4450-888f-68b56a0a7279",
    "source_id": "e6976806-8a4c-49d2-9fdc-890f5aea6574",
    "version_id": "2f63ecdc-1738-42e3-a89a-33d790ded59c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1160caf6-02c3-4782-a63c-045b2dd7065d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7b35151edcb00ae19c7c6aef4b68ea82f08c3eb5c09f8561f1ff9567745fdb20"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
