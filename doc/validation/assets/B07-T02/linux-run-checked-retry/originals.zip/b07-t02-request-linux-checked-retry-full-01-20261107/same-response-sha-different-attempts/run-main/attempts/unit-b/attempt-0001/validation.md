# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6f86ea040deaac9dfe1a7c3da62537f18872d3649834f7a537396fbd37515dac"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9fac03d55b636ffff13907648f1a5c5e177e19439001e3facfa6e13bd1561f7c"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "087cf49db59fad8f643046a46ab358e822697c4b87440016816333f937b88dc5"
    },
    "response.bin": {
      "byte_length": 513,
      "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "db8cfa7e43b544451f6b89cab9c5e825302c067a3b7ff32ccfa6af5de0ec312f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c9994a28-e838-4992-92d9-10e758e58525",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f356cbfb-0569-4c4a-bebb-a8b320898cad",
    "source_id": "994d40bd-435a-44bc-93c1-79abea2d4af1",
    "version_id": "1ad096cf-63e4-4151-abfe-669f88f7ea78"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36705/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_CANDIDATES",
      "message": "EXTRACT_API_CANDIDATES：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cb4330a8-34c2-47e0-8424-d0f7dbd4ddcb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 513,
    "omission_reason": null,
    "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
