# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cb50ebee8c32dfe4f417acec0171424c0126c9be5655b16f2b656a17d90ea228"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "25aaf12e3e32c0937e3940f7c8fca60bf66f72debc8cce78f54a50cdd4a5b9fd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fe86a451b861f19cbd1a58d18710c910e17fd9ac9e7db22e813fc96712f05f84"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "7e253abd1a8e84fea0c691c4d83ad830ee3851df7e4813478e3e0a4c4f36d7ef"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "de57d82182ff38c81f2d28ff5495df7de5575c914008bad3e82158d5249e5065"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7593c6787f3e3dcf78ed362339846d2504e4e8e996808febe2eae7cf33f03a41"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ad44dd30-6803-46f8-8365-5010dcfbcf58",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b20604d7-d91f-40a8-ace1-3744d98519b9",
    "source_id": "76649032-1aab-432e-abb8-b0df17e4b808",
    "version_id": "59ac87a7-5b9d-4136-9b93-451aa1cd3e90"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38045/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "55682189-f50b-4950-8c3d-9dc76ca25dc0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "de57d82182ff38c81f2d28ff5495df7de5575c914008bad3e82158d5249e5065"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
