# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4ec2199f3d968b53d91196e087502a7b18a3aee1bb6c9500c6928f8c98d646f2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e663d46b0d9981e72c5db0de2ce8da926f90ce6bc830a089382cdf95fa109e6e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3cc7f3461e506e3d74c866c9ae23f4bfc752986257ea300c139bfd089f4ff9bc"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "9dbf9c847e5114dbdb9a7509419781435eab68ca315b894d021160e1503d2986"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "54a3e8d4b47c463d4070cc13289e62e696699d7b7a97f363d5c41a62ec9404af"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2ab1b6dc8a56573b94b0d40d8cf7c8c46361712ccac2b608625f879350e46cf0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "505f710b-044c-4651-86ec-562b2b64da16",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "60ef2936-58e0-4228-bf2f-fd9cd87437fe",
    "source_id": "a5610eb4-0b38-4402-a808-ba43bfeeca42",
    "version_id": "56b6bf03-f05d-4b8c-91ee-409f6eef788f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36885/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e5f55117-e3dd-4fe9-b79c-97959eaedc39",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "54a3e8d4b47c463d4070cc13289e62e696699d7b7a97f363d5c41a62ec9404af"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
