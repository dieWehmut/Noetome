# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bb1c460fa5583d57ee2e5c66b1832ebf4abd7a40cd4f6b2ebf896ebcf3cd70ec"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3d1c3689a20f1851d05b18220861a4b9908efefaa7c504549a99320594806279"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "355a35a2248c49fdef27e6bc37aeef4ad420c1a998695b47972b95fe1116ebd9"
    },
    "request.json": {
      "byte_length": 2245,
      "sha256": "18ff481c15588131249cd3209079317bad65c6d46633e15d634ddc430c357ef4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "023c81b1d6d8e5c523d76e9e8af34e5c4812ac8ab6fdc32996db5ebf29943b1b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cd70faab599fd57fde335e8bef04e26e5e22d6e61419cc34a780a8b8745acb0c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e3001634-a32b-49b9-9a92-cd24bbdb164b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0a27fc9d-3b5d-47fe-9abf-efc340c3dba4",
    "source_id": "b6672f53-8fff-469e-97c3-acac6a62d7cd",
    "version_id": "001dc413-6e28-408a-bad6-55994234217a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37861/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7a941a3c-7d4d-4b45-a4eb-13c19a951d12",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "023c81b1d6d8e5c523d76e9e8af34e5c4812ac8ab6fdc32996db5ebf29943b1b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
