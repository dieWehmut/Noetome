# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2e34d324cec8d043cf80a8d9023691924b66f8390053856282a5b18b721daf37"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "18701bbd108b970ca7953bbba662321b4de369e53fceb6bffd0fc5c73198f13f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "23551c8cfbaa95a08cbdd4369585ebbb53d27a6e80c95ef568793f99b74754a9"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "58da8ed2a364ca22c7603c24a502b2bdfd56022611e4bab736a2f4999bf52017"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "81a98dd7f4b4461476143348957b4a1366e357102315e57fecf628c80ce3f1ac"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4ad85b2296629d6a7aac39822765c217e411ac3501667f5a256f182275e583c1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1256d796-2435-4d51-8c63-68b64fa7486e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4cbd1cdc-8d9e-4d04-a52c-0ccb7cb8dad2",
    "source_id": "cbee05af-b1a6-4629-8fb6-2f8c6f67762c",
    "version_id": "1f5cda70-2486-4d30-9703-c2413db79dc0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36881/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "24736b6c-7a49-4f21-9e95-35d482710c2f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "81a98dd7f4b4461476143348957b4a1366e357102315e57fecf628c80ce3f1ac"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
