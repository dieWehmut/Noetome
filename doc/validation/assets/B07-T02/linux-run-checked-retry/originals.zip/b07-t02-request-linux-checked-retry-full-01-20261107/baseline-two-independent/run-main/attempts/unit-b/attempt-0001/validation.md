# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f37e96ac60587b614da64609342714e8212e80b2d4b2e298b0571019ee1ee912"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "92239833fd0a705fa5bc1a08332b191752e96a703295fa5acabeeb025d8c4666"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "54b5c2d11bd64a5f1aac42a9b2011d20165689387f05803a031c9656241fec77"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "042b7465ea31f7d4716f8139cb3155c54ba5a3462fb5e9e72134413c72d54e2b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6eda1c8af7129c2919d63bf7be33a72ede61f4a4fd2e8feefc56759c538baf9e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9db4d8dd723611af16dd17806039a0d3f199928128d170e3a75129582c014cbc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d3c41374-504f-4d33-9359-eefde45fd991",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "55934668-5067-4cbe-9e21-35abc9869946",
    "source_id": "a9ba5f1b-d7fd-4ef0-bf90-18ad52b15cf5",
    "version_id": "e87d29bc-232d-4ca6-b29f-de03e73d1173"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36881/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f28fa868-3d6e-42c1-a8b0-c7ba24bb0a62",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6eda1c8af7129c2919d63bf7be33a72ede61f4a4fd2e8feefc56759c538baf9e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
