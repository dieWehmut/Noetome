# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "46b673697b5222217e4490a257d8fb16e89e31f8cf0963b0020cc3179043c41a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a34202d58f103a7e876ac474bd5b99d92b038741c2cc99383b30b4686d080ccd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a9866357d97f41cd40b9f289950fd8a55d9d6c4b579db521f8d3fa81b4c2a85a"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "281730af912e6fd685ad4db6b247434ecdd8d586e486fa2af0efd4d32c281a87"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "aeabd477e7d92dcf443cb6e3ee1580e8db0a61dce5c4a1ee7bd39c0e3a900fc4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2b25f5b5cbc1bbf1e77e0a258d14bb9ef9c79453fdb5e2b75a067cc093d56d53"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b58b5bb2-2b78-41a5-b833-ceda3cea2dbf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9a4d980e-5214-418b-a033-d9f563131d8c",
    "source_id": "d8ab8622-83e4-433a-b223-b0d0b55ce915",
    "version_id": "d9e72dc6-973d-4a78-bd33-3aa4b454622a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37229/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "023d0a4d-6fb6-43e0-b330-3720afcef441",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "aeabd477e7d92dcf443cb6e3ee1580e8db0a61dce5c4a1ee7bd39c0e3a900fc4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
