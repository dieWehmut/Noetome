# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "dc76209a64e8e09f334f17299be153087f59392cf3ffce4a87848294bfab688d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0baec6deb8413fa30f1eee0f792af81c5e47aa96313da92be963513c43f112da"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1f871989f0834b90c7ed389722e108d3c656576323e629f138f985ab0a7d2872"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "07ea9db5dd3fa0999eb22d01f9e217382aadc552f58af13720f47cc51c70b57f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9b59dbbdb11c23ebcbf990595ef812c7649d7c90739ea5d97276f6a0ef643593"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1fcf3cf39a1999fad30b93484ed508b14edfcd32627718e944f9605554d18ec6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7441958c-f262-4260-afbf-af0afb01f1f6",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "439b19b2-2bcf-4069-883d-e10f99d8d66e",
    "source_id": "ba62c271-eda7-4eb9-8bc9-a4146ce02657",
    "version_id": "5af8da98-1826-4934-9eaf-f2ad5e380784"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37229/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fca56a7f-40aa-442d-9ee1-00b52eca67e2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9b59dbbdb11c23ebcbf990595ef812c7649d7c90739ea5d97276f6a0ef643593"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
