# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "42b8453bff3821bfad66fced4dd2055f9bf1343f07bb74486dc5c27ad2db075e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1796a2965221778f52b9ffa567230f32cb76ffba45055a2ec582926d71f84e6b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1c84c0d19e413c84c47feb4bdc3f71ebcd58cf8e4cf178b9b612caee4c58b255"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "c5d0127b87a05527385fcc182ff4d0bd182740198ea52bb829425675b13f3121"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7ebd0a2d6c5d7f1288a4fef310ea845a60572bc9556cf05af79e605a4b49a79a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2d16db489729ffc05925de11fbdaad6b5575c4c056a0904cab2ab015608ece3e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b0e21eb0-999a-4dc9-b8b0-903144398e17",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3eea7f05-05db-4b1c-b7ce-f90bde64f0d5",
    "source_id": "be36b8f0-3e6b-4e5c-8e48-f4d24b691a21",
    "version_id": "412e8ab9-30e5-435d-b1c5-966c3c9e4874"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36939/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "91ce1868-2a86-45f7-bdf7-81694dec067b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7ebd0a2d6c5d7f1288a4fef310ea845a60572bc9556cf05af79e605a4b49a79a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
