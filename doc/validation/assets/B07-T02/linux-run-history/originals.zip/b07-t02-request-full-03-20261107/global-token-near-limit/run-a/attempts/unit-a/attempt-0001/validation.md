# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2c36a46c6da0d9f0aad9d12ec2aa4ee64ede3dd92c4d86c52a033d65c48c307d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "df31bf3bb73c2fba0b3b69226e1cee76a344348b50349bc098c1e4a870f7b053"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "61ce7058b5a585e5cc3714a8fdcb6a55f982ca9cc073f2523f6a55371be1a35b"
    },
    "request.json": {
      "byte_length": 2200,
      "sha256": "ca98f91f183dbdfb7380f976875facbed2ce2096249b00c763a0465e7f4b49e6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d1e10dd81d77764bdae867f73aee5d5d5c9091b04d76732f6fd89d387723cfb6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f9dc888cffbc73bee8c8a46bbe5f89c2c23778e449e5729bccb6e5209572c8e7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ce18f3e9-0bd6-4f55-84cd-d70bd258a2a9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d6da92c5-a4f2-4f83-bc8d-67b28a1c674f",
    "source_id": "53e21620-826c-458b-9c3d-ff8fbf122f1b",
    "version_id": "fcfc29ae-c342-4698-8904-13933af3a2cf"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38273/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ae8db2f1-0327-41c6-ae7f-cf499f81ceb1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d1e10dd81d77764bdae867f73aee5d5d5c9091b04d76732f6fd89d387723cfb6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
