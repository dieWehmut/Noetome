# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "857f3f47e2a82d9ad6511fee70ac5101baae306b684c616666712d7bc4a51e97"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fc228391f4303becf3da701da9b13f86422336841e93d0a937a883df5e14ae87"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "641d25a2f629483920d6f886f146498ce9f64d8a1f46c83cd9d17b4e9781c1cc"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "2481c8de8626b07d872ca0c7aecd20543ce98af1030bf017aa123c7d0e569c92"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2e1adf27921274443ff431c65fdbfe89d194bcc87d52493cab55e70b38804e95"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "395ea4176a9052562d56084e1772eae4366d2f905d12bf00468ee091e24e9676"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c24bf807-aec7-4663-879e-445114181767",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "548bd161-17e5-4771-b700-6cb194210fec",
    "source_id": "035b3f12-e241-4ff1-af57-3e70ea302c83",
    "version_id": "2b0f86f3-115e-424e-8251-67a05e90a7ad"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37713/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6496eefc-c4c0-4b2f-aba2-58cbbcbb5e7e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2e1adf27921274443ff431c65fdbfe89d194bcc87d52493cab55e70b38804e95"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
