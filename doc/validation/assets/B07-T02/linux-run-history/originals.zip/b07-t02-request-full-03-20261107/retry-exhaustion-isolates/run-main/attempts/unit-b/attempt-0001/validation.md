# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "456efdab02df71f1ec93dad04a3e1b35fa7d9c82cf400141ed164f15d83539b2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6845fb3c575883af6036a6b8734365543c86e57e8e51fb28362a3f250b9e96d7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e0e95daf3d574b5cc7f6bfcab15d42e11cb0a895efd622c2a6ea531e55cd5334"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "3de09b37929205a39f7ed1b453695cdd98a33451086c7d1e7988b712d67b24ba"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d528a16e11bcd559ef813a6c2f4e2630bac739545e630e26ed74dfe69207caa4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5ef188f7a244ab66aca4104bac666119a0b0f80f0b5e666587bbf0429c14a6b8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c58da7e4-cd4f-4834-8b6b-a25041289c9e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4f05d73e-6ff2-4d90-bd4b-f643dcab0ada",
    "source_id": "4ceb1644-3117-4e25-8c3b-5e15324f5281",
    "version_id": "9f748d9d-76d0-431f-8bfb-4c7fda6d20c2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36535/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a6585a15-3e3d-48c2-8412-362d7f1faaf3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d528a16e11bcd559ef813a6c2f4e2630bac739545e630e26ed74dfe69207caa4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
