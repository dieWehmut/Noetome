# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a62e6457f098f0ad037c93e05e1daf155d1a6d0e5f67c475fd0d86b2090e0185"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7f37c639e858ab930e536bc0c22564e9e3d6e5695b48738c027800c458ec7ca4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dbdbbcaebb9125590ec8c3c9b2ed7ba8ecf0f74ff1d7dacb80c2fb94d86f9728"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "6d3b6a26527d144fdbf52674dcb9a58be84faf583d1eb8885386d9d0cde02a29"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d4fa1ee7d2d39a3004541dae8e616bbb70edb9ccacd45f6cb630f8f3ae35e399"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e3c0203130bca4f53f2bbd7a977b40b682852b8cf41f7b51fa379d0c379c50e4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3abd74a7-e9a9-4abd-a3cf-99777e934139",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cb0057d6-c00f-4b22-8626-ca2e019a6301",
    "source_id": "ab6d03c6-2508-4b3d-b22e-c5c958695a64",
    "version_id": "4e2d4f34-646e-40f7-96d1-59603b404a49"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37447/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dd9152b0-9dbf-43b6-8b3c-1d5ce93633ae",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d4fa1ee7d2d39a3004541dae8e616bbb70edb9ccacd45f6cb630f8f3ae35e399"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
