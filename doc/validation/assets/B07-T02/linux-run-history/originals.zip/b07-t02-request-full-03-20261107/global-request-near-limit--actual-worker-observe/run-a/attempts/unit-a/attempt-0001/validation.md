# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f8cdf7998dd458e719d43f5d24ce44a649fd3fa112a2557b3b700658a5d8731b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "302c5abdd6470ac5d09d8c79888a0872ebf79602b6d52f68a438c74b277e588d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "07b96c0f4dfcd60941d7b7bbad4eaf80192053a94c4e9622950042894663a6b8"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "0f658c45a07cd7b5277c9f56d88fbfa23b653454769b2239a813ea566a8211e3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2bb8b7d11d42f3687c51745c92552fd4aa2f2fdf8416a2e350572af2e73ae770"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a6aeb0cd8c3dad523894f27e53809cf62aa5aad2aeae109cffb14366b38fd028"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1823ba5d-d552-44fb-84d4-e5c7b1404d4b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "52489813-5761-417f-9859-785c3484f5b2",
    "source_id": "2b2c31af-25c3-4811-9514-a9e7b24e006c",
    "version_id": "9eecd227-d3fe-48d8-8015-12675cb53280"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37979/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "00874318-3b65-4451-964e-0c649396ae8b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2bb8b7d11d42f3687c51745c92552fd4aa2f2fdf8416a2e350572af2e73ae770"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
