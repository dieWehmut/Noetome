# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4121eb81936d5e820016df1d3e398da9bac4aa06c3037eb7ba0bcc666f037a84"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1442ad760ca256cbcdaaf320b6a20ef8245476300ffde39c4d372d0d3d8fdec9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2123c69e5711ad5323e4a0f990aa8d01894568aeca10c057b4b413247e1f34bb"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "e899ef066c565be7814f88054c590fd19f5f52220ff3ae7907196deaeb307836"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8ccbe35b575774bdf27d3d7d76c88fdb13b21e576048ab2c802519bd13c1940e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "95dac9b72a1f8ad423072b33bda290fa3f56819a89a92b1c051ce331c34c9bdd"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d37afc6c-8d1b-45c4-a5c5-2dbcd9d955e9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9c44a5c8-9614-4eb8-ae0b-3c8d1af94797",
    "source_id": "49990dcc-6528-4fbd-93dd-2a66f3211467",
    "version_id": "b3964286-6aab-4abe-b4dd-0aed2a8a65b1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36885/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "53b58330-090b-4727-b53b-679b38a31957",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8ccbe35b575774bdf27d3d7d76c88fdb13b21e576048ab2c802519bd13c1940e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
