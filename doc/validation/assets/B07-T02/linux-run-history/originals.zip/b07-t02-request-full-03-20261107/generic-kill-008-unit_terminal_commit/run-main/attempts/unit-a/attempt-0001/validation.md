# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "34cfc2490fadcc31b883275c030f4104e80ca0ad0246da37425a3c4df572929a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d1844151e80872dd9869db81153c5952e662747c79c6b294abffa90ca8bdfc1e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "87ca9f641c3e7552423f9a03f686bcbaed20a45ec7f412d1787cfe2ce1d08289"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "9142179625304dbf9670f87959b372e90950a6815d59862012f7ec07ebb980ed"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2eb42f85fb161e2c04626e611757a778162ad87b080e69416bdd55cbc699bb40"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "25d9b2e8c6389b502607b4276704bf18be2ba5051b5fea49a30130e1b6acc583"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5682fdc9-5524-452f-91ef-0ba68f0c94b3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a5424864-918f-48b1-9e4f-f1052a5d318f",
    "source_id": "c0b9b65c-4c6c-4f8f-9829-7c126bd2dcce",
    "version_id": "15a56627-a74c-4b33-bf55-e097c0248f9f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37687/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2386e6c2-7582-4b5f-9206-2988b262050e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2eb42f85fb161e2c04626e611757a778162ad87b080e69416bdd55cbc699bb40"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
