# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d77a5133d697e9d442bd4b98778655e16fc19e4ef3e106ff289d6b0d9a3c7750"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "858604c7ecaebb203c404581f16883678a0dc631e04a929f63116e0eda240f4a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7b989d8a0e7534de3afbf9ab389e638f87d5724a2bae8598f8e0ed1c3ae131a1"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "a182a525cd4dc6ae30963db92d38f2aa5d3d54fce7a53e2005f717fc0c472552"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4d7cde6ab13c6f3f69254280bf10b86e46aa2a2d77bcd3d3404ac06049661fcb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9a3dfc0abf4a0f463b8845c20ec65d43d8eacf8bd6fb2caf0a049c22dca1ab1a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a5cdb897-dc3f-44b2-a90b-0c8378d19186",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7834fde5-b8ed-4daf-ad5e-618e1fa95489",
    "source_id": "abbe692b-87cd-4eca-bd33-48cb460a1f6e",
    "version_id": "c69ad1b0-5c10-48c8-ba54-6197a7e87f60"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36453/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4145c3b5-7487-4a9c-a882-2bf796282d92",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4d7cde6ab13c6f3f69254280bf10b86e46aa2a2d77bcd3d3404ac06049661fcb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
