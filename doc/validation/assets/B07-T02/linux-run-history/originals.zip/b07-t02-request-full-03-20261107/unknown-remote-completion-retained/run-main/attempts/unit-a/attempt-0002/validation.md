# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8642a08eaf120b2e00b771a1e2105d355b01f7d67baaefb32ccb41f7ec0df36f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2718723af51c32e96457e8442dd827354b037c201dd54b4faa36fa09785b9561"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0bae5f22eeb7e0d62d32bf4348dcf29b46a24ccd6665e22abc5c595655333fbd"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "fde06aadf17ca27a15b9f3498722a235fc1073590f7f2d4215fd39e4d14e8d00"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a41c5744498dc4d4bcc335e73e961d2f5d6de29e04b8ae3c584301e678ed9a5e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1455b76b94a084220064dac353d4e8e72dd7b978d7b58eb3fbbe9c8f5da65f9e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "482a0e65-4e86-4d2f-b65a-75e36c3a11e0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "044d6bf5-0ef0-4575-9186-f7085be64173",
    "source_id": "247740d3-964f-4716-a219-7736235a599f",
    "version_id": "469be0a7-4cf7-4bd2-aefb-953b54cc9757"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36453/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3dc8e476-1614-459b-b1ec-f414f00a47b0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a41c5744498dc4d4bcc335e73e961d2f5d6de29e04b8ae3c584301e678ed9a5e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
