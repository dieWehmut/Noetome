# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "06ab92b54aaf19a3109ad0561720274b90de9ca4d4cbec35e843b1b8b84b645a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7958e3d295f8aec20d8be9c84ca881c82c5c10995941b96e8b420d7c51f8680c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3083190c5fb7967a8ba3d5d883f7aec9321c898ba535a45ea6ee789165b57ebd"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "dbeac4af492408c26d6bd5bf2dc638cbf657d6ed915392cbb2da8e840c1153f2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6400c07c734c46cd71aa193f3acea48db81ec9a2894126766d79ac76d0e15d94"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c7329b93989baf35ed72c1dcdbb6217db17594ce2bb25cd88861e76adbf59c08"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8918280e-4937-46e4-8d10-19352e93a063",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2a3352aa-dd3c-4c74-bbdb-5e76f9a386c5",
    "source_id": "db65421f-bb69-4a91-acd0-6034872a771a",
    "version_id": "89ef58b4-e3f6-4ca2-81cd-c934177085c5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38149/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "711dbf36-16a7-4bdb-977a-936652d26f4f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6400c07c734c46cd71aa193f3acea48db81ec9a2894126766d79ac76d0e15d94"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
