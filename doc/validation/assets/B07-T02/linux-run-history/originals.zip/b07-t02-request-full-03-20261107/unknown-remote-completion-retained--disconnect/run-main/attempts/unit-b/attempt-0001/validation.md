# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "14db45783780191af0822c6d888c3c891e732c400ba0d9b70eb134bfeea866f4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "602b4ef28ffb4110ddc8adcbad98a6f61907e643f48aea33edb3109d0eb2db15"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ab457853f651075a8702f713461b045d2b88e92feb3d20fd7d4e6db93c661359"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "82b291f8ca9bad2299225673fc131c4ad6eebd738b6c3d6ae52ec8d1ec8ccfb7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "68678293a7072035b67c2837d4396e8e0eeaba0f9a9df03c5cd8cc77a6a7026a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9a340cf528dce5586e8c3a719ca1f52b8b9c08bb2e5e14d55e397707928340e4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7f757a60-efa6-4c34-872b-6ead7ab3a546",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8c22629e-ce68-41bd-a500-abf3e6a9cda4",
    "source_id": "938454d3-c512-4fe8-a1d4-9dc1b4e5019e",
    "version_id": "7fa2e59f-4372-47e5-b084-3357344b3dc0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38149/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "88aaeeaf-a3ee-406f-9d00-d40a9e9de8a1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "68678293a7072035b67c2837d4396e8e0eeaba0f9a9df03c5cd8cc77a6a7026a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
