# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4f82aa4121c45917f264014bd031966cb86d0705bd4298c23d8c71cac19e25cf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5c0b08135678ea75fba554db57e1347ff3939bd08ec92da7a69d545d8d66db98"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "48fc5c1395573a174893c83acecb3e88e9f241af477becebc8805c50d8bac35d"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "bfad97e23849b2b5a9d4d2a34c28046bbafb90d110936dd68cb6e8731707b1f9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "36939b4646a2cc88796aaa245d0a25678fc378dff1504c2184d6f549153bc3a9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f6b393829f3572a9bd9abc0df9763299f80e9e876f0791b6501af92ad765a30b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7bba3114-cf92-46bd-a1d9-06de4111129a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d6205755-de3c-49a6-976e-a0dd94e75e88",
    "source_id": "5e8bfd4a-4235-4647-857d-2f7a45469092",
    "version_id": "c952ea7c-3689-4d63-b01b-9d572f09265a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38083/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c6477458-b89f-4089-b4e9-faa7001f10f7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "36939b4646a2cc88796aaa245d0a25678fc378dff1504c2184d6f549153bc3a9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
