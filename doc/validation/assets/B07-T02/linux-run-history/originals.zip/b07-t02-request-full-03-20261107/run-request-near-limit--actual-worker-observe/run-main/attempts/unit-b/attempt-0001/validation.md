# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a042dc5321966686effa015580504e4465895a29089c495f451a41418fac6eb9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2dbe011f7526ac8fda62b0982a94b309df0d6469e6def32644251eab3167d06a"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "ec663a242e180bffbf7e0e601dc2a603ddb585e57be7580b6a431052008e06f0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5833345a-abef-4379-84d8-c68366339386",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2ed5f04a-2df7-4a3f-b33a-5a70f77da7e1",
    "source_id": "9b7f948b-9170-4852-8ac1-7565ab589691",
    "version_id": "0971584e-bb65-4679-bfed-473e31e4a286"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37553/v1/responses",
  "errors": [
    {
      "code": "REQUEST_RUN_BUDGET_STOP",
      "message": "REQUEST_RUN_BUDGET_STOP：准入拒绝；未发送并保留Prepared审计。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e7987960-6d7a-421e-8228-02fa743a1132",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
