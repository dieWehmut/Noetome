# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "702439f9504169c986813fbd9ad4388076ab1b61776f7b8395db226d1280a2cf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "74d389fa198d0386c49ab1d62046cdb9f48873a14bda5e23160f5485132a4d5c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f1052fb4eada1a53b0548af83f4de9f6bf2355f301f8095b997ddcc76d5e5361"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "c025eaadc42e90b62eef3e6a2269d28e3c758b24cea9f2eb67db4672086478b0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a643526adc922cebc7be37fb508529487f1e16249da00263e259f582927690fd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1eca274013cb3591c1688ef6f4217d364caae2f20713ce8feeba13f3090dd9e9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e3a09bff-01e2-4f5a-9dfb-ad3d5db1c728",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0ecd6f87-fcb8-40be-b246-405d4f4bd367",
    "source_id": "6611c3fd-4618-415b-942a-2093fc080a7b",
    "version_id": "a386c9e9-c1b6-4b82-ae5b-9fa54d1e419a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37553/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ab847c6e-4ff8-4aa3-b05c-ab2e47c0cbbe",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a643526adc922cebc7be37fb508529487f1e16249da00263e259f582927690fd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
