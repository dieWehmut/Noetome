# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0351232c95d7451b26245572f54f9f66daada8289b613f0a9c3a9131af294223"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ba9a39d2742b93dbe1dc8c22bc800dbced7327ac59b0d24d1b357629f187eb9f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fb33a13884ef3bcb7ab29535b5a72a8275f31ecb7715681d373509cd261f6bf8"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "395a1ec2602abebfb1a2e786e94cb66057a548840666cab430306fc74b18a98e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "084f0a5e6b4dc5a8d76eed1a198f0edd9ced1a2306806847d9c1c8f82deb0277"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5e9eeb9fe6c6f950955c19434c564dcfa79202a0c4fa7aa542714d59ae42247f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b7bd0b64-65db-482f-8703-93f066dd08a1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "65cd4f57-e523-4a3f-af36-de4be864acd8",
    "source_id": "7dd95195-3c6b-4711-a20b-39b661bc9707",
    "version_id": "d7a19e70-64a3-4089-9140-7c17c76faef3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36601/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2d4f238c-3260-4a9d-9bc0-9ac82fc8e00f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "084f0a5e6b4dc5a8d76eed1a198f0edd9ced1a2306806847d9c1c8f82deb0277"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
