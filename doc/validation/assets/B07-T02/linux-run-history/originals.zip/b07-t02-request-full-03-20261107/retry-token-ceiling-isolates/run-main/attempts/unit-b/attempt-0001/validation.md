# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b8ab7415bc1a0e4d82f613fa25f10468d6f084b1ce5c5fa3f8e2a4e9f0f0ec0a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3225de7f18c86537df9a98a27b87350f20e12a1ad24a6ee8b41d00b9c5255a68"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "69b9cb125c46a0ad617d68c06a57e32443e1754a76b21b73a1963587044f572a"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "a7500eaf847468dfe9db150ac8de79c63fcddac8fa5bd65c1705cdffb826ba94"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "dd5566594a259694a09d5a590f986cb6cab91b6cb8adab462f63913cf0d1d006"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4cb7d195bef69cd55396e987b04dce9742865427de93ada6ddf8f61e10ead9a5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3303f59a-3e4c-4ee9-a52f-213298c404c2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8816d9dd-c0b7-4c39-8d5f-3a5c573f5d1a",
    "source_id": "48d2018e-ad8e-40b7-a9a5-ebdf874b444d",
    "version_id": "65640776-09ae-4429-8697-0ca5afad1dff"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37739/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fd20bbae-1f15-475a-a086-0b3b59974e98",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "dd5566594a259694a09d5a590f986cb6cab91b6cb8adab462f63913cf0d1d006"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
