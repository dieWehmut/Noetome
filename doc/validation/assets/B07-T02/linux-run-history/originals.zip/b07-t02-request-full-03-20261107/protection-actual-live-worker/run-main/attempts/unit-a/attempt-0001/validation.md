# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8462a15edd830362224086628e627c1937b1783f9905e1ec7d8bb634e961d186"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "81af1f5de3d3b990cde1d71ec5f71f59936dd5ae1604a03d8dbe36e0f68b1292"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f1f0dfd3dd9c93edc8f21f5a41b69aed629981cbff6f868e7b8a20ce4c9b5087"
    },
    "request.json": {
      "byte_length": 2206,
      "sha256": "572f8f3d3691b662d58ecc4c8a136c7b247c02ba8f3ca2079d111eafdd47d77d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "78c5c0e6ce8025d1239815b94f89061cdebc1492279666c59427769a3c76bdfb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ee143c054b1e5323e7c8501418fd0e7141578d2f8258079aa7721951b8a59e15"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f5d26866-37d2-4358-a83c-e119bc810866",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d0baad6f-ff8e-40cd-99de-adff70fc2af3",
    "source_id": "9dc1ae2f-d2ad-43ce-9df3-4256ea422361",
    "version_id": "a798ef92-e126-4a17-bb33-1e44a23eaf42"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36861/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a1b05704-ca98-4507-b165-e23a39004c7e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "78c5c0e6ce8025d1239815b94f89061cdebc1492279666c59427769a3c76bdfb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
