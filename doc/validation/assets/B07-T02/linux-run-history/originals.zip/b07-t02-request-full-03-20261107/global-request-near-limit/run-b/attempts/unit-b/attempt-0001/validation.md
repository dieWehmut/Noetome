# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bae1b38aaa1cf4c3ff2d087e0ea2575ce4d2a3846e0f382aa84d03980a54c32f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3625731e01a7674d6e36091741f3e08349ae4b00cf7c9c87aad039c2b5378e76"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "90eacb079f0588903c8d7b7129d75da18e3c9dddcbbe6ad9a2d7bd0464107112"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "b08b6b70109949b8e8aab9e81a46338152ed8f5b473480b2818376681b5f044f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d50ff90c77fc829bc5f5d511dbae6fb9bcc085e408ef85e0aadfd3b8282f755d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f6c4bdd60c15c5d86e9e7cda5095fe6a3d2db0b38ab7f36a2979d6ba478a3ece"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "77175ef2-1d16-40a1-89a0-3a9d727b3e6f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e891cda5-95c4-4e74-894f-41c52a3b1dd0",
    "source_id": "e75caae9-7324-4c32-9b8e-b4581caf17b9",
    "version_id": "40754d69-db48-4d94-90c6-24a29e6c438f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37623/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5b7eb3b8-23b4-487d-b634-90a9ea54559b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d50ff90c77fc829bc5f5d511dbae6fb9bcc085e408ef85e0aadfd3b8282f755d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
