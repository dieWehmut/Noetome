# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f93d540fccb6ab7474f37e130e936ff2e7ec08a335e54c13bee3cb91ae5e053b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3e6806b4e65e84e64b32044c84d0f1f0f4370d92c6f6aba31aecb5e4b3cd06f8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "05714275330ac0fcf5a7397904f2f92577c7e8fc08180f8fc1ccd6a51fad936e"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "166d2db9fe5c095652147f19fe413068d1da953c070f48ceb2749474b750bdda"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "39985e86aa252302539e4821ea416e3ec250a03e17e4c11c7b0f4103eae33d19"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "af28cb6e4b756bd8cf2b7badbcb6217bf75b522c95898c2ad9a5e1afd84258e2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9fd63596-c653-4e14-8707-4ae268bb87cf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "666b54aa-321a-46c4-b080-bb9a02152def",
    "source_id": "f31e5f3d-2a38-4517-91d5-80e78f3d18bf",
    "version_id": "d2798f4e-a987-496b-ba6c-402411d8a25e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37981/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "317b7575-e589-4ad3-8af1-cd1dfd5f47c7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "39985e86aa252302539e4821ea416e3ec250a03e17e4c11c7b0f4103eae33d19"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
