# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3847dd0cc05fa516b7ef1b93a75947feab7117661f9f116076eef30242e0ab61"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1d56944eb21ec9f41d06a94a23797393d2670eaccfd66f0ee9838bee13bacb93"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a1715a1f0473dd65925b36ad2fd9cd26bfd41859bcfb1b05bfecac53fe8a9bc3"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "bb16a36e2cf4851d3d5c5da4ea20a475bab273597196a540cd47e120c1f6b356"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "240c5781d60a751c341ffcfea2c3277130a05749e1c221cfc3d9d7b88d9fc109"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4ed6b70186e7f7f7a0ec65759289bc17b797439ec938ab7812aef801d66c74c9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5db213d5-a5f4-4b1d-a314-ed3d3838a9dc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0c9aa866-e57a-48d1-91ae-121d3e78f214",
    "source_id": "bd477ea8-88eb-4784-94c2-721b4d865c0e",
    "version_id": "edf885f5-2447-43a7-b692-240668271942"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37693/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e38c6e1a-177b-41ed-83e1-6c1f2d90e4e6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "240c5781d60a751c341ffcfea2c3277130a05749e1c221cfc3d9d7b88d9fc109"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
