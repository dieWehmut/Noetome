# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b1a52ef0d6a381771920221d34a9c51667411ca772416b7e295fa843d6dbb955"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cd8832f5bbf71e41ec40a135d9380532c71ada4c5f7bc7a904bd80c906385823"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "379c5062ed05bc110d8900749efbfbf163258c5c4e62d3e4c138e4942b78e6cb"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "c0ad71f26787b9bc542970d42140ef43b7e353758ffb1d4a4e2e886a18e3fdb1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "85a3a058893ea72f23705a139b67909a04043a5856315a1729438aac8acd9e5e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2054ffda172ad50d57f5f1ea298fb90b8cb872947a60e692f4205cc720d8945f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cb382986-bbc3-4c93-9576-59753fa513df",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6bb33099-5b24-452b-816c-3c522223907a",
    "source_id": "76c6aa07-468d-49ce-b53e-3137f1e84546",
    "version_id": "0eb414dd-223c-471b-959d-212e8dd48304"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37223/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ba1b9df1-44b2-40b4-a83d-232c43f3e35d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "85a3a058893ea72f23705a139b67909a04043a5856315a1729438aac8acd9e5e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
