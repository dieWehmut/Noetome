# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "15b03853981ea26487031734e6e22e6b568a8a25e8fd209e8cdb35333c27859a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "36a4e31d98b5fb776b083563febc7975061e792da6da365930d754b589ddf692"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2cb1fd8dabc32b7eca73d48dd47e61b3c03c1044b45faaffc61da6877cf814ce"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "0328996f0a7e26b81e6b2a190a80f6d383428f5cce2ee0dd7c334fccb8d8bb97"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1ae21e44f409db7fc8b335f268026f73db13563583001377dd3e1835caa27372"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6c305cdfe904ab29eeafbe24cdede6f7370b59e92393c9ea444594c0319175bc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "75276a26-0320-4d97-8185-a363214f3a7e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f7eaa749-5733-422a-aca9-45e3a2aa4c5d",
    "source_id": "786cc13d-d4ba-4e8a-9ba3-f3b8055fb46c",
    "version_id": "9073ab8d-7e49-4615-8339-5ccbb39240d4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37223/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cc97656d-bcc6-44d9-8053-fdc8793880db",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1ae21e44f409db7fc8b335f268026f73db13563583001377dd3e1835caa27372"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
