# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "718a86c08d4f9ca86d0d14318080956c2a3800b70746794c97c2857ae174f2e5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ee779fc6a98f0cd58c86178e9e99efc5a40201352b239956de2ecc87529a5e46"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "15e253652698d4551383cb6a8919afc9691ef52eb4a405fdbffd2616d872f7a8"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "a31b509dad46d75e5d5d600aa839b16662a74f190f968b5770fa067db2f48c89"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "518c344351b849bc8ba77511c75348317dd289c42efe9f73174c5af65f7f0e9d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "01897aec6cfcadd613d3e77f1ff51f8cd38ab7523d6d74f331b406629c010faa"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ff4da0e4-e6ab-4908-b32a-396f0beb3b6c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "028a5f62-ac4b-4137-83e6-1f8b5c6b3270",
    "source_id": "44e8f6cb-c85f-44de-ad44-d5ac6e611654",
    "version_id": "ac158795-ffff-4b16-8aac-c1b82eaa521d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37261/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "adb2acbd-4fbe-4e01-b043-30dd0edf5e1c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "518c344351b849bc8ba77511c75348317dd289c42efe9f73174c5af65f7f0e9d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
