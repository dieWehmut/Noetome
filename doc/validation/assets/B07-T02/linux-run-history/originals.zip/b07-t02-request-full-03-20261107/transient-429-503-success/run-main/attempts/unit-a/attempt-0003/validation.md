# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0608c53cd6fea44e4c3f5ea8a4368d13144b4606867ceea5d6b3e9038945add6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "de6b4edb1c36cd2bc4f203925cbd52f1ea4a584c46b106ebf548dd62c382a23c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "83bd4abbde8a170b0578faf764acc7430622471b9b6041f8aeb2d5948b62d8ad"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "9df99193e01eeff3b2e1f18c31913802d827547731db832412ad556f93771904"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b598e12d3bbc16ec548fa66559da87eee21a03aa50bee788fc7d89a45e2d2120"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5f5e4aeec538f93bacb6d01943a63a0901eaad137e56c6db83c1a46272c0e53e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "399325af-67d9-4449-ab88-b5d0aa01879e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "28a7a831-7899-4efd-8e6e-fb415da62cae",
    "source_id": "d4b1b707-1ab0-400b-9566-abd6b370c566",
    "version_id": "36f97f6b-d3f8-45c7-93e8-cb7a6973bd1d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36769/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bceffb87-4e2e-448e-823c-43a45d01934b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b598e12d3bbc16ec548fa66559da87eee21a03aa50bee788fc7d89a45e2d2120"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
