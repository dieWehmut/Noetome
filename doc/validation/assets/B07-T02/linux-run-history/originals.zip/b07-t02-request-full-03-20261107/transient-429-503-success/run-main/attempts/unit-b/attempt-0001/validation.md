# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7b9fc8675fc97ac3219b0444dbbfa35e0cadc0fadaf3e9990d81866ba5240dd9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ae0b7d8dd64fda54b4178b9386c9e2c0ed3e177f4ace2e0d09825b316551a2f9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "791c3b033e893cb4d9010c621331572e8d6ff5062e734eed632d6b71d04d4b13"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "f4adbd991ea19abb3ff391fb965927b8bbbf618d0110687a0c50852969cf636b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b37d911049e28a3bc50a0acb5ebe25b33726c38455337f00dc24592b16779a1a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b77d377ece98ee3287ca1ce41e8999fdfce8b264cd074257df3fd0b23b16dd8a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "efc91fe7-08fc-40c6-a2ac-e931a22b2957",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "29ed891a-b058-491d-8465-9cd8f1bdc456",
    "source_id": "5a5f6423-ad90-451b-8532-9f9909edac45",
    "version_id": "8a40de1e-a4cb-4870-b5b3-286d665e1808"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36769/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f571ae7e-c54f-4bcc-8527-4086d076f4d1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b37d911049e28a3bc50a0acb5ebe25b33726c38455337f00dc24592b16779a1a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
