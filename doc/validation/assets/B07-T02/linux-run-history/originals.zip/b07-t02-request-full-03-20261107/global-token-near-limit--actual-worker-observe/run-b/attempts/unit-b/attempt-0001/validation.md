# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7b017a274954a427328ce5c0fb5c6b3638dcbe1a65ae4bf0b53fcc61606e00b8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "add601f4a1347e1785b8a5eea0d89acca68e981c308228e8bb0034c1fb209f48"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e34855b8404e920834a1dcc897e2d5fdc80d497df0b596a0b539b9b9e86935d1"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "7ba37a6fdcbabe4fbd1d09f305809a688d5678514247d486f3ee52ae961989b8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fa63a77ff3dacbf19a84bb7a910b972b2c091815b860f6cbf1a9ca14dab574e4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "22843f7cdda35fffb0748f635dafae8b79ae611dcb8063725d001d363c409b95"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "32417bce-7a8d-4203-baff-2aa9f4596f49",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a7a5c675-d3b7-4352-beb7-3cf14e5cde40",
    "source_id": "ed9effcd-5fed-4e34-a9ab-b3ad05e050ce",
    "version_id": "16bc9d58-e9de-486b-9f1d-72f181cdd18d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36837/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c6d75f9e-a626-47b9-8c6f-847987edd24a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fa63a77ff3dacbf19a84bb7a910b972b2c091815b860f6cbf1a9ca14dab574e4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
