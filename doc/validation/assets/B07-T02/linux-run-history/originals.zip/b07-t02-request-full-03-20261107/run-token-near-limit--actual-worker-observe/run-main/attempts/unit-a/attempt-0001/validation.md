# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b022d79d24fab61db6531319e569178c52efba0a443cd640f1924c7a4de0e976"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "da2d6aaacdf270873f7bb9cc83494b5e806867c88bfd18fcf8c21d842fe3e847"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f703f0e154d62f3f7b811c83144bb71d37390d483c4da0c457c3579f33820bcd"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "f89e575d3518c40ad6238cbf4ae937ab6ff07e85673fe91281e7364658b8b71c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "aca09d576ef8a154db5f9b16281b3c8e2f54a05ba0e177bbfe55366e1a633862"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3a7a4f9c53f08a1631e37baa9d5c3191ff47e8b387f1d80937dd269fb82096d6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d71e012c-8048-402f-a1ec-af1daf643336",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "11ccf790-38e2-4456-8a7c-deab9347ebaa",
    "source_id": "afcda1c4-db91-48fd-b4b7-4b0c761108c2",
    "version_id": "7209f031-0c46-43ab-861b-08fd77dd5a86"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37893/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fcddb753-b21b-4795-8240-62059e51b914",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "aca09d576ef8a154db5f9b16281b3c8e2f54a05ba0e177bbfe55366e1a633862"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
