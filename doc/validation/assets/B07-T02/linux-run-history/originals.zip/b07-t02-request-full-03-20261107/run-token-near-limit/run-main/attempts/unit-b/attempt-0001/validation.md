# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f85afdf1d1572265c67134cec32822f873df79c4bf2b999b381085ee564e5697"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b59550c40fd34b52bcffdaa26776c3acb6c42e8147ef7cfee57da9321fd4e2f8"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "469b4cb231feadd80b25837cd4ad4698b0a764ec2eabdcf078ee9dbdbb23bb69"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "22e03a91-cf10-49f5-811e-8945620f4b33",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "42836fa6-c463-4028-a541-9e591a4dc05f",
    "source_id": "79bca63d-6dd5-4273-a87a-4746783d25fa",
    "version_id": "16afa2c9-7094-4224-a73f-9d399dd227e6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37123/v1/responses",
  "errors": [
    {
      "code": "REQUEST_RUN_BUDGET_STOP",
      "message": "REQUEST_RUN_BUDGET_STOP：准入拒绝；未发送并保留Prepared审计。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4e7b5703-a660-4d68-b880-def435ac7c5b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
