# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "99505e9ea465a5799fb43c861189b74cf4fb6a032552556d2251db61ca7fbfac"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5a9cfe55c9ba246bfe1303bf5af66b67bb9aff10961dd765c79692c7a9a49543"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6cfefe809e601bdc35468e6afd36a8fb4cc1ba1233bd90f05dfb3d9299a0710a"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "fc06c03f52baac4e1517778d3d2b0081546cc7384460f6a7a40be4c2f910fff4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2e40c70e4116ee8e1da1b57814abf2eb9d0c9e757e3b4a61472b0c20e4df8025"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d62b4aaddcbb9c566c9f7f998933a850ef33a20a35f276eb13048c62932be659"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "39fda329-619d-4a4c-9f47-5892a9913686",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4bd0a366-c8cf-4cb2-8936-42b48f55d1fc",
    "source_id": "8adfe85b-1a10-462b-b413-d4dfa775c7d2",
    "version_id": "c8f39c40-e166-4d21-af1c-4e5058647252"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37123/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e4ac7026-21b9-46ee-b871-99925aff46d9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2e40c70e4116ee8e1da1b57814abf2eb9d0c9e757e3b4a61472b0c20e4df8025"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
