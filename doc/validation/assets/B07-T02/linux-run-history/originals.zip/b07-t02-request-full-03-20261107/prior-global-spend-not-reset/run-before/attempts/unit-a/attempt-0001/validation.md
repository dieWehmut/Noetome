# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "735363e0f357ba8d2de609e8b1178b78fde48417c408bd91006964c485e10016"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8d4ab463640c4c5bc75047a6f0a18dc74ed7fe5c3ac8275c81d00b591263d2e9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cef53087188ed251f5f510d6e8ebd5928737f765deb3fd5d3c1d55c62c0e48a5"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "9daed87e01601691eefe5cb373f054647456bfda876381cca6e2f17d8dbf5dd8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "36eed2780c5fe10147cd1cbb8eadd6788ee466c6080b2bb80ea4e8724085faa4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "201e6785d5bfee467f786370b4b3f1744e6ce6e29b3c757ae510c36b94e26e3f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "612ce16c-1193-484e-bb24-b190bd19f401",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b3b4e204-6fa1-4c4c-b9bd-ef7f544cae83",
    "source_id": "50d1afc8-b373-4b71-a772-a0a102a385d5",
    "version_id": "3958c89c-91c4-4c4a-8d22-197a0e4cf51a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37949/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "96ea4625-c015-4e21-88ee-4dd188285a7b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "36eed2780c5fe10147cd1cbb8eadd6788ee466c6080b2bb80ea4e8724085faa4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
