# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "347e09174637b38e601b4e3cd42dbb1f23416804bc7e4a00e25c5d405faf9dc9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4166f0a407f379d482e6ae18b7fd8f14a3f2e9aaf71eec1443038726f72d3e50"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cfed967279a0d56db1bfe5786b4610e175a863332da4213c1b40bfb3cc95fb85"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "6ef03abbdb901240e21208f9e18265cab14a7963cae531eedeb33385bcf0332b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "aade6718e04b1b7319534868e546a5e83e94821ed9dac0e713a46cb6c82ec727"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5fa7b238ee8637f8010df39c1112481d22fbbd089bc6fa4a601fef846f5f9211"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0bdf7388-c189-4b2b-851f-68c284eedcc6",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2aa50093-d725-42a4-ad44-6cc9e18f6c23",
    "source_id": "719b4095-2e79-400a-83e0-048416b5492d",
    "version_id": "2ffe48d6-86c3-4c88-bf43-c0c0b4f1547f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37189/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "49d609fe-9e07-4b3c-8dad-32859b7bab09",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "aade6718e04b1b7319534868e546a5e83e94821ed9dac0e713a46cb6c82ec727"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
