# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d5c600ce241045b2d233d8fee682519aa06e5cafd11ba2b8863bd6294e1d14d1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4645b9d7bf654bbac9f806d720f29ce886509fca06b6f3f5ccace1c1e71f2cdd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e6cc7f10b9717924bd5ca08dd72bda35ebfaeb2aa79a70f2b9c8ff91de0872e3"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "08f2c58edb65969e5c4e89a32f338ddccd850571a61af440a5f8188f7e289e9f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f6ab8e6b2196157947d94c64f049b3500b356aea47d811083fa5dbb7030ad479"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "38fa3e2f5b059b7a0b602d0ce349b7cea6697bbe256436046e63cfdb655b38d5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8dd34815-56d9-4b8a-ba12-79c893dfe00d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d7b81292-cf2d-41c8-b868-dee01a71bd9d",
    "source_id": "186ca93a-d416-4f9d-8c08-a6e841bd9547",
    "version_id": "182bebad-2d7b-4abd-bd9b-8d75c6df9088"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37281/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "06e2cf86-dab8-49d5-9981-8cca6a45980b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f6ab8e6b2196157947d94c64f049b3500b356aea47d811083fa5dbb7030ad479"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
