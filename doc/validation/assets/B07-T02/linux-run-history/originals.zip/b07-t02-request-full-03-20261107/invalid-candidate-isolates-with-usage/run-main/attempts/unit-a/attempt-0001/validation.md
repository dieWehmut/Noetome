# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9ef830c0e590e7f27bdfadc44005180cbfa7a0cd1a46d782eb959315458d412f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cfb5bcb377401a5d98749d3ce9d96ccab8b3aa98293f123fa852fe60c396c81d"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "2edc64a9da83a352ecfd771ac2f51281889b67b16830a4b49248f019da3ec5cd"
    },
    "response.bin": {
      "byte_length": 513,
      "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "8554f2707369c57e74d0a014a8ec74c9c7f6b8f6cf733f1d01e162332894d995"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9f9aa87f-27c0-44e2-9063-a6e3ab4c304a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4125905c-5706-4478-9ff5-bfad2886e238",
    "source_id": "d6998d34-9852-4900-b673-922bb91c1ab7",
    "version_id": "d197db8d-bded-4f95-ab77-1a6fea6859a6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37281/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_CANDIDATES",
      "message": "EXTRACT_API_CANDIDATES：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e8b21153-38d6-44b8-b9ca-92b0f1d6906e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 513,
    "omission_reason": null,
    "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
