# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9ef4ebe2758f5c632b13483100c286f5683a27edaf9bfdc4e986526c3c0288ea"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d54684e4eeaeab2974356b97a5e81e1d0ccdfa44622814beba24dca0950b3e04"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "409e8f1ff2b4ac07b2ee56927966c3fdbcb0174569b90c6e202cb0c705289958"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "1d9f8ef247d6d0db7f1a2f511c7d8122fa48ff570b641c2d881f279ff60ec08e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "48b8b3e9666ced1874a6d6684ec973b86921396690afec62d909d280b759e47d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4595bc8dc114b8d2c18c81ac70dd7e016e2b68e9afc6e71b648fdc2601695500"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c1e9e629-7e51-4dd6-9869-9256a2ac3266",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1cf78169-9cb6-458b-b88b-2c6d67d0b8e5",
    "source_id": "6fc363f5-8c6d-4e90-a2b4-615c063d8195",
    "version_id": "b4b75ffa-410a-40d5-be25-8f4fd7b085e8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38379/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9d65cf8a-b808-4a52-ae8b-2d20054b0cb7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "48b8b3e9666ced1874a6d6684ec973b86921396690afec62d909d280b759e47d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
