# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6e82b647be4048d41ba6fd27b5756391d9cb7bd20b74a7c4aa4f22997f083c3d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "80a5e0ad041107933932495a1295f74fae48a4200a1c09f5eb57feab7d5aec16"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b0005bd0e72418a9b2ef408f9f403697c858c9cb7e93d7ef208d3623687e2136"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "f25d5114e36edf4946db32b0092da23505ac1b4078e88edb857a169bce006494"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6152ed9187849dc65ceb702725974de8b7ca0383db151474806e5139fd164cef"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cbb070c48d5d85a35bd879336813a56d79d494f1347eb37f1f73cfd6678d433e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2cef289f-7699-48cf-ac6c-f8e73cdeb8d3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "205e9e1d-8783-4230-a799-4402c411ea45",
    "source_id": "6a36ec15-6db4-4289-95de-08cd9e193918",
    "version_id": "e8a2b9fd-0000-40bf-af55-97814b5742b5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37625/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0a76eada-6e14-4671-bfe5-780de83b22f0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6152ed9187849dc65ceb702725974de8b7ca0383db151474806e5139fd164cef"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
