# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4ebff664df8aa716a62cc45ce517add6b95a13adc6eaf503da9c2a600ce4f2a4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "35d3c6870e0535f5bd7185f776c1618df99fd745dc4b7f59ef2bb4a9b5c5d489"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a94dda31c98b902f9cf20fac3339e1865229e0c64e854b111b05ec980419e922"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "e083fb4256bf5043f795f2f7dc64008c121d3cfcb3ac0f8bc31e238b2cab3c0f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c501889fd7060b7a514d86d47c9e80ac14c19d4930135cd370ed60a7ca6a4cec"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "aaeacf8d14e075a5c59a50e0ae819bedd7990da7816ef67f287293ad1fd7cced"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "49606bd6-a116-4b06-bdc7-519c785f91a3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9c5df0de-7b64-4b6e-8bf0-6916158ea1a3",
    "source_id": "7e7fe566-d707-40a2-9992-37478356c8b2",
    "version_id": "51598598-8968-40bb-9924-3b51e0734d16"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37489/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1062deea-92a2-423e-85fb-5ba2dc8f7ea2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c501889fd7060b7a514d86d47c9e80ac14c19d4930135cd370ed60a7ca6a4cec"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
