# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d43e534ab5a3c63dd3ca6c5c36c702b633a5e74dc7b7cd0db284170e26d0b1d8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "20290dcbed112df7f310f5364f09d65cd281700cc2783d4dfc79ca216ce2d9a2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "54a0d46522743b8e9e04d4a8b309bd563c8359dcb6f809036d419bb5d2ba0ecf"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "a694b3ef669f8353d1e85e9f0cd8c8d389228ec70840f208f9b768e3a8c0a214"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c5f2e8d8633e8717a8190b867f09168b858a9e8af084c05f7b3811253a89412a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "997963a533c5018aa924599737d072eb5df50c0017f2a0a1232d5163537d53fb"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c844e50b-24b4-4562-a030-49365bc98f04",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "30ef346a-867a-405c-898c-5020b79062d6",
    "source_id": "e82fbf70-2cdd-411b-b4d4-e35061c33302",
    "version_id": "9069401d-c314-486d-b240-4698059bd4e5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37369/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c5023d7a-36df-4367-b946-3076f8587828",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c5f2e8d8633e8717a8190b867f09168b858a9e8af084c05f7b3811253a89412a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
