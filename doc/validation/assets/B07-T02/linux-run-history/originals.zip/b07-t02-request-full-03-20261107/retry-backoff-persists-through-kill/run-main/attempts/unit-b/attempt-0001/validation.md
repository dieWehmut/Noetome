# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e7cc00c14e678ec9680a6d1a8873ac48252185989a153b9c71b9a243c2ea2673"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9791e7bfb55895ce9bfd23aabdd7602cd2ce9dafe88c1c5a9bf55b8360a45e09"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0eb3fbb195e3e8684895ff3979047e1e41e8c5c148aacaa38c54b36427c5968f"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "bb8724152ba9abba2b75c13cf786c175e3e2d6112921a0a7109385a245e3370a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "05567a4569f3f46085befd711b70f44415297ae6a62fcb6407c6cc16e49100b4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e12e8e8c69aa780af427c45b79bc9ea3ce804ca76a03ce049a489d155bb4622a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "50e24344-4c9c-4066-ada1-59b9b62fb33a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "87238fe3-29c0-4386-a7fc-a715592bb8bb",
    "source_id": "9afd0664-d1b5-4d2f-a204-455e49bb6cc8",
    "version_id": "3eaa2560-4b3a-431e-acb1-eedb9a06a7c3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37369/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "95dde349-af38-453f-b492-559b6e365d17",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "05567a4569f3f46085befd711b70f44415297ae6a62fcb6407c6cc16e49100b4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
