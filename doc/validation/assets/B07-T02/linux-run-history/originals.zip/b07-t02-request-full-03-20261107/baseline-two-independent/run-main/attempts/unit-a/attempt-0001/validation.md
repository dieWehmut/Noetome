# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e874aac989201b37fa97a8a94ef6a40edfd415a0c81634fe9b1300db85c5121c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "926bc933670cc418d05b4ca1a97e7f8146ef1ca8f1e21e9ee810418c5979470e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "35cd1459053082b3d05718191092bf20af964c46ed52ff3ec2296a11c758f739"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "b7858f3b42487a665fd8cd993dd5a24e1395d4d6f694a4992b9804a36af954f2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9c583aed68f3bbc45e677d7a61d3e5ce6ee40e923a4524eb30924f6bf4cb15df"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "314077b35587ab0a6387f88762c90c53fbf490348e183e5bac28a25f95e22282"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b4b9f6d5-d982-45b6-b914-41088d00494c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "46310efa-4fd9-46f3-8558-4f232041e301",
    "source_id": "3054251d-c940-4e82-b3fd-6e3384677688",
    "version_id": "9502db31-b136-4617-ad86-f2fb235a0c93"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36871/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0cdc853d-8045-4d9d-a8ff-aafe1c9af692",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9c583aed68f3bbc45e677d7a61d3e5ce6ee40e923a4524eb30924f6bf4cb15df"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
