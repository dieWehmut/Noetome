# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c98164bd6d4463a4016771d41ab3e7f84c7a38f4e691b9215540cf422957ae08"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "612c78717f3a2407525db92f92cb8d24f1f0cd8aa279e66babb0f2eb17c5fd7b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fc900f31484dadc147e429af555c4e2f75a24dcd6b3f2b60249769e07587b6c6"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "9445ed4be6e4799660159a8f07bb241ba0d247e82d5f468a3953aee7ee4a9ff7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "28093a585f228e3532faf89a4082ee87ae973f9f4a421f0352a60861cbb8d8dc"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fc08bd5cb37cc5d78856e78f1d071bc4a96eb2e61ea92125cd2a812da67a64a9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "12c29d97-8e53-4bdb-b7c4-933f650d2dee",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8ad7d2a9-813e-49dc-98ea-0cbcd38d7e37",
    "source_id": "1be1a077-32a7-49d2-af60-b5659b2e5415",
    "version_id": "6c0b0f00-d5e4-4704-845f-ff1907331e92"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38031/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a162250c-690d-4653-9f82-db379af08f84",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "28093a585f228e3532faf89a4082ee87ae973f9f4a421f0352a60861cbb8d8dc"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
