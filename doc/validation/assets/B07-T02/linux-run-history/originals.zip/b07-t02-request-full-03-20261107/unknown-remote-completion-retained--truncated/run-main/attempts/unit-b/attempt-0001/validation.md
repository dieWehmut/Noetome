# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "09f15436211742b3ab32a8f0ac31ef4afd37f69ac18ab2248b54a8061dbfd6b6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3abb06d6a689e6012d2e8504696dfcc471d1cb815d17737138dc53ec9d78209f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6ce15fc0b3d55ae8654dfddedc5c4884a818898fcb1fda231422f3cff653b722"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "8f86bdd7432a8570524f3dff36de6cca26f1fed315565da3a1a85d15ca999d93"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c15363f05dc24ec6e7ec0232c5d1814fd266196fd59bb1b83fcce8d07fcd6b1e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "19d373440c4d96b03c505514b762a3bde63b3a14423cc5dff2834080abc8661d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e1a20567-6697-49a2-bea1-fa0efe716079",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0051385a-a8f5-4fac-a2a6-85869372f7f3",
    "source_id": "a3a904b0-ca00-4b7a-97fc-c8a89bc5c6ac",
    "version_id": "01aa57b4-3708-4c5e-86a0-f88d27d955f6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38031/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "159d3ba9-30cd-4113-8eda-7f680cefdb64",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c15363f05dc24ec6e7ec0232c5d1814fd266196fd59bb1b83fcce8d07fcd6b1e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
