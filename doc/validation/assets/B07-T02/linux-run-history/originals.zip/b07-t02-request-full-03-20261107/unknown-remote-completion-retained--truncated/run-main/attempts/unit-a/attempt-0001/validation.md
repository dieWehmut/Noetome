# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bb98e2b2c654098f649e67169ddf809dfa5d8b48da94d7063071929a73a9f8aa"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1a491a252fa98b80193192caab78b9fcfdb676de3a91a0def5c3d1369fa2a536"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "432e5714005e5ffee3777661252b5f748766813630e1220d5254d4192e5ab6ab"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 495,
      "sha256": "e4bd34d3d6f778fff9f12640d50766c84d7dcdbd3e6db67790a305e6408336ce"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "12c29d97-8e53-4bdb-b7c4-933f650d2dee",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8ad7d2a9-813e-49dc-98ea-0cbcd38d7e37",
    "source_id": "1be1a077-32a7-49d2-af60-b5659b2e5415",
    "version_id": "6c0b0f00-d5e4-4704-845f-ff1907331e92"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38031/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRUNCATED",
      "message": "EXTRACT_API_TRUNCATED：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "98bd962b-dfcb-4aa7-b8b8-d43f5c91c14b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
