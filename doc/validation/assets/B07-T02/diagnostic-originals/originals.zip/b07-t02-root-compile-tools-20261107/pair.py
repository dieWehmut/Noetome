from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile

repo = Path(__file__).resolve().parents[2]
root = repo / '.artifacts' / sys.argv[1]
root.mkdir()
build = repo / '.artifacts' / sys.argv[2]
driver_build = repo / '.artifacts' / sys.argv[3]

def pin(path):
    body = path.read_bytes()
    info = path.stat()
    return {'sha256': hashlib.sha256(body).hexdigest(), 'byte_length': len(body),
            'device': info.st_dev, 'inode': info.st_ino, 'mtime_ns': info.st_mtime_ns}

def save(name, value):
    (root / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf8')

def read(path):
    return json.loads(path.read_text(encoding='utf8'))

def messages(artifact):
    return [json.loads(line) for line in (artifact / 'stdout.bin').read_text().splitlines()
            if line.startswith('{')]

try:
    names = read(build / 'source-before.json')
    inventories = [names, read(build / 'source-after.json'),
                   read(driver_build / 'source-before.json'), read(driver_build / 'source-after.json')]
    before = {name: pin(repo / name) for name in names}
    save('source-before.json', before)
    if any(inventory != before for inventory in inventories):
        raise RuntimeError('CLI, driver build inventories and current source differ')
    if read(build / 'actual.json')['exit_code'] or read(driver_build / 'actual.json')['exit_code']:
        raise RuntimeError('a selected build/test command failed')
    cli_messages, driver_messages = messages(build), messages(driver_build)
    manifest = str(repo / 'crates/noetome-cli/Cargo.toml')
    cli_paths = [Path(value['executable']) for value in cli_messages
                 if value.get('reason') == 'compiler-artifact' and value.get('manifest_path') == manifest
                 and value.get('target', {}).get('name') == 'noetome' and value.get('executable')
                 and not value['profile']['test']]
    driver_paths = [Path(value['executable']) for value in driver_messages
                    if value.get('reason') == 'compiler-artifact' and value.get('manifest_path') == manifest
                    and value.get('target', {}).get('kind') == ['lib'] and value.get('executable')
                    and value['profile']['test']]
    if len(cli_paths) != 1 or len(driver_paths) != 1:
        raise RuntimeError('expected one actual CLI and one libtest artifact')
    fps = set()
    for value in cli_messages + driver_messages:
        if value.get('reason') == 'build-script-executed' and '/crates/noetome-cli#' in value.get('package_id', ''):
            fps.update(v for k, v in value['env'] if k == 'NOETOME_RUN_COMPILER_FINGERPRINT')
    if len(fps) != 1:
        raise RuntimeError('actual Cargo build-script compiler fingerprint is missing or ambiguous')
    for source, name in [(cli_paths[0], 'noetome'), (driver_paths[0], 'request-test-driver')]:
        shutil.copy2(source, root / name)
        if pin(source)['sha256'] != pin(root / name)['sha256']:
            raise RuntimeError('executable copy differs')
        (root / name).chmod(0o555)
    with zipfile.ZipFile(root / 'source-originals.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in names:
            body = (repo / name).read_bytes()
            if hashlib.sha256(body).hexdigest() != before[name]['sha256']:
                raise RuntimeError('source changed while archiving')
            archive.writestr(name, body)
    env = {k: os.environ[k] for k in ['PATH', 'HOME', 'USER', 'LOGNAME', 'LANG', 'LC_ALL', 'TZ'] if k in os.environ}
    env.update(NOETOME_PDF_PYTHON='/tmp/noetome-b05-t03-python/bin/python',
               NOETOME_TEST_PYTHON='/tmp/noetome-b05-t03-python/bin/python')
    argv = [str(root / 'noetome'), 'run', 'start', str(repo / 'fixtures/run-checkpoint-v1/fixture'),
            str(root / 'cli-runtime-probe'), '--paused']
    with (root / 'cli-probe.stdout.bin').open('xb') as stdout, (root / 'cli-probe.stderr.bin').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr)
        save('cli-probe.launch.json', {'argv': argv, 'pid': child.pid, 'started_unix': time.time()})
        code = child.wait()
    output = read(root / 'cli-probe.stdout.bin')
    runtime_fp = output['compiler_fingerprint']
    if code != 0 or runtime_fp not in fps:
        raise RuntimeError('actual ordinary CLI compiler probe differs from Cargo')
    after = {name: pin(repo / name) for name in names}
    save('source-after.json', after)
    if before != after:
        raise RuntimeError('source changed while creating pair')
    summary = re.findall(r'test result: .*', (driver_build / 'stdout.bin').read_text())
    save('actual.json', {
        'status': 'built_source_bound_pair_not_full_acceptance', 'source_files': len(names),
        'source_before_after_equal': before == after, 'source_archive': pin(root / 'source-originals.zip'),
        'cli': pin(root / 'noetome'), 'test_driver': pin(root / 'request-test-driver'),
        'original_cli': str(cli_paths[0]), 'original_test_driver': str(driver_paths[0]),
        'cargo_build_script_fingerprints': sorted(fps), 'actual_cli_fingerprint': runtime_fp,
        'cli_probe_exit_code': code, 'cli_probe_pid': child.pid,
        'cli_probe_stdout': pin(root / 'cli-probe.stdout.bin'), 'cli_probe_stderr': pin(root / 'cli-probe.stderr.bin'),
        'build_receipt': pin(build / 'actual.json'), 'driver_guard_test_receipt': pin(driver_build / 'actual.json'),
        'guard_test_summary': summary, 'real_model_calls': 0, 'paid_calls': 0,
        'scope': 'actual Linux source-bound CLI/libtest pair; product HTTP, OS interruption and native full acceptance pending'})
    print(json.dumps(read(root / 'actual.json'), ensure_ascii=False), flush=True)
except BaseException as error:
    save('failure.json', {'status': 'failed', 'type': type(error).__name__, 'error': str(error),
                          'real_model_calls': 0, 'paid_calls': 0})
    raise
