from pathlib import Path
import hashlib,json,os,subprocess,time,sys
repo=Path(__file__).resolve().parents[2]
artifact=repo/'.artifacts'/sys.argv[1]
artifact.mkdir()
def pin(p):
 b=p.read_bytes();s=p.stat();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
def save(name,v):(artifact/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
names=['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates/noetome-cli/Cargo.toml','crates/noetome-cli/build.rs']
for top in ['crates/noetome-cli/src','crates/noetome-cli/tests']:
 names.extend(p.relative_to(repo).as_posix() for p in (repo/top).rglob('*.rs'))
names=sorted(set(names));before={n:pin(repo/n) for n in names};save('source-before.json',before)
env={k:os.environ[k] for k in ['PATH','HOME','USER','LOGNAME','LANG','LC_ALL','TZ'] if k in os.environ}
env.update({'CARGO_TARGET_DIR':str(repo/'target'),'CARGO_ENCODED_RUSTFLAGS':'','NOETOME_PDF_PYTHON':'/tmp/noetome-b05-t03-python/bin/python','NOETOME_TEST_PYTHON':'/tmp/noetome-b05-t03-python/bin/python'})
argv=['/home/lyinn/.local/bin/cargo',*sys.argv[2:]];start=time.time()
with (artifact/'stdout.bin').open('xb') as out,(artifact/'stderr.bin').open('xb') as err:
 p=subprocess.Popen(argv,cwd=repo,env=env,stdout=out,stderr=err)
 save('launch.json',{'argv':argv,'pid':p.pid,'cwd':str(repo),'started_unix':start,'environment_names':sorted(env)})
 code=p.wait()
after={n:pin(repo/n) for n in names};save('source-after.json',after)
result={'argv':argv,'pid':p.pid,'exit_code':code,'elapsed_seconds':time.time()-start,'source_count':len(names),'source_before_after_equal':before==after,'source_delta':{n:{'before':before[n],'after':after[n]} for n in names if before[n]!=after[n]},'stdout':pin(artifact/'stdout.bin'),'stderr':pin(artifact/'stderr.bin'),'scope':'actual Linux diagnostic command; not final source freeze or full Linux workspace acceptance','real_model_calls':0,'paid_calls':0}
save('actual.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
print((artifact/'stderr.bin').read_text(errors='replace')[-12000:],flush=True)
sys.exit(code)
