# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0c800c2f6dab75f6e06aa29012f598df862320670f398a424912e099debfc283"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3c09266bd05065112161c8b2f6c0cab0f7b3cf30876fb2f41579b6fac371dd31"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "33f03ee16e43cb11e8aaf32f7eb553cefe915b0b99ac28d62454ffcca0d9d899"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "8bd3aab92be63fdaffe8d4f4795ce129299ff3b0353002b60ed7bd49b7aff56b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "322d5b8ee964cba2ae42b044011ffb6af4b0aa5e0108125b76085afaac2b0b86"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fbde90b8eafa51fb61917b3e92c61243bcf88412f3b25a3222fa728eeedd0c0f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "409b4382-9270-493e-ab4f-50c880d773e2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "10c3b6e1-014a-4c2b-8d00-b8a4a9074087",
    "source_id": "bdfe21c1-824a-4ef6-b833-0a62ea245028",
    "version_id": "2bd3dbfa-496b-42bd-82c7-34fe9b8299f0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37547/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a54a3f42-af4e-44ac-90ed-1f1e1dcb2695",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "322d5b8ee964cba2ae42b044011ffb6af4b0aa5e0108125b76085afaac2b0b86"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
