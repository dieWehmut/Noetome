# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：503；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1941c5bfa799f316f92cd150b072fd9fa75741c51b3a36a5415b786f43b12fc9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "db6feb1eeb9581a618f9627c857819117ffba5a22722fd9efd903f90bfd978c9"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "d0956d166dff4f7d0dfb14fb3f150de2273dbd7414d17698dbcc2b161c23ccb4"
    },
    "response.bin": {
      "byte_length": 131,
      "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
    },
    "transport-receipt.json": {
      "byte_length": 498,
      "sha256": "4a96e0762590cfafe9d3e1f74dab7265f53b6a9923908c740445e8bbcbc72492"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "409b4382-9270-493e-ab4f-50c880d773e2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "10c3b6e1-014a-4c2b-8d00-b8a4a9074087",
    "source_id": "bdfe21c1-824a-4ef6-b833-0a62ea245028",
    "version_id": "2bd3dbfa-496b-42bd-82c7-34fe9b8299f0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37547/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_SERVER",
      "message": "EXTRACT_API_HTTP_SERVER：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 503,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "de31809e-5f1e-4dca-9cc1-906732ff5372",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 131,
    "omission_reason": null,
    "sha256": "de3cb8fb5343a29f446091c674e9994c3a056850a2f7d4baeeaef57bb9114e66"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
