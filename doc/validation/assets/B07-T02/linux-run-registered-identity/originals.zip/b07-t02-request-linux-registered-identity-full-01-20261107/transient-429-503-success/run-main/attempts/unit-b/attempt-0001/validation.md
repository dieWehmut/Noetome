# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "39849466ea95410779d88f43d0687e0519a5da454ae8e5e9531c35a7561326a8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "372ebd425b4e935391845ec48da8a7396185d48d9f130c21e9895cafd40e5d7f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ead9c521933015da8bed9bd063f0cc8a1f5064ddb95aaf8baca0019b600d09c5"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "7b562c0b4dd61fb7269a29a0cfa047f7abcaeeea3ced7d13ce3ae3bee479c234"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9f0e898405764f4b45b67412da1085165a1110a5cad4562e2e5d53f0dd02ac58"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fa2204fdc53ecdce26a4c4ccfc4f63c9bb06c0fd94a3d97af8082af457f5c8d5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a4021c3f-f58e-4ede-910a-b71ef9c50f6a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ffd51d6-813a-4930-8189-fdc5d6bab1a6",
    "source_id": "16a771e2-ba99-4f4d-8563-2db81cb51135",
    "version_id": "7c334bc4-3550-4b74-969a-6a5fe7f49641"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37547/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5d824144-1afa-46f2-9092-afd8373fbe8a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9f0e898405764f4b45b67412da1085165a1110a5cad4562e2e5d53f0dd02ac58"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
