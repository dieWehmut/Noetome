# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f15fdbd0ae48f2f07734aee8a26958a22ff7f4ff21bc135e8edab2f5abd95506"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2b25825ca3211c3de714d58f5fca9cbbe269350e9d6621b46446652e395b7ff3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1f8095e9584e1d712921a2ac527acfff8ac4b6f893969d5c0a3cb115ee4b0387"
    },
    "request.json": {
      "byte_length": 2241,
      "sha256": "49f758fc5f5dce7aabc638588a7e034f5d4761856b9d1be0c7576eec86e53b7c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e4a579b8f2f3e4605ec19f387962b40788cd58f7ba5f5f9c1e2e4eed3b52ff80"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "925ed4aca154b5e9f27ce91531ab0158129e070f1fc6ea03fc2ef11d0ffa0cc3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fe08ec8e-edc4-4008-81fa-2da3c6cd9709",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f820a02a-09c0-451e-b29c-2ddead35f8c0",
    "source_id": "e8aa96d3-92fd-448e-b97a-d28c94cac8f8",
    "version_id": "9f1dccca-a6a5-47ff-988f-a508224b77af"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38281/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0cb1092e-a9cd-4f64-8b64-df95a12a28d0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e4a579b8f2f3e4605ec19f387962b40788cd58f7ba5f5f9c1e2e4eed3b52ff80"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
