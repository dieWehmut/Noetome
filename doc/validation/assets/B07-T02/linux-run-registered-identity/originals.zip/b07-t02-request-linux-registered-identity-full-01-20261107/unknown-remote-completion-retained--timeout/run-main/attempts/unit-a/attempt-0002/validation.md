# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "734f3e2249fa96025e10b88153c893e8601b1e7afbad237911540469732592b7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c739522483ad0b96c302796a8ac0b02d157a9ed667f377e730443706e8477ecf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a354df60c0b8e11700d3e88741bc2bd20863beb8722096394809b3c6432797db"
    },
    "request.json": {
      "byte_length": 2246,
      "sha256": "c882e1e2cf837f0caca956e45eeefe53a2b5c4165ee7e46c7dfe5391e4784c8c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "67517b1615fed5fe6ea07446b56024254ef6a860b3ee7a68964cac3d921d1d74"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b0bef13ccbcce0d0f1bc109a78ed9d6f1bb0d99d2d605669c03e29cef4281146"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4454fac1-3cee-4e2c-90ee-a3d6322eef1b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0a672670-f6d2-4680-99b7-38a30100c017",
    "source_id": "49757ec9-be14-4add-8ab9-55c21db20eb1",
    "version_id": "a339e9af-21b0-493d-9976-002f97d28714"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36677/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7e1556b4-ddd3-4c07-9cc8-53cc6ae2265b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "67517b1615fed5fe6ea07446b56024254ef6a860b3ee7a68964cac3d921d1d74"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
