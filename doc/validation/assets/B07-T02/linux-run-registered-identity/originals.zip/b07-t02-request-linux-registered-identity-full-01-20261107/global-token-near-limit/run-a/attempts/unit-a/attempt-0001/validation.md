# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0ee9ef3d7039feee047e933689139d8264bdea4112bb1fd1c154bd445bb61963"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e6c5c36d0803e3a795cd66654222bff04b342482515aa7eaa87fed1186c1dbe0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2280efd8c47efe66119b933491026539f8f923caba235fb144ef034a31b3e49e"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "fe9804795a95b9703bdfecf8c88db7f92ec8cc865f1677b5dbcdee6d8480f034"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d77e757289e95813a4b717f0e23367c39254ca8a8cedecb04256cfdd4602d5c8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5f21017e4fa5b8703bfb480535f0b3c859d011583ec30fd5a4d98a2297937def"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "70f3c8e2-1226-4cc6-a223-352c5e74b7e1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "12b7501e-3d08-4a37-8f1c-eda5fbc43033",
    "source_id": "1161da41-e72a-420a-8ad7-3854a51e40f0",
    "version_id": "4d940a85-25cf-4e48-a1c3-afcaf186181f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36447/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2f8eb115-7c02-4e96-bf95-f1853f9781a0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d77e757289e95813a4b717f0e23367c39254ca8a8cedecb04256cfdd4602d5c8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
