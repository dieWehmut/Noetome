# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5c540867c8b119e816bd1025419254da7df5de4459153fc5ce6ed80ee54d46c7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "83e8a0ba30cac88cd16a81dcbe261a83960d1f477993777c83af11dd6649409e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1f6d54a6ddbf622eca686e417a7f7acb1b35292821e7f2a147cda698180614af"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "bdb5cc1b723555454a0e56c85e82261faa46091670149129bb335b79151be553"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0e394cd2cb2f5e9b41d9619360fc08f6eec0dc66e24d820d806431a467069500"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bcfb95637df31694c29ebdf9a36089dc550a41e91244226305b05cc2a7631588"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3b300ccb-c739-41a1-8f0b-568ea94a1875",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b57bca21-cb5e-4fff-ad69-695eb58cd37a",
    "source_id": "2f271bd6-61a5-465c-aead-ff4f2bba4c80",
    "version_id": "cd886ee9-f2f2-443b-b8e4-53944e418882"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37027/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c08706db-af71-41dc-a45a-a3e006ffed4f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0e394cd2cb2f5e9b41d9619360fc08f6eec0dc66e24d820d806431a467069500"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
