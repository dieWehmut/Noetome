# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f88b4792ab9919a7403d8adbf915c38e35fe8429bd1b41e7b15c427f41807f31"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "57fe0c1ffb09cd2e9f4ee5a6b467cdef69800ee96b3c7a2c6c98794d4c6199b3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ff29853656d43c049d48dd53efbb0cbd0991c95e72db0a1f0fd2a2b480aad513"
    },
    "request.json": {
      "byte_length": 2251,
      "sha256": "ccccea1a8f0b143a155ca5b4bc657c94b295673e0ccb963c5a455f1e86d8dee4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6bcb49a8b5f7890c6a8c704a96a5c0e7c500233ce35c7661123e7db930331c54"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0a5c4c52a823a2617c70c290367aba956dd8151709e2f169999e11ee9f9b5b17"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3daa89de-2eac-4ee9-a358-f3eb865bf932",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b8bb22f7-7e9c-42ba-aa9f-37b417f27ec7",
    "source_id": "46fe2b51-cd49-418f-97d6-ce4dba8c3f99",
    "version_id": "7d4e6092-c592-4791-8ad0-472e929a9297"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37555/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fd47760c-d3e1-4b45-a23f-e619c808411f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6bcb49a8b5f7890c6a8c704a96a5c0e7c500233ce35c7661123e7db930331c54"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
