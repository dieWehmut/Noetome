# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bd62a1872cd81dd480dd5c68026fb7768c45814c84ee01af3a556a93ca81a5d2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "08b4a3a716dac0acae61c9d4bad71ca42be3d35020469581a3cdf6a4f914e83b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "22db9873fc94d30364b1347e4bd3e4ace16a93f2410bd0d32599575100468cc3"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "863a6e82b2427b9217ecca9f20cad6d13c4e6c0c3965a72440d07f98c0bde5a7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7288dd368a54ebcaceb85c79935a3334f22d5cf8545359ed2551dedcb6397618"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "54354a001b91ee1d652925e3b33cd09444ec2a082cbdffc09deb7a97919a68c0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "58d7f53c-3481-4e4e-8938-4520126401e9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ae333c44-4d7b-4ff1-9acb-46cc094fd78e",
    "source_id": "90b6341f-85df-404e-ae8a-2bfb86a96702",
    "version_id": "46bafd3d-c8f1-48d1-9bd4-393a45715116"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38109/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "53a02d9a-bfe8-41f6-86f2-9c43fe56edd7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7288dd368a54ebcaceb85c79935a3334f22d5cf8545359ed2551dedcb6397618"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
