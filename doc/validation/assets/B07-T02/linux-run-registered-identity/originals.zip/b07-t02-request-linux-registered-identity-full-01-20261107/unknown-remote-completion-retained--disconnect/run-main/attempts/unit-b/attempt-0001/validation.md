# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "02af5e115d1232ec1acc53fb01e5a6e4f4f8d69e9ba8844c7b87d3303ed886bf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7bd261a6408269aea22a59d011f7545c143e0f841a7ff18c55d7863a613617f5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f811e41f47b65504e8778db462117fa02bb5cbfa9febcda260aee57110fac574"
    },
    "request.json": {
      "byte_length": 2249,
      "sha256": "10f79b350d2e9760b6b3799195c71e54b712b836b2af202ca99d93c0e702319e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f45336959b3cf8ab9da5e74a67603e224cb9f30cf29a5aa4ec9e82c7c180884d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b781271882bf85f483c8abc5d8172b05453816b812f6b4e3103d72a177213af9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e524c665-bd77-4207-919b-abace42a1de0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "05dcae11-d02a-4549-8dd8-f700aa5e9dc3",
    "source_id": "ea1d7a28-c626-4f72-a96f-343b99d0cb8f",
    "version_id": "8e6567c8-ed4d-4fdb-af8f-d851b24ffa33"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bda7b99b-a734-4cd7-87be-9b39dd63ccea",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f45336959b3cf8ab9da5e74a67603e224cb9f30cf29a5aa4ec9e82c7c180884d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
