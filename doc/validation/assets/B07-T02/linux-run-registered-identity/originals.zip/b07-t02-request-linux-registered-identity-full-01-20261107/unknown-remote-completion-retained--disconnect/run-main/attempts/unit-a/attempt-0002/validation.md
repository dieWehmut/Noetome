# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cbd19a6a1e6ee1374cf131fba146dadb58f9bc19698bc3d01b9754039a440ea6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e2b91c3d6f643e2eb5558f6426bdcc5223c4658a61763574597d1a314174b558"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1fad5b9529062b9a88237ddfe0160178749fd5354dcfb552eab65c84e361715e"
    },
    "request.json": {
      "byte_length": 2249,
      "sha256": "6d1411f59ad4ce382d0624e02414632d28d32c1e34b1e36923b6c145d78a421b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6366c20685ed073d613716ffce02680e6b2340dc3f6d974a457a3bbd73302e67"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b4af3276902e777816b96a0f9937a5f84bd3b679d4c3c3509fd8175ac44e3931"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4e7e52c4-61bd-4353-9fa3-05a249f47e10",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6edf6862-6cec-4b60-afe1-aa3933ae8f5f",
    "source_id": "4677b103-0416-4ab3-a801-3df7511284a3",
    "version_id": "c6953046-cbf5-4482-835b-d89cc33b2753"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "25337fbb-58bb-4156-9187-4ac5a2e4ec06",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6366c20685ed073d613716ffce02680e6b2340dc3f6d974a457a3bbd73302e67"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
