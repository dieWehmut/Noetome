# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "831382c5d93824c0ad488b9008fe16151c5923f1acd838bf793c4d208c8501b2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d7d25f36fc17a5ff14d9f2bb0f03a0778d481ffc9bab68241b8f7efb47518622"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "431465a3ead7e612f9b66c8465951bfa50b5324750e84844906f2dc16267ca5c"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "8995e9e512d145d7eef7fc8fefc9dff41546e438a892943429a93b7fa8c32aca"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "cedf4fa9c9101145a2d222c3d40d8f5076110001cc24c56bb6f269df3ffcf5b3"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fc43cf2bd87927180952002774698e1e96bfdd773a925bac431500b01ec14752"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7c5dcde9-39a4-458a-9bb1-e66a5ac5ed33",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "127b8aee-09a0-4a1c-bda7-3ab659afe90f",
    "source_id": "25a49269-7509-465e-a15d-70cf396fba88",
    "version_id": "614f6831-6203-4a90-95f7-828802cc75fb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37727/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d63ea7ca-d11c-4500-8fbc-9e8547bd241b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "cedf4fa9c9101145a2d222c3d40d8f5076110001cc24c56bb6f269df3ffcf5b3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
