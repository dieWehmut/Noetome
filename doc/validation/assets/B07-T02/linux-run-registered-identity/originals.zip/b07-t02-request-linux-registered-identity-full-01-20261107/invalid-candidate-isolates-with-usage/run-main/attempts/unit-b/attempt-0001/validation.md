# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "256aad6a1cf32813d505a8c12da5d845a58b53c25f4a5e1d8465a18d04407057"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1f900be9b7d325c0f5ec4feeb67cf9fd57a94a287c8626a3ee34152fae469c6b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2ee69c03299e76ab9b20874deac4e1f71b4fe6e990299c802350453967d60f55"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "ede83493a32753804bcb10a13aca77d3ee3cb09235ed3c7d6ffb054bc9dc9db7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7b37cff33b025d78d73b945bd9ffecb5bb24a84fe3aa4be0609a29a2bece6596"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "64f426ea3d49e5adee997db651e185b7d08172b68136150c5dbf003e4e4eeb9d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "414ad60b-e14c-4116-8c97-896d13b35d76",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "06af4e95-1ba9-4977-a100-28ee897eb1cb",
    "source_id": "8104c231-55af-4896-9850-04b0e0afc0cc",
    "version_id": "93cfc01f-1a9a-412c-bef3-489535f4a2b8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37675/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2efb76c8-2c9b-4f2c-a968-4ecc089b04e3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7b37cff33b025d78d73b945bd9ffecb5bb24a84fe3aa4be0609a29a2bece6596"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
