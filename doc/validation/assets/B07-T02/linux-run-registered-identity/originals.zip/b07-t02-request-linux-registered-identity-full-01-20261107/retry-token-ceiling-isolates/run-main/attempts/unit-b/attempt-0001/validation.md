# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5b58c9d8953cdeea0fffffda357c05b5d7725bfe5b23fdfe2902d055af9c0762"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "32d2f0b880d4e3b7909b171b4dbc9bdeea6afcca2999f703939646a327c59e53"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "477fdeff83b16705281ecaf4c802c7da096347fbf889cd472568bf48c608d866"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "6ae0aa0e5e5c0b275d7521f2c55730f8784ac153a427e1025c8aaeb3bced5714"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6ed7e4f652609564378c057a253329ac749f8f36215281111ab4bb8925c40de6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "448daf4c636101eba069f4605de1b34d9bed9764c14cece2d3da58710e5a3d3d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "14369b2a-3356-4353-a01d-8204282871e8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b89b2275-0ae1-4749-9477-35c86670b3fc",
    "source_id": "0eb26bc2-1ab6-4f88-8003-e3f163e1afab",
    "version_id": "f1a1ee56-f41b-470d-ac0c-9a2d676799db"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37983/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ccc08ef1-6598-4a65-93bb-4a496d98a9c3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6ed7e4f652609564378c057a253329ac749f8f36215281111ab4bb8925c40de6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
