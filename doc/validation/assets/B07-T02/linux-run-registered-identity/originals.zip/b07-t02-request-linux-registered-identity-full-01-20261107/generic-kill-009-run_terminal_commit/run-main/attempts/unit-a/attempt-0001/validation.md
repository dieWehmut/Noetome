# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8fd37991c8ea48bcda00da9a12e05ce60c3535f0e88cbaae855d80038df77d11"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a202cb3b307f323c56b6f45284d5a70a69101d42060f0c86cfa681d1cf8718cd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7120dfac2eabfa0b2e820a9ca2b5628d02bdeb3fa9cdb7a88ae10bac11b12ac8"
    },
    "request.json": {
      "byte_length": 2239,
      "sha256": "cea0db39fb9babd36a2f0ffc9114c9325b0819a44f8f686bb43ac5aa3da23f9f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4b588d570ca9e1662a49a60d31911acde9e4b99996972d975e85c67ed81678b8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "efa3dbbee2c7dfaf0ee0d7a7c8bb23a9c55babed061de4cc799cd6ed12090e1a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b3fe3265-ff63-4565-b4b9-f25a2289c19e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5df5c38e-9d70-4ab1-96ff-25951d48d46d",
    "source_id": "0c444414-59f7-42c7-a08b-1ba43c3d7234",
    "version_id": "68181fc7-70e6-4619-9825-6ce265a0f430"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36927/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c08c8e81-c999-4059-8aa2-da3f8390f043",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4b588d570ca9e1662a49a60d31911acde9e4b99996972d975e85c67ed81678b8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
