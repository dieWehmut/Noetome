# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "951bdb1de9c7288a2198247481fd8c9f531aab512e8ab0216bca7b2e40606978"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9335a6ef7b54133cd0d96a2cc7c5728a54880e08f6b0c24fa169c8b7326098d9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7e1421740f69239f0faf18503ada2de39d961f304e5226694eecc1a2f86c1f0a"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "3a82d56511f713f4aee2f54ce96035f63c668281435aeb370e4b1b2c2b45edc6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f29fb9436c89750c67e89cb85b52d75b6c7fce1f0c21bca06bd23a9ec54b1fe4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a8dbf97c0e6b6bb3521dacc46d1d5ef257ff64f503a1e8ba4336615d6eff9e9e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6e8bb739-a692-4b3a-9f4c-7468f8e8f850",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "21a089fc-a152-47aa-ac7b-69b0ad072c5e",
    "source_id": "ff38c1d1-2bdf-424d-969c-a5bf2a0b7626",
    "version_id": "61fca8d3-be33-4011-a14f-64d0f4360b97"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36683/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "88ed36b9-69a0-4b6c-948f-91548d091fcc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f29fb9436c89750c67e89cb85b52d75b6c7fce1f0c21bca06bd23a9ec54b1fe4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
