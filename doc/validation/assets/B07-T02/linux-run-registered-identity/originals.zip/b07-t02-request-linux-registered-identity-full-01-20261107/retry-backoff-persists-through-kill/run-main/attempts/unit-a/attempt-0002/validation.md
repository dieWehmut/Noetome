# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a5e8df1ea33cafeafea479eb68dcfb4565bc1944435632612d0abc479e8e0e44"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8fa0a5869cf6162787598239d67cf1f2fdb31477b051675233c8c1eef1d28886"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "011687310910ab26f4abd2ca7fce26f795296a86f70f8954c5dfb201b431d9e2"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "21e84ffb8f5c69518ddaff0126b8d703768749c359dd0fa6a32d4c60fc6921e3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "03eaa771fc3e666ad3a706ab288dffbee3a0bbec83818c6edbfa26df79466d95"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "47bd26bfef53f2ddaaba408c2f74a1733f7da028a53b9d49246ec7a62fd65f45"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "454e327d-0f2c-41cb-93b0-6bb4e441c159",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "122ffb7f-d4a4-468a-bb23-39a62bcf36cb",
    "source_id": "e2b29467-25be-4f80-8931-785c13c046d1",
    "version_id": "8ff80f9c-6a49-4867-9e3e-0ffcdc8516dc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36451/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "49b89424-8505-4410-85db-64103907f7d7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "03eaa771fc3e666ad3a706ab288dffbee3a0bbec83818c6edbfa26df79466d95"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
