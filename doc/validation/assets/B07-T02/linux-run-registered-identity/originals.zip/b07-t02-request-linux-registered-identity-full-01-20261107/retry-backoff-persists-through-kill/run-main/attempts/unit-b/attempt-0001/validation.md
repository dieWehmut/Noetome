# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3c7a9e7c7f9f959e29a3c6fe901c4188ce96b0c6a920bf38857fb11dbbe3712b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e813f6c1368555cd8a9fdd3fd516564284f1e25ae71b2a05c4d36d821978f9b8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cad4016b494eb7e4011c12f90da92c58625d070fa8c536e87c61734c99456d5a"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "6361b282e1ab71f8577a186e21b4f8a30c7524a9bc73283d00f2844905658895"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8571669210c4991fb577d0ae884089cf92f09ead245044f6c18a458b609ba977"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "73426cf710a8df2996b9d01114d79ba34f3a592330524a11f9f2169fa1ef8924"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2a882109-d814-489b-b169-36d6dba08d8a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b1e90ec6-4de0-433c-a976-ae316d198c6d",
    "source_id": "8f9f4fa4-e712-49db-a2f7-021029a30443",
    "version_id": "fbdf924c-3664-4099-adea-f0a3b87caa08"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36451/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "577675db-e69b-41e7-9d33-15cfa5129b0f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8571669210c4991fb577d0ae884089cf92f09ead245044f6c18a458b609ba977"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
