# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c194ca70ba1dd77d6d47009f7c294ff5309abbd4437909218a9549e38693b969"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b9327ccc7c6bbfc7d9382472da5730176ed6eb0aa2c1c7be4dfcfd0cc67cd115"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9978cd6b45bb4e36ec1455f021eefd5ba6c874a6e58608f92a0d39c581ca7ea2"
    },
    "request.json": {
      "byte_length": 2249,
      "sha256": "5444447b2b1cafc38bd706ee0f3b478a244b6137df58193374fd391b6ca325d8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "76703d91d173ba22eaf4732ce389a6de5d7b8422e89aee7da844b4d2cba36127"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a2f37c92a41879eb7e56ea30d8248d42fadb9d721a38708adf014f1dd9deb023"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b2b8053a-6a6e-408c-b890-dff5b4358e85",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5356113e-d417-46b3-8556-be1f0f279074",
    "source_id": "89426a8e-0920-4a53-b050-87536ddbd052",
    "version_id": "0d924406-3874-4401-88b3-35b7a4fd0134"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37009/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f1ce8150-7624-43ee-baff-1d0fa1a5ff57",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "76703d91d173ba22eaf4732ce389a6de5d7b8422e89aee7da844b4d2cba36127"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
