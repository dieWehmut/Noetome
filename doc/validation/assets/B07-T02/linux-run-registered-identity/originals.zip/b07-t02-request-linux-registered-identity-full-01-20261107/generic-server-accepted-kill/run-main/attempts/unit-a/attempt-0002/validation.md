# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9d419b145fb6384dbeacafef8450e3019ac4f23b68b0990466dbe5816e8c06a5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8c9980d575c0594a55feada2c50d89719b6f9a84f27b237fdc08c4ed51876ebb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "847785db50ccf8b79a4dd3ef63ab8c79aed13f1d1c66a5188e5ddb388f7e9303"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "d01ce68957ab881eb216b7b84a0a8047db143c7820c789d9eee0b0498ced812b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "121b447a85f74f8b735f9ea9efd5535ea28f84b1f613b44c351d37a1a0c094e1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "087b82f795f11686f77bd0583c5d71f7699da7ce7ff218ee0089f4d7005fa7dc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "93a5f5f1-4806-4a32-8dfc-cb408707cf25",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3edd719f-78c0-4ce2-a80c-9f3c4674918e",
    "source_id": "1ef78073-1c11-43fb-9a0e-ffb1d00519b8",
    "version_id": "55f77323-3a92-4d0d-8703-881e65108355"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36691/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6b6afce0-2733-4fd4-b048-1ac14ce58897",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "121b447a85f74f8b735f9ea9efd5535ea28f84b1f613b44c351d37a1a0c094e1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
