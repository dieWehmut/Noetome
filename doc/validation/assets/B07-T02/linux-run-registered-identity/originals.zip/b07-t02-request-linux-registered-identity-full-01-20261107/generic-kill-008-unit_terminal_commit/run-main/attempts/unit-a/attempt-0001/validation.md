# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d77e97eeb0451f374dba543f539cf77bda6e3afd410c7e99422e94ce34b171fb"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "bff9e914469632c4d6bb40bbfacf2b038e73202e8d8b93c2ab22a9db73065848"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bb3dcbe9acea874418b62dbb6cd41dbd3c5fd8e31e11cd0777947702905e9eca"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "2788d6fcbbe995f9df3a7855f5fe798173ba1cbd7a721820c2f403027d4e178e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "39651284fd97ff5dc32e967187df532ad8859c8f1cc771c74405f17a89912414"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7e224b96c6d6c4d7d26d5c63e043d5aaf7e09354843d8d833ce131bb2d80fd1f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cba18da9-0b92-46ba-838e-81a6ea2050a0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cd3e7f7b-ae53-47b2-ad02-e42be697df31",
    "source_id": "db6b2b6a-7e75-476f-b126-b5ddd0cbc0c8",
    "version_id": "1a3b16c4-25c0-4087-8780-a1790845ca22"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37693/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6a093b92-7a3c-477e-9a53-f5134e4c17a5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "39651284fd97ff5dc32e967187df532ad8859c8f1cc771c74405f17a89912414"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
