# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "044589210beaf4fcabe834f90e562d4cf5cdd6807cb32cda83fdcfdc51207c5c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cea6bc7126c6f3eb437c25e42a6f4f90c4e4977c09a3ae4888b373c84a7201e8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7aff0b93b79f539a93be74c202a86e4f02b468062c34a73773fa41758f97a386"
    },
    "request.json": {
      "byte_length": 2248,
      "sha256": "5eba5a5bfe338866ecfe5612797664662bc7f420b62620f220edd7b2780fd4d1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ca8163399d2de756a4eeefbd9abe07a723d1eacab00f22519423c6319342c773"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "259b028ace620d0b46e18834473bbabf068427caf8cc0e9841d403380a79d533"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "84ee4ef8-36c1-4e8d-9021-d8e16625004f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "516ab478-9d5c-4f5a-8265-e05a640a2284",
    "source_id": "0c1f28d9-a483-438b-a766-33d9bf08043d",
    "version_id": "9518ca0f-9afc-406a-ab8e-d8255fd3d60e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38327/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "56450294-442b-46b4-b386-64269cd37f08",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ca8163399d2de756a4eeefbd9abe07a723d1eacab00f22519423c6319342c773"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
