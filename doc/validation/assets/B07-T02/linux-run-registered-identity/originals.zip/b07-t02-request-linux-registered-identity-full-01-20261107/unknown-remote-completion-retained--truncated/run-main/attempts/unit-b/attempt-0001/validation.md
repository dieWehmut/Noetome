# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c5f40b61ca643301d0b26a7286a0d8ef06238d81ce424de9effb011a50e5afa5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7eeb7b2607a71ff180b3f1da823aea12543aebbaf3ab99f0ec669dfcfd8f9df8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1f669742446d98eacfc34ff738d190f81b19a08b84c439252edec2930392f2ec"
    },
    "request.json": {
      "byte_length": 2248,
      "sha256": "78df28318005f8bb778e7a116fd4a3fe5970b222aa39f19cf8d65d6e30d35cae"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "72cc5bc1e413fe5fdfabc3e06292ffd8ccc04dbf2c27aa1f7461e3b6788392f1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8cc9b8d7a23d8c1bdfe509436582fdb8bdfb1edc041130d45db8b57d87ed32b3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cddb9301-2b13-4fce-8b22-b2ad3fb22447",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "59588e2a-34f7-42d3-aed4-fee6494d23b0",
    "source_id": "0ab8b6a5-daf1-460d-acb4-054b738732cc",
    "version_id": "806a4441-2c40-4890-bde2-c2ed3e2c32e9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38327/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b783566f-cc05-4606-a3c9-3eea0fbaefee",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "72cc5bc1e413fe5fdfabc3e06292ffd8ccc04dbf2c27aa1f7461e3b6788392f1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
