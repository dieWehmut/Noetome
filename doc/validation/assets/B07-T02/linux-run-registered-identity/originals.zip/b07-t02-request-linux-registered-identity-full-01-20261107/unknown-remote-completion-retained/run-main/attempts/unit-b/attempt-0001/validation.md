# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e209afaf6bec8762bfe775eea551f366ba010ddac24aeb342bd7f90b992cb26e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4678156c904321a8fa41a57afd47e24dc6bc9e476d77f591783fe4a6cfe25695"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fc7ae8cb8b7b770681d905a5d93252cbf589dd1132d31a954a8af51cf35f2efe"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "bcc3d4331856e712ae3de47877de685dc3435d8584bd29e00f2f65f5ba815a61"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5e3c7dcc42f6dffa412a270633426866fe7bd154d49b9554efe424942f5b058e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cf00e37eebde4697cd7b9f74262d9d04b165f82a35970feda80cd53bedb32238"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "822b07d3-601b-403a-b2ae-7349a6c64530",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "449dce14-404d-4bb8-9180-7c8e838c03b2",
    "source_id": "c409b49d-e0cb-490c-a2c2-63fff921b814",
    "version_id": "21258e53-b96f-41ce-8e9f-4757a4ac18ed"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37163/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "da4887ba-d894-414a-8922-d95cf895b9bd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5e3c7dcc42f6dffa412a270633426866fe7bd154d49b9554efe424942f5b058e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
