# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0d2a184ef353c2b3b0ca53ee7ea9ae92c7b1873c327d357fb89cf8e231f07460"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8adc88302c6bd8e8e89268a0fb7454e65154acc1c27e520bcda02320cb46b4fc"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ca4bf7713e22af2d4da2ebb303023684ed7172d810eddb6e18f7bd3965806043"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "6eab0735f09ed844755a6e33cf783e002a7aed65c15b87e451713cca087e1a1e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a6e440074473ebdd3f4c68f94e3f9b63976fc0ec1b6cf1d545fea64019fe8127"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1994da6f74ef57e5d3acd7c142be163f8c4b18c601b0e5e1e99c850ed7089c7f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a4d22f69-0cf7-4de2-b736-ba7d7d7fa281",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "66d7a53a-d1bb-4d10-a164-1c80294bd81e",
    "source_id": "ac742f2e-be82-471c-8611-d22163223765",
    "version_id": "50ddb9ed-8579-4518-8508-de62b35a5d19"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37163/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d0105fad-2d0b-45d2-856c-55c88585885f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a6e440074473ebdd3f4c68f94e3f9b63976fc0ec1b6cf1d545fea64019fe8127"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
