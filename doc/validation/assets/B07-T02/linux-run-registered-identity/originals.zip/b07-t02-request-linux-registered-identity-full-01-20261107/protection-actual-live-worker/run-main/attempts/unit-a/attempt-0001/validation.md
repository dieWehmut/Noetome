# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4a19c36fd7fb782357e2fcbe227b51ee0307d4950ccb8ff50f5a58edc599cbf9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "af466e5784a3224403cedaedc4a4271cdb41ec4e1373e6eb94eb36ce41d521ed"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e32ea956d647aef161bfe3b72c73987090c044121e86cb0cd5508582fcec1df7"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "6782ea2c0f407cb0086e9961a713fd0077d0b314097d8968d7d60ad2cb9ee113"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fc3d3188a3901033cb2f899f4e142cc6fae7450fdf1b6d9dc7698d7cc5a1b051"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0feb331967648df5d2ac1e7c9620c7fd06a0d3766d1834653d79d173f150f68e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0dafbd05-ff0d-4842-a844-b90dc1e8656f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76e83d56-4324-4ba4-9caa-7c3ea97cef29",
    "source_id": "130f4e15-0b80-488a-a458-002cbf226a7e",
    "version_id": "f7514d33-f5bb-483b-8c0a-e51ee0f0e252"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36661/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4076e5d5-919e-427a-bba7-6e15edf22ab6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fc3d3188a3901033cb2f899f4e142cc6fae7450fdf1b6d9dc7698d7cc5a1b051"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
