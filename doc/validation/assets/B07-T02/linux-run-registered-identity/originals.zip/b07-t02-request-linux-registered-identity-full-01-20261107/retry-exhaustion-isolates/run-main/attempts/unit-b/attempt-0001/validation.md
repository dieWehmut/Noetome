# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "30d8cc72d733844104b69e46932d4dfe71314ec67a927ae464e799e3c214678b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1e2564ba075ff2c2033b2baaa6a69de0b52f1480914e1f788104ede9bb62fa00"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "89184def351844417fa68859e0fc404d2bc2dacf14273dd9e5da9d5015e9bda1"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "480976a6ccf15645a62be6a57a60575ab51fb44946fcaa835639d84c57b6ce77"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "cad88fd8ccdebfad02b4f0e0248d315dcdf1518200647277003e5a0b866bcd20"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "44728cd235d36ff07191846b4fe5e06c9714ab6d64b7acaa9bfca5a7cbcc41e1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "afa1ff4d-c8dc-47d7-bd90-c4638572ab96",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "739298c9-5a27-41a5-b5f6-9b84d7c97ce9",
    "source_id": "dd431b64-0539-4979-9211-bb59eb8cdaa5",
    "version_id": "131b82ab-9c4b-44b1-8c77-1ff0bf38dcf2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36445/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "12776508-1bec-4808-b26a-9450521181e8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "cad88fd8ccdebfad02b4f0e0248d315dcdf1518200647277003e5a0b866bcd20"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
