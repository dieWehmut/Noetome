# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a8abbe15e0e237888142676f6b11966ebd5d56ea20e1030758b99dc5ba596699"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8fc211368f225918e3247df138a441daf7fed323cf3a6fb8a32f1131aab7ccec"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bce6353881938d5b9207ce49ee7609634ec5b2b8197b5a50c8504ac462b00f08"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "3b53fda256f1b752eefa3073bed15814f12bed752226336b754bd20705d7a902"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "945085498dc30f02d68663bc1b708763b781e28b027124b4bec57b566dd64598"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "215c97b5425c054505ed3e0046e950b871bd6447180a610c3c1e4c4bebdc0458"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f25d8f7d-ecdd-4d05-bdef-3b24ab50abf0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e2bec280-7f27-45db-941c-20e32e7b7656",
    "source_id": "22b4ee8e-d769-47c1-9ab2-d7b1e86c607e",
    "version_id": "c7ba997d-2307-4419-ba34-5fd3705b4625"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37575/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5b6829ef-af0b-4cb5-aa0b-7bcb1f5f1ae6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "945085498dc30f02d68663bc1b708763b781e28b027124b4bec57b566dd64598"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
