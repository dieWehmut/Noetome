# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c3f2c88c00edd1eaf93095b175a51e724cc44ead547ef9faa6ae94b3a600140e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f4cd550f34a0ecf4fafbe291db98ce22268f04cbc521cd8f99778226313b14b4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "233ed7191c10bd798c36746cbe2c054f568b7718d8c7c90afb816863433d5ae6"
    },
    "request.json": {
      "byte_length": 2227,
      "sha256": "735f8472387f6a32ba91642b6ca50a6d5ffa1a6418920b4a09c610d8ca5a7791"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "96c15c8b7d699b3532af4e83a872c728d30e762d0d736c7a67a59bcb3566b918"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "318e431339a12261c365fab74382f8db6f931047773e508c6fa5d6e1b4524a62"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "aeb4124f-c331-417f-af91-ea4ffc2be5aa",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6316d0cb-1332-4aae-a0d3-868d06cb715f",
    "source_id": "1a1ba292-5cbd-4750-8542-67bcdbd1d243",
    "version_id": "45132eee-07d9-47d3-a9d9-7f9d7ffa392b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36659/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "200b0c6e-72f1-4bf2-a2b4-e42667dc2275",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "96c15c8b7d699b3532af4e83a872c728d30e762d0d736c7a67a59bcb3566b918"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
