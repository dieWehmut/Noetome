# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2783e21c01319c0757f1c71ea593f0609b277615a805669b575ca92bfdfd173b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "083e659332f05a1c4886af515c5e79419a1d285fdadf03064849611a3e5fdf71"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a618b138de3beb1789380676b239a71a975bf8e22a165cb457848cd3c3e1206b"
    },
    "request.json": {
      "byte_length": 2227,
      "sha256": "8eb5801c6883ee60235ac53924ef9f630d0247a4523f3c18166f9f31eed63670"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b889ee1078ecddc2ab59fddd9bbc50d38409438631b2c67a533766e3647288a0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "33c314a14ea3f4f18ff790f85a3a03ac24d6726a2cfd47499686f4b5aeccb6f2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bd21d4f1-ce5f-4475-b744-32c34e015e46",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a7b7baf9-abd7-4097-b162-88a6aef52232",
    "source_id": "7923ff1d-b77b-4812-8053-839bc8385784",
    "version_id": "41c80eca-8907-480d-a148-45fec21b716c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36659/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "042e3af8-1225-4e02-8b22-0317573ef086",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b889ee1078ecddc2ab59fddd9bbc50d38409438631b2c67a533766e3647288a0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
