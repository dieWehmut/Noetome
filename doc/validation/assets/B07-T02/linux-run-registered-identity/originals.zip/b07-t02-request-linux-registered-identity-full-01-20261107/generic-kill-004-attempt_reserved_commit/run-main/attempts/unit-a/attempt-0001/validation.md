# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ff7c846ba0cd6e3b049ee3e0c3f6204a6a883300747c3a8e90d8e68d273c7e60"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d75b4db66a9d48e2edd9c82b6ecd58fb41a1a587b6455610f1f7e737145013d1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cd69fc13c3a61cf74ab4830c4e3c239db2ed054ce38705779fc53cb0d8384e94"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "2dcd74c1f2074eef27d0d2d8370b7dcb4b72f1a3c71dd009fe6bc7227fdbba43"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b379fb4fd910cee2159a71ef2306e855a0062fc65a50ca80eca18a7c7c133f58"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "52c4b81070944c1b9abfced3b95a2e6f350d895a283a0ed968ac43352187f507"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4babe13f-c42a-4042-a327-e76ed1e57b91",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3e8a43fc-5724-46da-88c5-876c3367c157",
    "source_id": "0644fe06-ec87-4b00-b49d-376f51af3728",
    "version_id": "4d97901b-2f30-462b-aace-ea231699de97"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37467/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ce28f928-6a49-4548-8028-289350c55004",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b379fb4fd910cee2159a71ef2306e855a0062fc65a50ca80eca18a7c7c133f58"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
