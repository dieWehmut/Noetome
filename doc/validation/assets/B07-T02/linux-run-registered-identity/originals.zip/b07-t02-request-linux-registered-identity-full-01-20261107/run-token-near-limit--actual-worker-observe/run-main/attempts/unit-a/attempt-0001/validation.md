# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9dc59c690619e6e4ba05829dea7b4871ae632636ddfb8248268024f697293933"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "59b00242c8c9c16940745309d7d2de4198ae8719fb5031e8e3c5d31348f39e5b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a915aa40a61f8010f859b78a97abcb1abb77f5e36e15b9a16a9549bb0073a30d"
    },
    "request.json": {
      "byte_length": 2246,
      "sha256": "4a16433bfb542e27b0913fe7b8fbc3274da7302aa2aae55b8398c8a0e5c9a9df"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6444a22508a0878645cd96e7b1f04907f27291d721daf61974e8f36e142f7bc9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3d3e0583e8aee026223baafced80b886c6c87ce004a928f010b1819fe51ab6bc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9c6bc3aa-a2e2-4793-b93c-0c922e1c1db5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9d9a51eb-4f06-4926-a045-0759251691b2",
    "source_id": "8101fffb-8fd8-4e57-89dd-908922a4820b",
    "version_id": "9bcb58f6-b0d3-4d95-9529-81e8c8658125"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36741/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c57a5923-255f-4dd9-8307-0e2a44127bed",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6444a22508a0878645cd96e7b1f04907f27291d721daf61974e8f36e142f7bc9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
