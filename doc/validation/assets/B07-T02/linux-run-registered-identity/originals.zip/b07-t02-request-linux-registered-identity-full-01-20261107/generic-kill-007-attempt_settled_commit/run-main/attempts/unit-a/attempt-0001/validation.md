# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cf673439eebdd107fbda5d0273b071c8d573a7ebc08a4874f44fb84fdd7ebfa9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b9661ff82585e716a0a62ec2ae9985e9c66bb1bdbe38a8417e74e6759e901f3b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "eb9430f422c2049c3e5d82e36f00eba17c07b59b4926e4c9f770e12b3eb4e821"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "034408b8bcc1d47935344e22ceb052e186bcf3357836fa2b9af8cd928b61a09f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "42057abee0d281e090ac8a95dbffed76c3dd9ec96cacbd1485c302e9a1c70f9d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "df2c8ca6ae9a33e04703ab648fdbd06a052033529c2ebc14085af8aab88e5c6f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f613768a-d35c-44ad-a7e6-a216c472312c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3161bc86-6715-4918-9b8a-5b2d0ae3d3c6",
    "source_id": "1ec3b77e-30bf-448a-a3dc-c73be6d2a498",
    "version_id": "a1f13fd1-6bf0-4c6b-9d55-ef660f5da111"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36833/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f45fd4df-92fd-4760-b9f5-9cfc3fa01760",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "42057abee0d281e090ac8a95dbffed76c3dd9ec96cacbd1485c302e9a1c70f9d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
