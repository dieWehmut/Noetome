# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2fc18bfd1d1926852b505499abf853a660accba32f02a18136e0b7f49bd971cd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7843adf9b67abf01b35901bce6c3d619e7d80f9e738d6b09a914b32849b3ae7f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9288d3c4b3ae9f6894be5c0cbc2633b2bda9923438e5c2f014f3c5794874f38a"
    },
    "request.json": {
      "byte_length": 2251,
      "sha256": "75d6d53c07b0cce97beabbf3051e3664a633f10800c08d3c9a03be11aba7f345"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "55974e16d1c99f2bb48c369131c48f560d4e82b909752ec59842d561ad6dee6e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0da2648a85fcf65b63c0743883c047011868beac3c88579082effd0c19ea0863"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "97b31779-d387-403e-b244-6a357d0f9180",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bc04502a-056f-48e0-ac47-0d162c1a5ca0",
    "source_id": "537560f5-c53e-4c19-a26b-f7140458e665",
    "version_id": "a52cf9bc-b159-4b10-97ba-52bc26b23a6d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36823/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8f11d4b1-c307-40ff-a165-5b9efc533cfb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "55974e16d1c99f2bb48c369131c48f560d4e82b909752ec59842d561ad6dee6e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
