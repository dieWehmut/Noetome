# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "616de86e056aee1cb625887076cb1154be766248f769089e7cbb59f4b5e540c7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d7b571d17143c0efea4b1b72fdf2ba215dcfba975e36e299cc4b28cee9885991"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6dc41f7d38fcc0debc4997fe3164cbd97ebcb20a6bffd07ab0eaac870bbc12c1"
    },
    "request.json": {
      "byte_length": 2246,
      "sha256": "0d2ef9274d94592d2b02f040542f380e132334905e8fe4a963a6cc3252da0e66"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c699d5967e742fa7e9e4a75cffa0a2c88958c1ded76bc9113b4f7571330ea596"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a20e14c29c326f63a72a790d48707c65c83001d6d6f36b2b5fe418acc48c92e2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "00f541b1-4c7a-4b9e-b4fd-2e9a1b65644f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "829ce4b5-5d4a-455a-9571-adeebe46aee1",
    "source_id": "617e87e5-68eb-4258-8b72-0ae9238c8b5f",
    "version_id": "48130d32-d0f1-4a40-b0ba-9c832a6d28e4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36861/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e9349bd3-1641-46f9-ba5d-69a6f0ca681e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c699d5967e742fa7e9e4a75cffa0a2c88958c1ded76bc9113b4f7571330ea596"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
