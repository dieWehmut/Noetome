# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "13470477f36823cb554d8aee2180a20def292ba2d01633694c9726aa433a4443"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0fcc3b25e1cd44a91abce795528acdc2390e1621d4126afb646db097c6fcfd11"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a6a28506737c18ecff29d7ffe344c85acce6839ce98e20f6bb572fe005be194a"
    },
    "request.json": {
      "byte_length": 2261,
      "sha256": "702923d3a0e6402ea35a19b5ae310f27a19b75c78f1ddef5c160fcf285dadbea"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3955d8013c9e39f3f6a785a46c1c1a43e08a076c86d7fd37c9cf0b9f94f5a92e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "05387aa6d8a36d9a8639c3a9be2a77e3b571cf3e792ab83a55074f8d4d163524"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9182e140-4006-49dc-a440-3bd8edd73e18",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "91ee1938-8d07-4fc4-96dd-c7431ae5b78b",
    "source_id": "6b01606f-e83a-484b-9265-c2a49c1b30e7",
    "version_id": "7b809cfc-38cb-4a23-a70d-47dcd671da58"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38097/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b47ab88c-ac07-4620-a798-4649def6ba90",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3955d8013c9e39f3f6a785a46c1c1a43e08a076c86d7fd37c9cf0b9f94f5a92e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
