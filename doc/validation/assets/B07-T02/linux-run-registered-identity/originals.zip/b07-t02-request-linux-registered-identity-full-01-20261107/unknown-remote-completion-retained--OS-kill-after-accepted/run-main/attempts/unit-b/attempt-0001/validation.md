# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "df807f87d4974c4993267eb1b5a0239706c7afd156f3c4d46bb79510665c2be2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c0d9ee13abb8630e38ec78eb8e1e6c9b6cfb20e2753854d717be74bf6a8fefb0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d326a87460028e0020d6461448da34fd108163c858300fc1c12f82bce635e691"
    },
    "request.json": {
      "byte_length": 2261,
      "sha256": "769baae2bdaf398c942b66618e9a537fe37b2ddbbb61c1bcab839826ccfd4104"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e60e761f7547e8559f48ab9f8a15d8aa8b9fe6194e59796242d79fd95e73e8b9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "42c7a777f1f3b7506d5e38f1415226e4ccabe209e31c384fd4054b50cd95aa24"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f9593e5c-5573-49d6-8a19-3b97bc57f223",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "56a88f24-8040-48ab-abb3-718115384515",
    "source_id": "f01f2e5e-32d3-491b-a4e2-658ad9e9eb89",
    "version_id": "32fe26c8-d083-48c5-b12e-da71d789dbcc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38097/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "86ce2c69-cadc-4421-8c7f-6d5274ab9c5c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e60e761f7547e8559f48ab9f8a15d8aa8b9fe6194e59796242d79fd95e73e8b9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
