"""Check actual closed pair and frozen launch bytes before the once-only run."""
from pathlib import Path
import hashlib
import json
import os
import time

HERE = Path(__file__).parent
REPO = Path('/home/lyinn/project/Noetome')
PAIR = REPO / '.artifacts/b07-t02-linux-registered-identity-pair-01-20261107'
FP = 'cb137897b122411e02bf42f67ad1484d8a77fd3efde62a8d402baa3f207ebcc4'
ROOT = REPO / '.artifacts/b07-t02-request-linux-registered-identity-full-01-20261107'


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'device': after.st_dev, 'inode': after.st_ino, 'mtime_ns': after.st_mtime_ns,
                 'nlink': after.st_nlink, 'metadata_captured_before_first_read': True}


def main():
    assert not ROOT.exists()
    raw, launch = capture(HERE / 'launch.py')
    assert launch['sha256'] == '8833c4a624931dcb8fb449f8333250a7bb202f4e18684595e72505cb63f815a0'
    assert raw.count(b"'--full'") == 1
    pair_raw, pair_pin = capture(PAIR / 'actual.json')
    pair = json.loads(pair_raw)
    assert pair['status'] == 'built_source_bound_pair_not_full_acceptance'
    assert pair['actual_cli_fingerprint'] == FP
    assert pair['cargo_build_script_fingerprints'] == [FP]
    assert pair['cli_probe_exit_code'] == 0
    assert pair['source_files'] == 130 and pair['source_before_after_equal'] is True
    bodies = {}
    for key, name, digest, size in [('cli', 'noetome', 'ac9e92e1c74d66d2c177d3606158946069deb6062f13d183d2f46b366abb436b', 17877456),
                                    ('test_driver', 'request-test-driver', '87568e22d95b643a10bbb61e7eaaad52dafa6bbc7811c69747a33130d637dc6b', 23873760)]:
        _, pin = capture(PAIR / name)
        assert (pin['sha256'], pin['byte_length']) == (digest, size)
        assert all(pin[field] == pair[key][field] for field in ('sha256', 'byte_length', 'device', 'inode', 'mtime_ns'))
        bodies[key] = {'original': str(PAIR / name), 'pin': pin}
    report = {'status': 'actual_new_pair_preflight_passed_before_once62_not_behavior_acceptance',
              'PID': os.getpid(), 'utc_ns': time.time_ns(), 'new_run_root_was_absent': True,
              'launcher': launch, 'actual_pair_original': {'path': str(PAIR / 'actual.json'), 'pin': pair_pin},
              'selected_bodies': bodies, 'actual_FP': FP, 'actual_pair_source_files': 130,
              'scope': 'Actual Root-authorized closed new pair only. No product, HTTP, driver or Native process invoked by this preflight; full checker performs all independent source/budget/wire/kill checks. No extra3Linux.'}
    with (HERE / 'preflight.json').open('xb') as stream:
        stream.write((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'status': report['status'], 'PID': report['PID'], 'FP': FP}))


if __name__ == '__main__':
    main()
