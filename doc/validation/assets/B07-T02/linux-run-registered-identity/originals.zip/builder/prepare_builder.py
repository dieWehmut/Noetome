"""Save the current standalone archive builder before executing it."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).parent
OLD = HERE.parent / 'b07-t02-linux-shared-header-final-independent-checker-20261107/build_archive.py'
raw = OLD.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '70618b517bfe6eafa12c9f7a606ff11aaa14b7a39eade0d59a2ed2b46e073c72'
with (HERE / 'prior-builder-original.py').open('xb') as stream:
    stream.write(raw)
source = raw.decode('utf-8')
replacements = [
    ('shared-read/header', 'registered-identity'),
    ('b07-t02-request-linux-shared-header-full-01-20261107', 'b07-t02-request-linux-registered-identity-full-01-20261107'),
    ('b07-t02-linux-shared-header-full-launch-01-20261107', 'b07-t02-linux-registered-identity-full-launch-01-20261107'),
    ('b07-t02-linux-shared-header-pair-01-20261107', 'b07-t02-linux-registered-identity-pair-01-20261107'),
    ('b07-t02-deadline-stamp-history-20261107/package', 'b07-t02-deadline-shared-header-history-20261107/package'),
    ('89136b36bc30a77c5e7a1a54fd480c8d06be89e060377f1482954fbed12433b0', 'cb137897b122411e02bf42f67ad1484d8a77fd3efde62a8d402baa3f207ebcc4'),
    ('Prior Native4650 elapsed NoFit and ordinary terminal-status artifact failure originals', 'Prior Nativec2f1 ordinary and selected elapsed NoFit originals'),
    ('sourceb393/2e97', 'sourcee4d598/57c1d73b'),
    ('b393/2e97', 'e4d598/57c1d73b'),
    ('current_shared_header_Linux_originals_CRC_SHA_length_readback_passed', 'current_registered_identity_Linux_originals_CRC_SHA_length_readback_passed'),
]
counts = []
for old, new in replacements:
    count = source.count(old)
    assert count > 0, old
    source = source.replace(old, new)
    counts.append({'old': old, 'new': new, 'replaced_occurrences': count})
with (HERE / 'build_archive.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
with (HERE / 'builder-materialization.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'status': 'standalone_current_builder_saved_before_execute',
               'original_builder_sha256': hashlib.sha256(raw).hexdigest(), 'replacements': counts,
               'new_builder_sha256': hashlib.sha256(source.encode()).hexdigest()}, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print('current standalone builder saved before execution', len(source.encode()))
