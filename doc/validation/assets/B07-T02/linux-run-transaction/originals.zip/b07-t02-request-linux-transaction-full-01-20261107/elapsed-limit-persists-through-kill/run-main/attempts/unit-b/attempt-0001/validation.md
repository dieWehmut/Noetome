# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a2436957eae6db2ecc753fc7f993d1fdc18c8155373b0db748ad250f6d9e59a1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2185865bb8c1c9911fd602980316945d6875a2ed8ac4bdd88057c7118e080742"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ca16888c1413a88f0de3b2a0ec8733a87fa2f15ec0d9158cbb2340738e1b5017"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "eb84167e4d82199aa4239dca917c24de21dafc527a2aa8d2f60401eccf0d0d6c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "93ae83befc04ddc00a21ac00e7225269e7eb3536328650115a70154820c3645b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b64c781cb6ffff86988907bb94003b22f63610f18a95fe78fe683f1636b7e2c2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8e948a10-5be9-41c7-a9cd-2f4e5595ba4b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2725501d-f899-496c-afc6-13b60e2144ab",
    "source_id": "5d9cd5c4-adca-4741-bd27-f651c8bc79b1",
    "version_id": "c6873b9b-5222-4edf-b320-c394ecc1a41f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37113/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1d2e7519-0943-453b-8a02-8b6a03842f7a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "93ae83befc04ddc00a21ac00e7225269e7eb3536328650115a70154820c3645b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
