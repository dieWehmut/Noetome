# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f6428ffa48d8c598387a986afe696aefa4fcaba3f458e96d8edcdceab0309b21"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "bc584ca31fd902446e45da35c32e584af6d10863b1c520c9f64a1b68ff9e0d89"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8461f3d3c9b6607fd78e646be652a649b392c5ec9e7148b1dad3a228f5739d2e"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "cc0e766258874f46d00b5cf41cfe2983a0de41ed40c47b34a0aaef6eb194ec22"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b9d061f575c7f3be37fe0665c071a855d18e8219ed17794b17565ba201a04faa"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b64a39dfcf69783cbe0f516deca154032196c3e7dea48bcd9dcc6816ab99c133"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ab02d4aa-695b-400d-857c-20d189b3389c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "af9988c5-f2b3-45e6-a925-0fda815ab544",
    "source_id": "66850055-17a4-4024-ad29-0ec6ebece70d",
    "version_id": "e8be684d-2d0b-405b-a214-ec90af274333"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37107/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "69180f5d-e7b8-48a0-b550-b443d8d3374a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b9d061f575c7f3be37fe0665c071a855d18e8219ed17794b17565ba201a04faa"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
