# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cf86f2613f095a5db91659d90a62db703533ab6a410f31bc68324df88cb3ba52"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a192e8604a7189170c20700d42c1f87b9a77c5b2f500289e8dc9fd300819643b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5eb1514d4ee093cb1fed969cb94587c9efc48e661dde8b5e90fa50452f55508e"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "0afa0d9fa22af3fac4c50c54a3b54e8070e9dda811810a65a7573eefdc979ed9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8f847735b11c315bf01f029d82139e9d659c867883fc6b63a1db3f29e2aec566"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1e5e0cb01bd12be757fcb6dabcb8d473bc85613269a8758dfd8dabcde18dd835"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a74b22ab-582c-492b-99b2-32ff99d5212c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c6bb6ad0-982c-4fd3-b978-28ab9f8b0926",
    "source_id": "8e7a1fcd-7b63-4a45-ae6b-a5ca7657360a",
    "version_id": "6c1f5393-9f7b-47d2-99fe-58477474da72"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37107/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "924c2d52-ac80-4166-b8d6-ac11d2a1b721",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8f847735b11c315bf01f029d82139e9d659c867883fc6b63a1db3f29e2aec566"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
