# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "afdf92add7a34d21251b03b228618313674af0afa71c1d89267c87f3d9537225"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e02cd680b46e2a27620c49f422c29449f6a1ee8bd7dc1810dc75192a72786721"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c6fe222fdab38fe76d10f637420e7259e440c021da6882db7a68af196cbdcb51"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "ec6cb580af429959ac919bfb63f35b741a31f1d619cd743237585c098939cdb7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a94828e902ca4abd980896f93aefe941473234ba0a2eb2d0102d53bc67de7f85"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5e833a2ee5eaae140a3c080034615cc0c994e407e1f4ce846fcfecbc6575ecf3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "64312352-798a-4be4-8a52-e4ac692e0a6e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "909cf350-a841-4753-92bd-ccb0cf491b7a",
    "source_id": "d9517d20-9695-4065-829e-71b1940e3bce",
    "version_id": "65367ce1-8f4e-4e49-99de-722676916b5f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37285/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "528aa4f9-ba1b-4a45-bbd2-f2e7ea62fe31",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a94828e902ca4abd980896f93aefe941473234ba0a2eb2d0102d53bc67de7f85"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
