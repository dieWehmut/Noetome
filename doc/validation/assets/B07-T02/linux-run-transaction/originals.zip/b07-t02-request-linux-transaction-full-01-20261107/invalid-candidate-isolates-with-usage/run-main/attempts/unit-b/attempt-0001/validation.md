# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4b82c7455463664b3f610d4000570e8abab981e43fe5343552c1e8e5e6853d52"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6b9fc3aa71b8dafa8cc1476b4fb06da5d78f51097a2a09586aab0c86d3752a7c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fefc8bdaeca918532da7fca55ae825aea6dd080755aa56a4f45d5e767e60a3a1"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "caefca2bf88bea029fd7b5cb93953b2fe01ac821aaa50e66ca41ba1042a0f3a4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6e0e80c458d604af0e1cbb5084f9260215fb289cf65fe080273b57bb12e30cd0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ae8e76f358d17afe243b5173293549b753d0b34f54bb59722e24789cf19d8bca"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "765d5643-3a9c-4a29-bc44-c65371c50eab",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1f1611e0-2499-41bb-b4e9-237d98952be5",
    "source_id": "0c1472bc-7239-4ee9-976d-606b6fcb5045",
    "version_id": "990081a0-ad9a-4d59-b9bb-2c8ba49d7dcc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36607/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8dbccc42-183f-424f-bedd-8199a8db3328",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6e0e80c458d604af0e1cbb5084f9260215fb289cf65fe080273b57bb12e30cd0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
