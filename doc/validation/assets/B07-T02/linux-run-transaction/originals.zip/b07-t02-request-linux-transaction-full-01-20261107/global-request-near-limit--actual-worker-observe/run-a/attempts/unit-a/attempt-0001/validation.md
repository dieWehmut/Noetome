# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ac8c9c90b2ef1d1338af2595cabf15e27ffac1d5e45ca15cf611115838c18626"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "38d7d7835a425f528548c5d937e047f7893dbd865a3b56b518a97a2ad7ac6885"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "34671958f083da50f01f5d7374970eee31471a7e45ec69ce15435897dfbb8c8b"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "735cbb3086403acf73ec48b9594a49fc2aff1fedd90f0b43f66221fc04bda975"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a3b4d088a2e2a8ee1239bf99b0d862ac6007d94959507f9b423415b4b4009e7b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "328fa2e85d71f222cdc936e6c572daca7b866ee53102c749e9aff4e8a444b97f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1bbc70d2-281c-44d1-890d-7571cacee035",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cde947e1-ac1a-4eda-bb77-d4a17d3cbda6",
    "source_id": "9be119fe-921a-49dc-a7f6-29127970a482",
    "version_id": "34e12438-5ad0-4791-b466-cdebddc71027"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36787/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b9a168d7-8252-4761-885d-d21554096775",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a3b4d088a2e2a8ee1239bf99b0d862ac6007d94959507f9b423415b4b4009e7b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
