# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cb6df6e70132836b8af133be1f4f5a6b720b0fd238b8123a97a8d7e948c61b72"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "eba0d1481904d086f287a29d9af825699a63429c9ebf190c241ea614b14252b0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1c0ada5c739473c55e46708a245312521576796d396fb40330bb150f38878398"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "a9562bb1d34a26fb624e524094690e9aa360f06e2e08a3d91035847b423db2b8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5fdc73f5b647167dad9b46c4d179918ea308dd2578ea49fac10db95d3d263bb8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fbdc26f33855982e5c7a4378daf654c79b5988b662654fe4c7f90cad05109781"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6a0a9146-b6a1-4da5-b3da-2396d3ef7e14",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "746bf03a-fb8c-41f5-a264-e89382379f62",
    "source_id": "9154cde8-addf-42f1-93c4-a079baf6ff4b",
    "version_id": "83b08e9f-0ee3-42cd-adb8-2a1af2253b11"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37917/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "841311ce-2b8c-453b-8560-b800ea26ab76",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5fdc73f5b647167dad9b46c4d179918ea308dd2578ea49fac10db95d3d263bb8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
