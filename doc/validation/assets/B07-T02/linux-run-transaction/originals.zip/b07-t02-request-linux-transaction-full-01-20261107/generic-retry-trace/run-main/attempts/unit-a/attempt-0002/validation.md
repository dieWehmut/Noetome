# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a3b305885c6cc4d2875324c6b799a6fb25730240380a6e827a2337f5c8da4e82"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b4a8730e2287ce2ba2c2c19e63d63a08239b861ef13638a6f06684195cfd8016"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e24dd623e2bfa2438d90a579ddf3ad8fa6ae4c4ca960b1cd129fada1e6b9e280"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "e5c38ad1c72cbd38ab3481cdf0dbe9ef2dff5263b11b863cee0730225e50287b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "dd7b164ca09043e59a545e20ff2c269d31d4b9d5a421b2327a66c570aa69d445"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8ce3e7d0624b0eef28300df9b69576a2a9cbe3ebe202d7d758d2d3295b1e0573"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a7001068-98d5-4cee-b826-33f21cae03ca",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6bc19706-486c-489f-a594-123ac7bef142",
    "source_id": "02694777-99d7-4469-92f9-ed21a6a326bf",
    "version_id": "26e80f1c-3a06-42f0-bd49-91d0db19852e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36967/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "557f78f6-238b-4ac0-8940-73a66ecf37c4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "dd7b164ca09043e59a545e20ff2c269d31d4b9d5a421b2327a66c570aa69d445"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
