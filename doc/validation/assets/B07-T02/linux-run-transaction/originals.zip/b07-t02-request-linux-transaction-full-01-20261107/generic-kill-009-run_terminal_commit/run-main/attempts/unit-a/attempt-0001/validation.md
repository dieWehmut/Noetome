# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d3d7f15782e9ca0fc5578ce4a5817aadc54a8ec28e37e225b7a9f237d4aaae96"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6f7e06a86c9b1489b9ad2cdd423fed6c9723acfce5928acb106aaa5f526e657d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6799300eb23d87050b4c4188f29fa9eba9c553fcd6da3a9c7d4a98c1f1e8f4ac"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "76f86bf4a249975a52318353f07a130378fea25e1b6fcae9abba6f470c097812"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "91d028b896a5f366e122420ed42b0aae562932acad72a92e6d0d34938834881f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bfa92466fc66f17e84c20da838f82a38e42437e0b9a3a63017813e0fa9b55f3c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e0bf05e4-40e9-47da-8451-8086f475924b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a8dbcf0d-4e04-4804-a0dc-a9331c37e580",
    "source_id": "ab57211e-a6df-40e9-84e2-2846f99d650f",
    "version_id": "fa654849-a2ac-4138-bb24-8fc073dcc4d5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37649/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0e9f4d5f-af09-472c-b35d-9f4c1300534e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "91d028b896a5f366e122420ed42b0aae562932acad72a92e6d0d34938834881f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
