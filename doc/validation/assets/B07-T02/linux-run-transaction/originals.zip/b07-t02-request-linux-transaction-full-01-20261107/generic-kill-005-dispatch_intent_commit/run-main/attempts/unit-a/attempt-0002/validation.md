# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "03acadd8e83a3f8a8b04e57c5f9a7dcce41cf601075e8672676ac6f4f5ec81f5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f0f2badfe9d8ba7ff43c890296c0ede4bb3f905c1b83b4f8dcb2ee3443f61873"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d518c55e6fec4fd8e8aa98fedb439ce368b3bcf878070087d1b1babe6fee9c97"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "96e9d53e34f5687cc051d31ade1c9d7031aabf76affff54d7fffa121beda7dfa"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9cb05d4fbdb80beb047b09a1482fec16528fd0be9635795778f45e433c261193"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e929d84438e630a1ce805385c7a2d54376c5583404e305ba4f0f50508f635f55"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "65a56e88-8455-46f0-97e8-f2b95651e915",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a89e4123-61be-4d41-aafa-ca0d6b195399",
    "source_id": "a2aa8983-d11e-4822-9d30-9ec43dbcaf8f",
    "version_id": "4cbf798c-d67b-47eb-865f-c241f169809f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38407/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "62cfc043-5aba-4520-93e8-1c505da9c3be",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9cb05d4fbdb80beb047b09a1482fec16528fd0be9635795778f45e433c261193"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
