# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "10aa98754367487e25dd5f89379546ae9775f6460619c7b91fbfd8dce84e4acd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "95f4ec1cc0b70383fb1e5bdbc323dfcbcf3309bb51099c8858c69b3833026f37"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9aa0fe095a4326b1e140292a0b9a6e3cbdd5a4816843be622f93ab2d71f2bb25"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "c52c4e790f907ad42c1fae83b0d5ca5f4624cd4fc541af238cd212bb0ec7db62"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6d4f722b8c873d84a98904e0f42ddac3d505b09fc3f5a0ef0b41ca08fc062e68"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "223aa8f98788ec039bfed1fff9cef3f8f289d7399cffcfe32e95c59226766114"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5e536bfa-5a20-4441-8cd0-83b1fe63b797",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "648f35c3-b1a6-4a98-98eb-21eb0ec83edd",
    "source_id": "ba25e69d-a6f3-4369-ae97-219f8b62fe95",
    "version_id": "26f71300-a8cf-41a8-a6c1-ae7b663abb9c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38131/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "05c395bb-9011-497d-9d82-902e8cc62733",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6d4f722b8c873d84a98904e0f42ddac3d505b09fc3f5a0ef0b41ca08fc062e68"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
