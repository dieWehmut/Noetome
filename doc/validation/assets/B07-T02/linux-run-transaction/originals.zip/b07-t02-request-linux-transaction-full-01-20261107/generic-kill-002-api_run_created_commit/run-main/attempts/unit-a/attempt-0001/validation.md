# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8210af27fefccd874e158a7437d95680191411e3569fa7ef9b927890ba8780db"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "322925c8af56ae58e20410ce3e467c589c7acd266f33006857d5789ce241345b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "41927609ba107e1eb3b4d29faed106f22fa98f9a7c88d26a56403423403cac8f"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "40e80e06ad8faff90fa36ef2ad6df93f36978b5533f08f1c4f3f0688da8ba2b7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d625adde7627ae0d1ed5f1116403be9d84b854c7380f2694531b723d0328f8af"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6c93100439d5b801278fed734356739998f7f32a9b6e8ccb3efe42bb4363c5b6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4bb7e3da-ff1c-47cb-a661-620dbc7a6bee",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d4b9ca91-8de2-4c90-b497-7202b8ba9977",
    "source_id": "3540a9b3-317b-4da1-9ca1-f33a3782039b",
    "version_id": "7e618cf2-d6da-42a6-8c15-433d784fa09c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37699/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6bbc0497-66b7-4c9a-be6a-f42b967d229c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d625adde7627ae0d1ed5f1116403be9d84b854c7380f2694531b723d0328f8af"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
