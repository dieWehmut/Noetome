# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "33eed818433d3d32018660005d008690db0371727e47072a5652ce8b125e544f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6e88d57b2c6e9ca8689b2dad06b92da311236111a1f475a230ee57524be216da"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2585cdcb3fd2ea5dcdc8489e1c9f184eb6abc347fbc208352127986c128ab4ca"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "c77a21eb67a658ebc9764757bb84cf79c5a098339504c935f27264a3f680ef7d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a8b3bd531fdda442c8ee468007c6eec05fa0bc394fa5ff604d568717742eab3a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a6ae7e47cffa20616ee0485947319182206a0d569b30a338a6e774f9135f6b5c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "35394f82-789c-4a34-8a83-c7b189b433ac",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "08fd51e5-21ed-4a58-8781-ce7e15e87553",
    "source_id": "ed1b9328-2fdb-43d0-a0aa-63d9c5e5df79",
    "version_id": "c71afd95-6dcf-4a78-9d52-97f228e9bb12"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36731/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "69faa647-ab75-4026-91da-97c11c7c9b23",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a8b3bd531fdda442c8ee468007c6eec05fa0bc394fa5ff604d568717742eab3a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
