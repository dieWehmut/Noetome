# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a1c04e2a11291649b198cd3e1f634c5b778aab2a15501429661b7b7a4f94f749"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "28292639b0811a0eeaa1bab5efec0e394cdf4f9919b6f391f44e6e8e79f17e1a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "85250bb8b958eebdbd79fab273e6432de296200d70d88aa4587ab50b46acd9a6"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "9b14e5b419cee8252a0b64b491c33678a57f605730c571db19a520de2280ba8a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1604ae5c8320d0c39d7958b0bd000433a7c65233b72c51f94de07dfc768d8aae"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c9d3f0745c88e34c112e0a714a014a340d11aeb1d9be21c62a63ea81b3cd211c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fa9d5062-b66f-43c2-b609-72785e8a8a66",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3488ad03-5955-4666-a12c-22bc0db26f26",
    "source_id": "93ed786d-1f2f-4c45-86f8-3f0af0052cc9",
    "version_id": "fbf1ae46-af34-459d-8ebf-e70e6b386eab"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37225/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0deea39d-94d9-419e-ac10-61f4cb9d207a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1604ae5c8320d0c39d7958b0bd000433a7c65233b72c51f94de07dfc768d8aae"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
