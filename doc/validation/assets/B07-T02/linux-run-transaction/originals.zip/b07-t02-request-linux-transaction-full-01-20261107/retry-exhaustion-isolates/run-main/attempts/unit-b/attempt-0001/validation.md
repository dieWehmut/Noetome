# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2b8a4c4c8c8cdb43578bc6da997ec6e9b080ff172c3c446a3ebef0c7d0466383"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "22889cb2694a37ff6ed520fe11095bb59e97f2ae270667b8081dfa422d440092"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2948249007724ba560384d98d584165e7a5e60beb8122f8a93b8c16577133ada"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "275df6698a20250c7a2e2a7712e7d4bbcf73321d32175df57ad5b6e4ff5e09d5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "891601dcb97f6523a07d81b141e0aafbb2cb755d9c3cb325777232804bbcc8de"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a2811416163d09d2a832cd5b128c957ad5e7799879d401328f78396536f1cec5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cbeb9a8b-c5e6-4047-8d6b-4ee623492130",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2ff0efc5-733f-4cc5-a26f-19bc218d3d62",
    "source_id": "c0515cdb-80f5-4dd7-922b-a33244013c9d",
    "version_id": "8ef15a2f-3a96-4767-8acb-97072b0ccd0a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37965/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "733e5f38-f152-4ca3-bec3-b8dbb424c44e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "891601dcb97f6523a07d81b141e0aafbb2cb755d9c3cb325777232804bbcc8de"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
