# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "413178bf1c430601c5eae612f7fc5309f4bcf6764da69f4f29bb9a809dd88934"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3b5e14e67ada20dfa9d71d858edcb7d10b29678ca17ed50a18d8d4c47c786bfc"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "87addaa29f340f1abdf8cba758f71f78e72bedb0374ca503222e851c997d2f40"
    },
    "request.json": {
      "byte_length": 2253,
      "sha256": "f9a38c58e1fa3c0aa8a23c8b1a4237417271d058b20d1c0155c3890991e15984"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3c000d4a6dbf96c16d59b8ef18d66c3e54bb5da3a8ce0d4da7b6467528cf4a9a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1a3ec5626ce5da02e53bc439d254eda043bf5b5de677513ab6c1657e8ecf1ddf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f5e26407-99d0-4b17-a048-df48dba2c435",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fb9f1c59-11a1-4f84-9e67-8857b0ca21ba",
    "source_id": "5df23575-a32a-4976-8049-cfcc0af66b4d",
    "version_id": "66818cab-92ab-4454-af88-7b15a7ed9228"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38365/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4e43173d-b11b-48de-933d-8579249d3ea3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3c000d4a6dbf96c16d59b8ef18d66c3e54bb5da3a8ce0d4da7b6467528cf4a9a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
