# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d07b0d434e56c9e8bf93ab93677bcbf14f67fecb241285f61c108b3a78f0424b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0f6c394607c84ee3d971ff553fbf70d1b773b6ea21aca26d8effb3de247ba6e2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c6e0edec7383831eaf4d45ecc2db89f6f00d09ac7e945542a0daf613ca5c8e4e"
    },
    "request.json": {
      "byte_length": 2253,
      "sha256": "1c1188c9b1003e2aa6a1e4b3ea7ba265f60dd0fb9fea4ea7191c356cb350d64d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "053ca6069036e6e3d886fbbbbeb73712026dd4bed90648aa7211b518098cb1df"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c35bc96c38d37046d32540d2ed715da03923a616ba69fcc798f120b62f71db89"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2d1b8351-bc76-460b-b299-6cbcea000c4f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "aa87454e-8717-4a9e-810b-5fc279df7665",
    "source_id": "fcde58e6-1827-4827-9a7f-a4d2628e01c9",
    "version_id": "8ea39d7d-81fe-418f-8b0a-deba08a9d33f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38365/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8cb239ca-94ee-47f6-bbd5-ac71d550785d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "053ca6069036e6e3d886fbbbbeb73712026dd4bed90648aa7211b518098cb1df"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
