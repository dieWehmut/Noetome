# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c6eb3ea9694cd85a39eac3dd5df8a07c621e8c0318452a254ba64aa6a5ac9340"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9a47bfc7fe677e19936a018e2d9aadf74e724df90dee9130a9190407ac67c24e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f3ae347db3389f43f16757313c510bee5aa31631ec419caf2c971200d5d7762e"
    },
    "request.json": {
      "byte_length": 2224,
      "sha256": "10d5976955b644d9870facb8cd5a5a104d131888b8048870483b258077bbd0ff"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "98b884e248288fe0428d68dfd74b5219396f8d6778359ea295aef8ab28b71a1e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "caa50419f2f3c4eafc29b71b06ba6de5ccc537018f99502e3cb236892bc94c4f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ccb7ecb2-6352-425b-be45-36b32067370c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "72f9815b-d133-467d-9082-f46572ad20c8",
    "source_id": "03bd6ecf-1e9a-4383-8b87-fc0f009dd235",
    "version_id": "fc3758ff-eaa3-4971-8618-dbe7c9b9533d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38303/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9ce3cadd-a4e9-466e-a03d-9a81e196a639",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "98b884e248288fe0428d68dfd74b5219396f8d6778359ea295aef8ab28b71a1e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
