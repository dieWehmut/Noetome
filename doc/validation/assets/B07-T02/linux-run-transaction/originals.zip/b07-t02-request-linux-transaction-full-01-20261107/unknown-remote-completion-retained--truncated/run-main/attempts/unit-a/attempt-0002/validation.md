# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "46f9a75fb53503da8d7c9ad85dc99a956c6d459da900685133c93c8116515201"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f262c3580d957718e3d615ec4027c3694be7e1168bdb75a607a8e20cf79b1156"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9f9b5711ec339cac643884958b22bb7a3d294847828259763eb0bd9665a7c0c3"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "bc30055a66a51e30a716293fd27434d7117f9f53f421d7d376f4546e69453847"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "73a21783b87100f29eea8c07f0c4e92a5081470dcf96df9d8cbdb1c3618df66c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "04874bddb27c150e862959e59557f9d6cb59ebff281596f7006727961d20f680"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b4385916-105b-4bf1-8f68-ac873bc8bb3a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a4c228ea-ecc9-47fc-8556-77b7de098d3f",
    "source_id": "8bc614ed-bec2-4248-9878-3b86e80d4ebd",
    "version_id": "4b442ce4-94e8-4787-9a50-e3940b65e649"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e8983ca4-97e2-4654-ae78-f69004eb8baf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "73a21783b87100f29eea8c07f0c4e92a5081470dcf96df9d8cbdb1c3618df66c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
