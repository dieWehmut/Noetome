# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9f195f07acfbd94854c29da524596316632a8c7d4724d8660809b5c5cf4e44cd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b9023fa2f644c1b894ad203529b35f165944bb1fb7b9a2f80ca801e7260c69cb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d73a69b516990f076a2a7f3e19ac55b85ceb27669d096969d7551138a7b2482b"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "48dc4eba0292509d26aded2c4079c2f83ae86e51719e43c5e71285ea2bb2877a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8b583a5a5681767ec0a101b34f45a3845a63f0304d2676e2a9f4e4c393fec9e3"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3decf4c5afeb7138d1d303696ee833831b9fca318d8f3236d9a6e404025c55c5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "233bf790-3f2b-4a3d-85ea-b12f67b75bb4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3e9c877a-3154-4173-a1d5-d97e39bce1d1",
    "source_id": "5420dc25-cc5d-4418-978e-b24eb523752b",
    "version_id": "88b883c8-761f-431f-8258-d8789846daea"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "33cf954c-62a8-48da-afcc-29db15e922ac",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8b583a5a5681767ec0a101b34f45a3845a63f0304d2676e2a9f4e4c393fec9e3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
