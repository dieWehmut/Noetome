# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7db3a229991b2cfa9414d68ef468fcf06d137d399fb78fb0c5f8bd3cd88e508e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4d1a031dc7860380ce4a62a979ba18aa309b24d22584fbfd4cc2ac934a03d89b"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "43b843eb5de85f87a3dbc53aedcb4c3ff3fd464e1f6704273477f59387450a40"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 495,
      "sha256": "783b97d25d25da29da87fa09b65b560eb5bd62e56064392c435c888283b9b92a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b4385916-105b-4bf1-8f68-ac873bc8bb3a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a4c228ea-ecc9-47fc-8556-77b7de098d3f",
    "source_id": "8bc614ed-bec2-4248-9878-3b86e80d4ebd",
    "version_id": "4b442ce4-94e8-4787-9a50-e3940b65e649"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38235/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRUNCATED",
      "message": "EXTRACT_API_TRUNCATED：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b9d1442f-c08a-4d25-a018-aa252e8e03b3",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
