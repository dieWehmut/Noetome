# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f165c8974a8d19468bc95cebaf7f3bcf06b62f03004eb91cd1f6d8a8e20e35d6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7661edf8aca3ff79a1a75280b80d961ee97cad70639f8335f35774ca6a26235a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2efcfe58bdb26de57301c70250d2bb37457279382ed286e57b3f0305928527c4"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "c94fb338a88a2825804843c845e8c649eed924519b269f46cc27f27d80e841cc"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8f1a7d215ab049a34f49b653d25373e44356bf09ab365e27507fb00519e1021a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ca9aceb57c64fb24fb949e9228494b9087eb15c9d6e9030d106bb6d9ee4fbae5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5aed2ac3-ed96-4532-bd34-c92ff7c25272",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "be8fa90d-6f4a-4111-bc0b-f816ed95d2a5",
    "source_id": "fb24450a-bcb6-4c27-8382-268d0976cada",
    "version_id": "4e5eb2e4-b32a-4bf0-95bb-8b79af253dd0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37941/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "770fe1be-1020-40fd-8bf8-3515c6770e69",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8f1a7d215ab049a34f49b653d25373e44356bf09ab365e27507fb00519e1021a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
