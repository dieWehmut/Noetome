# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "67d9afa5ec1932ddef858857d2d7a71095005e2857359c4f4c50f968bf679b18"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8be254a52ad43e98701cbbdc71232343883ebc8d73a6519acd25889183cd0ee3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b9577fbafb29e9d07e5107bcde8811ef165b42cca6980b8e07f470613227a072"
    },
    "request.json": {
      "byte_length": 2241,
      "sha256": "a6025ff86c8ab9b17d58c12c2efdffca189c8b8013078b4284656ef98bf9316b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0e96f38e851a9f98fc60eb5fd37defe3c06b28c9d35a4e606eb73f3de5792c21"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6d35e891a5f11969c4c30c8bb9d8b2de8d4f16dc264b2ee16b0e9b15b36c063f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9054662f-a9ef-4101-8459-9dc6eddd2fdf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6331fa99-3057-4bc6-96b7-a85f56ef99ba",
    "source_id": "5948b3ff-3467-431e-91e1-3eda17d6dfb0",
    "version_id": "5ed7af8a-a9ef-443a-95b5-05f93864c902"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38267/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "90fb0798-6b44-4c5b-abc1-ca832eb173bc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0e96f38e851a9f98fc60eb5fd37defe3c06b28c9d35a4e606eb73f3de5792c21"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
