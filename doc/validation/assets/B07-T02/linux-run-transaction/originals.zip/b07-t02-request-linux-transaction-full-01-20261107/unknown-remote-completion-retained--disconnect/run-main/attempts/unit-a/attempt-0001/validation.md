# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3aa8ff6c6b96dddd42098e7ec88ee2cdbe8eacce81a49d7f8841622c3f2dc7a3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dcf4dcaf7c063293001f171948e08f07822901c8dd631c90411b77e702e70379"
    },
    "request.json": {
      "byte_length": 2241,
      "sha256": "65e508fe7d4094ef879f77eb8672b9f6e89ebdf89a349be6e11de62603e7c3b7"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 482,
      "sha256": "48c7ff356d487813731ba47035e7a95aaf653dc9b088bceb9dbd5f00794f6462"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6c6798a0-ab53-42ae-8d85-6ab04cc1b666",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "95e21e9d-732e-4b3e-9e7c-316a5c61d8be",
    "source_id": "06b1d38e-9098-49d8-9af0-73517515af39",
    "version_id": "71d93614-721d-4ab1-9b58-da6d24aa9f65"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38267/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRANSPORT",
      "message": "EXTRACT_API_TRANSPORT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "40d6ea75-00c6-432a-ab57-4a2e27f3d656",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
