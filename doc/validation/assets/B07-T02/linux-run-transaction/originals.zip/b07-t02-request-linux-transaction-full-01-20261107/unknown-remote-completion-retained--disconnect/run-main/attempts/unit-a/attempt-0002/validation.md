# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b67d2157f9df17fccaf37fe10a2d53ae883ba18404e441b9ec2319fe76c625a3"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b40ee4dedc7b98811f75c244006e7ee2e433298c3202c30b8bf78040d93d0c0b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7d7367eba0236bb5245eb383c5252332fffb5aafc1bab4af8e9cb4fdeff8297e"
    },
    "request.json": {
      "byte_length": 2241,
      "sha256": "b0277f199172f82c4cd7ef9685d51a798b965fca3c8e0656a605e63de91ab2a0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fafa6fa62b56e96aac77b1384e7c5a4cf16c1a26c2774b5eb935006edae8168e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7ca50c38558cc723a5ea74b542aaab86875c522d9c3f182a07e39ff7878dddf1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6c6798a0-ab53-42ae-8d85-6ab04cc1b666",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "95e21e9d-732e-4b3e-9e7c-316a5c61d8be",
    "source_id": "06b1d38e-9098-49d8-9af0-73517515af39",
    "version_id": "71d93614-721d-4ab1-9b58-da6d24aa9f65"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38267/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "102adc43-fb01-414f-ad53-6b525ef05934",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fafa6fa62b56e96aac77b1384e7c5a4cf16c1a26c2774b5eb935006edae8168e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
