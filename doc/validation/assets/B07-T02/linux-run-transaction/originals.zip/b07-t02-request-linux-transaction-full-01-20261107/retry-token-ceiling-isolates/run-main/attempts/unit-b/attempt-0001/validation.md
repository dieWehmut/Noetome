# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8001be43a878a6c4f68443ab0099514c5b65e0a07fb566ec6a2f506c53a962d2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "41cfc0ac096103e5e98e2042c1d676429eaed957cc331d2d9eed3bcb72d369f9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b7f2aebfc1356600ad36616b4a88fb6064eab58dc37e8c88cc61253a6d3a4fab"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "1501956d7bd0a16f77b4751c6c36dd476c933fc2c91fb91523eb29ae9e3dad02"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a30772ab26afb852aff68ee21c77df3ea43cfd1f383ebffda452f44a2add9d79"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "781a22a47cec89e98294d90a97260b902f8d8feb07803aa7bc0c84449ef028b1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7b0dc373-94d9-4133-ad01-88964e39ed5d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "bcfcfd08-2e08-4e89-81b7-252907e38442",
    "source_id": "6b940016-5c6b-4807-9cdd-b1b55893be66",
    "version_id": "ffb8efe6-eb30-4789-9597-969b29f2c0db"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38107/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "83d5f9d3-594e-489f-87ad-dcf2490cc164",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a30772ab26afb852aff68ee21c77df3ea43cfd1f383ebffda452f44a2add9d79"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
