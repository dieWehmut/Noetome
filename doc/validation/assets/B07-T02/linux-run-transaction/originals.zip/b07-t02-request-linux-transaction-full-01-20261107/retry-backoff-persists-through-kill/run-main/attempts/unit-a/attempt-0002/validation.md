# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fe490c1a886404e17655a065b4354a935f4a74fff312c01bd6988fe9be01a58f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5541c1b07b807d5abe1a423a6860866ec2e95cd5dc5e0c84d02353d34f43465c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4b493ef7bafd9e94169896dd190c28a5d40b20b00cbd44b270b146566c3a5157"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "3d0a86a38d9f2c66fbd434877294e3de754fbfcedae4bc0b77824c892a91c531"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3ce3bab556559be5c885bf7ec739d9147b5d83b646cc0cd453031137f0c5fe06"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d0b9b33d00820c832c7a07bc8d2e3476733e3de7f2694c5185bf94bd0622014f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7d56e6c2-cabd-4a3c-9c6d-1d64725640ef",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ecb921b6-4e6f-419b-9b98-5352b47ea7c4",
    "source_id": "b4537137-1161-49da-afa9-a17857c54ebd",
    "version_id": "9221711b-eb39-47fd-b042-49dabe1f0e2d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38203/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "543e87f4-fe4a-4baf-9f27-c0fc3e76c578",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3ce3bab556559be5c885bf7ec739d9147b5d83b646cc0cd453031137f0c5fe06"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
