# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c60c1d3923a71e1fcfcb11690232f793d540d92f1eb8af64a65319aa1b022ea2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "09995e300cafe3333f28088ef7a9c1fa39e51d9989416b82690de08762b85626"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "fa1f8d6317fc8bd96979d57001b6842cf7a6a1b1d365772fe981b12a2edce7b6"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "4867c62882508e020851cde5b59c5f3c482d80ab976d84ae9ef3df825f13b79f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b9e7c4e7439ae7e4cc7c3cb04a5bd3db452407703da09439f707cd36e5a9dc92"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b7511a38091b0847e63dd0b34a1a5fc81671b81e0ba7538cc0b12f714232e109"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "64fb6b7b-dfd8-417a-aab7-7240f322ae33",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "13eb2ad7-3a5c-4ace-9e5b-714d7c061998",
    "source_id": "48764c33-cfa6-4a4f-a6f9-d8b99f58d325",
    "version_id": "b10b193f-99f3-4067-9f63-762ce62f2fbf"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38203/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "648b73ae-8118-4824-8f9d-c2f99282ed4c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b9e7c4e7439ae7e4cc7c3cb04a5bd3db452407703da09439f707cd36e5a9dc92"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
