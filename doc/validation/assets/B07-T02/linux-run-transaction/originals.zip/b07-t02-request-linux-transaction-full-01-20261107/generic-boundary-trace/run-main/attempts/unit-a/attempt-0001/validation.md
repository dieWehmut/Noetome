# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fe5cd4698c443b1034361c75155715b02d0bcb59f7e8aabc0f9c2ea3d7ac347a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6cb4fc770cad128395a2b8aed84e4984551408751fa3137d11b03de55262f5af"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2c86832a0871db72cbe89f9e1da6d9e4d74580348318d9672de91b659ef5a86f"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "86851bc69a4423d5b65e1c745b0c6a749bbc76bca708a474b044904c7cfb6bd7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6550153f64a3659b323bde02a24be36c3b6101fab3437f8883801fe4b3583aff"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "929215db4952a5792d6354b48265ac3942d2fb35c89f291f53dd3c569df45fb1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b5463239-60e8-452f-9fcd-ce4250720cf2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f855a617-afb2-4295-8915-8c591409eff8",
    "source_id": "41987ce3-7006-45d5-8d13-dab19e78eecd",
    "version_id": "548c979a-ee91-4938-81b0-3dac6381b96f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36705/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a0fb0271-1408-4eda-8c9f-a3a1e4f18e58",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6550153f64a3659b323bde02a24be36c3b6101fab3437f8883801fe4b3583aff"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
