# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "94fd9b580984d46b2afe9d647de84438d3cb0a65c427b81d67a372c81d7d4273"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "193a468340cfa388100651eb4f79b6a01bd4327f40773c97c8bebaf4ca84e9ac"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d7d29072b7c3f9bce82e0ed7a8c977f10bd48f33a0d0645b2ca275469c9e9e90"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "ba6866deed9edd590a34967a0bef6a1f567a4db96f55a0fab1546c5391b7d332"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "760f25db41685b62df981a5e8c1d0d979e56bf84d880a05fe4a269ca9ee7ed2e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6b970ae2fb5c666a4e4e3d02bf2687f6ccf8508796856f8ad5fec3b0678e4858"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d072c68d-1f0f-46b4-b8b1-dc3a5185e46e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "502c8b7e-4b07-4d14-9540-b856af1dcbeb",
    "source_id": "69b75eaa-6d02-4583-9a6a-847f9be50b9d",
    "version_id": "e8238094-5d6c-48ea-8cb0-dde12c79fb1f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36437/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2a9f4730-0502-4294-a57b-442c03f47cbe",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "760f25db41685b62df981a5e8c1d0d979e56bf84d880a05fe4a269ca9ee7ed2e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
