# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c0659892c98995ee86084f3e87aa6e2c90a501661e14c9b6199dd3fd399b6d93"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "729593cc54ec6500f28771d1fee6675f216fc5548757804941da28f78540b640"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "790cbe1e24951cfc77efed1869de96260b5bbd30e84ef5610f56e5beb31c9bb0"
    },
    "request.json": {
      "byte_length": 2229,
      "sha256": "4e15590ffa76a84d09f5b2a318044bb9d9748e2f31bebfd655f8c7c1afd1eedb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "13345a2b033430989a9f139337050c7ea084067da95b3141da3ad856f7697a20"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2a1ed4ef29139b07ffae3d067cfe794db59b8253a0840cfad303c6344f4b2b7e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ac1f0789-ca10-449a-ac47-a47a4b61fd47",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "066a55eb-7a36-4bf4-86e4-124e01cb6ec2",
    "source_id": "ece74542-34c1-4c21-9479-4ea303bc1c33",
    "version_id": "ecb1c64f-e22a-4cc1-9956-02c700d37059"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37265/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2da160bf-dd10-41fe-8545-ced0e89f3e6b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "13345a2b033430989a9f139337050c7ea084067da95b3141da3ad856f7697a20"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
