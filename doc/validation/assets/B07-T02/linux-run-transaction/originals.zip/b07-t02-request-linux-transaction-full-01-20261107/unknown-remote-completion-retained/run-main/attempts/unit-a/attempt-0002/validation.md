# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9ddaf1e6e4433388e791efd08ad9861cdf7be311ac114078c22f7c41f888af6d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "30be7f267a4005b757f39c4b8c60dad30543b58a0601a837f5fb7566701749e8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "336c2d2878744cde86b3d4f3ec3a01a5abeed97f285c921c6fcc58a99f2ce8f5"
    },
    "request.json": {
      "byte_length": 2229,
      "sha256": "a9fc484e43496a9e5e09ba1b7cd6f585c127068c73ee9ef6b28af2505768f676"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0fbd9254e42196b58d9fb9c217c73d5c42dc96a5932d370db1c27e250d8fa244"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fe0724a14e9a1ff7286ed03383aeded6673d59156f9272f775b7267d7ffb983e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a646607e-efb4-4ebb-8bb6-42fef2bec502",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "898c20bb-c485-4f44-b9e7-620c7a93067e",
    "source_id": "f90df436-d115-45b3-bf24-fd0f99a93bf6",
    "version_id": "c77ac6a9-878b-42be-a3ac-6c6f5ebf6f19"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37265/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ea73970a-53be-40f0-8d29-254ae93c9721",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0fbd9254e42196b58d9fb9c217c73d5c42dc96a5932d370db1c27e250d8fa244"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
