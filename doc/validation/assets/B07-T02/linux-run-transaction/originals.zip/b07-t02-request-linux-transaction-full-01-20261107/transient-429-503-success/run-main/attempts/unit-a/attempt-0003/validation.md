# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3481a2fb1fb10b3285bc2cc00d1cc5dd3627eef3c80ac75b3a002a366a29625f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fbd814656f1eeeb9e7e37d12ab17c43851e3af904f7df0f63cca0607ea8aa280"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b5fb4a783c79141b476e9555ae2b896d8ed8c0a3f40a3533a70cff2264173d54"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "04d0c17e7420a42ae083038847d44961249219b111e7d7c196982138f53aabea"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b52cd72a9c4abb31ca28a1350861c6c44bef9c0dd4a2fe649813d2e315c2858e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1d7ffc063608f806e98886e5a3688ce6ff69fe6d38fb4dcf008ba6de52c4c3c0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "423c364e-6743-40a3-8212-2827d3137dcd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e356e61f-56e3-4e40-b9e8-a72593d8965e",
    "source_id": "3d7f2d01-8b90-4088-8303-5b3b385f6a80",
    "version_id": "32a8a74f-a66f-4893-a19d-8fd79cf37663"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36751/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bd6b4e21-a65b-4c71-98e1-66d9ed7efa30",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b52cd72a9c4abb31ca28a1350861c6c44bef9c0dd4a2fe649813d2e315c2858e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
