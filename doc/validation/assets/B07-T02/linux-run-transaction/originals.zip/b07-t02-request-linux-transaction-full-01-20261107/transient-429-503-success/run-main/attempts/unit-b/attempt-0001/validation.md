# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "065c1d3fd10f59f46ea561040b46e619ea38f47baa62e67874412e7c62c557b1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "727766c76cbc110c0b75b719faa760ae6b7f3c7e60c9f64321a4ca0b63554adc"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5084bd201f5a4a994348cd0f0dc07216062c4cec5c386b5e80190f8015b63767"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "8b0525a5e070687348ced5a718fa2926b45a8553b4b72541ef0293ab2129e61c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7bd8f27e44bd5300635dc4eef7b0c16bb65767d05d33524e2e7c23dcc0fd83d1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1653a252532ff45b0a8faeb5ddd7eeb06c648a89aa1e2fc914b74ebacd21ec26"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "270eba78-00e4-4986-9734-9f205f3db154",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "593c7344-2cf3-47f9-b431-808ed790b52b",
    "source_id": "8c757b28-34cf-4ba7-a3b0-0c301dcbdfdf",
    "version_id": "8155888b-ff0f-4921-8b34-5911c80552a0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36751/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "55a25c8c-3162-4d5d-8cc1-6c2cd1b659bf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7bd8f27e44bd5300635dc4eef7b0c16bb65767d05d33524e2e7c23dcc0fd83d1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
