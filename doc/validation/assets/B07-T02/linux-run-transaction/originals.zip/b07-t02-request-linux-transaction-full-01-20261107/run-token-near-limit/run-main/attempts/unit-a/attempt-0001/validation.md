# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "460872e90bc0cf816d1a0d314f0267954c27180f4a91b33e176cc314e9f40495"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "72921d02bc0181a0f2ddd2267e41c5d45e104bdc22350d921b6ce116fdc2913c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6bfa233b77629d2a042d46534349bd11751988e1261fa8d8b87ea3f56eca166f"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "221cb433524fa296582ac7b84d65110f90bce677adfe8bcdb321203a465df8d8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "46219769a5cb2bf105c537d5d7be39d158045dae2abcee6160f4db3fea232d6e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "903382928d79494f649258c41781c2b3acb1c56e5ecf8c1b364ed142cf353f61"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ddd7b941-48dc-48ad-8e36-c2c21111f45f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ad31ce93-33a3-48f3-b529-332f270ef50c",
    "source_id": "48b8217d-4b83-4e78-8bc5-efdc40c43575",
    "version_id": "4972f6e9-38f5-4700-97b8-b4e1dc8ea52a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37841/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "08358b40-0a0f-460f-97a6-188572753784",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "46219769a5cb2bf105c537d5d7be39d158045dae2abcee6160f4db3fea232d6e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
