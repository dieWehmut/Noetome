# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6d05012fc0ed595a9d36017ecb9438d6965f6dc753849425c74a19a7a2f4ca9c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d5bba1da948bb8e7ac765bd8f269035e6db5780b76026f4b03504000a89c7df8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9cd90c99a496559a0efe233f1e84fc2c3e61605eb15a4c3873391372b6b934b0"
    },
    "request.json": {
      "byte_length": 2241,
      "sha256": "708245c60e4f3f7a8eb132ae3be5266e0014f18564a01202a712cba4120ff70d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8112b3b54bd558b50bc8053676db81271ee887c8fc0523b1f55e094f6a3331e1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fe5bfed960e26679cff29443a28cf842a8562a9aa24f4e3a267e0730a115f255"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ad5640e8-1ae0-4224-902c-4017d8403a65",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "079d6f8a-babc-4a5d-94b9-05c1538df7b2",
    "source_id": "010d1f57-b93c-486b-af8e-267283ac0b4c",
    "version_id": "bcb52636-620b-463d-a12e-65bdb8562777"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38283/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "135f3115-6310-4f15-aec6-c0173919aecc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8112b3b54bd558b50bc8053676db81271ee887c8fc0523b1f55e094f6a3331e1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
