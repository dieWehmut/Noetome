# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "105ed2ac4c9ebc7db9ae53ee24cb69919dc01d7de3e9a8461d12cd1e5ce3bd27"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0fbff47595626324904329fa5a1a0066315c20438ac787ba4520c5c1d0a30497"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2e06508c6be9d2f97aedaa0dc766d10dfb0acfdd7f722e029000913590574e7b"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "041fa9c8d8af34b9d3fe2822543b5063cb43e538cc1b97d066768b8e3e18791a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "174d0a1f65e40698e31ed2d1c5e47ce6eda971de35e49f06670e37b7a8ff7220"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "82a32ab0bd720b66f1ce47518329082b1f6c5ecd1c954bef61b170bc834bf5b3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d93334ba-cbc1-48a8-a700-5ec2b46fdcb6",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1dc6e0d5-ccb1-455b-93cc-3b6b83cfee42",
    "source_id": "998ffced-f098-4bc0-819f-e7d40b1b4ef4",
    "version_id": "16975862-b07b-45cf-a4a3-cfaa4ecd4d2c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37615/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2e4e6093-0e24-4276-a020-b05cb1e4f218",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "174d0a1f65e40698e31ed2d1c5e47ce6eda971de35e49f06670e37b7a8ff7220"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
