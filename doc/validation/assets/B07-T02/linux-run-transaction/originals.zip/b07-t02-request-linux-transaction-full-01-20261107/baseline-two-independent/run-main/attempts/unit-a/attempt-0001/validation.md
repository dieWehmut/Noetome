# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e4dd4852c36e576cda92817929e7798e0f4751dab8c5451f6d0caac3558e497e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fdcec869bbe1daf958e18cfd1ac7487893b85aa5b9051de9bc0543ea5af32be5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c989d4488a1c4369553df225ce2b9ee7898cbcc7f86ed85769df1a19eaba98da"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "e7a182c534332773eb7ddacf06356c3a505c1951293fa8897666c04c393465f9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "182192319500d8e78a28631ff388eeb0e20b324b269bdcfb04777a3d582ce36d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "94fe0f3c16ed0c19bd11747bf579c3a6a2a2915b5b4a82b9cc4028925a1c7900"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "129b46e4-6697-4005-ad14-f0815f4125cb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76e38a25-ef7e-4849-8567-5bb6496be01c",
    "source_id": "6f496da7-40ff-4a56-b051-c33dbf25b92f",
    "version_id": "cdd9d601-4d36-4943-954e-801f99eb4a17"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37615/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "62b0076f-a572-4f58-ad15-f3bc04ad9353",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "182192319500d8e78a28631ff388eeb0e20b324b269bdcfb04777a3d582ce36d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
