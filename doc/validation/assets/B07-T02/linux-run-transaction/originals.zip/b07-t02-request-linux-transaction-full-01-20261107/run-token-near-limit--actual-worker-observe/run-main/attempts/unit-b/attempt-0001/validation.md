# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3e3a1a70c3a9610b5c12b4a79ba76e300400b68a6e453633bfc518e3d2cd90a6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b51cd7b0ff519f287c34d5214559f8333368b2932bec296645e7d707311419ec"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "741c92d44e81e5ec0b718e352635ce8dcc4b35e4340f7d0e00f4d9c331930899"
    },
    "request.json": {
      "byte_length": 2238,
      "sha256": "be0a0e08f2ed5d9ef16819e2909c8fa2410caa7f583a3f887744cebd403c13be"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ba55afc1921caaad522a93980a770bd5a7efe6ce5b78411940fa62974c56cd9c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0560ccba338e8d43d46d830cedb95645e4a2476ad5c270734bd99c29480d266b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "dc5a1f98-3762-4668-a811-7cabfbb8a68d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3174e4c2-80f3-42ea-9118-97e4bdb0bdf9",
    "source_id": "aef91a87-32f2-4e64-b9d5-60b632f2a671",
    "version_id": "e2141c91-74d2-4402-9094-79e7575108ce"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38057/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "25c68b20-1d23-461e-a471-ad60e23e4b6c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ba55afc1921caaad522a93980a770bd5a7efe6ce5b78411940fa62974c56cd9c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
