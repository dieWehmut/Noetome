from pathlib import Path
import os,json,hashlib,stat
b=Path(r'D:\Noetome\.artifacts\b07-t02-windows-release-pair-01-20261107')
rows=[json.loads(l) for l in (b/'release-cli-build.stdout.bin').read_text().splitlines()]
r=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='noetome' and r.get('executable')][0]
p=Path(r['executable'])
def observe(p):
 s=p.stat(); raw=p.read_bytes(); return {'path':str(p),'regular':stat.S_ISREG(s.st_mode),'dev':s.st_dev,'ino':s.st_ino,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'size':s.st_size,'sha256':hashlib.sha256(raw).hexdigest()}
a=observe(p);aliases=[]
for q in (p.parent/'deps').glob('noetome-*.exe'):
 if os.path.samefile(p,q): aliases.append(observe(q))
assert a['regular'] and a['nlink']>1 and aliases
assert all(v['ino']==a['ino'] and v['dev']==a['dev'] and v['sha256']==a['sha256'] for v in aliases)
print(json.dumps({'platform':os.name,'actual_Cargo_artifact':a,'actual_same_file_deps_aliases':aliases,'source_and_selected_scope':'No selected PE was created or run; source/control guards passed on original Cargo command.','root_cause':'Cargo-produced top-level release executable is a hardlink to its own deps artifact; added singleton check on temporary Cargo output rejected this normal layout.'}))
