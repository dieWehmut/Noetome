新artifact-only draft04，仅修正实际缓存路径与独立编译来源根混用。旧draft03及prepare03失败原件不改、不移动缓存、不造不存在的02/build-target。

--cache-target只能是release02实际用过的01/build-target；--cache-evidence-root独立指定已闭合02。两者必须同时出现。固定02原compiler-cache-scope.json SHA/长度且它与固定主receipt.compiler_cache_scope.receipt完全一致；其actual target必须等于prepare选择的physical Windows路径及Native context.env.CARGO_TARGET_DIR。新snapshot/source ZIP分别封存physical target和independent evidence-root，Native不再从target.parent猜证据根。

保持两旧Cargo完整row==fixed primary commands、02实际outer0和全部guards、四表same names及精确两old/new变化，source/control/selected固定actualIDmtime/普通单链接和Cargo临时自身多链接复制前后保护保持。两current release Cargo和新双FP/probe/selected完整体必须实际重跑。

草稿尚未prepare/launch；Root快审授权后使用新windows-release-pair-04根。完整Rust793/module32/fullPython/HTTP不在本窄构建执行器运行，所有旧结果不复用。
