仅 artifact 新 draft03，原 30ad 执行器和 release02 原件不修改。尚未 prepare、launch 或运行任何 Cargo/CLI/HTTP。

缓存仅允许已真实闭合的 windows-release-pair-02/build-target。原 snapshot、四清单、完整 build 主 receipt、outer 原件逐 literal SHA/长度绑定；原两个 Cargo JSON receipt 必须与该固定主 receipt 的完整 commands 行相同、exit0、源/资产/哨兵不变、无 timeout/guard error，outer 必须实际 exit0 及完整库存/controls 一致。

四张清单逐所有 name/SHA/length 比较，名称集必须完全相同；仅明确列出的 request_run.rs 和 request_budget_store.rs 两项可从既定 old pin 改为既定 new pin，其他任何文件或遗漏变化拒绝。该全部名单和两项 old/new 进入新 snapshot 与 source ZIP，Native 入口再次核对。

新 release CLI 和 cfg(test) driver 两个 Cargo 命令仍实际执行，新 selected 完整程序复制及各实际 FP/CargoJSON/T01 探针重新取得，旧程序/结果不复用。Source/control/selected 的固定 actual ID/mtime/single-link 防护保持；只有 Cargo 临时输出的自身普通 hardlinks 允许，复制前后实际 ID/time/nlink 必须相等。

此执行器仍只作窄 release build/probe，完整 Rust 新预期 793 和 budget32 不在这里运行，完整 Python/HTTP not_run。prepare/launch 需 Root 后续明确 release 本轮授权。本次源码是实际生产优化，不能沿用旧 release02 FP 或旧行为结果。
