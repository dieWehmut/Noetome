$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-01-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-01-20261107' --snapshot-sha256 'a5b6e15b20d70429330e2a98f60bd8c1c9ba96c82ec38a42fba59c17c872e7be' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '753b2f8c2d1704ad4d70a7ef82ce74df0e7e5c4fa454bfa1a1d47cdee3232e5e' --executor-sha256 'dfbb7abf33c09bb28df35c310239e9c305e16f865c28b9a9c6f845458c4ecd65'
exit $LASTEXITCODE
