"""Append actual Native08 build references; do not execute any staged script."""
from pathlib import Path, PureWindowsPath
import hashlib
import json

HERE = Path(__file__).parent
BUILD = Path('/mnt/d/Noetome/.artifacts/b07-t02-windows-release-pair-08-20261107')
NATIVE_BUILD = PureWindowsPath('D:/Noetome/.artifacts/b07-t02-windows-release-pair-08-20261107')
FP = 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12'
CLI_SHA = 'f6778071e8533819660e783a814b76d0d39a3b77ea254ddd0b66a65ad993adbc'
DRIVER_SHA = '68b890af5cfbc2d3c820365877e4c77822b687b3eeb21dec1b925c546ae86089'


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino, 'mtime_ns': after.st_mtime_ns,
                 'nlink': after.st_nlink, 'metadata_captured_before_first_read': True}


def main():
    preserved = {}
    for name, digest in [('plan.json', '942a3d2741dc960bd03a742adb3a4f0c4c46369d3c56f72fa356d01631d8dfab'),
                         ('stage-copy.json', 'f15f3ee5f11246e73f94779dc278939f7b541fb5eab8d81f894cf52347311935')]:
        raw, pin = capture(HERE / name)
        assert pin['sha256'] == digest
        preserved[name] = {'path': str(HERE / name), 'pin': pin, 'raw': raw}
    plan = json.loads(preserved['plan.json']['raw'])
    assert all(plan[key] is None for key in ('future_native_build_root', 'actual_selected_FP', 'actual_original_CLI', 'actual_original_driver'))
    controls = {}
    for name in ('selected-build-receipt.json', 'release-build-receipt.json', 'outer-native-result.json'):
        raw, pin = capture(BUILD / name)
        controls[name] = {'original': str(BUILD / name), 'pin': pin, 'raw': raw}
    selected = json.loads(controls['selected-build-receipt.json']['raw'])
    release = json.loads(controls['release-build-receipt.json']['raw'])
    outer = json.loads(controls['outer-native-result.json']['raw'])
    assert selected['actual_compiler_fingerprint'] == release['actual_cli_and_driver_compiler_fingerprint'] == FP
    assert release['actual_cli_cargo_fingerprints'] == release['actual_driver_cargo_fingerprints'] == [FP]
    assert release['source_count'] == 2056 and release['source_before_after_equal'] is True
    assert len(selected['commands']) == len(release['commands']) == 11
    assert all(command['exit_code'] == 0 for command in selected['commands'])
    assert all(command['exit_code'] == 0 for command in release['commands'])
    assert outer['exit_code'] == 0
    for key, sha, size, name in [('cli', CLI_SHA, 16480256, 'noetome.exe'),
                                 ('test_driver', DRIVER_SHA, 22996480, 'noetome-cli-testdriver.exe')]:
        assert (selected[key]['sha256'], selected[key]['byte_length']) == (sha, size)
        assert PureWindowsPath(selected[key]['path']) == NATIVE_BUILD / 'selected' / name
    assert selected['source_snapshot']['sha256'] == release['source_snapshot']['sha256'] == 'ca280811c714992a51be9a25d4ad580c428375a9dde1681b617ebb56cae64814'
    assert selected['source_archive']['sha256'] == release['source_archive']['sha256'] == 'b4f573f943927aa51ea63ae2981dfe1d0295f8841cf4d47c18809fdfd6fc6479'
    assert selected['source_archive']['byte_length'] == 8239314
    assert selected['source_snapshot']['byte_length'] == 629328
    receipt = {
        'status': 'actual_Native08_build_handoff_references_prepared_no_stage_execution_authorization',
        'NativeBuildRoot': str(NATIVE_BUILD), 'Fingerprint': FP, 'CliSha': CLI_SHA, 'DriverSha': DRIVER_SHA,
        'actual_cli_original_from_build_receipt': selected['cli'],
        'actual_driver_original_from_build_receipt': selected['test_driver'],
        'actual_snapshot_reference_from_build_receipt': selected['source_snapshot'],
        'actual_source_archive_reference_from_build_receipt': selected['source_archive'],
        'source_members_in_actual_release_receipt': 2056,
        'source_ZIP_members_declared_by_Root_not_recounted_here': 2061,
        'small_original_control_readbacks': {name: {k: v for k, v in record.items() if k != 'raw'} for name, record in controls.items()},
        'immutable_prepared_plan_and_stage_originals': {name: {k: v for k, v in record.items() if k != 'raw'} for name, record in preserved.items()},
        'caller_parameters': {
            'normalize.ps1': {'NativeBuildRoot': str(NATIVE_BUILD), 'Fingerprint': FP, 'CliSha': CLI_SHA, 'DriverSha': DRIVER_SHA},
            'ordinary.ps1': {'NativeBuildRoot': str(NATIVE_BUILD)},
            'three.ps1': {'NativeBuildRoot': str(NATIVE_BUILD)},
            'full.ps1': {'NativeBuildRoot': str(NATIVE_BUILD)},
        },
        'authorization_at_capture': {'normalize': False, 'ordinary': False, 'three': False, 'full62': False,
                                     'independent_preflight_completed': False, 'sole_timing_window_GO': False},
        'preserved_limits': {'elapsed_unit_ms': 1500, 'backoff_ms': 1000, 'API_ms': 200, 'expired_wait_ms': 1700, 'R': 8310},
        'execution_sequence': 'Wait for all other workloads closed plus current independent preflight and Root GO. Then normalize; ordinary a7ef once final failed status expected3; frozen three once, every case needs real own-PID kill/wait; any miss STOP. Full62 only after allthree passes and separate Root GO. No extra or old C2/c61/57 reuse.',
        'readback_scope': 'Only three small actual build/control JSON originals read with WSL first-read metadata and byte guards. PE/source-ZIP whole bytes are references to the closed build and await independent preflight; this producer did not hash them or claim actual Windows volume/index proof.',
        'new_product_CLI': 0, 'new_driver': 0, 'new_HTTP': 0, 'new_Native_processes': 0,
        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': capture(Path(__file__).absolute())[1]},
    }
    for record in [*controls.values(), *preserved.values()]:
        path = Path(record.get('original', record.get('path')))
        raw, after = capture(path)
        assert raw == record['raw'] and after == record['pin']
    output = HERE / 'handoff-actual-build.json'
    with output.open('xb') as stream:
        stream.write((json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'status': receipt['status'], 'handoff_pin': capture(output)[1]}))


if __name__ == '__main__':
    main()
