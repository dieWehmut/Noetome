"""Retain the first pending plan and correct only its underscore status label."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).parent
PLAN = HERE / 'plan.json'
ORIGINAL = HERE / 'plan-first-label-original.json'
assert not ORIGINAL.exists()
before = PLAN.stat()
raw = PLAN.read_bytes()
after = PLAN.stat()
fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
assert fields(before) == fields(after) and before.st_nlink == 1
assert hashlib.sha256(raw).hexdigest() == '59ed9edb135592d4235be35ae15caa09085ba0f0a000390fcbfdad07cf1a9542'
old = json.loads(raw)
assert old['status'] == 'prepared_only_registered_identity_native_handoff_pending_not_executed'
new = dict(old)
new['status'] = 'prepared_only_standard_lock_native_handoff_pending_not_executed'
assert {k: v for k, v in new.items() if k != 'status'} == {k: v for k, v in old.items() if k != 'status'}
PLAN.rename(ORIGINAL)
assert ORIGINAL.read_bytes() == raw
new_raw = (json.dumps(new, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
with PLAN.open('xb') as stream:
    stream.write(new_raw)
receipt = {'status': 'pending_plan_one_status_label_correction_original_retained',
           'original_plan': str(ORIGINAL), 'original_sha256': hashlib.sha256(raw).hexdigest(),
           'corrected_plan': str(PLAN), 'corrected_sha256': hashlib.sha256(new_raw).hexdigest(),
           'old_status': old['status'], 'new_status': new['status'],
           'all_other_JSON_fields_equal': True, 'no_product_driver_HTTP_Native_calls': 0,
           'scope': 'The original generator replaced hyphenated path labels and left one underscored pending status label. Only that metadata label is corrected; original plan bytes are retained without overwriting. No FP/body/source/cap/path/kill policy changes.'}
with (HERE / 'plan-label-correction.json').open('xb') as stream:
    stream.write((json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
print(json.dumps(receipt))
