"""Copy exactly seven frozen scripts to the explicitly authorized new wrapper.

This standalone source is saved before use. No subprocess/Native product/HTTP.
"""
from pathlib import Path, PureWindowsPath
import hashlib
import json
import os

HERE = Path(__file__).parent
SOURCE = HERE / 'frozen-bundle'
DESTINATION = Path('/mnt/d/Noetome/.artifacts/b07-t02-native-registered-identity-wrapper-01-20261107')
PLAN = HERE / 'plan.json'
PLAN_SHA = '8c3d9d4753c86c450f512b0e2f8ae6df63148147efb9a031ea26737b50033bec'
EXPECTED = {
    'normalize_build.py': ('9fbc7c68c60c7f06bbd286d65b275fc26df99bc56326ce6ef4d91bda3cdd40af', 10711),
    'narrow.py': ('a7ef5424797ec59d5aebc8382ae26acb91a0885c3ff40ccb07e492b4d7d8bff3', 14081),
    'run_stage.py': ('11ab48b314f2ac95eed0c507d7fca13f318ec0b012f093442a56e5dc932d19ae', 3035),
    'normalize.ps1': ('6e53aa8badfc90dbe08e38458d744a6998ce2f74b224ce637f3cbcc1a17a765d', 1875),
    'ordinary.ps1': ('2489021257a941a2d10d5d44d91016e8b9a307e8cb7f9bdf9f53dd1c95383945', 1800),
    'three.ps1': ('bd2c90c9b723fd2597d80bc83dc0dd8f670186bfeb6e97abca54c411c6578edb', 1780),
    'full.ps1': ('ce6a70f397decdab586d278daa86e9220567baa7a79d9250a235c1ad23cc7dc5', 1803),
}


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino, 'mtime_ns': after.st_mtime_ns,
                 'nlink': after.st_nlink, 'metadata_captured_before_first_read': True}


def main():
    assert not DESTINATION.exists(), 'specified unused wrapper only; never overwrite'
    assert DESTINATION.parent.is_dir() and not DESTINATION.parent.is_symlink()
    plan_raw, plan_before = capture(PLAN)
    assert plan_before['sha256'] == PLAN_SHA
    plan = json.loads(plan_raw)
    assert PureWindowsPath(plan['future_native_wrapper_root']) == PureWindowsPath('D:/Noetome/.artifacts/b07-t02-native-registered-identity-wrapper-01-20261107')
    for name in ('future_native_build_root', 'actual_selected_FP', 'actual_original_CLI', 'actual_original_driver'):
        assert plan[name] is None
    assert {path.name for path in SOURCE.iterdir()} == set(EXPECTED)
    originals = {}
    for name, expected in EXPECTED.items():
        raw, pin = capture(SOURCE / name)
        assert (pin['sha256'], pin['byte_length']) == expected
        originals[name] = {'raw': raw, 'before': pin}
    DESTINATION.mkdir()
    copies = {}
    for name, original in originals.items():
        target = DESTINATION / name
        with target.open('xb') as stream:
            stream.write(original['raw'])
        os.utime(target, ns=(target.stat().st_atime_ns, original['before']['mtime_ns']))
        copy_raw, copy_before = capture(target)
        assert copy_raw == original['raw']
        copies[name] = {'original': str(SOURCE / name), 'original_before': original['before'],
                        'destination': str(target), 'destination_before_after_first_read': copy_before}
    assert {path.name for path in DESTINATION.iterdir()} == set(EXPECTED)
    for name, original in originals.items():
        source_raw, source_after = capture(SOURCE / name)
        copy_raw, copy_after = capture(DESTINATION / name)
        assert source_raw == original['raw'] == copy_raw
        assert source_after == original['before']
        assert copy_after == copies[name]['destination_before_after_first_read']
        copies[name]['original_after_independent_readback'] = source_after
        copies[name]['destination_after_independent_readback'] = copy_after
    plan_after_raw, plan_after = capture(PLAN)
    assert plan_after_raw == plan_raw and plan_after == plan_before
    receipt = {
        'status': 'seven_frozen_scripts_exact_stage_copy_readback_passed_no_execution',
        'PID': os.getpid(), 'copied_script_count': 7,
        'target_root': str(DESTINATION), 'target_Native_path': plan['future_native_wrapper_root'],
        'source_and_copy_SHA_length_bytes_all_equal': True,
        'source_identity_mtime_bytes_before_after_equal': True,
        'destination_identity_mtime_bytes_after_write_then_independent_reads_equal': True,
        'files': copies, 'immutable_original_plan_before': plan_before,
        'immutable_original_plan_after': plan_after,
        'future_actual_Native_build_root': None, 'future_actual_FP': None,
        'future_actual_CLI_body': None, 'future_actual_driver_body': None,
        'new_product_CLI': 0, 'new_testdriver': 0, 'new_HTTP': 0, 'new_Native_processes': 0,
        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': capture(Path(__file__).absolute())[1]},
        'scope': 'Exactly seven scripts copied with xb into the specified previously absent wrapper. No normalization, PowerShell, Native Python, CLI, driver, HTTP or model ran. Source/std/plan immutable. WSL metadata is labelled separately and does not substitute for the later actual Windows volume/index, no-reparse and build/PE source preflight. Current FP/PE/build root remain pending; no C2 values reused.',
    }
    with (HERE / 'stage-copy.json').open('xb') as stream:
        stream.write((json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'status': receipt['status'], 'PID': receipt['PID'],
                      'target': str(DESTINATION), 'actual_receipt': capture(HERE / 'stage-copy.json')[1]}))


if __name__ == '__main__':
    main()
