"""Artifact-only native checks of the unchanged frozen elapsed/dual cases.

The ordinary elapsed case uses no test driver and observes actual SQLite commits.
It does not reuse the no-kill timing profile's incompatible final expectations.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time


def ordinary_elapsed(recorder, audit, case):
    selected = audit.prepare_case(recorder, case)
    server = audit.ArtificialHttp(
        selected["server_root"], recorder.fixture, selected["routes"], case["units"],
        lambda request_id: audit.lookup_persistent_attempt(selected["budget"], request_id, selected["authority_file"]),
    )
    with server:
        audit.write_api_configs(recorder, selected, server, case)
        recorder.command(["run", "api", "init", selected["authority_file"], selected["budget"]], expected=0)
        active = recorder.launch(
            ["run", "api", "start", selected["configs"]["run-main"], selected["budget"], selected["run_roots"]["run-main"]],
            label="ordinary production elapsed real interruption; no cfg(test) callback",
        )
        observation_started_utc_ns = time.time_ns()
        observation_started_monotonic_ns = time.monotonic_ns()
        end = time.monotonic() + 10
        while True:
            audit.require(active.poll() is None and not server.errors, "ordinary CLI exited or synthetic server failed before durable first retry/B completion")
            fast = audit.coordination_chain(selected["budget"], selected["authority_file"])
            a_first = [(key, attempt) for key, attempt in fast.attempts.items() if key[1:3] == ("unit-a", 1)]
            b_success = audit.settled_success_attempts(fast, "unit-b")
            if len(a_first) == len(b_success) == 1 and a_first[0][1]["retry"] is not None and all(run["units"]["unit-b"]["outcome"] == "succeeded" for run in fast.runs.values()):
                observed_committed_state_utc_ns = time.time_ns()
                observed_committed_state_monotonic_ns = time.monotonic_ns()
                break
            audit.require(time.monotonic() < end, "actual ordinary first retry/B completion observation bounded")
            threading.Event().wait(0.002)

        # B is terminal and A has an original not-before time. Check all original
        # files in a quiescent window; the reader's preservation checks stay strict.
        before, before_evidence = audit.read_authority(
            selected["budget"], fixture=recorder.fixture, authority_config=selected["authority_file"],
            selected_run_roots=selected["run_roots"].values(), expected_fingerprint=recorder.build_fingerprint,
        )
        audit.require_event_prefix(fast, before)
        key, first = next((key, attempt) for key, attempt in before.attempts.items() if key[1:3] == ("unit-a", 1))
        b_before = audit.settled_success_attempts(before, "unit-b")
        audit.require(len(b_before) == 1 and all(run["units"]["unit-b"]["outcome"] == "succeeded" for run in before.runs.values()), "B original Known700/full200/sealed/validated and terminal before ordinary kill")
        audit.require({k for k in before.attempts if k[1] == "unit-a"} == {key} and first["state"] == "unknown" and first["transport_sealed"] and first["retry"] is not None, "ordinary A first retry only; original response sealed; A2 absent")
        receipt = first["receipt"]
        audit.require(receipt["network_attempts"] == 1 and receipt["http_status"] == 429 and receipt["response_complete"] is True and receipt["usage"] is None and receipt["error_code"] == first["retry"]["error_code"] == "EXTRACT_API_HTTP_RATE_LIMIT", "actual complete429/RATE_LIMIT retry, never transport substitution")
        with server.lock:
            first_received = copy.deepcopy([r for r in server.receipts if r["unit_id"] == "unit-a"])
            received_b = copy.deepcopy([r for r in server.receipts if r["unit_id"] == "unit-b"])
        audit.require(len(first_received) == len(received_b) == 1 and first_received[0]["request_id"] == key[3] and first_received[0].get("advertised_status") == 429 and "response_before_write_monotonic_ns" in first_received[0] and "response_flush_monotonic_ns" in first_received[0], "actual original429 write and flush timestamps exist")
        original429 = audit.paths.read_observed_file(server.root / first_received[0]["response_file"])
        audit.require(original429 == audit.paths.read_observed_file(recorder.fixture / "wire/http-429.bin") and audit.sha(original429) == first_received[0]["response_sha256"] == receipt["response"]["sha256"] and first_received[0]["request_body_sha256"] == first["plan"]["request_body"]["sha256"], "ordinary actual server request/429 bytes equal complete API originals")
        b_key, b_attempt = next(iter(b_before.items()))
        audit.require(received_b[0]["request_id"] == b_key[3] and received_b[0].get("advertised_status") == 200 and "response_flush_monotonic_ns" in received_b[0] and received_b[0]["response_sha256"] == b_attempt["receipt"]["response"]["sha256"] and received_b[0]["request_body_sha256"] == b_attempt["plan"]["request_body"]["sha256"], "ordinary B server full200/key/body bind original Known700")
        scheduled = [row for row in before.rows if row["event"]["kind"] == "retry_scheduled" and row["event"]["key"] == first["plan"]["key"]]
        audit.require(len(scheduled) == 1, "one actually visible committed retry record")
        retry_at_ns = audit.utc_ns(first["retry"]["retry_at_utc"])
        original_deadline_ns = audit.utc_ns(before.runs[key[0]]["units"]["unit-a"]["spec"]["deadline_utc"])
        audit.require(retry_at_ns - audit.utc_ns(scheduled[0]["at_utc"]) == 1_000_000_000 and retry_at_ns < original_deadline_ns, "frozen1000ms retry fits original1500ms deadline")
        audit.require(time.time_ns() < retry_at_ns and active.poll() is None, "ordinary full original audit completed before A2 original not-before")
        killed = recorder.force_kill(active)
        audit.require(killed[2]["kill_requested_utc_ns"] < retry_at_ns, "actual own ordinary CLI OS kill requested before retryAt")
        killed_state, killed_evidence = audit.read_authority(
            selected["budget"], fixture=recorder.fixture, authority_config=selected["authority_file"],
            selected_run_roots=selected["run_roots"].values(), expected_fingerprint=recorder.build_fingerprint,
        )
        audit.require_event_prefix(before, killed_state)
        audit.require({k for k in killed_state.attempts if k[1] == "unit-a"} == {key} and killed_state.attempts[key] == first and all(killed_state.attempts[k] == value for k, value in b_before.items()), "ordinary postkill A1/B full original key/body/file/prefix unchanged and A2 absent")
        audit.save_json(selected["root"] / "actual-ordinary-retry-observation.json", {
            "ordinary_CLI_PID": active.pid,
            "explicit_test_driver_calls": 0,
            "actual_OS_force_kill_and_wait_receipt": killed[2],
            "observer_started_utc_ns": observation_started_utc_ns,
            "observer_started_monotonic_ns": observation_started_monotonic_ns,
            "committed_state_observed_utc_ns": observed_committed_state_utc_ns,
            "committed_state_observed_monotonic_ns": observed_committed_state_monotonic_ns,
            "retry_event_original_at_utc": scheduled[0]["at_utc"],
            "retry_at_utc_ns": retry_at_ns,
            "original_A_deadline_utc_ns": original_deadline_ns,
            "A_actual429_server_receipt": first_received,
            "B_actual200_server_receipt": received_b,
            "prekill_complete_original_audit": before_evidence,
            "postkill_complete_original_audit": killed_evidence,
            "scope": "Actual ordinary production CLI, no cfg(test) boundary observer. SQLite visibility is observed after COMMIT; event.at is not used as actual COMMIT-completion time. Original author1500/1000/API200/429 bytes unchanged. Full original audit and ownPID kill occur before original retryAt.",
        })
        waited_from = time.monotonic_ns()
        threading.Event().wait(1.7)
        audit.save_json(selected["root"] / "actual-deadline-wait.json", {"before_monotonic_ns": waited_from, "after_monotonic_ns": time.monotonic_ns(), "minimum_author_wait_ms": 1700})
        recorder.command(["run", "api", "resume", selected["configs"]["run-main"], selected["budget"], selected["run_roots"]["run-main"]], expected=(0, 3), label="ordinary sameRun original elapsed1700 recovery")
        after, after_evidence = audit.read_authority(selected["budget"], fixture=recorder.fixture, authority_config=selected["authority_file"], selected_run_roots=selected["run_roots"].values(), expected_fingerprint=recorder.build_fingerprint)
        audit.require_event_prefix(killed_state, after)
        audit.require({k for k in after.attempts if k[1] == "unit-a"} == {key} and after.attempts[key] == first and all(after.attempts[k] == value for k, value in b_before.items()), "ordinary resumed elapsed case preserves A1/B originals and sends noA2")
        audit.require(not server.errors and len(server.incoming) == len(server.receipts) == 2, "exactly original A429/B200 actual HTTP; no extra requests")
        traffic = audit.verify_server_receipts(after, server.receipts, selected["server_root"])
        audit.case_expected_check(case, after, traffic)
        stable = audit.protected_inventory(selected)
        recorder.command(["run", "api", "resume", selected["configs"]["run-main"], selected["budget"], selected["run_roots"]["run-main"]], expected=(0, 3), label="ordinary elapsed duplicate resume")
        audit.require(audit.protected_inventory(selected) == stable, "ordinary duplicate resume cannot change any owned original/event/charge")
        recorder.command(["run", "api", "status", selected["budget"], selected["run_roots"]["run-main"]], expected=3, label="ordinary elapsed terminal readonly status")
        audit.require(audit.protected_inventory(selected) == stable, "ordinary final readonly status preserves every owned original")
    audit.require({str(p): audit.paths.inventory(p) for p in selected["projects"].values()} == selected["source_before"], "ordinary true OS interruption complete source originals preserved")
    audit.verify_saved_envelopes(recorder, selected, after)
    audit.save_json(selected["root"] / "independent-audit.json", {"before": before_evidence, "after": after_evidence, "traffic": traffic, "scope": "Extra ordinary production elapsed author case; 0testdriver/1realOSkill, frozen2HTTP700+R8310 and same original Run/keys; separate from62matrix and3cfg(test)target counters."})
    recorder.cases.append({"case_id": case["case_id"], "status": "passed", "actual_HTTP_requests": len(server.receipts), "independent_totals": after.totals(), "actual_OS_kill_and_wait": True, "explicit_test_driver_calls": 0, "scope": "ordinary production CLI interruption extra check, no test driver"})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=("ordinary-elapsed", "three-targets"))
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--source-pins", required=True, type=Path)
    parser.add_argument("--cli", required=True, type=Path)
    parser.add_argument("--driver", required=True, type=Path)
    parser.add_argument("--build-receipt", required=True, type=Path)
    parser.add_argument("--new-root", required=True, type=Path)
    args = parser.parse_args()
    if os.name != "nt":
        raise RuntimeError("This wrapper must run under actual native Windows Python")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(args.repo / "scripts"))
    import verify_request_budget as audit
    expected = json.loads(args.source_pins.read_bytes())
    def inventory():
        return {name: {"sha256": hashlib.sha256((args.repo / name).read_bytes()).hexdigest(), "byte_length": (args.repo / name).stat().st_size} for name in expected}
    audit.require(inventory() == expected, "artifact selected current checker/author mini source exact pins")
    recorder = audit.Recorder(args.new_root, args.cli, args.repo / "fixtures/run-api-budget-v1")
    audit.save_json(recorder.root / "native-wrapper-runtime.json", {"actual_Python_PID": os.getpid(), "os_name": os.name, "sys_executable": sys.executable, "sys_version": sys.version, "mode": args.mode, "program": str(Path(__file__).absolute()), "program_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "source_pins_original": expected})
    try:
        recorder.bind_build_receipt(args.build_receipt, args.driver)
        cases = audit.author_check(recorder.fixture)["cases"]
        if args.mode == "ordinary-elapsed":
            ordinary_elapsed(recorder, audit, next(case for case in cases if case["case_id"] == "elapsed-limit-persists-through-kill"))
        else:
            for name in ("retry-backoff-persists-through-kill", "elapsed-limit-persists-through-kill"):
                audit.dual_unit_kill_case(recorder, next(case for case in cases if case["case_id"] == name), args.driver)
            original = next(case for case in cases if case["case_id"] == "unknown-remote-completion-retained")
            variant = next(value for value in original["variants"] if value["name"] == "OS-kill-after-accepted")
            audit.dual_unit_kill_case(recorder, audit.parameter_case(original, variant), args.driver, accepted=True)
        result = recorder.finish("passed")
        audit.require(inventory() == expected, "native current mini source beforeafter bytes unchanged")
    except BaseException as error:
        recorder.finish("failed", {"type": type(error).__name__, "text": str(error)})
        raise
    print(json.dumps({"status": result["status"], "mode": args.mode, "ordinaryCLI": result["ordinary_CLI_count"], "drivers": result["driver_count"], "cases": len(result["cases"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
