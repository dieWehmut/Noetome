# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bf0f932f17e823570ed36c1e79a5f1189361e759700599d0b6a836c60dbc2178"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "51737c8a1335103f51da17153dc968016036de658d0d3be0db2a44f0077f6de9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8a12dfe073e92434bc071219f26681b46217bc2a773d0f7bd4e10620457acbba"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "b39ab9352bf39d8ef39d3b470943eba05f39ca7e212c876f89f20868a0424247"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a93fd5b46657bfac4254088c3dde970ddc90d9126387d647e2bd87a5affe5ddd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fbae6c7c49b6062b9648630528a41e8f2eb49b3dbc8177f94e0b9b3332a6074b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7f1e17d5-467c-4360-9dfa-51fb085892e5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ca581c91-9b7d-4597-9a2a-52d9d230aabe",
    "source_id": "bf1c6bdd-9e23-4799-b1b7-6477fee9ce6b",
    "version_id": "926f0850-3f18-4550-86e0-c2bee7fbb39d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:61138/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c2d30c1c-4799-479f-bce9-fed24b150066",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a93fd5b46657bfac4254088c3dde970ddc90d9126387d647e2bd87a5affe5ddd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
