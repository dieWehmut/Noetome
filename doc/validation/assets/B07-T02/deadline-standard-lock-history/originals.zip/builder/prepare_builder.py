"""Materialize a saved standalone capture program; no product/HTTP execution."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).parent
OLD = HERE.parent / 'b07-t02-deadline-shared-header-history-20261107/build_archive.py'


def read(path):
    before = path.stat()
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_nlink)
    assert fields(before) == fields(after) and not path.is_symlink()
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino,
                 'mtime_ns': after.st_mtime_ns, 'nlink': after.st_nlink}


def main():
    old_raw, old_pin = read(OLD)
    assert old_pin['sha256'] == 'c0e550cd2f7b36b9c794ff0ca435144bdb220f1b679a3c9d78533a689c3dca93'
    text = old_raw.decode('utf-8')
    text = text.replace('shared-header', 'standard-lock')
    text = text.replace('c2f1', 'c281')
    text = text.replace('Runb393 Store2e97', 'Rune4 Storec87')
    text = text.replace('b07-t02-windows-release-pair-06-20261107', 'b07-t02-windows-release-pair-08-20261107')
    text = text.replace('c281d498cb7c9da53a768c978ba01ea2b16837855a7a2304dc9cea63513f9e00', 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12')
    text = text.replace('65888', '26232').replace('42408', '84020')
    text = text.replace('09535d63b995673af12ac2a4fd101076bce82806cb2a26e2d72e9dcad0250325', 'f6778071e8533819660e783a814b76d0d39a3b77ea254ddd0b66a65ad993adbc')
    text = text.replace('4cfaa3cde16ea473a1da8b2cd81a647dfbd0b44b2f05f003b7fc3718bec03e68', '68b890af5cfbc2d3c820365877e4c77822b687b3eeb21dec1b925c546ae86089')
    text = text.replace('4c2b2fc1230c619cd2b7d3bb2ab8609ea3fdaa3923060c434d2d37b368e693f3', 'b4f573f943927aa51ea63ae2981dfe1d0295f8841cf4d47c18809fdfd6fc6479')
    old_phase = "phase = json.loads((HOME_REPO / '.artifacts/b07-t02-native-standard-lock-phase-readonly-review-20261107/actual.json').read_bytes())\n    assert phase['selected_FP'] == FP and phase['cases'][1]['exact_settled_to_NoFit_event_gap_ns'] == 183608900"
    new_phase = "phase = json.loads((HERE / 'phase-review/actual.json').read_bytes())\n    assert phase['actual_FP'] == FP\n    assert phase['cases'][0]['exact_first_A_settled_offset_ns'] == 504508700\n    assert phase['cases'][0]['exact_A_NoFit_event_offset_ns'] == 653722600\n    assert phase['cases'][1]['exact_first_A_settled_offset_ns'] == 437914300\n    assert phase['cases'][1]['exact_A_NoFit_event_offset_ns'] == 634726100\n    assert phase['cases'][1]['exact_settled_to_NoFit_event_interval_ns'] == 196811800\n    assert all(case['A_retry_scheduled_count'] == 0 for case in phase['cases'])\n    assert pin(HERE / 'phase-review/request_run.rs')['sha256'] == 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'\n    assert pin(HERE / 'phase-review/request_budget_store.rs')['sha256'] == 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'"
    assert old_phase in text
    text = text.replace(old_phase, new_phase)
    text = text.replace("HOME_REPO / '.artifacts/b07-t02-native-standard-lock-phase-readonly-review-20261107',", "HERE / 'phase-review',")
    text = text.replace("HERE / 'code-review',", "HOME_REPO / '.artifacts/b07-t02-native-standard-lock-execution-launch-01-20261107',")
    text = text.replace("('build_archive.py', 'README.md', 'prepare_builder.py', 'builder-generation-failure-01.json')", "('build_archive.py', 'README.md', 'prepare_builder.py', 'builder-preparation.json')")
    text = text.replace("    before = [{'member': name, 'original': str(path), 'pin': pin(path)} for name, path in pairs]", "    directories = [(str(path), path.stat()) for root in roots for path in [root, *sorted(p for p in root.rglob('*') if p.is_dir())]]\n    directory_fields = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_nlink)\n    before = [{'member': name, 'original': str(path), 'pin': pin(path)} for name, path in pairs]")
    text = text.replace("    assert references == {name: pin(Path(name)) for name in references}", "    assert references == {name: pin(Path(name)) for name in references}\n    assert all(directory_fields(Path(name).stat()) == directory_fields(stat) for name, stat in directories)")
    text = text.replace("'members': before,", "'members': before,\n                                   'captured_WSL_directories': [{'path': name, 'WSL_device': stat.st_dev, 'WSL_inode': stat.st_ino, 'mtime_ns': stat.st_mtime_ns, 'nlink': stat.st_nlink, 'byte_length': stat.st_size} for name, stat in directories],")
    text = text.replace("'ordinary_original_identity_mtime_bytes_before_after_equal': True,", "'ordinary_original_identity_mtime_bytes_before_after_equal': True,\n                                 'captured_WSL_directory_identity_mtime_inventory_before_after_equal': True,")
    assert 'c2f1d498' not in text and 'b393 Store' not in text
    destination = HERE / 'build_archive.py'
    with destination.open('xb') as stream:
        stream.write(text.encode('utf-8'))
    raw, generated = read(destination)
    assert raw == text.encode('utf-8')
    assert read(OLD)[1] == old_pin
    receipt = {'status': 'standalone_builder_saved_before_any_archive_generation_no_product',
               'original_builder': {'path': str(OLD), 'pin_before_after': old_pin},
               'new_builder': {'path': str(destination), 'pin': generated},
               'selected_FP': 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12',
               'scope': 'Only closed evidence source labels, actual counts/PIDs, fixed e4/c87 phase anchors and captured directory metadata adapt the prior saved standalone capture program. Original author/product/checker/limits unchanged; no CLI/HTTP/testdriver/Native is executed.'}
    with (HERE / 'builder-preparation.json').open('xb') as stream:
        stream.write((json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
