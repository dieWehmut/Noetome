# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c2d701464ce26b4a7b61d8688f165e427f7cad0bc7d0de8f3a4977d50b9bae4d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "90e8efde14926f0043025cd02290bffd552a023aedff7f9b347002276afcd307"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cb72f45d7ccd6c96854661ae382039d8a29e5dc2753d834460cfd1f21dacfa61"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "f6ee3c0bff3b2990bdb8ded89fad821a73616244428b2c004730018cb3f3b896"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4c15a60a6afbca50174a50d713b6491834e9295891d7650ef45f492660b7fb4a"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "7c5fe4c15e39b0ec3e04ee391fc75b481ef9e83d7b1888a3481e874dacf071d3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7e1f8ad3-98cd-41f0-ab3e-b37c1797f5bc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "89bef5c5-a4b7-4c4d-bf43-fbbd4605a254",
    "source_id": "794dc09b-8cde-4c14-b0f2-47ae0ad6d410",
    "version_id": "0b9f1aff-10bc-4875-b335-5514297e02c1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63562/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c40f7fd3-0f1c-4d01-ad2f-ffec9f150fb7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4c15a60a6afbca50174a50d713b6491834e9295891d7650ef45f492660b7fb4a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
