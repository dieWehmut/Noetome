# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "346ffd87892c9d962530f7f71eecaa1e9aa1d98c6491b30474d9078cc375f78a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "bed217738b743875bea48ecf7e3e9aed737b59b57272fe676e764b3ecbd78160"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a1125266c5abd3db9b8313e00a58dd97f808775f9d58b9d8426fca9d61ea0980"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "9a5e1074fbfef57ea0287cbdf6b4f236b2e82b8763fabb9ffb0039d6e5e261ed"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b88e0bfcdc14c2296435f83018f7442cbfccfd37ce6e4151ac983387f506d01a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0a94f95837013cdae72f259fd3f6eb9e7312adeee9b353cf08b58a0058d3d049"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "68781b5b-6049-461e-94e1-28acb7ee0e95",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "598df644-d857-4f49-aeb4-c48f2f1b1bd4",
    "source_id": "531ebfe1-36ff-4901-97e0-6fc838e0955d",
    "version_id": "532dc131-87cf-41df-a30b-4c18733dc816"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63562/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "633aea08-d25c-43c2-b111-222e400ba01b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b88e0bfcdc14c2296435f83018f7442cbfccfd37ce6e4151ac983387f506d01a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
