# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "46da72c363affd2b58c3086baccb2bceb83f0576a92aa16e59f29cfd34c5a163"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8fe4a9d3f96b9ec3f826b4f2bdc095542d1eb1f83e5120484fb8802ff5a3a57a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8ca263105118f7dd0e6ddd5af5b38d4bd87fb5ca40fcf15a022bad64488c6023"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "6943637452d7f3fff1d6c46beb97d840ea08ef23efb207032248b94b8a55e944"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3769ee4e3a15b092eb7d3aa06d91edbaeb2e731c38fe9a034e0b1c13ab06f1f5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a10799149c33ee682a7254a0398774f7bad1b47ce178f921fbdf0c146511e0da"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "152770dd-3ec8-4433-a6b6-3340b7faf87e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "636e9a87-2a25-4cc4-91fb-31e4ce977975",
    "source_id": "1e8742e9-da1c-4493-b66d-c540393aa5a9",
    "version_id": "97975343-25a4-4a2b-b57a-c1ad805b43b5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62235/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "659d1b38-d0b7-46b9-87d8-1ea4a34090ad",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3769ee4e3a15b092eb7d3aa06d91edbaeb2e731c38fe9a034e0b1c13ab06f1f5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
