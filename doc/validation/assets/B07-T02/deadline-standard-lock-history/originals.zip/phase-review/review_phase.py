"""Review closed Native08 raw SQL with integer100ns UTC; no product run."""
from pathlib import Path
import calendar
import contextlib
import datetime
import hashlib
import json
import sqlite3

HERE = Path(__file__).parent
NATIVE = Path('/mnt/d/Noetome/.artifacts')
BUILD = NATIVE / 'b07-t02-windows-release-pair-08-20261107'
FP = 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12'


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino, 'mtime_ns': after.st_mtime_ns,
                 'nlink': after.st_nlink, 'metadata_captured_before_first_read': True}


def ns(value):
    assert value.endswith('Z')
    base, _, fraction = value[:-1].partition('.')
    assert len(fraction) <= 9
    return calendar.timegm(datetime.datetime.strptime(base, '%Y-%m-%dT%H:%M:%S').timetuple()) * 10**9 + int(fraction.ljust(9, '0') or '0')


def save(name, value):
    with (HERE / name).open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def main():
    cases = []
    for label, root_name, cli, driver, http, kills in [
        ('ordinary', 'b07-t02-request-native-standard-lock-ordinary-elapsed-01-20261107', 6, 0, 2, 0),
        ('formal-three', 'b07-t02-request-native-standard-lock-three-target-01-20261107', 11, 2, 5, 1),
    ]:
        root = NATIVE / root_name
        actual_raw, actual_pin = capture(root / 'actual.json')
        actual = json.loads(actual_raw)
        assert actual['status'] == 'failed' and actual['ordinary_CLI_count'] == cli and actual['driver_count'] == driver
        assert all(actual['guards'].values())
        assert len({command['PID'] for command in actual['commands']}) == cli + driver
        assert all('exit_code' in command and 'wait_action' in command for command in actual['commands'])
        killed = [command for command in actual['commands'] if command['wait_action'] == 'actual_OS_force_kill_and_wait']
        assert len(killed) == kills and all(command['exit_code'] != 0 for command in killed)
        if kills:
            assert killed[0]['PID'] == 26232 and killed[0]['exit_code'] == 1
            natural = next(command for command in actual['commands'] if command['PID'] == 84020)
            assert natural['exit_code'] == 0 and natural['wait_action'] == 'ordinary_exit'
        servers = [json.loads(capture(path)[0]) for path in root.rglob('server-receipts.json')]
        assert sum(len(server['receipts']) for server in servers) == http
        assert all(not server['errors'] for server in servers)
        database = root / 'elapsed-limit-persists-through-kill/budget/control/budget.sqlite'
        original, before = capture(database)
        with contextlib.closing(sqlite3.connect(database.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)) as connection:
            sql = list(connection.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM events ORDER BY sequence'))
        previous = '0' * 64
        rows = []
        for sequence, parent, payload, digest in sql:
            assert sequence == len(rows) + 1 and parent == previous
            assert hashlib.sha256(payload.encode('utf-8')).hexdigest() == digest
            row = json.loads(payload)
            assert row['sequence'] == sequence and row['previous_sha256'] == parent
            rows.append(row)
            previous = digest
        spec = rows[0]['event']['spec']
        deadline = next(unit['deadline_utc'] for unit in spec['units'] if unit['unit_id'] == 'unit-a')
        start = ns(deadline) - 1500000000
        summary = []
        for row in rows:
            event = row['event']
            key = event.get('key', event.get('plan', {}).get('key', {}))
            summary.append({'sequence': row['sequence'], 'at_utc_original': row['at_utc'],
                            'kind': event['kind'], 'unit_id': event.get('unit_id', key.get('unit_id')),
                            'outcome': event.get('outcome'), 'diagnostic': event.get('diagnostic'),
                            'exact_offset_from_original_A_clock_ns': ns(row['at_utc']) - start})
        first = next(row for row in summary if row['kind'] == 'receipt_settled' and row['unit_id'] == 'unit-a')
        failed = next(row for row in summary if row['kind'] == 'unit_finished' and row['unit_id'] == 'unit-a')
        assert failed['outcome'] == 'failed' and failed['diagnostic'] == 'No retry fits the original absolute deadline'
        assert not any(row['kind'] == 'retry_scheduled' for row in summary)
        b_receipt = next(row for row in rows if row['event']['kind'] == 'receipt_settled' and row['event']['key']['unit_id'] == 'unit-b')
        usage = b_receipt['event']['receipt']['usage']
        assert usage['total_tokens'] == 700
        after_raw, after = capture(database)
        assert after == before and after_raw == original
        case = {'label': label, 'execution_original': str(root / 'actual.json'), 'execution_pin': actual_pin,
                'actual_CLI': cli, 'actual_driver': driver, 'actual_HTTP': http, 'actual_OS_kill_wait': kills,
                'all_owned_PID_exit_wait_recorded': True, 'guards': actual['guards'], 'failure': actual['failure'],
                'database_original': str(database), 'database_ID_mtime_bytes_before_after_equal': before,
                'raw_SQL_UTF8_chain_verified': True, 'original_A_deadline_utc': deadline,
                'original_A_clock_epoch_ns': start, 'original_latest_1000ms_retry_decision_epoch_ns': ns(deadline) - 1000000000,
                'exact_first_A_settled_offset_ns': first['exact_offset_from_original_A_clock_ns'],
                'exact_A_NoFit_event_offset_ns': failed['exact_offset_from_original_A_clock_ns'],
                'exact_settled_to_NoFit_event_interval_ns': failed['exact_offset_from_original_A_clock_ns'] - first['exact_offset_from_original_A_clock_ns'],
                'B_actual_Known700_receipt_at_utc': b_receipt['at_utc'], 'A_retry_scheduled_count': 0,
                'event_summary': summary, 'accepted_not_run': label == 'formal-three', 'main62_not_run': True}
        if label == 'ordinary':
            assert case['exact_first_A_settled_offset_ns'] == 504508700 and case['exact_A_NoFit_event_offset_ns'] == 653722600
        cases.append(case)
    compiled = {}
    for name, expected in [('request_run.rs', 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'),
                           ('request_budget_store.rs', 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a')]:
        path = BUILD / 'repo/crates/noetome-cli/src' / name
        raw, pin = capture(path)
        assert pin['sha256'] == expected
        with (HERE / name).open('xb') as stream:
            stream.write(raw)
        compiled[name] = {'compiled_original': str(path), 'pin': pin}
    report = {'status': 'closed_Native08_standard_lock_exact_integer_phase_review_completed', 'actual_FP': FP,
              'cases': cases, 'compiled_originals': compiled,
              'precision': 'Integer epoch seconds plus RFC3339 fractional digits padded to9. Original100ns UTC strings unchanged; no float conversion.',
              'scope': 'Closed failure history. A HTTP429 settlement is Unknown/R held, distinct from B Known700. No RetryScheduled event exists in either elapsed chain. Original event.at occurs before COMMIT completion and is not callback/function duration. No per-function timing or IO cost attribution. Root original1500/1000/200/1700/R8310 untouched. No repeat/new product/HTTP/driver/Native call.',
              'generation_program': {'path': str(Path(__file__).absolute()), 'pin': capture(Path(__file__).absolute())[1]}}
    save('actual.json', report)
    print(json.dumps({'status': report['status'], 'actual_pin': capture(HERE / 'actual.json')[1],
                      'phases': [{'label': case['label'], 'first_ns': case['exact_first_A_settled_offset_ns'],
                                  'NoFit_ns': case['exact_A_NoFit_event_offset_ns'], 'gap_ns': case['exact_settled_to_NoFit_event_interval_ns']} for case in cases]}))


if __name__ == '__main__':
    main()
