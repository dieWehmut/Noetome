"""Bind fixed compiled e4/c87 path excerpts to closed integer event records."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).parent


def capture(path):
    before = path.stat()
    assert path.is_file() and not path.is_symlink() and before.st_nlink == 1
    raw = path.read_bytes()
    after = path.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after)
    return raw, {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                 'WSL_device': after.st_dev, 'WSL_inode': after.st_ino, 'mtime_ns': after.st_mtime_ns, 'nlink': after.st_nlink}


def main():
    originals = {}
    for name, digest in [('request_run.rs', 'e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e'),
                         ('request_budget_store.rs', 'c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a'),
                         ('actual.json', '80ef3d2b24227fdba42ae116ed2d5770cefefca93c6664798d445507974e4c14')]:
        raw, pin = capture(HERE / name)
        assert pin['sha256'] == digest
        originals[name] = {'path': str(HERE / name), 'pin': pin, 'raw': raw}
    phase = json.loads(originals['actual.json']['raw'])
    formal = next(case for case in phase['cases'] if case['label'] == 'formal-three')
    assert formal['exact_first_A_settled_offset_ns'] == 437914300
    assert formal['exact_A_NoFit_event_offset_ns'] == 634726100
    assert formal['exact_settled_to_NoFit_event_interval_ns'] == 196811800
    assert formal['A_retry_scheduled_count'] == 0
    selections = [
        ('request_run.rs', 1708, 1714, 'Settlement callback follows store.settle; its recorded event.at is sampled inside the update before COMMIT.', ['self.store.settle(&key, &r)?;', 'self.event("attempt_settled_commit")']),
        ('request_run.rs', 1460, 1464, 'API return queues authoritative receipt checking in the next loop.', ['expect_receipt =']),
        ('request_run.rs', 1144, 1158, 'Original owner/input checks then fresh full budget view and inventory precede retry decisions.', ['g.verify()?;', 'g.inputs()?;', 'let view = store.view()?;', 'g.inventory(&view)?;']),
        ('request_run.rs', 1308, 1330, 'Actual NoFit branch returns through finish_unit before schedule_retry_after; no RetryScheduled call executed.', ['No retry fits the original absolute deadline', 'store.schedule_retry_after(&a.plan.key, code)?;']),
        ('request_run.rs', 1114, 1133, 'Failed finish first checks whether any unsent promise can be released, then commits the unit terminal state.', ['release_unsent(store, g, index, reason)?;', 'store.finish_unit']),
        ('request_run.rs', 915, 940, 'Even a settled attempt goes through another full view; only unreceipted Prepared/Reserved may release.', ['let view = store.view()?;', 'g.trusted_owner(&view)?;', 'a.receipt.is_none() && matches!(a.state, AttemptState::Prepared | AttemptState::Reserved)']),
        ('request_budget_store.rs', 793, 800, 'Every fresh view holds the authority lock, checks layout/schema, fully reloads the chain and rechecks witnesses.', ['let _guard = lock(&self.root)?;', 'load(&self.connection', 'witnesses(&view)?;']),
        ('request_budget_store.rs', 807, 864, 'Every update again checks layout/schema, begins Immediate SQL, reloads/witnesses/guard, then takes event time and commits.', ['TransactionBehavior::Immediate', 'let mut view = load(&tx', 'witnesses(&view)?;', 'let at = now()?;', 'tx.commit().map_err(database)?;']),
        ('request_budget_store.rs', 1246, 1268, 'UnitFinished is appended through this separate fresh update.', ['self.update(|v, _| {', 'BudgetEvent::UnitFinished']),
        ('request_budget_store.rs', 2080, 2145, 'Full witnesses check all registered roots, sealed file bytes/stamps, request, transport and final receipt originals.', ['for run in &v.runs', 'verify_request(&root, &a.plan)?;', 'receipt_files(&root, &a.plan, receipt)?;']),
    ]
    excerpts = []
    for name, first, last, purpose, literals in selections:
        raw = originals[name]['raw']
        text = ''.join(raw.decode('utf-8').splitlines(keepends=True)[first - 1:last])
        for literal in literals:
            assert literal in text, (name, first, literal)
        excerpts.append({'file': name, 'first_line': first, 'last_line': last, 'purpose': purpose, 'compiled_source_excerpt': text})
    report = {
        'status': 'compiled_e4_c87_source_paths_bound_to_closed_NoFit_raw_no_function_profile',
        'actual_FP': phase['actual_FP'],
        'originals': {name: {key: value for key, value in record.items() if key != 'raw'} for name, record in originals.items()},
        'exact_formal_A_settled_ns': 437914300, 'exact_formal_A_NoFit_event_ns': 634726100,
        'exact_event_interval_ns': 196811800, 'retry_scheduled_events': 0,
        'actual_path': ['A settle event timestamp before remaining commit/layout/callback/API return guards',
                        'next loop Run verify/inputs + fresh authority view/full witnesses/inventory',
                        'original now+1000ms vs1500ms unit deadline NoFit decision, before any RetryScheduled invocation',
                        'finish_unit -> release_unsent fresh view/trustedOwner/verify/inventory; settled A is not refundable',
                        'Store.finish_unit -> fresh Immediate update/load/full witnesses before UnitFinished event timestamp'],
        'B_events_between_A_events': [row for row in formal['event_summary'] if row['unit_id'] == 'unit-b' and 437914300 < row['exact_offset_from_original_A_clock_ns'] < 634726100],
        'excerpts': excerpts,
        'scope': 'Only fixed compiled e4/c87 originals and stable SQL were read. The interval includes post-settle SQL/callback/API work, fresh source/receipt guards, authority serialization/concurrent B and terminal cleanup. event.at is not COMMIT completion, and the NoFit comparison time itself has no recorded timestamp. No per-function/syscall profiling, no assignment of all196.8118ms to one function or IO, no source/cap/gate/phase/cache suggestion claimed as verified. No product/HTTP/driver/Native call; old compile bytes remain bound even if Root edits current worktree.',
        'generation_program': {'path': str(Path(__file__).absolute()), 'pin': capture(Path(__file__).absolute())[1]},
    }
    assert all(capture(Path(record['path']))[1] == record['pin'] for record in report['originals'].values())
    with (HERE / 'code-path-review.json').open('xb') as stream:
        stream.write((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'status': report['status'], 'actual_pin': capture(HERE / 'code-path-review.json')[1]}))


if __name__ == '__main__':
    main()
