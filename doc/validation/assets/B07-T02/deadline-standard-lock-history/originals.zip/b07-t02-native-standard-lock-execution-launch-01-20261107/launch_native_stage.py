"""Execute one explicitly selected frozen PS stage and retain outer wait/raws.

Root separately grants normalize and ordinary only in this first window.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

HERE = Path(__file__).parent
PS = Path('/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')
WRAPPER = r'D:\Noetome\.artifacts\b07-t02-native-standard-lock-wrapper-01-20261107'
BUILD = r'D:\Noetome\.artifacts\b07-t02-windows-release-pair-08-20261107'
FP = 'c2814aa5992af96421fc19ef1fecd773964718808235627376b00677a7658c12'
CLI = 'f6778071e8533819660e783a814b76d0d39a3b77ea254ddd0b66a65ad993adbc'
DRIVER = '68b890af5cfbc2d3c820365877e4c77822b687b3eeb21dec1b925c546ae86089'


def save(path, value):
    with path.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', required=True, choices=['normalize', 'ordinary'])
    args = parser.parse_args()
    name = args.stage
    stage = HERE / name
    assert not stage.exists(), 'run selected stage once only'
    stage.mkdir()
    script = Path('/mnt/d/Noetome/.artifacts/b07-t02-native-standard-lock-wrapper-01-20261107') / (name + '.ps1')
    expected = {'normalize': '1d7d20d8d12bc30e9de8c52e91876819bb05191948f9793477f5928089f20147',
                'ordinary': '23a1a4f774ea7a4ad05b59b25081597f1feefc668744374074846b73112d1b0c'}[name]
    before = script.stat()
    raw = script.read_bytes()
    after = script.stat()
    fields = lambda stat: (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_nlink)
    assert fields(before) == fields(after) and before.st_nlink == 1 and not script.is_symlink()
    assert hashlib.sha256(raw).hexdigest() == expected
    argv = [str(PS), '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File',
            WRAPPER + '\\' + name + '.ps1', '-NativeBuildRoot', BUILD]
    if name == 'normalize':
        argv += ['-Fingerprint', FP, '-CliSha', CLI, '-DriverSha', DRIVER]
    start = time.time_ns()
    with (stage / 'stdout.bin').open('xb') as stdout, (stage / 'stderr.bin').open('xb') as stderr:
        child = subprocess.Popen(argv, stdout=stdout, stderr=stderr)
        save(stage / 'launch.json', {'outer_WSL_PID': os.getpid(), 'interop_PID': child.pid,
                                     'argv': argv, 'start_utc_ns': start, 'stage': name})
        try:
            code = child.wait(timeout=300)
            action = 'ordinary_wait'
        except subprocess.TimeoutExpired:
            child.kill()
            code = child.wait()
            action = 'outer_own_timeout_kill_wait_not_Native_child_confirmation'
    assert fields(script.stat()) == fields(after) and script.read_bytes() == raw
    result = {'stage': name, 'outer_WSL_PID': os.getpid(), 'interop_PID': child.pid,
              'exit_code': code, 'wait_action': action, 'start_utc_ns': start, 'end_utc_ns': time.time_ns(),
              'frozen_script_SHA': expected, 'frozen_script_ID_mtime_bytes_before_after_equal': True,
              'actual_FP_parameter': FP, 'NativeBuildRoot': BUILD,
              'scope': 'Outer stage execution only. Actual native PS/Python and product PID/raw/guards remain in inner frozen stage receipts. Root authorized only normalize+ordinary; three/full not executed by this launcher.'}
    save(stage / 'actual.json', result)
    print(json.dumps(result))
    raise SystemExit(code if action == 'ordinary_wait' else 1)


if __name__ == '__main__':
    main()
