from pathlib import Path
import difflib
import hashlib
import json
import stat
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/lyinn/project/Noetome')
OUT = Path(__file__).parent
observed = []


def read(path):
    a = path.lstat()
    assert stat.S_ISREG(a.st_mode) and a.st_nlink == 1, str(path)
    raw = path.read_bytes()
    b = path.lstat()
    assert (a.st_dev, a.st_ino, a.st_size, a.st_mtime_ns) == (b.st_dev, b.st_ino, b.st_size, b.st_mtime_ns)
    assert raw == path.read_bytes(), str(path)
    observed.append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw),
                     'observer_identity': {'platform': 'linux', 'device': a.st_dev, 'inode': a.st_ino},
                     'observer_mtime_ns': a.st_mtime_ns})
    return raw


before_path = ROOT / '.artifacts/b07-t02-helper-selected-only-20261107/request_run.before.rs'
after_path = ROOT / '.artifacts/b07-t02-helper-selected-only-20261107/request_run.after.rs'
before = read(before_path)
after = read(after_path)
current = read(ROOT / 'crates/noetome-cli/src/request_run.rs')
assert hashlib.sha256(before).hexdigest() == '4235b2cfcd2344e7cfc57b7432a2182997532c19f7f9e32f98936931b1354469'
assert hashlib.sha256(after).hexdigest() == '2e7357871bc000afc308abc4de4db0d131bfe86cadb93471e5fe0063beb33b06'
assert after == current
added = b'        if !matched && selected != "observe" {\n            return Ok(());\n        }\n'
assert after.count(added) == 1 and after.replace(added, b'', 1) == before
assert before[:68173] == after[:68173]
assert hashlib.sha256(after[:68173]).hexdigest() == 'd69b6b76c30aebe3d5f5dffd0ad2edf8ca9153eb9babe97ad5f51ebdf1950b2a'
body = after[after.index(b'    pub(super) fn boundary('):after.index(b'    #[test]\n    fn checkpoint_driver()')]
assert body.index(added) < body.index(b'let _held = HANDSHAKE') < body.index(b'BudgetStore::open_readonly')
assert body.index(b'out.flush()') < body.index(b'drop(_held)') < body.index(b'if matched {') < body.index(b'io::stdin()')
for name, raw in [('request_run.before.rs', before), ('request_run.after.rs', after)]:
    (OUT / name).write_bytes(raw)
(OUT / 'test-only.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                                            fromfile='before.rs', tofile='after.rs')), encoding='utf-8')
store = read(ROOT / 'crates/noetome-cli/src/request_budget_store.rs').decode()
api = read(ROOT / 'crates/noetome-cli/src/extraction_api.rs').decode()
assert 'tx.commit().map_err(database)?;' in store
assert 'self.event("dispatch_intent_commit")' in after.decode()
result = {
    'status': 'passed_static_readback_only',
    'scope': 'Current B07-T02 cfg(test) boundary three-line early-return; no Cargo, CLI, HTTP, Windows calls, or source edits performed by this reviewer.',
    'production_prefix': {'byte_length': 68173, 'sha256': hashlib.sha256(after[:68173]).hexdigest(), 'exact_equal': True},
    'difference': {'added_bytes': len(after) - len(before), 'added_lines': 3, 'removed_lines': 0,
                   'exact_remove_added_lines_restores_whole_before': True},
    'protocol': {
        'trace': 'matched=true for every event; full BudgetStore observation and serial flush/stdin handshake retained',
        'observe': 'every event observed; unmatched will_wait=false; mutex dropped after JSON flush; no stdin wait',
        'selected_event': 'only exact event/unit/attempt matches reach BudgetStore observation and handshake; unmatched callbacks now return before lock/DB IO',
        'no_test_mode': 'returns before selector/lock/DB IO',
        'transaction_boundary': 'Production mark_may_send returns after BudgetStore.update COMMIT/post-layout; hook then calls event. Boundary holds no production SQLite transaction across stdin.',
        'deadline': 'Waiting at dispatch is included in the original absolute Unit/Run deadline. API HTTP timer is started after before_send returns and bounded by remaining original time.'
    },
    'reuse_executor': 'The old Native06 Python-only reuse executor must reject this Rust table delta; new helper requires a new compiled pair and actual source-bound validation.',
    'not_run': ['Cargo', 'ordinary CLI', 'driver', 'HTTP', 'Windows metadata calls', 'new Native06 preparation'],
    'observed_originals': observed,
}
(OUT / 'actual.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'actual': str(OUT / 'actual.json'),
                  'sha256': hashlib.sha256((OUT / 'actual.json').read_bytes()).hexdigest(),
                  'byte_length': (OUT / 'actual.json').stat().st_size}, ensure_ascii=False))
