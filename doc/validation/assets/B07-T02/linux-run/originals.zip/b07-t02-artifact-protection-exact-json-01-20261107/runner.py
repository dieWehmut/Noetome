from pathlib import Path
import sys, json
sys.path.insert(0, str(Path.cwd()/"scripts"))
import verify_request_budget as audit
recorder = audit.Recorder(Path(".artifacts/b07-t02-artifact-protection-exact-json-matrix-01-20261107"), Path(".artifacts/b07-t02-linux-pair-04-20261107/noetome"))
driver=Path(".artifacts/b07-t02-linux-pair-04-20261107/request-test-driver")
try:
 recorder.bind_build_receipt(Path(".artifacts/b07-t02-linux-pair-04-20261107/actual.json"),driver)
 audit.artifact_protection_matrix(recorder,driver,audit.author_check(audit.FIXTURE)["cases"])
 result=recorder.finish("passed")
 print(json.dumps({"status":result["status"],"CLI_count":result["ordinary_CLI_count"],"driver_count":result["driver_count"],"cases":result["cases"]}))
except BaseException as error:
 recorder.finish("failed",{"type":type(error).__name__,"text":str(error)})
 raise
