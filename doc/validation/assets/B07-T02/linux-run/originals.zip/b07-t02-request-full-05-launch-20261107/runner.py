from pathlib import Path
import hashlib,json,os,subprocess,time,sys
root=Path(__file__).resolve().parent
project=Path.cwd()
argv=["/tmp/noetome-b05-t03-python/bin/python",str(project/"scripts/verify_request_budget.py"),"--cli",str(project/".artifacts/b07-t02-linux-pair-04-20261107/noetome"),"--test-driver",str(project/".artifacts/b07-t02-linux-pair-04-20261107/request-test-driver"),"--build-receipt",str(project/".artifacts/b07-t02-linux-pair-04-20261107/actual.json"),"--fixture",str(project/"fixtures/run-api-budget-v1"),"--new-root",str(project/".artifacts/b07-t02-request-full-05-20261107"),"--full"]
files=[project/"scripts/verify_request_budget.py",project/"tests/test_verify_request_budget.py",project/"scripts/verify_run_checkpoint.py",project/"scripts/verify_fixture_compile.py"]
def pin(p):
 s=p.stat();return {"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"byte_length":s.st_size,"inode":s.st_ino,"mtime_ns":s.st_mtime_ns}
before={str(p):pin(p) for p in files}
for p in files:(root/p.name).write_bytes(p.read_bytes())
env={k:os.environ[k] for k in ("PATH","LANG","TEMP","TMP") if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUTF8="1",PYTHONIOENCODING="utf-8",NO_PROXY="127.0.0.1,::1",no_proxy="127.0.0.1,::1")
with (root/"stdout.bin").open("wb") as out,(root/"stderr.bin").open("wb") as err:
 child=subprocess.Popen(argv,env=env,stdout=out,stderr=err)
 (root/"launch.json").write_bytes((json.dumps({"outer_PID":os.getpid(),"actual_matrix_PID":child.pid,"argv":argv,"started_utc_ns":time.time_ns(),"env_keys":sorted(env),"source_before":before},indent=2)+"\n").encode())
 try:code=child.wait(timeout=600);action="ordinary_exit"
 except subprocess.TimeoutExpired:child.kill();code=child.wait(timeout=30);action="own_process_timeout_kill_wait"
after={str(p):pin(p) for p in files}
result={"status":"passed" if code==0 and before==after and action=="ordinary_exit" else "failed","outer_PID":os.getpid(),"actual_matrix_PID":child.pid,"exit_code":code,"wait_action":action,"source_before":before,"source_after":after,"source_before_after_equal":before==after,"stdout":pin(root/"stdout.bin"),"stderr":pin(root/"stderr.bin"),"scope":"actual Linux full62 ordinary CLI/driver/artificial numeric loopback; real model and paid calls0"}
(root/"actual.json").write_bytes((json.dumps(result,indent=2)+"\n").encode());print(json.dumps(result));sys.exit(code if before==after else 1)
