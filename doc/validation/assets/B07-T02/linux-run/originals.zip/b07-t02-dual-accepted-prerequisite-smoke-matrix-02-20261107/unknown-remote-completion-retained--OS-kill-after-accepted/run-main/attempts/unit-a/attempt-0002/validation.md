# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "83f15c183ae0e1ec285723a881bb8ab6aec29f62bf011fa0e84eba67e8482ffe"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "adbbb63fb8e6087c6e44b86a0d3cb526ae47720e2196581b8b10f02da9a55ab0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "be68d9bada6b061f70f8440f4e070f92c0469172acd05f9dc52271d836e9981e"
    },
    "request.json": {
      "byte_length": 2262,
      "sha256": "7a45a5e66e29d0c532c3989b5ec8031d49a8391bbf79f57bb2435343a85a3a02"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f71a2e0038f487eca315fd723695d90d9d66fa5971905dc2b5ab865a06e763fb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "958327e8f310bccf04e6f451a0264cc93b10ae1ad95d2ce769ac9a8abc8d089a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9e38d629-f3d1-47ca-a4db-fb331725cac2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9855fdda-3681-4bbc-886c-5b7ca2dd123b",
    "source_id": "456f1b0f-9a84-4787-b2fa-a10b3cb074e6",
    "version_id": "c6ee5eda-925d-4d49-aff6-b3baae9adcbb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37245/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9e37ff51-b211-45b3-8389-f5150acc4730",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f71a2e0038f487eca315fd723695d90d9d66fa5971905dc2b5ab865a06e763fb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
