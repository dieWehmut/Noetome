from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()/"scripts"))
import verify_request_budget as a
r=a.Recorder(Path(".artifacts/b07-t02-dual-accepted-prerequisite-smoke-matrix-02-20261107"),Path(".artifacts/b07-t02-linux-pair-04-20261107/noetome"))
d=Path(".artifacts/b07-t02-linux-pair-04-20261107/request-test-driver")
try:
 r.bind_build_receipt(Path(".artifacts/b07-t02-linux-pair-04-20261107/actual.json"),d)
 c=next(x for x in a.author_check(a.FIXTURE)["cases"] if x["case_id"]=="unknown-remote-completion-retained")
 v=next(v for v in c["variants"] if v["name"]=="OS-kill-after-accepted")
 a.dual_unit_kill_case(r,a.parameter_case(c,v),d,accepted=True)
 print(json.dumps(r.finish("passed")))
except BaseException as e:
 r.finish("failed",{"type":type(e).__name__,"text":str(e)})
 raise
