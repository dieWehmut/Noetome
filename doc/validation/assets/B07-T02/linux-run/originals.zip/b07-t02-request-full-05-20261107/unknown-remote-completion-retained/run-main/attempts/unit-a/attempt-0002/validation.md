# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1fd1af88eec3dd7c6d596c20db643194ae4f3bcf62bad77c18b822ab079eadcd"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d17c5c10af585fcf3d088339edbef070c5b6e497df7dc71fc362dfd071569a77"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6d7f229cebf7d621bb4ca0a8e0fcc6001161be57e7af2d9f25ea89faeb2674b3"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "c535fb22f2f13e90c33eedc5870d32b94a57bec23a99a2367b371b53ffb600f5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a88f109a47d30b0a8fe2439d01301ff4d38528e5c08d1caafe4d407cfc6eab67"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3302acad0f731d98282957f5190afff1ef759578afa13fb44015f3f24564cd94"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f456b0a3-feed-4dbd-ada3-260db9930bb5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f815167b-defd-4f41-a755-2a8fc55ca129",
    "source_id": "1d5afc3a-3d37-4e6a-a113-6268d8dbcd17",
    "version_id": "c18edca2-0600-4b9a-a485-8c0964937427"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38021/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "89267251-90cf-4cfc-bb42-44a1ad1eece9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a88f109a47d30b0a8fe2439d01301ff4d38528e5c08d1caafe4d407cfc6eab67"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
