# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c3a8c5549e4460feecad2815eb102205679207a5494a6c8602087a24e716dc50"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "eaf2abcbc9eadfc1fa4c9565d0f330966f5b553aecb5f67858554c4e7b3ab1d7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0c9eb859c07186b063dc034341218ecfe6b4482c2fa79bf2af7687cb0f36cfb2"
    },
    "request.json": {
      "byte_length": 2211,
      "sha256": "0392d82216a775ec384e23d481ca6046a992d3f9f4501b0a897a74dbe0649bb4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4103eb3a9ba55971034c4f7ce40b3c9c34ff0a9e12c8e128805e72f5a0bdffa5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "93357e795760203864f079a33c4db808dc45c9b45d791f5a6c72cc5b1ef5a9d5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "94668eab-1d82-420a-92c0-10d98428bcf6",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ed9e7f8c-0cb2-4b1d-95f5-e24cdc7b80ee",
    "source_id": "fd900b15-bf4b-4f3c-a57d-3b70a2c427fb",
    "version_id": "0cd3026b-01ef-4c37-aa47-7738863d675d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38021/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "81dae26c-16c6-4589-bafa-fb616d53870a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4103eb3a9ba55971034c4f7ce40b3c9c34ff0a9e12c8e128805e72f5a0bdffa5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
