# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d8b3aebf1a95466a22537097b0146f0f369440730a0eb01368962a3bcbeea6d6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f65528d3c7f3160f25d1a668c80799639d111ff96fee79b57ebc08be95f02060"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "94b7a9ef0d3a4ff35dc39284cd6a74114bb030322a5f2b96000122ba217e5628"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "154e68f4fa30c0737990eb439574038ddb0d997bc6ae8a3704e29069f1e03faa"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4accafdc5378c3f0c2daa5c7c07cedb66163a04f09795afe2b3bf300ff79f9f5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "31c6fc2b590b26e3bca68749242377617b3aa48a8bf7196e1ad1747bb36c11a9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "69a9ea8a-2d8b-4475-868e-a8ba86409ebf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0bf7bf14-f3a9-4739-b916-31014bb942b0",
    "source_id": "1ab31d34-1edc-4965-926c-b8fea9858a23",
    "version_id": "53388ebb-7570-4c24-80b1-1a71919a8fd5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36743/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "edd7a87f-f5a2-411a-9572-db9dd64159f1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4accafdc5378c3f0c2daa5c7c07cedb66163a04f09795afe2b3bf300ff79f9f5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
