# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ab833277f8faa117faea6e3f71b33221d020d606d0728a90289e1c051cb8903a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a6dd119e4785256031cde6743aad51adc59e81682857beb42cc50c516c85f377"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "c29314759489ec6c3e154d28a426216558fbb10941fa013b69e26ab05f2d34f3"
    },
    "response.bin": {
      "byte_length": 513,
      "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "3a549caf02fb4a04ac71dca925eb87f0e15591211c84913870c776500003dcfc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "04523c1d-bea8-4744-acaf-2a886e7f48e9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c35062a6-fed5-46a3-b362-4534d37f3887",
    "source_id": "12f0814a-2981-4b5e-a1ed-03b40fadb926",
    "version_id": "605d8c91-71f0-4447-9323-7489b3d885b4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37263/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_CANDIDATES",
      "message": "EXTRACT_API_CANDIDATES：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fcefbcc2-1217-494d-999f-8b5f8a794ed1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 513,
    "omission_reason": null,
    "sha256": "68b708a0de39b3d9645b39bf12732d14fe6d2fa403592cf91c864034ac07c25c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
