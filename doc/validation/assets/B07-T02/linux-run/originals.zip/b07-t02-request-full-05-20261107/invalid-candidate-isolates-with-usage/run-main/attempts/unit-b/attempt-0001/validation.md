# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f24d3e3064548b5d55d18e9db10339b38b704567c3b632f066b3e38538f1dc63"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3882c26e888eb21f10a5c9485b8c6dc63cbba4917015f628f96c41703c84a397"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d7e8f5a81f838f82e995acc516f2d73a655f23ac019e49af807fa969caf8fde2"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "11bbf5c3cf297e29eb5fbb13d49bf436caae9c4b57620954b0cd418cf9041dc2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a304657e248cb492c6ceb773eeadc8209ddee8f5237c87a4e800008c7a34483e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6ae9ec79be465a4e2646f0628245bd28b21d5ed34218d62953998147fc36e419"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "62643170-debe-484a-b341-2fa5531eb815",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "892581a1-50ae-45ce-8728-769d347fa3f2",
    "source_id": "32c87bd8-72c3-4794-92a7-5bfe2e9d9907",
    "version_id": "6a75fa5a-c023-4ba1-afa9-635afb721946"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37263/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "92a0be24-94dd-42d5-a678-98162d390e29",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a304657e248cb492c6ceb773eeadc8209ddee8f5237c87a4e800008c7a34483e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
