# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "80f4ccd0cf95ab081d15bfe9b961126f095d459fc8edf6d9222631520f115404"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8d7e14bb0cc457bfa987af7b9ef45af778183099d2db105598917200da768cc0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4bee6423efdb8cec7e012f732b3228f7a6fa1db9df40ee7b2127437216f52811"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "70083686e086ab27688bf85346b50fe9608cd8a346a07febf0531bfdd75f1887"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "914c71fe23635cfbfcec91cae4b674f44b664ac666a8669f95ca1321943b9c9b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e4f6e018ae72bbc52dc267079765505d01b871c0833b6fc037439aac3343e355"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "712ebf2a-5082-4fcf-86b7-29ca28ed3d94",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d6ed9056-faf3-472e-8de7-db9d22f3bda0",
    "source_id": "ddc002dc-6490-4f39-97cb-ae400587da7e",
    "version_id": "1ae80f36-6b80-4612-8028-f22e69ea4bac"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37053/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "077744b5-1777-448a-9fac-5d5b74b352c5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "914c71fe23635cfbfcec91cae4b674f44b664ac666a8669f95ca1321943b9c9b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
