# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ed6cba69cd6104d041db29e09b4cb1549821b6159890f237cd92cd89457dd60d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "236652513895894ad2432805c7a16495248e543feb128919339de3f79e4c8dbe"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "45b0ebdf5821bf455b3f63fc97fa84bfbe1d8ff8a46fae8d78161b9738bc0a3e"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 477,
      "sha256": "1a27143599111c8ed7d3df67bbdee2ccbe012c692dfbb9e174f7e5daffdfab63"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "683d4c26-4211-413e-811c-6ee6a169d15a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6bdd35e1-3776-4305-aae0-930639c2ae13",
    "source_id": "41a89c89-5c58-492c-b03b-5120ce4b423a",
    "version_id": "28aed40d-f276-4e86-86ae-1cf7dbe8af9f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37053/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_TIMEOUT",
      "message": "EXTRACT_TIMEOUT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9ee92813-6762-4420-9d7d-7bc8f9be83ae",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
