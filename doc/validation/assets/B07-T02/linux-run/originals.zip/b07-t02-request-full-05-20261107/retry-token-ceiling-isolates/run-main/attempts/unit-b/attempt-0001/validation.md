# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c5237ef8360f60ee5031bf72d88aabbeb60e22b6c21fe5ab1918061941c9e4c7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "33794e76db5cbfb0450cc88e0973cbd8b0899c25f92604c52542123852bb568f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dd3c1a15a846d3e32c85a2f57a876db021d96d5929160599559df258e73bdc22"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "0092dd70a77b5370b605d632ee02e315699193c2a55a85043cfeec7608153740"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8842d640530e8301954467696e61b395b585f352c7b118abde92de69c31c4cc8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0902afe5c46b5091f7ecaa8e3e3106b789327688d0aee488caa5495e3032de63"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "03d2460a-fb63-429d-9f8f-880581cb5472",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9cfc5f24-6c99-4b4a-b918-4f6d080cbfa3",
    "source_id": "a50f6862-1732-453f-b655-8a77735e5e9e",
    "version_id": "980ede60-23a2-4fab-942c-e54e833b6b1d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37157/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a8340d69-4964-4598-a9a6-5d0ba0a932ce",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8842d640530e8301954467696e61b395b585f352c7b118abde92de69c31c4cc8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
