# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "890246c10d9a4239d0a6f19ca48984d0c3404e12022b14bea258e0908893062c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "adfc7251a9074025af42a043934333a8d94d5e0c43cb589efb5068e336e46246"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0bc208b84a6147ec847cabdaa1553fdb203058b6ba14242394a9b93cb771fe22"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "9b228f556d9d62e3a5ca345248d3eb1fbb3da1fbb08ceda3a7ba2552a04446e0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1885e3e0a64050597ee32428c23ec42376cd665777a451539515224308bc90af"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "390a02e2c7a48d4ca3e871d31b698936078ec8797e8afbae86cdbe230a1c9a03"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5ddfef9d-337e-4493-99de-43f341e4c2e0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cab1828c-52dc-4722-baea-3d6ba448ebb6",
    "source_id": "4e380fb0-e795-43ef-be65-dd02157cbc7a",
    "version_id": "007f1906-ce27-4f5a-b4bb-d3c9de1a8fa2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37123/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6110e5c0-3e4e-4e75-b72c-6bc498de6004",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1885e3e0a64050597ee32428c23ec42376cd665777a451539515224308bc90af"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
