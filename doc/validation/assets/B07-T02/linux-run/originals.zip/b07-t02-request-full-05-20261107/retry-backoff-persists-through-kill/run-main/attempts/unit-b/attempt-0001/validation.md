# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d70675fb40d0481d9134fc53ff0a10edf4a72b1f2ee1415b1a9f9b11abf49c05"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2ceeaa2ecd59fb3270c946c2acd85fe1f7fcb317a7275fcc24c661dd57f995d8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "89de78f0ec3f923476c3c9119da5356954036b9ae51f515a3962781cc4d4c150"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "fe46716ff4df4de994374c59186ee50c1a8496a510ce72bdcd84c4046b2c05b0"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f0c56bcc1a5c5d67fa2566a969bb8c8a77d8f01f5a147f444ee696ce1c1906de"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1b3a7c6695131674b0808f69c1a93989b636d809db0e8f69f7aab50becab6496"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5231faee-c3ea-42b3-b18a-f52b72ee47e5",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e73fc5c0-dedc-462b-989f-287ff894c806",
    "source_id": "817d8ab0-0f71-49f8-8dd5-e1fefefc825e",
    "version_id": "4f75311f-b9e5-4022-b801-276ddf90c155"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37123/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f3231ae1-43fb-40bf-942f-8785fb32a021",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f0c56bcc1a5c5d67fa2566a969bb8c8a77d8f01f5a147f444ee696ce1c1906de"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
