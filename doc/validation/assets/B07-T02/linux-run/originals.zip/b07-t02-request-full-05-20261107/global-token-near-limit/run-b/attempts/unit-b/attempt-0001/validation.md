# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7c08fc344071a8d5323c73259ed297b548d30ebf85504f0770f61123e4b586ae"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cc754b91d72d032e82dfbf24b9bd38234e6bdd13bcea134384f9dbccf4e614e2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7e02af3feef1c7fd8d4ac0ae9dc86a38dfcf0cfec29424e1ba89f49e8330579f"
    },
    "request.json": {
      "byte_length": 2200,
      "sha256": "1fed7e296d9610924ca8075d0be417d9a8ae8b8fc921f8eb367fc4338d83e318"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fb1d958241f1b85a2a90b8c0283cd3d118252ae16ef0ccbbd61461ad9dc6391e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6f199b43abe4676010c97dbb06fcc3c7ff08319898bf64d6f7dc640dd88dd555"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e86afef1-84d8-4808-8dc6-d99a77e08cf4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "115ca8c4-06e4-43d8-99ad-740f6b11916b",
    "source_id": "3c26eb79-c9c6-46cd-9067-69820e46ca7c",
    "version_id": "f11331ca-34f4-48d5-a9ca-46749653fcba"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36487/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7c750f84-e33a-4192-a85b-ee6a8a6bd136",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fb1d958241f1b85a2a90b8c0283cd3d118252ae16ef0ccbbd61461ad9dc6391e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
