# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2952bc29356a34469d0af4fde42f8be337c9a363096a61082782a5e9214f39df"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e33c3c6c5868fce5718e475d96f9866ad19fb8a2ae6c12035cdee8d836ed760e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7be2c5963a51cbf5ae3e7f12613c427f7391a0ddd42b6ddb50c763794a63c59c"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "0f69515bce40f8366e85ea70b23dc45270ed8eaf8309156a95a404c56dbca8fb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "01b57e1e68fe1b5f0f5481da2ce0d78486475389fd1c5f2cfa38787b9cedeb7d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3fe13bdfffcb2a5a026dcd07ac7ab406dae8110521cbbbb1a772dd1e4552b903"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5371ea1e-5c11-41f9-8261-86e657995592",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0b0200f8-68d0-4f34-a020-4eb9f45ecb4e",
    "source_id": "42037146-3735-4f91-8ebb-adb4674cd90f",
    "version_id": "c9b7c024-5161-4cda-a4a7-6f3c95066e0c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36795/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "469c2489-d185-40f1-8c58-fe63a3689eaa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "01b57e1e68fe1b5f0f5481da2ce0d78486475389fd1c5f2cfa38787b9cedeb7d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
