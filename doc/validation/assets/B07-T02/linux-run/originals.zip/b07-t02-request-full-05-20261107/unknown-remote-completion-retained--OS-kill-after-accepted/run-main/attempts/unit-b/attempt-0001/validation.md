# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a45d9a408def978638dc18533a62fff5562734ffdb9513b016e30f936728b14b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7ac763c31a5e255ea2e91f17b9488f649562cdcc43eb006133e7e5e4bdd5697a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ab8143fc4c346d9b2ab10501c51fbd0466da26704c90e745357f3dda3437ef9b"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "e5b3d70b920ba1d23c74594ad6ac5be27459f7cd93da0db43aa39f4833f02273"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f0afdc9aa4d9a260b08612a48d537031828b9f5a9f9ee0a11a930f6ef6755592"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "35f03ea1f90cc1da0a9e6528f490b5bfcd0909cd0118f537a0e1ba29ef6cf47c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6be39b65-c974-4d7f-89bf-f9fb1e313d07",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6cf5f0b4-b219-425c-84dc-a00c1ae32d82",
    "source_id": "c5823e4b-18e5-4c32-8da9-4946aa4b3be3",
    "version_id": "07229ffd-765e-498b-b856-1163047120f2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37037/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "38f215ef-c8a4-4913-8781-3fd517e4c7c6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f0afdc9aa4d9a260b08612a48d537031828b9f5a9f9ee0a11a930f6ef6755592"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
