# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "85b50ddface069a77c71998f361bb1966fd17ee15d6d74ac79e0e66e0578bbe8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "adef28052ebc42d854205e9fee9f2f6499d64215f1549330f60e40a8de53461a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b1cd37fffe12f6aab82374d7e1fa7a6ba6991018ac5c16007b09047b970d855c"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "c7859d5e4d80a6d71ce7d90559f22667a61b4f77a5be89bfb114b95d1525742f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c1804e06001b2deaeb3b95192b7fc9bb00c2ef85d4500372ebe511a71eb2be68"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d768952ec384d03368247b4bf6e19e913723169454ce169355644525db6bb33b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b731b7a6-3e4b-40a8-b097-232c3447a064",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ceb80a5e-7b16-438b-8f58-3b8da33b5944",
    "source_id": "38b5af26-8fe8-49cb-844c-852820259f52",
    "version_id": "2311d198-72fc-4d6a-8daf-c4420c2c2b60"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37365/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9c0759ea-b03a-4d27-9513-026b1a98a339",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c1804e06001b2deaeb3b95192b7fc9bb00c2ef85d4500372ebe511a71eb2be68"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
