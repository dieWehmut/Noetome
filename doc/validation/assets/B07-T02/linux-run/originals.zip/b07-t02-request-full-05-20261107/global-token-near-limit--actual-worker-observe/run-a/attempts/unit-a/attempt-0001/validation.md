# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "19d173fba0cf1128b9ef2cc11ccb55c871644e2048133b46e93c100acd07edb1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "652a6ae9dc385ea4afd8322a61266ad0d6f560de21a7c151f142698059a20205"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "70beec88a44449b1e6d94be5828f075a2fe6118b40b59a95dde36a43f530ac39"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "74efce0a-4445-4cc3-b3d9-2eb41bc4b32b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3fddabd4-4239-4acb-9fb1-f6bc1f26f80a",
    "source_id": "b24c8035-9883-4d87-aac2-44e2c183954f",
    "version_id": "99b56d75-3ca2-4dc6-9a04-b04b2a3d4eac"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37365/v1/responses",
  "errors": [
    {
      "code": "REQUEST_RUN_BUDGET_STOP",
      "message": "REQUEST_RUN_BUDGET_STOP：准入拒绝；未发送并保留Prepared审计。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "52d2ffce-5ed1-4343-a81e-7e252b183ff8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
