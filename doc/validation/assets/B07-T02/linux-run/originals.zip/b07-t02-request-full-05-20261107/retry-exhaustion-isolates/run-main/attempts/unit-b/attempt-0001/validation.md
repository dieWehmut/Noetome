# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2372e4310bf753e4cc293c690bd6c15c15c0ccb44d5c20b3a0cbbb10163199ef"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "09a61f0860fe5d3491d9bce9fde6c58e9217e0a8a1a8824d743207de7576c2a2"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dad9dd93ced59750e0768842e80b2448f5763db49ed26e87653321a821523f47"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "a33b72d10913d3d5bf25e17ced8e116b0c2ffc76dfb0906aa103c55dc6250997"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "393afa02cfe83e4c4958d6f5b703f32cb337fd688ca0b5fcf3b77c7eeed10811"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3b5de9185df3e18fac15287e111fbc41b1a094ee99c18e2c5478781c34fee3e8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a2e84407-966f-41bf-90fb-025f39c5bcbd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "810c665b-adee-4a38-9e3d-3426ccc21580",
    "source_id": "f42ac6dd-cb01-4282-8cee-6888c3c92d3d",
    "version_id": "12397591-8ee4-4c99-82ad-e8e54e387fee"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36445/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f1d42506-94ca-4d1d-82eb-e3691173fffa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "393afa02cfe83e4c4958d6f5b703f32cb337fd688ca0b5fcf3b77c7eeed10811"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
