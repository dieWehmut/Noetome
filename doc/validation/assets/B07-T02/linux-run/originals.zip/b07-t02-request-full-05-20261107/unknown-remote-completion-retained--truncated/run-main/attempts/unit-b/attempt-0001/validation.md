# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3c50754935ceb618a99026c8b3776ea2a60fa4682205f5320dcc16cb7fd135db"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3db05fccdb62d9dbbcf05e94d06719405e7d844408f792df8dc28dae982cdb24"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7f6198f33c21b49474c481c78f356a8df519f97c814a42663000167da4c6bd1a"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "90452c795df25eaea43c997eb4d1fca57035b3b61f7bc5ab5706093858907bb4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a8d3dda39a60e2d0faa32a3ccde09239c05cdfbcbed340756303672c6b92ef2d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "69e70da49dcc92543c8556311198b40856cdcfb22ad37a0b61544fcb3c5d5705"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3f1de109-c4c8-447a-9628-6ad83aed2a4f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "076da487-a124-442c-b641-e6ea71ff175e",
    "source_id": "9c27c563-5894-440d-8ac4-f166c66421ed",
    "version_id": "bf2c2314-4be7-42df-8b72-5ddd586fadd3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b69f0648-e79c-4a75-8015-a7e4efe7484d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a8d3dda39a60e2d0faa32a3ccde09239c05cdfbcbed340756303672c6b92ef2d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
