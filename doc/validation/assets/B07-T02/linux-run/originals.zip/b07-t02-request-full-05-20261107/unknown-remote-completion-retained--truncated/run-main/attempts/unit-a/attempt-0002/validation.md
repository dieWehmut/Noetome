# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8f74a498fd5b626467f14cf4c11b1662756378ca13869f902c4d6bddab68e164"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "145ea9e884ab9edb036ddbfef2bb027d31dd9de90d3c6ee48d658c3a2c7ab836"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c227cdac9e88a85642cc68162497e396e06fd8ab0226a658952ef97d2f9d63fb"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "6edd7df07a95e652740d202ac2190a1337bf44e13d04d127d19c8d1358dd5680"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e2aad0c8a81697e37631e17763f256fa6ac570342d8876a4d8916a9e59d2ec18"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a1a549a6a17f895339fccc6469d92d546706bfc09748750655f48c4a92b259f0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "92a4b440-8d77-4321-b323-ff1c16652589",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "de5f4fec-2734-44d7-b39d-355916e18ed2",
    "source_id": "feb0cedf-3701-4e9a-ad7a-c2fdd97e5484",
    "version_id": "461b511a-7593-43f4-98a4-24aefe2b5bec"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1ece5765-b00c-47d9-9615-58ce4b2faa7a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e2aad0c8a81697e37631e17763f256fa6ac570342d8876a4d8916a9e59d2ec18"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
