# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ef33aa9299f129bb10ef5004197c6096de8e2ae178a892e8e9eb2e3e1ccd18b0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "510944f2681734fbe742b1b4b847555e4dd905c08d8bb4b993227a56ab46af40"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "cc305ba2e023bb80b6442a371a7285ebe8a9cee16b7d00268bab951698a12fd9"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 495,
      "sha256": "51f6c6719450b2dc478d55e29db4390e7213c60ad2b863fd4d542c965ed8eb56"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "92a4b440-8d77-4321-b323-ff1c16652589",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "de5f4fec-2734-44d7-b39d-355916e18ed2",
    "source_id": "feb0cedf-3701-4e9a-ad7a-c2fdd97e5484",
    "version_id": "461b511a-7593-43f4-98a4-24aefe2b5bec"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36779/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRUNCATED",
      "message": "EXTRACT_API_TRUNCATED：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "535d03f2-eb25-4673-83b7-dec6ca964e99",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
