# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "89dbbdcaf5301e1812fee8aaa348fdd87a08dacb901ddf2e2ce3e4a95da094ab"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "34548c06f3b3549ed0d5773002982f7dfc7c83c0e1e3b3da13a44ded1ad65436"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "77c1ae6ca7b37cdca1254d7d10357ca7211516611677925cc3eeb574802b3e8e"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "aaa2633ef1e49c62bcea2c65f7b156ed656b32806116106470487ceeaaecf939"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "297b99b7f4f74c4b6afaaac714e4bfd26cdeac378a7f122dc729654704a1490f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9ac4aa2fefbf89df58e6291997132689ada24a20f0dfae188a2a75cfd324b3cc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a03a94e8-bf79-40f7-9ee3-ba9f50d6406c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e344f120-f363-4942-9765-dcf2d92efb46",
    "source_id": "161cac5e-d22f-40fd-b77a-f306f14c5503",
    "version_id": "1ac688e4-b571-475e-8ae1-a6c69d3185f1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37171/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ab932551-0332-4831-b168-6cfe54ad3436",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "297b99b7f4f74c4b6afaaac714e4bfd26cdeac378a7f122dc729654704a1490f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
