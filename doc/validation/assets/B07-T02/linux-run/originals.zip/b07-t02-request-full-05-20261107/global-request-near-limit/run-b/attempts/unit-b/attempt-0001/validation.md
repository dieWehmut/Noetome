# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b1a45fe983fa5484a4f059429ab24e801fa48728bf74037901adb7afbe0dae58"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "21737d2390caaa84b34dbe6e07fb2f17cfc7eca3f7e97badef0666819883281c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d54f28220d7bef200e922020b1efb69ca0a5faf183f3fc103d09a1b90139c1a6"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "65b2e4dac325b83d21899101cb310ca32c5f7074ce5c1401960f2ac42d9a4e4e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fc66aa6d766c67b5d454e7baf6d7dde4b15fe0821dc201cdb5f69e909d36bb22"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fc85c9e243a9d0c8ef9317a6b075299e9bd1b6e9c25c4bda1160f6ae779b5ba0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0b507685-3438-491c-83af-547d93225dd9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "88ff2268-d358-4435-b8b1-0929894d3cc6",
    "source_id": "7ba341f8-756d-43ce-a592-6e702b602fdb",
    "version_id": "090432fc-7ad1-44ab-ad4d-dc1675a37c1b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36815/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5b14537a-b994-4d23-9c29-5d5c18b51ebe",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fc66aa6d766c67b5d454e7baf6d7dde4b15fe0821dc201cdb5f69e909d36bb22"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
