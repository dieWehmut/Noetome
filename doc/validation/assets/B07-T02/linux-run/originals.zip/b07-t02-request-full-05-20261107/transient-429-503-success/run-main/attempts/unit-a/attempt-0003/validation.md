# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3f86ff35704221a8f2f93974567e438d26dc8bea8be3869d273c4c145956ea67"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0700db792884b41eb7a8cd68c6922dd219d68881976475b7ac38693a927fe3bf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "93d9836946ab51776494fda1912444ae542c8f93efbc33e05d4fec7c09c46efe"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "92f1b2f22f13f058ffbfadefa45dd7baa8ab8b465317093f1ee86983d0154a7d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9765d17443d9d38c039c6c90d8278816bf50913ad2f0552a5ee3aa87e666ab27"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "28ec99232498e2abd45a8dd013b2c89bdc0726d553c020e08574340cff6695bf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "74a495b8-ccb1-45d8-9d73-0e8c08ce234e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "16ea27f6-5e75-465c-ba39-a6631afaddab",
    "source_id": "4c1e92b0-02c7-4a1f-b03d-316107d85961",
    "version_id": "e0fe657f-df66-43f0-9cbb-e4fe0cca935b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37861/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3fe5cd13-f68a-46e0-8de7-a7dee7f1ad18",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9765d17443d9d38c039c6c90d8278816bf50913ad2f0552a5ee3aa87e666ab27"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
