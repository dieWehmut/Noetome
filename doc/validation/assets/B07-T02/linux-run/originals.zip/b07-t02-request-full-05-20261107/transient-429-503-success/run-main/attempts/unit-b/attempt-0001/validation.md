# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "94e49667fe9b6b3c5feff486ea9ab4fd3d6a21280f95f0ee1f3b38d9a3b3c6de"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "eab936f1aad75813e0e247e4e423c6cd0b3019c591c521a6604d892cd9eecd8f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "301edbdcfee4dc84c87f82fc6d922c29d31df509231533588ba36528d3d413e2"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "8801bf6d1cf7ec5491102849aa3931d5fd50262d935d731d1ac5b01a85766d7f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "da0176fd1f8de59f1edffc2334672a6fdf0573c9ac9825ed8e245a31f7ce1d29"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "57530d9324d94e1ab565d17128184730084c1d73e0f8b6db0aeb1ed0a344b67d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8367df2c-96bf-4ad8-a2f2-4cde9fd823a4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "556c22de-f93a-4678-bf62-b2f6beba3a7e",
    "source_id": "de66eadf-a033-4759-b217-b0f747ab93ac",
    "version_id": "941f2282-03c4-4184-b394-ccda791b391d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37861/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5b0c687c-04ce-4fe8-98b3-a081201caf34",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "da0176fd1f8de59f1edffc2334672a6fdf0573c9ac9825ed8e245a31f7ce1d29"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
