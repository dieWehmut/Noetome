# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c2b28322b31bc564fde44b178a8e3b5421a7b7b44b238649b1242932cd42eb94"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "166c931bada3b3bb17fc91cbb27fe46277f8d90d4074134d598937247de80e39"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b783f62f7f6c6249257df814be9aa39c916693bdfdb5e04f5ddf595a18f25e03"
    },
    "request.json": {
      "byte_length": 2196,
      "sha256": "691e2b2018cc3fdc2656f2fabd9ee88b04d9c92d6eefaa20ea316ddfd7732f1b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4baf3009bf061830af1fd0b7b9001e8ff1df2f59c84067ec8689f6ff98a2e71e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "16754d564197b19b6c142b197ffa7ccf82e0f7f4bfc329c5404d0e5a292ac16f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "baa55cdd-6e7d-48a5-841e-9861110480ae",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4ad02b8c-7e6e-4986-98b7-1fa914dba3bb",
    "source_id": "3cdb31c1-425b-47a1-9d96-17267e6a68ac",
    "version_id": "56a851c1-c3c0-41ba-a654-eeed65df25a3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36983/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "80a3ed80-5cb9-40b5-9c1f-62fc22af042e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4baf3009bf061830af1fd0b7b9001e8ff1df2f59c84067ec8689f6ff98a2e71e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
