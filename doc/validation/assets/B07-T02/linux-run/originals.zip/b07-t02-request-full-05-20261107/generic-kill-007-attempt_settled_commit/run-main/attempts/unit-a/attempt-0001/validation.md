# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "578a4b53ea126b215688c1d7849edebc299fd10025d6e74fa5735b3eb96488ca"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3c2bbaf50eb1be7586be55bc2b512e55b9e94a8fdb1095cd9a753d902388fe07"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e0b65d299bee19c4867e271f90e235af5dcae8d2921e40dce743349cbd73e8ad"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "81715ce13e043fb8448f9408c9ffefa1a3c5bf8ace264f585b12b6c13f06bbc7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d4f49ca1087ba2f1ab2b44d661c7190a0667a6ba26aaad7da0572bf516fccd61"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "49504f3ef714107c964e66bd02eca7dbe3ea7731ba4d2efb75b2ff63c24071e3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b784d1fe-b5a1-4688-b54b-c1eef5e3b31c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1e7050ef-a65d-42a9-a5dd-923c85b33eba",
    "source_id": "6ba7f8d5-0ec3-4262-8bcd-bda82113eab2",
    "version_id": "19e71dda-e6d5-46c1-8119-1636d1b28e7f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37903/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "394e14b2-e654-4f35-9a28-0753fabe70c5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d4f49ca1087ba2f1ab2b44d661c7190a0667a6ba26aaad7da0572bf516fccd61"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
