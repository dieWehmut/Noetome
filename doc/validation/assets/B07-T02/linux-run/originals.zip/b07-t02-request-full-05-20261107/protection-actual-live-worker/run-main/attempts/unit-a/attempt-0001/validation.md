# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "20eb17bc1c5f3b6693ef9e6034f0f1a3461f80b8efd1821b0ccf62e251fbe6d7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "72efb60ca46e2b163274125908762bbfa50416e73ca62cc90fa0f08117b28c8b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0c10e7169505572e8dcd6bbfb846faee0620df364722579e45f2b70c5e2d7ed5"
    },
    "request.json": {
      "byte_length": 2206,
      "sha256": "11a77ba33f0d1daba908981b9caccb6ecec7d6bbc0b728fc3bee93e8363bbf42"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ed199e4a15fe1aac18da6f8193690034447d7eb74490f89ee811220dde6ae87d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "80daf607cc322b9f8b18915570909c6cad7bec0082532464ff44e24d610d0f67"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "08a81246-1fcd-4d0b-8bee-d6a1fe511417",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3b361336-c8a1-4f04-b91f-89235bc0af57",
    "source_id": "4ea7b7f6-3a2a-47d3-a5bd-ad10847ceb3d",
    "version_id": "c91f0f8d-b901-4696-881b-0304a64e1b4c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36977/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "34475bda-c445-469b-b7be-401802e482fa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ed199e4a15fe1aac18da6f8193690034447d7eb74490f89ee811220dde6ae87d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
