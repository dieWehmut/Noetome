# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1469e76e7c8f7b97aa339f4badddb535447aaf2ea6633ee856d12c67cb7ad0e9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b8a22d4c1b0fc426dcc3bf4d3332a5f232e9feba2afe0d9e3e960bfc18f1ca44"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "74f5cb35c92fcb583f584c954f15eddd339b2fd6750687391256b8af0c7dc956"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "322ee889089403d9c1808f526db3db990519c567dfaad2a25c321ac809989827"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "31cd7bc394df0955ad4719a6bad2feab5b8265810521b5dd3e0780f7a9ea4329"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fcf51fe8d4f16432169cfda3999dc9e1f90f154cc8fd0d0f57997f4d8c5a20f3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3c11fa59-dbad-481c-aa2c-c4038913c172",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "39de0da3-2ef6-45d9-a6d5-4e700bb82488",
    "source_id": "7a1c08b1-7ab9-409d-9b11-646b6ad8dde8",
    "version_id": "236acc24-712e-4570-ba78-a7010ee25446"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37077/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a1d2ee2c-d71d-4e5b-b566-d13578609e42",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "31cd7bc394df0955ad4719a6bad2feab5b8265810521b5dd3e0780f7a9ea4329"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
