# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ac055c8cdf0f67cde290d42769b0798807ff271c96e97c7b2f1df5836e2e60af"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ff93dc8e14f50e315fb7307135cdb94b6370158165826d9cc56dbd03282bdde1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "586b0f3a703260ab94d35ee4973d4f233983990da8f7e255257af578129a7140"
    },
    "request.json": {
      "byte_length": 2212,
      "sha256": "5e037ce0579e1404aa70ba23d64ed433f366bd8eb804613edbe8b3301b085508"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3c10e762947429462ea8a76e8f3ede7010222974ed4028c709fb311f1e10f630"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "312501fa066867e0d7d8eec634c948d6feb51ce1c0dd3b0dca80b66fda118297"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c8a1d189-8c46-4dca-b4a3-5dae33f7e0b1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0f44a772-8f26-4c09-adb6-8a285e32717e",
    "source_id": "bb1630fd-5211-484e-81d3-047c1daa545b",
    "version_id": "1ec8c06c-0e44-422e-a7c2-e75128e1bd90"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37451/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "66696d09-dffd-44cb-8392-9ffb8f0c696b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3c10e762947429462ea8a76e8f3ede7010222974ed4028c709fb311f1e10f630"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
