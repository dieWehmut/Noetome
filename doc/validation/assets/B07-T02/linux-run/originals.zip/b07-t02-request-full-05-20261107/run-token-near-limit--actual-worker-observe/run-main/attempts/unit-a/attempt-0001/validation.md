# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "387b7f6794f699201475062fd2cd4ab2ea85ffbf0e0a53d171657d15a9b31f4e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6e777090adc2600a69aca56e3a4cd95746bcacaa398c447b92a13731c06babad"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "350698ea002434fa466a7c304761c95fce6ac7af30f90381d9514e815c62ad0c"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "0a058ca9ccaee80ae3eba7fc618622acf2b9bbfd3acd3c16056a8712787be928"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b27c515e53cce212125c1d3ac21017c5b295a158c4b447a8046634d6ac36e0d4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "842b6891b06bb18bfb044cd17653ae284ecbd454e25dc9f07b33c18e31a736dc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b79ad094-3b49-459f-8e0f-2b52d4ecc3c4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0b74af97-456e-48ec-a3d0-da1dcdd82f24",
    "source_id": "ffa09909-b0df-456c-91a1-0fcdc8cba699",
    "version_id": "88012069-bb82-4fe4-a6fb-32077b46a7fa"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37951/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "34f9855b-7548-4df7-b367-ce99f3baae84",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b27c515e53cce212125c1d3ac21017c5b295a158c4b447a8046634d6ac36e0d4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
