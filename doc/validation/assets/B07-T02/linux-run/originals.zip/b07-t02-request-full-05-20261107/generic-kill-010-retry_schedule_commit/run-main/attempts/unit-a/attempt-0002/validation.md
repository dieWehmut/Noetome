# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e16670860c2b5db2d166008d7bb986add7857fc66afaeb6623b85ae62a1e0591"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "11af5544fa7c93fe1fc7cc3366c0e2f11c91323a7cd20484b73866df0c1f0a1f"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ee86238af6e79ff54660aee8c081dc8b1fbcc8ddf780d388e0e25271d363c15a"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "9c906c99a4cab3d23c32c35c1f6786d0e589bbbdd9aa0e5744581cd87c01d13f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0a1969e3c8398646b33b2354901d7f3cca8ff572fa84b3061613cc38fd0afa76"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "dd766840d68e19ea58b4b831232305ea97f2e15cbc69561c8302c5d35b7647ff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9066b381-5b38-4d81-adda-196017fa5afb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8999e597-c63c-4550-8c40-a2fe1d7e3d00",
    "source_id": "71d5f53f-e27a-4a62-b6a7-5808962f96ec",
    "version_id": "a7b81abf-f8ff-4e23-a31a-372c63979085"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38059/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "11887422-765f-453c-849d-986e078ade99",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0a1969e3c8398646b33b2354901d7f3cca8ff572fa84b3061613cc38fd0afa76"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
