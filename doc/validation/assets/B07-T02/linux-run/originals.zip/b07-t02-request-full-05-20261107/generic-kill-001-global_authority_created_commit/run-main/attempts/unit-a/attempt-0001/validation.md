# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "74877269ad278625d331e5d50d1f87b274f0b5290b902668b2e7f38a025395c4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d29bd873d93f60260cd5ce228944c231d08210a6aef41a9d936378a4a7b68984"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "692346db6697b9c807ee71babdd4a0b0dd45aae90f745752aa1c4bdb6986d063"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "1760cd96d860d1b6a5c4477a8ae058801d56da0e961f9c061b08950bf0f14cea"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fa17c8d7ad1daf0e5f12b9314d93215382b606bdd87128d8e3886c9bc5730c92"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e5620cfdc1ef20256ad8e9c4ff449c82e860c7311ad6949b38dcc887ad892dc7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0d9b02bd-f90b-4796-8d53-81ebd2a6103b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3b6be103-4f02-495e-8b72-bd337e769f51",
    "source_id": "87cf86b9-f188-4ead-b50c-01810df04cbb",
    "version_id": "2d31ffe3-3766-459d-bd83-9bb32eed2773"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37579/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "44601785-3b9a-484c-b108-234050cb5da7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fa17c8d7ad1daf0e5f12b9314d93215382b606bdd87128d8e3886c9bc5730c92"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
