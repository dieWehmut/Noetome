# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f6a2a108b267c446f2291f4103ee6b7d3eaf68a65bdc960f99856fa58c9938e9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "77e13ce820ebc76913bac306aa0bd7ed74fd7cb866186e46a2c53850e24aea80"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "69fac7da935004ab2c4fc6b3634aa0737399f34205d206be85f99ebfb5776836"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "b95a72ef149fb556cc411d7cdf205a3d64682ea8fd282b19937b23bbdc2a1bf7"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "adaf14e61d533cd49119ac48ddd2a2e09ed831c87362cc24415f1f37bce4ad7e"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "68606097cd2f3d52b49760918c994c07187f78c9e4fdfbae02ef7f7fd5b0229d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "314c43bc-1d95-44b1-9411-9841dd6d82d2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "77984ef8-cfd2-42ab-b7ca-ba80be6d39fa",
    "source_id": "15510c10-7947-4cf7-9bc0-ea7d6ebcc239",
    "version_id": "44e607ba-0e8a-4525-8f0a-a6ba28a0261f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37901/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f38d8b4d-ff70-4e2f-bfd0-779993595074",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "adaf14e61d533cd49119ac48ddd2a2e09ed831c87362cc24415f1f37bce4ad7e"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
