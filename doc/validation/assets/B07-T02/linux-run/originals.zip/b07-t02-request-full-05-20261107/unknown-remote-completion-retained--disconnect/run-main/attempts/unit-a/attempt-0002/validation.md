# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "35836d5527b362a075f12409999e0cb8249ecdef0c5859d9fa19e672ad2448c2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "4c2441390c60821cefdff2e74e0c27ef97bc5ae99bba83f8aed6f99d102875eb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e4f6060409e27e368495cf8fd9bad5a4418029f90215b141ca68407890ed5b60"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "1fadea3dbdc1b8cf9c476d738873b4acc8d9aa2601af514c15536ffbfe6d25c6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8ecd43c6964bbfecb1116294ed4b40fb1f927c46147cf48a8ab3b043fbba4314"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a3f8e3432005c39c5f711801db9d4b339a15508c0ff05a2c736f77d07afcded6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "036335f2-89af-4d53-977a-90331d1ceee4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "504f530b-7e7c-484e-bcc0-7c971475a1b0",
    "source_id": "506a4365-d82a-46cb-93ac-2e7efb280132",
    "version_id": "8f7f4d63-7a60-4488-a207-071f96b30b74"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36745/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b7ebc4a3-6157-4f15-81a4-3f6360a4d7fd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8ecd43c6964bbfecb1116294ed4b40fb1f927c46147cf48a8ab3b043fbba4314"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
