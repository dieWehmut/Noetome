# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7a96f9b1b050ec30771912477580334b5d8d50a835c47866090d39abc0154ec8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b6ff3926bdd47514c24d9acf6be4e95840364fbfdb2f5f5c15be699e1df08297"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c0798f1e3a490ac668672efce84d91ca68153d7a2b9f8b4abd908eb04c3f3d65"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "f587917baf12131a18fda8ca6a3a9923b4b106ccdf8055e3dca6a9e4406be5c4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ea364245c1a922c5b2039382b6d2d4004ec8dd798be8bf6d73c785cb05913299"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c246d61059b12215469983e5f932f839ed4044b62b18110519bb8a0405ee7cb3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fb4815fa-e0db-463c-ae12-eb8ae7307a09",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dc764ed1-2765-4764-bd9e-9507c9162901",
    "source_id": "6b932143-ff30-4695-8d9d-a61c20614a8a",
    "version_id": "92a1ba0f-656d-477d-81ec-1a2c9a1c9578"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36745/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8359a7c1-2622-4dd4-b1c4-d2eca7aab02a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ea364245c1a922c5b2039382b6d2d4004ec8dd798be8bf6d73c785cb05913299"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
