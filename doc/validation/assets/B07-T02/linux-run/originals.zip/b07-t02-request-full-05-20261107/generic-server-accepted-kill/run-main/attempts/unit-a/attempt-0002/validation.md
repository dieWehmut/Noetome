# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cef61ff35653e8d8621ba1f9058e5d01e7b34bff75d556bfebce9c1ab9f7da42"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f80613f4a50c9a4aa5937d60a9b41ebe1d67dedb66ad8f0e81c0e9567cf60675"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "450d97044a7b382cc79e7e2be3b81ed7cdb53baf8a51f910cdf1c45bec54cc77"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "3c25eab44d90c8010239c0d87e5f23600ac21d4a32e6f67510944d57f51bf383"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "61f37d21bd119a076306051b21fc4a3942a921b785203d4a8e44921499d55600"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "153370a665c5a85e1e64251b2e140d852bef0f88ed813341fde48c69f9fc144b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fdfcb99b-9d86-4c29-8f08-cff225f3d004",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5ef6a67a-c388-4c11-9424-f342ad01222f",
    "source_id": "478f6d60-da03-4819-bf5a-84d8f7d53796",
    "version_id": "b90edce5-435b-475b-b76d-30d7f57914f5"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36505/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f1c282f6-3b66-4e6b-a7ec-c4bd42ee611e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "61f37d21bd119a076306051b21fc4a3942a921b785203d4a8e44921499d55600"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
