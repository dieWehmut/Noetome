# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "11ef7dbd2de3b1420463e25af913441fa06677adb885b3ba95a6f70753530a9d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2ad6538dd2221e1908b334d7783cef392b7981ace5cf20f78510a7bf9e2f5f49"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "868e96c0aa0b14b7a625588cbc08ffb67f150c9a5c26dd2f7f0e104086a3efc1"
    },
    "request.json": {
      "byte_length": 2214,
      "sha256": "287ab67d4c4073147ae88b89ac2a34cc89060573730c4baef33aeadb0db32281"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "65f44883ac6e98c267e2faebb4c553a7d10a1d245e4da29f8e293d094fae400d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ed5d8a601574336ab08a0cf77b8798afde73a18e8f92e706762d259428b7070e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f256a5a4-3cf8-465c-889f-14b2d8b4981c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8a0f0387-40ee-4881-8344-4004a3eb62ea",
    "source_id": "1b6a3110-e556-4219-bec0-95387ac49b7d",
    "version_id": "3432cc30-04fe-4cc0-9e64-1decc3d602d2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36573/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d98f172f-1071-4e4b-936d-55b86b3f5c19",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "65f44883ac6e98c267e2faebb4c553a7d10a1d245e4da29f8e293d094fae400d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
