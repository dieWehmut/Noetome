# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6a17c7500ddc11caa9ac44d764d5fc24f936af34bfb1dc407da3bbc2920aaaef"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b769f78ad5549c269157fa942e0af76f7e47c3c2ab7848a8358e828aeaec18b1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "88b1627c7afb1d1d9a28e99f66d1dc9f9986d3cfd6de7d28f634b5ca0e694329"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "5825bc83d5434fa321e380d06e3cb87db6cf80625475ac365fd0ce60e0f9457e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f85357b7e0059c95efd34c448968e25eed83dbc9e64c972089e48ebb7ad2d65a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3660fdd019a22527f313c354cec624d6045d21f627a8fd9588787b451dfe69ff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "970a8325-5574-4915-a115-fd3a5c842397",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "28077804-2428-46e4-a917-3b81318cf0db",
    "source_id": "3bb891ca-fd08-4818-94b9-a3b96e584e1e",
    "version_id": "e1aaf5bb-6adc-431f-b214-0e10e48dcec4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36877/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7c7a0f15-0a06-4cad-8217-f499d5d0aea4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f85357b7e0059c95efd34c448968e25eed83dbc9e64c972089e48ebb7ad2d65a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
