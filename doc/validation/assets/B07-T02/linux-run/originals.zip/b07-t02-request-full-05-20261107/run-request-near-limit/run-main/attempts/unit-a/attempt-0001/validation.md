# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d71e0848635b68d869f2c833ba9e45a38c380f65264a1b2c7f6d70b84351ddd2"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "288425054b9a627f23ffae4c113813e873fa338915d61a38e1cd1ddc665ac461"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c68b1209a2af19e34605a23de899b56408b9911f9e6e863e2e4a7771f1a2eac5"
    },
    "request.json": {
      "byte_length": 2199,
      "sha256": "9f9fcdd376cb1ae97f914b6641d54316fcc42e83a1a4fb6e2d98a01f33a42b2c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e7619c6781c142318985d8cffd8a2c07cee50f53a2733d33272203b5adf80de1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "515c6fc1d4300e1698e847d42f87694b4b2b68604a3d1efffc5832f76ca2d1be"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d54fe3ab-0834-43a7-b239-324fa3e83ed3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7dec2494-d659-4322-9c40-cf733b8f6280",
    "source_id": "59b743bb-c5d4-4a31-a56d-d8de1961c0ee",
    "version_id": "dd69c9f0-6b46-4b95-b1c5-8a1ecd236d30"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38135/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9b9d9a03-9438-48af-bae1-25c4d72ee2b7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e7619c6781c142318985d8cffd8a2c07cee50f53a2733d33272203b5adf80de1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
