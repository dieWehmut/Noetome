# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f2a4fcb13991eed03336e9cdee60aee04393b5b98669288362e60410e08d02f7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8487249700b80c822e851e0d61b0bf5ba26f68252133d0826220db3e49409e52"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "230bdbbba54f3565987995bce5069e70ccc3782d162920a045a416a296c23337"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "18ed4edbceebd46a7ab192964a7f9d6a2493883a8c97eb2ffc201b218c2311bb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4b6ff70c5d90c6356c5405cfeb2c20433e2651d2cc2a4001aa110a9805cf5b5a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d7bd17e38df8f75a762f0d9f9b552f78b9ba02489a2c417b77575d129e1ba8ba"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "343214f5-f047-469d-b1c4-3c54a891d2e2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b90cb63d-39e1-4b1b-a66c-f094abac977b",
    "source_id": "d9e83390-5f3b-427d-b1a7-4d55dbb18ee3",
    "version_id": "4644975e-af95-49f1-884d-be938fae0bb8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38469/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "920f543e-0ae2-433b-a265-d3e5ca522bbb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4b6ff70c5d90c6356c5405cfeb2c20433e2651d2cc2a4001aa110a9805cf5b5a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
