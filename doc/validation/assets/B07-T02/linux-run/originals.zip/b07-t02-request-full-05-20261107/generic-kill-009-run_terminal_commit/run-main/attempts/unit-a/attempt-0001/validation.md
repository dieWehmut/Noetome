# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8def9249ede4647761adb77426e20772e69a9320d78c108286277b923667f599"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "347c9544e03ea2e7d8fa084fb87a392f114c880418c0bd0174f1682ee15df293"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3815e26b782b046511c7304e8bbb39e4580e5df732c9edeb5258855ac3b63d45"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "65db09ad2d0afd683223fc9148f53cfdb084687be70356efeabec5aecb4d52af"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2a091ef4cf4ebf73f5876bb0c80944b0e22a67639f5b030708d95c88d6439aee"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "51230bcd4b7fee4b666934bc4031fa8f7ba737cdb0e5f5818f843a6243ce5736"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2b8d8624-0321-43ea-9ba1-6e75b50cefd2",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ca702293-2dc1-4a01-aa1c-f1d9b372df09",
    "source_id": "cb3f5ae9-ffb4-4fab-a002-628c9561829d",
    "version_id": "e93e5148-4c94-46be-9287-f0bdcba1b60d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36443/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b7fc0e04-fb70-48bf-956e-2796289abcdb",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2a091ef4cf4ebf73f5876bb0c80944b0e22a67639f5b030708d95c88d6439aee"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
