# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ca3d52a090173c4c16effb18cecfd9ceb44847596111aec0cba393ff5b06d8cf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9620d452848ae5868c756488da884767c16fc5de7170c605ab2b98091d035e84"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7d79633be9c68b43fb668122153cebfa5d658312db4606271208058fbdaad2f8"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "c1d3e5aea6164e25840d1184d5c2f2d45bd2ffcbaa9e0382dc724ff2613f0599"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1f3853fbc38e78a649818a92d7abeea8506da008b2b83da5967cd622047159c4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "6fef10dc49b44eeb81b98272e42cd7c6a177635a86799da4df91fbcac6c187d4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "64ec9d86-850c-433f-997c-ae7d1b9dc4b9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "94fe5a1a-5fdf-4f43-9bc2-f2435406d626",
    "source_id": "256f0492-7a8a-42aa-9b9c-7e280820fcf7",
    "version_id": "3a4d70e2-4e1d-4f94-87d6-66f950fbe0c0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38041/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "88a65e04-3d26-4014-b5c0-1f4c29830383",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1f3853fbc38e78a649818a92d7abeea8506da008b2b83da5967cd622047159c4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
