$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-05-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-05-20261107' --snapshot-sha256 'b072f147632ae75d6934e311e657ec78e825b3060d9f8ec4720230519e587d74' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '0817cc1318efec8e888279587b2141a35e6c9575946e4f68a71b68d107b045dd' --executor-sha256 'd3984fb461cf26ef7d2e4898e05718196d86dcfa8928be4b3bd80acd67305b88'
exit $LASTEXITCODE
