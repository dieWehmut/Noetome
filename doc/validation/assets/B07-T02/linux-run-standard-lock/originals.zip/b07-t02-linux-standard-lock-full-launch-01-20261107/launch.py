from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path(__file__).parent
repo=Path('/home/lyinn/project/Noetome')
source=repo/'scripts/verify_request_budget.py'
frozen_four = {'crates/noetome-cli/src/request_run.rs': ('e4d598e28784050f3868e6677e2a26559f0304db414075d6c67d91e3d853758e', 74943), 'crates/noetome-cli/src/request_budget_store.rs': ('c87a46a59cee89b7e6ddfc136698b42a4990d63c5a813f74a9f1b2cc7d67ad4a', 165884), 'scripts/verify_request_budget.py': ('3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7', 169966), 'tests/test_verify_request_budget.py': ('42825f8af2e214759c3b709375416df6fdc1c4bccd1ed973aa0f39e2bd3c0348', 50420)}
for relative, (expected_sha, expected_length) in frozen_four.items():
    selected_file = repo / relative
    before = selected_file.stat()
    raw = selected_file.read_bytes()
    after = selected_file.stat()
    assert not selected_file.is_symlink() and before.st_nlink == 1
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_nlink) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_nlink)
    assert hashlib.sha256(raw).hexdigest() == expected_sha and len(raw) == expected_length
assert hashlib.sha256(source.read_bytes()).hexdigest()=='3b263fca7811d6c5dd138181d129fa2b6253ae74d6af78f6c66cb98e61795da7'
pair=repo/'.artifacts/b07-t02-linux-standard-lock-pair-01-20261107'
argv=[sys.executable,str(source),'--cli',str(pair/'noetome'),'--test-driver',str(pair/'request-test-driver'),'--build-receipt',str(pair/'actual.json'),'--fixture',str(repo/'fixtures/run-api-budget-v1'),'--new-root',str(repo/'.artifacts/b07-t02-request-linux-standard-lock-full-01-20261107'),'--full']
env={key:os.environ[key] for key in ['PATH','LANG','LC_ALL','TMPDIR'] if key in os.environ}
env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',NO_PROXY='127.0.0.1,::1',no_proxy='127.0.0.1,::1')
with (root/'stdout.bin').open('wb') as out,(root/'stderr.bin').open('wb') as err:
    child=subprocess.Popen(argv,cwd=repo,env=env,stdout=out,stderr=err)
    (root/'launch.json').write_text(json.dumps({'argv':argv,'PID':child.pid,'outer_PID':os.getpid(),'utc_ns':time.time_ns(),'child_environment_keys':sorted(env)},indent=2)+'\n',encoding='utf-8')
    try:code=child.wait(timeout=600);action='ordinary_wait'
    except subprocess.TimeoutExpired:child.kill();code=child.wait();action='own_timeout_force_kill_wait'
(root/'actual.json').write_text(json.dumps({'PID':child.pid,'outer_PID':os.getpid(),'exit_code':code,'wait_action':action,'utc_ns':time.time_ns(),'scope':'current3b263 checker and e4d598e2/c87a46a5 standard-lock Release actualLinux full62; prior registered-identity Linux62 and Native failure remain historical; no extra3Linux targets or pass-count reuse'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'PID':child.pid,'exit':code,'wait_action':action}))
raise SystemExit(code if action=='ordinary_wait' else 1)
