"""Retain the prior builder and write the new standalone source before use."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).parent
OLD = HERE.parent / 'b07-t02-linux-registered-identity-final-independent-checker-20261107/build_archive.py'
raw = OLD.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'afc49fb6284b62b6b8dcf51ad22659b8015c4cda9c324b35b47a38aeb3e24278'
with (HERE / 'prior-builder-original.py').open('xb') as stream:
    stream.write(raw)
source = raw.decode('utf-8')
changes = [
    ('registered-identity', 'standard-lock'), ('registered_identity', 'standard_lock'),
    ('cb137897b122411e02bf42f67ad1484d8a77fd3efde62a8d402baa3f207ebcc4', 'c61bcf12b4ba35618adfd95c97e72550738bde319a9923726fdb9bf606dd594b'),
    ('e4d598/57c1d73b', 'e4d598/c87a46a5'),
    ('ac9e92e1c74d66d2c177d3606158946069deb6062f13d183d2f46b366abb436b', 'c05f33874e548a47d29c2c7a9b427ef9cce4df1485853201f50686f990564671'),
    ('87568e22d95b643a10bbb61e7eaaad52dafa6bbc7811c69747a33130d637dc6b', '8df5913d8113b5f4a984a20dc2840ea808a9794c21e4966ec882f245eae66158'),
]
counts = []
for old, new in changes:
    count = source.count(old)
    assert count > 0, old
    source = source.replace(old, new)
    counts.append({'old': old, 'new': new, 'occurrences': count})
with (HERE / 'build_archive.py').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(source)
with (HERE / 'builder-materialization.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'status': 'standard_lock_standalone_builder_saved_before_execute',
               'prior_builder_sha256': hashlib.sha256(raw).hexdigest(), 'replacements': counts,
               'new_builder_sha256': hashlib.sha256(source.encode()).hexdigest()}, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print('standalone standard-lock builder saved before execution', len(source.encode()))
