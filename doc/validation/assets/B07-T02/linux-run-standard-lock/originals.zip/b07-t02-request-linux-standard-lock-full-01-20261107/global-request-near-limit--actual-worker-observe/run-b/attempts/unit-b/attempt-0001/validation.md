# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a54286bca5c87b3277bacad09568df2770deba53832285115a6fe777482f8cb1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7dd58c23866b78c5baaf801edfa86d0dd355e48d769aa2cf2614b14e4511ebbc"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "aa6837f6bf0738b1d4d265eb099a7093e3bbac0d0f6ddc2d87258fee19195aef"
    },
    "request.json": {
      "byte_length": 2245,
      "sha256": "493dcab835a970126eac73546704b72b9ccd9d85ce2e06b3e57ac1237e0a854b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "53e34cca3ab357e0af83706f99c41958b8e82beebfab8649d3364df860439fd4"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3dc38bfd23b9377f9a0f69d4d69ae5fb09e2d1d02a62893057743be035e1ecdf"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "959e4890-e970-48cd-99bf-eb375cb08386",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "01ce4e24-7254-4a0a-9c2b-c8ed44a3eec1",
    "source_id": "d8144538-4ee3-4df7-9c43-31c9042d3ce2",
    "version_id": "ad430a94-9949-4dc3-a22f-91265ebe784b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37585/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a67f15f4-e6bf-4b70-aa03-bd7ea29f0f6e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "53e34cca3ab357e0af83706f99c41958b8e82beebfab8649d3364df860439fd4"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
