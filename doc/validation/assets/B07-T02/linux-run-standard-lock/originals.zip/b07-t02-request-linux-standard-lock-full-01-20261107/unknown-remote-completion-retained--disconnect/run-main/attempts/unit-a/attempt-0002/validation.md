# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b69b8e0fc146b75237e969aaf3de124d9c2bf4a9db213b8873155b94248e1e03"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0cad120b2db53164f45fd8617b077b9daa03d0d0413fc4cde47a146a376ad5f5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1cd6b51e499ce0ccab5377dd6c3b0a02ef6200c58cf820b32db6355750b786b1"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "b65a42e9a3f02910bf36291a8c320cf12f4e7156c4f2888c6d2cd044173645eb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "72a593260fd885bad16ca42d086eb3c2d3a6c97d43ee2a7327a43f21787c40c0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c1dbb0ac54b860daa58192405c7373a83a8961955e5dd3cbcdc5c55acf8927c0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f8eb12bd-a983-47f3-a3f3-f217fcc42e87",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "d7b2dde5-387e-40ad-b2c0-5624cf942b77",
    "source_id": "2cbde91d-f0ca-415c-8bd8-749f65385880",
    "version_id": "0f60d404-571d-43b3-90aa-f0112fd06369"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37635/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dbb4e355-55ba-4f28-93a4-512542fc3cbf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "72a593260fd885bad16ca42d086eb3c2d3a6c97d43ee2a7327a43f21787c40c0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
