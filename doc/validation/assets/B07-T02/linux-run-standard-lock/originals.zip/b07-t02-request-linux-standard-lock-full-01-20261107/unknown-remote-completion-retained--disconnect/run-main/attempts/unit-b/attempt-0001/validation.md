# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "433c99d50dbd32c8c09138dbddca6d983cca996034d29d2315fa473c06c017a8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ba54ed45948d18d1487f91993edca19ed1cf9bc936abe496ad8189ff826d20e3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0d450eda40cb58ecbf9392a7c39aac6780020c80998ccc1d474a9f7bc2de7e3d"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "e1044e33eefdd52fc39c804f6df6334e8450c55c1aa8eee4c7d53dbbdb2f46d1"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "faca399640b6424bfa781d9628d8ca021d2b24c344a130b026d85e6a484d4b57"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f22bcffaa1ccd44802566ce8a1ec3046cf9a79158a406a6ecc04a2d164ec2212"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2201bb21-fe5f-4261-8225-876cf1f139cf",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5290dac9-846e-4234-a0e9-0be06f1ae34b",
    "source_id": "5d23cbcc-661d-4c1f-a50e-1f6ac6d4949e",
    "version_id": "54a777db-444e-4650-89a6-6a6a05b28da6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37635/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "09808814-5388-4929-841a-5c96ff6a7f00",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "faca399640b6424bfa781d9628d8ca021d2b24c344a130b026d85e6a484d4b57"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
