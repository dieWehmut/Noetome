# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "08d15c93ede9d9cffcd072318daa0ec7b3c1a7da6ac2352d8244d3d17b81697e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "af56c288bcc6d03f3644bd032a1032db7b0a772c8280b317816ad80510555582"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "31d4b2e1c6017439c6e07d8b7b9e6813e212d2b53072b1a82ba00a61e4dc8fe8"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "551a9bb7a3cd8eca8cf8c02f625a6ba2cb0244e943ed8a9cb97012594504d6c4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "241532c5683385e87b39251e677eb06195bbcf7fea04352eeda7ce5ccfe61a17"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1368ca49e95042c20bf75a86aa3582c7c5c98c6dde58ff47ef4e95ec6f49240f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a8dbd2c5-5b59-4b25-92c3-c0566dc7340e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c810f4fc-dc5e-4634-b068-539b6c79bccc",
    "source_id": "09731a31-cd97-457c-aedb-7da148a6e662",
    "version_id": "0681e435-ee46-4894-97ec-54d1188199c4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38101/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e203b6f4-446e-41c5-8743-24988f671156",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "241532c5683385e87b39251e677eb06195bbcf7fea04352eeda7ce5ccfe61a17"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
