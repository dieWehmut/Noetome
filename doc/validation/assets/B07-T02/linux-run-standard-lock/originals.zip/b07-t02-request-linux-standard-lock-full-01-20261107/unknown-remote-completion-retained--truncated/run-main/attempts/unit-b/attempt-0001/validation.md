# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b1afbd8d9dc199edb1e7b87f3dd006ee9c900747a5fc3d139344023fde4f11ad"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "437eafbf726a447f7f6ab35182f68a969ff3c22be30e18d51a5f8843d62a446d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "903e9f5b5e75208218a27bc304f6ab9f286bb32627c4313c50729142cdbbdbea"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "eae3962fc9edb6594776abf572e78fc883f0b44cc000a71f2ecad2fa7e69234d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ed8e3ab706001d0b825b4b78d5f976c3ff460b5858d3f1870a0871802d746e9b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "bedcf3e1c6b930d126647dbd0fad0447987679f3fff32e685f987e8eb34c5120"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "78144854-69f4-49a7-9d40-be0bb42a0e46",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6677bd2f-ffba-4920-96ba-1aa3502bf767",
    "source_id": "f8430f9e-bfd1-487a-81c2-ec0e418829a9",
    "version_id": "11bc7335-3f17-485f-a18a-fbe1163fe64f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37519/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1c94272a-437f-4f17-bc5e-c7b76149e28b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ed8e3ab706001d0b825b4b78d5f976c3ff460b5858d3f1870a0871802d746e9b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
