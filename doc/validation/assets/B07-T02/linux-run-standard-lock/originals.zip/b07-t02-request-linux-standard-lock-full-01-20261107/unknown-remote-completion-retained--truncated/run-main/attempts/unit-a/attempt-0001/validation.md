# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7dc9024cd7b3ab856b1dc25f3d26ceaddd9d2612115274a1c180f7f0bd263836"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "deff6fd8c291b81cfa379434dc897ed5cf2b402c0320a54078673ac1cf4be178"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "5158b48b2e0e8c850a812e935875eca6be869ba6bb480d51c60659fafdd53a27"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "transport-receipt.json": {
      "byte_length": 495,
      "sha256": "871b872b5da993e99795540ae31efdfa23a20b10e5fbbb1994e47cce3a63c3c5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c46086ac-2b79-4dc5-bee8-dd66c6fc44e9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2645ebda-805e-4301-82fd-d7e60d67023a",
    "source_id": "b1c85794-c0b8-4fb2-bd0f-0f01c9ce8c0a",
    "version_id": "bc7981a9-4239-4de4-a7d7-f3d4b8cee024"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37519/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_TRUNCATED",
      "message": "EXTRACT_API_TRUNCATED：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "205ce421-3277-4ffa-8058-f75c2773e474",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
