# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b4fcbeb9fee4165406ce9f33df6f0fec2c0768bd18cba656f22f9317c8cfb061"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2b35f15965a48a3d1f1269ba5721e642d782c5e7298a8f311263f7e44ca77cdf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "d3f253673d93bc2dfc0989eb62687f3d2085fb9d7cdbce6b47278b62be2886ef"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "8f46d094a07c11beef8091cb51c96b099c929b3762eb75610b820e04247d49eb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "738a19e6fc6c627cdbc0c984d519ad3dadde1490f94326b84fe3628e9dbab249"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3864c9258e052ebf7d77084c70c16a3f72a92e4b94ab3095c918e34b4a502127"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c46086ac-2b79-4dc5-bee8-dd66c6fc44e9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2645ebda-805e-4301-82fd-d7e60d67023a",
    "source_id": "b1c85794-c0b8-4fb2-bd0f-0f01c9ce8c0a",
    "version_id": "bc7981a9-4239-4de4-a7d7-f3d4b8cee024"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37519/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2b1972a6-1038-4b26-998e-5da9d482dca5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "738a19e6fc6c627cdbc0c984d519ad3dadde1490f94326b84fe3628e9dbab249"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
