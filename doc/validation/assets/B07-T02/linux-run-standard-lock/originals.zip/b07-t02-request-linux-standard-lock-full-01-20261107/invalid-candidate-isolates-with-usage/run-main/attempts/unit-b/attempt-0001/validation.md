# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d97ff72150d56075b98a78c64c229ee935da1b20314774109f59df1c1caad6f9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3c363665f77750dc3901aa883d397086bd9d9a8aa061e2591472230cb8efde97"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "29c4961c82e62538392d0a0531880b1a04fe60fadacc30702bb8db602a667256"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "a348e0024dbffc6be2d03aeb5a7fc40814b889802a4e57a5322ddbd9b9154da6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1c21edcb8996a0f5f26e03f4d2256c7b7cc6539c184cad04c245aa8003cb36dd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "57527577752cafcf96af632a77ee7e6bb1a1c029d1562e37ca68e93cbb7540b4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "792f02c2-be0e-4a1d-a9a3-e91f9eaa7f6a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cf562d1a-7130-4399-80d2-0146cc30886f",
    "source_id": "a1f85bdd-e001-4be5-9123-0630704232d0",
    "version_id": "45b59ed7-7060-45e1-a933-0951ba3f57f9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36961/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "720916ca-4964-4160-b097-4ae30fd04542",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1c21edcb8996a0f5f26e03f4d2256c7b7cc6539c184cad04c245aa8003cb36dd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
