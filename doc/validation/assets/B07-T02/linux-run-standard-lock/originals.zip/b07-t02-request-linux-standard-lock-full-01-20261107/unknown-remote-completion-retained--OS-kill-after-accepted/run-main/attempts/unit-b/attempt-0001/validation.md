# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "80044e92bc092887fda442694b918e3b562c832136f27976291db68022497ce8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "797fcef712ed192141406a1a313cdd8196892bb75aaa31cd0a0ae6acbe6a6698"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3c31405def4d94ddb3f76d0132d0cd4a6f55915767faae59038a0e7a032ba2e5"
    },
    "request.json": {
      "byte_length": 2255,
      "sha256": "4c7278014cce9d585a033042a205428bb0b4f98d1caf5bb44ac4e79a868ed892"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "750094377a90e1cd8394bfb68e6318e78867cfd65a62f01095789970181e185d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cd921883c7bb02b104d7305e574f5c2d8a610aaf84a32a7183db4ec162ff0be9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "04674124-f19c-46b7-8cb8-6f518251cacd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "883de037-5f26-4767-8c18-f6427a78eee2",
    "source_id": "05b8b21c-f543-4938-b969-fca074657b4e",
    "version_id": "8be7ef56-e801-4896-828d-b82b2c8e00cb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36717/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9d435564-c992-4cf8-aafb-ff6593cb6daf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "750094377a90e1cd8394bfb68e6318e78867cfd65a62f01095789970181e185d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
