# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0392422359cd1f828716ab64b3107d32f6f3f8e0a71cb57ff075a32f6a9c2e9d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f910c3fffd8418aa85bd22bda482c8778e454338a9001de081538d091b4b84b0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ab0859bbe5117d90458dd736f2415b3dcc4aa09309ab6c7179dda74c181fc09a"
    },
    "request.json": {
      "byte_length": 2255,
      "sha256": "616c49905d6e3de87b3b50b347ebd0498ef3569fb896c892b9a1ca810486ac50"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "89a825bb35a022c4f1179973fb30217fd83856203ab6dba24dfce83d6c8f38e8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "559ab6cd06978fcd48df8328113058c795274683dc7e750a89fd178239667a5e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1a9935c9-5152-45db-b8bd-f6914a37f2ad",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "576d4922-ef63-4b42-8c0c-73396f870ba2",
    "source_id": "2bd2d019-eb84-439a-8f1b-400a5df18dad",
    "version_id": "c28e51cd-7e79-4941-b885-74b3269993a2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36717/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9d0c950f-ad42-4516-851f-3de4d469724a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "89a825bb35a022c4f1179973fb30217fd83856203ab6dba24dfce83d6c8f38e8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
