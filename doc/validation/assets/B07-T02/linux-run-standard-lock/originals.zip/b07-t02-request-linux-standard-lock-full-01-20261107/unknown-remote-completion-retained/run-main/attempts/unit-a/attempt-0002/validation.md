# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "851b8aad7877c5888f7c564db69bd4420ee6db2186bcaa6161addbc456329305"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "71e82eaa0af2fa22654d1e9cdb2030c9cacdc5162a33e143accb8909bba6e458"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "49d743f260f3feff9b43382bd01a1e2da519163a97fb718318b2fea129e17407"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "39ea77a2a7b6e515bb62bace2a96d429a8e180ba83591039ae8a64643641d53f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e5902c4ce6ae140eac7fa7066959b833b88dbb50fc87f5c99542e600387d637b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8b27c48369cfcfffbd2bfda116802da7349786fa3597df8a7d03c480c78e13c5"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1bfc60f3-595d-4985-97ee-54cef642693a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4edfc000-6319-4658-b44c-bd552eace09c",
    "source_id": "73dd43f1-a007-4e5a-982f-90a29c834fdb",
    "version_id": "8b3c4941-a942-418c-917e-1812e30ce72c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36985/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8ef90358-cb8f-4c91-8b39-0a197f915028",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e5902c4ce6ae140eac7fa7066959b833b88dbb50fc87f5c99542e600387d637b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
