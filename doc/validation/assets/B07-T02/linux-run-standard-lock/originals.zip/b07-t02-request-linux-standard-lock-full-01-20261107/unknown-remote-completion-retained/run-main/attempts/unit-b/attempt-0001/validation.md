# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fc8890180bcca30d2c4ccc03311adab9bc768dc4debae030c1187fcfbea9351f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2b9160b0ebb99707c14d0dacaacdffde417bc8fcc101ca487c1bc209be43e3b8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "959b8bc6177d81ea37830d32619c60f17988c77e55cebf5dfba6af0ceec85a01"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "db20768288196931b66b2c778ca4e82b5e16101cb4692609a7bf9d2e1ad91e70"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c4f07ac2ad7089e8329d65d1dac2bc75b6d3b0aa5a4a438210cb74ff1641030f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c55fae52f1622a9b5d146b651aa0bea04c850b4ea14b72fb34a87a63b9407903"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a7621b2d-19ee-41fc-8e1c-e0463354e1b6",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c936f29e-2097-46c2-a068-ed9e54dffeea",
    "source_id": "58789022-0ba7-4599-8296-75acc669e5a5",
    "version_id": "8aeecce0-696a-4daa-9934-f8fdb82aa560"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36985/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bc120fe8-43f2-45ee-bf67-8fd55a74811e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c4f07ac2ad7089e8329d65d1dac2bc75b6d3b0aa5a4a438210cb74ff1641030f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
