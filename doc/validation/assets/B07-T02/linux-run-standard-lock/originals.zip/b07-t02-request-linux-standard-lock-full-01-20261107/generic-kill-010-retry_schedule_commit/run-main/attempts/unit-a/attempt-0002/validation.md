# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "98ef4a8a08a2206688f3f8c08158e7f6ae2ff902ba802711c3d9056be90b5310"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "05fc646d8066b7c862edda4c57e76605a0f9f2251060b86996f04e670085e581"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "32be3dddd4a400e109b434462a27877dc0057a5a10feb233a693806e1789bc2b"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "305b316a85fdcd3f991b01b1f800a8c99251c7801ab48504e6f12fade5d8540d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b2b1739b8ce15954cd0d7b6861d6d3e393de5932ff5835e18f3b90966bbdf5ab"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "33accaf949fd00ed5273c8e34b3953ddb6435ca685f0d3a25890626d7e5e6dd1"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "80ad4117-2607-482c-9a71-edde885a5eba",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "603f039f-36cd-4f31-a59e-079dc8a8561b",
    "source_id": "3a07c396-19de-46b2-be29-59b6b675ed73",
    "version_id": "ceff244f-3cf6-4624-a1da-ad47ae827147"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38313/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "df40d394-a0e3-4956-a4c2-23ce00967547",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b2b1739b8ce15954cd0d7b6861d6d3e393de5932ff5835e18f3b90966bbdf5ab"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
