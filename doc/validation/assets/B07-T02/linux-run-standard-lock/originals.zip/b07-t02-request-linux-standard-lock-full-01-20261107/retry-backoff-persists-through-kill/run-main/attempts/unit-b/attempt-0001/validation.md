# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "31fc92406d3592b13d00ead1d1c87bbd270b741a0b6e77acb1c34398b43d1101"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6bf911dad55adbb0394e8304da679ade609fb5c2a8620b04da18eadad57b55a4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6217555481b0bbd66a81bf07d68ed8e927bbf7c8c4aa42d4eed0fc2843c6de14"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "7a865559589b9889b9e8d58d65860092b1b3a4efb529d2631e4378d55d0868c8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3e24e0f658941fbd588045eeaec0d23bf055d22912cf0bed52d3628b260eaa57"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3575fb3436504090152c264ce0e48f3bc8f29fe08cd33508ded5c5707590fd5a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6bbfc744-b57a-415e-b2e0-85c9a982f4dd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e16925b7-a885-44a1-9949-89d7ff520f1a",
    "source_id": "58e96155-249f-47df-8e54-92af990ced06",
    "version_id": "4842c4e9-d9e7-494e-af1e-46f37b5322c2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37389/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3d143ed2-bcf8-47af-bebd-61e37723662b",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3e24e0f658941fbd588045eeaec0d23bf055d22912cf0bed52d3628b260eaa57"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
