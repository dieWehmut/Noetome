# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ca1575707d64cc73ddd22aef6b70d2063fe5341ba8666cbdb1f3922d470b9021"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "101cd9640aad87c2f95625de68510955f3abc5cd730fbb0953a8c4c58a32b83e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a909139cdb99e2e73db594b53fa019262e6a3abaf49882e35437afe4ef66df8b"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "c75ba601e480ee76d44d7ee335bd5272b945f1ce63e73e65b3e9231942af839e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3f37bb36d660d6d2618dba911973b5ac953589c96f4bef59199b45420255b0be"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d3b8220fb7dc6d5e44469b96def63c113a91255d7b5996a1d352b4fddbaa96b9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d4d3d3c6-265e-402a-83f6-57e9c67f929b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ff11e7e9-5037-453c-b0cb-720d521a1a4b",
    "source_id": "4e47dde2-9f70-41a4-ae7f-58fd95151904",
    "version_id": "90e92258-d2e3-4d66-8688-dd2a2212ba15"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37389/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ba1045d7-89d5-48b6-ae92-058f48f09127",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3f37bb36d660d6d2618dba911973b5ac953589c96f4bef59199b45420255b0be"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
