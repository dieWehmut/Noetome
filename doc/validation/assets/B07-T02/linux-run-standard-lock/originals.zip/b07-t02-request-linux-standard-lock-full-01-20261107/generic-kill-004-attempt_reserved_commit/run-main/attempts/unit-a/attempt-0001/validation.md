# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3633d865bcebae73d064a52b25ee719c5b5d0e9e1dd11b0dafa2a5e804f7f427"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "845de80b09786daa1c18da85f2bccd8eb34bffc854f33d13fee3db17a39012d4"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f49f1318a924cdc798f66e4972e3f1be128083de092b3985b89f3eaf5a50409f"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "8f21845f8d8ee0ba88bd77b193bedca370aab0e3b4785863d7b34ce6eda3627c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2b800385453b5ce2711985cf8c8d80173c3bd92dd7a3a887a630a0bf2f27de88"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "14ee502636df6df06add2f565a27ea259ddd4229abe7dde1986ce6eabffd294d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0649f6ca-9845-4d4f-8579-a3874073f1e1",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ce97e97-c1fd-43f8-b2ac-736ff5d390e7",
    "source_id": "861e9352-8a2b-4fda-b61b-51c223be706d",
    "version_id": "f5902a88-99a8-467a-92fa-4cc5908a94d1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37633/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3601f43a-c4bd-4d51-b118-087c5a60cb6d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2b800385453b5ce2711985cf8c8d80173c3bd92dd7a3a887a630a0bf2f27de88"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
