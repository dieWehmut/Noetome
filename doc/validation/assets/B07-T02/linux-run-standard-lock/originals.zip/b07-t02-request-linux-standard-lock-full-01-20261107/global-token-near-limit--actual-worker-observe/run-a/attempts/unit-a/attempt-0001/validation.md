# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "345b4f640fa4a5b43101166e7b8e5e0886cbd8161d44b2f7ee0e35154304bd77"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "33f5c7aa62f6ff3cef1868d2dc34d807941e0e3c9ab191b15f1bf79495dd518e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "033b46a432db08a8b6eb1ef0b6c870d0d1def60a1f5554e5b36efee39ac66782"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "0a995acc595cfdf122112ab958d9f6024dda924da07c97634e9c502e1e2c13ab"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "23af98750928a8830c765adeca2e4cbc5372889b01cebda85fcab5acf704eb07"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "41e622960d1431ff7454da7322b9a21c2d01de4efcb1b5c24a07931692fcca66"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9fbfc776-f623-41d6-a9ca-89ad4bb44ead",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4fa0b67b-d2d8-4cc2-bf5b-edafb9c81542",
    "source_id": "c288d3d1-1dc9-4949-ba4a-76f99dfa8443",
    "version_id": "cbab59ef-adb3-4d16-b22e-315f8a8e0c07"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38077/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "68875c56-62e6-4aaa-a140-8a7c9f1068ce",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "23af98750928a8830c765adeca2e4cbc5372889b01cebda85fcab5acf704eb07"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
