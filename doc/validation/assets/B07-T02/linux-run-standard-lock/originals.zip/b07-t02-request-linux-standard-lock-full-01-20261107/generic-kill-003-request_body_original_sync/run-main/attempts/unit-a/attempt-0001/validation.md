# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f775ede4c964811c197b36309b48313229bf49db4f4511c09479e01064001e8c"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cd7ba55477bcb8ac41389093c42048a20cc2abf21449be6e54aa4348c91791bb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "bb9ff6211cb71928853bf508025badc789374f224ddc7280277497453faca7aa"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "98d5d8f4e55bdd3733b2a4d46abeca3b7c7a81b582ca0276254cc572f33a0e97"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b636e2f42bd9dec67749b91ddbff1c02f8d8109106723eb0646ccf9ff23bf545"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "27c45bbe3f76a37e3af74d98ed36db76d1744362e3e51d732b5454b30099cbda"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0d525c1c-3444-490f-9904-6913ed8c3f8f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "3cdc737c-d4e2-4982-a9c5-7283c618aab9",
    "source_id": "9650e9bb-f4ed-464c-bf6d-e60974b0a25e",
    "version_id": "090865b1-7e76-4127-b4fc-8fce2d40c0aa"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37567/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f0a45d91-d28c-405b-9d21-656cf3773b4e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b636e2f42bd9dec67749b91ddbff1c02f8d8109106723eb0646ccf9ff23bf545"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
