# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8be885b261a7fbec10db4ad5aa21c4a955a6dbee5b9af57eeb6b4f84efd223f7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "28ca16a1ae07ebf7832380a63501974120cf9bf8f8fa8bf9e32785901f3cf2e9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4e3ead2c4eeab4feb77249847d3d516f37ecf2052c20041555af9659b5ef14cb"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "a86c5d0cd315bd666bb24d7b030b93b45af0d3b997c7d6e6d303e796e61ccbf9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "dc5c4ee3977509c03d2f89b9684f28ad470ac65a2a0bcd70a6698c7c889f3d7c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "91e4116b2a72aeb7e6d18e0d20bb3ca34fe8e0cc4ec9b82697312582cba5f193"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "639f1b1e-3424-4bee-a5f9-9d7667a8830e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c672d705-5e1f-4f73-8cf3-4f5998698bd3",
    "source_id": "b1cf7956-756e-40cd-867d-fcd51bf9eb7e",
    "version_id": "6f7a8564-20dc-4c35-b464-d1dda7eca428"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36539/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4c019bc3-4cef-4dea-b78f-c3cd9d04483d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "dc5c4ee3977509c03d2f89b9684f28ad470ac65a2a0bcd70a6698c7c889f3d7c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
