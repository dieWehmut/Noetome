# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a0274969aeaf335ed4e2f5321df1bb0de1d4b686b33843da9215dc2e58b67cba"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "cb31d360497941cdbceb4c9eb9efc4a54761dadabd2108797bcd6ac30a41fbf0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8b2f663842036138f9628dcc47cf0228c44abdd9c1fd5d47cfc1becfe73cd4a1"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "534b47fb2911412862aa951631e5a874d55ba19bce9daf4770f0f088d1a76e47"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0dbee29b335d4b6ed653a9528d4ee182d6f003474c28b394435b4fb3897245d2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fe985425f999d445b27a87f5363ccead9684460fdad3b8eaa4fe62ce050d0df7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5c94fccd-f70e-4e69-8aef-5d84240a658d",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dcae08f6-0ea3-4bc9-96f8-2c64a1139c48",
    "source_id": "23ede253-41d2-4a81-805a-5de38538746b",
    "version_id": "da64ba90-99db-4241-84b5-b26c7e34f703"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37251/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e470d161-ddf7-47f3-89a4-41e47be67b02",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0dbee29b335d4b6ed653a9528d4ee182d6f003474c28b394435b4fb3897245d2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
