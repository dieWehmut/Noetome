# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2de3d17fd47d452ac4bfcd0ff56c3a4729a7b72806acf0e7f5f40f3a772e7736"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d97a71c12f5b2b45e621afcc0eb7396a9379f7ccfffc4789b7fa85175c30ffb9"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "13f617a9e916448de15aab0d6660c14577b537ba1684879cb32eaa988652290a"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "a0b3037f668dcbc4410cd83db4cfaef48740f43f5185375982845b8e8a161b43"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "505a0aa6ddfd5e441722c51b9d431b1011e7d5ea4ddd02413e7ce68ec6e7fc8a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "feedff3c6cc707218ae3d71790c094dbe7ef87813e1606842ae810f38bd5979c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1f3afca9-15d2-4b57-a095-eab8ca6da922",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1c019a07-edf0-46d6-9220-46df104bdb51",
    "source_id": "6e99b685-080c-40fb-9070-94d3dd7dde33",
    "version_id": "b4c2b364-0000-4e1e-a92a-1bac0e362f9a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37251/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c8f8dc8e-9ddd-4620-891b-380de61b1143",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "505a0aa6ddfd5e441722c51b9d431b1011e7d5ea4ddd02413e7ce68ec6e7fc8a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
