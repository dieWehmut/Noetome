# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5153aeabe8c672cc368acb58680c131ef4cc582ed77fd6f15981c0df891b3839"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "3992cef970a596733ef3b6bec3b2829a8b53f06e99d0df535d42fe95bdd58dcd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b38daf752a450b6813689d25e5400a9eaf7b8e477403458c86595afe7da2b35a"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "4c9cef63eeb762a24bec211f9d06f4f7d68315a1d294fdc228744cbd58b65c45"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "dd93897a8e8b310485b02242752ea409e2306cdb42bd0f3650049584989cd253"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "269d5e989d9c7cee7366410338801aff1f3d695ce14f657a6d8eed1b065de69e"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6ac2612e-3030-4e9e-be85-6abc9caf0715",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "43c393c6-8b76-48ba-b724-4acf044038c2",
    "source_id": "d43a92aa-e131-4e04-bfbf-b02db5b0114c",
    "version_id": "0fdf57b0-d664-4f25-93a2-924bc460bb94"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36435/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "558796f8-c06a-4fcf-9158-445edd03b248",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "dd93897a8e8b310485b02242752ea409e2306cdb42bd0f3650049584989cd253"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
