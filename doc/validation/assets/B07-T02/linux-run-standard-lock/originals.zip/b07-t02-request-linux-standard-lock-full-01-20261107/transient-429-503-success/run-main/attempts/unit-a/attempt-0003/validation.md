# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "50f23f6d7427d9aeaf002ce96ecddb7dffbcdd0978f224e422d0faf495738ae9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7026af2c6cb632490836c758d334db2177b3b47ead03197373cfe8cf34685b3b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8d22a381becac467b9b8200b6b8305c0c84dc42eaf9c92f9c5708289bfa9f735"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "3e37edcc2e7cd658273b4586a6317044ee800350963621559875d87e9f247866"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "588abcbe4e011263a28d573978d179920db200fc133bcc1220efe5ba05930a5f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "52e91ec6c7edfc6474ca0e46106524383dc69c31be4e454216bd8522faa362e8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "de836fa7-85fb-45ae-b704-5b32edac5e9f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c52a0811-0c45-4074-99fc-9d7c0d918c41",
    "source_id": "7503c9ab-45bf-4b18-89e3-317822a1e982",
    "version_id": "f633cdc7-d5bd-4751-afae-07c93d0562b7"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37249/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cdf5a444-9dfe-4015-bca4-9cb5c029aded",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "588abcbe4e011263a28d573978d179920db200fc133bcc1220efe5ba05930a5f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
