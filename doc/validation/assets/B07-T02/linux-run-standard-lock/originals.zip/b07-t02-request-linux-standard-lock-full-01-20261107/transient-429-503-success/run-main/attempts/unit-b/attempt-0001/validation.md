# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "55875a9be18cc0f017fc902044f442c5d0e9e4a2eddc9308235d4fd4ec5f7a5f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "405600b68b5f037c1d0483940697c439cf6bd9647acf9e7c5ed2fa04de5d298e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ecd70010b101198832da9f22ff5781feb41b1c302ea32de79b8545cd59d19a73"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "3b30cbf3f09d1e09221a48e60bfc9a60324972ed665d9c0a79526dc811d4d54c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "276a1b2827e3667a3aa44649692df636274a03f21acc09849614a619d6f61e65"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d262d8b1b63aa43e6d416c515f5d4c15c5727b0c7b1d74c4ca140022024b1ef7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e03a70ad-9236-4215-8a40-9ed4bd7b600c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ec27d897-800a-4284-ad41-15734a6b5a2f",
    "source_id": "298f7d3c-ba1d-4195-820f-1a8d2b6be0d4",
    "version_id": "1b060071-61c3-40a3-a896-aaa41c49f561"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37249/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "501ff374-1213-4992-8099-b2f62ea47ca6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "276a1b2827e3667a3aa44649692df636274a03f21acc09849614a619d6f61e65"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
