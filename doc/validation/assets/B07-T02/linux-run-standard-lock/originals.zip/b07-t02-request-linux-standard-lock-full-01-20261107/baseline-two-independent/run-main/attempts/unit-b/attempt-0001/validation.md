# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "08f30b6b356ca6f2e2fa57cacec0008f14300576f8704b5d0df328e3eb7378c4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "34ba9ca9d15b96be1759011e0f48093b7a50bef1e0156884682806c51e0341ca"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "eea3bd572329938463911e133658e4b971d0541716d2481af75be01d6a9967e8"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "e3bb54b9d6f3fb5c29ec9b7505f9969be83a9b52d0716fb0d8b354d67705b6ab"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "62da8f62c7d4cf05c29ecdcd4515f80f24b09a30a85c89b9d21665aa594351bd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "77a4b87a02ef47c477d882c493c3dd8329fac86110baae9b20f068a7130c38d4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6944c61a-fd9c-4461-88d5-d66068ce9b7e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4851472e-d950-4d61-a8be-afefd7790e31",
    "source_id": "287ade78-a4c2-481b-ac1f-3c0131c5aa90",
    "version_id": "96548038-b023-4801-a50a-9c83aea512ac"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38177/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9f9602c8-c932-4963-902b-30e9fd083570",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "62da8f62c7d4cf05c29ecdcd4515f80f24b09a30a85c89b9d21665aa594351bd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
