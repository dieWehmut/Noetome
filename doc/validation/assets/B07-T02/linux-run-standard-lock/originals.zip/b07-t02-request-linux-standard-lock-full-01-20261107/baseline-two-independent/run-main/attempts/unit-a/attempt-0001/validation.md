# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c0520742f6640ae0dfddbf95a321d2b6414ce1b1fca4049e0aa47f222603fe50"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "12dd270ff0cfc8add54c9e122c0cb0511a8ac3c8ac4de17d135e9cfc183aa8e5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b9117edacc7e5b1ec2ad94d3ec21539f6887c21692815fb0cc90fc86f1252156"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "be1bb65c278163bf54b0253989bdbe0ef8adcc0b38eef020ecadad85d0f186bb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d6f6f670d262a1df80f397a7a2689d034578fb011ee70cce3ee98613ca807abf"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "640e00af40067db9e72a4b951993bedde7755b3f283b8ef7c1bbdfb320cec045"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "54e39446-5b16-44c3-abc9-026ac0a5f6ff",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4e03060d-b980-4d9e-95c2-16e08a4b751c",
    "source_id": "8f1728b5-f4f1-41a1-9484-510395496ba3",
    "version_id": "5433fc5f-7cac-40af-9464-7b077848eec0"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38177/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "eb37aaf4-c054-4bfc-8007-9eee21e4551f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d6f6f670d262a1df80f397a7a2689d034578fb011ee70cce3ee98613ca807abf"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
