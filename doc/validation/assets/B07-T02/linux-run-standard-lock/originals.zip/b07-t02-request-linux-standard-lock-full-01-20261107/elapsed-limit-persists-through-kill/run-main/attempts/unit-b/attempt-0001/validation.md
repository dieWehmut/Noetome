# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "cf34f366be7e54b1f2f8375f3475b717d0cb3cf4eb323b77496b745b69cc142a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "aeb946b822ac9c6b98d6867abfd212c88d3de04b0508b8411f9377fbaee51163"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e01c8225e24a5787b78385c66872e67e76532df7655ec5c6ac6308f4b7d73645"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "ad9078044c4f33bc2112822ea06992a6e100afd7709f2f161ca8f4810fe5aea5"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3fddd0c672ce7aff5e5f4aafb6d3bdbf9c8ae5fdbb02484355a9726debcdecde"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1e9c4af8c585db1b6ebddc1afaaa8ccfeb6fb08fb37bc0803aee25cdde7b300d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a5a996a3-929d-4618-815d-0eba027d76d3",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "21d5be1b-2edf-4e87-879b-8520d9d8a126",
    "source_id": "1b9b4c0c-4c42-42ba-8680-a242f6d4db21",
    "version_id": "a824af41-6cb7-419c-a6a9-087cbaab0c46"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37061/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0f968a3e-704d-4707-84c5-a1b5744f4b7c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3fddd0c672ce7aff5e5f4aafb6d3bdbf9c8ae5fdbb02484355a9726debcdecde"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
