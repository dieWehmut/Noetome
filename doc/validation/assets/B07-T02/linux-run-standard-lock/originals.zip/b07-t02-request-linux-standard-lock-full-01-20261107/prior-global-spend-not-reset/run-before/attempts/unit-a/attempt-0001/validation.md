# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5a844694a489287f5ca6f376634480ab6c79caea3fc42c9399ad670033e0bbcc"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "6228b2cebce8bcb6720cb0dde4ba370dc264e19c4650f116fe7834aeecda8cde"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "7cbf9519ccd585e0ef883b7b36648ac5b08d1709aed2875685fdebac833401af"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "4791791b89c964d572180a1f93acccb805ae5dbc9ebf18d7b9ed3ce9212b577e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "00454c2e728ca27912ccda982d21582a66a54d74d75299b6ab7484fb627dbbad"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2a9c8d4a3dbba3d4d8b400e55dfeade2e9d3317e8ec3bc32897f0dd3a843386d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8d0a1cb4-736f-4a19-a28b-859584fd3f88",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cc8b9696-5997-4e9d-b551-01b4355fc07e",
    "source_id": "2ecc7fb8-e0ed-4895-8b84-24f60376d8dc",
    "version_id": "7523bf13-b8fd-4b68-ab2d-40984a00d07e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37139/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9627cf87-d8f2-47d8-90e5-9b0f7df80f50",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "00454c2e728ca27912ccda982d21582a66a54d74d75299b6ab7484fb627dbbad"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
