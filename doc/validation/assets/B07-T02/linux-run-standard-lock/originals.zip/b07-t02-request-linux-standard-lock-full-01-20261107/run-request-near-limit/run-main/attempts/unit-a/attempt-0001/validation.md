# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6f1b0bae94a25b0b74853e6e83912c62a508a53be5ee995e596bc7cefee42bf9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "55bb70e97d0343d85be147ed4f84f441ad3a6349a7842033df4e64133de18fc0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9379e767db1d25a2913ccdc964f7545795762108cc7eacaf9366b69940699e43"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "7fe12b8e983105782c6b6cebe54afef756944912c0a357c94af0c118278bf153"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c10d87e85cf2cba75d51e8ddac60355456ca9d82218f4292338646935517a10f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ba84fe1ac8d5e8dd324c0d5ca19a238019a5827ea17fd152381b1e20e8a4b25b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "8957c3e3-e0cf-4c3e-bcda-35421cb2bae4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5a8ca6e1-5d1c-461f-a438-8a18bda3daaf",
    "source_id": "273a3f24-271f-4ee1-90bf-bed3b245e1c0",
    "version_id": "1f409976-7d44-4fc7-81c2-eb17a08aac58"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37613/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5717049d-0435-4f06-b055-7858b1e9949a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c10d87e85cf2cba75d51e8ddac60355456ca9d82218f4292338646935517a10f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
