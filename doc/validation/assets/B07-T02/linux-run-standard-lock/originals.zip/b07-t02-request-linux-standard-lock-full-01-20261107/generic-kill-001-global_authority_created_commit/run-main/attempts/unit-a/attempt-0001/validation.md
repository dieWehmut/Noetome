# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "d8cf648d6992cfc2d6b6fb010fd72518cd1eceb26b01bf526c4262b0de5c4cdf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "90ee68955f361feef3b6f7c4812ac93429f270a2d3e7aa13cee9a6dcbc676774"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a2b6d0fa27a1119957968efa6f2c716657a1386faa091b9d287b3bb4ecf01209"
    },
    "request.json": {
      "byte_length": 2245,
      "sha256": "f6eadfc5be6245a0f491e13831889323294ff30bcbd418e4aef4b5fe2a1a7774"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "67a596d94b00a8a001349bbd42018088d0f077712467da16530e25a7072646d6"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4a62d58bfdd79115b18c6403123057100e396e5c677657251a0b264b1f9537b3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "11689064-36e8-4ccf-b0b4-cc54a7a9a648",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "10bbd01d-b8f7-486e-8f37-2681e11e3729",
    "source_id": "4430216b-4388-4496-8588-3a39533399fe",
    "version_id": "13672a90-5b86-47ce-ad4b-c9f47ae63eda"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37547/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "299062c3-c2c8-4e9f-b12c-7a10309d5548",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "67a596d94b00a8a001349bbd42018088d0f077712467da16530e25a7072646d6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
