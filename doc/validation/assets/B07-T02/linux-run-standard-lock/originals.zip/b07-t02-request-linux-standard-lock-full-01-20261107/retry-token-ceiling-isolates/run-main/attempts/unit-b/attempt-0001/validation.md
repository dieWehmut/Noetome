# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7fe32ece7981a225868fb5682b61b893d9af6110ff589a39a26d54ec673ffd17"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "27894105b01fbec66db3523cbb82508ce355a4d4bc91cde1aeb4f129e5ed3f10"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1fc9a3ea174f89f8e2d27e7026fb88a20515fc64313b86de1357bdd2b87a1c51"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "4d932d74d8021b9ba098ee77a5e4417663f140467d611347a50e7d3181b71205"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e53a15b1f28526ab49bee4ee5daad57158f340381816b036fb4c6ffb4068418f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0bb589dbae56e9556b4b79e96eba4caabd07ad21033faa6c2fa71e8a7db2072b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "cc0ff36e-a064-4d58-bda9-9d3b6e3e5bc8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "4dcdad14-ad46-4709-aa47-24e8ae6b5b3e",
    "source_id": "565cd692-cb9e-4b37-a8d9-b11e3c61c7a4",
    "version_id": "7724252e-dc5f-452e-911b-39998b78f77e"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37075/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "09d30c21-2569-47c9-811a-2a183aaa8552",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e53a15b1f28526ab49bee4ee5daad57158f340381816b036fb4c6ffb4068418f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
