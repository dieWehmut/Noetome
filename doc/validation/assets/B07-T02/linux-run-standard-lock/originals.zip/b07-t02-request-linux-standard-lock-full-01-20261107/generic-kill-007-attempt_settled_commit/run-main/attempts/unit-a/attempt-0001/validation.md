# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "37ae9edf4e0c73af1be7d258585e775cfa6c869729618cf35033599b2aea4580"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "5fab0108f84606f6266be8e9102226309af28a203054663e79022962ca21bf11"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "82ee64e5b6d20bd8e63c5f43599c19296aa647cbad619b3285b63b04c0ab7246"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "39950fedd030752b54d21d820f9a1f2b2f044237f7ae15c32f00804da77c7ee9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "55d62c1cbe0a6f0f1007d29ae004f67b0423e6aeee3a37ecc7c905afb666a09d"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "417d707c8ef6a69e5cfa44d281cf6723fb06fa0a875541ed788f507c848d51b2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f6b46466-250e-4453-8cf3-d0a91b2a340f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9b612682-8daa-4a4f-9797-97fe85e684b7",
    "source_id": "9e39cd04-d0ba-4e3b-a313-a98571ee6c9f",
    "version_id": "656cf131-29d3-4249-9fce-2b7fe7a45ea1"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37753/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2cfd2de3-cc22-4df3-8d83-23113e4e80ea",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "55d62c1cbe0a6f0f1007d29ae004f67b0423e6aeee3a37ecc7c905afb666a09d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
