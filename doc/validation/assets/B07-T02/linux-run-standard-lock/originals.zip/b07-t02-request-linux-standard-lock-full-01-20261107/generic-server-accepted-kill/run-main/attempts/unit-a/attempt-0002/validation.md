# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "295a44d51d90709c3e65a42bb3aae5d5a69f15ef1541af4c8e1706ef47397321"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "698bb3a0ae15a00e079ac64e19881b7ee4a8824527d82cb92f61b5c70f8a1df8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f59b073403e7858bf4d4b1137f681f3cbf143682f389814470f06e5ee3306f92"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "205bc3fa38fd782635479bf989b3cb2fce38ab608cc750183e6e7b7bc8380e27"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a880a8b2d68fd05f7dbb00c423b0d7343e345abae7585164391a029b7c002c1a"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "81072f3c26051abc56066a75033da86a2b0d50fd81ceaf078a7609786c9134fa"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "c3f3288e-ce43-4c11-8f46-dd7f957ed370",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "48c80059-a5c2-4074-8d8d-09c193bd1b44",
    "source_id": "c7a08dd1-1da1-45cd-908d-fbd983c37fb0",
    "version_id": "e9dd4182-dc5a-4987-ac16-5ad02085c736"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37033/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "911508e8-31cf-4c40-a7b8-fddab56d7172",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a880a8b2d68fd05f7dbb00c423b0d7343e345abae7585164391a029b7c002c1a"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
