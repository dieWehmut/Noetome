# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "392545b0c7283e5f72aabbe17c60f5641953226f88fbf985d646d85abf0c77fb"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "11a413a1813323d6649153477a021b2346e441f05525b9ccce7ff7234f5d487b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f9f88dd2825fc3e6ae32a86c5779b2cc61ed7dcdcf120b5cfea6eed85699683e"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "d3ccacc731866e79026ea7afb2577cac6237efac97433b2a5e59ae955cdb358f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9ad8239f98a2d6dcc5479c16d6b300987ac57ff9c994b22d27e2ffe9050324ad"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a24b2a21d74f45ebbc9ba3e6a666b9ca860432dd388c92f94bf7f7dbc6a62538"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "998259cc-84b6-4d3c-ad0b-06ed3628fc88",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fe2a250f-fc61-40a0-b514-c0f64860947a",
    "source_id": "f8a26e0d-dd35-4047-885c-144b40efacad",
    "version_id": "417948ea-0127-4bf4-afe3-879b23471150"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38037/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "77ffc372-56e6-4b87-9df3-f1d8216daab1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9ad8239f98a2d6dcc5479c16d6b300987ac57ff9c994b22d27e2ffe9050324ad"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
