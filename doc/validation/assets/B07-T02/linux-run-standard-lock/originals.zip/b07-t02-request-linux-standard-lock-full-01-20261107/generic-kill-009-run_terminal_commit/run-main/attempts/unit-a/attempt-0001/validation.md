# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "22b225de449c1bdf027b442a0359af3f208e748614aa91bfca1b733f2cdd0cbf"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fb01a6dc0282fae5e5e7ca16b80d438d1228b90aef52ddecfeabc025b9df6c03"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2cf4a98731a50a2140b05d90bd3ce34a86495bed8f0e6222465eff80741dca5e"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "64c007a6e70976ee5ae743ea602deaeae3a18d57bb5a75d0009ead4cb40edfe8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e2a927af3221958e129f5060ead4400287d9c24ca76ca834cb2fe16a1ab4d317"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "db7e05f0bf909354a884ae1e42b352df9df95d385651a4d94910894780ca5448"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "1ab528df-c4bb-4ac9-942d-786303d3d655",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "26fd82bf-7095-419f-be76-e9b76864b165",
    "source_id": "629cafaf-fe63-45d9-9a77-ca78b8da7123",
    "version_id": "0b0046bc-bb52-4a05-a8da-a0d72791055b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36711/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "457614fe-0897-45b4-93c1-0b46697e73c0",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e2a927af3221958e129f5060ead4400287d9c24ca76ca834cb2fe16a1ab4d317"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
