# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "71a8d2458a1c3a13504f2cc1fa7a6f59eef24da4129f83b234af2a41cc8025a1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a5a2157ff475718607ea1feb83901eaef1d41de88c42a587690f5a553a34d5ff"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0fa3805e3a1b3c5afe19779f328733cd8bfed42ed83763f94d98e525942f8980"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "6902a74ff754dabb736a7042c102d489402e5c8448ebd51c8add3e4e57e6387a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "bfe01c682162d0b96711988811f6eb6371e4f78ca9a7cc0fc958e948409905e9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "414a2d8f54f6af912b7fad466b7a499d9a285fbe64f405818fea6a56965c7285"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e9f736e4-884a-46cc-b610-ea2bb679eb23",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "62662183-8f1f-451e-b135-2ce21a77f04c",
    "source_id": "a5b751fd-efdd-4876-ac72-a8eecf8e014b",
    "version_id": "5d226292-8e41-47eb-889a-56646f70d985"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37897/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "132582fd-b087-44d6-a040-183cb71393ab",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "bfe01c682162d0b96711988811f6eb6371e4f78ca9a7cc0fc958e948409905e9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
