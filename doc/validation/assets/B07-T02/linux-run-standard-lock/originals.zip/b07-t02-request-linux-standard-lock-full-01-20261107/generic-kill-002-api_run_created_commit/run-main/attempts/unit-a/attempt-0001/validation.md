# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "52fa2102e1ee7929f28439e16b53e90d875195b3188749d01a48d1a66c852fec"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d713e4ee8dbc11892d20709a33e47264ba8885cc343f3f5b9f034b8f5133e112"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e5f05b4830c7799a5e31906039f13087895b1fdcc8cbb01c9b1489b778758cca"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "551997835441dc37a24e44bf9eb53cf2b991167e33c6d5617a2378397b36b37d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3c0b9bce232149240d71cd77e27bac5cba30c4343c72e706ef405797b6e26265"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "64c481f06e2612f1db8876d9a1a552b9b7d694335229a7aa35f48173c2430a49"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9c5dec65-5cda-45c0-aa58-7e0e271a7cfc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "e95783b5-421b-479f-9062-3778171914ed",
    "source_id": "68f163b4-e257-4a7d-a4db-4dd5ad543162",
    "version_id": "1b8e2855-6cb3-4002-b3fd-edf611adac2c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38039/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "27c7e643-331c-424a-8c44-7f840a1edfc7",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3c0b9bce232149240d71cd77e27bac5cba30c4343c72e706ef405797b6e26265"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
