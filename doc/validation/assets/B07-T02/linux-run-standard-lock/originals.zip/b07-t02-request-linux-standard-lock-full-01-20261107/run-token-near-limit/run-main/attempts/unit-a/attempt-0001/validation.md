# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f7a1761f107f7d88f1e2dbe2a9aa4696ddfa49dd45ffb0cc510b20e4c4086cc7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "783e5eed819a3e0de6dee97de1b4f0d9011b771673cb6fbe0bcd78f13f50f47c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "22b2c980e1cb327de1e1731a0e7fb8482c9ee78d403f47fab9478dcffbe91cdf"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "5d4799c415d05c6f54348b6abe54d4e7c4a4d5cca7551321be56b10b81bc4126"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b4f0e7171f7e252aecc8d9b4d53422b0794dca07c83c11819e2c933b0e338644"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f4a891ded9bcf93b40d419bf604d38ac51246ad587e5ac2d4d781cb8479852b4"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "091b02a2-31bd-4fd6-9dcc-a03b54ab8075",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fb482732-e307-41c0-9a20-4815cc9c8bdb",
    "source_id": "bcc838b8-a6e3-4407-93aa-d91234995137",
    "version_id": "c439f930-7960-47cd-b89e-e54bcab7ab71"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37723/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "368a8268-9470-40ae-a862-c0698e3fdd57",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b4f0e7171f7e252aecc8d9b4d53422b0794dca07c83c11819e2c933b0e338644"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
