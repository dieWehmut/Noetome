# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1a361223fd473ed451a360ad7d76b85e971c646043007a6f991fdab456fd6fde"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "e553f981be9828b2ccc7e673e09c072d83474c2c5a088cedbbeab0ed3c84d791"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4c48ce411bd178d1c925e2ec39730c6be3193e486ccb60823e2165327c4af428"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "ee99aa85737b9b964792e6fe487ddda512ed8614d6c1915e3a4ec6963762d606"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "793ffbec43244a191202fccc934389c9154cbe834122fb2a90729ed08a82ec63"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "36b84dd61bbb807363224514bd45092c0eabcadf7df90f56c2c5bc76037ccc94"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "35c60e49-4643-416a-8eb3-32a2d1e3e240",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5c5205fc-0d14-4a58-9718-b2042f560460",
    "source_id": "2dd1ee82-5e13-459d-94c7-380af746ee29",
    "version_id": "9c55ab21-752f-476d-9446-362c60a647f4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37101/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "19782c5f-cbb8-4ac7-9630-bdad0d3f627a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "793ffbec43244a191202fccc934389c9154cbe834122fb2a90729ed08a82ec63"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
