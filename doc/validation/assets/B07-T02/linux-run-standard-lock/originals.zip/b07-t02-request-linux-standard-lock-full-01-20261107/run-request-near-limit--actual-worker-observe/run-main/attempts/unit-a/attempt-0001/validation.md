# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "61a9427bc01754af24b8c53602d702cf780226f9c190d9eb6a39c053732b58bb"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2ee2900cb00266305500e2996614a88964d91c4cd06f92dfd023c836051464bf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6447218a16c19b9afe4e0c125beed526c24df6dab264c3f30c606048c3099a03"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "ed76b53b423c3721f5e0123b4089d36dcc62b670a50fd05c1bf7d7fc56e74636"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5f2d768d95ec5829311cc3ae126b3f59361d85764a794457f785493963fc6af5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4b391bd4d797a1b6d5d5e53790c7c3157bd20615f4c38a5e0f32eb6c7d31009f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0b3c872c-8fd5-4582-bfc7-b25f62712b82",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "440fa087-5ab0-4f45-8ed1-28bf807cdcce",
    "source_id": "f7234b4f-5b89-4924-bad5-bc893e09c2ea",
    "version_id": "652c0098-ceb3-404e-92b4-cf17dcdb1030"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38011/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "be732c41-c0af-4c49-9cbd-acc68c48e74c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5f2d768d95ec5829311cc3ae126b3f59361d85764a794457f785493963fc6af5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
