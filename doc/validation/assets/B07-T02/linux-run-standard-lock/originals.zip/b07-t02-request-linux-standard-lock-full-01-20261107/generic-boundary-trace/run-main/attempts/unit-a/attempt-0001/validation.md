# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2cead2935c7d354b7983ff58324adcaf13c8b9f60e4d8b85d1c7a26ef74d9f21"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ad34350638908ff526af4d79e23833a6dd7e308f68c1945d9d1ee1a09edf9008"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "18955f72ba6df0174828037382145f9c8c06a19b5d0ede31e2841ee638c646e1"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "640686670eaf86477c5d67a3c191002ecbedf03c136dced962327b4b1a97fa8d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ffa13a696e575f4d4f91ddb12bda1b435819787071747d2b02749fd6234af118"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8080d56749920dca49547662a3459bb454246da3429efddbb1bfb36d01a9d36b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "db91999f-06ab-4bef-b5cf-ea9f3604a147",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "82fd673e-d4d8-4ba2-8a54-8a9d3c66e13d",
    "source_id": "2d2f6130-6289-4ab9-8c9a-269954e0c8bf",
    "version_id": "0128a50b-314f-45d6-b07b-64dab64c20ce"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36811/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d9d11eac-7cc5-4104-85f4-ca327289cb3d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ffa13a696e575f4d4f91ddb12bda1b435819787071747d2b02749fd6234af118"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
