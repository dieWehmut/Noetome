# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c9dbdbe030842b62121c182edfbbc0dd0e23acd065b8b2e7677f6f3c08c0ffb1"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "03009ba8d25259498d8314958760b127afcea5587a9c01fcc96efb0ed4f2907e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1159d7f0c67021cf835d52821dbc0943dafd314b5b22ee456f8ba3684a274165"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "2421a4c385fbff917aabcbf863d10534f8e2db32cdf4e69362858420204de017"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "36e20f7afad0829ae28c4254f20ef64cf2cda89b63200001962309b6a6719b67"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "5277dd6cc7fd4d2587419cacc8143d82fec5ed391c71b8c9c65c4502f7d3c957"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "d7a0ed26-4ac1-4c33-9530-d9c380907bfd",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "9b79ddbd-cea0-41cb-8ba7-e91a97660f48",
    "source_id": "df8e5428-7d07-4b30-93d3-03aadf6cb801",
    "version_id": "b415bc45-e25b-41cb-811a-1006a894e900"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36499/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a6cb7624-3cc6-45b6-b28d-a7cc73ba6c06",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "36e20f7afad0829ae28c4254f20ef64cf2cda89b63200001962309b6a6719b67"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
