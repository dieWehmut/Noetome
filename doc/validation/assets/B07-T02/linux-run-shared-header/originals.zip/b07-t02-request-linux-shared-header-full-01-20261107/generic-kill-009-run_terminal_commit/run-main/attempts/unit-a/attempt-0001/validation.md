# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2414e7f89f53dc8cb6ee52099fc98be04f26c4e9f287b15bad52b053a4a0c215"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1bb390d768d9be497ccaf4ed2dd6bb38e2212f560ecf36b73f3f17d0807b46e1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5c181de5ad6464aaf7b22764630faa00515aa549f33ac98123ad0abc807065e9"
    },
    "request.json": {
      "byte_length": 2233,
      "sha256": "3c54ff47a2cad838f5a6e64c365f0d27e24cbb30c2cad11692d885967ee74669"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "be3b990b28542b98e38286cb87d4ce772bc4b8935d32ce87fbf1b871961d89cd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "624a571448e5997554fa9d1d8c8d87544904cd5f87342538e50cc7aad84e905f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "14d2f731-47c8-42f9-8532-39eba5681ab9",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5e2c3b68-6230-4202-8320-3503488a60f3",
    "source_id": "a5ddbce7-9c06-4a51-a3cf-3001e5e53290",
    "version_id": "d02d2dab-cc44-42a6-8953-6cee2f67d403"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37219/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "de59c9b8-174c-48ac-86e3-6c76f93bc897",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "be3b990b28542b98e38286cb87d4ce772bc4b8935d32ce87fbf1b871961d89cd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
