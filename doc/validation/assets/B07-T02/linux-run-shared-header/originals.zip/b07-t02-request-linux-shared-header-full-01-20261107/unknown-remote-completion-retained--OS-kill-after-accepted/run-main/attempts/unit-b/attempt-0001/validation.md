# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bc3a7bd0f0414e5e0fde938b205a726f59c6c2b912f8558c3f3190bb2f5a5cb4"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "234c54bf8803142ee729dfae4e66d4e6098143974d5e786e622249097dc7a3d0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c10b1de77ace0d36fc203432a7a02991364ed5293800d7f4eb23cdd8c85a802e"
    },
    "request.json": {
      "byte_length": 2255,
      "sha256": "cb41c3187db13b289a8f28a56b7577bfe3b3c89edea5e8ecb55be54a3a854b00"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "66803713465295365b0aa662e564aa1efd672652b4f6c3a9f0f249b0469e6ee0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "fb8b007f91580349820a6904fcf415af96cff18cd3cbf88a43422fd17cbd75ff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5dbf1c52-decd-47b5-91e9-775fa9ae8a20",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "246e0719-bccc-4dfb-8044-c3ae7d61670d",
    "source_id": "b4129ad0-838a-42be-b607-e95255ef2d47",
    "version_id": "e72cefee-b39c-427a-8874-88a4a91bfd20"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37953/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "1326b4f1-0436-4e47-b3b5-fe15f86f651e",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "66803713465295365b0aa662e564aa1efd672652b4f6c3a9f0f249b0469e6ee0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
