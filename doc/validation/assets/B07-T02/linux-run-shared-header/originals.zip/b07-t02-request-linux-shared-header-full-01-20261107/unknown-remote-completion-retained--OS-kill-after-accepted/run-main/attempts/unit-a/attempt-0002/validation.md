# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "07ee2876e010b22814e484308faead4a23a0e4241eb1b0e8f62cc6d3d0966e5a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7a29856984d7393974e2d2f9285140b1fee15ee6d5227def562f74433fa151eb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2efec7681514aa437f7922cade29fa22d9410f0838759ffc278701fdd09f76e1"
    },
    "request.json": {
      "byte_length": 2255,
      "sha256": "a658231046076c2e01f428884561af005bb4120555e96ded500ea1edaf77e4aa"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "654212d199303ae38c1dac0b48cc9ed3abb58dfb002648a14880f8bb8ed82a96"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "9373a4de1ffeb56c19c00f82b29ce557c0d8f2f50431cdc67c9b37ed0f2fddee"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "632f73f5-bd67-4731-9beb-5baedcc8b803",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "cb888ce4-728b-4319-926b-467d675a0f16",
    "source_id": "3d90894c-ee4d-4a93-9f03-cd9d8ae80596",
    "version_id": "116f1d04-c58d-43ad-990c-4798c34e23fe"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37953/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8dccc6d3-534c-4e52-b340-695ae56e6103",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "654212d199303ae38c1dac0b48cc9ed3abb58dfb002648a14880f8bb8ed82a96"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
