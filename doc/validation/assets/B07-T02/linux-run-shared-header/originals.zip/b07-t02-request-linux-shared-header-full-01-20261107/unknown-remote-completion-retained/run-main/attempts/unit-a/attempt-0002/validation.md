# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a5d3995198ef6ecdbc4d5bed10c95f23cbe94f760b0f68badb0c081158802185"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "782865c5f30474e32d6187a6935c0cf88f8805f7a3398be4c4b0b2de75879d79"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9f57156aa67b2a891b48f8c79a06eb0ef7de4319c6c75357f2c978b2cc41995e"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "a5721e32d4869a7f316fd0fdcc59ef4d2f101b2ecaac8ae35946c78f890d1365"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "e62c41a51df18a58b635c75778e1218e789dab8ef0f0fbf28fc1876c485532e2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1f24c9abfa62c46e7427c203cbdf746038f1c53336bf0402034f8f335a400746"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "470275c6-d0df-4f12-a457-a24742b04859",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a799cb61-b932-46b9-8e43-e0425abfce81",
    "source_id": "de7446b4-9b12-4de8-9a31-7b7be3670baa",
    "version_id": "96d51a04-c7ff-442c-ad5a-2d1a51f44b72"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36443/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "484cc22b-5221-4f03-9e4a-8381d3bb4d80",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "e62c41a51df18a58b635c75778e1218e789dab8ef0f0fbf28fc1876c485532e2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
