# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "046a60f28371bbfb5a6ab8a78979e702e3371d35e494c0988f702f2b08b93a4a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1143b1766780beda4b896fa6e4c640299d5fd47d8f37b6b244da712686f0bb20"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c4c9d1b3176554bfcf83eea3a50bdbeaaeecceff9336598a75d9b1145064dbe6"
    },
    "request.json": {
      "byte_length": 2231,
      "sha256": "4490f4fbad36b277fdb62e6706323a803e8888203e1549570c1c677cb4082dfd"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "07a805b89d919b5333f5319d23e7af8024b1a9e4021f03cd4b7159febcc83e73"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d2b760503bcf78f5d7d1adef62557160fb474557bef3935097a01dd01a6d6187"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "f652b775-df3c-4b78-a19f-b2b32b513173",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a7176664-7149-48e0-8cdb-0d8e539d70b3",
    "source_id": "f0bb7563-755c-4161-a569-0c3feb5886aa",
    "version_id": "1910a11b-6592-448b-8faf-760c4c639156"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36443/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7c05d9cb-88e9-4077-8930-97b4a15266e9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "07a805b89d919b5333f5319d23e7af8024b1a9e4021f03cd4b7159febcc83e73"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
