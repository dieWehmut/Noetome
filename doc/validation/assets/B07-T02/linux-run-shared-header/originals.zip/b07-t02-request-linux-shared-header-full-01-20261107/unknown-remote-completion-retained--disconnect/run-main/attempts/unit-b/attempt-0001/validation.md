# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3557e56119a85d35750b1f5167842fd664fc7302cb5f824fc8cd34957b3394f6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d5becf664a2716798ec62745f85eb0374451bea9febb3bb05ecff1530070d388"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9d46be82f945fcfd74cfd6d9de50112f1252e4e60742d370e0ccd4bcb8eb3052"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "989f38270e0fb51da3a85e76512b2b912155c8f88657988abbbd21dc6e920e4e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "65641785fd16fe47c33059ceefcebcdfb983b1b177fa0a9c4f8a1d332c132ad2"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e79b4a45de7162a953a995f1fcf445f31609d1ab925245720cc0234b61a9cf59"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3d50e9c6-7062-4e26-95be-d92dcde9181c",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "a749c726-a93d-49b2-8155-4eb21a9e7cbb",
    "source_id": "918ebd5b-6420-45d8-a198-94bd46f0e76f",
    "version_id": "baa166de-7dcb-471d-9832-c90e02832346"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36663/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ead6492c-9751-4199-9c9a-f7a637b1c33c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "65641785fd16fe47c33059ceefcebcdfb983b1b177fa0a9c4f8a1d332c132ad2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
