# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3a42b52598ada7397096d4e7f130c096b180036252e64052df9f3f3803870118"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ccb46651434ae81e9d635ebc1088d9843fc43727ce4750898d43b26ec67fc586"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "3db762edfb42b07abf073ee25ab96c355de1a58c475077b8c568d470bcde5ac7"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "c1a4baf37b192ca0bc84de0ea3d06c5c264a0e0d9358624e1cd0815b710af41c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a2d73461aa4362d1fc6bfbd3e9ccc66ba5ebfa2576f037076a647e5802b062b9"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "a12ecb81545e204ac6aee37537ead249ffe006d4c10d8d2009557f7155a52b2f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "85b5db2b-730d-4a21-a3f0-ddf26de0a0ec",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "469969c3-4d2c-40c3-9e9a-55d19910a3b9",
    "source_id": "6285b20f-eb93-4856-a269-947e88b65143",
    "version_id": "168682b2-8aea-48e2-863d-82ba513d6741"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36663/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "208aa10d-75f7-4f3d-a0f5-aeca6a3f8a12",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a2d73461aa4362d1fc6bfbd3e9ccc66ba5ebfa2576f037076a647e5802b062b9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
