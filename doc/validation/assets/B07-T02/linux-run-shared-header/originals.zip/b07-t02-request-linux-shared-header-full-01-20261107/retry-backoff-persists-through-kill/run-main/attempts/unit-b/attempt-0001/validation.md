# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c0ab66a37c6e3add5ae1fc719f84cc2379e9399dc52eb43abc4becde2fa3e239"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a86d57672d216ce9632ea8b9cd9ed05472b2d9f98d7f403a961c0099d84df45a"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1505eb4ac4e54fa96bde810135636fc72536915e4e33e948015b5f1e6e524546"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "ee87d946ab00c1d3035333fe41b4fccb19198e48a43657b2c38a71b434af8080"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "4e2f738098ef19a816bb2effc3ac417d84254f2f7ddcf6799750aa9a4bf4a2d5"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "55f7f20a4b9d9c4b8b793870b831071e2d4f6c1ce79edd5865650c8e9359f36c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "72401813-2734-4a4a-ad52-ed4d4627e260",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "05b2dcba-5aa6-4d5d-b125-9e6fa8b259e4",
    "source_id": "a09b6de3-ac12-4f9d-bfb8-7d7e88962b7c",
    "version_id": "97d0f3a1-f3d0-4618-a882-b6ce3bacbf2c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37965/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "26811b0d-758a-483b-862c-b0c8670ef059",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "4e2f738098ef19a816bb2effc3ac417d84254f2f7ddcf6799750aa9a4bf4a2d5"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
