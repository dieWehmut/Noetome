# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e48684603c4ce59871a667efe3712ed6663ea27418e0a2245a0d56a2dc8985b0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "f88cc7d612d15f6b89779ed0d784a95d901982bc0e88b908a63ae72ce1e011b1"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8bb40b82c27a8c478491edb2e85fec0caef17a5bf644b3577b9f8643840fa996"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "9ec7383b20f34af0a26bf890e27b60ee65c83359de41a442ad2afe8b7decf96a"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "309b546058e958749baa31a68c4d4b3fcc2c879e4a95205f44383ae06ce6b134"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "2c625bc12e8e35fda77dbcd187b241bb9d21f0161ba311ffc51b961c0973d45a"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "995a8fad-656e-4010-b585-841b452d0598",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "432a05d7-a313-400e-805e-a3341ef7a3a9",
    "source_id": "95beb354-114e-4ffd-add7-5aa2836f9a75",
    "version_id": "04ab273b-3cb3-409a-80ba-7306aefc7030"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37965/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7d041fc4-8b08-48fa-8b24-9552b994fb62",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "309b546058e958749baa31a68c4d4b3fcc2c879e4a95205f44383ae06ce6b134"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
