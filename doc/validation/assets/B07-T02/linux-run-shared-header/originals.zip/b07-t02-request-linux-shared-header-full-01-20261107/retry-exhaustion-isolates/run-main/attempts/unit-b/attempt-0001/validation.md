# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "18a00eb958b1867c8a4e2086c106dd39c506b26eb7755c2e9c611a8b32dc18a5"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a70e84772df675de35b633c956f761c31d1969b0cb2c407e018f6f04e7be8e9e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "1dd918e62a730a36617c5ae615206c4f074cc103a34ca4d1463aa9bd2fc2a6ee"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "86ef7ae3c10a577f36165170bc7dc2c297d7aca40d88962e9e6bd31b34a848f6"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3b08a850dce0a4b62fa702332f096880c280126fad157ec6d72ad63d8af3a5cf"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "4cedd2a80cbffb35e9d25fed26da4ae572210b2b6ca2731de5caf549ab56b61d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a3335063-23b5-4958-96f9-920d31b68995",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "1625fa9d-bdb8-4288-983c-fa209f4414ca",
    "source_id": "0e07715f-4a72-40ac-b3d5-5c706fd566b7",
    "version_id": "018c256d-6949-48df-93d2-f3d43ce61c25"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37583/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "6131f5b2-5708-43f9-967e-be4b8d3e88e8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3b08a850dce0a4b62fa702332f096880c280126fad157ec6d72ad63d8af3a5cf"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
