# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "82da59eec003ca398a85e71fc8ba08a69258544417bad63a88a763723f4bcc5a"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "897cbbe2807c56190ecb2b8258daccd1276bbf4013024e0c0ac69074ebdd98a5"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "70f86dbf26d64ef03f4459d7310ca04bc4b199736b9244982fdec853f7136696"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "d7af27098b744a04b8c9d5e6814c5b92b57179a77ba2c0dfdb9a2c45c6b3e38f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a647064a040d0b1f52e78ea650a2693ffa9101ec383ae9c1b29b742b6e7281bf"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "3e837bb1a58e2353915de07253e6846fe014c10dc0fd723da7e92ab299e5077f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "56719453-27b6-446b-b1f7-b42575d05d87",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "eae8148b-1949-40ea-97ef-053e221fcce3",
    "source_id": "10bfcc34-00af-4445-bbd5-e6b9f187c6d3",
    "version_id": "bc81e112-ea7c-4beb-96c8-a4cf8e6879ec"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36699/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b39b2fec-7282-4e61-b71b-98e3a558caff",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a647064a040d0b1f52e78ea650a2693ffa9101ec383ae9c1b29b742b6e7281bf"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
