# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4df561069ec2818a880f55416077b262678105564e32dc4e8e271e55ae40df2f"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "23f82182d6dbd993a767acaa18d8234360fc6b65c25d1482bd3f0fb9c35e433c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "17912976ea0019f6938ff18c772add86a581efe2f11b365f0849791ccd32b8e8"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "6347e7427d51bba23dd4378355a6df8502601b8e74e94eb9eed80895161b7927"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7a00abd60be4e13c5b6c2ab0439cb2645100bb6f169a0919530202960b62d830"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ccea3fc8ab7a30b7fcccbe9233881c2ac6d0b1eed3a5c592e6bf8b3fcad32904"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "6d59e8f0-ff97-4cf0-abde-0252b2c02286",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "fd1f2cc7-6a9f-4fb0-8e73-285481b51dd1",
    "source_id": "edb3bbe0-6d25-4a4e-a615-1a9c27948480",
    "version_id": "829fed2f-e485-4a72-9da9-6f7afb49e927"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37333/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "cc002cba-fef0-4289-8278-72c0976afdab",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7a00abd60be4e13c5b6c2ab0439cb2645100bb6f169a0919530202960b62d830"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
