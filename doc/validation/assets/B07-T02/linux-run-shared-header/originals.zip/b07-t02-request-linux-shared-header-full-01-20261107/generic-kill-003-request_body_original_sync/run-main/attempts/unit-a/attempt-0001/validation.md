# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "44daa184c4cc4e8c9b139b41e44deaf2379f1a6623e095f26e8e2461a7be8709"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "58291a70d8c39f05b7dc70b1f52732458065b406b764a4ec3ffd79d940ea0625"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "737e80f4ad41067be5d7abe6d525aff5ce597d9fc9e2ee09e003e0328bd3e864"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "6c4e78d302ddc11dae5cc6dafa9a85467eadf45a2aa31f08d2fa504f21ba3bd4"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "3666c5e5d3b23f561ff8d627bf8e9a6428d4527c6609a041fa1f74beed894baf"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ba276d05b134197cba02c77ebf2343a15c1e9a4cec90c64f96ecc0b76d03a45c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a4107670-ea83-46cd-8686-ec051bf13ed0",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "aec2f20d-f1ee-4fcf-921f-3ebc241259dc",
    "source_id": "1ef7aef3-842c-43cd-8b1d-c1dbbc830761",
    "version_id": "371992a1-597c-403b-9d45-3838280f8610"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36791/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4fcd3ea3-d450-4df0-bed8-5bd467aa80aa",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "3666c5e5d3b23f561ff8d627bf8e9a6428d4527c6609a041fa1f74beed894baf"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
