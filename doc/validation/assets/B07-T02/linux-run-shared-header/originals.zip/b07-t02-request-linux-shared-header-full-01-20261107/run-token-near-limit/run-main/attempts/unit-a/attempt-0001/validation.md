# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "49d132efc71715efcb84febc7513d00bca67c3bca9db6d7840375fd7602d7c43"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "042656618c82f83a940ae418e98dd033bb45126478652d797dbd1652421c9d73"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c10675a4105571666f754f708b50ded5ef3777621f1460a1daab658b2ef17a15"
    },
    "request.json": {
      "byte_length": 2217,
      "sha256": "3cb2850a2767ff275b60e481ffb6a5c0dd7d7578c285cf814d03a4ad9d6b069c"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5afdd6ec4543479e507a9e6ad5e24c575e00a7202a5decad2cc7fe559e4b4e4b"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c42f2419032d20f0ce7b6224b29154abeb5c4ff5faa1b512b70c16b29daad470"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e5da6152-0a40-430a-aec0-9578dca41d16",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "da2910df-43d9-4833-8153-d0eb33f7f34a",
    "source_id": "2f9e1761-336b-44fc-bfb4-eb989e496c13",
    "version_id": "b39f0623-22e4-4595-9897-26ee598f38f3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37843/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b915e4e3-c6cd-4d75-b20f-1cd7a41d4557",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5afdd6ec4543479e507a9e6ad5e24c575e00a7202a5decad2cc7fe559e4b4e4b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
