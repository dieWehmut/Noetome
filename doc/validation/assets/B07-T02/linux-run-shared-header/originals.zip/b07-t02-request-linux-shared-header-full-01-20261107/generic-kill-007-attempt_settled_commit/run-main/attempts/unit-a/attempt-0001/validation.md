# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "99126e5283448da7ff8005387e54bf9e41969d0f245ebd59374fe274c2521b1e"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "d10c299074b63a8ea0b3894f5d6f967a87ded6b0656a1235548199913f31acc6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8134ae733887b9daabdf9f5246bf27cdfe525426c7a94df7de745f0e568b2082"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "942b4a37608f8d1a67f57695c28f6aa5bcb17b96a316aa9cd82fe323105f3b23"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "34f2253327b409dcc8571be3c8b8f330d6be7a976370fc5f0046bfd811ae14db"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7ba8169dc0c152455182e10f684c712d589f33579d312b45b5518b619d92af12"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "7885f3d0-85d4-47ca-98a3-0b4a6a45f8ff",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "f32befbd-c6c0-4ece-8e43-89423318deb3",
    "source_id": "c1dd4f56-ce84-4c23-9849-871d8fa9c46d",
    "version_id": "f1241317-67f5-43a8-b6ff-f6183868a3cb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37801/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "14ea3590-118d-4b5b-b546-b9166626d500",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "34f2253327b409dcc8571be3c8b8f330d6be7a976370fc5f0046bfd811ae14db"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
