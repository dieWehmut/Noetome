# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c5ff712f856c90970eaf1c8d43cf5529975d25a8f4a922e8fab91c2c89df9c29"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "15bfaf435136480e6af6603d64e9470e4d4374e30854e96c978c995c5f7b85b0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "6abe6b6e4667f05c0916c02028898af143e43445fc3d58f78d3178b648bfca1a"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "71dc4ea5b103a4a968e1292d24e410cb5635d1179b2afdf2a9b48fa101b52f7f"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "32bd7a5f83f8c2e4c63fe39be3da3d76215b60490f48511f865b59b7eb6dd23f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0a97d9b1bb6c98dad6eb62566ba3e697c1b9db320698da8dfa2940ba073dd0ab"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "3f625806-ab59-4229-884b-2aaeb8964f78",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "ed136118-346d-4c70-8572-cae08794ebe3",
    "source_id": "32ff6e1c-2f69-4a3b-b45c-b82165c23c6a",
    "version_id": "0397c906-9407-4f49-96c1-14d136a1f5e6"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37573/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "69da9f86-7d28-4ff1-b8fb-0340b41e624a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "32bd7a5f83f8c2e4c63fe39be3da3d76215b60490f48511f865b59b7eb6dd23f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
