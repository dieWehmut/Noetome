# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "35ddb86a52a71419a91c3c0b5fda2eaba70621f590fd161541c4dd9602a9fb9d"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "1a2ab4280340ee49953d571230905f69ab5e8c18e8b0afaee2bdd59ddb5eb57d"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "c25dc5caecafc48a863505c74740c7adc59690974df872f719b41eb342765a1e"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "219746ba48a0b8e4eb22d9ba520a4f6d97a20137238e8d3caa033928f99e8890"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b85d922eed81988d719ce0cf5d55744500957dcce1720b1304d3e4354abf6c4f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "c8dd1c690ef6a8411688058eb0ea982184917efe16e7326e2951ed3c6a29aa0d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fffb68ae-6c16-4913-a717-82ea9e9f2309",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "984d70f6-e405-42f0-be0a-e2d6cf1e507b",
    "source_id": "dfbde090-01fe-43aa-a6f0-9130f150f52b",
    "version_id": "f0ece989-4ff3-4288-a956-595a37858876"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37573/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f2a4065b-0b19-4257-83c1-5badf03140dd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b85d922eed81988d719ce0cf5d55744500957dcce1720b1304d3e4354abf6c4f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
