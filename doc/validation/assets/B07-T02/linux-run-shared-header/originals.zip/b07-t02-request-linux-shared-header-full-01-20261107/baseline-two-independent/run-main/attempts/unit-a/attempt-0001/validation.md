# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6138056084e4256a5ef842005ea3fe4cb3c48d9ee150ac0a1864f460cbfde9d9"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "ca8dfb73a36485a822e5ae889fe1dcc8d1e281e38d6bb00c4f5140ded26ef9fd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "48b3d68521316e91653b73ef1c353dd248e00d5d68873ce18e377cfa836dbb47"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "2b5ebed391a275d32feb664c75478efad2f275c6a58c0cae3cc13e96586dea14"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "abb24b4f4ee32a463cc172faecec0ccdb86d0c9b7ea11cf2568be5d6727aa5ab"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "19a2063408f47d369cd15b03ae624a33acee86d7fa01ef4e6d77219976324b76"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "0563c9e2-2c93-4de3-b7b7-5447a0cf17cc",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8d1fbfbf-ca43-40a6-b3d6-41f7f379a2ec",
    "source_id": "cc3d8a0a-e3fe-48e9-9491-53012b6cfdbf",
    "version_id": "96a889d5-2304-4326-8bbe-6cdd555a189d"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36925/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7e7ccaee-6b29-4cbf-9db0-d6fa19b22f3d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "abb24b4f4ee32a463cc172faecec0ccdb86d0c9b7ea11cf2568be5d6727aa5ab"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
