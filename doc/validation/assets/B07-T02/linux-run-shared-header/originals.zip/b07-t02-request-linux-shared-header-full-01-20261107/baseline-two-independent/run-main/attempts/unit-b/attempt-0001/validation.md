# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ffe082ac11747c7faf9f259a9c9701554af116941b149dcef694afb16237854b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "2faa9b1f44b744d743e627654a89aeba0b135f595fd9762db05328c137484307"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "5e0cb4b1705f3ed34bde4b8bb131c6a42bff4bbb4a075b072979b4465d2866f5"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "faf20bf32eeb1370db1615c345b1a361b9fa7a9c3fbda80d7d7944c23d1d7f36"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "1ad90adee7b4ca294a91b748cc6edad55550137ad11860dac9da2131562899dd"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "642c8660ff0272924b2b35ca81e95383c80d282e831af983a24bab1ab9be6138"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "480144bf-07d9-4f84-b825-b0920d167252",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6d555e1c-6aae-4e92-86fd-8ebfd6c3c827",
    "source_id": "55fd148b-a618-40cb-a473-e9e195794f04",
    "version_id": "68b3257a-1019-4faf-8518-4865f30346ef"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36925/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b328eef6-4e87-47ed-aeaa-ba38f72bd618",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "1ad90adee7b4ca294a91b748cc6edad55550137ad11860dac9da2131562899dd"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
