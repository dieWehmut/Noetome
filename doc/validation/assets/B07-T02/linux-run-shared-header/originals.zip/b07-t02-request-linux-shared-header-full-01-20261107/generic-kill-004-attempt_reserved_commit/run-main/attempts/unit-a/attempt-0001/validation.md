# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fdf9981f4f5d98727c61c2bef255643cc49b004aaa88948f00ee02788f77fe9b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "a3c5713c14762cd0ec29c8990b710ebc1777844dd9456c5dd06ba75e3755c8b8"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "cdaf7979ea1be90dc3a97dc3e22a4f494b58bacbb2e544bfc594e8071f12f2f0"
    },
    "request.json": {
      "byte_length": 2237,
      "sha256": "165dafb1088cce2e757d43f30edfa517ca5ee40d13271b66555dc2bce2d94be3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "2f6ed866ca5da51a11da4ccf8c32c9828707601892ad1d8be3ddbe1267159ba0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "b928b279172c2467fcd24e3918badaa7724b0db15b6545470acaa0caaf2e46e7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "77bad2dc-9b57-4360-b5a0-2142181b7e15",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "5ef536d8-356b-4f45-bdb5-766a625a9c49",
    "source_id": "02f704e8-1840-4a62-8ba9-cda71104f981",
    "version_id": "04de8ec7-7735-453c-9907-6f09ba1816cf"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38119/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "32746e44-8b4b-4279-959b-505c76cfdd88",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "2f6ed866ca5da51a11da4ccf8c32c9828707601892ad1d8be3ddbe1267159ba0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
