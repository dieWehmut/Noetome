# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "c21d0a9c0ba33c20f7aaa09ad7d072dff9e2f04bf098978373391b85ad05221b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "31750d154854e85bda36b0df0c94a4a9f597f399bf13d11b6b54301fd599ac59"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "40508126db52745479e857a73a08151b2ed9369f7bc7e851fffe33037a864746"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "ae9590f6440975f1321aecdb3bbe6999d71ba5f726d0f24b71c4edc4f70b29f8"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "8e6880de3d8195a6b54908cbf5091608fa942b1516cd74697cc1780c915f36aa"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "0e7e1f83991b6eb3fd61c537b4547f29f4797fc3eddd52c65ad97466b18596b2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "ec2507c1-07f9-465a-97c1-03e5d4dc8291",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b35c07ca-010f-4cdd-b60f-672156e350c4",
    "source_id": "890d6ad1-4e1d-4aa1-9d47-008fe8eb99af",
    "version_id": "35424b8c-0ba0-4d60-973d-35e9e09ea088"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38475/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4537a620-8ac6-40e0-829b-4f1bbab15388",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "8e6880de3d8195a6b54908cbf5091608fa942b1516cd74697cc1780c915f36aa"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
