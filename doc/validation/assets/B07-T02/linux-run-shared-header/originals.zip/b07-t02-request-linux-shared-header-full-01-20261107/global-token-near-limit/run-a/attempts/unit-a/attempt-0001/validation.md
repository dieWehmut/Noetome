# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f815ceace0eb456559b9085e07fd0459daf0a606fab1bca6e7f6cb381872ab68"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "b3a56a8e07636a54bd5f43b75e0cc5e956a62485d7d6bb31fe8363c04f1f1395"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "9910ad5d86af3b30e5eb471acb8dc084789b2ebaa0818d406cdd633ff0c80121"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "d5f9866b64d7b27c3b51a77cfa26ae37e12a0affcd3c138571b4d2aae0330577"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "672834d9453a29a929d864d152883341f888faf3330974cdf3190fa103607320"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e207c021d234e3f63ce834f9e02256f5e0eb4cd7bda502cd7fc80898b2b25437"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "28b2ff43-4891-4bbc-859c-30e24a6110be",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "8b8a4cf4-dd23-4009-9af0-3a499b4beacc",
    "source_id": "d0cbd6c4-defc-4469-9b48-5be965b5e867",
    "version_id": "36ddde56-d497-4790-bf41-ebb6b6367622"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37011/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5485541b-629b-488e-a06f-4f7a7e01011d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "672834d9453a29a929d864d152883341f888faf3330974cdf3190fa103607320"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
