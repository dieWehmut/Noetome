# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "84d405e0317264a8908f7c4a64e81cc3d647bb3bc143eadf167d5b145433ec4b"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c21f44f98c13c43d66b164b715e2ee7245a00fabb5f8f7e4c8c2b5763bd54ab7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e342067e700e714dd716792f838079697dc4278b69028dcaf9a434047fd754f3"
    },
    "request.json": {
      "byte_length": 2216,
      "sha256": "146148e65e4559a95e72c2d53282c542d648521a66876a7bf3e7cbc5c4753f80"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "6b1945eb8075096c3a63e45db4b6aa560ba22bbb5b7d913b3472b1f57151fd35"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "af1f655f69ef0bd19dc28f0dcbc9669f301ea172a5ddb6da951fa0d47014887f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "817647fe-4ce9-4db4-a77b-4aae68f549bb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c2a6e2f4-5882-4fba-aec5-a133fa0b1067",
    "source_id": "61c272fd-b083-4853-8874-68e0f235830f",
    "version_id": "9a7ed4b0-4f19-42c3-9b10-a609d17b55d3"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38123/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5f067d16-903c-4334-abab-10d5cf13dcdc",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "6b1945eb8075096c3a63e45db4b6aa560ba22bbb5b7d913b3472b1f57151fd35"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
