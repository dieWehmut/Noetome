# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b620968829077bc00bb3d5b73dd79c581802c92a9455e9cf80bd647adf59b245"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "509c5759b5d337e2d48309a7050d92acfb2eacc3f7dfb60d5f2c9eb27f489afb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0cf2acad012c0babf18448d36e7d1a9748356683ea0afd34335c85877d060d50"
    },
    "request.json": {
      "byte_length": 2242,
      "sha256": "1bfac7e6a2f412eb7b73b29ee912f36ccf8cd523d152f18b26f3c94117fa56d9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "0fcf3428908880bc3217407b15fabb0c5996d2086a4b351676b5f6105e1ad708"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "cd000dd74bf6c6cfe6901cc673ca8edaa479f1e83ec45547a64a7c94333f6dbc"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e718c0fd-b63c-430b-b7c2-743718e6a22b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0950accf-12fb-496c-b7ae-d9f3c68d9ccd",
    "source_id": "77aed9df-aabc-4c74-8bb1-bbb4ef02c77c",
    "version_id": "c5f2f714-9fbd-4db0-a6e8-4702b6d0c195"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38401/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8b8e41ee-0fdd-40a3-8172-016e65117a26",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "0fcf3428908880bc3217407b15fabb0c5996d2086a4b351676b5f6105e1ad708"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
