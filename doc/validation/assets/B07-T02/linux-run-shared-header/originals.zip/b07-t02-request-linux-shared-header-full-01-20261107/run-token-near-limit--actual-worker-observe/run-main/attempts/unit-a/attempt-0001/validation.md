# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "450a923c620b1976ad7a114b4183e683cf10ef96a9e56274c5db3fba1eb5b9a8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "93d057127363f9afd1179328aaedf88b124d7df8d6628f54d23814a661219b10"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "23fa0d1ddeeb79933f0afcd93abe1882ea19e08a7abe2af4ea9b3f1657f59583"
    },
    "request.json": {
      "byte_length": 2240,
      "sha256": "2b5defa4dada77ef43f1a5313edd0c24f0daebca3c3422ea8edb98636902dd7b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c9ed90f51d9333cc82daa8c427efbfefb7349de44d6d8aa18cee721eaefdb6c8"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "e5200bbd958ac161a24b49951fa95246fa50b58d1ec30732598c72ef998a2e69"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9f066f43-dc19-43c6-8394-118e3fe2bead",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6231620e-7cdd-405f-9ed1-8d214d5440ff",
    "source_id": "fdba79d7-0e51-494c-baaf-7370dd5b5e5c",
    "version_id": "2e79df03-d883-4252-9150-ee2df9a198af"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37473/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "21b52b71-e1b8-42fb-aec9-b2feff3d1e25",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c9ed90f51d9333cc82daa8c427efbfefb7349de44d6d8aa18cee721eaefdb6c8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
