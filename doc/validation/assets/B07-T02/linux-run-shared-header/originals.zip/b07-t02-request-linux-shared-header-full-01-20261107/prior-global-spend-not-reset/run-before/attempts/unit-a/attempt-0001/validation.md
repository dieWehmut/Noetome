# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7adaf67a362ccfb83aa4b0026547fa8b0af0ed2ceeaff654a66bb6e0413bfe02"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "bc49fa220b3768e05b9e58420e8b10a115ca5e184b890855791d5bb49d1199c6"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "ab0f1efd21c34b912568104a98780484d2fd2ab214e4273d7d1b3a6d9c7e820b"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "321d42d3f171b5a931044dcb882d069defc114460bca980be084a6778dcbdc3d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ac55cd2325bd671fab173f0834db70ee4af4ae528551e95607be02f496fb2c1f"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8a7f31af9273cb034f1d22bdc8077d5bf5d4719114f172df915a99be46927424"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "01945412-81e4-4248-81a6-f5e52e9da8c7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7f73dc27-cf54-4749-987b-39e8023db962",
    "source_id": "b5d762e2-f1f5-4fa0-a871-48499d623766",
    "version_id": "093226a5-136b-4880-b958-a09a27edf6cb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36821/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "3a43b3fc-3283-4888-9af5-93f4d63521b6",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ac55cd2325bd671fab173f0834db70ee4af4ae528551e95607be02f496fb2c1f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
