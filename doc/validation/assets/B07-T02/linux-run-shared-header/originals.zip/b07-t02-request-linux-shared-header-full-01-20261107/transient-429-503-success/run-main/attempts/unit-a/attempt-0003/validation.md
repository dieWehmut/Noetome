# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "44a7776db09ef9cce45e064272ed73ccb53f962601d07d27b704c8b244f53f71"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "fe874f5fdd61dde3f44c62a43e2344d4c60136c684d6373e4c4a5ba44aa6108b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "09f61c8cb7900627b471bb363ab12d266e4d0642b05632a361c321b17c314850"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "e8412ca78160d4aaa0c9404dc73c7e22c3cc5141d5d3ec60601e48bc8f6be2fb"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "615e8917bb79f396feb98491c5e8143244f3b59a02d6c24daf97caff1371ffd0"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7ec5365a96d956e5ad21932998516001b97000adc61c53bdad861a146af608af"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "97d588f1-ba64-4a58-bb3a-2fe53af3e424",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "c98f9a74-8d60-45ce-b146-0a1c3aef9dd7",
    "source_id": "82b32bcf-3b9b-4bd4-8bff-af4b246bf333",
    "version_id": "7b8227ca-8d5d-4b53-af78-672fee3f9004"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36703/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "116a87b1-2a9b-4b60-af97-ad510b184dcd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "615e8917bb79f396feb98491c5e8143244f3b59a02d6c24daf97caff1371ffd0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
