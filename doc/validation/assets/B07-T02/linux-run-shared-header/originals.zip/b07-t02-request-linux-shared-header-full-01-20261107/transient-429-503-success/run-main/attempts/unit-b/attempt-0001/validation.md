# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fa337b009a2fc6e58e716a1e83e3cb60bec8a80fec40ac84c0970dba5ddbd5a0"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "24707d80c5344381e7b0cfdf5892db7c721a451aa02ff424a93b1bccea81dc13"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "20eb909240615f79892d67eed30ab8a3f01945db5cf0f240ad4423bc24478055"
    },
    "request.json": {
      "byte_length": 2222,
      "sha256": "b19ecaac720af8a1b05f4db69494373f22fc539797410351416358075e2ecb1b"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "7cd9084b0b51bf2d330e77b28d36b1c9b88f1a6fad325fb66fabcb7d52506613"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "94c6999561c3d0c9d10c19694ecc8d2cd9f97956d5f932dbe6ce444d8c08989d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "17edd434-04b4-497e-80ea-59a6c27f2cc7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0fb92dcd-da24-40a4-89f5-267a4dc590e9",
    "source_id": "9374d578-bd5f-436d-8ac7-0dd8dbb4a550",
    "version_id": "936c15e0-6a40-42d1-a5f4-368f61f23dda"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36703/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7b337bc2-2920-4c29-a06a-8841085cde65",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "7cd9084b0b51bf2d330e77b28d36b1c9b88f1a6fad325fb66fabcb7d52506613"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
