# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4debe5ae61358ea91f9cd08245e89d4dca4f1eeba65d61ec2d4e26e87c6f61f8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "41f4fde635b9b03f4d388bb8eb586112e36c121c4204fd6899b9c9f3235be228"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "923920d9ba3cd97e2ccdfbbd3b4b36c9a8de867348c9afb30e28528e05c56083"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "124bf327739ed7fef4112a39f03ce87fc1989d43d3eac5c649e1989cdb010b17"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "5ba36a652132f10bcdd6e820ec25b68f3b15f2a36e739066d825b96651e5aa65"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "1ef673900022914f5fdf66cc619713e975e1e56e539a817fd933aa65c566d62c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a70b8a43-6ec4-4932-83f9-8434c9dbd39f",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "44e2ff22-4fe9-4015-ba5e-aecdf58f6a28",
    "source_id": "5efdef9f-28fa-4631-acbe-e91e72ae86e3",
    "version_id": "adb10e9f-2b20-43da-be12-5ec4ee69479c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37651/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c52a51b0-ea64-42da-8349-b7a4d33b4893",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "5ba36a652132f10bcdd6e820ec25b68f3b15f2a36e739066d825b96651e5aa65"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
