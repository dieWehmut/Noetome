# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b337af65b17408d838c4fa17d177d24aaaf8a63e94fd9cccdd46f8f067216169"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "8c7c66d93adfa3afefbe1761c907937a4d4f15fa4ec0c30ed8f8c67a04ca672b"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2779bd797b2020c049c5316c2cfb19c1b36332603b1d76c095137118dc25200c"
    },
    "request.json": {
      "byte_length": 2245,
      "sha256": "f429439933d3b719011e62d30f76fb1fdd8a4c300fa398c739e4b2247ad1e3fd"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "c0d81fa343487565610e9ce07ca29183e4789240600817d4ee7d5a79e23b38eb"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "d9a3bbd2948c08696c1836b9e8a95c26640d4001aac609203efb8712988456a6"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "72b32af3-7c1b-454d-9754-aa74565d6a3a",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b457d894-b209-40ed-be99-da3850f62d5e",
    "source_id": "23dbc130-f0a7-4299-8f3a-9517ae5de852",
    "version_id": "661c3a80-1bd7-4ce8-8504-cb5fcd0959eb"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37901/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "69a0accd-695f-493f-b28c-90f5f40cdf33",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "c0d81fa343487565610e9ce07ca29183e4789240600817d4ee7d5a79e23b38eb"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
