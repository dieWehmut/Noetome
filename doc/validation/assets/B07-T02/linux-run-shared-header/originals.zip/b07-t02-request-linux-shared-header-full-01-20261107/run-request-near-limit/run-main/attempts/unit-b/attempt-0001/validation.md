# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f623ab34877eed0df30848f240575f9e05aa2c1f27d5d760954e130a1effdcec"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "022b26f81a58de4604c262eb8130f4ac0e4091241d18ff0c6cecf3be3de3c1ba"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e365cdd0902ba8f46a42c6815e68df6d6496f836137a7c310d397ab54475738e"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "cbd51bc32c55a0f806bdf24e3fe7e9fadb52e7ff9a2471f6562d49110938a716"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ee1a93d3cad7b531c760027cc5d669d9ef526f79c8a70dd68497f5741ca12163"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "352cdf01c35cf07cce4f88eaab6dbfdb37a6f1fe0f42ad9dde79bdb48c0763ef"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "b6edf608-0de8-405a-ba78-c59344e811cb",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "df227820-aab1-4700-87e9-b948ea20c0db",
    "source_id": "9ca4e853-c933-46ca-bde6-fb6bb40add35",
    "version_id": "674b8144-6e51-41a9-acb7-96bff25d5c18"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36435/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "86e8bcf6-8676-4ca2-9a67-ba76301df27d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ee1a93d3cad7b531c760027cc5d669d9ef526f79c8a70dd68497f5741ca12163"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
