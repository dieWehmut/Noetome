# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9749d3b1f41bb7c9d67443ea69580c0b9428f55c63fd6f4f6697d72828956a48"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "0dfe41216f249e448acbe4ab8285ff9820d1613106f5afb6a7a357194f07c7cf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "2aa327add80a8649d56f4dea6b7edee96b386b102f8d78d0f9e1b9385ae7450a"
    },
    "request.json": {
      "byte_length": 2234,
      "sha256": "5a721c52ca84639d8aa480bf3c62b2e665aa3ea1f60233c29d383dd6db0f2167"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "29e00182af3708bef47fd6c3e7d0e15b27f1675c82cf1799828c11ac3ce9437c"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "7bfbc0875793b48d48ebe49577c50ffcc1ce8bd944151f7a790974beb4e1d038"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "5f0dd536-43b4-4f26-b7ee-0e6515d2fd31",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "70975a10-03a9-45e8-9532-c6a77b5e5b1d",
    "source_id": "47788894-de71-421c-909a-40903e37b696",
    "version_id": "ae60a7be-461f-4851-90fc-dc2e1b6af74c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:38375/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b66c27c5-2958-40fa-8306-af721fb2c0c9",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "29e00182af3708bef47fd6c3e7d0e15b27f1675c82cf1799828c11ac3ce9437c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
