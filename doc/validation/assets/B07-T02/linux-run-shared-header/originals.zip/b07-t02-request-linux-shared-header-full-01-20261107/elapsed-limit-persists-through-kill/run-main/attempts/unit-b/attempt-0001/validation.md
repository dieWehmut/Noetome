# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fe079fc8df520d5a4cfcd233542fe145061f2218fbf7b976ea6869f1c880cac6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "c264fb2ad0e0e2c7d90efde4bc3eea45c0e6ed52f3bac2c536e4928e0f91dc20"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b4d3d338fd3009a135a563bfc7cac5b4148ee7426b623d8eb55398d5a81d25f8"
    },
    "request.json": {
      "byte_length": 2232,
      "sha256": "5b7d7a9913eb3ccb846cbbe8f2c184c50b7bf0588636899d749d8dd43604361e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b2aebff82337d817d497abeeb12ee7577f50af7b39930dd078b33a540fda7286"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "aa16acfe3d199dab6f02b14c98382d60dac60a456790b3ec542bcd1bdb85531d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fa22d352-adf7-42ec-a68c-67808926ca20",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "0f592fb2-a0c1-41c4-ade5-25298a161e25",
    "source_id": "68b96464-d895-41cc-9c50-5a31a48f63a0",
    "version_id": "a2b30415-848f-43ff-975b-dcba2241d41b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36469/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ad511d94-5d47-4b35-a900-468bcc6d197c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b2aebff82337d817d497abeeb12ee7577f50af7b39930dd078b33a540fda7286"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
