# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "82e43c8582f1ddd7b6bf548d65ed96ea428304db61cc615a7df0663ff6164817"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "bd7869e48aeff8864cf26d071c8b159c637f034b79d73b4a1efb2243da2e447c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "082309dfea2fd0aa64a4b396b7e24044cf826490560df29a72804965d88c08f1"
    },
    "request.json": {
      "byte_length": 2245,
      "sha256": "8b290eb1c0ec0a2109faed8f0574f4582c7b1960f8ab7da6a7ba8d53fcb320e2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "a648761e8030c49600dac886a64a0e8ed06e7e2754577c34ecafefdca321a301"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "ee9a7b9e63169daaa071b4c8e33e3fcd9395c59de0df41b4306bddcb37ca4c12"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "30fde7b9-8295-4009-85b5-88e3a85fde11",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "7fa9591c-c6db-4c0a-a5cd-830cf5591898",
    "source_id": "844a1c46-4b41-4c0c-a95c-527a8eca827e",
    "version_id": "8c9aceb3-5d87-4ed8-bc2e-10b41b2ab4dc"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37863/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d3465d34-3f1a-4011-9bcd-a4d4a119d647",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "a648761e8030c49600dac886a64a0e8ed06e7e2754577c34ecafefdca321a301"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
