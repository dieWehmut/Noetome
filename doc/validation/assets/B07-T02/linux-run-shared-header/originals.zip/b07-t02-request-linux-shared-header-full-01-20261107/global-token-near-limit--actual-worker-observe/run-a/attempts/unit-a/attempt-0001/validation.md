# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8c2e12f37d78716ed2c1b838c4f1d75198d4b52fd263e5a354cd756406214aa8"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "7e04f88a52e6f316beb34c11f73c76b8acea2bf8ffd46adf100c919d739979bd"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "795d6f6621034328c07a0170099386452ad7484b8468c990b2e3b269796e6fdc"
    },
    "request.json": {
      "byte_length": 2243,
      "sha256": "05d551bbbfd7de1175d48a9aaa59ac6d0d1db9b0302b8ddf075d5433106482f3"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "da30bafb6946e70c4002392c8c99c5b249324c189837dd845410a2e319fb9184"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "8b9b440709121305e7efff4d9da934bb2b7095eae1e6f2caad733da5e248637f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "64cdcfc0-5b69-4df0-8c15-9243e80b305b",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "dd309de4-5bf8-47db-84d0-c6915b78f5af",
    "source_id": "ebec75b1-2c26-435f-a352-4e1c244338d4",
    "version_id": "dba91d79-0dae-47a8-a338-0fe80ceee05c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:36681/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "595e2975-7c54-4a3f-92d6-526ecc59afe1",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "da30bafb6946e70c4002392c8c99c5b249324c189837dd845410a2e319fb9184"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
