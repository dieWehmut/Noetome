# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "bb8c2d24483e70b2f1bb3b07f2c9236e95cc11fa5559f2edd59f33e7c9e2a760"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "9caa589ca3ccb19250f1689d943bd35379772eee6ae25c6fc47e009e9bdf05e0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "39115021e9307cee3045cbeb7cb4e729036fbfbd69293b22546245948971730f"
    },
    "request.json": {
      "byte_length": 2236,
      "sha256": "576f0ddc90ec2b4c2cf7057c16a50ce8a55fcb8434bce3cccfcdf9455cfd8873"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "81cafb834c53eb8cda0ad42b82f3090fd2150bf4e0976fd344fdaebee1547dd1"
    },
    "transport-receipt.json": {
      "byte_length": 478,
      "sha256": "f0f3783cb9e6bd3a2f354be669ff4e7c0688879a7e1013ce5b22622b4ec49e18"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "770c01f0-5ee3-40f2-8d07-6efa3a3d845e",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "22d272d5-36b5-4a5b-8152-584ecc7ef30a",
    "source_id": "cfe14196-2d27-4757-8c3b-8b2aab0d01d3",
    "version_id": "d6b71710-0ee2-48df-871e-6f30fe6ffb6b"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:37713/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0a3ac108-2431-4b02-9cbe-588ce2567497",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "81cafb834c53eb8cda0ad42b82f3090fd2150bf4e0976fd344fdaebee1547dd1"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
