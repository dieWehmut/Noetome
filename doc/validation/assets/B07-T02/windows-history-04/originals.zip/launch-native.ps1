$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-native-04-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-native-04-20261107' --snapshot-sha256 '6585ce76951850ac206243e61afd4ee055fa7089be875d94652807d235c096a1' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '1d68e14a213ae736c8a7c2d825ae6bf3c845f5c37bc78febcbff3294c6b215c9'
exit $LASTEXITCODE
