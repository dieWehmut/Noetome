$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-06-20261107\release-executor.py' run --base 'D:\Noetome\.artifacts\b07-t02-windows-release-pair-06-20261107' --snapshot-sha256 'f3e2925a9df5508dd74b5852128ef9179d6881ea2d839c0f2dd03db06ce99004' --runner-sha256 '3f4978367fce60895bf798ba40eee4d2c3d088a3ca409ca58f10608931a6e0c1' --source-archive-sha256 '4c2b2fc1230c619cd2b7d3bb2ab8609ea3fdaa3923060c434d2d37b368e693f3' --executor-sha256 '83d34e42602b78b5438f90ad70766c17a3d33227d1fa4961a95a1d80a1d20c15'
exit $LASTEXITCODE
