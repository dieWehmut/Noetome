"""Fresh read-only audit of preserved B03-T03 evidence; never invokes product code."""
import base64
import hashlib
import json
import pathlib
import platform
import sqlite3
import sys
import traceback
from datetime import datetime, timezone

source = pathlib.Path(sys.argv[1]).resolve()
destination = pathlib.Path(sys.argv[2]).resolve()
writer_facts_path = pathlib.Path(sys.argv[3]).resolve()
receipt = json.loads((source / "verification.json").read_bytes())
report = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "runtime": sys.executable,
    "python_version": platform.python_version(),
    "sqlite_version": sqlite3.sqlite_version,
    "argv": sys.argv,
    "method": "stdlib SQLite mode=ro&immutable=1, independent JSON lexical numbers, actual file bytes and metadata",
    "not_run": ["fresh CLI execution", "Rust compilation", "fresh process termination", "source_model cache-root timing probe"],
    "projects": [],
}
tables = {
    "project_metadata", "sources", "source_versions", "source_spans", "source_imports",
    "pdf_parses", "pdf_pages", "pdf_regions", "pdf_resources", "pdf_imports",
}

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ordinary_file(path):
    metadata = path.lstat()
    require(path.is_file() and not path.is_symlink(), f"Nonregular file: {path}")
    require(not (getattr(metadata, "st_file_attributes", 0) & 0x400), f"Reparse file: {path}")
    return metadata

def inventory(root):
    result = {}
    for path in sorted(root.rglob("*")):
        metadata = path.lstat()
        require(not path.is_symlink() and not (getattr(metadata, "st_file_attributes", 0) & 0x400), f"Linked entry: {path}")
        relative = path.relative_to(root).as_posix()
        if path.is_file():
            result[relative] = ("file", metadata.st_size, metadata.st_mtime_ns, metadata.st_nlink, sha(path.read_bytes()))
        else:
            require(path.is_dir(), f"Nonregular entry: {path}")
            result[relative] = ("directory",)
    return result

def within(root, relative):
    path = root / relative
    require(path.resolve().is_relative_to(root), f"Out of selected evidence root: {relative}")
    return path

def lexical_json(raw):
    return json.loads(raw, parse_float=lambda value: ("number", value), parse_int=lambda value: ("number", value))

def audit_project(root):
    before = inventory(root)
    config = json.loads((root / "project.json").read_bytes())
    connection = sqlite3.connect((root / "project.sqlite").as_uri() + "?mode=ro&immutable=1", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        actual_tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        require(actual_tables == tables, f"Wrong tables: {root}")
        require(connection.execute("PRAGMA user_version").fetchone()[0] == 3 == config["schema_version"], f"Schema pairing: {root}")
        require(connection.execute("PRAGMA application_id").fetchone()[0] == 0x4e4f4554, f"Application ID: {root}")
        metadata = dict(connection.execute("SELECT * FROM project_metadata").fetchone())
        require(metadata["project_id"] == config["project_id"] and metadata["created_at"] == config["created_at"], f"Metadata pairing: {root}")
        require(connection.execute("PRAGMA foreign_key_check").fetchall() == [], f"Foreign key mismatch: {root}")
        versions = [dict(row) for row in connection.execute("SELECT * FROM source_versions")]
        attempts = [dict(row) for row in connection.execute("SELECT * FROM pdf_parses")]
        imports = [dict(row) for row in connection.execute("SELECT rowid,* FROM source_imports")] + [dict(row) for row in connection.execute("SELECT rowid,* FROM pdf_imports")]
        require(len({row["rowid"] for row in imports}) == len(imports) and all(row["rowid"] > 0 for row in imports), f"Shared import rowids: {root}")
        require(len({row["import_id"] for row in imports}) == len(imports), f"Shared import IDs: {root}")
        version_map = {version["version_id"]: version for version in versions}
        for source_id in {version["source_id"] for version in versions}:
            revisions = sorted(version["revision"] for version in versions if version["source_id"] == source_id)
            require(revisions == list(range(1, len(revisions) + 1)), f"Version revisions: {root}")
        for version in versions:
            raw_path = within(root, version["raw_snapshot"])
            raw = raw_path.read_bytes()
            require(sha(raw) == version["content_sha256"] and len(raw) == version["byte_length"], f"Version raw SHA: {raw_path}")
            if version["media_type"] == "application/pdf":
                require(ordinary_file(raw_path).st_nlink == 1, f"Version raw link count: {raw_path}")
                require(version["ingest_status"] == "acquired" and all(version[field] is None for field in ["normalized_sha256", "normalization_version", "normalized_snapshot", "error_code", "error_message"]), f"PDF version text semantics: {root}")
                require(connection.execute("SELECT count(*) FROM source_spans WHERE source_version_id=?", [version["version_id"]]).fetchone()[0] == 0, f"PDF legacy Spans: {root}")
            elif version["normalized_snapshot"] is not None:
                normalized = within(root, version["normalized_snapshot"]).read_bytes()
                expected = raw.decode("utf-8").removeprefix("\ufeff").replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")
                require(normalized == expected and sha(normalized) == version["normalized_sha256"], f"Old text normalization: {root}")
        totals = {"source_versions": len(versions), "pdf_parses": len(attempts), "imports": len(imports), "pages": 0, "resources": 0, "lexical_pages": 0, "host_failed": 0}
        for attempt in attempts:
            parse_id = attempt["parse_id"]
            location = within(root, attempt["snapshot_path"])
            resources = [dict(row) for row in connection.execute("SELECT * FROM pdf_resources WHERE parse_id=?", [parse_id])]
            expected_paths = {resource["relative_path"] for resource in resources}
            actual = inventory(location)
            require({name for name, value in actual.items() if value[0] == "file"} == expected_paths, f"Parse file inventory: {location}")
            expected_directories = set()
            for name in expected_paths:
                parent = pathlib.PurePosixPath(name).parent
                while str(parent) != ".":
                    expected_directories.add(parent.as_posix())
                    parent = parent.parent
            require({name for name, value in actual.items() if value[0] == "directory"} == expected_directories, f"Parse directory inventory: {location}")
            for resource in resources:
                path = within(location, resource["relative_path"])
                raw = path.read_bytes()
                require(ordinary_file(path).st_nlink == 1 and sha(raw) == resource["sha256"] and len(raw) == resource["byte_length"], f"Resource SHA/size/link count: {path}")
            version = version_map[attempt["source_version_id"]]
            preimage = {
                "adapter_sha256": attempt["adapter_sha256"], "cache_version": "pdf-source-cache-v1",
                "import_options_version": attempt["import_options_version"],
                "input_fingerprint": {"sha256": version["content_sha256"], "byte_length": version["byte_length"]},
                "protocol_version": attempt["protocol_version"], "requested_parser": json.loads(attempt["requested_parser_json"]),
            }
            canonical = json.dumps(preimage, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
            require(sha(canonical) == attempt["cache_key"], f"Cache key preimage: {location}")
            pages = [dict(row) for row in connection.execute("SELECT * FROM pdf_pages WHERE parse_id=? ORDER BY physical_page_index", [parse_id])]
            totals["pages"] += len(pages)
            totals["resources"] += len(resources)
            if attempt["outcome_kind"] == "validated":
                manifest_raw = (location / "parser/pdf-manifest.json").read_bytes()
                manifest = json.loads(manifest_raw)
                lexical_pages = lexical_json(manifest_raw)["pages"]
                require(sha(manifest_raw) == attempt["manifest_sha256"] and manifest["input_fingerprint"]["sha256"] == version["content_sha256"], f"Manifest identity: {location}")
                require(len(pages) == len(lexical_pages) == attempt["confirmed_page_count"], f"Page count: {location}")
                for sql_page, original_page in zip(pages, lexical_pages):
                    require(lexical_json(sql_page["record_json"]) == original_page, f"Original page numeric lexemes: {location}")
                    page = json.loads(sql_page["record_json"])
                    require(sql_page["physical_page_index"] == page["physical_page_index"] and sql_page["display_page_number"] == page["physical_page_index"] + 1 and sql_page["status"] == page["status"], f"Page SQL indices: {location}")
                    totals["lexical_pages"] += 1
            else:
                require(attempt["outcome_kind"] == "host_failed" and not pages and attempt["parser_json"] is None and attempt["page_count"] is None and attempt["region_count"] == 0, f"Host failure evidence: {location}")
                failure = json.loads((location / "failure.json").read_bytes())
                require(failure["error"]["code"] == attempt["error_code"] and failure["error"]["message"] == attempt["error_message"] and failure["input_fingerprint"] is None and failure["confirmed_pages"] == [], f"Host failure truth: {location}")
                totals["host_failed"] += 1
        for row in connection.execute("SELECT * FROM pdf_imports WHERE acquisition_status='failed'"):
            require(row["version_id"] is None and row["parse_id"] is None and row["reused"] == 0 and row["parse_reused"] == 0, f"Incomplete acquisition identity: {root}")
        if root.name == "schema2-history":
            for table, old_rows in receipt["checks"][0]["old_rows"].items():
                current = {row["rowid"]: dict(row) for row in connection.execute(f"SELECT rowid,* FROM {table}")}
                require(all(current[row["rowid"]] == row for row in old_rows), f"Old complete SQL rows changed: {table}")
            totals["old_row_tables_exact"] = len(receipt["checks"][0]["old_rows"])
    finally:
        connection.close()
    require(inventory(root) == before, f"Read-only byte/mtime/inventory changed: {root}")
    return {"project": str(root), "result": "passed", "counts": totals, "files_unchanged": sum(value[0] == "file" for value in before.values())}

try:
    require(receipt["result"] == "passed" and len(receipt["checks"]) == 31 and all(check["result"] == "passed" for check in receipt["checks"]), "Archived verifier check totals")
    require(len(receipt["calls"]) == 159 == receipt["real_cli_calls"], "Archived verifier CLI total")
    pdf_calls = 0
    for call in receipt["calls"]:
        raw_stdout = base64.b64decode(call["stdout_base64"])
        raw_stderr = base64.b64decode(call["stderr_base64"])
        require(raw_stdout.decode("utf-8") == call["stdout"] and raw_stderr.decode("utf-8") == call["stderr"], "Archived call bytes differ from text")
        if call["stdout"].lstrip().startswith("{"):
            output = json.loads(call["stdout"])
            if output.get("report_kind") == "source_pdf_import":
                require(call["exit_code"] == (0 if output["status"] == "ready" else 3), "PDF CLI status/exit mismatch")
                pdf_calls += 1
    report["archived_verifier"] = {"checks": 31, "calls": 159, "pdf_report_status_exit_pairs": pdf_calls, "sha256": sha((source / "verification.json").read_bytes())}
    for check in receipt["checks"][:12]:
        root = pathlib.Path(check["project"]).resolve()
        require(root.parent == source, "Selected audit project is not direct child of verifier root")
        report["projects"].append(audit_project(root))
    facts = json.loads(writer_facts_path.read_bytes())
    require(len(facts) == 5 and {fact["stage"] for fact in facts} == {"Prepared", "VersionPublished", "ParsePublished", "DatabasePublished", "ConfigPublished"}, "Archived Writer stage facts")
    require(all(fact["alive_before_kill"] and fact["exited_and_reaped"] and fact["old_history_and_snapshots_preserved"] and fact["inspection_read_only"] for fact in facts), "Archived Writer interruption facts")
    report["archived_writer_facts"] = {"sha256": sha(writer_facts_path.read_bytes()), "actual_pid_count": 5}
    report["result"] = "passed"
    report["exit_code"] = 0
except Exception as error:
    report["result"] = "failed"
    report["error"] = repr(error)
    report["traceback"] = traceback.format_exc()
    report["exit_code"] = 1
report["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
(destination / "snapshot-audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(report["exit_code"])

