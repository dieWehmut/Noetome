import hashlib
import json
import pathlib
import platform
import sys

expected_manifest = "66eb4a26f47681098cb6ceffc03dec7a6cf26ef7892c2f42248a4d49f2a65277"
expected_base = "058a8b353dd41cff7840a2995dedde032a41db9a"
source = pathlib.Path(sys.argv[1]).resolve()
destination = pathlib.Path(sys.argv[2]).resolve()
payload = (source / "manifest.json").read_bytes()
manifest = json.loads(payload)
results = []
for relative, expected in manifest["files"].items():
    data = (source / relative).read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    length = len(data)
    results.append({
        "path": relative,
        "sha256": sha,
        "byte_length": length,
        "line_count": len(data.splitlines()),
        "matches": sha == expected["sha256"] and length == expected["byte_length"]
    })
actual_files = {p.relative_to(source).as_posix() for p in source.rglob("*") if p.is_file()}
expected_files = set(manifest["files"]) | {"manifest.json"}
result = {
    "runtime": sys.executable,
    "python_version": platform.python_version(),
    "argv": sys.argv,
    "scope": str(source),
    "manifest_sha256": hashlib.sha256(payload).hexdigest(),
    "manifest_matches": hashlib.sha256(payload).hexdigest() == expected_manifest,
    "base": manifest["base"],
    "base_matches": manifest["base"] == expected_base,
    "schema_version": manifest["schema_version"],
    "file_count": len(results),
    "unknown_files": sorted(actual_files - expected_files),
    "missing_files": sorted(expected_files - actual_files),
    "files": results
}
result["passed"] = result["manifest_matches"] and result["base_matches"] and result["file_count"] == 20 and all(r["matches"] for r in results) and not result["unknown_files"] and not result["missing_files"]
result["exit_code"] = 0 if result["passed"] else 1
(destination / "manifest-verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
raise SystemExit(result["exit_code"])

