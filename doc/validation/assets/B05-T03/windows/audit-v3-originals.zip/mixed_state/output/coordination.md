# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：1；条件不适用：1；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：1；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "6b7fa759-5c60-4fd2-9a7c-c58e5d025b1f",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
        "import_id": "5d822ff4-22b9-46ba-b71c-9b15cb42ba77",
        "source_id": "9f09281b-4f78-42ef-aa1d-ac785d6421f8",
        "version_id": "a5886002-7fcd-4fcc-a965-edb05df90753",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "5d822ff4-22b9-46ba-b71c-9b15cb42ba77",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
              "source_id": "9f09281b-4f78-42ef-aa1d-ac785d6421f8",
              "version_id": "a5886002-7fcd-4fcc-a965-edb05df90753"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "5d822ff4-22b9-46ba-b71c-9b15cb42ba77",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
              "source_id": "9f09281b-4f78-42ef-aa1d-ac785d6421f8",
              "version_id": "a5886002-7fcd-4fcc-a965-edb05df90753"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "3dc397691b240eb36c659af092d5015968bd065d2004d99fbf8985713511fd43",
          "byte_length": 2708
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "f68393ea13402c16099132dbb194e34591ed5554dda0988f9eebff47cd1c75f2",
          "byte_length": 492
        },
        "knowledge-ir.json": {
          "sha256": "783e0e1a42f72a059ef50386ad207f0e0c898f7459b920d11bc9b5775999ba70",
          "byte_length": 9243
        },
        "review-original.json": {
          "sha256": "5febe091be57f649090a8f0332549c2cb33ac7d9733c299d74eb4574cbfeff3d",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "f53960daeb8d0dfe29c91d0e0923a81ed7faa3ba03e147010762a9be398b78f6",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "fdf057b4d69839d56ba77b98927af9123168ccb33689fa78527d55ca4d9072a1",
          "byte_length": 13979
        },
        "verification.md": {
          "sha256": "3e702576298e720c6663c9c7ed9a67dbbf2181cb80bdfff028d45787a2f5f7ea",
          "byte_length": 14413
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
        "import_id": "e9d632c4-2c18-4cd1-b5f6-7c40f3233333",
        "source_id": "e1928a24-a90a-498f-bfb1-b1bacfe58e71",
        "version_id": "b64e091f-966a-4e6b-b81f-33c3c29143e2",
        "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "import_id": "e9d632c4-2c18-4cd1-b5f6-7c40f3233333",
              "manifest_sha256": null,
              "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "parse_id": null,
              "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
              "source_id": "e1928a24-a90a-498f-bfb1-b1bacfe58e71",
              "version_id": "b64e091f-966a-4e6b-b81f-33c3c29143e2"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "import_id": "e9d632c4-2c18-4cd1-b5f6-7c40f3233333",
              "manifest_sha256": null,
              "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "parse_id": null,
              "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
              "source_id": "e1928a24-a90a-498f-bfb1-b1bacfe58e71",
              "version_id": "b64e091f-966a-4e6b-b81f-33c3c29143e2"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 12 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s。",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "66e6c551ef62ee9bafb0f1ed3e0ecdede9a6ab856cbd0846b024d55d0f5946cd",
          "byte_length": 2708
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "cbed5c4d86b933cea42966337dba28719e176be1625d625761f2e320f3d9ae6c",
          "byte_length": 492
        },
        "knowledge-ir.json": {
          "sha256": "a1cea971a8bcfd3be691d7f006127a4f68483cf9f89fc1281b7da5d0f156af68",
          "byte_length": 9243
        },
        "review-original.json": {
          "sha256": "21cbab5301a7320d157eb97782ca735479450232b0e676a3f09cf33756820b21",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "7fb8abd34623a75ec920bf45ad9f39a90aedfd148be433555499847212f0cdf8",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "2d3f3532f7ea3f1b0c48ab780efa6496dfbe059b6a9e6bed34ad8b8ed6b764cf",
          "byte_length": 13979
        },
        "verification.md": {
          "sha256": "ab847d6befe9e11acb9376550ecb2d4fabdce8d8365df8077163b972f46b3f57",
          "byte_length": 14413
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-3618996ca2c59f0e591f6e36935f4615ed8af1e7ec2a0cec18c531f11e8c7908",
      "input_id": "a",
      "binding": {
        "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
        "import_id": "5d822ff4-22b9-46ba-b71c-9b15cb42ba77",
        "source_id": "9f09281b-4f78-42ef-aa1d-ac785d6421f8",
        "version_id": "a5886002-7fcd-4fcc-a965-edb05df90753",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "ae29748b-159f-4290-b297-4c444bb0ef5b",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
        "sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b"
      },
      "occurrence_id": "occ-ffc0b0d4228202e11417a7b2ea8c514b9eeb13c8092c223b6c82c9abb50f8320",
      "input_id": "b",
      "binding": {
        "project_id": "84786b49-d216-4908-b86e-4bf1e70b604d",
        "import_id": "e9d632c4-2c18-4cd1-b5f6-7c40f3233333",
        "source_id": "e1928a24-a90a-498f-bfb1-b1bacfe58e71",
        "version_id": "b64e091f-966a-4e6b-b81f-33c3c29143e2",
        "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "8a76a6b5-3203-4f30-8c79-f7e613e44405",
          "ordinal": 0,
          "resource_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-d0907032cb4dc7d590b47392f3074436030610f9e26ed86dbe1816fbcd123321",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-ffc0b0d4228202e11417a7b2ea8c514b9eeb13c8092c223b6c82c9abb50f8320"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-eb49228a6157a60022a52b9ee0121e53ec5c06af794a3dd1f0bb1a5bef188abc",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-3618996ca2c59f0e591f6e36935f4615ed8af1e7ec2a0cec18c531f11e8c7908"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-3618996ca2c59f0e591f6e36935f4615ed8af1e7ec2a0cec18c531f11e8c7908",
      "right_occurrence_id": "occ-ffc0b0d4228202e11417a7b2ea8c514b9eeb13c8092c223b6c82c9abb50f8320",
      "relation": "insufficient_evidence",
      "issue_code": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-3618996ca2c59f0e591f6e36935f4615ed8af1e7ec2a0cec18c531f11e8c7908",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    },
    {
      "occurrence_id": "occ-ffc0b0d4228202e11417a7b2ea8c514b9eeb13c8092c223b6c82c9abb50f8320",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 1,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 2,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "ab791b430eb14c8e2c0c3ba6b63bfb2486b0b02955607d57801450fbff107a3d",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "5446a7ea9415c5eb044896d4224cb4dbdeb3ff9abd269139d5a630c53f5a21fd",
      "byte_length": 4326
    },
    "identity-original.json": {
      "sha256": "38ba51ab4365d0c36a8f2397f1ca1583afea1a32314784c7a63afe15cd63fa18",
      "byte_length": 1909
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "3dc397691b240eb36c659af092d5015968bd065d2004d99fbf8985713511fd43",
      "byte_length": 2708
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "f68393ea13402c16099132dbb194e34591ed5554dda0988f9eebff47cd1c75f2",
      "byte_length": 492
    },
    "input-a--knowledge-ir.json": {
      "sha256": "783e0e1a42f72a059ef50386ad207f0e0c898f7459b920d11bc9b5775999ba70",
      "byte_length": 9243
    },
    "input-a--review-original.json": {
      "sha256": "5febe091be57f649090a8f0332549c2cb33ac7d9733c299d74eb4574cbfeff3d",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "f53960daeb8d0dfe29c91d0e0923a81ed7faa3ba03e147010762a9be398b78f6",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "fdf057b4d69839d56ba77b98927af9123168ccb33689fa78527d55ca4d9072a1",
      "byte_length": 13979
    },
    "input-a--verification.md": {
      "sha256": "3e702576298e720c6663c9c7ed9a67dbbf2181cb80bdfff028d45787a2f5f7ea",
      "byte_length": 14413
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "66e6c551ef62ee9bafb0f1ed3e0ecdede9a6ab856cbd0846b024d55d0f5946cd",
      "byte_length": 2708
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "cbed5c4d86b933cea42966337dba28719e176be1625d625761f2e320f3d9ae6c",
      "byte_length": 492
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a1cea971a8bcfd3be691d7f006127a4f68483cf9f89fc1281b7da5d0f156af68",
      "byte_length": 9243
    },
    "input-b--review-original.json": {
      "sha256": "21cbab5301a7320d157eb97782ca735479450232b0e676a3f09cf33756820b21",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "7fb8abd34623a75ec920bf45ad9f39a90aedfd148be433555499847212f0cdf8",
      "byte_length": 974
    },
    "input-b--verification.json": {
      "sha256": "2d3f3532f7ea3f1b0c48ab780efa6496dfbe059b6a9e6bed34ad8b8ed6b764cf",
      "byte_length": 13979
    },
    "input-b--verification.md": {
      "sha256": "ab847d6befe9e11acb9376550ecb2d4fabdce8d8365df8077163b972f46b3f57",
      "byte_length": 14413
    }
  }
}
```
