# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：1；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "3d7d33af-bc3e-451c-951b-768b1656b6c8",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
        "import_id": "65dae2f4-ac8f-4317-b060-2522a62f066b",
        "source_id": "b91ab473-52a0-454a-8631-efc54a14ea92",
        "version_id": "ef5b5115-6bc2-40ae-850f-0fbdab5a04e4",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "65dae2f4-ac8f-4317-b060-2522a62f066b",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
              "source_id": "b91ab473-52a0-454a-8631-efc54a14ea92",
              "version_id": "ef5b5115-6bc2-40ae-850f-0fbdab5a04e4"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "65dae2f4-ac8f-4317-b060-2522a62f066b",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
              "source_id": "b91ab473-52a0-454a-8631-efc54a14ea92",
              "version_id": "ef5b5115-6bc2-40ae-850f-0fbdab5a04e4"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "e55fba0f01422d95073fca680f00174de205dbd9c58162598a6a3e498af3b2ed",
          "byte_length": 3051
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "3b841dd1a43ed4bc71fbff817f24e94ab50ba4bc809dbb4d20fdeeb7f609638d",
          "byte_length": 736
        },
        "knowledge-ir.json": {
          "sha256": "2874427578a1cdd415107fb648938b56e41edcb634e23000f8dcafcef6ab7156",
          "byte_length": 12385
        },
        "review-original.json": {
          "sha256": "84cd5e2f110aedfd69eff1564f5c5d54914f8bbcce8f491ad633bebaf8d5e365",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "f6cde2412abf3e2b19127925f580ff7c2ab779d4bf9fc557a059d0ef5b79fe60",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "814209e3a587331c0462f52ed63b4af295a151c13483d32e1b39e523ec6bd91c",
          "byte_length": 16860
        },
        "verification.md": {
          "sha256": "af0c894a13f672c76beace18bd54d193934c6ec6570c8dba162b5c3a3e4392ab",
          "byte_length": 17294
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
        "import_id": "7f5ca1be-be46-4a05-b8ed-027f78b2bfd8",
        "source_id": "df7691df-a5ff-4ab6-8f14-739650994ccc",
        "version_id": "b89876b5-b2cf-49c8-b617-e5358ec2bbad",
        "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "import_id": "7f5ca1be-be46-4a05-b8ed-027f78b2bfd8",
              "manifest_sha256": null,
              "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "parse_id": null,
              "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
              "source_id": "df7691df-a5ff-4ab6-8f14-739650994ccc",
              "version_id": "b89876b5-b2cf-49c8-b617-e5358ec2bbad"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "import_id": "7f5ca1be-be46-4a05-b8ed-027f78b2bfd8",
              "manifest_sha256": null,
              "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "parse_id": null,
              "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
              "source_id": "df7691df-a5ff-4ab6-8f14-739650994ccc",
              "version_id": "b89876b5-b2cf-49c8-b617-e5358ec2bbad"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 167,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 166,
            "excerpt_sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "quote": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 166,
              "excerpt_sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "km/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "km/s",
          "actual": {
            "measurement": "km/s",
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "km/s"
          },
          "actual": [
            "km/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "a5d3ec79afea0f8e355ec4f476e836c2a35f2e093cccc9fc811b3f13e9d16821",
          "byte_length": 3055
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "c34f1a45ee3cd500a85e81e6962c7e5ea125bf26de76c0d19aec403e092097dd",
          "byte_length": 739
        },
        "knowledge-ir.json": {
          "sha256": "2163a8a50f27f60e46b727a89edc1287c9274243440b3321a2c42c490c2c41f5",
          "byte_length": 12404
        },
        "review-original.json": {
          "sha256": "e9e22c5925a1313632eaee3a9c7d6535eecde8403dd8ee597c094ce0457db277",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "f7388fa1100d66f5d118cdc404acbdbef7938d618de45ca5d8cc8082aabc3093",
          "byte_length": 1057
        },
        "verification.json": {
          "sha256": "cf2e7c892ee48394dfa97076bdf091a9427afd6dcfc58f7b061d0a4e7c268f35",
          "byte_length": 16876
        },
        "verification.md": {
          "sha256": "de7af3797168f31d7f3186973788585f978a2c746db595adbdab03418e88e2b4",
          "byte_length": 17310
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-4e486cedcb729cefb18861f03997bce792a6e7c30a4bf4ccf33113431fd406c5",
      "input_id": "a",
      "binding": {
        "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
        "import_id": "65dae2f4-ac8f-4317-b060-2522a62f066b",
        "source_id": "b91ab473-52a0-454a-8631-efc54a14ea92",
        "version_id": "ef5b5115-6bc2-40ae-850f-0fbdab5a04e4",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "0210b572-3b77-42fb-ae98-fe20d188f6dd",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 166,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30"
      },
      "occurrence_id": "occ-bdfcab276993d0abd58f1d1107dd7e22068f9172eaa0097cd5ad4c26c8f6c960",
      "input_id": "b",
      "binding": {
        "project_id": "de25f76e-d9dd-46e9-88d8-2053183d8447",
        "import_id": "7f5ca1be-be46-4a05-b8ed-027f78b2bfd8",
        "source_id": "df7691df-a5ff-4ab6-8f14-739650994ccc",
        "version_id": "b89876b5-b2cf-49c8-b617-e5358ec2bbad",
        "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "85a003d7-9fde-4fca-afc1-7f722005f55a",
          "ordinal": 0,
          "resource_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 167,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "km/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "km/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 166,
          "excerpt_sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "km/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-45514b2b1191f029ec6e3cca45d7d15407fb146d3f3b8033531ccd80de6b5dcc",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "km/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-bdfcab276993d0abd58f1d1107dd7e22068f9172eaa0097cd5ad4c26c8f6c960"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-71585ac2caed36414e2692879ef09222ae8e60dcf8eef7c928b2ccd0b2ff2bfd",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-4e486cedcb729cefb18861f03997bce792a6e7c30a4bf4ccf33113431fd406c5"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-4e486cedcb729cefb18861f03997bce792a6e7c30a4bf4ccf33113431fd406c5",
      "right_occurrence_id": "occ-bdfcab276993d0abd58f1d1107dd7e22068f9172eaa0097cd5ad4c26c8f6c960",
      "relation": "insufficient_evidence",
      "issue_code": "COORD_UNIT_NOT_COMPARABLE"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-4e486cedcb729cefb18861f03997bce792a6e7c30a4bf4ccf33113431fd406c5",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNIT_NOT_COMPARABLE"
    },
    {
      "occurrence_id": "occ-bdfcab276993d0abd58f1d1107dd7e22068f9172eaa0097cd5ad4c26c8f6c960",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNIT_NOT_COMPARABLE"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 1,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 2,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "1a9ca74be7f7fcb90d61be21113f0c128411b85156e30af6bf4b892d9be18f20",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "0e604620dd17232c03182bead7a7ffa3a8a3c1358aa6fcb076c138aa1ebd0b9f",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "a8ea11ff5a2c5cc4a5e252df5e66ef3e8953fe2eae3632224ed325477a21948a",
      "byte_length": 1898
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "e55fba0f01422d95073fca680f00174de205dbd9c58162598a6a3e498af3b2ed",
      "byte_length": 3051
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "3b841dd1a43ed4bc71fbff817f24e94ab50ba4bc809dbb4d20fdeeb7f609638d",
      "byte_length": 736
    },
    "input-a--knowledge-ir.json": {
      "sha256": "2874427578a1cdd415107fb648938b56e41edcb634e23000f8dcafcef6ab7156",
      "byte_length": 12385
    },
    "input-a--review-original.json": {
      "sha256": "84cd5e2f110aedfd69eff1564f5c5d54914f8bbcce8f491ad633bebaf8d5e365",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "f6cde2412abf3e2b19127925f580ff7c2ab779d4bf9fc557a059d0ef5b79fe60",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "814209e3a587331c0462f52ed63b4af295a151c13483d32e1b39e523ec6bd91c",
      "byte_length": 16860
    },
    "input-a--verification.md": {
      "sha256": "af0c894a13f672c76beace18bd54d193934c6ec6570c8dba162b5c3a3e4392ab",
      "byte_length": 17294
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "a5d3ec79afea0f8e355ec4f476e836c2a35f2e093cccc9fc811b3f13e9d16821",
      "byte_length": 3055
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "c34f1a45ee3cd500a85e81e6962c7e5ea125bf26de76c0d19aec403e092097dd",
      "byte_length": 739
    },
    "input-b--knowledge-ir.json": {
      "sha256": "2163a8a50f27f60e46b727a89edc1287c9274243440b3321a2c42c490c2c41f5",
      "byte_length": 12404
    },
    "input-b--review-original.json": {
      "sha256": "e9e22c5925a1313632eaee3a9c7d6535eecde8403dd8ee597c094ce0457db277",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "f7388fa1100d66f5d118cdc404acbdbef7938d618de45ca5d8cc8082aabc3093",
      "byte_length": 1057
    },
    "input-b--verification.json": {
      "sha256": "cf2e7c892ee48394dfa97076bdf091a9427afd6dcfc58f7b061d0a4e7c268f35",
      "byte_length": 16876
    },
    "input-b--verification.md": {
      "sha256": "de7af3797168f31d7f3186973788585f978a2c746db595adbdab03418e88e2b4",
      "byte_length": 17310
    }
  }
}
```
