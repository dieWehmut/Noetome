# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：1；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "2d7ed5b9-d79f-4cee-85bd-8a25a86b52c4",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
        "import_id": "91a33174-4353-4546-ba0d-44ad3869ef31",
        "source_id": "faacd37f-5ca9-41b2-add6-c1c9b24b9728",
        "version_id": "867924ac-0fa8-4337-bb97-e69fbeb97cb2",
        "content_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
        "normalized_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
              "import_id": "91a33174-4353-4546-ba0d-44ad3869ef31",
              "manifest_sha256": null,
              "normalized_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
              "parse_id": null,
              "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
              "source_id": "faacd37f-5ca9-41b2-add6-c1c9b24b9728",
              "version_id": "867924ac-0fa8-4337-bb97-e69fbeb97cb2"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
              "import_id": "91a33174-4353-4546-ba0d-44ad3869ef31",
              "manifest_sha256": null,
              "normalized_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
              "parse_id": null,
              "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
              "source_id": "faacd37f-5ca9-41b2-add6-c1c9b24b9728",
              "version_id": "867924ac-0fa8-4337-bb97-e69fbeb97cb2"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 168,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 167,
            "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 167,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 55
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 167,
              "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "146c8d5263466ebce210b8ff67cd450601d25a7d7512b91d1070c3a1932f13ff",
          "byte_length": 3053
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "3b841dd1a43ed4bc71fbff817f24e94ab50ba4bc809dbb4d20fdeeb7f609638d",
          "byte_length": 736
        },
        "knowledge-ir.json": {
          "sha256": "654e3d9036a5f0d150757c02483e8d8f0723926ef3ec73a8dc55b285a1fddf3d",
          "byte_length": 12391
        },
        "review-original.json": {
          "sha256": "84cd5e2f110aedfd69eff1564f5c5d54914f8bbcce8f491ad633bebaf8d5e365",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "de053f4dbb1100db7bd0de882276731b3877f3f82ee259f6106b000ca262c80e",
          "byte_length": 1058
        },
        "verification.json": {
          "sha256": "68a7ddeec9772555b7ccd51ec812f23bcf97df8c13ef3613175aabdb40f4dfd4",
          "byte_length": 16866
        },
        "verification.md": {
          "sha256": "0bf31fdbe03ab9813430f4e57c645d65a3adcc6dab23208ed76ec34625c75d08",
          "byte_length": 17300
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
        "import_id": "a97550c4-306e-4a75-8bd9-55e552555e6a",
        "source_id": "13e96486-7b36-40ed-b8d1-dba1b67af4e4",
        "version_id": "4616e967-6d87-451e-b539-23075c3a280f",
        "content_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
        "normalized_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
              "import_id": "a97550c4-306e-4a75-8bd9-55e552555e6a",
              "manifest_sha256": null,
              "normalized_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
              "parse_id": null,
              "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
              "source_id": "13e96486-7b36-40ed-b8d1-dba1b67af4e4",
              "version_id": "4616e967-6d87-451e-b539-23075c3a280f"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
              "import_id": "a97550c4-306e-4a75-8bd9-55e552555e6a",
              "manifest_sha256": null,
              "normalized_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
              "parse_id": null,
              "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
              "source_id": "13e96486-7b36-40ed-b8d1-dba1b67af4e4",
              "version_id": "4616e967-6d87-451e-b539-23075c3a280f"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 168,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 167,
            "excerpt_sha256": "0ffcf3510daf9f79379626ac840316bd743e81898e67749ca7b57f7c7404cdef",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 167,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 55
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 167,
              "excerpt_sha256": "0ffcf3510daf9f79379626ac840316bd743e81898e67749ca7b57f7c7404cdef",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "9e841dab76ba56ce47d44bf4211f32c2d8cd5e7e1d902e655e09a47a7f32a011",
          "byte_length": 3053
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "7ffd64c12e927b67227f0a504ed90c7423c08cc1f98a0fb4852f8e1f87d4008b",
          "byte_length": 736
        },
        "knowledge-ir.json": {
          "sha256": "f5c820e0496a0cfdd6f0f7cec510abfa5f32f830d554ddd46fed173313423cae",
          "byte_length": 12391
        },
        "review-original.json": {
          "sha256": "d8c559f0755f06ade356dadfa80d725a1f0dbfb43650f0dda98d6c9b970c333c",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "dd7b9a45f0edadc91fe7a02b4eba5e160808feb1b7add9d05e8902a1778a5990",
          "byte_length": 1058
        },
        "verification.json": {
          "sha256": "cd2347bc9d275ce53658f9c53cb2c8a172c8cc469da5cf7678022d261a6b942c",
          "byte_length": 16866
        },
        "verification.md": {
          "sha256": "daa80e200e7d71f9f9e41d660d9f233fa1d6b25c0155dd7833ded5656b571c04",
          "byte_length": 17300
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": 0
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 167,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "0ffcf3510daf9f79379626ac840316bd743e81898e67749ca7b57f7c7404cdef"
      },
      "occurrence_id": "occ-79a9195dfe58836a8d4b1842fdd61f74b1e9c0d1f8ce582f9fc95e7fb9af62aa",
      "input_id": "b",
      "binding": {
        "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
        "import_id": "a97550c4-306e-4a75-8bd9-55e552555e6a",
        "source_id": "13e96486-7b36-40ed-b8d1-dba1b67af4e4",
        "version_id": "4616e967-6d87-451e-b539-23075c3a280f",
        "content_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
        "normalized_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "0f51234b-8872-44ea-97ff-73528a954995",
          "ordinal": 0,
          "resource_sha256": "cc9d09c564508500219f5bf5752924b41e6aaca964569ac431ee379d096625b0"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 168,
        "text": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 167,
          "excerpt_sha256": "0ffcf3510daf9f79379626ac840316bd743e81898e67749ca7b57f7c7404cdef",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 167,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-9ee5ce5fad1246037891338ede0311e76039ca034322c8e904d6c05e65155de2",
      "input_id": "a",
      "binding": {
        "project_id": "80837c37-25b0-4c79-ae06-5a77ee283348",
        "import_id": "91a33174-4353-4546-ba0d-44ad3869ef31",
        "source_id": "faacd37f-5ca9-41b2-add6-c1c9b24b9728",
        "version_id": "867924ac-0fa8-4337-bb97-e69fbeb97cb2",
        "content_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
        "normalized_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "12d1e10c-a54b-4d73-b0ee-6d186f35799c",
          "ordinal": 0,
          "resource_sha256": "bcda91c1229a5939dd96a918dd473214b01a24201503c0dbe5d303f516fe87ea"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 168,
        "text": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 167,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": 0
      },
      "fact_id": "fact-v3-3318e88e3f09b2d40911897027fe53b7a0bb41ca5ffb8b49b124143d7f4b6317",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-79a9195dfe58836a8d4b1842fdd61f74b1e9c0d1f8ce582f9fc95e7fb9af62aa"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v3-c5a8399d0d6ebd7030791b54adadfc750152996665908582746b7a9dc0e81b1e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-9ee5ce5fad1246037891338ede0311e76039ca034322c8e904d6c05e65155de2"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-79a9195dfe58836a8d4b1842fdd61f74b1e9c0d1f8ce582f9fc95e7fb9af62aa",
      "right_occurrence_id": "occ-9ee5ce5fad1246037891338ede0311e76039ca034322c8e904d6c05e65155de2",
      "relation": "insufficient_evidence",
      "issue_code": "COORD_TIME_NOT_COMPARABLE"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-79a9195dfe58836a8d4b1842fdd61f74b1e9c0d1f8ce582f9fc95e7fb9af62aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TIME_NOT_COMPARABLE"
    },
    {
      "occurrence_id": "occ-9ee5ce5fad1246037891338ede0311e76039ca034322c8e904d6c05e65155de2",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TIME_NOT_COMPARABLE"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 1,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 2,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "11e49485c704395a35f5eceed00902268e5ab74c84634bb07cf2ab8f9238652a",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "9ae153b4f1682f2bcf2dcc3b45344fbf67f5d4582c7b52776304a9c65e8f9490",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "610ca5682d13c223f5cca5ff2c2a207c11414442d024e5347463e2955e0b7527",
      "byte_length": 1894
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "146c8d5263466ebce210b8ff67cd450601d25a7d7512b91d1070c3a1932f13ff",
      "byte_length": 3053
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "3b841dd1a43ed4bc71fbff817f24e94ab50ba4bc809dbb4d20fdeeb7f609638d",
      "byte_length": 736
    },
    "input-a--knowledge-ir.json": {
      "sha256": "654e3d9036a5f0d150757c02483e8d8f0723926ef3ec73a8dc55b285a1fddf3d",
      "byte_length": 12391
    },
    "input-a--review-original.json": {
      "sha256": "84cd5e2f110aedfd69eff1564f5c5d54914f8bbcce8f491ad633bebaf8d5e365",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "de053f4dbb1100db7bd0de882276731b3877f3f82ee259f6106b000ca262c80e",
      "byte_length": 1058
    },
    "input-a--verification.json": {
      "sha256": "68a7ddeec9772555b7ccd51ec812f23bcf97df8c13ef3613175aabdb40f4dfd4",
      "byte_length": 16866
    },
    "input-a--verification.md": {
      "sha256": "0bf31fdbe03ab9813430f4e57c645d65a3adcc6dab23208ed76ec34625c75d08",
      "byte_length": 17300
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "9e841dab76ba56ce47d44bf4211f32c2d8cd5e7e1d902e655e09a47a7f32a011",
      "byte_length": 3053
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "7ffd64c12e927b67227f0a504ed90c7423c08cc1f98a0fb4852f8e1f87d4008b",
      "byte_length": 736
    },
    "input-b--knowledge-ir.json": {
      "sha256": "f5c820e0496a0cfdd6f0f7cec510abfa5f32f830d554ddd46fed173313423cae",
      "byte_length": 12391
    },
    "input-b--review-original.json": {
      "sha256": "d8c559f0755f06ade356dadfa80d725a1f0dbfb43650f0dda98d6c9b970c333c",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "dd7b9a45f0edadc91fe7a02b4eba5e160808feb1b7add9d05e8902a1778a5990",
      "byte_length": 1058
    },
    "input-b--verification.json": {
      "sha256": "cd2347bc9d275ce53658f9c53cb2c8a172c8cc469da5cf7678022d261a6b942c",
      "byte_length": 16866
    },
    "input-b--verification.md": {
      "sha256": "daa80e200e7d71f9f9e41d660d9f233fa1d6b25c0155dd7833ded5656b571c04",
      "byte_length": 17300
    }
  }
}
```
