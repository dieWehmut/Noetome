# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：1；证据不足关系：0；反证链接：1。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "895a1b65-d5a3-438f-8001-90ce6cc3b966",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
        "import_id": "99253959-d1a0-4f2c-b1cc-0e9bbc5d6bc9",
        "source_id": "7d72d644-b51e-4f88-9d52-ca9b5d4b2c3e",
        "version_id": "bbb9f79a-6a8a-4711-b97a-242f067f9ccd",
        "content_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
        "normalized_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
              "import_id": "99253959-d1a0-4f2c-b1cc-0e9bbc5d6bc9",
              "manifest_sha256": null,
              "normalized_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
              "parse_id": null,
              "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
              "source_id": "7d72d644-b51e-4f88-9d52-ca9b5d4b2c3e",
              "version_id": "bbb9f79a-6a8a-4711-b97a-242f067f9ccd"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
              "import_id": "99253959-d1a0-4f2c-b1cc-0e9bbc5d6bc9",
              "manifest_sha256": null,
              "normalized_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
              "parse_id": null,
              "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
              "source_id": "7d72d644-b51e-4f88-9d52-ca9b5d4b2c3e",
              "version_id": "bbb9f79a-6a8a-4711-b97a-242f067f9ccd"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 235,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 235,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "ab496ac17ef6d1aa7eda8c2cd0ac7b8674d6ac2db11d658c0dbf34dff2e71141",
          "byte_length": 3495
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "ffe03d935098618e80ccfa74daaa5df06834102b69e74c177543745ef229548c",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "396fbfa66143834c30ff8a3dc162af281bb2e18f0cb585301730c5cee9e38af6",
          "byte_length": 12809
        },
        "review-original.json": {
          "sha256": "0847d96c71b9119dddce48bdb10ca38d2b6f280a7bf7ce934c74d9f763953c79",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "4b62d26f5e67b127aa9a760d93ec33c7f1b24d415e4967f677c3d21540065169",
          "byte_length": 1126
        },
        "verification.json": {
          "sha256": "74e2e7ade0a5a166f7a164b4e5fd9a45c1613b266bbb31bceb454f4c6ae7d929",
          "byte_length": 16939
        },
        "verification.md": {
          "sha256": "3e1ef7656b5910c1e8cc78faca52373575630710e844891bcdf56a28b055b47b",
          "byte_length": 17373
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
        "import_id": "e3ff9957-5873-43ac-b4dc-09a36a3a19c0",
        "source_id": "a1258a7a-2582-4d37-ac63-e01bd36aaf74",
        "version_id": "1714a6e8-838d-4f8a-ad59-435c8f430164",
        "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "import_id": "e3ff9957-5873-43ac-b4dc-09a36a3a19c0",
              "manifest_sha256": null,
              "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "parse_id": null,
              "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
              "source_id": "a1258a7a-2582-4d37-ac63-e01bd36aaf74",
              "version_id": "1714a6e8-838d-4f8a-ad59-435c8f430164"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "import_id": "e3ff9957-5873-43ac-b4dc-09a36a3a19c0",
              "manifest_sha256": null,
              "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "parse_id": null,
              "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
              "source_id": "a1258a7a-2582-4d37-ac63-e01bd36aaf74",
              "version_id": "1714a6e8-838d-4f8a-ad59-435c8f430164"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "51956296bf544c569ef4059efc438b50e5b6e34e11c681ad7a9af606cba2aeff",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0ffdf2514c70543a28c2bfa815784818f99d4af6d06ef17e79411f159d3b6604",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "a1576aaeb6e8b73535b92031b0f6755d3460e9c35f645dcc8873fc159ec7f88f",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "c7689ddf55c3459d798eba9550ec3cb8318fafe9ebbf3934538b5566af3b81ca",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "300130796a336641e57102cbac059e8f08ef35eb27f9ea5e8f9d6d2877e4d987",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "56b268aaccd01a10c596e0832407b0ad455d5dd947240ab08674f557f72321da",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "db0dfa55d6ee9a982f6253bbcbad8895399babb591b935e817fb9209122fc0bd",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-0df10743fb20fd53ba1b95eda5e1b2aeba815da5b2643248d1caa84929da55dc",
      "input_id": "a",
      "binding": {
        "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
        "import_id": "99253959-d1a0-4f2c-b1cc-0e9bbc5d6bc9",
        "source_id": "7d72d644-b51e-4f88-9d52-ca9b5d4b2c3e",
        "version_id": "bbb9f79a-6a8a-4711-b97a-242f067f9ccd",
        "content_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
        "normalized_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "df1eec88-c0d2-4992-bb2c-e1fbdc9b0a68",
          "ordinal": 0,
          "resource_sha256": "7c430107111b430f9ec2807f4b27361b01df82b4d37eba77ba575d13fb1752c8"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 235,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n反证记录：同一范围的速度 10 m/s 不获本来源支持。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            },
            {
              "evidence_id": "a-refutes",
              "relation": "refutes"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "evidence_id": "a-refutes",
          "unit_id": "unit-0",
          "excerpt_start_byte": 166,
          "excerpt_end_byte": 234,
          "excerpt_sha256": "f57fc701519abe86bce4fb6e8bf44162043b5e1e5227155b464d6e7587fe63bd",
          "quote": "反证记录：同一范围的速度 10 m/s 不获本来源支持。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666"
      },
      "occurrence_id": "occ-59c926a3f04b6ff640318a74b9def0595d278cef0404e1f14017644e8563a255",
      "input_id": "b",
      "binding": {
        "project_id": "a1e646f6-c501-4147-99ea-a19cb6403c6e",
        "import_id": "e3ff9957-5873-43ac-b4dc-09a36a3a19c0",
        "source_id": "a1258a7a-2582-4d37-ac63-e01bd36aaf74",
        "version_id": "1714a6e8-838d-4f8a-ad59-435c8f430164",
        "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "43366542-4208-4255-b15b-803dd42b84f9",
          "ordinal": 0,
          "resource_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-71585ac2caed36414e2692879ef09222ae8e60dcf8eef7c928b2ccd0b2ff2bfd",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-0df10743fb20fd53ba1b95eda5e1b2aeba815da5b2643248d1caa84929da55dc"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-8247ec69399ea4a69c02ec0091daaa89fe400b591013802493c29b849e4fee4e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-59c926a3f04b6ff640318a74b9def0595d278cef0404e1f14017644e8563a255"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-0df10743fb20fd53ba1b95eda5e1b2aeba815da5b2643248d1caa84929da55dc",
      "right_occurrence_id": "occ-59c926a3f04b6ff640318a74b9def0595d278cef0404e1f14017644e8563a255",
      "relation": "true_conflict",
      "issue_code": "COORD_TRUE_CONFLICT"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-0df10743fb20fd53ba1b95eda5e1b2aeba815da5b2643248d1caa84929da55dc",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    },
    {
      "occurrence_id": "occ-59c926a3f04b6ff640318a74b9def0595d278cef0404e1f14017644e8563a255",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    }
  ],
  "totals": {
    "true_conflicts": 1,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 2,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 1,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 3,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "606df42bfdbb8060d7285480ad741c4d5f034ef558a0896a45abe6e730f9eda4",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "ce62edc050e6558f3d787b07b47c739cbdc4deb2a67408b8d362d27406aabc71",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "dd1378444d203829b6368e908833270c4c80b9fef826c77ea886fd748db71496",
      "byte_length": 1897
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "ab496ac17ef6d1aa7eda8c2cd0ac7b8674d6ac2db11d658c0dbf34dff2e71141",
      "byte_length": 3495
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "ffe03d935098618e80ccfa74daaa5df06834102b69e74c177543745ef229548c",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "396fbfa66143834c30ff8a3dc162af281bb2e18f0cb585301730c5cee9e38af6",
      "byte_length": 12809
    },
    "input-a--review-original.json": {
      "sha256": "0847d96c71b9119dddce48bdb10ca38d2b6f280a7bf7ce934c74d9f763953c79",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "4b62d26f5e67b127aa9a760d93ec33c7f1b24d415e4967f677c3d21540065169",
      "byte_length": 1126
    },
    "input-a--verification.json": {
      "sha256": "74e2e7ade0a5a166f7a164b4e5fd9a45c1613b266bbb31bceb454f4c6ae7d929",
      "byte_length": 16939
    },
    "input-a--verification.md": {
      "sha256": "3e1ef7656b5910c1e8cc78faca52373575630710e844891bcdf56a28b055b47b",
      "byte_length": 17373
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "51956296bf544c569ef4059efc438b50e5b6e34e11c681ad7a9af606cba2aeff",
      "byte_length": 3056
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "0ffdf2514c70543a28c2bfa815784818f99d4af6d06ef17e79411f159d3b6604",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a1576aaeb6e8b73535b92031b0f6755d3460e9c35f645dcc8873fc159ec7f88f",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "c7689ddf55c3459d798eba9550ec3cb8318fafe9ebbf3934538b5566af3b81ca",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "300130796a336641e57102cbac059e8f08ef35eb27f9ea5e8f9d6d2877e4d987",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "56b268aaccd01a10c596e0832407b0ad455d5dd947240ab08674f557f72321da",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "db0dfa55d6ee9a982f6253bbcbad8895399babb591b935e817fb9209122fc0bd",
      "byte_length": 17303
    }
  }
}
```
