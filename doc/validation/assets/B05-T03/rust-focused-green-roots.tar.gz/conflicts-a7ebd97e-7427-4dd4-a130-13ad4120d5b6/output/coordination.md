# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：1；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "e903c4d7-e75d-46d7-a670-111336ffddd1",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
        "import_id": "57e6a527-758d-4036-9020-7e2ac696ddab",
        "source_id": "33623686-cdb0-4597-adf3-2a8a3ea524ce",
        "version_id": "ad1e12e7-9f84-4c30-919d-46cd3a01addb",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "57e6a527-758d-4036-9020-7e2ac696ddab",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
              "source_id": "33623686-cdb0-4597-adf3-2a8a3ea524ce",
              "version_id": "ad1e12e7-9f84-4c30-919d-46cd3a01addb"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "57e6a527-758d-4036-9020-7e2ac696ddab",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
              "source_id": "33623686-cdb0-4597-adf3-2a8a3ea524ce",
              "version_id": "ad1e12e7-9f84-4c30-919d-46cd3a01addb"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "71e4d893b6ba22f5f7eeb58a39accc5666cc2e912d1d541af2c272a738b3565e",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "ffe03d935098618e80ccfa74daaa5df06834102b69e74c177543745ef229548c",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "2c49009fe924613b9412f8ee6290c9c195157a82d5737c10a0f81da9c73426a9",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "0847d96c71b9119dddce48bdb10ca38d2b6f280a7bf7ce934c74d9f763953c79",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "99beb58b486981d16e9e41b49b200e11a10cb7a656fa9aaca1fccfb207ddd2bd",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "c180aceff73183b220f7c99cd5abaf4bfb0c23c359567516ec0b24113f876723",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "4c92f589c225fb8ea4bb61cb7c2445687ec6f4c44f49cbc8e3f378f13d425235",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
        "import_id": "5d1d7a65-f0bd-40b8-b44c-66228ef9e217",
        "source_id": "d27f7a03-b4ec-443a-bdc7-0bfef623b2a5",
        "version_id": "a082b52d-b2ac-4737-a988-485bd3bd9959",
        "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "import_id": "5d1d7a65-f0bd-40b8-b44c-66228ef9e217",
              "manifest_sha256": null,
              "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "parse_id": null,
              "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
              "source_id": "d27f7a03-b4ec-443a-bdc7-0bfef623b2a5",
              "version_id": "a082b52d-b2ac-4737-a988-485bd3bd9959"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "import_id": "5d1d7a65-f0bd-40b8-b44c-66228ef9e217",
              "manifest_sha256": null,
              "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "parse_id": null,
              "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
              "source_id": "d27f7a03-b4ec-443a-bdc7-0bfef623b2a5",
              "version_id": "a082b52d-b2ac-4737-a988-485bd3bd9959"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "a1384922d11c08c600e9079bb6c3038c9a39b8981a46eafc1fef53e5df5287cd",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0ffdf2514c70543a28c2bfa815784818f99d4af6d06ef17e79411f159d3b6604",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "efbe2e0d599bacc275dadd8d779570787b1f6fbfd34f12664cfea1ec600ba1fc",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "c7689ddf55c3459d798eba9550ec3cb8318fafe9ebbf3934538b5566af3b81ca",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "d70336d41d667f363167069ff2ed8d756db8b7c17ca52df9993b39154a35e0f5",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "ee12f50b90200314e089c552fccb29d5d31cfd6d74913da320bb8abbb1e50ce1",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "c2b8284e0394fa294bac432586bc4dc30c819ef62947e085541a76286a77cf53",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666"
      },
      "occurrence_id": "occ-15fd6122a6f063c045ea01594a8fb62484b174447f9cd8303beeb16f346fe74c",
      "input_id": "b",
      "binding": {
        "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
        "import_id": "5d1d7a65-f0bd-40b8-b44c-66228ef9e217",
        "source_id": "d27f7a03-b4ec-443a-bdc7-0bfef623b2a5",
        "version_id": "a082b52d-b2ac-4737-a988-485bd3bd9959",
        "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "59f1c5b8-e222-4fe2-b228-dcfad3d9e424",
          "ordinal": 0,
          "resource_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-5dac9e20f8d263195c611a5f111ad0f24233e37119c0a43b34a1ab5c56827766",
      "input_id": "a",
      "binding": {
        "project_id": "1a299ffa-dd63-4e7c-87d0-1c0963902f3b",
        "import_id": "57e6a527-758d-4036-9020-7e2ac696ddab",
        "source_id": "33623686-cdb0-4597-adf3-2a8a3ea524ce",
        "version_id": "ad1e12e7-9f84-4c30-919d-46cd3a01addb",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "314e49b2-f724-4e84-9f18-7185830e374c",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-71585ac2caed36414e2692879ef09222ae8e60dcf8eef7c928b2ccd0b2ff2bfd",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-5dac9e20f8d263195c611a5f111ad0f24233e37119c0a43b34a1ab5c56827766"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-8247ec69399ea4a69c02ec0091daaa89fe400b591013802493c29b849e4fee4e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-15fd6122a6f063c045ea01594a8fb62484b174447f9cd8303beeb16f346fe74c"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-15fd6122a6f063c045ea01594a8fb62484b174447f9cd8303beeb16f346fe74c",
      "right_occurrence_id": "occ-5dac9e20f8d263195c611a5f111ad0f24233e37119c0a43b34a1ab5c56827766",
      "relation": "true_conflict",
      "issue_code": "COORD_TRUE_CONFLICT"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-15fd6122a6f063c045ea01594a8fb62484b174447f9cd8303beeb16f346fe74c",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    },
    {
      "occurrence_id": "occ-5dac9e20f8d263195c611a5f111ad0f24233e37119c0a43b34a1ab5c56827766",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    }
  ],
  "totals": {
    "true_conflicts": 1,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 2,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "1cd131fe757b675f0d03fea6e4b80448ac3d39ac6ed937b0e4b979aca0a74198",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "ea745584d341dd95c49f692fdcdad23a53243b3d71226ee283e5dfe3b3b9471c",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "dd1378444d203829b6368e908833270c4c80b9fef826c77ea886fd748db71496",
      "byte_length": 1897
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "71e4d893b6ba22f5f7eeb58a39accc5666cc2e912d1d541af2c272a738b3565e",
      "byte_length": 3056
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "ffe03d935098618e80ccfa74daaa5df06834102b69e74c177543745ef229548c",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "2c49009fe924613b9412f8ee6290c9c195157a82d5737c10a0f81da9c73426a9",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "0847d96c71b9119dddce48bdb10ca38d2b6f280a7bf7ce934c74d9f763953c79",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "99beb58b486981d16e9e41b49b200e11a10cb7a656fa9aaca1fccfb207ddd2bd",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "c180aceff73183b220f7c99cd5abaf4bfb0c23c359567516ec0b24113f876723",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "4c92f589c225fb8ea4bb61cb7c2445687ec6f4c44f49cbc8e3f378f13d425235",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "a1384922d11c08c600e9079bb6c3038c9a39b8981a46eafc1fef53e5df5287cd",
      "byte_length": 3056
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "0ffdf2514c70543a28c2bfa815784818f99d4af6d06ef17e79411f159d3b6604",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "efbe2e0d599bacc275dadd8d779570787b1f6fbfd34f12664cfea1ec600ba1fc",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "c7689ddf55c3459d798eba9550ec3cb8318fafe9ebbf3934538b5566af3b81ca",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "d70336d41d667f363167069ff2ed8d756db8b7c17ca52df9993b39154a35e0f5",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "ee12f50b90200314e089c552fccb29d5d31cfd6d74913da320bb8abbb1e50ce1",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "c2b8284e0394fa294bac432586bc4dc30c819ef62947e085541a76286a77cf53",
      "byte_length": 17303
    }
  }
}
```
