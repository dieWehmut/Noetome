# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：1；条件未知：1；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "3cd7e187-a241-4b67-b87f-5881df152127",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000003",
      "display_name": "质量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
        "import_id": "5b4bfa9a-2710-4657-b88a-a7d21fbb32c9",
        "source_id": "87a22e5e-5f28-4a6f-b3a0-4896b7e7caac",
        "version_id": "7b6fba6f-9def-49ec-9098-4e4327c06122",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "5b4bfa9a-2710-4657-b88a-a7d21fbb32c9",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
              "source_id": "87a22e5e-5f28-4a6f-b3a0-4896b7e7caac",
              "version_id": "7b6fba6f-9def-49ec-9098-4e4327c06122"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "5b4bfa9a-2710-4657-b88a-a7d21fbb32c9",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
              "source_id": "87a22e5e-5f28-4a6f-b3a0-4896b7e7caac",
              "version_id": "7b6fba6f-9def-49ec-9098-4e4327c06122"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "cea616123431833a1b3e0da98996cc8b939e8f1d5c2cb49164c51cec821d9a0d",
          "byte_length": 2713
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0df2868395538c730fc55fe39b187c3727c9cb9d19ce9442ce27a8a46230a378",
          "byte_length": 491
        },
        "knowledge-ir.json": {
          "sha256": "48816d0199ab32a768dd60faab0118dd3c05492f0f7c349e1e9fffe03e1e2795",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e3fcff1c7f74554fec152d40633fb23641bc7324f0d8e5eed2ddb668a88b7a7d",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "a8ca5c37bb66ed46e79dc456e915c8c1cd376acaea539bac0a4e01b2302b39e7",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "83689f4f6dbfd26194bc73487b895fa91181682ee965de0a8d0554e74fba0d05",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "4d2c6ed4f9b99f3f57af5432ec2404c8b8f53daea9980757f0b8accdd1dc6b5b",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
        "import_id": "94bf9b8e-6939-44c9-9e7b-0676ce63cfb0",
        "source_id": "4415537e-c37f-4dae-bcb6-d02c7dbc289d",
        "version_id": "e67963fb-b8ba-4408-9008-5844ab37f047",
        "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-mass"
            ],
            "decision": {
              "atom_ids": [
                "b-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "import_id": "94bf9b8e-6939-44c9-9e7b-0676ce63cfb0",
              "manifest_sha256": null,
              "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "parse_id": null,
              "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
              "source_id": "4415537e-c37f-4dae-bcb6-d02c7dbc289d",
              "version_id": "e67963fb-b8ba-4408-9008-5844ab37f047"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "import_id": "94bf9b8e-6939-44c9-9e7b-0676ce63cfb0",
              "manifest_sha256": null,
              "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "parse_id": null,
              "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
              "source_id": "4415537e-c37f-4dae-bcb6-d02c7dbc289d",
              "version_id": "e67963fb-b8ba-4408-9008-5844ab37f047"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 164,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 163,
            "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "quote": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 163,
              "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "3",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "kg",
            "value": "3",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "395601ee6e6b4adf8285198add55b398b1ca3d8ab743ad798a829a40f4ea86e1",
          "byte_length": 3048
        },
        "decision-original.json": {
          "sha256": "51090d899297ab9f797b54daf93b4ba7f5f2bc6b03d52e557ff7c2763bb91cea",
          "byte_length": 139
        },
        "gold-original.json": {
          "sha256": "3c406bad5f83697b4da1b07f6bd3a44afa3d51494b7b88c2f2bd3ccd226c2607",
          "byte_length": 729
        },
        "knowledge-ir.json": {
          "sha256": "e53245e28ee2e907bff619e8509573d41b744954df17284d1f78dd73acc51842",
          "byte_length": 12349
        },
        "review-original.json": {
          "sha256": "bdc323abd3b870289bd724eb9f8e643fb9304d46489938badb58c57dfe29c566",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "fb582560cbc521f87cdc731ef095f85331d6d70ec088442243fb4cd18d98a43b",
          "byte_length": 1054
        },
        "verification.json": {
          "sha256": "5809b7c2ff3952e848c22f81b7a9c03e39ff5d2de0b6cbb2184a997d217cdae5",
          "byte_length": 16829
        },
        "verification.md": {
          "sha256": "f6301c3ea6766da94523fa069cd907e7b02d4f505b030b58099f3b83f1ef193e",
          "byte_length": 17263
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-7555817c7697560ec8f16fa3d2ab3241c46e33dc2772b409be0dbe068e35c2db",
      "input_id": "a",
      "binding": {
        "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
        "import_id": "5b4bfa9a-2710-4657-b88a-a7d21fbb32c9",
        "source_id": "87a22e5e-5f28-4a6f-b3a0-4896b7e7caac",
        "version_id": "7b6fba6f-9def-49ec-9098-4e4327c06122",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "8ea30bb1-2bad-46e6-a336-1a995405b5bd",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 163,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff"
      },
      "occurrence_id": "occ-dabf9a71cf0c69a078563dc532d0c9846235c7941da3996e99da874769d41d03",
      "input_id": "b",
      "binding": {
        "project_id": "0c8835b5-f4f8-4753-9b04-64d54076041b",
        "import_id": "94bf9b8e-6939-44c9-9e7b-0676ce63cfb0",
        "source_id": "4415537e-c37f-4dae-bcb6-d02c7dbc289d",
        "version_id": "e67963fb-b8ba-4408-9008-5844ab37f047",
        "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "70af5c19-9863-48d7-9494-a6d12c906759",
          "ordinal": 0,
          "resource_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "3",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 163,
          "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000003"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "value": "3",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-3cf5b5dfe6841b7a58b4328a6079fada3e7fef5eb5a014a738a4c3e1351ae419",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "3",
      "unit": "kg",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-dabf9a71cf0c69a078563dc532d0c9846235c7941da3996e99da874769d41d03"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-8c1f2d690ccc7a055376e05407d10602a1101c2f06bc364de6c1ba12ca448830",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-7555817c7697560ec8f16fa3d2ab3241c46e33dc2772b409be0dbe068e35c2db"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-7555817c7697560ec8f16fa3d2ab3241c46e33dc2772b409be0dbe068e35c2db",
      "right_occurrence_id": "occ-dabf9a71cf0c69a078563dc532d0c9846235c7941da3996e99da874769d41d03",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-7555817c7697560ec8f16fa3d2ab3241c46e33dc2772b409be0dbe068e35c2db",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    },
    {
      "occurrence_id": "occ-dabf9a71cf0c69a078563dc532d0c9846235c7941da3996e99da874769d41d03",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 1,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 1,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 1,
    "failed": 0,
    "needs_review": 1,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "975a3bbe4266d93398f78283d8c266462fff941dadcacb4c36d4bae288c9383a",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "382c1f5e182fb20ba1090743505ae5d174424526e5170573afa3cb2d29c541f3",
      "byte_length": 4327
    },
    "identity-original.json": {
      "sha256": "d2fb74566931e430b7419d7368dc2ee0cc3885725d64ac367372a290619c0592",
      "byte_length": 2003
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "cea616123431833a1b3e0da98996cc8b939e8f1d5c2cb49164c51cec821d9a0d",
      "byte_length": 2713
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "0df2868395538c730fc55fe39b187c3727c9cb9d19ce9442ce27a8a46230a378",
      "byte_length": 491
    },
    "input-a--knowledge-ir.json": {
      "sha256": "48816d0199ab32a768dd60faab0118dd3c05492f0f7c349e1e9fffe03e1e2795",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e3fcff1c7f74554fec152d40633fb23641bc7324f0d8e5eed2ddb668a88b7a7d",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "a8ca5c37bb66ed46e79dc456e915c8c1cd376acaea539bac0a4e01b2302b39e7",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "83689f4f6dbfd26194bc73487b895fa91181682ee965de0a8d0554e74fba0d05",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "4d2c6ed4f9b99f3f57af5432ec2404c8b8f53daea9980757f0b8accdd1dc6b5b",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "395601ee6e6b4adf8285198add55b398b1ca3d8ab743ad798a829a40f4ea86e1",
      "byte_length": 3048
    },
    "input-b--decision-original.json": {
      "sha256": "51090d899297ab9f797b54daf93b4ba7f5f2bc6b03d52e557ff7c2763bb91cea",
      "byte_length": 139
    },
    "input-b--gold-original.json": {
      "sha256": "3c406bad5f83697b4da1b07f6bd3a44afa3d51494b7b88c2f2bd3ccd226c2607",
      "byte_length": 729
    },
    "input-b--knowledge-ir.json": {
      "sha256": "e53245e28ee2e907bff619e8509573d41b744954df17284d1f78dd73acc51842",
      "byte_length": 12349
    },
    "input-b--review-original.json": {
      "sha256": "bdc323abd3b870289bd724eb9f8e643fb9304d46489938badb58c57dfe29c566",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "fb582560cbc521f87cdc731ef095f85331d6d70ec088442243fb4cd18d98a43b",
      "byte_length": 1054
    },
    "input-b--verification.json": {
      "sha256": "5809b7c2ff3952e848c22f81b7a9c03e39ff5d2de0b6cbb2184a997d217cdae5",
      "byte_length": 16829
    },
    "input-b--verification.md": {
      "sha256": "f6301c3ea6766da94523fa069cd907e7b02d4f505b030b58099f3b83f1ef193e",
      "byte_length": 17263
    }
  }
}
```
