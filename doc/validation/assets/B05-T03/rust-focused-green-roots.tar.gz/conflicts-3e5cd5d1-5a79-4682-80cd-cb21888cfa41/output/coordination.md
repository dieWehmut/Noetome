# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：1；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "c08d7b07-7c80-4890-9db8-138d31edf2f4",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
        "import_id": "78701c12-f282-4ae7-a19d-9f9f71b811f2",
        "source_id": "36209695-af2e-4788-a0e2-2ad41d41a9f1",
        "version_id": "760585e7-d147-4a8c-9c4d-2040fa099660",
        "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "import_id": "78701c12-f282-4ae7-a19d-9f9f71b811f2",
              "manifest_sha256": null,
              "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "parse_id": null,
              "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
              "source_id": "36209695-af2e-4788-a0e2-2ad41d41a9f1",
              "version_id": "760585e7-d147-4a8c-9c4d-2040fa099660"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "import_id": "78701c12-f282-4ae7-a19d-9f9f71b811f2",
              "manifest_sha256": null,
              "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "parse_id": null,
              "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
              "source_id": "36209695-af2e-4788-a0e2-2ad41d41a9f1",
              "version_id": "760585e7-d147-4a8c-9c4d-2040fa099660"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 206,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 205,
            "excerpt_sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 205,
              "excerpt_sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "100000000000000000000000000000000000000001",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "100000000000000000000000000000000000000001",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "9ee2931e03393cf2c6836d1f36d43240496ff087802f6888f1127330bb86c769",
          "byte_length": 3176
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "283cc3ec29159b5d07b79dca514407eff6c56f2ae2906764deb43b138d2c9800",
          "byte_length": 855
        },
        "knowledge-ir.json": {
          "sha256": "9e5f8d7fc26b975e2971575f90a9e650d60c5d6f2a501361af6d4973560a808f",
          "byte_length": 12834
        },
        "review-original.json": {
          "sha256": "d9cf4e4910303186260c8383183ee16ca9b88ef390328667ce490209fcf1d3c4",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "49729bf95b25d0c2f5ad2ca73d2be14b4fa375938e980fdd084c93fa1c16c728",
          "byte_length": 1096
        },
        "verification.json": {
          "sha256": "fe76b5b638c25c3dd3cf4d454dc571677093db69499a5db09d2e05695ff42e71",
          "byte_length": 17229
        },
        "verification.md": {
          "sha256": "813dd7bc622d6eaf0e82440872d1165e24227b8e4bcbbd49f968bfdc28c77ed9",
          "byte_length": 17663
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
        "import_id": "1e2e41af-d238-4071-b2ca-caadc8c7409b",
        "source_id": "bb9a9cbf-e153-46b3-bb3b-614dbfdd6fbd",
        "version_id": "3e8293ed-ba6b-4cc8-85e4-f906e00b5ceb",
        "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "import_id": "1e2e41af-d238-4071-b2ca-caadc8c7409b",
              "manifest_sha256": null,
              "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "parse_id": null,
              "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
              "source_id": "bb9a9cbf-e153-46b3-bb3b-614dbfdd6fbd",
              "version_id": "3e8293ed-ba6b-4cc8-85e4-f906e00b5ceb"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "import_id": "1e2e41af-d238-4071-b2ca-caadc8c7409b",
              "manifest_sha256": null,
              "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "parse_id": null,
              "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
              "source_id": "bb9a9cbf-e153-46b3-bb3b-614dbfdd6fbd",
              "version_id": "3e8293ed-ba6b-4cc8-85e4-f906e00b5ceb"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 206,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 205,
            "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 205,
              "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "100000000000000000000000000000000000000002",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "100000000000000000000000000000000000000002",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "d077abfbd852d9fb741011abf5580501e283e381f7805c9f8c25a77b147994c9",
          "byte_length": 3176
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "d471df96779d59237aa16ab77b93fa5dbada92fb62c314a628e275ce111d97f1",
          "byte_length": 855
        },
        "knowledge-ir.json": {
          "sha256": "72c895fd3f630907d77a2d3fb3f5a4a31526cc4b69b65a7fe66599b25f052eca",
          "byte_length": 12834
        },
        "review-original.json": {
          "sha256": "f3127383417d2a935f2f227c0999a66ca5012613b6f0545a0e3d4cc61c5e0808",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "a513980524a47d78ad6e387d1824954b1c0efa02372163a420279ffc0b0326f9",
          "byte_length": 1096
        },
        "verification.json": {
          "sha256": "3088bb38e57d0a7a13bb3c4b43f9056f4871b60651cc188d825196b09d2179f2",
          "byte_length": 17229
        },
        "verification.md": {
          "sha256": "65965202362b4e92fe80f4a129c7851087c61284dff4631f233fe84b05716187",
          "byte_length": 17663
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90"
      },
      "occurrence_id": "occ-5120f718db5eb134848ba39140b80c38d08e5e54bc0592f4cddc7d706014d691",
      "input_id": "a",
      "binding": {
        "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
        "import_id": "78701c12-f282-4ae7-a19d-9f9f71b811f2",
        "source_id": "36209695-af2e-4788-a0e2-2ad41d41a9f1",
        "version_id": "760585e7-d147-4a8c-9c4d-2040fa099660",
        "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "55784e8b-36df-40e1-afa1-acccabc9c3f4",
          "ordinal": 0,
          "resource_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 206,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "100000000000000000000000000000000000000001",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 205,
          "excerpt_sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "100000000000000000000000000000000000000001",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc"
      },
      "occurrence_id": "occ-aeee1180e42b748003f37926fce0812c1cac7c57d81f7b0dd2dd47048da62770",
      "input_id": "b",
      "binding": {
        "project_id": "17fd48f0-2bb1-4f30-af3c-c3d6aa84e028",
        "import_id": "1e2e41af-d238-4071-b2ca-caadc8c7409b",
        "source_id": "bb9a9cbf-e153-46b3-bb3b-614dbfdd6fbd",
        "version_id": "3e8293ed-ba6b-4cc8-85e4-f906e00b5ceb",
        "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "895354b6-f099-41ea-98db-b5f253c5b275",
          "ordinal": 0,
          "resource_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 206,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "100000000000000000000000000000000000000002",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 205,
          "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "100000000000000000000000000000000000000002",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-5c2d1fe385927c51f60c1d87e9bf66fc794dd99b79980937a97af1da7695da2d",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "100000000000000000000000000000000000000002",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-aeee1180e42b748003f37926fce0812c1cac7c57d81f7b0dd2dd47048da62770"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-7ee4c75cae9b2a74d4c616abd902c02abeac3485e3817fbdc8190f4538679f02",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "100000000000000000000000000000000000000001",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-5120f718db5eb134848ba39140b80c38d08e5e54bc0592f4cddc7d706014d691"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-5120f718db5eb134848ba39140b80c38d08e5e54bc0592f4cddc7d706014d691",
      "right_occurrence_id": "occ-aeee1180e42b748003f37926fce0812c1cac7c57d81f7b0dd2dd47048da62770",
      "relation": "true_conflict",
      "issue_code": "COORD_TRUE_CONFLICT"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-5120f718db5eb134848ba39140b80c38d08e5e54bc0592f4cddc7d706014d691",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    },
    {
      "occurrence_id": "occ-aeee1180e42b748003f37926fce0812c1cac7c57d81f7b0dd2dd47048da62770",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    }
  ],
  "totals": {
    "true_conflicts": 1,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 2,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "daf6f6e6a7587989a36612514a3bdeb44c2ee90b848f00a7eb254d328cdaaada",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "5c4807a66d6c1d2131fb3da057a9856863664e6bc34b0ad9eb6632d038b31b45",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "dd1378444d203829b6368e908833270c4c80b9fef826c77ea886fd748db71496",
      "byte_length": 1897
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "9ee2931e03393cf2c6836d1f36d43240496ff087802f6888f1127330bb86c769",
      "byte_length": 3176
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "283cc3ec29159b5d07b79dca514407eff6c56f2ae2906764deb43b138d2c9800",
      "byte_length": 855
    },
    "input-a--knowledge-ir.json": {
      "sha256": "9e5f8d7fc26b975e2971575f90a9e650d60c5d6f2a501361af6d4973560a808f",
      "byte_length": 12834
    },
    "input-a--review-original.json": {
      "sha256": "d9cf4e4910303186260c8383183ee16ca9b88ef390328667ce490209fcf1d3c4",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "49729bf95b25d0c2f5ad2ca73d2be14b4fa375938e980fdd084c93fa1c16c728",
      "byte_length": 1096
    },
    "input-a--verification.json": {
      "sha256": "fe76b5b638c25c3dd3cf4d454dc571677093db69499a5db09d2e05695ff42e71",
      "byte_length": 17229
    },
    "input-a--verification.md": {
      "sha256": "813dd7bc622d6eaf0e82440872d1165e24227b8e4bcbbd49f968bfdc28c77ed9",
      "byte_length": 17663
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "d077abfbd852d9fb741011abf5580501e283e381f7805c9f8c25a77b147994c9",
      "byte_length": 3176
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "d471df96779d59237aa16ab77b93fa5dbada92fb62c314a628e275ce111d97f1",
      "byte_length": 855
    },
    "input-b--knowledge-ir.json": {
      "sha256": "72c895fd3f630907d77a2d3fb3f5a4a31526cc4b69b65a7fe66599b25f052eca",
      "byte_length": 12834
    },
    "input-b--review-original.json": {
      "sha256": "f3127383417d2a935f2f227c0999a66ca5012613b6f0545a0e3d4cc61c5e0808",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "a513980524a47d78ad6e387d1824954b1c0efa02372163a420279ffc0b0326f9",
      "byte_length": 1096
    },
    "input-b--verification.json": {
      "sha256": "3088bb38e57d0a7a13bb3c4b43f9056f4871b60651cc188d825196b09d2179f2",
      "byte_length": 17229
    },
    "input-b--verification.md": {
      "sha256": "65965202362b4e92fe80f4a129c7851087c61284dff4631f233fe84b05716187",
      "byte_length": 17663
    }
  }
}
```
