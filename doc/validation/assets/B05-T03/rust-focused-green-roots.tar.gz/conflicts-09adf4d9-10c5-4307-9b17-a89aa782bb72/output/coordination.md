# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：2；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：1；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "13f55ee5-7112-421b-af3a-453a9f2fc016",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
        "import_id": "5185be8d-8fd8-43e9-a08f-2c054301a7cc",
        "source_id": "4956da93-c11f-419f-bf1d-9cf2468cda70",
        "version_id": "c942eeaa-95fc-404e-847f-f70efab59e58",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "5185be8d-8fd8-43e9-a08f-2c054301a7cc",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
              "source_id": "4956da93-c11f-419f-bf1d-9cf2468cda70",
              "version_id": "c942eeaa-95fc-404e-847f-f70efab59e58"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "5185be8d-8fd8-43e9-a08f-2c054301a7cc",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
              "source_id": "4956da93-c11f-419f-bf1d-9cf2468cda70",
              "version_id": "c942eeaa-95fc-404e-847f-f70efab59e58"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "bb00cbcd53066085dc9ab5cf52c7984c76c060257dad449cf1e07771c609b977",
          "byte_length": 2713
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0df2868395538c730fc55fe39b187c3727c9cb9d19ce9442ce27a8a46230a378",
          "byte_length": 491
        },
        "knowledge-ir.json": {
          "sha256": "afb975f12453ef22686a95f0bbbbd932be863de673633970889b9daedd1599ff",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e3fcff1c7f74554fec152d40633fb23641bc7324f0d8e5eed2ddb668a88b7a7d",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "40c96f309f6bf6421cef7e0f165d6d97894cb470f437b139e8b46b4d106708b5",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "d0a4456641eb3dbf2f32dec9bbf3f130352ec7df74e723b4b9c9e1670d1fb6c8",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "5c0369fece878993e567313080b41f3ce1a1b4b8bbf1af28432e4dca89d5c2c5",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
        "import_id": "916902e5-6c2c-495f-bc31-dbd9ea1095f9",
        "source_id": "4b7d47ff-95b6-44b6-a91f-b6b1ed238478",
        "version_id": "e5188c00-b5d9-4908-84b8-879c665d75c7",
        "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "import_id": "916902e5-6c2c-495f-bc31-dbd9ea1095f9",
              "manifest_sha256": null,
              "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "parse_id": null,
              "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
              "source_id": "4b7d47ff-95b6-44b6-a91f-b6b1ed238478",
              "version_id": "e5188c00-b5d9-4908-84b8-879c665d75c7"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "import_id": "916902e5-6c2c-495f-bc31-dbd9ea1095f9",
              "manifest_sha256": null,
              "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "parse_id": null,
              "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
              "source_id": "4b7d47ff-95b6-44b6-a91f-b6b1ed238478",
              "version_id": "e5188c00-b5d9-4908-84b8-879c665d75c7"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 12 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s。",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "7d834464e95f236ed3ac3323a5e23b7e33cd9c0eda5275b43061dd79ebb63134",
          "byte_length": 2713
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "f5e55e5192a2141bc0ddb658a6d0c73d5ce38699272ff463d72787e425ac971b",
          "byte_length": 491
        },
        "knowledge-ir.json": {
          "sha256": "df5ee04077c7307fc06c24f7cb4c0e4c0c86f6254405bd7f2f2bb04777ac7d65",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "f499407ae2da9de7f8f4d565115f4b5d75d41271c3969d69ae79a1bde49e2302",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "c6d59843a0d89baaabc694f30eb7fa5e75a3dcc04afaeb20032312c2f87d12c7",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "b0dcb8b4027051b956bf5c76d9b8b6e372f64d627cc9c40379cf158068f35616",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "67967a53d805c2582652773c9e59474c99e4dff36748a979d23f746d825c3541",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-4fea624b06552b61243c670e102535452518ea894e545d5bd132713d73538bf4",
      "input_id": "a",
      "binding": {
        "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
        "import_id": "5185be8d-8fd8-43e9-a08f-2c054301a7cc",
        "source_id": "4956da93-c11f-419f-bf1d-9cf2468cda70",
        "version_id": "c942eeaa-95fc-404e-847f-f70efab59e58",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "05f87130-247d-429e-9ca2-f668a34be9b1",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
        "sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b"
      },
      "occurrence_id": "occ-b40b80e90e7739f1b58458dd5c4722308bb89e2c1aee82e2ca55ef97745b2f4d",
      "input_id": "b",
      "binding": {
        "project_id": "b2182a57-b292-4ca3-904a-f3852f75e1d6",
        "import_id": "916902e5-6c2c-495f-bc31-dbd9ea1095f9",
        "source_id": "4b7d47ff-95b6-44b6-a91f-b6b1ed238478",
        "version_id": "e5188c00-b5d9-4908-84b8-879c665d75c7",
        "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "577c6017-d656-48a7-8408-93ca187a4757",
          "ordinal": 0,
          "resource_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-3a1046b34d758285bcc26c6b7b18965888d981c7264578599a443e654d78c532",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-4fea624b06552b61243c670e102535452518ea894e545d5bd132713d73538bf4"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-50830ad31f01ca898569d03ae26527c1cacd9816336f989f64eea6525f2a2956",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-b40b80e90e7739f1b58458dd5c4722308bb89e2c1aee82e2ca55ef97745b2f4d"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-4fea624b06552b61243c670e102535452518ea894e545d5bd132713d73538bf4",
      "right_occurrence_id": "occ-b40b80e90e7739f1b58458dd5c4722308bb89e2c1aee82e2ca55ef97745b2f4d",
      "relation": "insufficient_evidence",
      "issue_code": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-4fea624b06552b61243c670e102535452518ea894e545d5bd132713d73538bf4",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    },
    {
      "occurrence_id": "occ-b40b80e90e7739f1b58458dd5c4722308bb89e2c1aee82e2ca55ef97745b2f4d",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 1,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 2,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 2,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "5b75693c1d847c51998b376ea5bd3632244c147349114db3efc88c0727093bdf",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "bf489715755a41b7f991172bbe403b5e65bc86fccfcbefb6c4fcb03801bcf2d3",
      "byte_length": 4325
    },
    "identity-original.json": {
      "sha256": "76037c1ecf5c3c4276e089ed6f679811ae833068b8135b9de70d2a4b1b1be081",
      "byte_length": 1901
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "bb00cbcd53066085dc9ab5cf52c7984c76c060257dad449cf1e07771c609b977",
      "byte_length": 2713
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "0df2868395538c730fc55fe39b187c3727c9cb9d19ce9442ce27a8a46230a378",
      "byte_length": 491
    },
    "input-a--knowledge-ir.json": {
      "sha256": "afb975f12453ef22686a95f0bbbbd932be863de673633970889b9daedd1599ff",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e3fcff1c7f74554fec152d40633fb23641bc7324f0d8e5eed2ddb668a88b7a7d",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "40c96f309f6bf6421cef7e0f165d6d97894cb470f437b139e8b46b4d106708b5",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "d0a4456641eb3dbf2f32dec9bbf3f130352ec7df74e723b4b9c9e1670d1fb6c8",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "5c0369fece878993e567313080b41f3ce1a1b4b8bbf1af28432e4dca89d5c2c5",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "7d834464e95f236ed3ac3323a5e23b7e33cd9c0eda5275b43061dd79ebb63134",
      "byte_length": 2713
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "f5e55e5192a2141bc0ddb658a6d0c73d5ce38699272ff463d72787e425ac971b",
      "byte_length": 491
    },
    "input-b--knowledge-ir.json": {
      "sha256": "df5ee04077c7307fc06c24f7cb4c0e4c0c86f6254405bd7f2f2bb04777ac7d65",
      "byte_length": 9252
    },
    "input-b--review-original.json": {
      "sha256": "f499407ae2da9de7f8f4d565115f4b5d75d41271c3969d69ae79a1bde49e2302",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "c6d59843a0d89baaabc694f30eb7fa5e75a3dcc04afaeb20032312c2f87d12c7",
      "byte_length": 974
    },
    "input-b--verification.json": {
      "sha256": "b0dcb8b4027051b956bf5c76d9b8b6e372f64d627cc9c40379cf158068f35616",
      "byte_length": 13988
    },
    "input-b--verification.md": {
      "sha256": "67967a53d805c2582652773c9e59474c99e4dff36748a979d23f746d825c3541",
      "byte_length": 14422
    }
  }
}
```
