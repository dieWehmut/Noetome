# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：3；条件未知：0；条件不适用：0；时间已知：3；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：1；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "d5e01858-2b29-419f-a236-d2dc1a97aa95",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "354c7507-c140-430d-bd2b-141debe06657",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000003",
      "display_name": "质量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "354c7507-c140-430d-bd2b-141debe06657",
        "import_id": "e980c4d3-6ac4-4cea-a125-401f0cabb718",
        "source_id": "b685ec4b-71ab-499d-b134-e29df9496304",
        "version_id": "43ad66d0-ded4-451d-b099-0b8a67c8bc0f",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "e980c4d3-6ac4-4cea-a125-401f0cabb718",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "354c7507-c140-430d-bd2b-141debe06657",
              "source_id": "b685ec4b-71ab-499d-b134-e29df9496304",
              "version_id": "43ad66d0-ded4-451d-b099-0b8a67c8bc0f"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "e980c4d3-6ac4-4cea-a125-401f0cabb718",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "354c7507-c140-430d-bd2b-141debe06657",
              "source_id": "b685ec4b-71ab-499d-b134-e29df9496304",
              "version_id": "43ad66d0-ded4-451d-b099-0b8a67c8bc0f"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "95285c43c6b5f66430c16a16acb1ae556ae12ef1b4e940d3453fc0b060f48d18",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "ffe03d935098618e80ccfa74daaa5df06834102b69e74c177543745ef229548c",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "94ba12a77be2bae57ba414f488510c3599f55139593da2e2febcbca4d5794dd1",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "0847d96c71b9119dddce48bdb10ca38d2b6f280a7bf7ce934c74d9f763953c79",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "ec65a6067542097f27a4e90a72db4fc3771aaf7633158ecb613570f97a4700ad",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "1910138e48422a398e38480db69b52bb7140a9e9b5039355bf53433668429a73",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "9bdce64d583409de416057a45c68a727beb2b42ef2e4b1506eb78334ef5f946b",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "354c7507-c140-430d-bd2b-141debe06657",
        "import_id": "8b37d9dc-bed8-4977-a7bc-b57029e025a7",
        "source_id": "71cd8039-cd00-455a-9a12-2d070130ec40",
        "version_id": "33650f29-71c4-4bba-88a3-e3d0e45dddde",
        "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "import_id": "8b37d9dc-bed8-4977-a7bc-b57029e025a7",
              "manifest_sha256": null,
              "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "parse_id": null,
              "project_id": "354c7507-c140-430d-bd2b-141debe06657",
              "source_id": "71cd8039-cd00-455a-9a12-2d070130ec40",
              "version_id": "33650f29-71c4-4bba-88a3-e3d0e45dddde"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "import_id": "8b37d9dc-bed8-4977-a7bc-b57029e025a7",
              "manifest_sha256": null,
              "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
              "parse_id": null,
              "project_id": "354c7507-c140-430d-bd2b-141debe06657",
              "source_id": "71cd8039-cd00-455a-9a12-2d070130ec40",
              "version_id": "33650f29-71c4-4bba-88a3-e3d0e45dddde"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "9efb89f0fb030eb0b250705d9b019f2d717fce06a51a79c9518fc588dbd98cf6",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0ffdf2514c70543a28c2bfa815784818f99d4af6d06ef17e79411f159d3b6604",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "bd160bec679a7ce9232c06d7f158fa24790ccb76cd30b44e1752dd116a80adc8",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "c7689ddf55c3459d798eba9550ec3cb8318fafe9ebbf3934538b5566af3b81ca",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "087dcc8ad7a0e35df8fec1db32c69392a742a66bc4e88abd9c9edb0d132081a2",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "4610476f2574b8095386083cc8aae087a2102c6ec94c4303afea7c8eee1ebc59",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "c2a50fe4dd1b388acf56246069bd7f627aad25542135d327c18cbf9dcb618fe8",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "354c7507-c140-430d-bd2b-141debe06657",
        "import_id": "6af06ebf-038b-499e-93ea-3b2b220afadc",
        "source_id": "e1e6077b-9e39-4567-a38d-bf33a88d754c",
        "version_id": "3c5fae49-4352-473c-8df4-2a8933230d07",
        "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "import_id": "6af06ebf-038b-499e-93ea-3b2b220afadc",
              "manifest_sha256": null,
              "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "parse_id": null,
              "project_id": "354c7507-c140-430d-bd2b-141debe06657",
              "source_id": "e1e6077b-9e39-4567-a38d-bf33a88d754c",
              "version_id": "3c5fae49-4352-473c-8df4-2a8933230d07"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "import_id": "6af06ebf-038b-499e-93ea-3b2b220afadc",
              "manifest_sha256": null,
              "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "parse_id": null,
              "project_id": "354c7507-c140-430d-bd2b-141debe06657",
              "source_id": "e1e6077b-9e39-4567-a38d-bf33a88d754c",
              "version_id": "3c5fae49-4352-473c-8df4-2a8933230d07"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 164,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 163,
            "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "quote": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 163,
              "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "3",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "kg",
            "value": "3",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "774ae77108c9b510f9ddc1c2e3978c97d245ed4d7fa9d91c9e26f4104cf5ef5b",
          "byte_length": 3048
        },
        "decision-original.json": {
          "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
          "byte_length": 139
        },
        "gold-original.json": {
          "sha256": "3c406bad5f83697b4da1b07f6bd3a44afa3d51494b7b88c2f2bd3ccd226c2607",
          "byte_length": 729
        },
        "knowledge-ir.json": {
          "sha256": "f2b6aad05cd7684726014d6552e42a1a73fc0a1d95bd1c061227cc7e3f96f6c8",
          "byte_length": 12349
        },
        "review-original.json": {
          "sha256": "bdc323abd3b870289bd724eb9f8e643fb9304d46489938badb58c57dfe29c566",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "380beec425459e90492451e8ab0b03265037d8211c1c0a575072768ed740ea2e",
          "byte_length": 1054
        },
        "verification.json": {
          "sha256": "4aeae815e33a7bb9b6e25cc21883279783b33366b1416a10542f3e0500d61c59",
          "byte_length": 16829
        },
        "verification.md": {
          "sha256": "f45de5807419f35f35676b10405876bb8ac18b896444acc72c5ccf624de94d1a",
          "byte_length": 17263
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-6d3f919c90b4082da5d201f2ebb6f59e221c3d8b18dcd67f6d855e7daefc6c12",
      "input_id": "a",
      "binding": {
        "project_id": "354c7507-c140-430d-bd2b-141debe06657",
        "import_id": "e980c4d3-6ac4-4cea-a125-401f0cabb718",
        "source_id": "b685ec4b-71ab-499d-b134-e29df9496304",
        "version_id": "43ad66d0-ded4-451d-b099-0b8a67c8bc0f",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "720f3861-d3b7-49a1-8fdd-eb5e114c42e7",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "c-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 163,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff"
      },
      "occurrence_id": "occ-df3ecf01b287778863d46071478483d000385d4b0f2a3a0947b5720f5657f803",
      "input_id": "c",
      "binding": {
        "project_id": "354c7507-c140-430d-bd2b-141debe06657",
        "import_id": "6af06ebf-038b-499e-93ea-3b2b220afadc",
        "source_id": "e1e6077b-9e39-4567-a38d-bf33a88d754c",
        "version_id": "3c5fae49-4352-473c-8df4-2a8933230d07",
        "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4ba66e42-f5b7-4a21-b4fe-59a20b2f9bfb",
          "ordinal": 0,
          "resource_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "3",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 163,
          "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000003"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "value": "3",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666"
      },
      "occurrence_id": "occ-ee6dc416deb694c2ffd1c1464df07ce831f2a598c959454dc92240731deef4d1",
      "input_id": "b",
      "binding": {
        "project_id": "354c7507-c140-430d-bd2b-141debe06657",
        "import_id": "8b37d9dc-bed8-4977-a7bc-b57029e025a7",
        "source_id": "71cd8039-cd00-455a-9a12-2d070130ec40",
        "version_id": "33650f29-71c4-4bba-88a3-e3d0e45dddde",
        "content_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "normalized_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "e58a1c05-1c5b-496d-b2ac-e0163428084c",
          "ordinal": 0,
          "resource_sha256": "1d069804204504229470422305acab6deb01bffcfbf520f6dc5babc58fd2f0be"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "33eb33a4258a9d9d34e5f59de9e1d098a589921c6f02e7dda45487f4724ce666",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-3cf5b5dfe6841b7a58b4328a6079fada3e7fef5eb5a014a738a4c3e1351ae419",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "3",
      "unit": "kg",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-df3ecf01b287778863d46071478483d000385d4b0f2a3a0947b5720f5657f803"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-71585ac2caed36414e2692879ef09222ae8e60dcf8eef7c928b2ccd0b2ff2bfd",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-6d3f919c90b4082da5d201f2ebb6f59e221c3d8b18dcd67f6d855e7daefc6c12"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-8247ec69399ea4a69c02ec0091daaa89fe400b591013802493c29b849e4fee4e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-ee6dc416deb694c2ffd1c1464df07ce831f2a598c959454dc92240731deef4d1"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-6d3f919c90b4082da5d201f2ebb6f59e221c3d8b18dcd67f6d855e7daefc6c12",
      "right_occurrence_id": "occ-df3ecf01b287778863d46071478483d000385d4b0f2a3a0947b5720f5657f803",
      "relation": "complement",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-6d3f919c90b4082da5d201f2ebb6f59e221c3d8b18dcd67f6d855e7daefc6c12",
      "right_occurrence_id": "occ-ee6dc416deb694c2ffd1c1464df07ce831f2a598c959454dc92240731deef4d1",
      "relation": "true_conflict",
      "issue_code": "COORD_TRUE_CONFLICT"
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-df3ecf01b287778863d46071478483d000385d4b0f2a3a0947b5720f5657f803",
      "right_occurrence_id": "occ-ee6dc416deb694c2ffd1c1464df07ce831f2a598c959454dc92240731deef4d1",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-6d3f919c90b4082da5d201f2ebb6f59e221c3d8b18dcd67f6d855e7daefc6c12",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    },
    {
      "occurrence_id": "occ-df3ecf01b287778863d46071478483d000385d4b0f2a3a0947b5720f5657f803",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-ee6dc416deb694c2ffd1c1464df07ce831f2a598c959454dc92240731deef4d1",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    }
  ],
  "totals": {
    "true_conflicts": 1,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 2,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 3,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 3,
    "undated_occurrences": 0,
    "context_evidence_links": 3,
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 3,
    "canonical_facts": null,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 0,
    "passed": 1,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c77503ad64aded2b82aac27ea6f371aee203ab89a3c75d2e37b03d0b9312cbf6",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "afd8dd6fa02be02676f5dec8cea2aa7be31aee62c102688ed367451f21ab37fb",
      "byte_length": 6401
    },
    "identity-original.json": {
      "sha256": "3eebf915ecbdbfc9b6350ebe221b4d7b41a8c05162823e3cb7b7e02b75830e72",
      "byte_length": 2749
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "95285c43c6b5f66430c16a16acb1ae556ae12ef1b4e940d3453fc0b060f48d18",
      "byte_length": 3056
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "ffe03d935098618e80ccfa74daaa5df06834102b69e74c177543745ef229548c",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "94ba12a77be2bae57ba414f488510c3599f55139593da2e2febcbca4d5794dd1",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "0847d96c71b9119dddce48bdb10ca38d2b6f280a7bf7ce934c74d9f763953c79",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "ec65a6067542097f27a4e90a72db4fc3771aaf7633158ecb613570f97a4700ad",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "1910138e48422a398e38480db69b52bb7140a9e9b5039355bf53433668429a73",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "9bdce64d583409de416057a45c68a727beb2b42ef2e4b1506eb78334ef5f946b",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "9efb89f0fb030eb0b250705d9b019f2d717fce06a51a79c9518fc588dbd98cf6",
      "byte_length": 3056
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "0ffdf2514c70543a28c2bfa815784818f99d4af6d06ef17e79411f159d3b6604",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "bd160bec679a7ce9232c06d7f158fa24790ccb76cd30b44e1752dd116a80adc8",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "c7689ddf55c3459d798eba9550ec3cb8318fafe9ebbf3934538b5566af3b81ca",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "087dcc8ad7a0e35df8fec1db32c69392a742a66bc4e88abd9c9edb0d132081a2",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "4610476f2574b8095386083cc8aae087a2102c6ec94c4303afea7c8eee1ebc59",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "c2a50fe4dd1b388acf56246069bd7f627aad25542135d327c18cbf9dcb618fe8",
      "byte_length": 17303
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "774ae77108c9b510f9ddc1c2e3978c97d245ed4d7fa9d91c9e26f4104cf5ef5b",
      "byte_length": 3048
    },
    "input-c--decision-original.json": {
      "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
      "byte_length": 139
    },
    "input-c--gold-original.json": {
      "sha256": "3c406bad5f83697b4da1b07f6bd3a44afa3d51494b7b88c2f2bd3ccd226c2607",
      "byte_length": 729
    },
    "input-c--knowledge-ir.json": {
      "sha256": "f2b6aad05cd7684726014d6552e42a1a73fc0a1d95bd1c061227cc7e3f96f6c8",
      "byte_length": 12349
    },
    "input-c--review-original.json": {
      "sha256": "bdc323abd3b870289bd724eb9f8e643fb9304d46489938badb58c57dfe29c566",
      "byte_length": 509
    },
    "input-c--source-snapshot.json": {
      "sha256": "380beec425459e90492451e8ab0b03265037d8211c1c0a575072768ed740ea2e",
      "byte_length": 1054
    },
    "input-c--verification.json": {
      "sha256": "4aeae815e33a7bb9b6e25cc21883279783b33366b1416a10542f3e0500d61c59",
      "byte_length": 16829
    },
    "input-c--verification.md": {
      "sha256": "f45de5807419f35f35676b10405876bb8ac18b896444acc72c5ccf624de94d1a",
      "byte_length": 17263
    }
  }
}
```
