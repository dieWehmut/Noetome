# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：0；条件不适用：2；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：1；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "1b76aa7d-6ffd-4fc4-b94b-764ea1c91438",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
        "import_id": "b35758a6-a424-4927-a19f-69b394f19ca5",
        "source_id": "f0f51937-8ba9-4a6f-b142-f25e99214dcc",
        "version_id": "8e45c959-7275-4998-b089-ae921eef27a2",
        "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "import_id": "b35758a6-a424-4927-a19f-69b394f19ca5",
              "manifest_sha256": null,
              "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "parse_id": null,
              "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
              "source_id": "f0f51937-8ba9-4a6f-b142-f25e99214dcc",
              "version_id": "8e45c959-7275-4998-b089-ae921eef27a2"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "import_id": "b35758a6-a424-4927-a19f-69b394f19ca5",
              "manifest_sha256": null,
              "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "parse_id": null,
              "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
              "source_id": "f0f51937-8ba9-4a6f-b142-f25e99214dcc",
              "version_id": "8e45c959-7275-4998-b089-ae921eef27a2"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "7a0a64f3f91195b41b007cf9b1583d9c2563a14dce8675fa1f71f552a716a618",
          "byte_length": 2713
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0df2868395538c730fc55fe39b187c3727c9cb9d19ce9442ce27a8a46230a378",
          "byte_length": 491
        },
        "knowledge-ir.json": {
          "sha256": "bbd4b63aa3cc40e629fa915283a023322dba5322ba130040a6c24c80f3912a15",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e3fcff1c7f74554fec152d40633fb23641bc7324f0d8e5eed2ddb668a88b7a7d",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "d75fad3b2d97bd9492398426894e5e04828a5a31d1ee76a882770ad89da6c894",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "74780bdc010526aa8c836fefbc8147fad6e2e7c373f92cdf47e884139b57ee49",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "c8ec95f7301084b934bc0dd3b454ef73dfa3284aca4234605470b12958031c14",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
        "import_id": "66cd1365-d276-4496-97a2-a7f75b666d29",
        "source_id": "cef22c2e-3d4b-4dc5-a13e-e861d873516d",
        "version_id": "47ed2c4a-6fa8-4f19-8f86-2e0bfbc7c02b",
        "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "import_id": "66cd1365-d276-4496-97a2-a7f75b666d29",
              "manifest_sha256": null,
              "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "parse_id": null,
              "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
              "source_id": "cef22c2e-3d4b-4dc5-a13e-e861d873516d",
              "version_id": "47ed2c4a-6fa8-4f19-8f86-2e0bfbc7c02b"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "import_id": "66cd1365-d276-4496-97a2-a7f75b666d29",
              "manifest_sha256": null,
              "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
              "parse_id": null,
              "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
              "source_id": "cef22c2e-3d4b-4dc5-a13e-e861d873516d",
              "version_id": "47ed2c4a-6fa8-4f19-8f86-2e0bfbc7c02b"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 12 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s。",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "89c63cfda791d6ba289c36f57f41348d7ce9ca34ed4d964947e116d2603432bf",
          "byte_length": 2713
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "f5e55e5192a2141bc0ddb658a6d0c73d5ce38699272ff463d72787e425ac971b",
          "byte_length": 491
        },
        "knowledge-ir.json": {
          "sha256": "d44aa1ed75d85b0884fb18cc5b86a0c3dae98eb0b7902e39b23e335086f9950d",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "f499407ae2da9de7f8f4d565115f4b5d75d41271c3969d69ae79a1bde49e2302",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "ec9e8a0503eac353cdee2ed72bbac6488fcfd4d21ad42027b31b5e8005e7790c",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "eadaa2654306dac4ce48de29a781b4e54c49d96d6efb5ad5c0e21bc0b044a4f3",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "68a5a29e80a021aaf6a2f697c1710a3fb6155b0e5e102e4ead3f2e1d052e9f8e",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e"
      },
      "occurrence_id": "occ-8940e70023992ed5de97789bb95088f74504b89fb8e4a3c8475c7a3adfa42043",
      "input_id": "a",
      "binding": {
        "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
        "import_id": "b35758a6-a424-4927-a19f-69b394f19ca5",
        "source_id": "f0f51937-8ba9-4a6f-b142-f25e99214dcc",
        "version_id": "8e45c959-7275-4998-b089-ae921eef27a2",
        "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "b20433d9-e60f-49a7-b358-e6da567b18c1",
          "ordinal": 0,
          "resource_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
        "sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b"
      },
      "occurrence_id": "occ-d78cdc9cfa1420e2fcbba313a128e94b62db72d4fcf8ffd34984527d9e6475f0",
      "input_id": "b",
      "binding": {
        "project_id": "7b41580c-ae64-49e3-95dc-b186854f7961",
        "import_id": "66cd1365-d276-4496-97a2-a7f75b666d29",
        "source_id": "cef22c2e-3d4b-4dc5-a13e-e861d873516d",
        "version_id": "47ed2c4a-6fa8-4f19-8f86-2e0bfbc7c02b",
        "content_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "normalized_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "8c1c8946-1676-4ba1-8a65-034fb51c59e3",
          "ordinal": 0,
          "resource_sha256": "7626a6d3e1737fcae0a3de2fab55e7ac252beae5a811f1bd2e177214ad493c09"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b76528a0ce81974545d1278f587a2540820df8b8b34985881be0df9649e1f94b",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 12 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-32949f92e33936155bb624da3056f9e49fa64de9b4228868349908aec7fa29e7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-8940e70023992ed5de97789bb95088f74504b89fb8e4a3c8475c7a3adfa42043"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-d0907032cb4dc7d590b47392f3074436030610f9e26ed86dbe1816fbcd123321",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-d78cdc9cfa1420e2fcbba313a128e94b62db72d4fcf8ffd34984527d9e6475f0"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-8940e70023992ed5de97789bb95088f74504b89fb8e4a3c8475c7a3adfa42043",
      "right_occurrence_id": "occ-d78cdc9cfa1420e2fcbba313a128e94b62db72d4fcf8ffd34984527d9e6475f0",
      "relation": "true_conflict",
      "issue_code": "COORD_TRUE_CONFLICT"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-8940e70023992ed5de97789bb95088f74504b89fb8e4a3c8475c7a3adfa42043",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    },
    {
      "occurrence_id": "occ-d78cdc9cfa1420e2fcbba313a128e94b62db72d4fcf8ffd34984527d9e6475f0",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    }
  ],
  "totals": {
    "true_conflicts": 1,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 2,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 2,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2013dbbaea6b0d3ff85f100c8b8c3aef0333e158be3b5563d60d6cd58a0533cd",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "10c9a55050a5e56d0e6cdd693a7ef699fecfe5633a06db42b4527e1578bffc89",
      "byte_length": 4325
    },
    "identity-original.json": {
      "sha256": "1c53b5fb4ffe5430ff0bb0f73be8ee57bde607a80003b630aaea1a525cadd5ad",
      "byte_length": 1915
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "7a0a64f3f91195b41b007cf9b1583d9c2563a14dce8675fa1f71f552a716a618",
      "byte_length": 2713
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "0df2868395538c730fc55fe39b187c3727c9cb9d19ce9442ce27a8a46230a378",
      "byte_length": 491
    },
    "input-a--knowledge-ir.json": {
      "sha256": "bbd4b63aa3cc40e629fa915283a023322dba5322ba130040a6c24c80f3912a15",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e3fcff1c7f74554fec152d40633fb23641bc7324f0d8e5eed2ddb668a88b7a7d",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "d75fad3b2d97bd9492398426894e5e04828a5a31d1ee76a882770ad89da6c894",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "74780bdc010526aa8c836fefbc8147fad6e2e7c373f92cdf47e884139b57ee49",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "c8ec95f7301084b934bc0dd3b454ef73dfa3284aca4234605470b12958031c14",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "89c63cfda791d6ba289c36f57f41348d7ce9ca34ed4d964947e116d2603432bf",
      "byte_length": 2713
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "f5e55e5192a2141bc0ddb658a6d0c73d5ce38699272ff463d72787e425ac971b",
      "byte_length": 491
    },
    "input-b--knowledge-ir.json": {
      "sha256": "d44aa1ed75d85b0884fb18cc5b86a0c3dae98eb0b7902e39b23e335086f9950d",
      "byte_length": 9252
    },
    "input-b--review-original.json": {
      "sha256": "f499407ae2da9de7f8f4d565115f4b5d75d41271c3969d69ae79a1bde49e2302",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "ec9e8a0503eac353cdee2ed72bbac6488fcfd4d21ad42027b31b5e8005e7790c",
      "byte_length": 974
    },
    "input-b--verification.json": {
      "sha256": "eadaa2654306dac4ce48de29a781b4e54c49d96d6efb5ad5c0e21bc0b044a4f3",
      "byte_length": 13988
    },
    "input-b--verification.md": {
      "sha256": "68a5a29e80a021aaf6a2f697c1710a3fb6155b0e5e102e4ead3f2e1d052e9f8e",
      "byte_length": 14422
    }
  }
}
```
