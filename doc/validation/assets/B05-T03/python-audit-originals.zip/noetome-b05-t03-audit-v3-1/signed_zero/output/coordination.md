# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "500b7d16-86dc-45da-8aaf-1e025898bc82",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
        "import_id": "db72995c-5e70-4cf9-956b-732ba5c62b11",
        "source_id": "a33f00fa-f956-4343-b562-72b02798bcd7",
        "version_id": "95bfdf39-bf66-466e-901a-19ae68ff8b9d",
        "content_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
        "normalized_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
              "import_id": "db72995c-5e70-4cf9-956b-732ba5c62b11",
              "manifest_sha256": null,
              "normalized_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
              "parse_id": null,
              "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
              "source_id": "a33f00fa-f956-4343-b562-72b02798bcd7",
              "version_id": "95bfdf39-bf66-466e-901a-19ae68ff8b9d"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
              "import_id": "db72995c-5e70-4cf9-956b-732ba5c62b11",
              "manifest_sha256": null,
              "normalized_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
              "parse_id": null,
              "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
              "source_id": "a33f00fa-f956-4343-b562-72b02798bcd7",
              "version_id": "95bfdf39-bf66-466e-901a-19ae68ff8b9d"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "2aaa98e680e785fb40ebf1c776814477298ccf39cd4e538bf539ec5651c318ec",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "2aaa98e680e785fb40ebf1c776814477298ccf39cd4e538bf539ec5651c318ec",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "+0",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "+0",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "81c517ffc1eab08128080435898785aa38c2c1649284c3283fe6451c2f1fd345",
          "byte_length": 3051
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "6bc5f482e39ba9d6abb03a7da9f79de17cb820aff4996b288b9bb2573fea8842",
          "byte_length": 736
        },
        "knowledge-ir.json": {
          "sha256": "937d2d4c05b4b42c534e73d9b92f722f6fd35de6aebf4bd61a154932e8a425ab",
          "byte_length": 12385
        },
        "review-original.json": {
          "sha256": "54cd74d809e51d49ba239b33660c4b53d199bbd2e8de28d45226d4c5e29ec226",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "c594738177a2d6f40622a1bc33d89aa745375e6821aba1ffd6ad0b7352ed7382",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "2e3716b4cc176805bcee92404efdbe386c7174a6378cd14034aab137f67b7354",
          "byte_length": 16860
        },
        "verification.md": {
          "sha256": "774f592756c0cb6829252e95b946bc3b468f2d2a8e4359d653628198f75e8483",
          "byte_length": 17294
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
        "import_id": "d9bcd82f-8f71-41d2-b732-289e23bcbc44",
        "source_id": "dd85d97d-6945-4bdf-865f-498322dc144c",
        "version_id": "e6c9e52f-157a-4bed-93cd-07f2caedf251",
        "content_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
        "normalized_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
              "import_id": "d9bcd82f-8f71-41d2-b732-289e23bcbc44",
              "manifest_sha256": null,
              "normalized_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
              "parse_id": null,
              "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
              "source_id": "dd85d97d-6945-4bdf-865f-498322dc144c",
              "version_id": "e6c9e52f-157a-4bed-93cd-07f2caedf251"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
              "import_id": "d9bcd82f-8f71-41d2-b732-289e23bcbc44",
              "manifest_sha256": null,
              "normalized_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
              "parse_id": null,
              "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
              "source_id": "dd85d97d-6945-4bdf-865f-498322dc144c",
              "version_id": "e6c9e52f-157a-4bed-93cd-07f2caedf251"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 168,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 167,
            "excerpt_sha256": "cb1e32bb9f7de398801787c1362d167a9aef190f9a9d4eacfa47c801da9ac51e",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 167,
            "quote": "样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 167,
              "excerpt_sha256": "cb1e32bb9f7de398801787c1362d167a9aef190f9a9d4eacfa47c801da9ac51e",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "-0.0",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "-0.0",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 168,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "96b1303802a4b58fb3495f91de9dfd63e801bef65b115452332c9874f0269431",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "5d84681ff4741c645b0296e94997f5279acee27104f853b800cbc769b36cb837",
          "byte_length": 742
        },
        "knowledge-ir.json": {
          "sha256": "a2e80a6f8a529f22926bb8e4cdb4f2622553ed0e50452324dfddb22fa7859c66",
          "byte_length": 12407
        },
        "review-original.json": {
          "sha256": "e4d934fb7c10e43a7f868e1a524f17e540099748b6cec1175ea3fd8f17d2a1af",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "1272651d0f7c7aae19f595623f9e71996ed92806ced4bd73c7b0c1615a654249",
          "byte_length": 1058
        },
        "verification.json": {
          "sha256": "15d3dd9f8c43e1a31dfb0bb463ed8cfb4639e882b8830a8c16478a0134613f37",
          "byte_length": 16878
        },
        "verification.md": {
          "sha256": "1b87212034455da480001476b99bbabeab582726609dd9516a4239d3cc3a3f20",
          "byte_length": 17312
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 167,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "cb1e32bb9f7de398801787c1362d167a9aef190f9a9d4eacfa47c801da9ac51e"
      },
      "occurrence_id": "occ-9f7d85cec0cb5de1bf2193d875837c6e0dab9a6bb5ae1d2c1a6d10d28b00523d",
      "input_id": "b",
      "binding": {
        "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
        "import_id": "d9bcd82f-8f71-41d2-b732-289e23bcbc44",
        "source_id": "dd85d97d-6945-4bdf-865f-498322dc144c",
        "version_id": "e6c9e52f-157a-4bed-93cd-07f2caedf251",
        "content_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
        "normalized_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "b75f3268-626a-4a2a-bd0a-427280b92497",
          "ordinal": 0,
          "resource_sha256": "e8b81fe4f38efec7a8219a2faa2386424649fdf0640fed055d4335d4e7a1eba4"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 168,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "-0.0",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 167,
          "excerpt_sha256": "cb1e32bb9f7de398801787c1362d167a9aef190f9a9d4eacfa47c801da9ac51e",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 -0.0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "-0.0",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "2aaa98e680e785fb40ebf1c776814477298ccf39cd4e538bf539ec5651c318ec"
      },
      "occurrence_id": "occ-e862c3d0af075069cc651886d984244bea194591fa6dc47dad5f229f4153597d",
      "input_id": "a",
      "binding": {
        "project_id": "12975a2b-809f-434e-9b12-f1db23ead9c3",
        "import_id": "db72995c-5e70-4cf9-956b-732ba5c62b11",
        "source_id": "a33f00fa-f956-4343-b562-72b02798bcd7",
        "version_id": "95bfdf39-bf66-466e-901a-19ae68ff8b9d",
        "content_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
        "normalized_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "d7ea920d-7570-47bd-b093-cfedf8c9f9c1",
          "ordinal": 0,
          "resource_sha256": "09e1ae1732b103f3b303418a6e14a30564d0c6ecec1988688f5577256499bbe7"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "+0",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "2aaa98e680e785fb40ebf1c776814477298ccf39cd4e538bf539ec5651c318ec",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 +0 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "+0",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-8c64da2868163b0b8ff948c2d15a2583a72b31408f2ecd78b85ffa6916f99122",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "-0.0",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-9f7d85cec0cb5de1bf2193d875837c6e0dab9a6bb5ae1d2c1a6d10d28b00523d"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-da895b4bf5fb00c0efebf8e4e31d259ff4dcca0e82a91ccf00f34e4a985a8847",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "+0",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-e862c3d0af075069cc651886d984244bea194591fa6dc47dad5f229f4153597d"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-9f7d85cec0cb5de1bf2193d875837c6e0dab9a6bb5ae1d2c1a6d10d28b00523d",
      "right_occurrence_id": "occ-e862c3d0af075069cc651886d984244bea194591fa6dc47dad5f229f4153597d",
      "relation": "numeric_equivalent",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-9f7d85cec0cb5de1bf2193d875837c6e0dab9a6bb5ae1d2c1a6d10d28b00523d",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-e862c3d0af075069cc651886d984244bea194591fa6dc47dad5f229f4153597d",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "7b66a227d39a4799a46e6f5bc8f325086aa6c532da60cfa7ce8e9e46acd69bc6",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "f0a489f813f2bcb0e11a1cab97a2c28ad93c850b4379bb7304990a8998666fe9",
      "byte_length": 41227
    },
    "coordination-original.json": {
      "sha256": "28e9f1aa540b816d3d4190eaeef780cedacfaaad55f90909c447cb67e99718b9",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "a8ea11ff5a2c5cc4a5e252df5e66ef3e8953fe2eae3632224ed325477a21948a",
      "byte_length": 1898
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "81c517ffc1eab08128080435898785aa38c2c1649284c3283fe6451c2f1fd345",
      "byte_length": 3051
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "6bc5f482e39ba9d6abb03a7da9f79de17cb820aff4996b288b9bb2573fea8842",
      "byte_length": 736
    },
    "input-a--knowledge-ir.json": {
      "sha256": "937d2d4c05b4b42c534e73d9b92f722f6fd35de6aebf4bd61a154932e8a425ab",
      "byte_length": 12385
    },
    "input-a--review-original.json": {
      "sha256": "54cd74d809e51d49ba239b33660c4b53d199bbd2e8de28d45226d4c5e29ec226",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "c594738177a2d6f40622a1bc33d89aa745375e6821aba1ffd6ad0b7352ed7382",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "2e3716b4cc176805bcee92404efdbe386c7174a6378cd14034aab137f67b7354",
      "byte_length": 16860
    },
    "input-a--verification.md": {
      "sha256": "774f592756c0cb6829252e95b946bc3b468f2d2a8e4359d653628198f75e8483",
      "byte_length": 17294
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "96b1303802a4b58fb3495f91de9dfd63e801bef65b115452332c9874f0269431",
      "byte_length": 3057
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "5d84681ff4741c645b0296e94997f5279acee27104f853b800cbc769b36cb837",
      "byte_length": 742
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a2e80a6f8a529f22926bb8e4cdb4f2622553ed0e50452324dfddb22fa7859c66",
      "byte_length": 12407
    },
    "input-b--review-original.json": {
      "sha256": "e4d934fb7c10e43a7f868e1a524f17e540099748b6cec1175ea3fd8f17d2a1af",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "1272651d0f7c7aae19f595623f9e71996ed92806ced4bd73c7b0c1615a654249",
      "byte_length": 1058
    },
    "input-b--verification.json": {
      "sha256": "15d3dd9f8c43e1a31dfb0bb463ed8cfb4639e882b8830a8c16478a0134613f37",
      "byte_length": 16878
    },
    "input-b--verification.md": {
      "sha256": "1b87212034455da480001476b99bbabeab582726609dd9516a4239d3cc3a3f20",
      "byte_length": 17312
    }
  }
}
```
