# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：1；条件未知：1；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "dd508d8b-0eea-4036-8cec-b3b47d1b925b",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000003",
      "display_name": "质量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
        "import_id": "1edbb4fc-e4d9-482a-b710-1e6491fbf780",
        "source_id": "be6c409d-f034-4b6c-8f54-d0c8f8498b64",
        "version_id": "fcb0aef7-3567-407c-bbc5-1bfa4ac97ce5",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "1edbb4fc-e4d9-482a-b710-1e6491fbf780",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
              "source_id": "be6c409d-f034-4b6c-8f54-d0c8f8498b64",
              "version_id": "fcb0aef7-3567-407c-bbc5-1bfa4ac97ce5"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "1edbb4fc-e4d9-482a-b710-1e6491fbf780",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
              "source_id": "be6c409d-f034-4b6c-8f54-d0c8f8498b64",
              "version_id": "fcb0aef7-3567-407c-bbc5-1bfa4ac97ce5"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "4529bdd1b84e04b99144213d3ec212c863b062a04bed2ca89e91e1c9ce1afb65",
          "byte_length": 2708
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "f68393ea13402c16099132dbb194e34591ed5554dda0988f9eebff47cd1c75f2",
          "byte_length": 492
        },
        "knowledge-ir.json": {
          "sha256": "6546dde39dc53bdef28e07c22adf9424e20f60edafdac09b4e5a0f13433c4ac0",
          "byte_length": 9243
        },
        "review-original.json": {
          "sha256": "5febe091be57f649090a8f0332549c2cb33ac7d9733c299d74eb4574cbfeff3d",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "56c36c5231b12009f930ee4ee0b304897f6263c5cdcc16df9dabdf51bc6bb115",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "7e51267d453a01454221791e279235dad4a280a92c715b43553b5ccfe82a4e11",
          "byte_length": 13979
        },
        "verification.md": {
          "sha256": "807011ecdb05f6e7b5a2053e67ff7b3b344508eb757bcd5ab3377c4840b68df6",
          "byte_length": 14413
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
        "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
        "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
        "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997",
        "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-mass"
            ],
            "decision": {
              "atom_ids": [
                "b-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
              "manifest_sha256": null,
              "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "parse_id": null,
              "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
              "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
              "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
              "manifest_sha256": null,
              "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
              "parse_id": null,
              "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
              "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
              "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 164,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 163,
            "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "quote": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 163,
              "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "3",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "kg",
            "value": "3",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "c25883e1f3cbd78dfb672e55501e9e62bdda1c2edb94b99c0c255fbcdd2cd081",
          "byte_length": 3043
        },
        "decision-original.json": {
          "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "01ecedd103303f344c6c9cb6a72c4f780495dce33b2b63f9703d2b613b185440",
          "byte_length": 730
        },
        "knowledge-ir.json": {
          "sha256": "1b1bae887e65d3d9084dadaee25c94a65d036a89e1832200c6a3fbae5a0390f9",
          "byte_length": 12340
        },
        "review-original.json": {
          "sha256": "6647ff6eef4f73340f9634977e7785b461c4f70da8d9f1eb3edf672ca7dcee99",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "92fee06ddfef17dd5e9d9ae7e3cc717b181f2ae73c7818d18dfb276318ef5fb8",
          "byte_length": 1054
        },
        "verification.json": {
          "sha256": "dc2ca29f858886ba940a860675e4a1b464da076a47e7d4611141b611efcc17da",
          "byte_length": 16820
        },
        "verification.md": {
          "sha256": "7d133c7b04c29f015b1f56f61c949d8eb85ab8b9d64b70aabe820033bbc4365c",
          "byte_length": 17254
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 163,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff"
      },
      "occurrence_id": "occ-1ed23a7cdaf42d23361336aa71cad385c18ad7cfd02437e771b74efe326e5277",
      "input_id": "b",
      "binding": {
        "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
        "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
        "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
        "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997",
        "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f2ab2681-1d63-40f6-9ba1-d5c9c1e0bffc",
          "ordinal": 0,
          "resource_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "3",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 163,
          "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000003"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "value": "3",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-bacbf695d60b7f15b505221c04c529f9da9213deeb8a690a2930428fdf36543d",
      "input_id": "a",
      "binding": {
        "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
        "import_id": "1edbb4fc-e4d9-482a-b710-1e6491fbf780",
        "source_id": "be6c409d-f034-4b6c-8f54-d0c8f8498b64",
        "version_id": "fcb0aef7-3567-407c-bbc5-1bfa4ac97ce5",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "e34168f8-3ca7-45ea-93ce-0be1d8e5f610",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-3cf5b5dfe6841b7a58b4328a6079fada3e7fef5eb5a014a738a4c3e1351ae419",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "3",
      "unit": "kg",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-1ed23a7cdaf42d23361336aa71cad385c18ad7cfd02437e771b74efe326e5277"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-cffc258a3fd9be2b22fe8217a391f7b0fe4e7e8a99cb65388d3ed92414da83ad",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-bacbf695d60b7f15b505221c04c529f9da9213deeb8a690a2930428fdf36543d"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-1ed23a7cdaf42d23361336aa71cad385c18ad7cfd02437e771b74efe326e5277",
      "right_occurrence_id": "occ-bacbf695d60b7f15b505221c04c529f9da9213deeb8a690a2930428fdf36543d",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-1ed23a7cdaf42d23361336aa71cad385c18ad7cfd02437e771b74efe326e5277",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-bacbf695d60b7f15b505221c04c529f9da9213deeb8a690a2930428fdf36543d",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 1,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 1,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 1,
    "failed": 0,
    "needs_review": 1,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "47aeb23ac164326c5bcf43bdd4cda4369f812f86f803b0530de17e53330e20c7",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "44c3598794510b6b534bed27754d675a1f1275c33b648d2df59fec8f59616b13",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "42b180c6a46574fddd8b445c03fa54eb048bf449436a1308dd6d54158c62a776",
      "byte_length": 2004
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "4529bdd1b84e04b99144213d3ec212c863b062a04bed2ca89e91e1c9ce1afb65",
      "byte_length": 2708
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "f68393ea13402c16099132dbb194e34591ed5554dda0988f9eebff47cd1c75f2",
      "byte_length": 492
    },
    "input-a--knowledge-ir.json": {
      "sha256": "6546dde39dc53bdef28e07c22adf9424e20f60edafdac09b4e5a0f13433c4ac0",
      "byte_length": 9243
    },
    "input-a--review-original.json": {
      "sha256": "5febe091be57f649090a8f0332549c2cb33ac7d9733c299d74eb4574cbfeff3d",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "56c36c5231b12009f930ee4ee0b304897f6263c5cdcc16df9dabdf51bc6bb115",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "7e51267d453a01454221791e279235dad4a280a92c715b43553b5ccfe82a4e11",
      "byte_length": 13979
    },
    "input-a--verification.md": {
      "sha256": "807011ecdb05f6e7b5a2053e67ff7b3b344508eb757bcd5ab3377c4840b68df6",
      "byte_length": 14413
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "c25883e1f3cbd78dfb672e55501e9e62bdda1c2edb94b99c0c255fbcdd2cd081",
      "byte_length": 3043
    },
    "input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "01ecedd103303f344c6c9cb6a72c4f780495dce33b2b63f9703d2b613b185440",
      "byte_length": 730
    },
    "input-b--knowledge-ir.json": {
      "sha256": "1b1bae887e65d3d9084dadaee25c94a65d036a89e1832200c6a3fbae5a0390f9",
      "byte_length": 12340
    },
    "input-b--review-original.json": {
      "sha256": "6647ff6eef4f73340f9634977e7785b461c4f70da8d9f1eb3edf672ca7dcee99",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "92fee06ddfef17dd5e9d9ae7e3cc717b181f2ae73c7818d18dfb276318ef5fb8",
      "byte_length": 1054
    },
    "input-b--verification.json": {
      "sha256": "dc2ca29f858886ba940a860675e4a1b464da076a47e7d4611141b611efcc17da",
      "byte_length": 16820
    },
    "input-b--verification.md": {
      "sha256": "7d133c7b04c29f015b1f56f61c949d8eb85ab8b9d64b70aabe820033bbc4365c",
      "byte_length": 17254
    }
  }
}
```
