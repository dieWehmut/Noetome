# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-conflicts-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
      "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
      "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
      "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997",
      "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
      "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f2ab2681-1d63-40f6-9ba1-d5c9c1e0bffc",
          "ordinal": 0,
          "resource_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
    "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
    "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
    "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997",
    "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
    "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "c25883e1f3cbd78dfb672e55501e9e62bdda1c2edb94b99c0c255fbcdd2cd081",
        "byte_length": 3043
      },
      "decision.json": {
        "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "01ecedd103303f344c6c9cb6a72c4f780495dce33b2b63f9703d2b613b185440",
        "byte_length": 730
      },
      "review.json": {
        "sha256": "6647ff6eef4f73340f9634977e7785b461c4f70da8d9f1eb3edf672ca7dcee99",
        "byte_length": 510
      }
    },
    "gold_sha256": "01ecedd103303f344c6c9cb6a72c4f780495dce33b2b63f9703d2b613b185440"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "质量",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-mass"
        ],
        "decision": {
          "atom_ids": [
            "b-mass"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
          "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
          "manifest_sha256": null,
          "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
          "parse_id": null,
          "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
          "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
          "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997"
        },
        "request_id": "synthetic-conflicts-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
          "import_id": "bf99e595-9a9d-4177-8ff1-6a17af041983",
          "manifest_sha256": null,
          "normalized_sha256": "24abcbbea2a362d2df45e7c33c700633a9086a63f4db82b5011849263789bd3e",
          "parse_id": null,
          "project_id": "fd25520a-1bcd-499d-9b24-0631f4165220",
          "source_id": "443fb0e7-3388-45a1-9071-345158aed660",
          "version_id": "b65a9e68-b530-49a9-9416-9e1b8aa99997"
        },
        "request_id": "synthetic-conflicts-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 164,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 163,
        "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
        "excerpt_start_byte": 0,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 163,
        "quote": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 163,
          "excerpt_sha256": "c72df0f45855f6b5a17bdcc727ac214dbcaca33eb7c221b478e3a24d697495ff",
          "excerpt_start_byte": 0,
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "质量"
        ],
        "compound": "样例 A 质量"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "质量",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的质量为 3 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "3",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "kg",
        "value": "3",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "kg",
      "actual": {
        "measurement": "kg",
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "kg"
      },
      "actual": [
        "kg",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "candidates-original.json": {
      "sha256": "c25883e1f3cbd78dfb672e55501e9e62bdda1c2edb94b99c0c255fbcdd2cd081",
      "byte_length": 3043
    },
    "decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "01ecedd103303f344c6c9cb6a72c4f780495dce33b2b63f9703d2b613b185440",
      "byte_length": 730
    },
    "knowledge-ir.json": {
      "sha256": "1b1bae887e65d3d9084dadaee25c94a65d036a89e1832200c6a3fbae5a0390f9",
      "byte_length": 12340
    },
    "review-original.json": {
      "sha256": "6647ff6eef4f73340f9634977e7785b461c4f70da8d9f1eb3edf672ca7dcee99",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "92fee06ddfef17dd5e9d9ae7e3cc717b181f2ae73c7818d18dfb276318ef5fb8",
      "byte_length": 1054
    }
  }
}
```
