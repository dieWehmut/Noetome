# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：2；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：1；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "ac5e90a6-fce2-45a5-93ce-2374b9daaf6f",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
        "import_id": "d1165b2a-a659-4571-abd7-0112fa486b51",
        "source_id": "6cb76f62-3d34-46a5-a581-519b84e66880",
        "version_id": "c2ae647f-7f3f-4393-8a61-9f9f05732888",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "d1165b2a-a659-4571-abd7-0112fa486b51",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
              "source_id": "6cb76f62-3d34-46a5-a581-519b84e66880",
              "version_id": "c2ae647f-7f3f-4393-8a61-9f9f05732888"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "d1165b2a-a659-4571-abd7-0112fa486b51",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
              "source_id": "6cb76f62-3d34-46a5-a581-519b84e66880",
              "version_id": "c2ae647f-7f3f-4393-8a61-9f9f05732888"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "c8931d5644d8f96262e2bb64e30d6e2d52112c18f6702905bf4b6b4c2c197465",
          "byte_length": 2708
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "f68393ea13402c16099132dbb194e34591ed5554dda0988f9eebff47cd1c75f2",
          "byte_length": 492
        },
        "knowledge-ir.json": {
          "sha256": "30a112f94b3493a1faf9eff59df6e11f4bb5ecaa8fa32401b53a988d7df0b239",
          "byte_length": 9243
        },
        "review-original.json": {
          "sha256": "5febe091be57f649090a8f0332549c2cb33ac7d9733c299d74eb4574cbfeff3d",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "312e2ac20c0f5d356c6dbd63c9f2ec19401d39678d0dc594c391a893973a1b2b",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "8ec5e546a5bd7d397925d78bcf8a85026aa6fc663ce73e03ad65de2c5a90ed12",
          "byte_length": 13979
        },
        "verification.md": {
          "sha256": "df6ec92c1a825d5c65897ced9eb1a52fa8398b689c841409745852c43148cf42",
          "byte_length": 14413
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
        "import_id": "fbc51992-434b-4f57-9c48-e325545ba708",
        "source_id": "cbb327c9-a85b-41d9-bbcd-2d7cf79f6071",
        "version_id": "ede9b9a9-fea6-4fbf-8fe0-5d0083bea7c1",
        "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "import_id": "fbc51992-434b-4f57-9c48-e325545ba708",
              "manifest_sha256": null,
              "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "parse_id": null,
              "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
              "source_id": "cbb327c9-a85b-41d9-bbcd-2d7cf79f6071",
              "version_id": "ede9b9a9-fea6-4fbf-8fe0-5d0083bea7c1"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "import_id": "fbc51992-434b-4f57-9c48-e325545ba708",
              "manifest_sha256": null,
              "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
              "parse_id": null,
              "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
              "source_id": "cbb327c9-a85b-41d9-bbcd-2d7cf79f6071",
              "version_id": "ede9b9a9-fea6-4fbf-8fe0-5d0083bea7c1"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 12 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s。",
          "actual": "样例 A 的速度为 12 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "7690744d977406855c22a2f73171c58219c44b151f7535d9dbb19aa84245892e",
          "byte_length": 2708
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "cbed5c4d86b933cea42966337dba28719e176be1625d625761f2e320f3d9ae6c",
          "byte_length": 492
        },
        "knowledge-ir.json": {
          "sha256": "63c659fc7cda221f534b18234079fa310aa84fe3253c59bcce109ab6d89fdd47",
          "byte_length": 9243
        },
        "review-original.json": {
          "sha256": "21cbab5301a7320d157eb97782ca735479450232b0e676a3f09cf33756820b21",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "3da12cb33ba74e71fbe26333eb2f21541f1ba49f053296febf83e44bf494ec8a",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "da3a7ddbbacef29bb515c99aa11b865a6a1db1bc967d3373b4f6f1a97668db6e",
          "byte_length": 13979
        },
        "verification.md": {
          "sha256": "fa5421d82921017cd4c6bab0d15bc98fb92569a25c6cba0fa092fc080487450c",
          "byte_length": 14413
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。",
        "sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b"
      },
      "occurrence_id": "occ-8c08896bfdbbb3f1197ddd4512d636288bcb576096b37487e4c17aae0d2c7360",
      "input_id": "b",
      "binding": {
        "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
        "import_id": "fbc51992-434b-4f57-9c48-e325545ba708",
        "source_id": "cbb327c9-a85b-41d9-bbcd-2d7cf79f6071",
        "version_id": "ede9b9a9-fea6-4fbf-8fe0-5d0083bea7c1",
        "content_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "normalized_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "18761af0-db06-4091-ab1b-f0795cb5f85a",
          "ordinal": 0,
          "resource_sha256": "4b924a6c30d44b09958851c72383ecf4247a68877ae514f86915f5ee1eaf9bf3"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "1879b515bcd6cf2b299b2459df09ddf9443c21dc619024eba45bf0e146973c2b",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 12 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-d6add6c25af10d252475088e6f4a93480a50bacc9b27be3d8a626e53b07f0d23",
      "input_id": "a",
      "binding": {
        "project_id": "e6f7bfa0-8614-4aed-b6eb-4f04961334d5",
        "import_id": "d1165b2a-a659-4571-abd7-0112fa486b51",
        "source_id": "6cb76f62-3d34-46a5-a581-519b84e66880",
        "version_id": "c2ae647f-7f3f-4393-8a61-9f9f05732888",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "263bc555-8290-41ee-85ee-fd1db6f340fc",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-92a799aa98a5de725c80607b9a11d6152d805f4149e5d0a18c254772db7749be",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-d6add6c25af10d252475088e6f4a93480a50bacc9b27be3d8a626e53b07f0d23"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-d0907032cb4dc7d590b47392f3074436030610f9e26ed86dbe1816fbcd123321",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-8c08896bfdbbb3f1197ddd4512d636288bcb576096b37487e4c17aae0d2c7360"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-8c08896bfdbbb3f1197ddd4512d636288bcb576096b37487e4c17aae0d2c7360",
      "right_occurrence_id": "occ-d6add6c25af10d252475088e6f4a93480a50bacc9b27be3d8a626e53b07f0d23",
      "relation": "insufficient_evidence",
      "issue_code": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-8c08896bfdbbb3f1197ddd4512d636288bcb576096b37487e4c17aae0d2c7360",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    },
    {
      "occurrence_id": "occ-d6add6c25af10d252475088e6f4a93480a50bacc9b27be3d8a626e53b07f0d23",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 1,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 2,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 2,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "231a104a35ba8535e0099aed252348c10723b81fcc532d2514fd87c1611df512",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "c95d41c75f84126c675a1d301c62ce5690664a81c932a9b104b159c36ff827bf",
      "byte_length": 4326
    },
    "identity-original.json": {
      "sha256": "e01fab6874c65df3cb9ccd83306cac7ddc172f6aad6fa1622e48509fb1b48da9",
      "byte_length": 1902
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "c8931d5644d8f96262e2bb64e30d6e2d52112c18f6702905bf4b6b4c2c197465",
      "byte_length": 2708
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "f68393ea13402c16099132dbb194e34591ed5554dda0988f9eebff47cd1c75f2",
      "byte_length": 492
    },
    "input-a--knowledge-ir.json": {
      "sha256": "30a112f94b3493a1faf9eff59df6e11f4bb5ecaa8fa32401b53a988d7df0b239",
      "byte_length": 9243
    },
    "input-a--review-original.json": {
      "sha256": "5febe091be57f649090a8f0332549c2cb33ac7d9733c299d74eb4574cbfeff3d",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "312e2ac20c0f5d356c6dbd63c9f2ec19401d39678d0dc594c391a893973a1b2b",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "8ec5e546a5bd7d397925d78bcf8a85026aa6fc663ce73e03ad65de2c5a90ed12",
      "byte_length": 13979
    },
    "input-a--verification.md": {
      "sha256": "df6ec92c1a825d5c65897ced9eb1a52fa8398b689c841409745852c43148cf42",
      "byte_length": 14413
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "7690744d977406855c22a2f73171c58219c44b151f7535d9dbb19aa84245892e",
      "byte_length": 2708
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "cbed5c4d86b933cea42966337dba28719e176be1625d625761f2e320f3d9ae6c",
      "byte_length": 492
    },
    "input-b--knowledge-ir.json": {
      "sha256": "63c659fc7cda221f534b18234079fa310aa84fe3253c59bcce109ab6d89fdd47",
      "byte_length": 9243
    },
    "input-b--review-original.json": {
      "sha256": "21cbab5301a7320d157eb97782ca735479450232b0e676a3f09cf33756820b21",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "3da12cb33ba74e71fbe26333eb2f21541f1ba49f053296febf83e44bf494ec8a",
      "byte_length": 974
    },
    "input-b--verification.json": {
      "sha256": "da3a7ddbbacef29bb515c99aa11b865a6a1db1bc967d3373b4f6f1a97668db6e",
      "byte_length": 13979
    },
    "input-b--verification.md": {
      "sha256": "fa5421d82921017cd4c6bab0d15bc98fb92569a25c6cba0fa092fc080487450c",
      "byte_length": 14413
    }
  }
}
```
