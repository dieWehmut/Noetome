# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：1；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "109dc1e7-ac94-479f-bd38-b11e9ccafb9a",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
        "import_id": "b1a808de-3630-4eb7-89b6-0e2ff657e4e6",
        "source_id": "47f56d91-1ef0-463b-8703-6de95edd2139",
        "version_id": "ea262c3e-dd98-46e6-84bb-bc7523015b9a",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "b1a808de-3630-4eb7-89b6-0e2ff657e4e6",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
              "source_id": "47f56d91-1ef0-463b-8703-6de95edd2139",
              "version_id": "ea262c3e-dd98-46e6-84bb-bc7523015b9a"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "b1a808de-3630-4eb7-89b6-0e2ff657e4e6",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
              "source_id": "47f56d91-1ef0-463b-8703-6de95edd2139",
              "version_id": "ea262c3e-dd98-46e6-84bb-bc7523015b9a"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "09602ebe7d46f6a9c5c9dab759157cf9cc4e039ff7f49a80bdd4bd62c7e72447",
          "byte_length": 3051
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "3b841dd1a43ed4bc71fbff817f24e94ab50ba4bc809dbb4d20fdeeb7f609638d",
          "byte_length": 736
        },
        "knowledge-ir.json": {
          "sha256": "42a768da9874bec442eec1f724206a697cdd20ea7710c992063885af939020df",
          "byte_length": 12385
        },
        "review-original.json": {
          "sha256": "84cd5e2f110aedfd69eff1564f5c5d54914f8bbcce8f491ad633bebaf8d5e365",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "6791567006017c09aca6615719b1d57aa4f8a39ed8a4911a17f4cb771645df96",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "eccdab6bd8129a4d2fe7014d29d46db88e41278c6f72ef54a1c111d97a06584e",
          "byte_length": 16860
        },
        "verification.md": {
          "sha256": "a0d070c6018c357a43a09f3a7936917df60b4d9dd8071630163002ec6f68fa1a",
          "byte_length": 17294
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
        "import_id": "790d1b03-8b0d-4903-9e67-623ecb6c70c5",
        "source_id": "5e3723de-d35f-4676-8bca-d63cfb18d8dd",
        "version_id": "6eccefcd-c7f9-4dec-a8f5-43810392e6ab",
        "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "import_id": "790d1b03-8b0d-4903-9e67-623ecb6c70c5",
              "manifest_sha256": null,
              "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "parse_id": null,
              "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
              "source_id": "5e3723de-d35f-4676-8bca-d63cfb18d8dd",
              "version_id": "6eccefcd-c7f9-4dec-a8f5-43810392e6ab"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "import_id": "790d1b03-8b0d-4903-9e67-623ecb6c70c5",
              "manifest_sha256": null,
              "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
              "parse_id": null,
              "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
              "source_id": "5e3723de-d35f-4676-8bca-d63cfb18d8dd",
              "version_id": "6eccefcd-c7f9-4dec-a8f5-43810392e6ab"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 167,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 166,
            "excerpt_sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "quote": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 166,
              "excerpt_sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "km/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "km/s",
          "actual": {
            "measurement": "km/s",
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "km/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 167,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "km/s"
          },
          "actual": [
            "km/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "c2f41d7b4a106f9de68d0ef5352957bf8615287d1f354e09afeb3324c7c6be5f",
          "byte_length": 3055
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "c34f1a45ee3cd500a85e81e6962c7e5ea125bf26de76c0d19aec403e092097dd",
          "byte_length": 739
        },
        "knowledge-ir.json": {
          "sha256": "b4b738ac320bdaaab553cb6bd7b65a147592c4dfe16999c07f7e7060bb829388",
          "byte_length": 12404
        },
        "review-original.json": {
          "sha256": "e9e22c5925a1313632eaee3a9c7d6535eecde8403dd8ee597c094ce0457db277",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "6c095b3a2264aa8cb57b520853fb29011f4c03dd70eb6b900971a6f75952f914",
          "byte_length": 1057
        },
        "verification.json": {
          "sha256": "77351ec20e2adb06a940e4a198260df4aea0567f708fb9a2824521c5dc3a93d6",
          "byte_length": 16876
        },
        "verification.md": {
          "sha256": "ada661620669a8591a41b32531877bccb9a8980a6863b1d1b1158ed550d307cd",
          "byte_length": 17310
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-7a964357da1291a8a3de283fe621f127dd749e9f5c20b9566315a4b6fc2382ff",
      "input_id": "a",
      "binding": {
        "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
        "import_id": "b1a808de-3630-4eb7-89b6-0e2ff657e4e6",
        "source_id": "47f56d91-1ef0-463b-8703-6de95edd2139",
        "version_id": "ea262c3e-dd98-46e6-84bb-bc7523015b9a",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "43646aab-3e57-41d3-945d-3a8a5d4c5bed",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 166,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30"
      },
      "occurrence_id": "occ-ae18a3f6d1d7ba2eec7d94115df5ab53be0c65def775bac46faf042ed70d7532",
      "input_id": "b",
      "binding": {
        "project_id": "d8fa23f5-2808-4438-a420-f70a84d6b0ea",
        "import_id": "790d1b03-8b0d-4903-9e67-623ecb6c70c5",
        "source_id": "5e3723de-d35f-4676-8bca-d63cfb18d8dd",
        "version_id": "6eccefcd-c7f9-4dec-a8f5-43810392e6ab",
        "content_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "normalized_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "1d5bde18-46eb-4c09-8413-e6750995e112",
          "ordinal": 0,
          "resource_sha256": "267124884e4e6579673ffb180a62698fd00c6194403d962d68dcff84a20a2e28"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 167,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "km/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "km/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 166,
          "excerpt_sha256": "d5692e8606cf82a779cbbda482896f91ede0c57ae69533ff3b7536c482459e30",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 km/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "km/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-45514b2b1191f029ec6e3cca45d7d15407fb146d3f3b8033531ccd80de6b5dcc",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "km/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-ae18a3f6d1d7ba2eec7d94115df5ab53be0c65def775bac46faf042ed70d7532"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-71585ac2caed36414e2692879ef09222ae8e60dcf8eef7c928b2ccd0b2ff2bfd",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-7a964357da1291a8a3de283fe621f127dd749e9f5c20b9566315a4b6fc2382ff"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-7a964357da1291a8a3de283fe621f127dd749e9f5c20b9566315a4b6fc2382ff",
      "right_occurrence_id": "occ-ae18a3f6d1d7ba2eec7d94115df5ab53be0c65def775bac46faf042ed70d7532",
      "relation": "insufficient_evidence",
      "issue_code": "COORD_UNIT_NOT_COMPARABLE"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-7a964357da1291a8a3de283fe621f127dd749e9f5c20b9566315a4b6fc2382ff",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNIT_NOT_COMPARABLE"
    },
    {
      "occurrence_id": "occ-ae18a3f6d1d7ba2eec7d94115df5ab53be0c65def775bac46faf042ed70d7532",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNIT_NOT_COMPARABLE"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 1,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 2,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2c94e2fcaa6cb4082da3744fdb0842def6a4c8e546dcbf22d5356274ef98382b",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "8af1f2d616af0ebaf6bd87b21e98a5256a2533e658fbe24cc1bbea121dfea5b1",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "a8ea11ff5a2c5cc4a5e252df5e66ef3e8953fe2eae3632224ed325477a21948a",
      "byte_length": 1898
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "09602ebe7d46f6a9c5c9dab759157cf9cc4e039ff7f49a80bdd4bd62c7e72447",
      "byte_length": 3051
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "3b841dd1a43ed4bc71fbff817f24e94ab50ba4bc809dbb4d20fdeeb7f609638d",
      "byte_length": 736
    },
    "input-a--knowledge-ir.json": {
      "sha256": "42a768da9874bec442eec1f724206a697cdd20ea7710c992063885af939020df",
      "byte_length": 12385
    },
    "input-a--review-original.json": {
      "sha256": "84cd5e2f110aedfd69eff1564f5c5d54914f8bbcce8f491ad633bebaf8d5e365",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "6791567006017c09aca6615719b1d57aa4f8a39ed8a4911a17f4cb771645df96",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "eccdab6bd8129a4d2fe7014d29d46db88e41278c6f72ef54a1c111d97a06584e",
      "byte_length": 16860
    },
    "input-a--verification.md": {
      "sha256": "a0d070c6018c357a43a09f3a7936917df60b4d9dd8071630163002ec6f68fa1a",
      "byte_length": 17294
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "c2f41d7b4a106f9de68d0ef5352957bf8615287d1f354e09afeb3324c7c6be5f",
      "byte_length": 3055
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "c34f1a45ee3cd500a85e81e6962c7e5ea125bf26de76c0d19aec403e092097dd",
      "byte_length": 739
    },
    "input-b--knowledge-ir.json": {
      "sha256": "b4b738ac320bdaaab553cb6bd7b65a147592c4dfe16999c07f7e7060bb829388",
      "byte_length": 12404
    },
    "input-b--review-original.json": {
      "sha256": "e9e22c5925a1313632eaee3a9c7d6535eecde8403dd8ee597c094ce0457db277",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "6c095b3a2264aa8cb57b520853fb29011f4c03dd70eb6b900971a6f75952f914",
      "byte_length": 1057
    },
    "input-b--verification.json": {
      "sha256": "77351ec20e2adb06a940e4a198260df4aea0567f708fb9a2824521c5dc3a93d6",
      "byte_length": 16876
    },
    "input-b--verification.md": {
      "sha256": "ada661620669a8591a41b32531877bccb9a8980a6863b1d1b1158ed550d307cd",
      "byte_length": 17310
    }
  }
}
```
