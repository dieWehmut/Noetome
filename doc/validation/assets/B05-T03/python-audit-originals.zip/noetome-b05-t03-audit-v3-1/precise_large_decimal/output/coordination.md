# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：1；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "7596445c-9544-41e5-9142-36e02401bf4e",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
        "import_id": "195d32f5-3b10-4947-8b7d-4d346e8bc4e5",
        "source_id": "7d458776-cd65-451e-aba5-c337fed9c004",
        "version_id": "4148cab2-7344-4300-8b5c-d16750586f5d",
        "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "import_id": "195d32f5-3b10-4947-8b7d-4d346e8bc4e5",
              "manifest_sha256": null,
              "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "parse_id": null,
              "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
              "source_id": "7d458776-cd65-451e-aba5-c337fed9c004",
              "version_id": "4148cab2-7344-4300-8b5c-d16750586f5d"
            },
            "request_id": "synthetic-conflicts-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "import_id": "195d32f5-3b10-4947-8b7d-4d346e8bc4e5",
              "manifest_sha256": null,
              "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
              "parse_id": null,
              "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
              "source_id": "7d458776-cd65-451e-aba5-c337fed9c004",
              "version_id": "4148cab2-7344-4300-8b5c-d16750586f5d"
            },
            "request_id": "synthetic-conflicts-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 206,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 205,
            "excerpt_sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 205,
              "excerpt_sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "100000000000000000000000000000000000000001",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "100000000000000000000000000000000000000001",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "e8afbf344de04817ef18f954af9a4cd5c648c85541914e149e9d39d38c07ed10",
          "byte_length": 3171
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "ab785d0b5fb6baacaf2b9e30d2d472760cefe8a955f9d8f3e31aaa3a51981d81",
          "byte_length": 856
        },
        "knowledge-ir.json": {
          "sha256": "b1ebbaa64a07ad427b0662d0c99356f0fc110762872add936b8cc127eee68bd8",
          "byte_length": 12825
        },
        "review-original.json": {
          "sha256": "de4de93564a071ef85b2cf2e115e2182f7b3862bdb04928bb85cbdaca6eaeddd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "03166c080450b7647a447354dcad0aa4af37760755e2de414d56002cabf0bed8",
          "byte_length": 1096
        },
        "verification.json": {
          "sha256": "6f15e095ff861397b17ebcd8f1174c7afd340b89f252966beba58f80ce058d40",
          "byte_length": 17220
        },
        "verification.md": {
          "sha256": "e4e3355430fc924c49d5c238ee5e9f141655ff1e5ce30c1b4eac17ee78705bcf",
          "byte_length": 17654
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
        "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
        "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
        "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb",
        "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-conflicts-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
              "manifest_sha256": null,
              "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "parse_id": null,
              "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
              "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
              "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb"
            },
            "request_id": "synthetic-conflicts-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
              "manifest_sha256": null,
              "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
              "parse_id": null,
              "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
              "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
              "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb"
            },
            "request_id": "synthetic-conflicts-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 206,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 205,
            "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 205,
              "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "100000000000000000000000000000000000000002",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "100000000000000000000000000000000000000002",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 206,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
          "byte_length": 139
        },
        "candidates-original.json": {
          "sha256": "4f67b7a64fcec91834f0dbfb0b52c4fe78601869096b0a38ac5fdcb2ccd9273a",
          "byte_length": 3171
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "6e54e87d86ffffe3addbfe943c1cd5adfbb7c9b151fa1e70385e220422561bdb",
          "byte_length": 856
        },
        "knowledge-ir.json": {
          "sha256": "46ada98831ae569617ff7adbfd49ea3c57f8029797c821f69cd65596dbfa16af",
          "byte_length": 12825
        },
        "review-original.json": {
          "sha256": "c18b62d1f27e1546a14a9f534cf007f9bffcd715d17ccff4d35232f4fa72352c",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "f2449c8163da6fba908e2ca147699636c3272cca3e677f0b7e81d5cf4ca28449",
          "byte_length": 1096
        },
        "verification.json": {
          "sha256": "cf436ef48c87cb604381a60e4c041bc958899805dec10c7056a2448d1647cb4b",
          "byte_length": 17220
        },
        "verification.md": {
          "sha256": "c0570400583595d23e9798bc99f881c6803ad3309fd8a0aa4a7dd12e383a2f8b",
          "byte_length": 17654
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90"
      },
      "occurrence_id": "occ-1aac22ea5fe6c105b0f0f43055e425ebfc60684503854676131e80e0cfc6bdc2",
      "input_id": "a",
      "binding": {
        "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
        "import_id": "195d32f5-3b10-4947-8b7d-4d346e8bc4e5",
        "source_id": "7d458776-cd65-451e-aba5-c337fed9c004",
        "version_id": "4148cab2-7344-4300-8b5c-d16750586f5d",
        "content_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "normalized_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "69039ef7-b754-4ead-b899-5d5ee903e23d",
          "ordinal": 0,
          "resource_sha256": "6ae82171e556da78f8aa86843c29cae08b3738d980185f9a20c145003df679f1"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 206,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "100000000000000000000000000000000000000001",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 205,
          "excerpt_sha256": "d00cc6ad61d91d1cc1dece992bc4b2ac0ccfb757d802189b082d9e9ac46e6e90",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000001 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "100000000000000000000000000000000000000001",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc"
      },
      "occurrence_id": "occ-8835ff5db909b14016056bc784438a8395be87de6ac21cd3f26d9cbb2cab50bf",
      "input_id": "b",
      "binding": {
        "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
        "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
        "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
        "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb",
        "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f9572e78-ddf2-49e4-a6c5-6b97effb5dee",
          "ordinal": 0,
          "resource_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 206,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "100000000000000000000000000000000000000002",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 205,
          "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "100000000000000000000000000000000000000002",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-5c2d1fe385927c51f60c1d87e9bf66fc794dd99b79980937a97af1da7695da2d",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "100000000000000000000000000000000000000002",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-8835ff5db909b14016056bc784438a8395be87de6ac21cd3f26d9cbb2cab50bf"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-7ee4c75cae9b2a74d4c616abd902c02abeac3485e3817fbdc8190f4538679f02",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "100000000000000000000000000000000000000001",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-1aac22ea5fe6c105b0f0f43055e425ebfc60684503854676131e80e0cfc6bdc2"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-1aac22ea5fe6c105b0f0f43055e425ebfc60684503854676131e80e0cfc6bdc2",
      "right_occurrence_id": "occ-8835ff5db909b14016056bc784438a8395be87de6ac21cd3f26d9cbb2cab50bf",
      "relation": "true_conflict",
      "issue_code": "COORD_TRUE_CONFLICT"
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-1aac22ea5fe6c105b0f0f43055e425ebfc60684503854676131e80e0cfc6bdc2",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    },
    {
      "occurrence_id": "occ-8835ff5db909b14016056bc784438a8395be87de6ac21cd3f26d9cbb2cab50bf",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "status": "needs_review",
      "issue_codes": [
        "COORD_TRUE_CONFLICT"
      ],
      "action": "retain_for_review",
      "reason": "COORD_TRUE_CONFLICT"
    }
  ],
  "totals": {
    "true_conflicts": 1,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 2,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "1c19f65928c509f291a72da93d490d27ef5b80b554b27cec8d06a7b185d70be3",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "0e242c47cb7711e468ad6503eda0503eb9c2f1e6bd3560a3ec3f094d7d6b78eb",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "a8ea11ff5a2c5cc4a5e252df5e66ef3e8953fe2eae3632224ed325477a21948a",
      "byte_length": 1898
    },
    "input-a--.owner.json": {
      "sha256": "41a8a2f4743f975023d27acb2c97a0d1f27a991b843449265d78e26d4220fa09",
      "byte_length": 139
    },
    "input-a--candidates-original.json": {
      "sha256": "e8afbf344de04817ef18f954af9a4cd5c648c85541914e149e9d39d38c07ed10",
      "byte_length": 3171
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "ab785d0b5fb6baacaf2b9e30d2d472760cefe8a955f9d8f3e31aaa3a51981d81",
      "byte_length": 856
    },
    "input-a--knowledge-ir.json": {
      "sha256": "b1ebbaa64a07ad427b0662d0c99356f0fc110762872add936b8cc127eee68bd8",
      "byte_length": 12825
    },
    "input-a--review-original.json": {
      "sha256": "de4de93564a071ef85b2cf2e115e2182f7b3862bdb04928bb85cbdaca6eaeddd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "03166c080450b7647a447354dcad0aa4af37760755e2de414d56002cabf0bed8",
      "byte_length": 1096
    },
    "input-a--verification.json": {
      "sha256": "6f15e095ff861397b17ebcd8f1174c7afd340b89f252966beba58f80ce058d40",
      "byte_length": 17220
    },
    "input-a--verification.md": {
      "sha256": "e4e3355430fc924c49d5c238ee5e9f141655ff1e5ce30c1b4eac17ee78705bcf",
      "byte_length": 17654
    },
    "input-b--.owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "input-b--candidates-original.json": {
      "sha256": "4f67b7a64fcec91834f0dbfb0b52c4fe78601869096b0a38ac5fdcb2ccd9273a",
      "byte_length": 3171
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "6e54e87d86ffffe3addbfe943c1cd5adfbb7c9b151fa1e70385e220422561bdb",
      "byte_length": 856
    },
    "input-b--knowledge-ir.json": {
      "sha256": "46ada98831ae569617ff7adbfd49ea3c57f8029797c821f69cd65596dbfa16af",
      "byte_length": 12825
    },
    "input-b--review-original.json": {
      "sha256": "c18b62d1f27e1546a14a9f534cf007f9bffcd715d17ccff4d35232f4fa72352c",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "f2449c8163da6fba908e2ca147699636c3272cca3e677f0b7e81d5cf4ca28449",
      "byte_length": 1096
    },
    "input-b--verification.json": {
      "sha256": "cf436ef48c87cb604381a60e4c041bc958899805dec10c7056a2448d1647cb4b",
      "byte_length": 17220
    },
    "input-b--verification.md": {
      "sha256": "c0570400583595d23e9798bc99f881c6803ad3309fd8a0aa4a7dd12e383a2f8b",
      "byte_length": 17654
    }
  }
}
```
