# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-conflicts-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
      "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
      "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
      "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb",
      "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
      "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f9572e78-ddf2-49e4-a6c5-6b97effb5dee",
          "ordinal": 0,
          "resource_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 206,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
    "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
    "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
    "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb",
    "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
    "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "4f67b7a64fcec91834f0dbfb0b52c4fe78601869096b0a38ac5fdcb2ccd9273a",
        "byte_length": 3171
      },
      "decision.json": {
        "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "6e54e87d86ffffe3addbfe943c1cd5adfbb7c9b151fa1e70385e220422561bdb",
        "byte_length": 856
      },
      "review.json": {
        "sha256": "c18b62d1f27e1546a14a9f534cf007f9bffcd715d17ccff4d35232f4fa72352c",
        "byte_length": 510
      }
    },
    "gold_sha256": "6e54e87d86ffffe3addbfe943c1cd5adfbb7c9b151fa1e70385e220422561bdb"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
          "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
          "manifest_sha256": null,
          "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
          "parse_id": null,
          "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
          "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
          "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb"
        },
        "request_id": "synthetic-conflicts-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
          "import_id": "a2b5e5a1-c579-4a4c-b1fb-dca684231b34",
          "manifest_sha256": null,
          "normalized_sha256": "0134b5ca0b2b364c9709f316cae9221a1782656439fc0bb81fc1bad6b85864bc",
          "parse_id": null,
          "project_id": "67683869-c67f-4691-90d8-3f83f11bf45d",
          "source_id": "43ac310f-cf99-4d29-9fc4-87e1c375c519",
          "version_id": "a5ac4376-978b-4cba-8021-2c19158adceb"
        },
        "request_id": "synthetic-conflicts-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 206,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 205,
        "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
        "excerpt_start_byte": 0,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 205,
        "quote": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 205,
          "excerpt_sha256": "338e2ceada9e55653b712fc3dd201bd4ecc7f59a2bd3147f2079da8215d461dc",
          "excerpt_start_byte": 0,
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 100000000000000000000000000000000000000002 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "100000000000000000000000000000000000000002",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "100000000000000000000000000000000000000002",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 206,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2120c1906c9a10a208432d8baafd7326b5e02bf206078c43490c1cfcb75e4970",
      "byte_length": 139
    },
    "candidates-original.json": {
      "sha256": "4f67b7a64fcec91834f0dbfb0b52c4fe78601869096b0a38ac5fdcb2ccd9273a",
      "byte_length": 3171
    },
    "decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "6e54e87d86ffffe3addbfe943c1cd5adfbb7c9b151fa1e70385e220422561bdb",
      "byte_length": 856
    },
    "knowledge-ir.json": {
      "sha256": "46ada98831ae569617ff7adbfd49ea3c57f8029797c821f69cd65596dbfa16af",
      "byte_length": 12825
    },
    "review-original.json": {
      "sha256": "c18b62d1f27e1546a14a9f534cf007f9bffcd715d17ccff4d35232f4fa72352c",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "f2449c8163da6fba908e2ca147699636c3272cca3e677f0b7e81d5cf4ca28449",
      "byte_length": 1096
    }
  }
}
```
