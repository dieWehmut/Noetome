# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f9f82a0ae8588ef1126323cfc9cf105aada74a602809e569b310fbb68351628a"
    },
    "request-body.json": {
      "byte_length": 7360,
      "sha256": "be273a704bb2fe4793af4bcbd0f720e2e4b0f8f38cbd5b24d03bfeaecc82d48c"
    },
    "request.json": {
      "byte_length": 2215,
      "sha256": "8f2cf0e86be94d6a876f0c687068b001d7e70cb8acee8588636be84c22b0825a"
    },
    "response.bin": {
      "byte_length": 1999,
      "sha256": "0a2132e31f8890b3d346cd7058c84ad72dde749f71dcfae6a791fd3aa12c6a5b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a6b0da27-a709-42c6-922f-0633af1d1155",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "58cb978e-3b9e-45f2-abb1-e5a371dc631d",
    "source_id": "6428dfb8-46cd-4cf0-85a0-4458ada3599d",
    "version_id": "1d24420d-dd57-42f0-9d13-2b32b9f11ef8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55707/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_REFUSAL",
      "message": "EXTRACT_API_REFUSAL：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ed81d33a-80f5-4bf4-84f4-d328011ea013",
  "request_strategy": "tangmao-deepseek-chat-qualifiers-v5",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1999,
    "omission_reason": null,
    "sha256": "0a2132e31f8890b3d346cd7058c84ad72dde749f71dcfae6a791fd3aa12c6a5b"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8384,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 7360,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10432
  },
  "validated_atoms": 0
}
```
