# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "2f8f51b717324b60786b6afd2680930984158850d45295e85671f2bb0a681a47"
    },
    "request-body.json": {
      "byte_length": 7360,
      "sha256": "4c32b4255c7d50041e27efa06b55da5a7b84f82941a33d26ef3d0e93077ac7ce"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "fdba440b4f1e306124b8d0f4dea8c31cbdc38f8f496b7651adbb00af8664f49d"
    },
    "response.bin": {
      "byte_length": 1979,
      "sha256": "275459d7b428af0df35b83d5ed269c6671f46f744e34354a4b848ba0f47937a3"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a6b0da27-a709-42c6-922f-0633af1d1155",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "58cb978e-3b9e-45f2-abb1-e5a371dc631d",
    "source_id": "6428dfb8-46cd-4cf0-85a0-4458ada3599d",
    "version_id": "1d24420d-dd57-42f0-9d13-2b32b9f11ef8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55759/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_USAGE",
      "message": "EXTRACT_API_USAGE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "28477e4c-0bec-4699-a776-908013f865f2",
  "request_strategy": "tangmao-deepseek-chat-qualifiers-v5",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 1979,
    "omission_reason": null,
    "sha256": "275459d7b428af0df35b83d5ed269c6671f46f744e34354a4b848ba0f47937a3"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8384,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7360,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10432
  },
  "validated_atoms": 0
}
```
