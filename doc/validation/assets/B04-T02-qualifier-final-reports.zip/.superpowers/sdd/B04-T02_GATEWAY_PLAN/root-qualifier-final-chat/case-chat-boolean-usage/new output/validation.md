# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "83c1101e92c9a661193c2ee798a89ffa3de892933375ae560b084af2ca673200"
    },
    "request-body.json": {
      "byte_length": 7360,
      "sha256": "cac28d0a12dca737539809e47caa327b01d43bc57ab4ddae9c3feffbfbbad1f7"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "d3e6485796ae7e4645ec90edfa800cb7488e16eb636d8d59de938541fede322c"
    },
    "response.bin": {
      "byte_length": 1980,
      "sha256": "39d2c46e804695bd0886b306ad7581bad8ae349b4f8c459efe72d65feca1457f"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a6b0da27-a709-42c6-922f-0633af1d1155",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "58cb978e-3b9e-45f2-abb1-e5a371dc631d",
    "source_id": "6428dfb8-46cd-4cf0-85a0-4458ada3599d",
    "version_id": "1d24420d-dd57-42f0-9d13-2b32b9f11ef8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55763/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_USAGE",
      "message": "EXTRACT_API_USAGE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ceee7414-27d1-4b4f-9886-6fe74ea21ead",
  "request_strategy": "tangmao-deepseek-chat-qualifiers-v5",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 1980,
    "omission_reason": null,
    "sha256": "39d2c46e804695bd0886b306ad7581bad8ae349b4f8c459efe72d65feca1457f"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8384,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7360,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10432
  },
  "validated_atoms": 0
}
```
