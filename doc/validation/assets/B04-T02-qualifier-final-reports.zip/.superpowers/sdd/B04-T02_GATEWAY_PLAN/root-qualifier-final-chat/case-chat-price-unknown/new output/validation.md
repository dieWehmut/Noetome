# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0f4c0557907de1ec509e84d70b47a235f70da932cfb46f544322f9772185c4d1"
    },
    "request-body.json": {
      "byte_length": 7360,
      "sha256": "2156e7c29a42ab3125641bb6db3a2042e95a7a40a880e273e9f5b62a498fd73f"
    },
    "request.json": {
      "byte_length": 2223,
      "sha256": "c9567e46df027c5d124ce2a193e7063dd60538698ddcb2bc3f74a81dc4a1129b"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "a6b0da27-a709-42c6-922f-0633af1d1155",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "58cb978e-3b9e-45f2-abb1-e5a371dc631d",
    "source_id": "6428dfb8-46cd-4cf0-85a0-4458ada3599d",
    "version_id": "1d24420d-dd57-42f0-9d13-2b32b9f11ef8"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55790/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_PRICE_UNKNOWN",
      "message": "EXTRACT_PRICE_UNKNOWN：价格未知，无法证明金额预算；未调用。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d4794ba4-e5d3-47c8-b223-bf5d9c7fa196",
  "request_strategy": "tangmao-deepseek-chat-qualifiers-v5",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8384,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7360,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10432
  },
  "validated_atoms": 0
}
```
