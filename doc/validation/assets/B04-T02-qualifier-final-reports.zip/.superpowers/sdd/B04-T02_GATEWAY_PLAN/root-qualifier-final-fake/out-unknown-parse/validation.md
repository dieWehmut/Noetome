# 离线 fake 候选验证

状态：failed

请求：fd647591-9a0a-49ce-80aa-383390a7608e
来源版本：865e56ca-2d1e-4eda-85c3-ffd3bfab9abf
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2084 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_BINDING: EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "fd647591-9a0a-49ce-80aa-383390a7608e",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "6c1b541d-fef9-48f3-a072-29f58dc8607f",
    "source_id": "8b23d6eb-75b8-46bb-b34f-126fb11a1ef0",
    "version_id": "865e56ca-2d1e-4eda-85c3-ffd3bfab9abf",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2084,
    "output_bytes": 2084,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_BINDING",
      "message": "EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "892b412c96cf27d41967032b2f607876129e82595eeb969582ccaadec9dea249",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "8a4a5bd36e551fd1599c99f3ec13cee1895c4659e3e9231eb095e0201a57ab87",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "1c6992672c44a606777a25306151c3be06aeefb6ffed00e1aa07571292a221e5",
      "byte_length": 2084
    }
  }
}
```
