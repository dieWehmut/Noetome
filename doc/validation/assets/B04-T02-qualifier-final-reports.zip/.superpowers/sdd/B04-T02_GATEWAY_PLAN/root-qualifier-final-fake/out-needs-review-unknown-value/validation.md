# 离线 fake 候选验证

状态：candidates_validated

请求：dadf0116-2dab-403f-a768-2a390cc3c9e4
来源版本：069c1519-794f-4a93-a948-a939e4739417
来源状态：needs_review
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 56 字节；输出 1898 计量单位；预留 8248 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "dadf0116-2dab-403f-a768-2a390cc3c9e4",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "b199d274-78c2-46fe-b01c-1103fdb2dff3",
    "source_id": "2ec9a366-0663-4b26-819e-3c34e3ce55d8",
    "version_id": "069c1519-794f-4a93-a948-a939e4739417",
    "content_sha256": "0f930cfb984cb91754ebeb8dc245e57ed490cf7fb3d487d8cf384011cd2f3c92",
    "normalized_sha256": "036f70c8257857485962d54674813b42fe4fe1d05adbf57e0bc7ac4aa9023ec5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "needs_review"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 56,
    "input_bytes": 56,
    "output_tokens": 1898,
    "output_bytes": 1898,
    "reserved_tokens": 8248,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "c428759f8175d8f1fac0b12b67e7df04f438f68d31ad88e2ba1dd664a80ba169",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "818e2e79efd6249b96062c2562116743f20a557fdc52c0e967534ec4ce230986",
      "byte_length": 2024
    },
    "request.json": {
      "sha256": "65ab0f86b08087b7eba0d45bf04b70a1169b37f145a54553c2eeb98441368806",
      "byte_length": 1282
    },
    "response.bin": {
      "sha256": "436082751b4380919514c5601c3c8dddba2feb9d53d485e0095034df007ce48a",
      "byte_length": 1898
    }
  }
}
```
