# 离线 fake 候选验证

状态：failed

请求：7edb5a55-23e9-4692-a00b-d2f3317dcc1e
来源版本：865e56ca-2d1e-4eda-85c3-ffd3bfab9abf
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 141 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_OUTPUT_TOKENS: EXTRACT_OUTPUT_TOKENS：完整fake响应超过fake UTF-8字节token上限。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "7edb5a55-23e9-4692-a00b-d2f3317dcc1e",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "6c1b541d-fef9-48f3-a072-29f58dc8607f",
    "source_id": "8b23d6eb-75b8-46bb-b34f-126fb11a1ef0",
    "version_id": "865e56ca-2d1e-4eda-85c3-ffd3bfab9abf",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 141,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_OUTPUT_TOKENS",
      "message": "EXTRACT_OUTPUT_TOKENS：完整fake响应超过fake UTF-8字节token上限。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "dcf6004b0a0012e8790e66e01ba0717cab169d5cc46481921798db5c8b921169",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "1177ed7d1b31be87115b0cc75d7fc6826a133647f00cfff3761d90fca9d949ba",
      "byte_length": 1357
    },
    "response.bin": {
      "sha256": "80f90f59f943084af7f7105710c09eacb557132766346bb8ffbbf5fed81177f3",
      "byte_length": 2050
    }
  }
}
```
