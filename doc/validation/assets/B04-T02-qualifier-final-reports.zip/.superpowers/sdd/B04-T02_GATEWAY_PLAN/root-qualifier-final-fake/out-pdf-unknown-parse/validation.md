# 离线 fake 候选验证

状态：failed

请求：cd2be186-f9f2-4054-b142-05b89f4fb3cb
来源版本：40809fa0-65a4-4174-87d5-5dfb9ac42345
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_BINDING: EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "cd2be186-f9f2-4054-b142-05b89f4fb3cb",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "108217eb-31e2-4d16-a496-ac49f089e7c8",
    "source_id": "9dc0d18d-6ef8-4c8d-b592-3eaa30653f1c",
    "version_id": "40809fa0-65a4-4174-87d5-5dfb9ac42345",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "ce14d895-30d5-4df2-a7b0-3068b084596b",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_BINDING",
      "message": "EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "a6bc64c6b4f27c0c80e62e4777a89e1a880dfc7400f4bd23c27fb2330e431e12",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "88422f9d604a8fae9b176252e6b507321b26ee57fd4735e921235269c21e9833",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "b9547c15d34ce90b032f11267cd34236a9ea6036e03895dfc5cd158e52578d7e",
      "byte_length": 1935
    }
  }
}
```
