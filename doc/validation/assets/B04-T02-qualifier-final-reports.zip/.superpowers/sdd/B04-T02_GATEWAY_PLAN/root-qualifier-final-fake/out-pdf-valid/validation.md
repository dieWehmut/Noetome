# 离线 fake 候选验证

状态：candidates_validated

请求：a069cd57-9adf-4215-b461-988a22d07eb2
来源版本：40809fa0-65a4-4174-87d5-5dfb9ac42345
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "a069cd57-9adf-4215-b461-988a22d07eb2",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "108217eb-31e2-4d16-a496-ac49f089e7c8",
    "source_id": "9dc0d18d-6ef8-4c8d-b592-3eaa30653f1c",
    "version_id": "40809fa0-65a4-4174-87d5-5dfb9ac42345",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "ce14d895-30d5-4df2-a7b0-3068b084596b",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "e27fe3c478b91f168414b1656fcdc183a98da3744543a97d57408becb1b1b224",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "666ddfb6aeefea81c857eeb0afc1676b954230c4939202d1d380e64d7a0bdd24",
      "byte_length": 2061
    },
    "request.json": {
      "sha256": "767641205b0e46bc62d42460c48f66e58065429a42b16df401563109ca7564a2",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "0eff49700f189c3fe4645dfeca49908067392f47b4a11a210305a97bea54a20a",
      "byte_length": 1935
    }
  }
}
```
