# 离线 fake 候选验证

状态：candidates_validated

请求：e9e0ef97-460b-4f6c-8031-58a5c0b73b79
来源版本：865e56ca-2d1e-4eda-85c3-ffd3bfab9abf
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "e9e0ef97-460b-4f6c-8031-58a5c0b73b79",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "6c1b541d-fef9-48f3-a072-29f58dc8607f",
    "source_id": "8b23d6eb-75b8-46bb-b34f-126fb11a1ef0",
    "version_id": "865e56ca-2d1e-4eda-85c3-ffd3bfab9abf",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "b30b4d861dd6c11f6c7b86aa16fd84b21eacf7c79e6e4acc7f36aa7044c1bbc7",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "bda3864fb2fdc0d5c577f132fe2425116ef77f7c8659b79806c3d3f94755b5a2",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "163267b9d141145910b1b3b3b6eb59b60aa08310dad34ccabcb09330855e117c",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "93973226e33554bdcd0b63271d6a13b817d284e731f4bd4fa14db890d2d72c6a",
      "byte_length": 2050
    }
  }
}
```
