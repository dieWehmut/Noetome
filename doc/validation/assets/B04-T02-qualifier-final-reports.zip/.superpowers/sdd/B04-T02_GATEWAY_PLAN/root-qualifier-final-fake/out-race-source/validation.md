# 离线 fake 候选验证

状态：failed

请求：86a3fc46-18b4-4305-a372-f4fd41174d40
来源版本：865e56ca-2d1e-4eda-85c3-ffd3bfab9abf
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_CHANGED: EXTRACT_SOURCE_CHANGED：来源身份、mtime或递归清单发生变化。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "86a3fc46-18b4-4305-a372-f4fd41174d40",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "6c1b541d-fef9-48f3-a072-29f58dc8607f",
    "source_id": "8b23d6eb-75b8-46bb-b34f-126fb11a1ef0",
    "version_id": "865e56ca-2d1e-4eda-85c3-ffd3bfab9abf",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_CHANGED",
      "message": "EXTRACT_SOURCE_CHANGED：来源身份、mtime或递归清单发生变化。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "3a29e5680edae14f2f228e9a3d8266be36618759226e3824fd10b7b642585a9a",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "7a62edcf5d1c856576f6243465a2642c1b44ab34f001cfe3c3bc4167e16b00b9",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "22ca6774b63c809429f03cd46a581b7fd3d6af4ddedceda41e080690c97befce",
      "byte_length": 2050
    }
  }
}
```
