# 离线 fake 候选验证

状态：candidates_validated

请求：abf615bb-0531-452d-b472-b2fe067a6f7d
来源版本：865e56ca-2d1e-4eda-85c3-ffd3bfab9abf
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "abf615bb-0531-452d-b472-b2fe067a6f7d",
  "binding": {
    "project_id": "4f1945cd-ea67-471d-a83f-7d6da8785285",
    "import_id": "6c1b541d-fef9-48f3-a072-29f58dc8607f",
    "source_id": "8b23d6eb-75b8-46bb-b34f-126fb11a1ef0",
    "version_id": "865e56ca-2d1e-4eda-85c3-ffd3bfab9abf",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "ccf0397ff44227634a93ebe34b458ded2793b20558c73df5fcfd2fb3d3fdd767",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "861d2af97659c3453142fc865a407a017cc0344bcff582a9cc541a0297e510cc",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "b45478b0ba7ff44dcbf626c23f7d539e70b9a81a24e2507d6a5f8eaac3421ff1",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "cff9f5b53fd5f51cf062972af193d52bbf6d0468c974c9facda0c25d2d67f6f9",
      "byte_length": 2050
    }
  }
}
```
