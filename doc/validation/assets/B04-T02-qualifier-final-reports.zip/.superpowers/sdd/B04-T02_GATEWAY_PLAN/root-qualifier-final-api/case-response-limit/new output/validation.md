# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3242e0a97d36fcd2a1cda7f69687a975ab9c03a07c7442c1ef98e2ff667f0902"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "dc76099a0f4f13e2c3fbc83b5563969dec0ff3cfe574583d879f3caa6a00b902"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "f664b7780ef235cc69d5416d16d20779e83a110cf43bcb005d6c517c261eb8f8"
    },
    "response.bin": {
      "byte_length": 128,
      "sha256": "213d0b5648f5e6bd9e82542caeb2dcbc535f98607675323fb7570660b4d0ce8c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4abeaa20-64d1-4084-9e9d-ab65221881b8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "33079a1b-4738-4500-9982-27b31140cfbb",
    "source_id": "8ab433a7-5e37-4ca4-b18e-97ca189a4fdc",
    "version_id": "0ddcfee3-9f97-475b-ac1c-ce131238c6a2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52595/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_RESPONSE_LIMIT",
      "message": "EXTRACT_RESPONSE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "33fb0d5c-f0a3-4bd6-8bc9-ae1c6b30ec77",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 128,
    "omission_reason": null,
    "sha256": "213d0b5648f5e6bd9e82542caeb2dcbc535f98607675323fb7570660b4d0ce8c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
