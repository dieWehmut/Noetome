# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "44d80c772d9d13905a19a374ed83a6f67fe610682209ff395d64eb35c7e58135"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4b75682372f6334346e42d70245e7a4645061132b41f3eb5f968f3b92f37e3a5"
    },
    "request.json": {
      "byte_length": 2204,
      "sha256": "6d094c740793b10b0652d14edba93e6693c7605a7732c42c6bdd247c44a9ae15"
    },
    "response.bin": {
      "byte_length": 2110,
      "sha256": "e42c6d2f645b70c4c14434fc9adb0bb20c7e886af4865b34ad25d81602b13c14"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4abeaa20-64d1-4084-9e9d-ab65221881b8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "33079a1b-4738-4500-9982-27b31140cfbb",
    "source_id": "8ab433a7-5e37-4ca4-b18e-97ca189a4fdc",
    "version_id": "0ddcfee3-9f97-475b-ac1c-ce131238c6a2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52578/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_USAGE",
      "message": "EXTRACT_API_USAGE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "619d2b56-b73d-4a8f-9e1d-2dfd17077fa2",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2110,
    "omission_reason": null,
    "sha256": "e42c6d2f645b70c4c14434fc9adb0bb20c7e886af4865b34ad25d81602b13c14"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
