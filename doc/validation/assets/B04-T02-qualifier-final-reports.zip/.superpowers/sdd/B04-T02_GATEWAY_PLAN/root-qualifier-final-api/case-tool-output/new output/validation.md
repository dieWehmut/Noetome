# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7709389cf953f4b8410c7fe06763de7224e524b7b1d405998539f9c4c758f7c3"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "b7310d7a3a82d7e7e689967df2af65a7107e4a7f48854db4c3ac2766d878498c"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "1cbaf5046cac46dca498f3202588d45bea7234c7fb13686211693b2798199794"
    },
    "response.bin": {
      "byte_length": 2152,
      "sha256": "6bc33ff35610d8aa7ffe34278f7be8492427ede61bbae14aaa45b3127abe4558"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4abeaa20-64d1-4084-9e9d-ab65221881b8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "33079a1b-4738-4500-9982-27b31140cfbb",
    "source_id": "8ab433a7-5e37-4ca4-b18e-97ca189a4fdc",
    "version_id": "0ddcfee3-9f97-475b-ac1c-ce131238c6a2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55825/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_OUTPUT",
      "message": "EXTRACT_API_OUTPUT：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "11472ee9-decd-4bda-9881-a84a57953493",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2152,
    "omission_reason": null,
    "sha256": "6bc33ff35610d8aa7ffe34278f7be8492427ede61bbae14aaa45b3127abe4558"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
