# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "294fb72a5cfed9296f8ec9529827e091142504e7b9a77b76a1663757324d6259"
    },
    "candidates.json": {
      "byte_length": 2755,
      "sha256": "a39f346f8c20b1f0e34d65f2d506e4b0b415ed3273e35b4fccf3613e35a221ca"
    },
    "request-body.json": {
      "byte_length": 5144,
      "sha256": "272d5d2d3bbb7c8a69161498549455c7173ec7f731317902c7a3d03f6fd96e10"
    },
    "request.json": {
      "byte_length": 2163,
      "sha256": "2f9e13205b0b6515e740cdf538ae6eaa7e691ddd37df55cc378c2a84187eab8e"
    },
    "response.bin": {
      "byte_length": 2110,
      "sha256": "412b23a9354524517c152218afc64f5bc18628b71aa94e8001ce450611e3b018"
    }
  },
  "binding": {
    "content_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "import_id": "a6d66f90-04c3-4144-bfe6-8b77c2989bd0",
    "manifest_sha256": null,
    "normalized_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "parse_id": null,
    "project_id": "c7cb8dca-c871-45e6-b2a4-2e6d5bb007a7",
    "source_id": "872a8f84-2668-4b1b-9758-795243727e4b",
    "version_id": "2ce80cd4-d4eb-4d61-83f0-ca32f38b3f57"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:55700/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "4fc7befc-78fd-482a-b218-9360a50248c5",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2110,
    "omission_reason": null,
    "sha256": "412b23a9354524517c152218afc64f5bc18628b71aa94e8001ce450611e3b018"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6168,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5144,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8216
  },
  "validated_atoms": 1
}
```
