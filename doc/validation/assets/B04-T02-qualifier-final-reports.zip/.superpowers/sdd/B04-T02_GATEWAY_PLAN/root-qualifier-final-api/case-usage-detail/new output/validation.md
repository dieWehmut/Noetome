# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "e9c1b3730f0a8ea6ea0f5ba1fcaccf2b79f869f4cf7e66b2e4cddd8dbbdc62c7"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "22d4d2feea8f881d28cfb7551937f02f46e762a219e1d982c98fac79f18899fb"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "50e73a9ad0fc2ab892f92ae677ee2195a9531b0a4f90a0b862cc8530b5d081f5"
    },
    "response.bin": {
      "byte_length": 2109,
      "sha256": "17a3b32a8286d9588308509ff43d7abec00af9e0c5bccfa7236d20c3c89d50b9"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "4abeaa20-64d1-4084-9e9d-ab65221881b8",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "33079a1b-4738-4500-9982-27b31140cfbb",
    "source_id": "8ab433a7-5e37-4ca4-b18e-97ca189a4fdc",
    "version_id": "0ddcfee3-9f97-475b-ac1c-ce131238c6a2"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:52580/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_USAGE",
      "message": "EXTRACT_API_USAGE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "c31b08a7-99de-4ff9-92aa-bc35aa2e855f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2109,
    "omission_reason": null,
    "sha256": "17a3b32a8286d9588308509ff43d7abec00af9e0c5bccfa7236d20c3c89d50b9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
