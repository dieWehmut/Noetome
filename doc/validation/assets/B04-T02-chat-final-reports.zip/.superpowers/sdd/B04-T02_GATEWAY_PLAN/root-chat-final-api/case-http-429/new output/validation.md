# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6b2ea3056d8de1ef0b7a17d308a1a066fc8cb01c3cdb9d30618207400c53545c"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "8436834435a0d6268b67e6326145345462b280dc3cb154c8258fadc99f8dd70b"
    },
    "request.json": {
      "byte_length": 2193,
      "sha256": "5e70a9c70b9ca52150f35c1c7c4792cf9229fb8454641bf3893ebad5db22c5c9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "ccf6b8027a9c9bcccc484b587b8418d4dd77fe6c9f398eac8916e9d56a302aed"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bccfa716-0bdc-45ce-98b4-21e96128ee96",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b3e1d4a1-f58d-424a-8fa7-6f20b5807ee0",
    "source_id": "7c0d1e13-cac9-4e04-ac17-3988800c0f1e",
    "version_id": "fce7261b-3b2b-4f29-988f-03d723191d66"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58942/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "9e92630a-592b-44a4-83bd-51b9b8abe2dd",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "ccf6b8027a9c9bcccc484b587b8418d4dd77fe6c9f398eac8916e9d56a302aed"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
