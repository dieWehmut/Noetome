# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "192176fce4611d871933d00b51406d960fa1097716e44bc1d52df977e4ffe3ef"
    },
    "request-body.json": {
      "byte_length": 5236,
      "sha256": "94d037c39335696162bcdbeaed16519192ed0a62aa5227ec7771f5434487301c"
    },
    "request.json": {
      "byte_length": 2201,
      "sha256": "caf1ece490b82a71e7921b7e027bf5086ad2cc3a6347ac919d2b8af1e34fa274"
    },
    "response.bin": {
      "byte_length": 2107,
      "sha256": "484f8465ab671b64e9bbe07c101bd970cc667c8c32b5c12bc8f78bc399441543"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bccfa716-0bdc-45ce-98b4-21e96128ee96",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b3e1d4a1-f58d-424a-8fa7-6f20b5807ee0",
    "source_id": "7c0d1e13-cac9-4e04-ac17-3988800c0f1e",
    "version_id": "fce7261b-3b2b-4f29-988f-03d723191d66"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63111/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_BUDGET_STOP",
      "message": "EXTRACT_BUDGET_STOP：已验证的实际模型用量超过输入预留、输出限制或总预算；不再调用。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2a3d4db9-2686-47a8-bb1e-8865ff9f4443",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2107,
    "omission_reason": null,
    "sha256": "484f8465ab671b64e9bbe07c101bd970cc667c8c32b5c12bc8f78bc399441543"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6260,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 17,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 117
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5236,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 6276
  },
  "validated_atoms": 0
}
```
