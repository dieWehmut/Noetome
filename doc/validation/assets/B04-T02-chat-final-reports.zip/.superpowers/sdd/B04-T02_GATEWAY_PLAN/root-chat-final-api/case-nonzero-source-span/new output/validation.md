# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6142c017683b23f89187c118b706714390ed79eaeb553be035ffceb1be81f7d1"
    },
    "candidates.json": {
      "byte_length": 2755,
      "sha256": "5ff4ed6acf89afaee9b699d96e856e4d9abbdd50d5902b3ac830d1ab7d9467ee"
    },
    "request-body.json": {
      "byte_length": 5144,
      "sha256": "45b2b718dda5dca27ff9a6721eddbb0fb21730e17ba560b8fbd08dde3808d984"
    },
    "request.json": {
      "byte_length": 2158,
      "sha256": "4b3460ef6a1e0c701d0b4ac7a6d48e1587dd86acdccee12064da5867745c773b"
    },
    "response.bin": {
      "byte_length": 2110,
      "sha256": "ccd66925079d7cdb38f72d88dfa523248ac659b1e7c7a134ff314d28bab3f2f8"
    }
  },
  "binding": {
    "content_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "import_id": "e1137c01-bdfd-4ea1-b025-127ebc4d787d",
    "manifest_sha256": null,
    "normalized_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "parse_id": null,
    "project_id": "b90ed941-5ab0-4474-9c03-1c66d9a1acb8",
    "source_id": "329eb94c-e725-4fbe-8138-25ac9ee9676f",
    "version_id": "44e0b385-de90-42d9-a59c-2cf543a347a9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58922/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "5336f6da-d433-4003-908a-284e748de4c8",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2110,
    "omission_reason": null,
    "sha256": "ccd66925079d7cdb38f72d88dfa523248ac659b1e7c7a134ff314d28bab3f2f8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6168,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5144,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8216
  },
  "validated_atoms": 1
}
```
