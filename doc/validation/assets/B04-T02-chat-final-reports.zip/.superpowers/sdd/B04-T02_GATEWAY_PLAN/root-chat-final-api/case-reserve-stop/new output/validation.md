# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "0f67e90fb8573b9c3b1f3fdb48d1168401f6e715d8df71b430e45e648c07a181"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "000dacff001ffe65ffe3c2e3f6997790a0a8ff6095018cf7780db0607133c248"
    },
    "request.json": {
      "byte_length": 2196,
      "sha256": "a757a3e7dfd438c369aa632baa23c541a199eef27d2b1801c757957c38d35848"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bccfa716-0bdc-45ce-98b4-21e96128ee96",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b3e1d4a1-f58d-424a-8fa7-6f20b5807ee0",
    "source_id": "7c0d1e13-cac9-4e04-ac17-3988800c0f1e",
    "version_id": "fce7261b-3b2b-4f29-988f-03d723191d66"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63114/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_BUDGET_STOP",
      "message": "EXTRACT_BUDGET_STOP：单次请求次数或预留总量超过明确预算；未调用。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bd60eeb0-1f7d-4490-a6d4-156bbc57d852",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
