# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "06de7ed10075aadde95f736f35777026477ffbdbf5659f84a2ebc414924bc8ff"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "868703db886f0f2e7c8e02afe3eb7cd10575bab4ee37c84524ca3ce558312808"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "a7a161866e47b3775a5e202dd036d5aeb3686b52685b6f2d84b4e10e63383a6d"
    },
    "request.json": {
      "byte_length": 2191,
      "sha256": "4581228e8ad93a7434c4ae08f39118d6f31ccc52171e96c67aecd95551bf0b3e"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "59a309ebe4bc6ec78582b2defcfa3e3246765e4541f8c4fcc7c23e7cdf7e7268"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "bccfa716-0bdc-45ce-98b4-21e96128ee96",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "b3e1d4a1-f58d-424a-8fa7-6f20b5807ee0",
    "source_id": "7c0d1e13-cac9-4e04-ac17-3988800c0f1e",
    "version_id": "fce7261b-3b2b-4f29-988f-03d723191d66"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58913/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "0fe2ef2c-41bf-4362-885c-dfe281fddfd4",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "59a309ebe4bc6ec78582b2defcfa3e3246765e4541f8c4fcc7c23e7cdf7e7268"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 1
}
```
