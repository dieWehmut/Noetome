# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "06f6a8673f1bda47d63fa9ad306a6ddbe408375d3acaae280d5d0a69ede86757"
    },
    "request-body.json": {
      "byte_length": 6451,
      "sha256": "3e7700f208947db9d8f3b49159685e818aef942f000f0a6f8370cad80d5af23b"
    },
    "request.json": {
      "byte_length": 2229,
      "sha256": "9fbbbd58ecc369d7474861b1556bbf3f84ed67a9353f8832ef607e08d2ea0c24"
    },
    "response.bin": {
      "byte_length": 2006,
      "sha256": "144e405fe038a6f44c4f30fcaa10c26145b050fea318cb58b3b86d117188587c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "190d73e4-4433-4112-ac4c-0ac29ce273d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "23e02288-daf5-48e8-ba77-aae3659c3a88",
    "source_id": "0933f16e-4f41-4ef5-9cea-0c346c2edd94",
    "version_id": "45b9791a-e4b0-4fad-ad97-929eaea49597"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58965/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_RESPONSE",
      "message": "EXTRACT_API_RESPONSE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "56eef9c9-621a-4593-bb8e-ea7e3f5599f2",
  "request_strategy": "tangmao-deepseek-chat-json-object-no-thinking-v3",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2006,
    "omission_reason": null,
    "sha256": "144e405fe038a6f44c4f30fcaa10c26145b050fea318cb58b3b86d117188587c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 7475,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 6451,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 9523
  },
  "validated_atoms": 0
}
```
