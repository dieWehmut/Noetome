# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f148f30ae87f429d4fb718419a063434b97e03a02b53f0a8a411b3d23d06383b"
    },
    "request-body.json": {
      "byte_length": 6451,
      "sha256": "4f57298de823f2473bcacbcf691ff89fe90a887cde4d3f5f89f8911895c5d826"
    },
    "request.json": {
      "byte_length": 2230,
      "sha256": "c2aa2228f525f4eee1430508717507e7c33da8e05c5f73cc6a0501314c58d203"
    },
    "response.bin": {
      "byte_length": 1996,
      "sha256": "c66b21bee41687f4258050149a98e0b0bdca0a23c5611b6fb481e461e493c615"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "190d73e4-4433-4112-ac4c-0ac29ce273d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "23e02288-daf5-48e8-ba77-aae3659c3a88",
    "source_id": "0933f16e-4f41-4ef5-9cea-0c346c2edd94",
    "version_id": "45b9791a-e4b0-4fad-ad97-929eaea49597"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58957/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_CANDIDATES",
      "message": "EXTRACT_API_CANDIDATES：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "e350223c-9a61-4da5-a7a4-88b5950715a0",
  "request_strategy": "tangmao-deepseek-chat-json-object-no-thinking-v3",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1996,
    "omission_reason": null,
    "sha256": "c66b21bee41687f4258050149a98e0b0bdca0a23c5611b6fb481e461e493c615"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 7475,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 6451,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 9523
  },
  "validated_atoms": 0
}
```
