# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "4f06956c186bb33a3b8825bf4758e8c012bf93c9bc88b7abb280a6821e8f031b"
    },
    "request-body.json": {
      "byte_length": 6451,
      "sha256": "29617ea9f1e2a8052ddb31d4147b6df6b2a69eb6f06612c69b49efb8dd012558"
    },
    "request.json": {
      "byte_length": 2225,
      "sha256": "19afc65a72370f443dca063267cc5301c63d75af552fc179b66d98aafb918a29"
    },
    "response.bin": {
      "byte_length": 1974,
      "sha256": "beed7584a5a77c81d134bc42e2018f81db23f8a7e51fbae725c3252d1bf855b0"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "190d73e4-4433-4112-ac4c-0ac29ce273d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "23e02288-daf5-48e8-ba77-aae3659c3a88",
    "source_id": "0933f16e-4f41-4ef5-9cea-0c346c2edd94",
    "version_id": "45b9791a-e4b0-4fad-ad97-929eaea49597"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58949/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_OUTPUT",
      "message": "EXTRACT_API_OUTPUT：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "bd0842f1-e4fe-442a-b1cb-b95f349b3bc7",
  "request_strategy": "tangmao-deepseek-chat-json-object-no-thinking-v3",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1974,
    "omission_reason": null,
    "sha256": "beed7584a5a77c81d134bc42e2018f81db23f8a7e51fbae725c3252d1bf855b0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 7475,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 6451,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 9523
  },
  "validated_atoms": 0
}
```
