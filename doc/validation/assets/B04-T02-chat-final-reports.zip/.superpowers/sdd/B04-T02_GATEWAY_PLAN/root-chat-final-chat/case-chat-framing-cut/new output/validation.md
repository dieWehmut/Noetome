# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：false。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6918820d3eea64924beabfa634e852cb2658337cd52c4a22b2ac4bb1ed81e4e6"
    },
    "request-body.json": {
      "byte_length": 6451,
      "sha256": "7cb8062a411a24bbba74dcb9f0f584dd2f9baf6e8511246068d70761b9b7491b"
    },
    "request.json": {
      "byte_length": 2226,
      "sha256": "9d250397f14d00a94649b810bba7f9f089827dd80859e7462f12ae0ad4a1ee34"
    },
    "response.bin": {
      "byte_length": 1979,
      "sha256": "d722aa11debf78032f1dc4d4683ff0be23ff590f539116799d87c91b74867c49"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "190d73e4-4433-4112-ac4c-0ac29ce273d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "23e02288-daf5-48e8-ba77-aae3659c3a88",
    "source_id": "0933f16e-4f41-4ef5-9cea-0c346c2edd94",
    "version_id": "45b9791a-e4b0-4fad-ad97-929eaea49597"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58992/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_TRUNCATED",
      "message": "EXTRACT_API_TRUNCATED：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "dabb4f40-e69a-4208-8148-25210bad43c5",
  "request_strategy": "tangmao-deepseek-chat-json-object-no-thinking-v3",
  "response_complete": false,
  "response_id": null,
  "response_receipt": {
    "byte_length": 1979,
    "omission_reason": null,
    "sha256": "d722aa11debf78032f1dc4d4683ff0be23ff590f539116799d87c91b74867c49"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 7475,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 6451,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 9523
  },
  "validated_atoms": 0
}
```
