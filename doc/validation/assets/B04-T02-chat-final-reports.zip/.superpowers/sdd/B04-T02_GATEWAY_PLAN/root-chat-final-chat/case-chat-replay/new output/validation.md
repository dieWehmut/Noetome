# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f1c3c38007940712bc3ec8e59b3b8ddc3804d2d1f6f7cfad0af96b5c973880b6"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "97398f422d194232b8e2e0adadafae6919f9120ccf9153ee8cc2471edd30fcbf"
    },
    "request-body.json": {
      "byte_length": 6451,
      "sha256": "ef34981afa2e7e74525c1b1ce8bb726495504b76a0329cdcc2822955e02a8788"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "6950f2129163220da7dd65b65a2337b1dd19fc8c7e9a0645aa8bb6cc0e1a0a40"
    },
    "response.bin": {
      "byte_length": 1979,
      "sha256": "4d8a9eae64b08ec3efeabe1b245e16dee38c55f72bcdb1421aa7b18469afce44"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "190d73e4-4433-4112-ac4c-0ac29ce273d4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "23e02288-daf5-48e8-ba77-aae3659c3a88",
    "source_id": "0933f16e-4f41-4ef5-9cea-0c346c2edd94",
    "version_id": "45b9791a-e4b0-4fad-ad97-929eaea49597"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:58914/v1/chat/completions",
  "errors": [],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8240c4b8-145e-40bf-b9fa-cdf42758efb8",
  "request_strategy": "tangmao-deepseek-chat-json-object-no-thinking-v3",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1979,
    "omission_reason": null,
    "sha256": "4d8a9eae64b08ec3efeabe1b245e16dee38c55f72bcdb1421aa7b18469afce44"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 7475,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 6451,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 9523
  },
  "validated_atoms": 1
}
```
