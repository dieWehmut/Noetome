# 离线 fake 候选验证

状态：candidates_validated

请求：7e199969-357d-4d55-b693-52ace8a4ab62
来源版本：c0d42ae8-4937-430b-9f0e-0c4b66a6f69e
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "7e199969-357d-4d55-b693-52ace8a4ab62",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "c4c189a5-01c7-4112-af79-4ecd101d01de",
    "source_id": "6544d367-1045-4b42-9500-f550dfea91ca",
    "version_id": "c0d42ae8-4937-430b-9f0e-0c4b66a6f69e",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "fb5ed4639465e6cfd0019a3ff7dd34671c477410669f4f543c2bdf1391c9874a",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "99df56a22fe88535f98db73a2f44840bbe7e3d118efa594b32d5a0c1d2515319",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "b588167f61a15de268d95f8804ce9f78592f9fbc5b44c76d8667450e36993815",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "59d3ac106bf27761e89540c3ca2fdf1fb91ed8f23c364f4eb7b345922142a80f",
      "byte_length": 2050
    }
  }
}
```
