# 离线 fake 候选验证

状态：failed

请求：5c4a4710-301b-4746-8479-393d7e782e0a
来源版本：c0d42ae8-4937-430b-9f0e-0c4b66a6f69e
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2084 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_BINDING: EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "5c4a4710-301b-4746-8479-393d7e782e0a",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "c4c189a5-01c7-4112-af79-4ecd101d01de",
    "source_id": "6544d367-1045-4b42-9500-f550dfea91ca",
    "version_id": "c0d42ae8-4937-430b-9f0e-0c4b66a6f69e",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2084,
    "output_bytes": 2084,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_BINDING",
      "message": "EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "cdaee06d7829795da8401d9f5248e715be0e0de331040334b45463464292ac9b",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "4d2d4dbc482429fee52cd57968c6a9f4555c6e49e6818c37aa12eb70c37aca34",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "473a0e81139721c863e754392bcd4c68b83d4f8f81dd41b897086c31269df798",
      "byte_length": 2084
    }
  }
}
```
