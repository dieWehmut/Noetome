# 离线 fake 候选验证

状态：failed

请求：e5ce9cdf-1927-4dd3-8c03-895fbfed32a1
来源版本：8624b58d-b32d-4ba4-8458-67ad20963b5f
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_BINDING: EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "e5ce9cdf-1927-4dd3-8c03-895fbfed32a1",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "49e8d570-833f-4be0-9cf4-521715f1f305",
    "source_id": "f8d30e5c-ca8b-4af3-9d89-6e39070c1200",
    "version_id": "8624b58d-b32d-4ba4-8458-67ad20963b5f",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "0d5e5098-c7c5-469b-a273-bc00d45f7bfb",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_BINDING",
      "message": "EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "67a472b779fb4869bf3d433e208c16575f9872c8dd73a5e6de85f4b7cad6f118",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "e210454430dd6aea6b9fc786b4f051a057d81001e18148169e860123adf49527",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "e0650f7d2b1163038af17ae67b28b959b79d20bb775012b755d0bf4453b70dce",
      "byte_length": 1935
    }
  }
}
```
