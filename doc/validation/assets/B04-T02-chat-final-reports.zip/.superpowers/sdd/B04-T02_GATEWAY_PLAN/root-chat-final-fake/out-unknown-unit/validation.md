# 离线 fake 候选验证

状态：failed

请求：f98e6358-6fd4-449f-b812-885661de6a98
来源版本：c0d42ae8-4937-430b-9f0e-0c4b66a6f69e
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2051 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_EVIDENCE_UNIT: EXTRACT_EVIDENCE_UNIT：证据没有引用请求内的真实来源单位。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "f98e6358-6fd4-449f-b812-885661de6a98",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "c4c189a5-01c7-4112-af79-4ecd101d01de",
    "source_id": "6544d367-1045-4b42-9500-f550dfea91ca",
    "version_id": "c0d42ae8-4937-430b-9f0e-0c4b66a6f69e",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2051,
    "output_bytes": 2051,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_EVIDENCE_UNIT",
      "message": "EXTRACT_EVIDENCE_UNIT：证据没有引用请求内的真实来源单位。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "ae2cf654e9827eaad436237f843b19f5722f09b0aab3d031826a779f806739a3",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "122f12fc0b1c2f5d6d3ee29cf05b1fa5f6d11513472f1bbd8d3c72fa48a0b15c",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "4b9592803f9e9a09de4377c052a260d44d2030a53dec1444384b180a63e7e165",
      "byte_length": 2051
    }
  }
}
```
