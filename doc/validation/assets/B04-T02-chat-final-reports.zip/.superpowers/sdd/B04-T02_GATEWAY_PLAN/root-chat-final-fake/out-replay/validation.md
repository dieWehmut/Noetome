# 离线 fake 候选验证

状态：candidates_validated

请求：73023303-d391-4ec9-879c-bf2fd198e8e6
来源版本：c0d42ae8-4937-430b-9f0e-0c4b66a6f69e
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "73023303-d391-4ec9-879c-bf2fd198e8e6",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "c4c189a5-01c7-4112-af79-4ecd101d01de",
    "source_id": "6544d367-1045-4b42-9500-f550dfea91ca",
    "version_id": "c0d42ae8-4937-430b-9f0e-0c4b66a6f69e",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "a9d9b4fd428397e37c7a030cd254ca83d53ddb5c5231c296162557deac6798c5",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "3ab4d372ad3cd698964ab5a9096bb3da43598305a66cb0fc0d3e0d6f394e479f",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "ddae39c9fcaa6fb0b36cc69651b9717c567f82481c95fb332832b5671e6be806",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "3edf38e2aeb8ce5350d3f6a58be759c258c11d1dad11016af3d9fd10ca074c51",
      "byte_length": 2050
    }
  }
}
```
