# 离线 fake 候选验证

状态：candidates_validated

请求：2ca6a5ba-8519-40f5-8643-33865fd67203
来源版本：8624b58d-b32d-4ba4-8458-67ad20963b5f
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "2ca6a5ba-8519-40f5-8643-33865fd67203",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "49e8d570-833f-4be0-9cf4-521715f1f305",
    "source_id": "f8d30e5c-ca8b-4af3-9d89-6e39070c1200",
    "version_id": "8624b58d-b32d-4ba4-8458-67ad20963b5f",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "0d5e5098-c7c5-469b-a273-bc00d45f7bfb",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "5cc3770760fdef48547423a3c2eb712286524b39e569989e072965889875f281",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "93bcab7e26b3889aa2636a1db6228fad1e35d37d1627a230660871d61a25f22f",
      "byte_length": 2061
    },
    "request.json": {
      "sha256": "417d688d8dbfe0ac66fb24244f1a152d4b7bd636a942058c6b0b96c476ebac04",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "905f5b817b79ddeabfccd9749b160f795bde85fd048e083e6f86675e4aa8bd1f",
      "byte_length": 1935
    }
  }
}
```
