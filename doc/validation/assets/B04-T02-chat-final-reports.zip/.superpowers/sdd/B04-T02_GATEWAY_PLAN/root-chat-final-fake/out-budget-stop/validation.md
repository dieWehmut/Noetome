# 离线 fake 候选验证

状态：failed

请求：0a251571-c04c-4663-b603-0ae95a520cf2
来源版本：c0d42ae8-4937-430b-9f0e-0c4b66a6f69e
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 unknown 计量单位；预留 8332 计量单位；实际 provider 调用 0 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_BUDGET: EXTRACT_BUDGET：单请求次数或fake token预留超过预算，未调用provider。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "0a251571-c04c-4663-b603-0ae95a520cf2",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "c4c189a5-01c7-4112-af79-4ecd101d01de",
    "source_id": "6544d367-1045-4b42-9500-f550dfea91ca",
    "version_id": "c0d42ae8-4937-430b-9f0e-0c4b66a6f69e",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": null,
    "output_bytes": null,
    "reserved_tokens": 8332,
    "provider_calls": 0,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_BUDGET",
      "message": "EXTRACT_BUDGET：单请求次数或fake token预留超过预算，未调用provider。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "d104d3e947b91f5d1b85401efcdecc64c713c909c0d8adefadb3e4377eaf71cd",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "62d65d41bfaf7f2d5772f9276bbe57bb2dd40b47fc86da98c57fb7308659990c",
      "byte_length": 1360
    }
  }
}
```
