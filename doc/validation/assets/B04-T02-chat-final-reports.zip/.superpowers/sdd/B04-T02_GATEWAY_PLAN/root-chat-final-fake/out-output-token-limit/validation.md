# 离线 fake 候选验证

状态：failed

请求：858ef935-3abf-430c-91de-d073a701da0c
来源版本：c0d42ae8-4937-430b-9f0e-0c4b66a6f69e
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 141 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_OUTPUT_TOKENS: EXTRACT_OUTPUT_TOKENS：完整fake响应超过fake UTF-8字节token上限。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "858ef935-3abf-430c-91de-d073a701da0c",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "c4c189a5-01c7-4112-af79-4ecd101d01de",
    "source_id": "6544d367-1045-4b42-9500-f550dfea91ca",
    "version_id": "c0d42ae8-4937-430b-9f0e-0c4b66a6f69e",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 141,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_OUTPUT_TOKENS",
      "message": "EXTRACT_OUTPUT_TOKENS：完整fake响应超过fake UTF-8字节token上限。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "1725f8834036c2282bc3c629194de83ab16691e0e6278b2320bcc9ddac8c9c98",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "8c99d46939aaaf8c8c98ffe25e7f8bf6f720d5e5ebd6f4f0359def3212ca2872",
      "byte_length": 1357
    },
    "response.bin": {
      "sha256": "372afe9d9bb0061c1b18ee1d8bba6d09d06527e34111dcb096aa5d5c98aa2368",
      "byte_length": 2050
    }
  }
}
```
