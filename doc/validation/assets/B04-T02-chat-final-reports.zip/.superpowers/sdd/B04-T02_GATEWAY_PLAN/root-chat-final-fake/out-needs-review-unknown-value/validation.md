# 离线 fake 候选验证

状态：candidates_validated

请求：8e3916f0-3eb1-4603-9350-6887e84bba62
来源版本：9cd51e50-8bda-4122-80ec-35433d166bb7
来源状态：needs_review
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 56 字节；输出 1898 计量单位；预留 8248 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "8e3916f0-3eb1-4603-9350-6887e84bba62",
  "binding": {
    "project_id": "4d5c1b52-e203-45d8-b9b0-679ff9d4ee36",
    "import_id": "e5e5c7b5-65cf-436d-8b5e-d6abbad75d1a",
    "source_id": "8c30553e-247a-4d34-a3fa-b7703960eff2",
    "version_id": "9cd51e50-8bda-4122-80ec-35433d166bb7",
    "content_sha256": "0f930cfb984cb91754ebeb8dc245e57ed490cf7fb3d487d8cf384011cd2f3c92",
    "normalized_sha256": "036f70c8257857485962d54674813b42fe4fe1d05adbf57e0bc7ac4aa9023ec5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "needs_review"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 56,
    "input_bytes": 56,
    "output_tokens": 1898,
    "output_bytes": 1898,
    "reserved_tokens": 8248,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "a65b170f6e97aea2c0742990110b4e46b5db21f112b791c6096a1f9970338e12",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "70374c838d5ca0b08139b6e3339fa4add0e1b934fa37bb81e93abf8d7ca58376",
      "byte_length": 2024
    },
    "request.json": {
      "sha256": "aef5415f627e331525e18ba4e38f27118c83929387cabf88d87794fb15071f1e",
      "byte_length": 1282
    },
    "response.bin": {
      "sha256": "c7d993e20a026f7a6a2580a6e040697deccf66281051f201a8f2d1098857a7cf",
      "byte_length": 1898
    }
  }
}
```
