# Noetome fixture 验证报告

- schema_version: 1
- producer: fixture
- case_id: C7k
- run_id: 76f6351e-f645-4a08-bb47-09430fcf9b5d
- release_id: 354c5557-19ce-4013-bd71-af695797ba23
- started_at: 2026-11-06T17:40:23.2477422Z
- finished_at: 2026-11-06T17:40:24.3704361Z
- result: validated

## 四维状态

| dimension | state | reason |
| --- | --- | --- |
| knowledge\_compilation | complete | 自造fixture的必要原子、条件和证据映射已在实际文件中验证。 |
| optional\_research | not\_applicable | 本轮未启用研究、模型或网络抽取。 |
| quality\_validation | complete | 仅完成本轮fixture契约、实际内容、映射、清单与本地引用的确定性检查；科学质量未运行。 |
| source\_coverage | complete | 自造fixture的完整来源及覆盖处置已双向对账。 |

## 计数

| scope | key | value |
| --- | --- | --- |
| overall | atoms | 4 |
| overall | duplicates | 1 |
| overall | excluded | 7 |
| overall | included | 4 |
| overall | issues | 0 |
| overall | links | 2 |
| overall | mappings | 9 |
| overall | nodes | 4 |
| overall | notes | 2 |
| overall | rendered\_files | 2 |
| overall | required\_atoms | 4 |
| overall | sources | 2 |
| overall | spans | 12 |
| knowledge\_compilation | files | 2 |
| knowledge\_compilation | required\_atoms | 4 |
| quality\_validation | issues | 0 |
| source\_coverage | duplicates | 1 |
| source\_coverage | excluded | 7 |
| source\_coverage | included | 4 |
| source\_coverage | spans | 12 |

## 检查

| check | status | issue_count |
| --- | --- | --- |
| coverage | passed | 0 |
| expected | passed | 0 |
| knowledge | passed | 0 |
| note\_plan | passed | 0 |
| output\_content | passed | 0 |
| output\_link | passed | 0 |
| output\_manifest | passed | 0 |
| output\_mapping | passed | 0 |
| rendering | passed | 0 |
| scientific\_quality | not\_run | 0 |
| sources | passed | 0 |
| staging\_output | passed | 0 |
| vault\_output | passed | 0 |

## 文件

| relative_path | note_id | plan_revision | byte_length | content_sha256 |
| --- | --- | --- | --- | --- |
| 笔记/甲容器.md | N4u | 1 | 462 | 33eedf491e2ab58e5ee7d2da80c701e91bb0c77700b0212672a1ddbed2bfa376 |
| 笔记/乙容器.md | N8v | 1 | 244 | 349f06a40ea199f4d2fb2f6ebcecf61aa652a571ea18e1e81f665a11cf505b88 |

## 内容映射

| relative_path | section_id | node_id | scope | atom_ids | start_byte | end_byte |
| --- | --- | --- | --- | --- | --- | --- |
| 笔记/甲容器.md | H2j | Q2z | paragraph::: | A3d | 33 | 90 |
| 笔记/甲容器.md | H2j | T5x | table\_cell::W3g:D2c |  | 202 | 214 |
| 笔记/甲容器.md | H2j | T5x | table\_cell::W3g:D4c | A5p | 217 | 320 |
| 笔记/甲容器.md | H2j | T5x | table\_cell::W3g:D6c | A9w | 323 | 423 |
| 笔记/甲容器.md | H2j | T5x | table\_cell::W7g:D2c |  | 428 | 434 |
| 笔记/甲容器.md | H2j | T5x | table\_cell::W7g:D4c |  | 437 | 446 |
| 笔记/甲容器.md | H2j | T5x | table\_cell::W7g:D6c |  | 449 | 458 |
| 笔记/乙容器.md | H6n | Q6z | paragraph::: | A7e | 33 | 90 |
| 笔记/乙容器.md | H6n | L9x | list\_item:I4b:: | A9w | 142 | 242 |

## 语义引用

| relative_path | section_id | node_id | scope | target_concept_id | target_path | target_heading | display_text | start_byte | end_byte |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 笔记/甲容器.md | H2j | Q2z | paragraph::: | C6h | 笔记/乙容器.md | 定义与条件 | 乙容器 | 91 | 137 |
| 笔记/乙容器.md | H6n | Q6z | paragraph::: | C2f | 笔记/甲容器.md | 定义与比较 | 甲容器 | 91 | 137 |

## 问题

| rule_id | object_refs | message |
| --- | --- | --- |

## 输入与规则

| scope | key | value |
| --- | --- | --- |
| input\_hashes | case\_sha256 | a4790b5bb67ec8b4fea71ced53cd44a853a226ffecf74d3599daebb08bbc4437 |
| input\_hashes | expected\_sha256 | 0477e6dc10ee3e5be654a3bbce4c22cb214972bf658a58e9f8a0cf16db39eadd |
| input\_hashes | ir\_sha256 | 3dd1e99ef340d1f603c9514be9e5a3b2b2b2225135f0397d20bcffbe7577fc50 |
| input\_hashes | plan\_sha256 | 2944b5d0ec3868947c0880650eaaa3c444c6b030f3b5dc77f876e91f4394e1fb |
| versions | coverage\_policy:P1a | fixture-policy-v1 |
| versions | coverage\_policy:P1b | fixture-policy-v1 |
| versions | coverage\_policy:P2a | fixture-policy-v1 |
| versions | coverage\_policy:P2b | fixture-policy-v1 |
| versions | coverage\_policy:P3a | fixture-policy-v1 |
| versions | coverage\_policy:P3b | fixture-policy-v1 |
| versions | coverage\_policy:P4a | fixture-policy-v1 |
| versions | coverage\_policy:P4b | fixture-policy-v1 |
| versions | coverage\_policy:P5a | fixture-policy-v1 |
| versions | coverage\_policy:P5b | fixture-policy-v1 |
| versions | coverage\_policy:P6b | fixture-policy-v1 |
| versions | coverage\_policy:P7b | fixture-policy-v1 |
| versions | ir\_schema | 1 |
| versions | normalization:S4m | utf8-newlines-v1 |
| versions | normalization:S9q | utf8-newlines-v1 |
| versions | parser:S4m | blocks-v1 |
| versions | parser:S9q | blocks-v1 |
| versions | plan\_schema | 1 |
| versions | renderer | fixture-markdown-v1 |
| versions | report | fixture-compile-report-v1 |
| versions | validator | fixture-contracts-v1 |

## 发布依据

验证事实通过不等于发布已经提交。只有以下数据库中与本轮文件和双报告指纹一致的已提交记录才是发布依据。

- database: state/compile.sqlite
- commit_table: publication\_commits
- release_id: 354c5557-19ce-4013-bd71-af695797ba23
