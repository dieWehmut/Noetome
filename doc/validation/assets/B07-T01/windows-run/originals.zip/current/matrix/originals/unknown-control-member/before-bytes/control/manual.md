foreign control original
