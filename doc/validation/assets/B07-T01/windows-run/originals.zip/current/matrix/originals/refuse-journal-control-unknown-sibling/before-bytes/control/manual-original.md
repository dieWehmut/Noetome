unknown original must survive
