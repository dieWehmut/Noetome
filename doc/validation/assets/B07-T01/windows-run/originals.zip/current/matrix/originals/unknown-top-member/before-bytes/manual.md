foreign user note
