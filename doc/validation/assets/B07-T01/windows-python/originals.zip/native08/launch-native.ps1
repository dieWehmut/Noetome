$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-08-20261107\python-only-runner.py' --base 'D:\Noetome\.artifacts\b07-t01-windows-final-08-20261107' --snapshot-sha256 '5ebf97755b2a9b3e0c10fd37173782aaa1d3c752a083f184a3f10515c982f96e'
exit $LASTEXITCODE
