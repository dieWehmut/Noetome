$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-07-20261107\python-only-runner.py' --base 'D:\Noetome\.artifacts\b07-t01-windows-final-07-20261107' --snapshot-sha256 'b37d9f612f687a19cbc71732d99b8f5a26bfec7cfa690343d8fac0405c34a17d'
exit $LASTEXITCODE
