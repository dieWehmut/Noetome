"""Recheck all Windows Python inputs with an exactly scoped prior native build."""
import argparse, hashlib, importlib.metadata, importlib.util, json, os
from pathlib import Path
import re, shutil, sys, traceback

def module(path):
    spec=importlib.util.spec_from_file_location('frozen_native_runner',path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

def execute(args):
    base=Path(args.base)
    core=module(base/'runner.py')
    run=core.NativeRun(args)
    prior=Path(r'D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107')
    old=json.loads((prior/'snapshot.json').read_bytes())
    final=json.loads((prior/'native-final.json').read_bytes())
    old_subset=json.loads((prior/'rust-dependency-subset.json').read_bytes())['files']
    subset=json.loads((base/'rust-dependency-subset.json').read_bytes())['files']
    core.require(set(old['files'])==set(run.expected),'source input set changed beyond the selected Python repair')
    delta={name:{'before':old['files'][name],'after':run.expected[name]} for name in run.expected if old['files'][name]!=run.expected[name]}
    core.require(set(delta)=={'scripts/verify_run_checkpoint.py','tests/test_verify_run_checkpoint.py'},'unexpected old/new whole-source delta')
    core.require(subset==old_subset,'Rust/test dependency subset changed; prior Rust cannot be reused')
    compiler_names=sorted(name for name in run.expected if name in {'Cargo.toml','Cargo.lock','crates/noetome-cli/Cargo.toml','crates/noetome-cli/build.rs'} or name.startswith('crates/noetome-cli/src/') and name.endswith('.rs'))
    compiler_inputs={name:run.expected[name] for name in compiler_names}
    core.require(all(old['files'][name]==item for name,item in compiler_inputs.items()),'actual build.rs compiler input changed')
    core.require(final['status']=='passed' and final['rust_totals']=={'passed':756,'failed':0,'ignored':0},'prior actual full Rust is not a passed source-bound run')
    proof={'producer':'exact_native_rust_reuse_scope','previous_snapshot':core.pin(prior/'snapshot.json'),'previous_native_final':core.pin(prior/'native-final.json'),'current_snapshot':core.pin(base/'snapshot.json'),'whole_source_count':len(run.expected),'unchanged_count':len(run.expected)-len(delta),'changed_files':delta,'conservative_rust_dependencies_equal':True,'conservative_rust_dependency_count':len(subset),'conservative_rust_dependency_files':subset,'actual_compiler_input_files_equal':True,'actual_compiler_input_count':len(compiler_inputs),'actual_compiler_input_files':compiler_inputs,'scope':'prior native06 actual fmt/check/build/test756 applies only to unchanged compiler and conservative Rust/test dependencies; this run does not run Cargo or infer its Python results'}
    core.save(base/'rust-reuse-scope.json',proof)
    tools=json.loads((prior/'native-runtime.json').read_bytes())
    for item in tools['compiler_tools'].values():
        core.require(core.pin(item['path'])=={k:item[k] for k in ('sha256','byte_length')},'prior native compiler tool bytes changed')
    core.require(core.pin(sys.executable)==tools['python_pin'],'selected native Python executable changed')
    core.require(core.pin(core.FAKE_PYTHON)=={k:tools['fake_python'][k] for k in ('sha256','byte_length')},'selected fake Python bytes changed')
    packages=json.loads((run.repo/'sidecars/pdf_parser/runtime-lock.json').read_bytes())['packages']
    core.require({name:importlib.metadata.version(name) for name in packages}==packages,'actual PDF Python lock changed')
    core.save(base/'native-runtime.json',{'platform':sys.platform,'python':sys.version,'python_executable':sys.executable,'python_pin':core.pin(sys.executable),'pdf_packages':packages,'fake_python':tools['fake_python'],'compiler_tools':tools['compiler_tools'],'reused_native_tools_from':core.pin(prior/'native-runtime.json'),'removed_sensitive_environment_names':run.removed,'scope':'actual selected Windows Python and unchanged original native tool bytes; no Cargo invoked'})
    for name,item in final['selected_executables'].items():
        original=core.ordinary(prior/'selected'/name)
        core.require(core.pin(original)==item and original.stat().st_nlink==1,'fixed prior executable changed or linked')
        destination=base/'selected'/name;shutil.copyfile(original,destination)
        core.require(core.pin(destination)==item and destination.stat().st_nlink==1,'fixed executable copy changed or linked')
        run.selected[name]=item
    cli=base/'selected/noetome.exe';driver=base/'selected/noetome-cli-testdriver.exe'
    run.env['NOETOME_TEST_BINARY']=str(cli)
    fallback=run.repo/'target/debug/noetome.exe';fallback.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(cli,fallback)
    core.require(core.pin(fallback)==run.selected[cli.name],'source-bound fallback copy differs')
    run.command('fake-python-version',[core.FAKE_PYTHON,'--version'])
    pwsh=core.ordinary(Path(r'C:\Program Files\PowerShell\7\pwsh.exe'))
    core.require(pwsh.is_file(),'previously selected PowerShell 7 executable is unavailable')
    pwsh_before=core.pin(pwsh)
    run.env['PATH']=str(pwsh.parent)+';'+run.env['PATH']
    discovered_pwsh=shutil.which('pwsh',path=run.env['PATH'])
    core.require(discovered_pwsh is not None and os.path.samefile(core.ordinary(discovered_pwsh),pwsh),'task PATH does not select the pinned PowerShell 7')
    pwsh_version,_=run.command('pwsh-version',[pwsh,'-NoProfile','-NonInteractive','-Command','$PSVersionTable.PSVersion.ToString()'])
    powershell=core.ordinary(Path(core.POWERSHELL));powershell_before=core.pin(powershell)
    powershell_version,_=run.command('powershell-version',[powershell,'-NoProfile','-NonInteractive','-Command','$PSVersionTable.PSVersion.ToString()'])
    core.save(base/'credential-engine-runtime.json',{'producer':'actual_native_credential_engine_selection','pwsh':{'path':str(pwsh),**pwsh_before,'actual_version_stdout':pwsh_version.decode('utf8').strip()},'powershell':{'path':str(powershell),**powershell_before,'actual_version_stdout':powershell_version.decode('utf8').strip()},'task_path_prefix':str(pwsh.parent),'scope':'explicitly selected two existing PowerShell engines; synthetic credentials only, no global environment discovery or real credential reads'})
    fixture=run.repo/'fixtures/run-checkpoint-v1/fixture'
    raw,_=run.command('actual-cli-compiler-probe',[cli,'run','start',fixture,base/'cli-runtime-probe','--paused'])
    envelope=json.loads(raw);actual_fp=envelope['compiler_fingerprint']
    core.require(actual_fp==final['actual_cli_and_driver_compiler_fingerprint'],'actual reused CLI fingerprint differs')
    raw,_=run.command('actual-driver-compiler-probe',[driver,'--exact','fixture_run::tests::checkpoint_child','--nocapture'],extra={'NOETOME_RUN_TEST_CASE':str(fixture),'NOETOME_RUN_TEST_ROOT':str(base/'driver-runtime-probe'),'NOETOME_RUN_TEST_OPERATION':'start','NOETOME_RUN_TEST_EVENT':'created','NOETOME_RUN_TEST_UNIT':'','NOETOME_RUN_TEST_OCCURRENCE':'1'},input_bytes=b'release\n')
    hands=[];decoder=json.JSONDecoder()
    for line in raw.decode('utf8').splitlines():
        start=line.find('{"')
        if start<0:continue
        value,_=decoder.raw_decode(line[start:])
        if isinstance(value,dict) and value.get('producer')=='run_checkpoint_test_handshake':hands.append(value)
    core.require(len(hands)==1 and hands[0]['compiler_fingerprint']==actual_fp and hands[0]['pid']==run.commands[-1]['pid'],'actual reused driver fingerprint/PID differs')
    pair={'status':'reused_actual_runtime_identity_bound','source_snapshot':core.pin(base/'snapshot.json'),'actual_native_build_receipt':core.pin(prior/'selected-build-receipt.json'),'actual_native_final':core.pin(prior/'native-final.json'),'rust_reuse_scope':core.pin(base/'rust-reuse-scope.json'),'selected_executables':run.selected,'actual_compiler_fingerprint':actual_fp,'cli_probe':envelope,'driver_handshake':hands[0],'scope':'native06 PE/driver actual byte copies; current full-Python is pending and Cargo was not run here'}
    core.save(base/'selected-reuse-receipt.json',pair)
    out,err=run.command('full-python',[core.PDF_PYTHON,'-X','utf8','-m','unittest','discover','-s','tests','-p','test_*.py','-v'])
    count=re.search(rb'Ran (\d+) tests in ([\d.]+)s',err)
    core.require(count and re.search(rb'\nOK(?: \(|\r?\n|$)',err),'actual complete Python summary missing')
    modern_credentials=[line.decode('utf8') for line in err.splitlines() if b'TestCredentials_pwsh.' in line or b'ScanCredentials_pwsh.' in line]
    core.require(len(modern_credentials)==39 and all(line.endswith(' ... ok') for line in modern_credentials),'39 existing PowerShell 7 credential regressions were not all actually discovered and passed')
    core.require(core.pin(pwsh)==pwsh_before and core.pin(powershell)==powershell_before,'selected PowerShell engines changed during actual regressions')
    run.guards()
    for item in tools['compiler_tools'].values():core.require(core.pin(item['path'])=={k:item[k] for k in ('sha256','byte_length')},'native compiler bytes changed during Python checks')
    core.require(core.pin(sys.executable)==tools['python_pin'] and core.pin(core.FAKE_PYTHON)=={k:tools['fake_python'][k] for k in ('sha256','byte_length')},'selected Python tool bytes changed')
    core.require(all(core.pin(prior/'selected'/name)==item for name,item in final['selected_executables'].items()),'original prior PE/driver changed')
    core.save(base/'source-after.json',core.files(run.repo,run.expected))
    skips=[line.decode('utf8') for line in err.splitlines() if b' ... skipped ' in line]
    result={'status':'passed','producer':'native_windows_full_python_with_scoped_prior_rust','platform':sys.platform,'source_count':len(run.expected),'source_snapshot':core.pin(base/'snapshot.json'),'source_archive':core.pin(base/'source-originals.zip'),'source_before_after_equal':True,'declared_build_assets_equal':True,'external_sentinel_before_after_equal':True,'python_tests_run':int(count[1]),'python_skips':skips,'python_passed':int(count[1])-len(skips),'python_failed':0,'python_errors':0,'actual_cli_and_driver_compiler_fingerprint':actual_fp,'selected_executables':run.selected,'actual_native_build_receipt':core.pin(prior/'selected-build-receipt.json'),'rust_reuse_scope':core.pin(base/'rust-reuse-scope.json'),'native_runtime':core.pin(base/'native-runtime.json'),'credential_engine_runtime':core.pin(base/'credential-engine-runtime.json'),'actual_modern_powershell_credentials':modern_credentials,'credential_engines_before_after_equal':True,'commands':run.commands,'real_api_calls':0,'real_model_calls':0,'paid_calls':0,'limits':['No Cargo or complete Rust rerun in this run; earlier 756 evidence applies through exact scoped source proof','Independent native checkpoint matrix is separate','No production/24h/scientific acceptance inferred']}
    core.save(base/'native-final.json',result)
    print(json.dumps({'status':'passed','python_tests_run':result['python_tests_run'],'python_passed':result['python_passed'],'python_skip_count':len(skips),'reused_rust_tests':756}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,required=True);parser.add_argument('--snapshot-sha256',required=True);args=parser.parse_args()
    try:execute(args)
    except BaseException as error:
        (args.base/'native-failure.json').write_text(json.dumps({'status':'failed','producer':'native_windows_python_only_runner','error_type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()},ensure_ascii=False,indent=2)+'\n');raise
