from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,re

WORK=Path('/home/lyinn/project/Noetome');ROOT=Path(__file__).resolve().parent;REPO=ROOT/'repo'
PYTHON=Path('/tmp/noetome-b05-t03-python/bin/python')
CLI=WORK/'.artifacts/b07-t01-linux-build-05-20261107/noetome'
CLI_SHA='e7194fa4f3bd530996c657f24f5870773a08ab25a1873d5b1fa4f4b5f55c8512'
def pin(raw):return {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
names=set(json.loads((WORK/'.artifacts/b06v-t03-linux-final-04-20261106/source-before.json').read_text()))
names={n for n in names if not n.startswith('target/')}
for folder in ['scripts','tests','fixtures','crates/noetome-cli/src','crates/noetome-cli/tests','dev-log','doc/technical','doc/execution','doc/standards','doc/templates']:
    names.update(p.relative_to(WORK).as_posix() for p in (WORK/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and not p.name.startswith('.'))
names.update(['README.md','AGENTS.md','.gitattributes','.gitignore','doc/README.md','Cargo.toml','Cargo.lock','crates/noetome-cli/Cargo.toml','crates/noetome-cli/build.rs'])
def pins(base,selected):return {n:pin((base/n).read_bytes()) for n in sorted(selected)}
before=pins(WORK,names);save(ROOT/'worktree-source-before.json',before)
for n in sorted(names):
    path=WORK/n;assert path.is_file() and not path.is_symlink(),n
    raw=path.read_bytes();assert pin(raw)==before[n],n
    target=REPO/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
raw=CLI.read_bytes();assert pin(raw)['sha256']==CLI_SHA
for n in ['target/debug/noetome','target/debug/noetome.exe']:
    target=REPO/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);target.chmod(0o555)
    names.add(n)
(ROOT/'temp').mkdir();(REPO/'target/compiler-temp').mkdir()
snapshot=pins(REPO,names);save(ROOT/'source-before.json',snapshot)
env={n:os.environ[n] for n in ['PATH','USER','LOGNAME','LANG','LC_ALL','TZ'] if n in os.environ}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TMPDIR=str(ROOT/'temp'),NOETOME_TEST_BINARY=str(REPO/'target/debug/noetome'))
argv=[str(PYTHON),'-m','unittest','discover','-s','tests','-p','test_*.py','-v'];started=time.time()
with (ROOT/'stdout.bin').open('wb') as out,(ROOT/'stderr.bin').open('wb') as err:
    p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=out,stderr=err)
    save(ROOT/'launch.json',{'argv':argv,'cwd':str(REPO),'pid':p.pid,'environment_names':sorted(env),'selected_binary':str(CLI),'binary':pin(raw),'started_unix':started,'real_model_calls':0,'paid_calls':0})
    code=p.wait()
after=pins(REPO,names);save(ROOT/'source-after.json',after)
related=names-{'target/debug/noetome','target/debug/noetome.exe'}
work_after=pins(WORK,related);save(ROOT/'worktree-source-after.json',work_after)
stderr=(ROOT/'stderr.bin').read_text(errors='replace');matched=re.search(r'^Ran (\d+) tests? in ([0-9.]+)s$',stderr,re.M)
result={'status':'passed' if code==0 and after==snapshot and work_after==before else 'failed','argv':argv,'exit_code':code,'elapsed_seconds':time.time()-started,'tests_run':int(matched[1]) if matched else None,'result_line':next((l for l in reversed(stderr.splitlines()) if l.startswith(('OK','FAILED'))),None),'skipped_tests':re.findall(r'^(.+?) \.\.\. skipped (.+)$',stderr,re.M),'stdout':pin((ROOT/'stdout.bin').read_bytes()),'stderr':pin((ROOT/'stderr.bin').read_bytes()),'source_files':len(names),'snapshot_source_unchanged':snapshot==after,'worktree_source_unchanged':before==work_after,'ordinary_binary_aliases':True,'source_build_receipt':str(CLI.parent/'actual.json'),'real_model_calls':0,'paid_calls':0,'scientific_quality':'not_run','full_linux_rust':'not_run'}
save(ROOT/'actual.json',result);print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if result['status']=='passed' else 1)
