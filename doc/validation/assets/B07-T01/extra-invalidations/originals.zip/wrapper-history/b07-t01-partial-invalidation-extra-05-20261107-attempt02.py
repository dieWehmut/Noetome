from pathlib import Path
import json,hashlib,sqlite3,shutil,os,importlib.util,sys,traceback,time
sys.dont_write_bytecode=True
ROOT=Path('/home/lyinn/project/Noetome');sys.path.insert(0,str(ROOT/'scripts'));PATH=ROOT/'scripts/verify_run_checkpoint.py';EXPECTED='87cb1580d26ca216061a9ef129ff92904958c099866d7811f9bcb79139b936da'
assert hashlib.sha256(PATH.read_bytes()).hexdigest()==EXPECTED
spec=importlib.util.spec_from_file_location('frozen_final_checker87cb',PATH);v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
base=ROOT/'.artifacts/b07-t01-partial-invalidation-extra-05-20261107';cli=ROOT/'.artifacts/b07-t01-linux-build-05-20261107/noetome';d05=ROOT/'.artifacts/b07-t01-linux-build-05-20261107/run-test-driver';d04=ROOT/'.artifacts/b07-t01-linux-build-04-20261107/run-test-driver';pack=ROOT/'fixtures/run-checkpoint-v1';rec=v.Recorder(base,cli,pack/'fixture');v.frozen_pack_check(pack,'240cf6bf13c082c24c93d92ab47a5e76cadb799beb4fe162d2665e9fbc12ccd1')
rows=[];held=None

def sql_rows(root):
 with sqlite3.connect(v.sqlite_file_uri(root/'control/run.sqlite'),uri=True) as c:
  return {'metadata':c.execute('SELECT singleton,schema_version,metadata_json FROM metadata').fetchall(),'checkpoints':c.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM checkpoints ORDER BY sequence').fetchall(),'controls':c.execute('SELECT sequence,run_id,action,requested_at FROM controls ORDER BY sequence').fetchall()}
def publication_count(root):
 with sqlite3.connect(v.sqlite_file_uri(root/'output/state/compile.sqlite'),uri=True) as c:return c.execute('SELECT count(*) FROM publication_commits').fetchone()[0]
def file_pin(path):
 s=path.stat();return {'identity':v.actual_identity(path),'sha256':v.sha(path.read_bytes()),'byte_length':s.st_size,'modified':str(s.st_mtime_ns),'mode':s.st_mode & 0o777}
try:
 for name,driver,kind in [('source-bytes-after-four-confirmed',d05,'bytes'),('same-source-bytes-new-file-ID-after-four-confirmed',d05,'identity'),('actual-Core04-to-Core05-after-four-confirmed',d04,'compiler')]:
  case=rec.root/(name+'-input');shutil.copytree(rec.fixture,case);root=rec.root/name
  held=v.HeldDriver(rec,driver,'fixture_run::tests::checkpoint_child',root,'unit_prepared','reports',fixture=case)
  old=v.read_journal(root,fixture=case);v.require(sum(u['state']=='confirmed' for u in old['state']['units'])==4,'did not reach four real confirmations');v.require(old['state']['units'][4]['state']=='running' and old['state']['pending_intent'] is not None,'reports not actually prepared');v.verify_partial_author(pack,root,old)
  v.require(publication_count(root)==0,'premature publication before kill');termination=held.force_stop();held=None
  v.require(termination['termination_method']=='SIGKILL' and termination['exit_code']==-9,'did not actually kill and wait owned PID');before=v.read_journal(root,fixture=case);evidence,run_before=rec.witness(name,root);before_raw=sql_rows(root);output_before=v.inventory(root/'output');input_before=v.inventory(case);v.save_json(evidence/'selected-input-before.json',input_before);shutil.copytree(case,evidence/'selected-input-before-bytes')
  source=case/'sources/材料甲.md';old_pin=file_pin(source);old_bytes=source.read_bytes();(evidence/'source-old.bin').write_bytes(old_bytes);v.save_json(evidence/'source-old.json',old_pin)
  if kind=='bytes':
   source.write_bytes(old_bytes+'\n本轮选定测试来源新增有效UTF-8字节，用于检查已确认结果失效。\n'.encode());v.require(source.read_bytes().decode('utf8').endswith('\n'),'changed source not loadable UTF8')
  elif kind=='identity':
   replacement=source.with_name(source.name+'.owned-test-replacement');replacement.write_bytes(old_bytes);replacement.chmod(old_pin['mode']);os.utime(replacement,ns=(source.stat().st_atime_ns,int(old_pin['modified'])));os.replace(replacement,source)
  new_pin=file_pin(source);(evidence/'source-new.bin').write_bytes(source.read_bytes());v.save_json(evidence/'source-new.json',new_pin)
  if kind=='bytes':v.require(new_pin['sha256']!=old_pin['sha256'] and new_pin['identity']==old_pin['identity'],'byte mutation does not isolate changed bytes on original identity')
  if kind=='identity':v.require(new_pin['sha256']==old_pin['sha256'] and new_pin['identity']!=old_pin['identity'] and new_pin['modified']==old_pin['modified'],'same-byte replacement did not isolate actual new FileID')
  input_after_mutation=v.inventory(case);v.save_json(evidence/'selected-input-after-mutation.json',input_after_mutation);shutil.copytree(case,evidence/'selected-input-after-mutation-bytes')
  if kind=='bytes':
   loaded,_=rec.command(('case','verify',case),3,label='actual changed UTF8 source load and contract verification');v.require(isinstance(loaded,dict) and loaded.get('producer')=='fixture','changed source failed parsing instead of loading to fixture validation report');v.save_json(evidence/'loadable-changed-source-report.json',loaded)
  _,receipt=rec.command(('run','resume',case,root),3,label='ordinary Core05 resume after actual4-confirmed input/compiler change')
  after=v.read_journal(root,expected_run_id=before['owner']['run_id']);after_raw=sql_rows(root);v.require(after['state']['status']=='invalidated','no actual four-confirmation invalidation');v.require(after['state']['units']==before['state']['units'],'retained confirmation/attempt/IDs changed');v.require(after['owner']==before['owner'] and after['metadata']==before['metadata'],'owner or original metadata rewritten');v.require(after_raw['metadata']==before_raw['metadata'] and after_raw['controls']==before_raw['controls'],'original raw metadata or controls changed');v.require(after_raw['checkpoints'][:-1]==before_raw['checkpoints'] and len(after_raw['checkpoints'])==len(before_raw['checkpoints'])+1,'original raw checkpoint prefix changed or duplicate invalidation');v.require(after['checkpoints'][-1]['event']=='invalidated','actual append not invalidated');v.require(v.inventory(root/'output')==output_before and publication_count(root)==0,'old output changed or published');v.require(v.inventory(case)==input_after_mutation,'resume mutated selected changed source')
  # Explicit owner file hash/ID/mtime compare, not just parsed JSON.
  v.require(v.inventory(root)['control/owner.json']==run_before['control/owner.json'],'owner physical original changed');v.verify_partial_author(pack,root,after)
  repeat_before=v.inventory(root);rec.command(('run','resume',case,root),3,label='already invalidated partialRun repeated resume preserves exact tree');v.require(v.inventory(root)==repeat_before,'repeat invalidation rewrote Run');v.require(v.inventory(case)==input_after_mutation,'repeat resume rewrote input')
  v.save_json(evidence/'after-journal.json',after);v.save_json(evidence/'after-output-inventory.json',v.inventory(root/'output'));v.save_json(evidence/'after-run-inventory.json',v.inventory(root));v.save_json(evidence/'before-raw-SQL-rows.json',before_raw);v.save_json(evidence/'after-raw-SQL-rows.json',after_raw)
  row={'case':name,'status':'passed','run_id':before['owner']['run_id'],'release_id':before['owner']['release_id'],'driver_PID':termination['pid'],'driver_real_OS_kill':termination['termination_method'],'driver_exit':termination['exit_code'],'held_boundary':termination['handshake'],'old_confirmed':4,'new_confirmed':4,'old_compiler_fingerprint':before['owner']['compiler_fingerprint'],'resume_current_compiler_actual_driver_binding':before['owner']['compiler_fingerprint'] if kind!='compiler' else rows[0]['old_compiler_fingerprint'],'actual_status':after['state']['status'],'diagnostic':after['state']['diagnostic'],'old_prefix_count':len(before_raw['checkpoints']),'new_checkpoint_count':len(after_raw['checkpoints']),'raw_prefix_exact':True,'owner_raw_identity_unchanged':True,'metadata_raw_exact':True,'output_full_inventory_exact':True,'publication_SQL_count':0,'confirmations':after['confirmations'],'attempts':{u['unit_id']:u['attempts'] for u in after['state']['units']},'source_old':old_pin,'source_new':new_pin,'source_after_resume_exact':True,'repeat_resume_full_Run_tree_equal':True,'real_model_calls':0};rows.append(row);v.save_json(rec.root/'progress.json',rows)
 assert hashlib.sha256(PATH.read_bytes()).hexdigest()==EXPECTED
 result=rec.finish({'status':'passed','producer':'independent_actual_partial_dependency_invalidation','scope':'three explicitly copied inputs/new Runs; ownPID kill at reports unit_prepared with four actual confirmations then ordinary Core05 resume','cases':rows,'fixed_checker_sha256':EXPECTED,'scientific_quality':'not_run','paid_calls':0});v.require(result['source_before_after_equal'],'public source changed during additional cases');print(json.dumps({'status':'passed','cases':len(rows),'CLI':result['actual_cli_calls'],'drivers':result['actual_driver_calls'],'invalidated_after_four':[r['case'] for r in rows],'source_gate':result['source_before_after_equal']},ensure_ascii=False),flush=True)
except Exception as e:
 if held is not None and held.process.poll() is None:held.force_stop()
 traceback.print_exc();rec.finish({'status':'failed','error':str(e),'cases':rows,'fixed_checker_sha256':EXPECTED});raise
