from pathlib import Path
import datetime,hashlib,json,stat,zipfile
ROOT=Path('/home/lyinn/project/Noetome')
BASE=Path(__file__).resolve().parent
OUT=ROOT/'.artifacts/b07-t01-partial-invalidation-extra-archive-05-20261107'
OUT.mkdir()
def digest(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);size+=len(b)
 return {'sha256':h.hexdigest(),'byte_length':size}
def stamp(p):
 s=p.stat();return {**digest(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
a=json.loads((BASE/'actual.json').read_bytes())
assert a['status']=='passed' and a['actual_cli_calls']==7 and a['actual_driver_calls']==3 and a['source_before_after_equal']
for r in a['cases']:
 assert r['status']=='passed' and r['actual_status']=='invalidated' and r['old_confirmed']==r['new_confirmed']==4
 assert r['driver_exit']==-9 and r['old_prefix_count']==23 and r['new_checkpoint_count']==24
 assert r['raw_prefix_exact'] and r['metadata_raw_exact'] and r['output_full_inventory_exact'] and r['publication_SQL_count']==0 and r['repeat_resume_full_Run_tree_equal']
readme="""# B07-T01 已确认四单元后的实际依赖失效补验证

仅新的三个 fixture copies/Run。固定 Core05 CLI e7194fa4，Core05 driver 77c7043d，第三案固定 Core04 driver f62c5172；完整程序本体在此前独立程序包，不在本 ZIP 重复。

正式 attempt02 共 7 次 ordinary CLI、3 个实际 driver。每次在 reports/unit_prepared 且 4 confirmed 后，对自己启动的实际 PID SIGKILL 并 wait（exit -9），随后分别追加有效 UTF-8 源字节、同 SHA/长度/mtime 的新 FileID replacement、实际 Core04→Core05 编译指纹变化。三案均实际 invalidated。旧23条 SQL checkpoint 的完整原元组逐项完全保持，只追加1条失效 checkpoint；4确认和旧attempt、Owner/原 metadata、已有 output 完整库存保持，publication SQL=0，重复 resume 全 Run 树相等。

不编辑 checkpoint/payload/Owner/version。源 old/new 全字节及文件ID/SHA/长度/mtime、原始 SQL 与输出树、每次 argv/PID/stdout/stderr、实际握手及 kill 原件完整收录。Recorder 核对执行前后生产/检查器源不变，实际模型/付费调用0，不证明科学质量或生产恢复。

第一次包装器因 verify_fixture_compile import 路径缺失，在调用任何 CLI/driver 之前退出；其脚本及物理 stdout/stderr 同时保留。此基础设施失败不是产品恢复 RED，attempt02 修正仅包装器 sys.path，没有更改冻结公共 source。

ZIP 逐 member CRC/SHA/length 回读及原文件ID/mtime/bytes前后全部通过。任何符号链接只记录自身 target，不跟随到外部。
"""
(OUT/'README.md').write_text(readme,encoding='utf8')
selected={};links=[]
for p in sorted(BASE.rglob('*')):
 n='actual/'+str(p.relative_to(BASE))
 if p.is_symlink():links.append({'path':n,'original_path':str(p),'link_target':str(p.readlink()),'not_followed':True});continue
 if p.is_file():selected[n]=p
for stem in ('b07-t01-partial-invalidation-extra-05-20261107','b07-t01-partial-invalidation-extra-05-20261107-attempt02'):
 for ext in ('.py','.stdout.bin','.stderr.bin'):
  p=ROOT/'.artifacts'/str(stem+ext);assert p.is_file();selected['wrapper-history/'+p.name]=p
selected['README.md']=OUT/'README.md'
rows={};archive=OUT/'originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in selected.items():
  s=stamp(p);z.write(p,n);assert stamp(p)==s;rows[n]={'original_path':str(p),'original_capture':s,'sha256':s['sha256'],'byte_length':s['byte_length']}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(rows)
 for n,r in rows.items():
  b=z.read(n);assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['byte_length'];assert stamp(Path(r['original_path']))==r['original_capture'];r['archive_crc32']=z.getinfo(n).CRC
m={'producer':'independent_actual_partial_invalidation_archive','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':digest(archive),'member_count':len(rows),'full_crc_sha_length_readback_passed':True,'all_original_ID_mtime_bytes_after_equal':True,'files':rows,'symlinks_not_followed':links,'actual_pin':digest(BASE/'actual.json'),'actual_cli_calls':7,'actual_driver_calls':3,'actual_invalidated_four_confirmed_cases':3,'source_before_after_equal':True,'initial_wrapper_import_failure_cli_driver_calls':0,'program_bodies_in_this_zip':False,'real_model_calls':0}
(OUT/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'archive':m['archive'],'manifest':digest(OUT/'manifest.json'),'members':len(rows),'actual':m['actual_pin']},ensure_ascii=False),flush=True)
