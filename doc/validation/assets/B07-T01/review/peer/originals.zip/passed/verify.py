from pathlib import Path
import hashlib,json,zipfile,collections,datetime
ROOT=Path('/home/lyinn/project/Noetome');BASE=Path(__file__).resolve().parent
PACKS={'linux':ROOT/'.artifacts/b07-t01-run-final-evidence-06-20261107','windows':Path('/mnt/d/Noetome/.artifacts/b07-t01-windows-matrix-evidence-final-07-20261107')}
def pin(b):return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def digest(p):return pin(p.read_bytes())
results={}
ks=('cases','refusal_cases','active_controls','concurrency_cases','publication_control_cases','publication_control_interruption_cases','temporary_io_cases','hot_journal_cases','compiler_version_cases','interruption_cases','publication_visibility_cases','partial_refusal_cases')
for role,p in PACKS.items():
 m=json.loads((p/'manifest.json').read_bytes());archive=p/'originals.zip';before=digest(archive);assert before=={'sha256':m['archive_sha256'],'byte_length':m['archive_byte_length']}
 with zipfile.ZipFile(archive) as z:
  assert len(z.namelist())==len(set(z.namelist()))==m['member_count']==(3439 if role=='linux' else 5259) and set(z.namelist())==set(m['members'])
  assert z.testzip() is None
  for n,r in m['members'].items():assert pin(z.read(n))=={'sha256':r['sha256'],'byte_length':r['byte_length']}
  a=json.loads(z.read('current/matrix/actual.json'));assert a['status']=='passed' and a['source_before_after_equal'] and a['fixture_freeze_sha256']=='240cf6bf13c082c24c93d92ab47a5e76cadb799beb4fe162d2665e9fbc12ccd1'
  cli=320 if role=='linux' else 319;driver=65 if role=='linux' else 64
  assert a['actual_cli_calls']==len(a['commands'])==cli and a['actual_driver_calls']==len(a['drivers'])==driver and a['actual_auxiliary_process_calls']==len(a['auxiliary_processes'])==16
  groups={k:len(a[k]) for k in ks};assert sum(groups.values())==95
  statuses=collections.Counter(r['status'] for k in ks for r in a[k]);assert statuses==({'passed':95} if role=='linux' else {'passed':94,'not_run':1})
  for i,c in enumerate(a['commands'],1):
   prefix=f'current/matrix/commands/{i:03d}/';assert json.loads(z.read(prefix+'receipt.json'))==c
   for stream in ['stdout','stderr']:assert pin(z.read(prefix+stream+'.bin'))['sha256']==c[stream+'_sha256']
  for d in a['drivers']:assert isinstance(d['pid'],int) and isinstance(d['exit_code'],int) and d.get('driver_before_after_equal',True)
  for aux in a['auxiliary_processes']:assert aux['alive_before_kill'] and isinstance(aux['exit_code'],int) and aux['exit_code']!=0 and aux['real_model_calls']==0
  rd=json.loads(z.read('current/race/driver-receipt.json'));assert rd['exit_code']==0
  for stream in ['stdout','stderr']:assert pin(z.read('current/race/'+stream+'.bin'))['sha256']==rd[stream+'_sha256']
  race=json.loads(z.read('current/race/actual-race/actual-race.json'));assert race['controller_checked_before_worker_finished'] and race['controller_transaction_after_worker_finished'] and race['worker_executed_all_six_units'] and race['controller_result']=={'Err':'RUN_TERMINAL'} and race['controls']==[0,None] and race['database_unchanged']
  before_db=z.read('current/race/actual-race/before.sqlite');after_db=z.read('current/race/actual-race/after.sqlite');assert before_db==after_db and pin(before_db)['sha256']==race['database_before_sha256']==race['database_after_sha256']
  rcli=json.loads(z.read('current/race/independent-cli/actual.json'));assert rcli['status']=='passed' and rcli['actual_cli_calls']==2 and rcli['actual_driver_calls']==0 and rcli['source_before_after_equal']
  for i,c in enumerate(rcli['commands'],1):
   prefix=f'current/race/independent-cli/commands/{i:03d}/';assert json.loads(z.read(prefix+'receipt.json'))==c
   for stream in ['stdout','stderr']:assert pin(z.read(prefix+stream+'.bin'))['sha256']==c[stream+'_sha256']
  results[role]={'archive':before,'manifest':digest(p/'manifest.json'),'members':m['member_count'],'all_member_CRC_SHA_length_independently_verified':True,'peer_reported_original_ID_mtime_before_after_equal':m['source_bytes_ids_mtime_before_after_equal'],'independent_all_original_ID_reprobe_claim':False,'all_CLI_receipts_and_stdout_stderr_SHA_linked':True,'matrix':{'CLI':cli,'driver':driver,'SQLite_aux':16,'case_groups':groups,'passed_cases':statuses['passed'],'not_run':statuses['not_run']},'actual_race':{'driver':1,'ordinary_CLI':2,'actual_driver_PID':rd['pid'],'exit0':True,'controller_running_check_before_worker_done':True,'controller_after_sqlite_writer_lock_sees_terminal':True,'controller_result':'Err RUN_TERMINAL','controls':0,'whole_before_after_database_byte_equal':True},'actual_pin':pin(z.read('current/matrix/actual.json')),'race_pin':pin(z.read('current/race/actual-race/actual-race.json')),'real_model_calls':0}
 assert digest(archive)==before
scope_base=ROOT/'.artifacts/b07-t01-final-source-scope-audit-20261107';scope=json.loads((scope_base/'actual.json').read_bytes());assert scope['status']=='passed' and scope['core_build_originals_count']==len(scope['core_files'])==125 and scope['core_partition']=={'cargo_and_build':4,'cli_src':85,'cli_tests':36} and scope['compiler_fingerprint_source_count']==len(scope['compiler_fingerprint_source_names'])==89 and scope['rust_dependency_subset_count']==len(scope['rust_dependency_files'])==1864
core05=json.loads((ROOT/'.artifacts/b07-t01-linux-build-05-20261107/source-before.json').read_bytes());native06=json.loads(Path('/mnt/d/Noetome/.artifacts/b07-t01-windows-final-06-20261107/snapshot.json').read_bytes())['files'];deps06=json.loads(Path('/mnt/d/Noetome/.artifacts/b07-t01-windows-final-06-20261107/rust-dependency-subset.json').read_bytes())['files']
for n,r in scope['core_files'].items():assert {'sha256':r['sha256'],'byte_length':r['byte_length']}=={k:core05[n][k] for k in ['sha256','byte_length']}==native06[n]==digest(ROOT/n)
for n,r in scope['rust_dependency_files'].items():assert {'sha256':r['sha256'],'byte_length':r['byte_length']}==deps06[n]==native06[n]==digest(ROOT/n)
expected_fp={n for n in core05 if not n.startswith('crates/noetome-cli/tests/')};assert len(expected_fp)==89 and set(scope['compiler_fingerprint_source_names'])==expected_fp
with zipfile.ZipFile(scope_base/'originals.zip') as z:
 assert len(z.namelist())==2 and z.testzip() is None;assert pin(z.read('actual.json'))==digest(scope_base/'actual.json');assert pin(z.read('README.md'))==digest(scope_base/'README.md')
report={'producer':'independent_final36_matrix_archives_and_named_source_readback','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','platforms':results,'exact_source_sidecar':digest(scope_base/'actual.json'),'exact_source_sidecar_zip':digest(scope_base/'originals.zip'),'core125_and_native1864_current_byte_equal_verified':True,'compiler_fingerprint89_names_exact':True,'raw_source2000_field_means_snapshot2002_minus_two_python_including_docs_and_fixtures':'not a claim of 2000 production build dependencies','primary_body_and_programs_recompressed':False,'new_product_runs':0,'earlier_wrapper_assertion_failure':'125 Linux source records include device/inode/mtime metadata; first wrapper incorrectly compared complete dict against Windows SHA/length dict. No byte mismatch; first script/stdout/stderr physically preserved. Second comparison uses exact SHA and length while preserving full original metadata.','public_files_mutated':False}
(BASE/'actual.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({'status':'passed','Linux3439members':'all CRC/SHA/length passed','Windows5259members':'all CRC/SHA/length passed','linux':results['linux']['matrix'],'windows':results['windows']['matrix'],'races_each_driver1_CLI2':'real terminal-under-writer-lock controls0 and whole DB byteeq','source125_89_1864':'exact pins/names passed'},ensure_ascii=False),flush=True)
