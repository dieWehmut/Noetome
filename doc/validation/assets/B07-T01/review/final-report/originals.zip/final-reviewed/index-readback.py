from pathlib import Path
import hashlib,json,subprocess,os
ROOT=Path('/home/lyinn/project/Noetome');OUT=ROOT/'.artifacts/b07-t01-final-report-review-20261107-attempt02';P=ROOT/'doc/validation/assets/B07-T01/review/feature-index-source-check.json';source=ROOT/'doc/validation/assets/B07-T01/review/current-source/actual.json'
h=lambda b:hashlib.sha256(b).hexdigest();raw=P.read_bytes();x=json.loads(raw);pins=json.loads(source.read_text())
scope={s['scope']:s for s in x['scopes']};core=scope['core_files'];dep=scope['rust_dependency_files']
assert set(core['git_index_members'])==set(pins['core_files']) and len(core['git_index_members'])==125
untracked={r['path']:r for r in dep['untracked_original_source_members']};assert len(untracked)==4 and len(dep['git_index_members'])==1860 and set(dep['git_index_members'])|set(untracked)==set(pins['rust_dependency_files'])
env={k:v for k,v in os.environ.items() if k in ('PATH','LANG','LC_ALL','SYSTEMROOT')}
rawindex=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT,env=env);index={}
for row in rawindex.split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);mode,oid,stage=meta.split();assert stage==b'0';index[name.decode()]=oid.decode()
for n in core['git_index_members']+dep['git_index_members']:assert n in index,n
p=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
byoid={}
for oid in sorted({index[n] for n in dep['git_index_members']}):
 p.stdin.write((oid+'\n').encode());p.stdin.flush();header=p.stdout.readline().split();assert header[0].decode()==oid and header[1]==b'blob';size=int(header[2]);b=p.stdout.read(size);assert len(b)==size and p.stdout.read(1)==b'\n';byoid[oid]={'sha256':h(b),'byte_length':len(b)}
p.stdin.close();stderr=p.stderr.read();exitcode=p.wait();assert exitcode==0 and stderr==b''
for n in dep['git_index_members']:
 pin=pins['rust_dependency_files'][n];assert byoid[index[n]]=={'sha256':pin['sha256'],'byte_length':pin['byte_length']},n;assert h((ROOT/n).read_bytes())==pin['sha256'],n
for n,row in untracked.items():
 assert n not in index and h((ROOT/n).read_bytes())==row['sha256']==pins['rust_dependency_files'][n]['sha256'] and (ROOT/n).stat().st_size==row['byte_length']
assert P.read_bytes()==raw
result={'status':'passed','producer':'independent_feature_index_exact_blob_review','reviewed_receipt_sha256':h(raw),'core_exact_members':125,'rust_dependency_tracked_exact_blobs':1860,'untracked_original_derived_assets':list(untracked.values()),'conservative_named_total':1864,'all_git_index_blob_sha_and_length_equal_current_and_original_source':True,'git_readonly_commands':['git ls-files --stage -z','git cat-file --batch'],'git_mutations':0,'public_source_mutations':0,'real_model_calls':0};(OUT/'index-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print({'status':'passed','index-check-sha256':h((OUT/'index-check.json').read_bytes())})
