from pathlib import Path
import ast,collections,hashlib,json,re,time,zipfile
ROOT=Path('/home/lyinn/project/Noetome');OUT=ROOT/'.artifacts/b07-t01-final-report-review-20261107';ASSETS=ROOT/'doc/validation/assets/B07-T01'
FILES=['doc/validation/B07-T01.md','doc/validation/assets/B07-T01/README.md','doc/validation/assets/B07-T01/verification-summary.json','doc/execution/NEXT_STEPS.md','scripts/verify_run_checkpoint.py','tests/test_verify_run_checkpoint.py']
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def save(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
before={n:pin(ROOT/n) for n in FILES};save('source-before.json',before)
for n in FILES:
 p=OUT/'selected-originals'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/n).read_bytes())
summary=json.loads((ASSETS/'verification-summary.json').read_text());checks=[]
def check(label,actual,expected):
 checks.append({'claim':label,'actual':actual,'expected':expected,'passed':actual==expected});assert actual==expected,(label,actual,expected)
keys=('cases','refusal_cases','active_controls','concurrency_cases','publication_control_cases','publication_control_interruption_cases','temporary_io_cases','hot_journal_cases','compiler_version_cases','interruption_cases','publication_visibility_cases','partial_refusal_cases')
raws={};timing={}
for name,relative,expected in [('linux','linux-run',(95,0,320,65)),('windows','windows-run',(94,1,319,64))]:
 x=json.loads((ASSETS/relative/'actual.json').read_text());raws[name]=x;s=summary['runtime_checks'][name+'_matrix'];rows=[r for k in keys for r in x[k]];status=collections.Counter(r['status'] for r in rows)
 check(name+' case row/status accounting',(len(rows),status['passed'],status['not_run']),(95,expected[0],expected[1]))
 for key,actual in [('passed',status['passed']),('not_run',status['not_run']),('ordinary_cli_calls',x['actual_cli_calls']),('driver_calls',x['actual_driver_calls']),('sqlite_writer_calls',x['actual_auxiliary_process_calls'])]:check(name+' summary '+key,s[key],actual)
 check(name+' exact CLI/driver receipts',(len(x['commands']),len(x['drivers']),len(x['auxiliary_processes'])),(expected[2],expected[3],16))
 check(name+' driver terminations',sum(d.get('action')=='force_terminated' for d in x['drivers']),s['forced_driver_terminations'])
 check(name+' all SQLite auxiliary real kills',sum(p.get('alive_before_kill') and p.get('termination_method') in ('SIGKILL','TerminateProcess') for p in x['auxiliary_processes']),16)
 check(name+' author source/CLI source unchanged',x['source_before_after_equal'],True)
 check(name+' publication gap state',(x['publication_visibility_cases'][0]['confirmed_units_before'],x['publication_visibility_cases'][0]['visible_work_status'],x['publication_visibility_cases'][0]['authoritative_release_status']),(5,'running','published'))
 check(name+' independent durable callbacks',len(x['interruption_cases']),39)
 check(name+' late ACK kill boundaries',len(x['publication_control_interruption_cases']),6)
 check(name+' hot journal cases',len(x['hot_journal_cases']),14)
 race=json.loads((ASSETS/relative/'race-actual.json').read_text());check(name+' race followup ordinaryCLI',race['actual_cli_calls'],2);check(name+' race followup passed',race['status'],'passed');check(name+' race separate from matrix',summary['runtime_checks']['terminal_transaction_race'][name]['additional_ordinary_cli_calls'],2)
 timing[name]=x['active_controls'][0]
check('Linux active timing exact rounded',[round(timing['linux']['pause_receipt_seconds'],6),round(timing['linux']['deadline_observation_seconds'],6)],[0.037608,2.058607])
check('Windows active timing exact rounded',[round(timing['windows']['pause_receipt_seconds'],3),round(timing['windows']['deadline_observation_seconds'],3)],[0.109,2.062])
check('final checker pin',summary['final_checker']['sha256'],before['scripts/verify_run_checkpoint.py']['sha256']);check('final checker bytes',summary['final_checker']['byte_length'],131174)
check('final checker test pin',summary['final_checker_tests']['sha256'],before['tests/test_verify_run_checkpoint.py']['sha256']);check('final checker tests bytes',summary['final_checker_tests']['byte_length'],29187)
with zipfile.ZipFile(ASSETS/'history/native06/originals.zip') as z:old=z.read('old-public-checker-originals/verify_run_checkpoint.py').decode()
check('Extra exact old checker pin',hashlib.sha256(old.encode()).hexdigest(),'87cb1580d26ca216061a9ef129ff92904958c099866d7811f9bcb79139b936da')
current=(ROOT/'scripts/verify_run_checkpoint.py').read_text();oldt=ast.parse(old);newt=ast.parse(current)
def functions(t):return {node.name:ast.dump(node,include_attributes=False) for node in t.body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(oldt),functions(newt)
check('old35 to final36 only existing top-level function delta',[n for n in a if a[n]!=b[n]],['inventory']);check('old35 to final36 added empty-file helpers',sorted(set(b)-set(a)),['copy_observed_file','read_observed_file'])
with zipfile.ZipFile(ASSETS/'extra-invalidations/originals.zip') as z:
 extra=json.loads(z.read('actual/actual.json'));check('Extra old35 SHA scoped',extra['fixed_checker_sha256'],summary['runtime_checks']['partial_invalidation_extra']['checker_scope'].split('unchanged')[0] and '87cb1580d26ca216061a9ef129ff92904958c099866d7811f9bcb79139b936da');check('Extra counts',(len(extra['cases']),extra['actual_cli_calls'],extra['actual_driver_calls']),(3,7,3))
 check('Extra source old/new byte lengths',(extra['cases'][0]['source_old']['byte_length'],extra['cases'][0]['source_new']['byte_length']),(170,258))
 for row in extra['cases']:
  check('Extra four-confirmed immutable prefix '+row['case'],(row['old_prefix_count'],row['new_checkpoint_count'],row['old_confirmed'],row['new_confirmed'],row['raw_prefix_exact'],row['output_full_inventory_exact'],row['repeat_resume_full_Run_tree_equal']),(23,24,4,4,True,True,True))
pack=ROOT/'fixtures/run-checkpoint-v1';frozen=json.loads((pack/'expected.json').read_text());norm=[]
for f in frozen['normative_files']:
 expected=(pack/f['expected_file']).read_bytes();actual=(ROOT/'.artifacts/b07-t01-run-final-launch-06-20261107/matrix/run-default/output/vault'/f['relative_path']).read_bytes();check('independent authored Markdown byte match '+f['relative_path'],actual==expected,True);norm.append({'path':f['relative_path'],'length':len(actual),'sha256':hashlib.sha256(actual).hexdigest(),'ending_twoLF':actual.endswith(b'\n\n'),'CR_absent':b'\r' not in actual})
check('normative note exact lengths',sorted(r['length'] for r in norm),[244,462]);check('normative endings',all(r['ending_twoLF'] and r['CR_absent'] for r in norm),True)
for item in summary['archives']:
 p=ASSETS/item['path'];check('public ZIP exact SHA '+item['path'],pin(p)['sha256'],item['sha256']);check('public ZIP length '+item['path'],p.stat().st_size,item['byte_length'])
 with zipfile.ZipFile(p) as z:check('public ZIP central members '+item['path'],len(z.infolist()),item['members'])
check('public archive totals',(len(summary['archives']),sum(r['members'] for r in summary['archives']),sum(r['byte_length'] for r in summary['archives'])),(14,27004,237641302))
lp=json.loads((ASSETS/'linux-python/actual.json').read_text());wp=json.loads((ASSETS/'windows-python/actual.json').read_text());wr=json.loads((ASSETS/'windows-rust/actual.json').read_text())
check('Linux fullPython exact total/result',(lp['tests_run'],lp['result_line']),(416,'OK (skipped=21)'));check('Windows final fullPython exact counts',(wp['python_tests_run'],wp['python_passed'],wp['python_failed'],wp['python_errors'],len(wp['python_skips'])),(477,469,0,0,8))
check('Linux fullRust explicit not_run',summary['runtime_checks']['linux_full_workspace_rust'],'not_run')
check('real model and science boundary',(summary['real_model_calls'],summary['paid_calls'],summary['scientific_quality'],summary['production_vault']),(0,0,'not_run','not_accessed'))
after={n:pin(ROOT/n) for n in FILES};save('source-after.json',after)
check('selected product/test sources unchanged',{n:before[n] for n in FILES[-2:]},{n:after[n] for n in FILES[-2:]})
result={'status':'passed','producer':'independent_final_report_and_summary_review','checks':checks,'check_count':len(checks),'timing_observations':timing,'normative_outputs':norm,'selected_doc_before_after_equal':before==after,'source_before':before,'source_after':after,'findings':[{'severity':'wording','path':'doc/validation/B07-T01.md','line':58,'issue':'deadline_observation_seconds measures the observation window after pause response+verify_envelope, not total render blocking duration','raw_numbers_correct':True,'suggested_wording':'请求返回并核验后等待2.05秒，再读取检查点；观察窗口实测2.058607/2.062秒。'}],'scope':'readonly final36/final matrices/race/Extra previous35/timing/authored outputs/public summary and archive identity; no product commands or model calls; not a rerun of every public ZIP member CRC','real_model_calls':0,'finished_ns':time.time_ns()};save('actual.json',result);print({'status':result['status'],'checks':len(checks),'docs_before_after_equal':before==after,'actual_sha256':pin(OUT/'actual.json')['sha256']})
