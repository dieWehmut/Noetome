from pathlib import Path
import json,hashlib,zipfile,datetime,stat,io
ROOT=Path('/home/lyinn/project/Noetome');OUT=ROOT/'.artifacts/b07-t01-independent-review-archive-20261107-01'
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def stamp(p):
 s=p.stat();return {**pin(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
def save(n,d):
 p=OUT/n;assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Independent final source ZIP4 audit. All 125 declared members are read, not just testzip.
build=ROOT/'.artifacts/b07-t01-linux-build-04-20261107';before=json.loads((build/'source-before.json').read_bytes());after=json.loads((build/'source-after.json').read_bytes());assert before==after and len(before)==125
actual=json.loads((build/'actual.json').read_bytes());assert actual['status']=='passed' and pin(build/'source-originals.zip')==actual['source_archive'];source_rows={}
with zipfile.ZipFile(build/'source-originals.zip') as z:
 assert z.testzip() is None and len(z.infolist())==125 and set(z.namelist())==set(before)
 for n,r in before.items():
  b=z.read(n);p=ROOT/n;pb=p.read_bytes();assert b==pb and len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256'];source_rows[n]={'sha256':r['sha256'],'byte_length':r['byte_length'],'archive_crc32':z.getinfo(n).CRC,'matches_current_bytes':True}
for n in ['cli','driver']:
 p=build/('noetome' if n=='cli' else 'run-test-driver');assert pin(p)==actual[n]
for n in ['rustc','cargo','fmt','clean','build','driver-build']:
 r=json.loads((build/n/'receipt.json').read_bytes());assert r['exit_code']==0
save('final-build04-source-audit.json',{'observer':'independent archive CRC/SHA/raw byte comparison','at':now,'build_actual_pin':pin(build/'actual.json'),'source_zip':pin(build/'source-originals.zip'),'source_before_after_full_equal':True,'source_member_count':125,'member_names_exact':True,'all_crc_passed':True,'all_member_sha_and_lengths_passed':True,'all_current_source_bytes_equal':True,'files':source_rows,'cli':actual['cli'],'driver':actual['driver'],'execution_scope':actual['scope'],'windows_execution_claim':False})
# Peer final matrix archive independently read against every recorded original.
peer=ROOT/'.artifacts/b07-t01-run-final-evidence-20261107';pm=json.loads((peer/'manifest.json').read_bytes());assert pm['members']==3315 and pin(peer/'originals.zip')==pm['archive'];peer_rows={}
with zipfile.ZipFile(peer/'originals.zip') as z:
 assert z.testzip() is None and len(z.infolist())==3315 and set(z.namelist())==set(pm['files'])
 for n,r in pm['files'].items():
  b=z.read(n);p=Path(r['original_path']);s=stamp(p);assert b==p.read_bytes() and s['sha256']==r['sha256'] and s['byte_length']==r['byte_length'];peer_rows[n]={'sha256':r['sha256'],'byte_length':r['byte_length'],'archive_crc32':z.getinfo(n).CRC,'original_path':r['original_path'],'original_after_read':s};assert stamp(p)==s
 nested=z.read('checker-author-build/build04/source-originals.zip');assert nested==(build/'source-originals.zip').read_bytes()
 matrix=json.loads(z.read('matrix/actual.json'));assert hashlib.sha256(z.read('matrix/actual.json')).hexdigest()=='739310445b28b2b421e41f503e25c69e659a58a80c4e2917668014ae1c8b03f4';assert len(matrix['commands'])==matrix['actual_cli_calls']==320;assert len(matrix['drivers'])==matrix['actual_driver_calls']==65;assert len(matrix['auxiliary_processes'])==matrix['actual_auxiliary_process_calls']==16;assert len(matrix['cases'])==95
 assert matrix['status']=='passed' and matrix['cli_sha256']==actual['cli']['sha256']
save('peer-final-matrix-archive-audit.json',{'at':now,'archive':pin(peer/'originals.zip'),'manifest':pin(peer/'manifest.json'),'member_count':3315,'all_crc_sha_length_original_bytes_passed':True,'nested_source125_zip_matches_final_build04':True,'actual_matrix':{'sha256':'739310445b28b2b421e41f503e25c69e659a58a80c4e2917668014ae1c8b03f4','CLI':320,'driver':65,'auxiliary':16,'cases':95},'cli':actual['cli'],'driver':actual['driver'],'windows_execution_claim':False,'files':peer_rows})
# Root explicitly confirmed two historical outputs existed only in tool conversation.
old_helper=ROOT/'.artifacts/b07-t01-sqlite-protocol-20261106-01/helper-identity-provenance-unexecuted.rs.txt'
save('failure-history-index.json',{'at':now,'failure_history_preserved':True,'early_capture_limitations':[{'event':'initial helper compile attempt','actual_outcome':'compile failed: 4 errors','errors':['E0689 ambiguous integer offset.checked_add at original line329; fixed to usize','E0277 u64 FromSql unsupported for count at original line479','E0277 u64 FromSql unsupported for checkpoint seq at original line506','E0277 u64 FromSql unsupported for control seq at original line536'],'tool_id':'22923','original_source':str(old_helper.relative_to(ROOT)),'original_source_pin':pin(old_helper),'raw_status':'original merged tool output available in conversation, standalone raw stdout/stderr not captured','not_final_source_validation':True},{'event':'first control race harness attempt','actual_outcome':'NotFound during fs::create_dir of test root because parent did not exist; not product RED','tool_id':'56789','source_location':'fixture_run.rs original line806','raw_status':'original merged tool output available in conversation, standalone raw stdout/stderr not captured','no_original_transcript_file_invented':True}], 'physical_raw_evidence':{'foreign_journal_failure':'.artifacts/b07-t01-foreign-journal-diagnostic-20261106-01/','late_publication_control':'.artifacts/b07-t01-publication-control-red-01-20261107/','cancel_then_pause_missing_ACK':'.artifacts/b07-t01-publication-ack-red-02-20261107/','actual_request_race_RED':'.artifacts/b07-t01-control-race-red-01-20261107/','actual_request_race_GREEN':'.artifacts/b07-t01-control-race-green-01-20261107/'},'Git_EOF_scope':'The author LF/LF gold is immutable. Final exact EOF and git text unset observations are physically recorded in RootReview03; no standalone historical git-failure stdout/stderr is claimed.'})
# Whole meaningful original artifacts. Large ELF bodies stay in their immutable runtime roots.
dirs=[
'b07-t01-readonly-review-20261106-01','b07-t01-readonly-review-20261106-02','b07-t01-readonly-review-20261106-03','b07-t01-readonly-review-20261106-04',
'b07-t01-root-core-review-20261106-01','b07-t01-root-core-review-20261107-02','b07-t01-root-core-review-20261107-03','b07-t01-root-author-readback-20261106-01',
'b07-t01-sqlite-protocol-20261106-01','b07-t01-foreign-journal-diagnostic-20261106-01','b07-t01-checkpoint-old-cli-red-linux-20261106',
'b07-t01-publication-control-red-01-20261107','b07-t01-publication-ack-red-02-20261107','b07-t01-control-race-red-01-20261107','b07-t01-control-race-green-01-20261107','b07-t01-control-request-race-final-01-20261107',
'b07-t01-run-active-01-20261106','b07-t01-run-active-02-20261106','b07-t01-run-active-03-20261106','b07-t01-run-active-04-20261106','b07-t01-run-public-01-20261106','b07-t01-run-public-02-20261106','b07-t01-run-seed-refusal-red-01-20261106','b07-t01-run-hot-journal-01-20261106','b07-t01-run-temporary-io-01-20261106','b07-t01-linux-build-04-20261107']
selected={};omitted=[];links=[]
for d in dirs:
 root=ROOT/'.artifacts'/d;assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if p.is_symlink():links.append({'path':str(p.relative_to(ROOT)),'link_target':str(p.readlink()),'archived_as_bytes':False});continue
  if not p.is_file():continue
  if p.name in ['fixed-test-driver','run-test-driver','noetome']:
   omitted.append({'original_path':str(p.relative_to(ROOT)),**pin(p),'reason':'immutable runtime binary retained in named original root; body omitted, actual bytes freshly hashed'});continue
  selected['originals/'+str(p.relative_to(ROOT))]=p
for p in sorted((ROOT/'fixtures/run-checkpoint-v1').rglob('*')):
 if p.is_file() and not p.is_symlink():selected['author/'+str(p.relative_to(ROOT/'fixtures/run-checkpoint-v1'))]=p
sqlite_pin=json.loads((ROOT/'.artifacts/b07-t01-sqlite-protocol-20261106-01/locked-sqlite-source.json').read_bytes());sqlite=Path(sqlite_pin['path']);assert pin(sqlite)=={k:sqlite_pin[k] for k in ['sha256','byte_length']};selected['protocol/locked-sqlite3.c']=sqlite
for p in sorted(OUT.iterdir()):
 if p.is_file():selected['observer/'+p.name]=p
archive=OUT/'readbackmanifest.zip';assert not archive.exists();rows={}
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in selected.items():
  s=stamp(p);b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==s['sha256'] and len(b)==s['byte_length'];z.writestr(n,b);assert stamp(p)==s;rows[n]={'original_path':str(p),'sha256':s['sha256'],'byte_length':s['byte_length'],'original_capture':s}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.infolist())==len(rows) and set(z.namelist())==set(rows)
 for n,r in rows.items():
  b=z.read(n);assert len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256'];assert stamp(Path(r['original_path']))==r['original_capture'];r['archive_crc32']=z.getinfo(n).CRC
save('readbackmanifest.json',{'producer':'independent_B07_T01_review_and_failure_original_archive','at':now,'archive':pin(archive),'member_count':len(rows),'all_member_crc_sha_length_readback_passed':True,'all_originals_after_readback_equal':True,'scope':'bounded fixture T01 reviews/source/helper/real historical RED and final source ZIP4; separate final matrix peer ZIP audited but its body not duplicated','files':rows,'omitted_binary_bodies_preserved_local':omitted,'symlink_evidence_not_followed':links,'final_core_source125_verified':True,'peer_final_matrix3315_verified':True,'windows_execution_claim':False,'early_tool_only_capture_limitations':'failure-history-index.json','docassets_written':False,'real_model_calls':0,'paid_calls':0})
print(json.dumps({'archive':pin(archive),'manifest':pin(OUT/'readbackmanifest.json'),'members':len(rows),'omitted_binaries':len(omitted),'symlinks_not_followed':len(links),'source125_passed':True,'peer3315_passed':True,'docassets_written':False},ensure_ascii=False))
