# B07-T01 late-control 修正独立源码审查 round02

本轮只读审查 Root 冻结的 late-control/control-release 修正版，未修改 Rust、Cargo、fixture 或账本，未执行 Cargo。新原件在本目录，旧 `.artifacts/b07-t01-root-core-review-20261106-01/` 和所有实际 RED 保持原样。审查源码复制时刻 2026-11-06 16:11 UTC（北京时间 2026-11-07 00:11）。

## 实际旧 RED 与来源核对

独立读取旧两轮实际 stdout：publication 握手期间 `run_pause`/`run_cancel` 报 Running/verified；同期 `run_status` 报 Running/published；释放后 `run_status` 最终报 Succeeded/published，但 controls latest2/ACK0。原 bytes 的路径、SHA、长度和这些实际字段在 `late-control-red-observed.json`；没有只信摘要。

旧 clean SourceBuild 的 source-before/source-after 125 项完全相等。`source-originals.zip` 全部 125 成员 CRC 通过，并逐成员比对原 manifest 的 SHA/长度，125/125 精确相等：ZIP SHA `092bf855ef7452e931c0c5ee0976c27e1f0eb2db810a03cac525c87aa454fcd3`，660823B。当前源与该旧 archive 只有 run_store.rs 与 fixture_run.rs 两处差异；完整 diff 已分别保存在本目录。当前 round02 构建/最终程序运行不从旧 archive 推定通过。

## 新事件与恢复的静态核对

`completed_control` 只允许旧/新均 Succeeded、旧 confirmed6、新 ACK 严格增长，且 diagnostic 精确为 `completed before control took effect`。通常 `validate_state` 同时要求新 Succeeded 对应完整六单元；随后控制事件分支逐项保持 units、manifest、output_snapshot、pending_intent、validation_report、checks 不变。history 校验完整实际 control 链和 ACK 范围，拒绝 ACK0；工作、失败和失效事件仍不能伪增 ACK。没有以此事件重新执行单元或改写发布。

正常执行在最后 `unit_confirmed` 后调用 `acknowledge_completed_controls`。已经 Succeeded 的显式 resume 先只读强验实际输出，再调用同一补确认方法。若在 CP6 后、补 ACK 前被击杀，恢复可仅追加该控制确认 CP；若在 ACK 后被击杀，latest sequence 已覆盖，方法直接返回，不追加第二次 ACK，不重做六单元或 publication。这是当前源码路径结论；正式新程序的真实击杀原件尚由 Root/执行代理运行，本代理不填通过。

`control` 在写请求前通过真正 readonly Store 恢复视图读取实际 phase，作为响应的 release_override，修正了旧 verified/published 落后显示。此前强制 metadata 完整原 record 页出处、双 DB witness、来源/Owner/输出先验及真正 readonly status 的主体与上一轮逐字节相同，本轮没有放宽。

## 立即报告的真实逻辑竞态

仍有一个控制插入窗口：`Journal::request` 在 `self.reload` 后检查终态，随后才取得 `BEGIN IMMEDIATE`，事务内没有重新读取终态。源码允许以下交错：

1. controller 检查时读取 Running。
2. worker 提交真实 Succeeded6，并把此前 controls 确认到序号 n，然后离开执行尾部。
3. 已通过旧检查的 controller 才取得写事务并 INSERT n+1。
4. 最终真实 DB 可以是 Succeeded、latest n+1、ACK n；甚至 controller 后续 `try_acquire/apply_controls` 失败前，controls INSERT 已经持久化。

单次 `completed_control` 尾部补 ACK 不能阻止后提交的旧 controller。因此在 request 的 IMMEDIATE 事务取得后、metadata zeroize 或任何 mutation 之前，应重新读取并校验最新 history.state，拒绝当时终态，由同一个 SQLite writer 锁给确认和控制插入排序。此点已立即报 Root；本代理尚未实际执行它，不能写成已运行 RED。

已给 Root 建议的确定性真实 SQL 测试：生产 request 经一个内部 NoOp callback，测试 callback 仅在旧终态检查后、BEGIN 前以 channel 等待；真实工作线程执行冻结 fixture 至 publication_committed，controller 到达 callback 后释放 worker，让真实六单元产生 Succeeded6并退出，再释放 controller。旧主体实际 INSERT 与期望 controls0 相违；修正后在事务内返回 RUN_TERMINAL，controls0，原 DB/输出不改变。测试不手工造 CP、不伪造成功，不访问模型或生产 Vault；hook-only RED 与修正版分别绑定源和 binary。

## 本轮指纹

| 文件 | SHA-256 | 字节 |
| --- | --- | ---: |
| run_store.rs | `f251a78992983cbf3ea5a3cd72090aa5a959ca76233f2f7be21edd0028e832a9` | 45074 |
| fixture_run.rs | `86ebd7ee004d70a3e9500ea859dc16e0526e192ac8bc894878f66d64b62d03a0` | 31450 |
| run_recovery.rs | `0ded7ddf2a88f7c373e83961980686e17eba28282f95c00b0ef70125550b71c0` | 42603 |
| compile_store.rs | `034eb652243da332a970810d3d789abbd198b8c40de8b5a240ba43c6ae23dd76` | 139831 |
| build.rs | `b82006d24d7db88b9f328067b08f909819429c940268551d779f8ddd71f024e9` | 2378 |

完整 9 项 source pins、副本、两处 delta、旧125 archive独立审计与旧 RED实际字段在同目录。新 SQL writer 终态修正或 test callback 使源码变化后，需要另立 round，不回写本轮或旧 candidate01 的原件、结论。
