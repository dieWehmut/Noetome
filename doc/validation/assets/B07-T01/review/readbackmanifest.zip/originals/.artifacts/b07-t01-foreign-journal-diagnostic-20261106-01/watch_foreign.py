from pathlib import Path
import datetime, hashlib, json, os, struct, subprocess, sys, time

base = Path(__file__).resolve().parent
tmp = base / 'tmp'
binary = base / 'fixed-test-driver'
env = os.environ.copy()
env['TMPDIR'] = str(tmp)
args = [str(binary), '--exact', 'run_recovery::tests::valid_foreign_run_journal_is_refused_before_real_recovery', '--nocapture', '--test-threads=1']
before_binary = hashlib.sha256(binary.read_bytes()).hexdigest()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
child = subprocess.Popen(args, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
seen = set()
records = []
deadline = time.monotonic() + 30
while child.poll() is None:
    if time.monotonic() > deadline:
        child.kill()
        raise RuntimeError('bounded diagnostic deadline exceeded')
    for root in list(tmp.iterdir()):
        if not root.name.startswith('noetome-run-journal-') or root.is_symlink() or not root.is_dir():
            continue
        control = root / 'run' / 'control'
        paths = {'db.bin': control / 'run.sqlite', 'journal.bin': control / 'run.sqlite-journal', 'owner.bin': control / 'owner.json'}
        try:
            data = {name: path.read_bytes() for name, path in paths.items()}
            if data['db.bin'][:16] != b'SQLite format 3\0' or data['journal.bin'][:8] != bytes.fromhex('d9d505f920a163d7'):
                continue
            owner = json.loads(data['owner.bin'])
            if any(paths[name].read_bytes() != value for name, value in data.items()):
                continue
        except (OSError, ValueError):
            continue
        key = (root.name, *(hashlib.sha256(data[name]).hexdigest() for name in sorted(data)))
        if key in seen or len(records) >= 64:
            continue
        seen.add(key)
        destination = base / 'snapshots' / f'{len(records):03d}'
        destination.mkdir(parents=True)
        for name, value in data.items():
            (destination / name).write_bytes(value)
        record = {'index': len(records), 'root': str(root), 'run_id': owner['run_id'], 'release_id': owner['release_id'], 'read_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'child_pid': child.pid, 'files': {name: {'sha256': hashlib.sha256(value).hexdigest(), 'byte_length': len(value)} for name, value in data.items()}}
        records.append(record)
        (destination / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    time.sleep(0.001)
stdout, stderr = child.communicate(timeout=2)
(base / 'stdout.bin').write_bytes(stdout)
(base / 'stderr.bin').write_bytes(stderr)
result = {'args': args, 'python': sys.executable, 'started': started, 'ended': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': child.returncode, 'fixed_binary_before': before_binary, 'fixed_binary_after': hashlib.sha256(binary.read_bytes()).hexdigest(), 'captured': records, 'remaining_child_temporary_roots': [str(path) for path in tmp.iterdir()], 'real_model_calls': 0}
(base / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'exit_code': child.returncode, 'captured': len(records), 'run_ids': sorted(set(r['run_id'] for r in records)), 'remaining_roots': result['remaining_child_temporary_roots']}, indent=2))
