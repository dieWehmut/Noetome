# Read-only Run recovery review 02, engine now present

Exact current source snapshots are beside this note; sources were being implemented, so fixes and pending items are separated. No source/contract/fixture/ledger change or actual CLI reproduction was performed by this review. Earlier read-only review01 remains intact.

Static fixes observed in this snapshot:

- Journal metadata and created initial checkpoint now share one SQLite transaction; the formerly separate post-metadata-COMMIT/pre-created window was removed, including loss of paused initial intent.
- Confirmed units require phase evidence (snapshot, manifest, source checks, final report and published snapshot); event/RunStatus and acknowledgement/existing controls bindings were added. The old empty-success/control witness should now be refused, subject to actual focused tests.

Remaining exact windows to reproduce and reconcile:

1. Store::create has returned after its own durable bootstrap, but source_contract progress has not committed a Run checkpoint. The output directory exists while Run output_snapshot is still null; fixture_run::verify_output returns RUN_RECOVERY_REQUIRED.
2. Each staged/Vault/report write has completed its file sync, but progress is not yet committed. The previous StoreSnapshot excludes that completed file; strict Store::resume rejects the extra inventory. A post-progress hook misses this gap.
3. record_staged or record_verified has returned after SQLite COMMIT, but progress is not yet committed. Previous snapshot.database differs; Store::resume only permits the separate final publication window. Actual kill at this COMMIT-to-Run-CP gap cannot resume through the current path.
4. Final publication COMMIT-to-Run-confirm is explicitly supported by the existing reconciliation and publication_committed hook. This narrow support must be actually tested and not generalized to the earlier write/commit gaps.

All items above are after a complete file sync or COMMIT has returned. A genuine hot rollback journal is a separate interruption inside an unfinished transaction: it should roll back only that unconfirmed transaction and retain previously confirmed history. Current Journal::verify_owner refuses any run.sqlite-journal before opening SQLite. Root has recorded this and requested a trustworthy bounded owned-journal recovery design; a foreign fake journal must remain refused. A hot-journal refusal is not proof of successful Run recovery.

Controller/cache tests to add:

- Hold a worker at a real no-transaction unit_started boundary, externally UPDATE metadata_json.context.versions.renderer in control/run.sqlite without altering owner/schema, commit, then release worker. Journal::verify currently only checks owner/schema; it does not compare current metadata/history with the writer cache. The worker can continue from cached original context; later status sees the inconsistency after publication. Recheck actual metadata/history before output confirmations/publication while allowing legitimate controllers to append controls only.
- Current control loads and verifies input but does not re-read output. Specify whether its envelope is only accepted control intent or verified physical output state; do not label unknown/tampered output freshly verified. Root will first record real RED for the intended contract.
- Parameter mismatch: start a valid paused Run, call resume with a nonexistent or different fixture path, then call resume with the original valid path. fixture_run currently invalidates the original Run for any load(parameter) failure; the second correct request then reaches RUN_TERMINAL although original selected inputs never changed. Reject mismatched caller roots without mutating Run state, and persist Invalidated only for actual stored input/identity/version change, unless the contract explicitly chooses another behavior.

Pause timing remains the PRD's <=2s stop-new-scheduling behavior. In-flight work and safe flushing can continue with observed status. The actual worker/controller tests, every output_committed boundary handshake, malformed checkpoint mutations and full regressions remain necessary; this static review is not counted as passed recovery.
