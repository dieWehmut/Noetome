from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,datetime
ROOT=Path('/home/lyinn/project/Noetome')
OUT=ROOT/'.artifacts/b07-t01-root-core-review-20261107-03'
PACK=ROOT/'fixtures/run-checkpoint-v1'
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def stamp(p):
 s=p.stat();return {**pin(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
def write(n,d):
 p=OUT/n;assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
manifest=json.loads((PACK/'frozen-sha256.json').read_bytes())
actual={p.relative_to(PACK).as_posix():pin(p) for p in sorted(PACK.rglob('*')) if p.is_file()}
expected_files=manifest['files'];assert set(actual)==set(expected_files)|{'frozen-sha256.json'}
assert all(actual[n]==v for n,v in expected_files.items())
source_pins=json.loads((PACK/'source-pins.json').read_bytes())
originals=[]
for r in source_pins['original_sources']:
 src=ROOT/r['source_path'];cap=PACK/r['captured_file'];expected={'sha256':r['sha256'],'byte_length':r['byte_length']};before=stamp(src)
 old=subprocess.run(['git','show',source_pins['repo_head_at_freeze']+':'+r['source_path']],cwd=ROOT,check=True,capture_output=True).stdout
 assert pin(src)==pin(cap)==expected
 assert old==cap.read_bytes()
 assert before==stamp(src)
 originals.append({**r,'actual_original':before,'actual_captured':pin(cap),'byte_identical':True,'matches_freeze_git_commit':True})
literal_source=(PACK/'originals/compile_expectations.rs.txt').read_text(encoding='utf8')
gold=[]
for const,name in [('ALPHA','甲容器'),('BETA','乙容器')]:
 block=re.search(r'pub const '+const+r': &str = concat!\((.*?)\n\);',literal_source,re.S).group(1)
 tokens=re.findall(r'"(?:\\.|[^"\\])*"',block)
 # Selected old author strings use JSON-compatible quoting/escapes; no renderer runs.
 authored=''.join(json.loads(t) for t in tokens).encode('utf8');p=PACK/f'expected-markdown/笔记/{name}.md'
 assert authored==p.read_bytes();assert authored.endswith(b'\n\n') and not authored.endswith(b'\n\n\n');assert b'\r' not in authored
 gold.append({'constant':const,'path':p.relative_to(ROOT).as_posix(),**pin(p),'reconstructed_from_old_author_literals':True,'last_16_bytes_hex':authored[-16:].hex(),'terminal_lf_count':len(authored)-len(authored.rstrip(b'\n')),'contains_cr':False})
attrs=subprocess.run(['git','check-attr','text','eol','whitespace','--',*[str((PACK/n).relative_to(ROOT)) for n in actual]],cwd=ROOT,capture_output=True,check=True).stdout.decode()
assert all(line.endswith(': text: unset') for line in attrs.splitlines() if ': text:' in line)
write('fixture-originals-observed.json',{'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'freeze_manifest':pin(PACK/'frozen-sha256.json'),'total_members':len(actual),'signed_members':len(expected_files),'all_signed_bytes_equal':True,'original_source_count':len(originals),'originals':originals,'gold':gold,'all_member_text_attributes_unset':True,'git_check_attr':attrs,'stable_ids':json.loads((PACK/'expected.json').read_bytes())['stable_ids'],'stable_counts':json.loads((PACK/'expected.json').read_bytes())['counts'],'dynamic_fields_separate':json.loads((PACK/'expected.json').read_bytes())['run_audit_rules']})
records=[]
for label in ['red','green']:
 base=ROOT/f'.artifacts/b07-t01-control-race-{label}-01-20261107';d=json.loads((base/'actual.json').read_bytes());run=base/'actual-run';a=json.loads((run/'actual-race.json').read_bytes());assert d['actual_race']==a
 before=(run/'before.sqlite').read_bytes();after=(run/'after.sqlite').read_bytes();assert hashlib.sha256(before).hexdigest()==a['database_before_sha256'];assert hashlib.sha256(after).hexdigest()==a['database_after_sha256'];assert (before==after)==a['database_unchanged']
 q=run/'run/control/run.sqlite';assert q.read_bytes()==after
 c=sqlite3.connect(q.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
 assert c.execute('PRAGMA quick_check').fetchall()==[('ok',)]
 controls=c.execute('SELECT sequence,run_id,action,requested_at FROM controls ORDER BY sequence').fetchall()
 cps=c.execute('SELECT sequence,previous_sha256,payload_json,payload_sha256 FROM checkpoints ORDER BY sequence').fetchall();last_hash='';events=[]
 owner=json.loads((run/'run/control/owner.json').read_bytes());last=None
 for i,previous,raw,h in cps:
  cp=json.loads(raw);assert i==len(events)+1 and previous==last_hash and hashlib.sha256(raw.encode()).hexdigest()==h and cp['sequence']==i and cp['run_id']==owner['run_id'];last_hash=h;events.append(cp['event']);last=cp
 assert len(cps)==29 and last['state']['status']=='succeeded';assert all(u['state']=='confirmed' and u['attempts']==1 for u in last['state']['units']);assert len(last['state']['units'])==6
 assert last['state']['acknowledged_control']==0
 c.close()
 sql=run/'run/output/state/compile.sqlite';c=sqlite3.connect(sql.resolve().as_uri()+'?mode=ro&immutable=1',uri=True)
 assert c.execute('PRAGMA quick_check').fetchall()==[('ok',)]
 commits=c.execute('SELECT * FROM publication_commits').fetchall();assert len(commits)==1 and commits[0][0]==owner['release_id']
 for x in commits:
  assert hashlib.sha256((run/'run/output'/x[2]).read_bytes()).hexdigest()==x[3];assert hashlib.sha256((run/'run/output'/x[4]).read_bytes()).hexdigest()==x[5]
 release=c.execute('SELECT release_id,run_id,status FROM releases').fetchall();assert release==[(owner['release_id'],owner['run_id'],'published')];c.close()
 for g in gold:
  rel=Path(g['path']).relative_to('fixtures/run-checkpoint-v1/expected-markdown')
  assert (run/'run/output/staging/vault'/rel).read_bytes()==(run/'run/output/vault'/rel).read_bytes()==(ROOT/g['path']).read_bytes()
 assert d['source_before']==d['source_after'];assert d['source_unchanged']
 stdout=(base/'stdout.bin').read_bytes().decode();stderr=(base/'stderr.bin').read_bytes().decode()
 if label=='red':
  assert d['exit_code']==101 and '0 passed; 1 failed' in stdout and 'Some("RUN_TERMINAL")' in stderr;assert a['controller_result']=={'Ok':1} and len(controls)==1 and before!=after
  assert pin(base/'run-test-driver')==d['selected_binary']
 else:
  assert d['exit_code']==0 and '1 passed; 0 failed' in stdout;assert a['controller_result']=={'Err':'RUN_TERMINAL'} and not controls and before==after
 files={str(p.relative_to(base)):stamp(p) for p in sorted(base.rglob('*')) if p.is_file() and p.name!='run-test-driver'}
 record={'label':label,'actual_json_pin':pin(base/'actual.json'),'stdout_pin':pin(base/'stdout.bin'),'stderr_pin':pin(base/'stderr.bin'),'argv':d['argv'],'pid':d['pid'],'exit_code':d['exit_code'],'selected_binary':d.get('selected_binary'),'source_before':d['source_before'],'source_after':d['source_after'],'race':{k:v for k,v in a.items() if k!='worker_result'},'actual_sql_controls':controls,'checkpoint_count':len(cps),'last_checkpoint':{'sequence':last['sequence'],'event':last['event'],'status':last['state']['status'],'acknowledged_control':last['state']['acknowledged_control']},'checkpoint_chain_raw_sha_verified':True,'six_actual_confirmations_attempts_one':True,'publication_commit_count':len(commits),'publication_report_sha_checked':True,'staged_vault_bytes_match_old_author_gold':True,'files':files}
 assert all(stamp(base/n)==s for n,s in files.items())
 record['originals_unchanged_after_readonly_sql_audit']=True;records.append(record)
write('actual-race-red-green-observed.json',{'observer':'independent_readonly_raw_SQL_SHA_audit','records':records,'new_core_execution':False,'no_model_or_paid_calls':True})
sources=json.loads((OUT/'source-pins.json').read_bytes())['files'];unchanged=[]
for p in sources:
 current=pin(ROOT/p['path']);assert current=={'sha256':p['sha256'],'byte_length':p['byte_length']};assert pin(ROOT/p['copy'])==current;unchanged.append({'path':p['path'],**current,'same_after_review':True})
write('source-after-review.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':unchanged,'all_frozen_sources_equal':True,'matches_green_source_scope':{n:pin(ROOT/n)==records[1]['source_after'][n] for n in records[1]['source_after']}})
print(json.dumps({'signed_fixture_members':len(expected_files),'total_fixture_members':len(actual),'original_source_count':len(originals),'gold':gold,'actual_sql_verified_red_green':True,'source_count':len(sources),'all_frozen_sources_equal':True},ensure_ascii=False))
