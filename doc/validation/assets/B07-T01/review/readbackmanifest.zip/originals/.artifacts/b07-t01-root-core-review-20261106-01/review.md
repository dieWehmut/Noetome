# B07-T01 candidate final01 独立源码审查

审查时刻为 2026-11-06 16:03 UTC（北京时间 2026-11-07 00:03）。本代理只读审查 Root 明确冻结的 candidate final01，未运行 Cargo，未改本次冻结的 Rust、Cargo、fixture、合同或账本。12 份实际源文件副本和逐字节 SHA/长度在 `source-pins.json`；复查结束时全部仍相等。`compiler-source-inputs.json` 独立列出 build.rs 使用的 89 个源码/Cargo 输入，未冒充实际运行时 compiler fingerprint。

当前控制和输出恢复先验的源码接线相符；原先查出的创建种子、错误参数写后拒绝、只读 status 升级 RW、cancel1→pause2 前缀，以及工作事件伪增控制确认的缺口，在此冻结源码中已有明确修正。还保留一项末尾控制确认边界待实际验证，见下表。此审查不代表最终固定 CLI、全量回归、Windows 恢复或全部强制终止验收已完成。

| 检查点 | 冻结源码结论 | 实际约束 |
| --- | --- | --- |
| 原身份与库存 | 已读 `verify_owner_layout`、普通单硬链接身份及 `worker.lock` 空长度检查 | Root/control/DB/lock/owner 原身份、有限库存先于恢复；未知侧文件不接管 |
| 错误继续参数 | `open_for_resume` 在任何 hot RW 之前调用 `check_requested_case` | 错误 case 根不能因调用 `Journal::open` 而先修改合法热日志 |
| 创建检查点 | 首 CP 必须精确等 `RunState::initial(queued/paused)` | 不接受伪造 created+Cancelled、Running、attempt、pending intent 或已有输出 |
| 控制链 | 全 controls 连续身份/动作/UTC 校验；按已确认前缀计算 cancel 优先 | cancel1+pause2 的确认不能只看最后动作；resumed 不得跳过 cancel；工作/失败/失效事件不能提高 ACK |
| 输入失效与恢复失败 | 原 guarded fixture、原 inputs 身份/SHA/长度/修改时刻、稳定 context 比对 | 新随机 UUID/时间不用于稳定比较；Failed 允许有据 resumed/invalidated，Cancelled/Invalidated 继续终止 |
| 只读 status/影像输出 | `restore_parts(..., writable=false)` 进入 `resume_readonly`/`resume_intent_readonly` | unpublished 也不升级真实 DB 为 RW；status 不调用 hot 恢复入口 |
| control 热日志 | 完整页格式→安全内存影像→原 metadata payload 页出处→Owner/Run/Release/完整链/源输出→witness→正常 SQLite | 全部 metadata 单例 record 本地/overflow 页须来自 synced before-images；不能借用未覆盖 DB 身份或冷尾段身份 |
| compile 热日志 | 原 DB identity、镜像整 SHA/长度等 snapshot；只读完整目录、intent、六表和源语义核验；witness 后才 SQLite | 无原 snapshot bootstrap 继续拒绝；普通 Store 默认不因热日志自行恢复；同时双 DB 热现场不联合接管 |
| metadata 事务 | append/request 内，在其它 SQL 修改之前 zeroize 原 UTF8 payload 并原 raw 还原，随后同 tx COMMIT | 当前 SQLite 的相同数据覆盖优化不能被当作身份页已写依据；恢复门禁仍检查实际 synced 页集合 |
| 编译来源 | build.rs 以有长度 framing 的实际源码/Cargo 字节、rustc verbose stdout、TARGET/PROFILE/OPT_LEVEL/DEBUG/flags/OS/ARCH 生成 FP | 本次仅独立核对算法及输入集合；最终二进制和实际 FP 由最终 SourceBuild 原件证明 |

## 完整 metadata 原页出处的实际失败与修正

旧 helper 第一次实际编译有 4 处类型错误，修正为显式 usize 和受检 SQL u32→u64 后，Root 实际报告 10 项中 9 通过、foreign journal 1 失败。该失败没有改 expected。独立重放固定已编译 test driver（SHA `beb8c775d641f60e314524212fb8a65b6912dbfd806f1584004b5eb9f19431dc`），测试再次 exit101；仅该子进程 TMPDIR 下的 7 组真实 DB/journal/owner 原字节由只读 watcher 保存，临时根正常清理为空。原件在 `.artifacts/b07-t01-foreign-journal-diagnostic-20261106-01/`。

`page-analysis.json` 证实两份 journal 的 synced 段只含相同 page1，SHA `2a922f5a39dcb7bc22c2a18acee63455f16e9ed42f4e852e733100c73124daf0`；Run UUID 所在 page3 属于未同步的零 magic/nRec0 尾段。旧影像的身份来自目标 DB 未覆盖的页，因此错误放过 copied foreign journal。新的门禁按 SQLite 单例 metadata 实际 table-leaf cell、varint、local payload 和 overflow 链重建完整 record，与影像 SQL 解码的 raw UTF8 元数据逐字节比对，并要求其所有承载页在 synced 恢复集合中。shared-page-only 日志现在成为单独明确拒绝用例。

根代理报告当前 focused 20 实际通过，包含全部 12 个 helper 测试，以及 foreign/shared-only 拒绝、512 page overflow 正例和 witness 突变用例。本代理没有重新运行这轮 Cargo，故该数字是 Root 的执行结果；本独立执行事实是上面的固定 binary 失败诊断和原字节页分析。最终 CLI 结果没有据此填通过。

SQLite rollback journal 不含数据库路径/file ID/Run UUID 身份字段，稀疏 checksum 也不是身份认证，因此只检查 magic/几何或影像未覆盖页的 Owner 不足以接管日志。格式和算法对照 [SQLite 文件格式](https://www.sqlite.org/fileformat.html)、[SQLite 锁与热日志恢复](https://www.sqlite.org/lockingv3.html)，并核对锁定 `libsqlite3-sys 0.39.1` 原 crate 的 SQLite 3.54.1 amalgamation：原 archive SHA 与 Cargo.lock 精确相等，tar 内 member 与 registry 源文件逐字节相等（源码 SHA `0c657666d819f261cc4007526ad57e1669de9949df7a8ea847aa284a2bf0ee52`）。safe deserialize 采用 rusqlite 公共入口和零 spare buffer，无应用层 unsafe 或落盘影像。[SQLite deserialize](https://www.sqlite.org/c3ref/deserialize.html)

## 保留待实测边界

唯一继续报告的控制边界是：worker 停在现成 `publication_committed` 握手（真实 publication SQL 已完成，Run 仍 confirmed5），此时 pause/cancel 控制请求可以落入 controls。释放 worker 后，冻结 `execute` 的末尾直接 `unit_confirmed`→Succeeded 并退出 while，没有再次 `apply_controls`；工作事件又正确禁止提高 ACK，所以该已接受请求会继续显示 pending/旧 acknowledged sequence。这是当前源路径的确定结论，本代理未执行此 case。

建议用同一个固定 final CLI/test-driver 握手实测其请求响应、最终 Run/Release、ACK 与不再调度。已有发布保持 published；不引入 T03 的用户版本回滚。若当前有限契约认可在途发布完成优先，应明确末尾 pending 的处理与可见结果；若要求下一安全边界确认 pause/cancel，则需在相应边界处理并保留真实 RED。此项没有被科学质量、最终 CLI 或通过的普通 kill cases 替代。

Windows 的读句柄在 RW 前必须释放；`RecoveryWitness` 只保存原 identity、整 SHA、长度和 modified，无返回句柄，并在源/语义检查结束后紧邻正常 SQLite RW 前复验。这减少了语义校验窗口中的现场变化风险，源码没有声称跨过最后释放读句柄到 SQLite 自身加锁之间的微小外部竞争能由该 API 原子消除。

## 指纹

| 文件 | SHA-256 | 字节 |
| --- | --- | ---: |
| run_recovery.rs | `0ded7ddf2a88f7c373e83961980686e17eba28282f95c00b0ef70125550b71c0` | 42603 |
| run_store.rs | `7272e3597db0c62e6e2bea5742749c137a4a70878bf757b9f4a52975e0f89573` | 44550 |
| fixture_run.rs | `1fedb083708647fdf288d0ccdc47749a6b1b3401083392f4e077c6bd42cc22b7` | 30590 |
| compile_store.rs | `034eb652243da332a970810d3d789abbd198b8c40de8b5a240ba43c6ae23dd76` | 139831 |
| build.rs | `b82006d24d7db88b9f328067b08f909819429c940268551d779f8ddd71f024e9` | 2378 |

完整原副本、source pins、89 项编译输入及审查结束前后相等结果在同目录 JSON。任何后续 Rust 修改需要重新绑定此审查，不以旧 fingerprint 或文档更新推定新代码已审查。
