import sqlite3,sys
db=sqlite3.connect(sys.argv[1])
db.execute('PRAGMA journal_mode=DELETE')
db.execute('PRAGMA cache_size=1')
db.execute('BEGIN IMMEDIATE')
db.execute('CREATE TABLE interrupted_writer(payload BLOB)')
for _ in range(32): db.execute('INSERT INTO interrupted_writer VALUES(?)',(b'x'*262144,))
print('actual_hot_writer_ready',flush=True)
sys.stdin.readline()
