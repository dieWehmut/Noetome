from pathlib import Path
import hashlib,json,zipfile,datetime,difflib
ROOT=Path('/home/lyinn/project/Noetome');BASE=ROOT/'.artifacts/b07-t01-independent-review-archive-20261107-01';OUT=BASE/'final'
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def save(n,d):
 p=OUT/n;assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
old_manifest=json.loads((BASE/'attempt02/readbackmanifest.json').read_bytes());assert pin(BASE/'attempt02/readbackmanifest.zip')==old_manifest['archive'];new_sources={};build_audits={};omitted=[]
for round in ['01','02']:
 p=ROOT/f'.artifacts/b07-t01-linux-build-{round}-20261107';before=json.loads((p/'source-before.json').read_bytes());after=json.loads((p/'source-after.json').read_bytes());assert before==after and len(before)==125
 a=json.loads((p/'actual.json').read_bytes());assert pin(p/'source-originals.zip')==a['source_archive'];members={};current_differences=[]
 with zipfile.ZipFile(p/'source-originals.zip') as z:
  assert z.testzip() is None and len(z.infolist())==125 and set(z.namelist())==set(before)
  for n,r in before.items():
   b=z.read(n);assert len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256'];members[n]={'sha256':r['sha256'],'byte_length':r['byte_length'],'crc32':z.getinfo(n).CRC}
   if (ROOT/n).read_bytes()!=b:current_differences.append(n)
 for f in sorted(p.rglob('*')):
  if not f.is_file():continue
  if f.name in ['run-test-driver','noetome']:
   omitted.append({'original_path':str(f),**pin(f),'reason':'actual historical fixed runtime body retained local'});continue
  new_sources['historical-builds/'+f'{round}/'+str(f.relative_to(p))]=f
 build_audits[round]={'source_archive':pin(p/'source-originals.zip'),'actual_pin':pin(p/'actual.json'),'source_before_after_equal':True,'all125_original_member_CRC_SHA_length_checked':True,'actual_source_members':members,'current_differences':current_differences,'scope':'Historical source remains historical; differences are not final-source pass evidence.'}
# Hash-identical source reproduction, explicitly distinct from contemporary capture.
cur=ROOT/'crates/noetome-cli/src/run_store.rs';current=cur.read_bytes();s=current.decode();start=s.index('        // Another worker may finish after the earlier read. Serialize the\n');end=s.index('        journal_original_metadata(&tx)?;',start);restored=(s[:start]+s[end:]).encode()
red=ROOT/'.artifacts/b07-t01-control-race-red-01-20261107/actual.json';d=json.loads(red.read_bytes());declared=d['source_before']['crates/noetome-cli/src/run_store.rs'];assert declared==d['source_after']['crates/noetome-cli/src/run_store.rs'];assert {'sha256':hashlib.sha256(restored).hexdigest(),'byte_length':len(restored)}==declared
p=OUT/'race-red-run_store.hash-identical-derived.rs.txt';p.write_bytes(restored);new_sources['derived-source/'+p.name]=p
patch=OUT/'race-red-to-final.diff';patch.write_text(''.join(difflib.unified_diff(restored.decode().splitlines(keepends=True),s.splitlines(keepends=True),fromfile='RED hash-identical derived run_store.rs',tofile='final frozen run_store.rs')));new_sources['derived-source/'+patch.name]=patch
save('historical-source-audit.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'builds':build_audits,'race_RED_source':{'status':'hash-identical derived source; not a contemporaneous disk capture','original_source_before_after_pin':declared,'actual_RED_json_pin':pin(red),'current_final_source_pin':pin(cur),'removed_block_bytes':len(current)-len(restored),'full_derived_source_pin':pin(p),'difference_patch_pin':pin(patch),'exact_match_to_original_recorded_source_sha':True},'initial_diagnostic_source_scope':'Earlier 89-input diagnostic inventories state copied-binary-time fingerprint capture, not retroactive proof of every compiler read; their existing whole code-review source copies remain preserved in the first review package.'})
for p in sorted(OUT.iterdir()):
 if p.is_file():new_sources['observer-final/'+p.name]=p
# Preserve the initial observer aggregation error and its honest labelled tool transcript.
for n in ['archive_review.py','attempt01-tool-output.txt','final-build04-source-audit.json','attempt02-stdout.bin','attempt02-stderr.bin','attempt02-receipt.json']:
 p=BASE/n;new_sources['observer-history/'+n]=p
archive=OUT/'readbackmanifest.zip';rows={n:dict(r) for n,r in old_manifest['files'].items()}
with zipfile.ZipFile(BASE/'attempt02/readbackmanifest.zip') as old,zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 assert old.testzip() is None
 for n,r in rows.items():
  b=old.read(n);assert len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256'];z.writestr(n,b)
 for n,p in new_sources.items():
  assert n not in rows;b=p.read_bytes();info=pin(p);z.writestr(n,b);assert pin(p)==info;rows[n]={'original_path':str(p),**info}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.infolist())==len(rows) and set(z.namelist())==set(rows)
 for n,r in rows.items():
  b=z.read(n);assert len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256'];assert pin(Path(r['original_path']))=={k:r[k] for k in ['sha256','byte_length']};r['archive_crc32']=z.getinfo(n).CRC
save('readbackmanifest.json',{'producer':'independent_B07_T01_review_failure_source_archive_final','archive':pin(archive),'member_count':len(rows),'all_member_crc_sha_length_readback_passed':True,'all_original_bytes_unchanged_after_readback':True,'files':rows,'prior_immutable_package':old_manifest['archive'],'omitted_binary_bodies_preserved_local':old_manifest['omitted_binary_bodies_preserved_local']+omitted,'final_source125_current_equal':'observer/final-build04-source-audit.json','peer_final_matrix3315_originals_verified':'observer/peer-final-matrix-archive-audit.json','early_tool_only_history':'observer/failure-history-index.json','hash_identical_derived_source_label':'observer-final/historical-source-audit.json','docassets_written':False,'Windows_pass_claim':False})
print(json.dumps({'archive':pin(archive),'manifest':pin(OUT/'readbackmanifest.json'),'members':len(rows),'previous_package_unchanged':pin(BASE/'attempt02/readbackmanifest.zip')==old_manifest['archive'],'old_source_zip_round01_round02_all125_checked':True,'derived_RED_source_exact_original_SHA':declared},ensure_ascii=False))
