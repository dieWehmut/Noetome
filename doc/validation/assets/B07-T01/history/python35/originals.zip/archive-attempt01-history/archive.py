from pathlib import Path
import hashlib,json,re,stat,datetime,zipfile
BASE=Path(__file__).resolve().parent
NATIVE=Path('/mnt/d/Noetome/.artifacts')
ROOT=Path('/home/lyinn/project/Noetome')
def digest(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);size+=len(b)
 return {'sha256':h.hexdigest(),'byte_length':size}
def stamp(p):
 s=p.stat();return {**digest(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
selected={};rounds={}
for n in ['01','02']:
 p=NATIVE/f'b07-t01-windows-uri-focused-{n}-20261107'
 result=json.loads((p/'result.json').read_bytes());outer=json.loads((p/'outer-result.json').read_bytes())
 assert result['exit_code']==outer['exit_code']==(1 if n=='01' else 0)
 before=json.loads((p/'source-before.json').read_bytes());after=json.loads((p/'source-after.json').read_bytes());assert before==after and len(before)==2 and result['source_before_after_equal']
 for name,pin in before.items():assert digest(p/'source-copy'/name)==pin
 for stream in ['stdout','stderr']:assert digest(p/f'{stream}.bin')['sha256']==result[f'{stream}_sha256']
 raw=(p/'stderr.bin').read_text(encoding='utf8');rows=re.findall(r'^(test_.*) \.\.\. (ok|ERROR|FAIL|skipped.*)$',raw,re.M)
 ran=re.search(r'^Ran (\d+) tests in ([0-9.]+)s$',raw,re.M);assert ran and int(ran[1])==35 and len(rows)==35 and len({name for name,status in rows})==35
 ok=[name for name,status in rows if status=='ok'];errors=[name for name,status in rows if status=='ERROR'];skips=[(name,status) for name,status in rows if status.startswith('skipped')];assert len(skips)==1 and len(ok)==(30 if n=='01' else 34) and len(errors)==(4 if n=='01' else 0)
 if n=='01':assert 'FAILED (errors=4, skipped=1)' in raw and raw.count('PermissionError: [WinError 32]')==4
 else:
  assert 'OK (skipped=1)' in raw
  assert before['scripts/verify_run_checkpoint.py']['sha256']=='87cb1580d26ca216061a9ef129ff92904958c099866d7811f9bcb79139b936da'
  assert before['tests/test_verify_run_checkpoint.py']['sha256']=='18d67c31a95ce4f9c30182b9968e93da39e447878f1b19d47e72bde38a698cb3'
  assert 'actual_cli_calls' in (p/'source-copy/tests/test_verify_run_checkpoint.py').read_text()
 freeze=p/'source-copy/fixtures/run-checkpoint-v1/frozen-sha256.json';fm=json.loads(freeze.read_bytes())
 for name,pin in fm['files'].items():assert digest(freeze.parent/name)==pin
 assert digest(freeze)['sha256']=='240cf6bf13c082c24c93d92ab47a5e76cadb799beb4fe162d2665e9fbc12ccd1'
 files=[x for x in sorted(p.rglob('*')) if x.is_file()];assert not any(x.is_symlink() for x in files)
 for x in files:selected['attempt-'+n+'/'+str(x.relative_to(p))]=x
 rounds[n]={'result_pin':digest(p/'result.json'),'outer_pin':digest(p/'outer-result.json'),'test_PID':result['pid'],'outer_PID':outer['pid'],'actual_exit':result['exit_code'],'test_count':35,'actual_ok_count':len(ok),'actual_error_count':len(errors),'actual_skip_count':len(skips),'error_tests':errors,'skip_tests':skips,'raw_elapsed_seconds':float(ran[2]),'declared_two_script_pins':before,'declared_two_script_before_after_equal':True,'frozen_author16_members_exact':True,'scope_original_string':result['scope'],'main_probe_scope_correction':'final frozen test implements start/status/resume and asserts actual_cli_calls==3; original runner.scope says two and is preserved verbatim','every_main_CLI_raw_in_this_zip':False,'process_termination_evidence':'owner review_scan_tools explicit confirmation in current collaboration conversation; all outer/test/internal writer/CLI finished; no standalone new OS PID probe is claimed','real_model_calls':0}
receipt=NATIVE/'b07-t01-windows-final-04-20261107/selected-build-receipt.json';selected['fixed-Native04-binding/selected-build-receipt.json']=receipt
program=NATIVE/'b07-t01-windows-final-04-20261107/selected/noetome.exe'
program_pin=digest(program);assert program_pin=={'sha256':'ee5dde731f73d506a9f9a4c61136067446d2da111e5cad3b450f1b9537bb25b0','byte_length':27589120}
body_archive=ROOT/'.artifacts/b07-t01-native-history-archive-20261107-01/final/originals.zip'
assert digest(body_archive)=={'sha256':'bc2e3466b103c0dfe2e23a9504899bba90d77fd303162f66d6ae23dde4a8dc8a','byte_length':57509639}
readme="""# B07-T01 Windows focused35 清理失败及真实修复回归

历史01实际35测试=30 ok+4 ERROR+1 skip、unit PID38056/outer54324、exit1，原stderr四项均为NTFS WinError32临时数据库清理失败。程序未关闭RO/mutator连接会让临时目录删除失败。原source 21250294/b0f0f1c6与原stderr完整保留，不把先前错误当通过。

历史02实际35测试=34 ok+1 skip、unit PID61272/outer10488、exit0；87cb1580检查器、18d67c31测试两份源原件 before/after逐字相等。冻结 test 使用实际 SQLite writer spill/cold与ownPID kill、正常Windows路径和规范Owner/只读status、普通三CLI start/status/resume六单元/唯一发布桥接检查。原runner.scope误写two main probes未改，计数以冻结测试真实assert3CLI及实际ok执行为依据；不能据旧字符串计两次。

两次各自完整top-level launcher/runner/raw/result/source before/after及31 source-copy成员收录，包括17作者包、8旧fixture、检查器/测试/legacy helper和原生成pyc。作者冻结16 member字节独立重验。成功测试的绿色02临时目录已由测试清理，因此本包没有逐CLI独立stdout/stderr或该临时Run DB；证据是原unit stdout/stderr、完整源及其执行断言。01失败残留的C:临时目录不扫描、不纳入本包。进程所有者review_scan_tools明确确认两轮outer/test/writer/CLI已结束，所有原root稳定；该确认不是重新生成的OS进程原raw。

固定Native04 PE ee5dde73真实SHA/长度与构建回执绑定。它的完整本体已在native-history final bc2e ZIP，此小包明确不重复PE、driver或GB缓存；不把历史04 PE的专项结果推为Native06最终验收或Core05全部检查。

逐member CRC/SHA/长度与原件的WSL读取句柄device/inode、mtime和byte SHA前后全部核对；此读取身份证据不是新Win32 file-ID采集。实际模型/付费调用0，无生产Vault/凭据读取。所有公开写入仍由root在最终source gates之后进行。
"""
(BASE/'README.md').write_text(readme,encoding='utf8');selected['README.md']=BASE/'README.md';selected['observer/archive.py']=Path(__file__)
observed={'rounds':rounds,'program_body_in_this_zip':False,'actual_fixed_native04_program':program_pin,'program_original_path':str(program),'fixed_build_receipt_pin':digest(receipt),'whole_PE_body_existing_archive':{'original_path':str(body_archive),**digest(body_archive)},'Windows_final06_scope':'not_in_this_historical_archive'}
(BASE/'independent-observed.json').write_text(json.dumps(observed,ensure_ascii=False,indent=2)+'\n',encoding='utf8');selected['independent-observed.json']=BASE/'independent-observed.json'
archive=BASE/'originals.zip';rows={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in selected.items():
  s=stamp(p);z.write(p,n);assert stamp(p)==s;rows[n]={'original_path':str(p),'original_capture':s,'sha256':s['sha256'],'byte_length':s['byte_length']}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(rows)
 for n,r in rows.items():
  b=z.read(n);assert len(b)==r['byte_length'] and hashlib.sha256(b).hexdigest()==r['sha256'];assert stamp(Path(r['original_path']))==r['original_capture'];r['archive_crc32']=z.getinfo(n).CRC
manifest={'producer':'independent_windows_focused35_history_readback','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':digest(archive),'member_count':len(rows),'full_crc_sha_length_readback_passed':True,'all_original_read_namespace_ID_mtime_bytes_after_equal':True,'files':rows,**observed}
(BASE/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'archive':manifest['archive'],'manifest':digest(BASE/'manifest.json'),'members':len(rows),'round01':{'tests':35,'ok':30,'error':4,'skip':1,'exit':1},'round02':{'tests':35,'ok':34,'error':0,'skip':1,'exit':0}},ensure_ascii=False),flush=True)
