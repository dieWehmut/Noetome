from pathlib import Path
import ctypes, hashlib, importlib.util, json, os, shutil, sqlite3, subprocess, sys, uuid
from ctypes import wintypes

BASE = Path(__file__).parent
NATIVE = Path(r'D:\Noetome\.artifacts\b07-t01-windows-final-04-20261107')
CLI = NATIVE / 'selected/noetome.exe'
sys.path.insert(0,str(NATIVE/'repo/scripts'))
spec = importlib.util.spec_from_file_location('frozen_independent_checker', NATIVE / 'repo/scripts/verify_run_checkpoint.py')
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)
K = ctypes.WinDLL('kernel32', use_last_error=True)
K.CreateFileW.argtypes = [wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
K.CreateFileW.restype = wintypes.HANDLE
K.GetFinalPathNameByHandleW.argtypes = [wintypes.HANDLE,wintypes.LPWSTR,wintypes.DWORD,wintypes.DWORD]
K.GetFinalPathNameByHandleW.restype = wintypes.DWORD
K.CloseHandle.argtypes = [wintypes.HANDLE]
K.CloseHandle.restype = wintypes.BOOL

def canonical_handle(path):
    h = K.CreateFileW(str(path),0,7,None,3,0x02200000,None)
    assert h != ctypes.c_void_p(-1).value, ctypes.get_last_error()
    try:
        data = ctypes.create_unicode_buffer(32768)
        size = K.GetFinalPathNameByHandleW(h,data,len(data),0)
        assert 0 < size < len(data), ctypes.get_last_error()
        return data.value
    finally:
        assert K.CloseHandle(h)

def pin(path):
    raw=Path(path).read_bytes()
    return {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}

environment=os.environ.copy()
for key in list(environment):
    if key.lower() in {'http_proxy','https_proxy','all_proxy'} or key.startswith('NOETOME_RUN_TEST_'):
        environment.pop(key,None)
environment.update(NO_PROXY='localhost,127.0.0.1',no_proxy='localhost,127.0.0.1')
commands=[]
def command(label,args):
    p=subprocess.Popen([str(CLI),*map(str,args)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=environment)
    out,err=p.communicate(timeout=30)
    (BASE/(label+'.stdout.bin')).write_bytes(out)
    (BASE/(label+'.stderr.bin')).write_bytes(err)
    commands.append({'label':label,'argv':[str(CLI),*map(str,args)],'pid':p.pid,'exit_code':p.returncode,
                     'stdout':pin(BASE/(label+'.stdout.bin')),'stderr':pin(BASE/(label+'.stderr.bin'))})
    assert p.returncode==0,err.decode('utf-8',errors='replace')
    return json.loads(out)

rows=[]
for page_size in (4096,512):
    base=BASE/('plain-temp-'+str(page_size))
    base.mkdir()
    fixture=base/'case'
    shutil.copytree(NATIVE/'repo/fixtures/run-checkpoint-v1/fixture',fixture)
    root=base/'run'
    start=command('start-'+str(page_size),['run','start',fixture,root,'--paused'])
    db=root/'control/run.sqlite'
    journal=root/'control/run.sqlite-journal'
    owner=json.loads((root/'control/owner.json').read_bytes())
    connection=sqlite3.connect(db)
    connection.execute('PRAGMA page_size='+str(page_size))
    connection.execute('VACUUM')
    original_db=db.read_bytes()
    connection.executescript('PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA cache_size=1; PRAGMA cache_spill=1; BEGIN IMMEDIATE;')
    original=connection.execute('SELECT metadata_json FROM metadata WHERE singleton=1').fetchone()[0]
    connection.execute('UPDATE metadata SET metadata_json=zeroblob(?) WHERE singleton=1',(len(original.encode('utf-8')),))
    connection.execute('UPDATE metadata SET metadata_json=? WHERE singleton=1',(original,))
    connection.execute('UPDATE checkpoints SET payload_json=zeroblob(131072) WHERE sequence=1')
    dirty=db.read_bytes();raw_journal=journal.read_bytes()
    assert raw_journal[:8]==bytes.fromhex('d9d505f920a163d7')
    connection.rollback();connection.close()
    db.write_bytes(dirty);journal.write_bytes(raw_journal)
    paths={'root':root,'parent':root.parent,'control':root/'control','database':db,
           'lock':root/'control/worker.lock','case':fixture}
    ids={name:checker.actual_identity(path) for name,path in paths.items()}
    equality={name:ids[name]==owner[name+'_identity'] for name in paths}
    canonical=canonical_handle(root)
    assert all(equality.values()),equality
    assert owner['root'] != str(root) and owner['root']==canonical,(owner['root'],str(root),canonical)
    (BASE/('path-evidence-'+str(page_size)+'.json')).write_text(json.dumps({'plain_root':str(root),'owner_root':owner['root'],'canonical_root':canonical,'all_ids_equal':equality,'resume_status':'not_yet_run'},ensure_ascii=False,indent=2))
    before=checker.inventory(root)
    (BASE/('before-'+str(page_size)+'.json')).write_text(json.dumps(before,ensure_ascii=False,indent=2))
    (BASE/('original-'+str(page_size)+'.sqlite')).write_bytes(original_db)
    (BASE/('dirty-'+str(page_size)+'.sqlite')).write_bytes(dirty)
    (BASE/('hot-'+str(page_size)+'.journal')).write_bytes(raw_journal)
    outcome=command('resume-'+str(page_size),['run','resume',fixture,root])
    assert outcome['run_status']=='succeeded' and outcome['confirmed_units']==6 and outcome['release_status']=='published'
    assert outcome['run_id']==start['run_id'] and not journal.exists()
    with sqlite3.connect((root/'output/state/compile.sqlite').as_uri()+'?mode=ro',uri=True) as readback:
        assert readback.execute('SELECT count(*) FROM publication_commits').fetchone()==(1,)
    rows.append({'page_size':page_size,'plain_test_root':str(root),'owner_root':owner['root'],
                 'actual_handle_canonical_root':canonical,'plain_root_string_matches_owner':False,
                 'canonical_root_string_matches_owner':True,'actual_owner_identity_equalities':equality,
                 'actual_owner_ids':ids,'restored_same_owned_db_identity':ids['database']==checker.actual_identity(db),
                 'real_synced_journal_pin':pin(BASE/('hot-'+str(page_size)+'.journal')),
                 'ordinary_cli_resume_succeeded':True,'same_run':True,'confirmed_units':6,'publication_single':True})
result={'status':'passed','producer':'native_hot_journal_owner_path_diagnostic','platform':sys.platform,
        'python':sys.version,'sqlite_auxiliary_version':sqlite3.sqlite_version,'cli':pin(CLI),'cases':rows,'commands':commands,
        'conclusion':'positive Rust test generator kept plain root while Journal::create persisted canonical Windows root; every actual file identity matches and ordinary CLI canonicalizes then recovers the same owned hot journal',
        'scope':'new diagnostic roots only; real FULL/DELETE auxiliary SQLite spill copied/restored, no forced-kill claim; public source unchanged',
        'real_model_calls':0,'real_api_calls':0}
(BASE/'actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed','case_count':len(rows),'identity_equal':True,'ordinary_resume_both':True}))
