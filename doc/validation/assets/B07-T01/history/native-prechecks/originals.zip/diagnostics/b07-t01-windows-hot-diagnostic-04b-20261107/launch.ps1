﻿$ErrorActionPreference='Stop'
$base='D:\Noetome\.artifacts\b07-t01-windows-hot-diagnostic-04b-20261107'
$pinfo=New-Object System.Diagnostics.ProcessStartInfo
$pinfo.FileName='D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe'
$pinfo.Arguments='-X utf8 "D:\Noetome\.artifacts\b07-t01-windows-hot-diagnostic-04b-20261107\native-wrapper.py"'
$pinfo.UseShellExecute=$false
$pinfo.CreateNoWindow=$true
$pinfo.RedirectStandardOutput=$true
$pinfo.RedirectStandardError=$true
$pinfo.EnvironmentVariables.Clear()
foreach($name in @('PATH','SystemRoot','WINDIR','COMSPEC','TEMP','TMP','PATHEXT','USERPROFILE','LOCALAPPDATA','APPDATA')) { $value=[Environment]::GetEnvironmentVariable($name,'Process'); if($null-ne$value) {$pinfo.EnvironmentVariables[$name]=$value} }
$pinfo.EnvironmentVariables['PYTHONUTF8']='1'
$pinfo.EnvironmentVariables['NO_PROXY']='127.0.0.1,localhost'
$pinfo.EnvironmentVariables['no_proxy']='127.0.0.1,localhost'
$process=New-Object System.Diagnostics.Process
$process.StartInfo=$pinfo
$null=$process.Start()
$start=@{producer='native_windows_independent_hot_launcher'; pid=$process.Id; started_at=[DateTime]::UtcNow.ToString('o'); real_model_calls=0}|ConvertTo-Json -Compress
[IO.File]::WriteAllText(($base+'\outer-running.json'),$start,[Text.UTF8Encoding]::new($false))
$stdout=[IO.File]::Create($base+'\outer.stdout.bin')
$stderr=[IO.File]::Create($base+'\outer.stderr.bin')
$outtask=$process.StandardOutput.BaseStream.CopyToAsync($stdout)
$errtask=$process.StandardError.BaseStream.CopyToAsync($stderr)
$process.WaitForExit(); $outtask.Wait(); $errtask.Wait(); $stdout.Dispose(); $stderr.Dispose()
$result=@{producer='native_windows_independent_hot_launcher';pid=$process.Id;exit_code=$process.ExitCode;finished_at=[DateTime]::UtcNow.ToString('o');real_model_calls=0}|ConvertTo-Json -Compress
[IO.File]::WriteAllText(($base+'\outer-result.json'),$result,[Text.UTF8Encoding]::new($false))
Write-Output $result
exit $process.ExitCode
