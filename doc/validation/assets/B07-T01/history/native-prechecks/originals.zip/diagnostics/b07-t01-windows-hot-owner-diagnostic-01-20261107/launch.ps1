$ErrorActionPreference='Stop'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-hot-owner-diagnostic-01-20261107\diagnose.py'
exit $LASTEXITCODE
