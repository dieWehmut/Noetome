from pathlib import Path
import sys, subprocess, json, hashlib, time, platform, shutil
BASE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-hot-diagnostic-04b-20261107")
NATIVE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-final-04-20261107")
REPO=NATIVE/"repo"
sys.path.insert(0,str(REPO/"scripts"))
import verify_run_checkpoint as a
def canonical(path):
    # Use the explicit Windows verbatim namespace which the actual CLI owner
    # records; file identity is still independently checked by the frozen tool.
    return Path("\\\\?\\"+str(path))
cli=NATIVE/"selected/noetome.exe";driver=NATIVE/"selected/noetome-cli-testdriver.exe"
expected={"cli":"ee5dde731f73d506a9f9a4c61136067446d2da111e5cad3b450f1b9537bb25b0","driver":"2113ab84b1d96ec059e5a5f65afca8f903f2e0b5dfc0173cd758e806da46ca3b","scripts/verify_run_checkpoint.py":"ee3802d0825e780623f2d6f20caa39cae4330e0abd1079b7b9cfc2ff1a803539","tests/test_verify_run_checkpoint.py":"df54c16018a34e430d5391c29aa8f705e6e78c74588b00a4ecb12598148b28ab"}
paths={"cli":cli,"driver":driver,**{name:REPO/name for name in expected if "/" in name}}
before={name:{"sha256":a.sha(path.read_bytes()),"byte_length":path.stat().st_size} for name,path in paths.items()}
a.require(all(before[name]["sha256"]==expected[name] for name in expected),"fixed native selected source/runtime differs")
a.save_json(BASE/"selected-before.json",before)
a.save_json(BASE/"platform.json",{"python":sys.version,"executable":sys.executable,"platform":platform.platform(),"pid":__import__('os').getpid(),"source_snapshot":str(NATIVE/"snapshot.json"),"selected_build_receipt_sha256":a.sha((NATIVE/"selected-build-receipt.json").read_bytes()),"canonical_path_policy":"explicit Windows verbatim paths, matching actual frozen CLI owner; no checker relaxation","real_model_calls":0})
shutil.copyfile(NATIVE/"selected-build-receipt.json",BASE/"selected-build-receipt.json")
argv=[sys.executable,"-X","utf8",str(BASE/"sqlite-uri-wrapper.py"),str(REPO/"scripts/verify_run_checkpoint.py"),"--cli",str(canonical(cli)),"--test-driver",str(canonical(driver)),"--root",str(canonical(BASE/"actual-hot")),"--author-pack",str(canonical(REPO/"fixtures/run-checkpoint-v1")),"--fixture-sha256","240cf6bf13c082c24c93d92ab47a5e76cadb799beb4fe162d2665e9fbc12ccd1","--hot-journal-only"]
t=time.time_ns();p=subprocess.Popen(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=a.clean_environment())
a.save_json(BASE/"running.json",{"argv":argv,"pid":p.pid,"started_ns":t,"real_model_calls":0})
try:stdout,stderr=p.communicate(timeout=600)
except subprocess.TimeoutExpired:
 p.kill();stdout,stderr=p.communicate();(BASE/"stdout.bin").write_bytes(stdout);(BASE/"stderr.bin").write_bytes(stderr);raise
(BASE/"stdout.bin").write_bytes(stdout);(BASE/"stderr.bin").write_bytes(stderr)
after={name:{"sha256":a.sha(path.read_bytes()),"byte_length":path.stat().st_size} for name,path in paths.items()}
a.save_json(BASE/"selected-after.json",after)
a.save_json(BASE/"result.json",{"status":"passed" if p.returncode==0 else "failed","argv":argv,"pid":p.pid,"exit_code":p.returncode,"started_ns":t,"finished_ns":time.time_ns(),"stdout_sha256":a.sha(stdout),"stderr_sha256":a.sha(stderr),"selected_before_after_equal":before==after,"scope":"Native04 historical diagnostic hot submatrix only; full Rust has separate unresolved helper failures","real_model_calls":0})
a.require(before==after,"selected frozen sources changed")
print(json.dumps({"status":"passed" if p.returncode==0 else "failed","pid":p.pid,"exit_code":p.returncode,"base":str(BASE)}))
sys.exit(p.returncode)
