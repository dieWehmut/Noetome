"""Temporary Windows namespace adapter; frozen semantic checker stays intact."""
from pathlib import Path
from urllib.parse import urlsplit, unquote
import sys, re
BASE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-hot-diagnostic-04b-20261107")
frozen=Path(sys.argv[1])
sys.path.insert(0,str(frozen.parent))
import verify_run_checkpoint as a
original_connect=a.sqlite3.connect
receipts=[]
def connect(database,*args,**kwargs):
    if kwargs.get("uri") and isinstance(database,str) and database.startswith("file://%3F/"):
        parsed=urlsplit(database)
        path=unquote(parsed.path)
        a.require(parsed.netloc=="%3F" and re.match(r"^/[A-Za-z]:/",path) is not None and not parsed.fragment,
                  "unexpected Windows verbatim SQLite URI")
        plain=Path(path[1:])
        verbatim=Path("\\\\?\\"+str(plain))
        left,right=a.actual_identity(verbatim),a.actual_identity(plain)
        a.require(left==right,"SQLite namespace adapter changed actual volume/index file identity")
        converted=plain.as_uri()+("?"+parsed.query if parsed.query else "")
        receipts.append({"original_uri":database,"converted_uri":converted,"verbatim_identity":left,"plain_identity":right,
                         "query_preserved":parsed.query,"file_byte_length":plain.stat().st_size})
        a.save_json(BASE/"sqlite-uri-adaptations.json",receipts)
        database=converted
    return original_connect(database,*args,**kwargs)
a.sqlite3.connect=connect
sys.argv=[str(frozen),*sys.argv[2:]]
a.main()
