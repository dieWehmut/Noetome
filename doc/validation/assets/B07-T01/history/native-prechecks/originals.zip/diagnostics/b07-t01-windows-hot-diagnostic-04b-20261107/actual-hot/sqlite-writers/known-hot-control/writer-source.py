import sqlite3,sys
db=sqlite3.connect(sys.argv[1])
db.execute('PRAGMA journal_mode=DELETE')
db.execute('PRAGMA cache_size=1')
db.execute('BEGIN IMMEDIATE')
original_metadata=db.execute('SELECT metadata_json FROM metadata').fetchone()[0]
db.execute('UPDATE metadata SET metadata_json=zeroblob(length(CAST(metadata_json AS BLOB)))')
db.execute('UPDATE metadata SET metadata_json=?',(original_metadata,))
db.execute('CREATE TABLE interrupted_writer(payload BLOB)')
for _ in range(32): db.execute('INSERT INTO interrupted_writer VALUES(?)',(b'x'*262144,))
print('actual_sqlite_writer_ready',flush=True)
sys.stdin.readline()
