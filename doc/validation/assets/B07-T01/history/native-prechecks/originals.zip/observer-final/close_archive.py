from pathlib import Path
import zipfile,json,hashlib,stat
BASE=Path(__file__).resolve().parent.parent;OUT=Path(__file__).resolve().parent
def pin(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def stamp(p):
 s=p.stat();return {**pin(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
m=json.loads((BASE/'manifest.json').read_bytes());assert pin(BASE/'originals.zip')==m['archive'];rows={n:dict(r) for n,r in m['files'].items() if n not in ['observer/archive-stdout.bin','observer/archive-stderr.bin']}
closed={ 'observer/archive-stdout.bin':BASE/'archive-stdout.bin','observer/archive-stderr.bin':BASE/'archive-stderr.bin','observer/archive-receipt.json':BASE/'archive-receipt.json','observer-final/README.md':OUT/'README.md','observer-final/close_archive.py':Path(__file__)}
archive=OUT/'originals.zip'
with zipfile.ZipFile(BASE/'originals.zip') as old,zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 assert old.testzip() is None
 for name,r in rows.items():
  b=old.read(name);assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['byte_length'];assert stamp(Path(r['original_path']))==r['original_capture'];z.writestr(name,b)
 for name,p in closed.items():
  s=stamp(p);z.writestr(name,p.read_bytes());assert stamp(p)==s;rows[name]={'original_path':str(p),'sha256':s['sha256'],'byte_length':s['byte_length'],'original_capture':s}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(rows) and set(z.namelist())==set(rows)
 for name,r in rows.items():
  b=z.read(name);assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['byte_length'];assert stamp(Path(r['original_path']))==r['original_capture'];r['archive_crc32']=z.getinfo(name).CRC
assert archive.stat().st_size<100*1024*1024
result={**m,'archive':pin(archive),'member_count':len(rows),'files':rows,'all_CRC_SHA_length_full_readback_passed':True,'all_original_identity_mtime_bytes_after_equal':True,'first_archive_immutable':m['archive'],'self_running_stdout_excluded_and_replaced_with_closed_logs':True}
(OUT/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'archive':result['archive'],'manifest':pin(OUT/'manifest.json'),'members':len(rows),'all_closed_originals_equal':True,'below100MiB':True},ensure_ascii=False))
