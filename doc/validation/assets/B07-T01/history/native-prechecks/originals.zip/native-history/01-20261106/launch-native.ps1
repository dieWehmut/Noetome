$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-01-20261106\runner.py' run --base 'D:\Noetome\.artifacts\b07-t01-windows-final-01-20261106' --snapshot-sha256 'c59a1f2c67cbc4e7171cb6f3007f44c8b53238b1a5768591457fbdca7d0cab2c'
exit $LASTEXITCODE
