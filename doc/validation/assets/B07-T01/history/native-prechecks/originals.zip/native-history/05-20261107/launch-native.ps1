$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-05-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t01-windows-final-05-20261107' --snapshot-sha256 'b3c4c832fa929c3d0d06f7699492969ac6107c4d89b5b2f4bbd0e37f0fa26305'
exit $LASTEXITCODE
