$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-04-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t01-windows-final-04-20261107' --snapshot-sha256 '18570d3719aa9d3192d47674be6ea860b7f298710ef9971cea888e030bbb37e7'
exit $LASTEXITCODE
