$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-02-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t01-windows-final-02-20261107' --snapshot-sha256 'b504c91b5aad91ef818447c489b0bfe587d4d10c54152c1c8a545ebc5dcea222'
exit $LASTEXITCODE
