$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-03-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t01-windows-final-03-20261107' --snapshot-sha256 'ec7be89446da132f815c2179d937c55bf4b13d18961d592a2c3314cbf1bc6b6d'
exit $LASTEXITCODE
