"""Prepare a new immutable source copy, then run native Windows checks.

Preparation and execution are separate. Nothing runs Cargo until the explicit
native `run` mode; it requires the earlier source manifest and its exact SHA.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tarfile
import time
import tomllib
import zipfile


PDF_PYTHON = r"D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe"
FAKE_PYTHON = r"C:\Users\Lyinn\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
POWERSHELL = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
RUSTUP = r"C:\Users\Lyinn\.cargo\bin\rustup.exe"
SKIP = {"__pycache__", "node_modules", "target", "dist", ".venv", ".git"}
SOURCE_TOPS = ("crates", "apps", "fixtures", "scripts", "sidecars", "tests", "schemas")
DOCS = ("doc/technical/RUN_CHECKPOINT_CONTRACT.md", "doc/execution/B07-T01_RUN_PLAN.md",
        "doc/README.md", "doc/technical/DATA_CONTRACTS.md", "doc/technical/ARCHITECTURE.md",
        "doc/standards/TESTING.md", "doc/standards/DESIGN.md", "README.md")


def require(value, explanation):
    if not value:
        raise RuntimeError(explanation)


def pin(path):
    digest = hashlib.sha256()
    length = 0
    with Path(path).open("rb") as stream:
        for body in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(body)
            length += len(body)
    return {"sha256": digest.hexdigest(), "byte_length": length}


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def files(root, paths):
    return {name: pin(root / name) for name in paths}


def current_source_names(repo):
    names = set()
    for top in SOURCE_TOPS:
        for path in (repo / top).rglob("*"):
            relative = path.relative_to(repo)
            if path.is_file() and not (SKIP & set(relative.parts)) and path.suffix != ".pyc":
                names.add(relative.as_posix())
    return names


def ordinary(path):
    path = Path(path)
    for item in (path, *path.parents):
        if item.exists():
            meta = item.lstat()
            require(not item.is_symlink() and not (getattr(meta, "st_file_attributes", 0) & 0x400),
                    f"linked/reparse path: {item}")
    return path


def source_names(repo):
    # Preserve the proven full-Python input inventory, including the four old
    # native collector sources and original review bytes omitted by naive
    # scripts/tests-only snapshots. Rehash current bytes; old hashes are not
    # claimed to be the new compiler's build provenance.
    baseline = repo / "doc/validation/assets/B06V-T03/windows-python/final/source-before.json"
    names = set(json.loads(baseline.read_bytes()))
    names.update(current_source_names(repo))
    names.update(DOCS)
    for name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "AGENTS.md", ".gitattributes", ".gitignore"):
        names.add(name)
    names = sorted(name for name in names if not name.startswith("target/"))
    for name in names:
        require(ordinary(repo / name).is_file(), f"selected input missing: {name}")
    return names


def prepare(args):
    require(os.name != "nt", "prepare from the current Linux worktree before native execution")
    repo = ordinary(args.repo.resolve())
    base = ordinary(args.native_base)
    require(not base.exists() and base.parent.is_dir(), "native artifact root must be absent; parent must exist")
    names = source_names(repo)
    before = files(repo, names)
    base.mkdir()
    snapshot = base / "repo"
    snapshot.mkdir()
    for name in names:
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(repo / name, target)
    require(files(snapshot, names) == before == files(repo, names), "copy or worktree changed during freeze")
    frozen = {"schema_version": 1, "producer": "b07_t01_native_source_freeze", "freeze_label": args.freeze_label,
              "source_root": str(repo), "files": before,
              "scope": "current full input/source inventory including untracked new Rust, tests and author pack; no runtime/target or generated acceptance claim"}
    save(base / "snapshot.json", frozen)
    rust_names = [name for name in names if name.startswith(("crates/", "apps/", "fixtures/", "sidecars/"))
                  or name in ("Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "scripts/cargo_local.ps1")]
    save(base / "rust-dependency-subset.json", {"files": {name: before[name] for name in rust_names},
                                               "scope": "conservative compiler/test dependency subset; retained original bytes"})
    shutil.copyfile(Path(__file__), base / "runner.py")
    with zipfile.ZipFile(base / "source-originals.zip", "x", zipfile.ZIP_DEFLATED) as archive:
        for name in names:
            archive.write(snapshot / name, "repo/" + name)
        for name in ("snapshot.json", "rust-dependency-subset.json", "runner.py"):
            archive.write(base / name, name)
    with zipfile.ZipFile(base / "source-originals.zip") as archive:
        require(archive.testzip() is None, "source archive CRC failure")
        require(len(archive.namelist()) == len(set(archive.namelist())) == len(names) + 3, "archive inventory mismatch")
        for name in names:
            raw = archive.read("repo/" + name)
            require({"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)} == before[name], "archive byte mismatch")
    save(base / "prepared-source.json", {"status": "frozen_not_executed", "snapshot": pin(base / "snapshot.json"),
                                         "source_archive": pin(base / "source-originals.zip"), "source_count": len(names),
                                         "runner": pin(base / "runner.py"), "rust_dependency_count": len(rust_names)})
    require(base.is_relative_to(Path("/mnt/d")), "native launcher requires explicit D: artifact path")
    native_base = "D:\\" + base.relative_to(Path("/mnt/d")).as_posix().replace("/", "\\")
    def quote(value):
        return "'" + value.replace("'", "''") + "'"
    launch = "$ErrorActionPreference='Stop'\n"
    launch += "$env:PSExecutionPolicyPreference='Bypass'\n"
    launch += "& " + quote(PDF_PYTHON) + " -X utf8 " + quote(native_base + "\\runner.py")
    launch += " run --base " + quote(native_base) + " --snapshot-sha256 " + quote(pin(base / "snapshot.json")["sha256"]) + "\n"
    launch += "exit $LASTEXITCODE\n"
    (base / "launch-native.ps1").write_text(launch, encoding="utf-8")
    print(json.dumps({"status": "frozen_not_executed", "native_base": str(base), "snapshot": pin(base / "snapshot.json")}), flush=True)


def launch_native(args):
    require(os.name != "nt", "launch uses explicit WSL-to-native Windows process")
    base = ordinary(args.native_base.resolve())
    require(base.is_relative_to(Path("/mnt/d")), "native artifact path must be on D:")
    frozen = json.loads((base / "snapshot.json").read_bytes())
    current = Path(frozen["source_root"])
    require(files(current, frozen["files"]) == frozen["files"], "current source changed since freeze; do not execute stale source")
    native_base = "D:\\" + base.relative_to(Path("/mnt/d")).as_posix().replace("/", "\\")
    argv = ["/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe", "-NoProfile", "-NonInteractive",
            "-ExecutionPolicy", "Bypass", "-File", native_base + "\\launch-native.ps1"]
    environment = os.environ.copy()
    for name in list(environment):
        if name.lower() in {"http_proxy", "https_proxy", "all_proxy"} or name.upper() in {"NOETOME_TANGMAO_API_KEY", "OPENAI_API_KEY", "NOETOME_SCAN_API_KEY"}:
            environment.pop(name, None)
    environment.update({"NO_PROXY": "localhost,127.0.0.1", "no_proxy": "localhost,127.0.0.1"})
    with (base / "outer-native.stdout.bin").open("xb") as out, (base / "outer-native.stderr.bin").open("xb") as err:
        child = subprocess.Popen(argv, env=environment, stdout=out, stderr=err)
        save(base / "outer-native-launch.json", {"argv": argv, "pid": child.pid, "snapshot": pin(base / "snapshot.json"),
                                                "started_at": datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"status": "native_started", "interop_pid": child.pid, "base": str(base)}), flush=True)
        code = child.wait()
    after = files(current, frozen["files"])
    save(base / "worktree-after.json", after)
    save(base / "outer-native-result.json", {"exit_code": code, "finished_at": datetime.now(timezone.utc).isoformat(),
                                            "worktree_before_after_equal": after == frozen["files"],
                                            "stdout": pin(base / "outer-native.stdout.bin"), "stderr": pin(base / "outer-native.stderr.bin")})
    print(json.dumps({"status": "native_completed", "exit_code": code, "worktree_unchanged": after == frozen["files"]}), flush=True)
    require(code == 0 and after == frozen["files"], "native command or current source guard failed; originals retained")


class NativeRun:
    def __init__(self, args):
        require(sys.platform == "win32", "run must execute in actual native Windows Python")
        require(platform.python_version() == "3.12.14", "selected Windows Python version differs")
        self.base = ordinary(args.base.resolve())
        self.repo = ordinary(self.base / "repo")
        require(pin(self.base / "snapshot.json")["sha256"] == args.snapshot_sha256, "wrong source-freeze anchor")
        self.snapshot = json.loads((self.base / "snapshot.json").read_bytes())
        self.expected = self.snapshot["files"]
        require(files(self.repo, self.expected) == self.expected, "native snapshot differs before execution")
        require(not (self.base / "native-running.json").exists(), "existing attempt is never overwritten")
        self.env = os.environ.copy()
        removed = []
        for name in list(self.env):
            if name.startswith("NOETOME_RUN_TEST_") or name.upper() in {"NOETOME_TANGMAO_API_KEY", "OPENAI_API_KEY", "NOETOME_SCAN_API_KEY"}:
                removed.append(name)
                self.env.pop(name, None)
            elif name.lower() in {"http_proxy", "https_proxy", "all_proxy"}:
                self.env.pop(name, None)
        self.env.update({"NO_PROXY": "localhost,127.0.0.1", "no_proxy": "localhost,127.0.0.1",
                         "RUSTUP_TOOLCHAIN": "1.98.1-x86_64-pc-windows-msvc", "CARGO_TARGET_DIR": str(self.base / "build-target"),
                         "NOETOME_PDF_PYTHON": PDF_PYTHON, "NOETOME_TEST_PYTHON": FAKE_PYTHON,
                         "TEMP": str(self.base / "runtime-temp"), "TMP": str(self.base / "runtime-temp"),
                         "PYTHONUTF8": "1", "PSExecutionPolicyPreference": "Bypass"})
        self.env["PATH"] = r"C:\Users\Lyinn\.cargo\bin;C:\Windows\System32\WindowsPowerShell\v1.0;" + self.env.get("PATH", "")
        Path(self.env["TEMP"]).mkdir()
        Path(self.env["CARGO_TARGET_DIR"]).mkdir()
        (self.base / "selected").mkdir()
        self.sentinel = self.base / "external-sentinel.txt"
        self.sentinel.write_bytes("外部人工哨兵保持原字节\n".encode("utf-8"))
        self.sentinel_before = pin(self.sentinel)
        self.commands = []
        self.selected = {}
        self.removed = removed
        save(self.base / "native-running.json", {"status": "running", "pid": os.getpid(), "platform": sys.platform,
                                                "snapshot": pin(self.base / "snapshot.json"), "source_count": len(self.expected)})

    def guards(self):
        expected_names = {name for name in self.expected if name.split("/", 1)[0] in SOURCE_TOPS}
        require(current_source_names(self.repo) == expected_names, "frozen compiler/test/input file set changed")
        actual = files(self.repo, self.expected)
        require(actual == self.expected, "frozen source/input changed during native execution")
        require(pin(self.sentinel) == self.sentinel_before, "external sentinel changed")
        for name, item in self.selected.items():
            require(pin(self.base / "selected" / name) == item, "fixed selected executable changed")
        return actual

    def command(self, name, argv, *, timeout=1800, extra=None, input_bytes=None):
        self.guards()
        env = self.env.copy()
        env.update(extra or {})
        started = time.monotonic()
        started_at = datetime.now(timezone.utc).isoformat()
        stdout = self.base / (name + ".stdout.bin")
        stderr = self.base / (name + ".stderr.bin")
        timed_out = False
        cleanup = None
        with stdout.open("xb") as out, stderr.open("xb") as err:
            child = subprocess.Popen([str(value) for value in argv], cwd=self.repo, env=env, stdout=out, stderr=err,
                                     stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL)
            save(self.base / (name + ".running.json"), {"argv": [str(value) for value in argv], "pid": child.pid})
            try:
                child.communicate(input=input_bytes, timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                killed = subprocess.run([r"C:\Windows\System32\taskkill.exe", "/PID", str(child.pid), "/T", "/F"],
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
                (self.base / (name + ".cleanup.stdout.bin")).write_bytes(killed.stdout)
                (self.base / (name + ".cleanup.stderr.bin")).write_bytes(killed.stderr)
                child.wait(timeout=30)
                cleanup = {"owned_pid": child.pid, "taskkill_exit": killed.returncode,
                           "stdout": pin(self.base / (name + ".cleanup.stdout.bin")), "stderr": pin(self.base / (name + ".cleanup.stderr.bin"))}
        guard_error = None
        try:
            after = self.guards()
        except Exception as error:
            guard_error = str(error)
            after = None
        receipt = {"name": name, "argv": [str(value) for value in argv], "cwd": str(self.repo), "pid": child.pid,
                   "exit_code": child.returncode, "timed_out": timed_out, "elapsed_seconds": time.monotonic() - started,
                   "started_at": started_at, "finished_at": datetime.now(timezone.utc).isoformat(),
                   "stdout": {"path": str(stdout), **pin(stdout)}, "stderr": {"path": str(stderr), **pin(stderr)},
                   "snapshot": pin(self.base / "snapshot.json"), "source_before_after_equal": after == self.expected,
                   "external_sentinel_before_after_equal": pin(self.sentinel) == self.sentinel_before,
                   "guard_error": guard_error, "cleanup": cleanup}
        self.commands.append(receipt)
        save(self.base / (name + ".json"), receipt)
        save(self.base / "native-commands.json", self.commands)
        print(json.dumps({"name": name, "exit_code": child.returncode, "elapsed_seconds": receipt["elapsed_seconds"]}), flush=True)
        require(child.returncode == 0 and not timed_out and guard_error is None,
                f"actual command or guard failed: {name}; original logs retained")
        return stdout.read_bytes(), stderr.read_bytes()

    def cargo(self, name, *args):
        return self.command(name, [POWERSHELL, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File",
                                   self.repo / "scripts/cargo_local.ps1", *args])

    def registry(self):
        source = Path(r"C:\Users\Lyinn\.cargo\registry\src")
        cache = source.parent / "cache"
        require(source.is_dir(), "actual locked registry source absent")
        lock = tomllib.loads((self.repo / "Cargo.lock").read_text(encoding="utf-8"))
        inventory = {}
        archives = {}
        missing = []
        for package in lock["package"]:
            if not package.get("source", "").startswith("registry+"):
                continue
            candidates = list(source.glob("*/" + package["name"] + "-" + package["version"]))
            if not candidates:
                missing.append(package["name"] + "@" + package["version"])
                continue
            require(len(candidates) == 1, "ambiguous selected registry source")
            root = candidates[0]
            archive = cache / root.parent.name / (root.name + ".crate")
            require(archive.is_file(), "locked package's original .crate cache absent: " + str(archive))
            archive_pin = pin(archive)
            require(archive_pin["sha256"] == package["checksum"], "original registry .crate differs from Cargo.lock")
            archives[archive.relative_to(cache).as_posix()] = archive_pin
            member_files = set()
            with tarfile.open(archive, "r:gz") as original:
                for member in original:
                    if member.isdir():
                        continue
                    require(member.isfile() and member.name.startswith(root.name + "/"), "nonordinary original registry member")
                    relative = member.name[len(root.name) + 1:]
                    require(relative and all(part not in {"", ".", ".."} for part in relative.split("/"))
                            and relative not in member_files, "unsafe or duplicate original registry member")
                    member_files.add(relative)
                    raw = original.extractfile(member).read()
                    require(pin(ordinary(root / relative)) == {"sha256": hashlib.sha256(raw).hexdigest(), "byte_length": len(raw)},
                            "registry source differs from original locked .crate: " + str(root / relative))
            actual_files = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file()}
            require(actual_files - member_files <= {".cargo-ok", ".cargo-checksum.json"}, "unknown file in locked registry source")
            checksum_file = root / ".cargo-checksum.json"
            if checksum_file.exists():
                checksums = json.loads(checksum_file.read_bytes())
                require(checksums["package"] == package["checksum"], "registry package metadata checksum differs from Cargo.lock")
                for relative, expected in checksums["files"].items():
                    require(pin(ordinary(root / relative))["sha256"] == expected, "registry checksum metadata differs from actual source")
            for path in sorted(root.rglob("*")):
                if path.is_file():
                    inventory[path.relative_to(source).as_posix()] = pin(path)
        return {"root": str(source), "cache_root": str(cache), "files": inventory, "archives": archives,
                "lock_packages_not_unpacked_for_this_platform": missing,
                "method": "Cargo.lock package SHA equals actual original .crate; every regular archive member equals unpacked source; optional checksum metadata independently checked"}

    def runtime_probes(self, cli, driver, build_scripts):
        fixture = self.repo / "fixtures/run-checkpoint-v1/fixture"
        probe, _ = self.command("actual-cli-compiler-probe", [cli, "run", "start", fixture, self.base / "cli-runtime-probe", "--paused"])
        envelope = json.loads(probe)
        actual_fp = envelope["compiler_fingerprint"]
        require(re.fullmatch(r"[0-9a-f]{64}", actual_fp), "actual CLI compiler fingerprint absent")
        build_fingerprints = {item[1] for script in build_scripts for item in script.get("env", [])
                              if item[0] == "NOETOME_RUN_COMPILER_FINGERPRINT"}
        require(build_fingerprints == {actual_fp}, "actual Cargo build-script fingerprint differs from selected CLI")
        driver_probe, _ = self.command("actual-driver-compiler-probe", [driver, "--exact", "fixture_run::tests::checkpoint_child", "--nocapture"],
                                       extra={"NOETOME_RUN_TEST_CASE": str(fixture), "NOETOME_RUN_TEST_ROOT": str(self.base / "driver-runtime-probe"),
                                              "NOETOME_RUN_TEST_OPERATION": "start", "NOETOME_RUN_TEST_EVENT": "created", "NOETOME_RUN_TEST_UNIT": "",
                                              "NOETOME_RUN_TEST_OCCURRENCE": "1"}, input_bytes=b"release\n")
        handshakes = []
        decoder = json.JSONDecoder()
        for line in driver_probe.decode("utf-8").splitlines():
            marker = line.find('{"')
            if marker < 0:
                continue
            value, _ = decoder.raw_decode(line[marker:])
            if isinstance(value, dict) and value.get("producer") == "run_checkpoint_test_handshake":
                handshakes.append(value)
        require(len(handshakes) == 1 and handshakes[0]["compiler_fingerprint"] == actual_fp
                and handshakes[0]["pid"] == self.commands[-1]["pid"], "actual driver/CLI source compiler fingerprints or actual PID differ")
        receipt = {"status": "built_runtime_identity_bound_not_full_validation", "platform": "windows",
                   "source_snapshot": pin(self.base / "snapshot.json"), "source_archive": pin(self.base / "source-originals.zip"),
                   "conservative_rust_dependencies": pin(self.base / "rust-dependency-subset.json"),
                   "cli": {"path": str(cli), **self.selected[cli.name]},
                   "test_driver": {"path": str(driver), **self.selected[driver.name]}, "actual_compiler_fingerprint": actual_fp,
                   "cargo_build_script_fingerprints": sorted(build_fingerprints), "cli_probe": envelope, "driver_handshake": handshakes[0],
                   "commands": self.commands.copy(), "scope": "actual native source/CLI/driver identity only; full regression and independent interruption acceptance still pending"}
        save(self.base / "selected-build-receipt.json", receipt)
        print(json.dumps({"status": receipt["status"], "cli": str(cli), "driver": str(driver), "compiler_fingerprint": actual_fp}), flush=True)
        return envelope, actual_fp, handshakes, build_fingerprints

    def execute(self):
        packages = json.loads((self.repo / "sidecars/pdf_parser/runtime-lock.json").read_bytes())["packages"]
        actual_packages = {name: importlib.metadata.version(name) for name in packages}
        require(actual_packages == packages, "actual Python PDF dependency lock differs")
        fake_stdout, _ = self.command("fake-python-version", [FAKE_PYTHON, "--version"])
        require(b"Python 3.12.14" in fake_stdout, "selected fake Python differs")
        tools = {}
        for tool in ("cargo", "rustc", "rustfmt", "rustdoc"):
            raw, _ = self.command("rustup-which-" + tool, [RUSTUP, "which", tool])
            path = Path(raw.decode("utf-8").strip())
            tools[tool] = {"path": str(path), **pin(path)}
        rustc, _ = self.command("rustc-version", [tools["rustc"]["path"], "--version", "--verbose"])
        require(b"release: 1.98.1" in rustc and b"host: x86_64-pc-windows-msvc" in rustc, "actual selected Rust compiler differs")
        cargo, _ = self.command("cargo-version", [tools["cargo"]["path"], "--version", "--verbose"])
        require(b"cargo 1.98.1" in cargo, "actual selected Cargo differs")
        registry_before = self.registry()
        save(self.base / "registry-before.json", registry_before)
        save(self.base / "native-runtime.json", {"platform": sys.platform, "python": sys.version, "python_executable": sys.executable,
                                                "python_pin": pin(sys.executable), "pdf_packages": actual_packages,
                                                "fake_python": {"path": FAKE_PYTHON, **pin(FAKE_PYTHON)}, "compiler_tools": tools,
                                                "selected_environment": {key: self.env.get(key) for key in ("RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "NOETOME_PDF_PYTHON", "NOETOME_TEST_PYTHON", "TEMP", "TMP", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CARGO_BUILD_TARGET", "CARGO_PROFILE_DEV_OPT_LEVEL", "CARGO_PROFILE_DEV_DEBUG")},
                                                "removed_sensitive_environment_names": self.removed,
                                                "scope": "native Windows selected Rust/Python; synthetic local tests only, no real service credential or production Vault"})
        self.cargo("cli-cache-invalidate", "clean", "-p", "noetome-cli")
        self.cargo("fmt", "fmt", "--all", "--check")
        self.cargo("workspace-check", "check", "--workspace", "--locked", "--offline")
        self.cargo("cli-build", "build", "-p", "noetome-cli", "--locked", "--offline")
        built = Path(self.env["CARGO_TARGET_DIR"]) / "debug/noetome.exe"
        cli = self.base / "selected/noetome.exe"
        shutil.copyfile(built, cli)
        require(cli.read_bytes().startswith(b"MZ") and cli.stat().st_nlink == 1 and pin(cli) == pin(built), "selected actual PE copy failed")
        self.selected["noetome.exe"] = pin(cli)
        self.env["NOETOME_TEST_BINARY"] = str(cli)
        fallback = self.repo / "target/debug/noetome.exe"
        fallback.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(cli, fallback)
        require(pin(fallback) == pin(cli), "actual source-bound fallback differs")
        driver_raw, _ = self.cargo("test-driver-build", "test", "-p", "noetome-cli", "--lib", "--no-run", "--locked", "--offline", "--message-format=json")
        drivers = []
        artifacts = []
        build_scripts = []
        for line in driver_raw.decode("utf-8").splitlines():
            value = json.loads(line)
            if value.get("reason") == "compiler-artifact":
                artifacts.append(value)
                if value["target"]["name"] == "noetome_cli" and value["profile"]["test"] and value.get("executable"):
                    drivers.append(Path(value["executable"]))
            elif value.get("reason") == "build-script-executed":
                build_scripts.append(value)
        require(len(drivers) == 1, "no exact actual test-driver artifact")
        driver = self.base / "selected/noetome-cli-testdriver.exe"
        shutil.copyfile(drivers[0], driver)
        require(pin(driver) == pin(drivers[0]) and driver.stat().st_nlink == 1, "fixed driver copy failed")
        self.selected[driver.name] = pin(driver)
        save(self.base / "compiler-artifacts.json", artifacts)
        save(self.base / "actual-build-script-records.json", build_scripts)
        self.command("test-driver-list", [driver, "--list"])
        envelope, actual_fp, handshakes, build_fingerprints = self.runtime_probes(cli, driver, build_scripts)
        suite_stdout, suite_stderr = self.cargo("workspace-tests", "test", "--workspace", "--locked", "--offline", "--", "--test-threads=4", "--nocapture")
        summaries = [tuple(map(int, match)) for match in re.findall(rb"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", suite_stdout)]
        require(summaries and all(failed == ignored == 0 for _, failed, ignored in summaries), "full Rust result summaries missing or not all passed")
        raw_modes = [b"Observed live raw sharing violation; mode=" + str(mode).encode() + b", outcome="
                     + (b"Applied" if mode < 2 else b"Blocked") in suite_stderr for mode in range(4)]
        require(all(raw_modes), "actual legacy raw-cache race injections were not all observed")
        python_stdout, python_stderr = self.command("full-python", [PDF_PYTHON, "-X", "utf8", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", "-v"])
        match = re.search(rb"Ran (\d+) tests in ([\d.]+)s", python_stderr)
        require(match and re.search(rb"\nOK(?: \(|\r?\n|$)", python_stderr), "full Python summary missing")
        registry_after = self.registry()
        save(self.base / "registry-after.json", registry_after)
        require(all(registry_after["files"].get(name) == item for name, item in registry_before["files"].items()), "original locked registry bytes changed")
        require(all(registry_after["archives"].get(name) == item for name, item in registry_before["archives"].items()), "original locked registry package archives changed")
        for name, item in tools.items():
            require(pin(item["path"]) == {key: item[key] for key in ("sha256", "byte_length")}, "compiler tool changed")
        self.guards()
        save(self.base / "source-after.json", files(self.repo, self.expected))
        receipt = {"status": "passed", "platform": "windows", "source_count": len(self.expected), "source_before_after_equal": True,
                   "source_snapshot": pin(self.base / "snapshot.json"), "source_archive": pin(self.base / "source-originals.zip"),
                   "rust_summaries": summaries, "rust_totals": {"passed": sum(row[0] for row in summaries), "failed": 0, "ignored": 0},
                   "python_tests_run": int(match[1]), "python_skips": [line.decode("utf-8") for line in python_stderr.splitlines() if b" ... skipped " in line],
                   "actual_cache_guard_modes": raw_modes, "selected_executables": self.selected,
                   "actual_cli_and_driver_compiler_fingerprint": actual_fp, "runtime_probes": {"cli": envelope, "driver_handshake": handshakes[0]},
                   "actual_build_script_fingerprints": sorted(build_fingerprints),
                   "registry_before_after_existing_bytes_equal": True,
                   "registry_source_additions": sorted(set(registry_after["files"]) - set(registry_before["files"])),
                   "external_sentinel_before_after_equal": True, "commands": self.commands,
                   "real_model_calls": 0, "real_api_calls": 0, "paid_calls": 0,
                   "limits": ["independent all-boundary/pause/cancel/forgery suite is separate; no stale trace count claimed here",
                              "this runner proves this actual native source and platform only; no production Vault or 24h claim"]}
        save(self.base / "native-final.json", receipt)
        print(json.dumps({"status": "passed", "rust_totals": receipt["rust_totals"], "python_tests_run": receipt["python_tests_run"],
                          "selected_executables": self.selected, "compiler_fingerprint": actual_fp}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    modes = parser.add_subparsers(dest="mode", required=True)
    preparing = modes.add_parser("prepare")
    preparing.add_argument("--repo", type=Path, required=True)
    preparing.add_argument("--native-base", type=Path, required=True)
    preparing.add_argument("--freeze-label", required=True)
    running = modes.add_parser("run")
    running.add_argument("--base", type=Path, required=True)
    running.add_argument("--snapshot-sha256", required=True)
    launching = modes.add_parser("launch")
    launching.add_argument("--native-base", type=Path, required=True)
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare(args)
        return
    if args.mode == "launch":
        launch_native(args)
        return
    native = None
    try:
        native = NativeRun(args)
        native.execute()
    except Exception as error:
        if native is not None:
            save(native.base / "native-failure.json", {"status": "failed", "error_type": type(error).__name__, "error": str(error),
                                                     "commands": native.commands, "selected_executables": native.selected,
                                                     "scope": "real failed attempt retained; no all-pass or cleanup inferred"})
        raise


if __name__ == "__main__":
    main()
