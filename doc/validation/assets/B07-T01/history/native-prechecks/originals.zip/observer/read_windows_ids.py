from pathlib import Path
import subprocess,json,hashlib
OUT=Path(__file__).resolve().parent
native=r'''from pathlib import Path
import json,ctypes,importlib.util,sys
from ctypes import wintypes
scripts=Path(r'D:\Noetome\.artifacts\b07-t01-windows-final-04-20261107\repo\scripts')
sys.path.insert(0,str(scripts))
spec=importlib.util.spec_from_file_location('historical_checker_read_only',scripts/'verify_run_checkpoint.py');checker=importlib.util.module_from_spec(spec);sys.modules[spec.name]=checker;spec.loader.exec_module(checker)
K=ctypes.WinDLL('kernel32',use_last_error=True)
K.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE];K.CreateFileW.restype=wintypes.HANDLE
K.GetFinalPathNameByHandleW.argtypes=[wintypes.HANDLE,wintypes.LPWSTR,wintypes.DWORD,wintypes.DWORD];K.GetFinalPathNameByHandleW.restype=wintypes.DWORD
K.CloseHandle.argtypes=[wintypes.HANDLE];K.CloseHandle.restype=wintypes.BOOL
rows=[]
for page in [4096,512]:
 base=Path(r'D:\Noetome\.artifacts\b07-t01-windows-hot-owner-diagnostic-02-20261107')/('plain-temp-'+str(page));root=base/'run';owner=json.loads((root/'control/owner.json').read_bytes());paths={'root':root,'parent':base,'control':root/'control','database':root/'control/run.sqlite','lock':root/'control/worker.lock','case':base/'case'}
 actual={name:checker.actual_identity(path) for name,path in paths.items()};equal={name:actual[name]==owner[name+'_identity'] for name in paths};assert all(equal.values())
 h=K.CreateFileW(str(root),0,7,None,3,0x02200000,None);assert h!=ctypes.c_void_p(-1).value
 try:
  buf=ctypes.create_unicode_buffer(32768);size=K.GetFinalPathNameByHandleW(h,buf,len(buf),0);assert 0<size<len(buf);canonical=buf.value
 finally:assert K.CloseHandle(h)
 assert canonical==owner['root'] and str(root)!=owner['root'];rows.append({'page_size':page,'actual_WinAPI_ids':actual,'owner_equalities':equal,'actual_canonical_root':canonical,'canonical_owner_equal':True,'plain_owner_equal':False})
print(json.dumps({'scope':'read-only independent current Windows handle ID/canonical readback of explicit two historical test roots; no CLI or SQL mutation','rows':rows,'all_twelve_owner_ids_equal':True,'real_model_calls':0},ensure_ascii=False))
'''
(OUT/'native_identity_source.py.txt').write_text(native,encoding='utf8')
exe='/mnt/c/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
with (OUT/'native-identity-stdout.bin').open('wb') as o,(OUT/'native-identity-stderr.bin').open('wb') as e:p=subprocess.run([exe,'-X','utf8','-c',native],stdout=o,stderr=e)
(OUT/'native-identity-receipt.json').write_text(json.dumps({'argv_executable':exe,'argv_mode':'-X utf8 -c exact source separately recorded','exit_code':p.returncode,'source_sha256':hashlib.sha256(native.encode()).hexdigest(),'stdout_sha256':hashlib.sha256((OUT/'native-identity-stdout.bin').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((OUT/'native-identity-stderr.bin').read_bytes()).hexdigest()},indent=2)+'\n')
print('exit',p.returncode);print((OUT/'native-identity-stdout.bin').read_text());print((OUT/'native-identity-stderr.bin').read_text())
