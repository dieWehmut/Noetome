from pathlib import Path
import hashlib,json,zipfile,re,stat,datetime,sqlite3
BASE=Path('/mnt/d/Noetome/.artifacts');OUT=Path(__file__).resolve().parent
ROUNDS=['01-20261106','02-20261107','03-20261107','04-20261107','05-20261107']
def digest(p):
 h=hashlib.sha256();length=0
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b);length+=len(b)
 return {'sha256':h.hexdigest(),'byte_length':length}
def stamp(p):
 s=p.stat();return {**digest(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
def save(n,d):
 p=OUT/n;assert not p.exists();p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
selected={};observed={};zip_audits={}
for suffix in ROUNDS:
 root=BASE/('b07-t01-windows-final-'+suffix);snapshot=json.loads((root/'snapshot.json').read_bytes());expected=snapshot['files'];source=root/'source-originals.zip';members={}
 with zipfile.ZipFile(source) as z:
  assert z.testzip() is None and len(z.infolist())==2005 and set(z.namelist())=={'repo/'+n for n in expected}|{'snapshot.json','rust-dependency-subset.json','runner.py'}
  for n in z.namelist():
   b=z.read(n);actual={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
   if n.startswith('repo/'):assert actual==expected[n[5:]]
   else:assert b==(root/n).read_bytes()
   members[n]={**actual,'crc32':z.getinfo(n).CRC}
 zip_audits[suffix]={'source_zip':digest(source),'snapshot':digest(root/'snapshot.json'),'source_members':len(expected),'zip_members':len(members),'all_CRC_SHA_length_exact':True,'all_auxiliary_files_equal':True,'files':members}
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():selected['native-history/'+suffix+'/'+p.name]=p
 commands=json.loads((root/'native-commands.json').read_bytes()) if (root/'native-commands.json').exists() else []
 for c in commands:
  for stream in ['stdout','stderr']:
   p=root/(c['name']+'.'+stream+'.bin');assert digest(p)=={k:c[stream][k] for k in ['sha256','byte_length']}
  assert c['external_sentinel_before_after_equal']
 summary={'recorded_commands':[{'name':c['name'],'pid':c['pid'],'exit_code':c['exit_code'],'source_before_after_equal':c['source_before_after_equal'],'guard_error':c['guard_error']} for c in commands],'cargo_validation_stages':[c['name'] for c in commands if c['name'] in ['fmt','workspace-check','cli-build','test-driver-build','workspace-tests']],'sourceZIP_all2005_member_readback_passed':True}
 if suffix.startswith('01'):assert not commands;summary['result']='prepared, explicitly not launched';summary['candidate_not_launched']=json.loads((root/'candidate-not-launched.json').read_bytes())
 elif suffix.startswith('02'):
  failure=json.loads((root/'native-failure.json').read_bytes());assert failure['error_type']=='FileNotFoundError' and '.cargo-checksum.json' in failure['error'];assert not summary['cargo_validation_stages'];summary['result']='registry-checksum preflight failed; toolchain/version probes ran but zero fmt/check/test/build stages';summary['failure_error']=failure['error'];assert all(c['source_before_after_equal'] for c in commands)
 elif suffix.startswith('03'):
  check=json.loads((root/'workspace-check.json').read_bytes());delta=json.loads((root/'workspace-generated-source-guard-delta.json').read_bytes());assert check['exit_code']==0 and not check['source_before_after_equal'];assert list(delta['unexpected_added_files'])==['crates/noetome-desktop/gen/schemas/windows-schema.json'] and not delta['changed_original_files'] and not delta['missing_source_files'];summary['result']='actual check exit0, source guard failed on new windows-schema.json; test/build not reached';summary['generated_schema_delta']=delta
 elif suffix.startswith('04'):
  test=json.loads((root/'workspace-tests.json').read_bytes());stdout=(root/'workspace-tests.stdout.bin').read_text();stderr=(root/'workspace-tests.stderr.bin').read_text();failures=re.findall(r'^test (run_recovery::tests::[^ ]+) \.\.\. FAILED$',stdout,re.M);counts=re.search(r'test result: FAILED\. (\d+) passed; (\d+) failed;',stdout);assert counts and tuple(map(int,counts.groups()))==(496,2);assert test['exit_code']==101 and len(failures)==2 and all(n in stderr for n in failures);assert all(c['source_before_after_equal'] and c.get('declared_build_assets_equal',True) for c in commands)
  summary.update(result='actual native unit tests failed 498=496pass+2fail; no full-workspace pass',actual_test_rows=498,passed=496,failed=2,failed_test_names=failures,stderr_has_both_panic_names=True,source_all_true=True,declared_build_assets_all_true=True,test_pid=test['pid'],test_exit=101)
 else:assert not commands;summary['result']='prepared only; zero native toolchain or Cargo stages launched'
 observed[suffix]=summary
# Original selected PE+driver bodies, actually captured and hash bound to native04 source receipts.
native04=BASE/'b07-t01-windows-final-04-20261107';receipt=json.loads((native04/'selected-build-receipt.json').read_bytes());assert digest(native04/'snapshot.json')==receipt['source_snapshot'];assert digest(native04/'source-originals.zip')==receipt['source_archive']
programs={}
for role,file,key in [('cli','noetome.exe','cli'),('driver','noetome-cli-testdriver.exe','test_driver')]:
 p=native04/'selected'/file;actual=digest(p);assert actual=={k:receipt[key][k] for k in ['sha256','byte_length']};selected['native04-selected/'+file]=p;programs[role]={'original_path':str(p),**actual,'body_in_zip':True,'source_zip':receipt['source_archive'],'selected_build_receipt':digest(native04/'selected-build-receipt.json'),'actual_compiler_fingerprint':receipt['actual_compiler_fingerprint']}
# Diagnostic roots are explicit and peer-confirmed quiescent. No repo/build-target cache traversal.
diag_names=['b07-t01-windows-hot-owner-diagnostic-01-20261107','b07-t01-windows-hot-owner-diagnostic-02-20261107','b07-t01-windows-hot-diagnostic-04-20261107','b07-t01-windows-hot-diagnostic-04b-20261107'];diagnostics={}
for name in diag_names:
 root=BASE/name
 for p in sorted(root.rglob('*')):
  if p.is_file() and not p.is_symlink():selected['diagnostics/'+name+'/'+str(p.relative_to(root))]=p
 if 'owner-diagnostic-01' in name:
  text=(root/'outer.stderr.bin').read_text();assert 'ModuleNotFoundError' in text;diagnostics[name]={'outer_exit':json.loads((root/'outer-result.json').read_bytes())['exit_code'],'result':'helper import infrastructure failure; no CLI or product writes','ModuleNotFoundError_raw':True}
 elif 'owner-diagnostic-02' in name:
  a=json.loads((root/'actual.json').read_bytes());assert a['cli']==programs['cli'] if False else True
  assert a['cli']=={k:programs['cli'][k] for k in ['sha256','byte_length']};assert a['status']=='passed' and len(a['commands'])==4 and len(a['cases'])==2;cases=[]
  for c in a['commands']:
   assert c['exit_code']==0
   for stream in ['stdout','stderr']:assert digest(root/(c['label']+'.'+stream+'.bin'))==c[stream]
  for row in a['cases']:
   page=row['page_size'];start=json.loads((root/f'start-{page}.stdout.bin').read_bytes());resume=json.loads((root/f'resume-{page}.stdout.bin').read_bytes());assert start['run_id']==resume['run_id'] and resume['confirmed_units']==6 and resume['run_status']=='succeeded' and resume['release_status']=='published';assert all(row['actual_owner_identity_equalities'].values()) and row['canonical_root_string_matches_owner'] and not row['plain_root_string_matches_owner'];assert digest(root/f'hot-{page}.journal')==row['real_synced_journal_pin']
   sql=root/f'plain-temp-{page}/run/output/state/compile.sqlite';conn=sqlite3.connect(sql.resolve().as_uri()+'?mode=ro&immutable=1',uri=True);assert conn.execute('SELECT count(*) FROM publication_commits').fetchone()==(1,);conn.close();cases.append({'page_size':page,'same_run_raw_verified':True,'confirmed':6,'publication_single_SQL_recounted':True,'original_journal_SHA_verified':True,'six_owner_ids_reported_equal':True})
  diagnostics[name]={'actual_pin':digest(root/'actual.json'),'CLI_count':4,'source_and_PE':'historical04 exact receipt/PE/sourceZIP, not final05/06','cases':cases,'transaction_method':'real FULL/DELETE spill journals copied and restored on same DB identity; not force-kill'}
 else:
  a=json.loads((root/'result.json').read_bytes());assert a['exit_code']==1 and a['selected_before_after_equal'];assert digest(root/'stdout.bin')['sha256']==a['stdout_sha256'] and digest(root/'stderr.bin')['sha256']==a['stderr_sha256']
  if '04b' in name:
   f=root/'actual-hot/sqlite-writers/known-hot-control/failure-receipt.json';w=json.loads(f.read_bytes());assert 'exit_code' in w and w['exit_code'] is not None;diagnostics[name]={'result':'URI-only wrapper passed initial SQL; actual writer failed CRLF vs expectedLF handshake; no product gate conclusion','writer_PID':w['pid'],'writer_exit':w['exit_code'],'writer_failure_receipt':digest(f),'peer_confirmed_no_running_children':True,'harness_PID':a['pid'],'harness_exit':1}
  else:diagnostics[name]={'result':'invalid URI authority after actual paused CLI; no writer','harness_PID':a['pid'],'harness_exit':1,'peer_confirmed_no_running_children':True}
# Independently repeated Windows handle IDs/canonical paths were recorded before this collector.
native_ids=json.loads((OUT/'native-identity-stdout.bin').read_bytes());assert native_ids['all_twelve_owner_ids_equal'];assert json.loads((OUT/'native-identity-receipt.json').read_bytes())['exit_code']==0
save('independent-observed.json',{'producer':'independent historical native source/raw/selected program archive audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rounds':observed,'sourceZIPs':zip_audits,'programs':programs,'diagnostics':diagnostics,'independent_Windows_handle_id_canonical_readback':native_ids,'scope':'history only, native04 full Rust failed and source05 only prepared; no final native acceptance','repo_or_buildtarget_traversed':False,'availability':'All files named in this manifest are actual captured disk bytes. Earlier helper4 compile errors/tool22923 and race harness tool56789 standalone raw were not captured; retained conversation availability only in separate historical review index.','public_source_written':False,'real_model_calls':0,'paid_calls':0})
for p in sorted(OUT.iterdir()):
 if p.is_file():selected['observer/'+p.name]=p
archive=OUT/'originals.zip';rows={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in selected.items():
  before=stamp(p);z.write(p,name);assert stamp(p)==before;rows[name]={'original_path':str(p),'sha256':before['sha256'],'byte_length':before['byte_length'],'original_capture':before}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.infolist())==len(rows) and set(z.namelist())==set(rows)
 for name,r in rows.items():
  b=z.read(name);assert hashlib.sha256(b).hexdigest()==r['sha256'] and len(b)==r['byte_length'];assert stamp(Path(r['original_path']))==r['original_capture'];r['archive_crc32']=z.getinfo(name).CRC
assert archive.stat().st_size<100*1024*1024
save('manifest.json',{'producer':'independent_native_B07_T01_history_archive','archive':digest(archive),'member_count':len(rows),'all_CRC_SHA_length_full_readback_passed':True,'all_original_identity_mtime_bytes_after_equal':True,'files':rows,'program_bodies':programs,'each_distributed_file_below100MiB':True,'native04_actual_failure':observed['04-20261107'],'scope':'historical only, never final native pass','repo_buildtarget_cache_copied':False,'public_source_written':False})
print(json.dumps({'archive':digest(archive),'manifest':digest(OUT/'manifest.json'),'members':len(rows),'sourceZIPs':5,'native04_failed':observed['04-20261107']['failed_test_names'],'selected_bodies':programs,'below100MiB':True},ensure_ascii=False),flush=True)
