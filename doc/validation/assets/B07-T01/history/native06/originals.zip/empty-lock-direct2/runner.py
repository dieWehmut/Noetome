from pathlib import Path
import sys,subprocess,time,json
BASE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-empty-lock-diagnostic-06-20261107")
NATIVE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107")
REPO=NATIVE/"repo"
sys.path.insert(0,str(REPO/"scripts"));import verify_run_checkpoint as a
cli=NATIVE/"selected/noetome.exe";driver=NATIVE/"selected/noetome-cli-testdriver.exe";fixture=a.canonical_selected_path(REPO/"fixtures/run-checkpoint-v1/fixture")
r=a.Recorder(BASE/"controller",cli,fixture);run=a.canonical_selected_path(BASE)/"held-run";held=None
try:
 held=a.HeldDriver(r,driver,"fixture_run::tests::checkpoint_child",run,"unit_progress","render",1)
 lock=run/"control/worker.lock";records=[]
 a.save_json(BASE/"held-lock-metadata.json",{"driver_pid":held.process.pid,"handshake":held.handshake,"zero_byte_length":lock.stat().st_size,"actual_file_identity":a.actual_identity(lock),"owner":a.read_json(run/"control/owner.json"),"reader_strategy":"metadata only before ordinary PE calls; no file-byte read or checker inventory bypass acceptance","real_model_calls":0})
 for operation in ("status","pause"):
  args=[str(cli),"run",operation,str(run)];t=time.time_ns();p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=a.clean_environment(),timeout=30)
  (BASE/(operation+".stdout.bin")).write_bytes(p.stdout);(BASE/(operation+".stderr.bin")).write_bytes(p.stderr)
  records.append({"argv":args,"exit_code":p.returncode,"started_ns":t,"finished_ns":time.time_ns(),"stdout_sha256":a.sha(p.stdout),"stderr_sha256":a.sha(p.stderr),"driver_still_alive":held.process.poll() is None})
  a.save_json(BASE/"ordinary-cli-observations.json",records)
finally:
 if held is not None and held.process.poll() is None: held.force_stop()
 if held is not None:
  lock=run/"control/worker.lock";(BASE/"lock-after-process-death.bin").write_bytes(lock.read_bytes())
  a.save_json(BASE/"result.json",{"status":"observed","actual_cli_calls":len(records),"actual_driver_calls":1,"owned_driver_pid":held.process.pid,"driver_exit_code":held.process.returncode,"force_terminated":True,"lock_after_byte_length":lock.stat().st_size,"lock_after_identity":a.actual_identity(lock),"real_model_calls":0})
print(json.dumps(records))
