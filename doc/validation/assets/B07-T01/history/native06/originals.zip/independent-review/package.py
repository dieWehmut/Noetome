from pathlib import Path
import json,hashlib,re,stat,zipfile,datetime
ROOT=Path('/home/lyinn/project/Noetome');BASE=Path(__file__).resolve().parent;OUT=BASE/'package';OUT.mkdir()
NATIVE=Path('/mnt/d/Noetome/.artifacts')
def digest(p):return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'byte_length':p.stat().st_size}
def stamp(p):
 st=p.stat();return {**digest(p),'device':st.st_dev,'inode':st.st_ino,'mtime_ns':st.st_mtime_ns,'mode':stat.S_IMODE(st.st_mode)}
selected={};links=[]
roots={n:NATIVE/name for n,name in {'first-matrix06':'b07-t01-windows-matrix-final-06-20261107','empty-lock-direct2':'b07-t01-windows-empty-lock-diagnostic-06-20261107','live-lock-direct4':'b07-t01-windows-live-lock-diagnostic-01-20261107','focused36':'b07-t01-windows-empty-lock-focused-03-20261107'}.items()}
mat=roots['first-matrix06']/'matrix';a=json.loads((mat/'actual.json').read_bytes());assert a['status']=='failed' and a['actual_cli_calls']==121 and a['actual_driver_calls']==1 and a['source_before_after_equal'];assert a['error_type']=='PermissionError'
for i,c in enumerate(a['commands'],1):
 p=mat/'commands'/f'{i:03d}';assert json.loads((p/'receipt.json').read_bytes())==c
 for stream in ['stdout','stderr']:assert digest(p/f'{stream}.bin')['sha256']==c[f'{stream}_sha256']
assert len(a['commands'])==121 and len(a['drivers'])==1 and a['drivers'][0]['pid']==65640 and a['drivers'][0]['action']=='force_killed' and a['drivers'][0]['exit_code']==1
empty=json.loads((roots['empty-lock-direct2']/'result.json').read_bytes());assert empty['actual_cli_calls']==2 and empty['actual_driver_calls']==1 and empty['force_terminated'] and empty['driver_exit_code']==1 and empty['lock_after_byte_length']==0
calls=json.loads((roots['empty-lock-direct2']/'ordinary-cli-observations.json').read_bytes());assert len(calls)==2 and all(c['exit_code']==0 and c['driver_still_alive'] for c in calls)
for c,stream_name in zip(calls,['status','pause']):
 for stream in ['stdout','stderr']:assert digest(roots['empty-lock-direct2']/f'{stream_name}.{stream}.bin')['sha256']==c[f'{stream}_sha256']
live=json.loads((roots['live-lock-direct4']/'readback-actual.json').read_bytes());assert live['status']=='passed' and live['whole_product_before_after_equal'] and live['same_lock_identity'] and len(live['calls'])==4 and all(c['exit_code']==0 for c in live['calls'])
assert live['driver']['action']=='released' and live['driver']['exit_code']==0 and live['driver']['pid']==63688
for c in live['calls']:
 for stream in ['stdout','stderr']:assert digest(roots['live-lock-direct4']/f"{c['label']}.{stream}.bin")==c[stream]
assert live['actual_live_lock']['metadata_size']==0 and not live['actual_live_lock']['python_read_observation']['read_succeeded']
f=roots['focused36'];fr=json.loads((f/'result.json').read_bytes());assert fr['status']=='passed' and fr['exit_code']==0 and fr['source_before_after_equal'];b=json.loads((f/'source-before.json').read_bytes());assert b==json.loads((f/'source-after.json').read_bytes())
for name,pin in b.items():assert digest(f/'source-copy'/name)==pin==digest(ROOT/name)
raw=(f/'stderr.bin').read_text();r=re.findall(r'^(test_.*) \.\.\. (ok|ERROR|FAIL|skipped.*)$',raw,re.M);assert len(r)==len(set(n for n,v in r))==36 and sum(v=='ok' for n,v in r)==35 and sum(v.startswith('skipped') for n,v in r)==1 and 'OK (skipped=1)' in raw
for key,root in roots.items():
 for p in sorted(root.rglob('*')):
  n=key+'/'+str(p.relative_to(root))
  if p.is_symlink():links.append({'path':n,'original_path':str(p),'target':str(p.readlink()),'not_followed':True});continue
  if p.is_file():selected[n]=p
for p in sorted(BASE.iterdir()):
 if p.is_file():selected['independent-review/'+p.name]=p
for ext in ['.stdout.bin','.stderr.bin']:selected['independent-review/audit'+ext]=Path(str(BASE)+ext)
for p in (ROOT/'.artifacts/b07-t01-empty-lock-source-before-20261107').iterdir():
 if p.is_file():selected['old-public-checker-originals/'+p.name]=p
body=NATIVE/'b07-t01-native-final-evidence-06-20261107';selected['peer-body/manifest.json']=body/'manifest.json'
scope=ROOT/'.artifacts/b07-t01-closeout-draft-20261107/python-discovery-engine-scope-06.json';selected['full-python-engine-history/python-discovery-engine-scope-06.json']=scope
metadata={'native06_program_and_build_body_archive':digest(body/'originals.zip'),'native06_program_and_build_body_original_path':str(body/'originals.zip'),'complete_body_in_this_review_zip':False,'first_matrix06':{'status':'failed','CLI':121,'driver':1,'error':'PermissionError on reading actual empty NTFS worker.lock; actual driver killed and waited','separate_race_postcheck_error':'selected input root identity differs; original race driver exit0 is not treated as passed independent postcheck'},'empty_lock_direct2':empty,'live_lock_direct4':{'status':'passed_readonly_postcheck','CLI':4,'released_driver_PID':63688,'driver_exit':0,'whole_product_before_after_equal':True,'same_lock_identity':True,'first_postcheck_fixture_path_failure_preserved':True},'focused36':{'tests':36,'pass':35,'skip':1,'source_two_before_after_equal':True,'test_PID':fr['pid'],'temporary_product_per_CLI_raw_not_retained':True},'owned_processes_closed_confirmation':'review_scan_tools explicit current collaboration confirmation for all four roots; rust audit owns live-lock released-driver confirmation; no additional OS process probe fabricated','public_files_mutated':False,'real_model_calls':0,'new_matrix_final07_scope':'separate final archive by checker agent; not counted into historical121'}
(OUT/'historical-observed.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf8');selected['historical-observed.json']=OUT/'historical-observed.json'
readme="""# B07-T01 Native06独立原件与Windows零字节锁范围复核

本包为独立review及历史补充。完整Native06两PE本体/top raw/build/source ZIP/runtime探针已在peer 7267b68c ZIP，本包不重复该body；独立审计已逐107成员CRC/SHA/长度与真实原文件before/after复读，nested source ZIP全部2005成员（2002repo源码+snapshot/subset/runner三aux）精确读回；单derived schema在body独立member且等pinned desktop schema。

Native06原Rust23suite=756通过/0失败/0忽略；四真实raw sharing violation mode0/1 Applied、2/3 Blocked；17命令源/derived/sentinel全等且exit0。26294 registry展开文件与446 crate archive记录前后整对象相等。当前125编译源和1864保守依赖逐byte仍等该构建原件；当前2002完整源码精确只两份Python变化，明确不声称全部2002当前相等。Native06 fullPython437=429通过/8跳过属旧35检查器/单PowerShell引擎，root比较原件指出39个额外pwsh测试未在这一轮discovery；不推成最新36或所有引擎验收。

首Native06matrix实际121CLI+1driver后因Python试图读取真实NTFS强制锁住的0B worker.lock而PermissionError。helddriver65640真实TerminateProcess/wait退出1。原独立race driver41632退出0，但wrapper的fixture路径后验失败原件仍保留，不算独立race passed。该矩阵不是完整通过，所有原失败/DB/源/CLI/driver raw完整保留。

额外direct2CLI status/pause均在真实helddriver26260仍活跃时exit0；锁0B同ID，实际强制终止并wait退出1。另direct4CLI live-status/live-pause/released→paused-status/same-run-resume均exit0，driver63688真实release并exit0；同Run6确认/唯一发布及完整author/SQL/tree只读后验通过。第一次后验误用fixture路径失败及后续readback原件分开保留。

新版2a247639检查器/3c414d77测试的36focused在实际Windows为35通过/1symlink跳过，源两件before/after逐字等。源码精确归一证明：移除两个Win0B metadata/copy helper并还原两个调用点，新checker整文件等旧87cb；移除唯一新增NTFS test，新tests整文件等旧18d。源派生、SQL、Owner、状态/检查点及非空读取判据原字节未变。0B通过普通非reparse、单link、前后lstat size/mtime/身份和WinID重查证明空字节；Linux及所有非空仍沿用普通读取/copy失败。新真实NTFS test同时证明0B被锁仍能inventory/copy、1B锁时两路径均PermissionError。没有发现阻断性新问题。

绿色focused成功临时目录已清理，本包只提供unit原raw和冻结源码断言，不冒称逐CLI raw或临时DB完整留存；矩阵/direct诊断owned roots完整保留，符号链接只记录target不跟随。所有进程终态由原进程拥有者明确确认，不伪造新OS进程raw。本包不包含最终Current36双平台matrix，那些由checker另归档，不推为科学/生产Vault/24小时或跨平台迁移通过。所有写入只在.artifacts。
"""
(OUT/'README.md').write_text(readme,encoding='utf8');selected['README.md']=OUT/'README.md';selected['observer/package.py']=Path(__file__)
rows={};archive=OUT/'originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in selected.items():
  st=stamp(p);z.write(p,n);assert stamp(p)==st;rows[n]={'original_path':str(p),'original_capture':st,'sha256':st['sha256'],'byte_length':st['byte_length']}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(rows)
 for n,r in rows.items():
  bb=z.read(n);assert {'sha256':hashlib.sha256(bb).hexdigest(),'byte_length':len(bb)}=={'sha256':r['sha256'],'byte_length':r['byte_length']};assert stamp(Path(r['original_path']))==r['original_capture'];r['archive_crc32']=z.getinfo(n).CRC
m={'producer':'independent_native06_current36_scope_originals_archive','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':digest(archive),'member_count':len(rows),'all_CRC_SHA_length_readback_passed':True,'all_original_read_namespace_ID_mtime_bytes_before_after_equal':True,'files':rows,'symlinks_not_followed':links,**metadata}
(OUT/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'archive':m['archive'],'manifest':digest(OUT/'manifest.json'),'members':len(rows),'firstmatrixCLI':121,'directCLI':6,'focusedtests':36},ensure_ascii=False),flush=True)
