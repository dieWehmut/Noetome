from pathlib import Path,PureWindowsPath
import hashlib,json,zipfile,re,stat,datetime,difflib
ROOT=Path('/home/lyinn/project/Noetome');BASE=Path(__file__).resolve().parent
NATIVE=Path('/mnt/d/Noetome/.artifacts/b07-t01-windows-final-06-20261107');BODY=NATIVE.parent/'b07-t01-native-final-evidence-06-20261107'
def pin(b):return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
def digest(p):return pin(p.read_bytes())
def stamp(p):
 s=p.stat();return {**digest(p),'device':s.st_dev,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
def save(p,x):assert not p.exists();p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
m=json.loads((BODY/'manifest.json').read_bytes());assert digest(BODY/'originals.zip')==m['archive']
archive_rows={}
with zipfile.ZipFile(BODY/'originals.zip') as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==107 and set(z.namelist())==set(m['files'])
 for n,r in m['files'].items():
  original=NATIVE/n if n!='declared-assets/windows-schema.json' else NATIVE/'repo/crates/noetome-desktop/gen/schemas/windows-schema.json'
  before=stamp(original);b=z.read(n);assert pin(b)==r==digest(original);assert stamp(original)==before
  archive_rows[n]={'crc32':z.getinfo(n).CRC,'pin':r,'original_path':str(original),'original_read_namespace_capture':before,'original_before_after_equal':True}
a=json.loads((NATIVE/'native-final.json').read_bytes());assert a['status']=='passed' and a['source_count']==2002
snapshot=json.loads((NATIVE/'snapshot.json').read_bytes())['files'];after=json.loads((NATIVE/'source-after.json').read_bytes());work_after=json.loads((NATIVE/'worktree-after.json').read_bytes());assert snapshot==after==work_after and len(snapshot)==2002
ziprows={}
with zipfile.ZipFile(NATIVE/'source-originals.zip') as z:
 assert digest(NATIVE/'source-originals.zip')==a['source_archive'] and z.testzip() is None and len(z.namelist())==2005 and len(set(z.namelist()))==2005
 assert set(z.namelist())=={'repo/'+n for n in snapshot}|{'snapshot.json','rust-dependency-subset.json','runner.py'}
 for n in z.namelist():
  b=z.read(n);original=NATIVE/n;expected=snapshot[n[5:]] if n.startswith('repo/') else digest(original)
  assert pin(b)==expected==digest(original);ziprows[n]={'crc32':z.getinfo(n).CRC,**expected}
source_current_diff={}
for n,r in snapshot.items():
 current=digest(ROOT/n)
 if current!=r:source_current_diff[n]={'native06':r,'current':current}
assert set(source_current_diff)=={'scripts/verify_run_checkpoint.py','tests/test_verify_run_checkpoint.py'}
subset=json.loads((NATIVE/'rust-dependency-subset.json').read_bytes())['files'];core125=json.loads((ROOT/'.artifacts/b07-t01-linux-build-05-20261107/source-before.json').read_bytes())
assert len(subset)==1864 and len(core125)==125
for n,r in subset.items():assert r==snapshot[n]==digest(ROOT/n)
for n,r in core125.items():assert {'sha256':r['sha256'],'byte_length':r['byte_length']}==snapshot[n]==digest(ROOT/n)
assets=json.loads((NATIVE/'declared-build-assets.json').read_bytes());assert len(assets)==1
for n,r in assets.items():assert digest(NATIVE/'repo'/n)==r['pin']==snapshot[r['derived_from']]
reg_before=json.loads((NATIVE/'registry-before.json').read_bytes());reg_after=json.loads((NATIVE/'registry-after.json').read_bytes());assert reg_before==reg_after and len(reg_before['files'])==26294 and len(reg_before['archives'])==446
summary=[list(map(int,t)) for t in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (NATIVE/'workspace-tests.stdout.bin').read_text())]
assert summary==a['rust_summaries'] and len(summary)==23 and sum(x[0] for x in summary)==756 and all(x[1:]==[0,0] for x in summary)
raw_guard=re.findall(r'Observed live raw sharing violation; mode=(\d), outcome=(\w+)',(NATIVE/'workspace-tests.stderr.bin').read_text());assert sorted(raw_guard)==[('0','Applied'),('1','Applied'),('2','Blocked'),('3','Blocked')]
raw=(NATIVE/'full-python.stderr.bin').read_text();rows=re.findall(r'^(test_.*) \.\.\. (ok|ERROR|FAIL|skipped.*)$',raw,re.M)
assert len(rows)==len(set(n for n,v in rows))==437 and sum(v=='ok' for n,v in rows)==429 and sum(v.startswith('skipped') for n,v in rows)==8 and 'OK (skipped=8)' in raw
assert a['python_tests_run']==437
for c in a['commands']:
 assert c['exit_code']==0 and not c['timed_out'] and c['source_before_after_equal'] and c['declared_build_assets_equal'] and c['external_sentinel_before_after_equal']
 for stream in ['stdout','stderr']:
  row=c[stream];p=NATIVE/PureWindowsPath(row['path']).name;assert digest(p)=={'sha256':row['sha256'],'byte_length':row['byte_length']}
assert len(a['commands'])==17
outer=json.loads((NATIVE/'outer-native-result.json').read_bytes());assert outer['exit_code']==0 and outer['worktree_before_after_equal']
selected=json.loads((NATIVE/'selected-build-receipt.json').read_bytes());assert selected['actual_compiler_fingerprint']==a['actual_cli_and_driver_compiler_fingerprint']=='03b1674c9739fe39581d0736784b28f51582f58749801eba778df917f94eb52e'
for n,r in a['selected_executables'].items():assert digest(NATIVE/'selected'/n)==r
scope_path=ROOT/'.artifacts/b07-t01-closeout-draft-20261107/python-discovery-engine-scope-06.json';scope=json.loads(scope_path.read_bytes());assert scope['old_rows']==441 and scope['new_rows']==437 and len(scope['missing'])==39 and len(scope['added'])==35
new_source={};old_source={}
for name,new in [('verify_run_checkpoint.py',ROOT/'scripts/verify_run_checkpoint.py'),('test_verify_run_checkpoint.py',ROOT/'tests/test_verify_run_checkpoint.py')]:
 old=ROOT/'.artifacts/b07-t01-empty-lock-source-before-20261107'/name
 old_source[name]=digest(old);new_source[name]=digest(new);(BASE/('old-'+name)).write_bytes(old.read_bytes());(BASE/('new-'+name)).write_bytes(new.read_bytes());(BASE/(name+'.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='old/'+name,tofile='new/'+name)),encoding='utf8')
old=(BASE/'old-verify_run_checkpoint.py').read_bytes();new=(BASE/'new-verify_run_checkpoint.py').read_bytes()
start=new.index(b'\n\ndef read_observed_file(');end=new.index(b'\n\ndef canonical_selected_path(',start);normalized=new[:start]+new[end:]
normalized=normalized.replace(b'sha256=sha(read_observed_file(path, info))',b'sha256=sha(path.read_bytes())',1).replace(b'symlinks=True, copy_function=copy_observed_file)',b'symlinks=True)',1);assert normalized==old
old_test=(BASE/'old-test_verify_run_checkpoint.py').read_bytes();new_test=(BASE/'new-test_verify_run_checkpoint.py').read_bytes();start=new_test.index(b'    @unittest.skipUnless(os.name == "nt", "actual Windows mandatory empty/nonempty range locks require NTFS")');end=new_test.index(b'    def test_actual_unicode_space_database_uri_preserves_identity_query_and_readonly',start);assert new_test[:start]+new_test[end:]==old_test
report={'producer':'independent_native06_and_checker36_exact_source_audit','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'peer_body_archive':digest(BODY/'originals.zip'),'peer_body_manifest':digest(BODY/'manifest.json'),'peer107_all_CRC_SHA_length_original_before_after':True,'body_members':archive_rows,'source_archive':a['source_archive'],'source_zip_members':ziprows,'source_zip_count':2005,'actual_repo_source_count':2002,'derived_asset_count':1,'source06_before_after_equal':True,'current2002_differences_exactly_two_python':source_current_diff,'current_core125_exact_equal_native06':True,'current_conservative_rust1864_exact_equal_native06':True,'core125_subset_of_1864':set(core125)<=set(subset),'all2002_current_equal':False,'registry26294_files_446_archives_before_after_equal':True,'rust23suite':summary,'rust_actual_passed':756,'rust_actual_failed':0,'rawcache_guard_observations':raw_guard,'actual17_native_commands_all_exit0_source_asset_sentinel_equal':True,'full_python_old35_scope':{'run':437,'pass':429,'skip':8,'missing_secondary_pwsh_tests':39,'scope_comparison':digest(scope_path),'final36_or_all_engines_claim':False},'selected_programs':a['selected_executables'],'actual_compiler_fingerprint':selected['actual_compiler_fingerprint'],'checker_old_source':old_source,'checker_new_source':new_source,'whole_old_checker_restored_exactly_by_removing_only_two_helpers_and_two_inventory_copy_call_changes':True,'whole_old_test_restored_exactly_by_removing_one_new_NTFS_test':True,'all_other_SQL_Owner_source_state_semantics_byte_equal':True,'linux_inventory_nonempty_windows_reads_copy_paths_original':True,'runtime_body_recompressed':False,'real_model_calls':0,'public_source_changed_by_this_audit':False}
save(BASE/'native06-independent-readback.json',report)
print(json.dumps({'body_members':107,'source_zip_members':2005,'repo_source':2002,'current_allowed_diff':list(source_current_diff),'rust':756,'native_old_py':437,'core125_equal':True,'rust1864_equal':True,'whole_delta_exact':True},ensure_ascii=False),flush=True)
