from pathlib import Path
import sys, subprocess, json, time, platform, shutil, threading
BASE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-matrix-final-06-20261107")
NATIVE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107")
REPO=NATIVE/"repo"
sys.path.insert(0,str(REPO/"scripts"));import verify_run_checkpoint as a
cli=NATIVE/"selected/noetome.exe";driver=NATIVE/"selected/noetome-cli-testdriver.exe"
previous=Path(r"D:\Noetome\.artifacts\b07-t01-windows-final-04-20261107\selected\noetome.exe")
expected={"cli":"7acd2ea0cad8c852dc6b147925bfff7d063387d2db274d23f5d7648eba4a2830","driver":"95fc2905a901b64095e4eb661c18bc5e1f89e92bdf1ea01c12cd295a8040e725","previous":"ee5dde731f73d506a9f9a4c61136067446d2da111e5cad3b450f1b9537bb25b0","scripts/verify_run_checkpoint.py":"87cb1580d26ca216061a9ef129ff92904958c099866d7811f9bcb79139b936da","tests/test_verify_run_checkpoint.py":"18d67c31a95ce4f9c30182b9968e93da39e447878f1b19d47e72bde38a698cb3"}
paths={"cli":cli,"driver":driver,"previous":previous,**{n:REPO/n for n in expected if "/" in n}}
before={n:{"sha256":a.sha(p.read_bytes()),"byte_length":p.stat().st_size} for n,p in paths.items()};a.require(all(before[n]["sha256"]==expected[n] for n in expected),"fixed native source/runtime changed")
a.save_json(BASE/"selected-before.json",before);shutil.copyfile(NATIVE/"selected-build-receipt.json",BASE/"selected-build-receipt.json")
a.save_json(BASE/"platform.json",{"python":sys.version,"executable":sys.executable,"platform":platform.platform(),"pid":__import__('os').getpid(),"public_command_normal_drive_paths":True,"source_snapshot":str(NATIVE/"snapshot.json"),"selected_build_receipt_sha256":a.sha((NATIVE/"selected-build-receipt.json").read_bytes()),"real_model_calls":0})
pack=REPO/"fixtures/run-checkpoint-v1";a.frozen_pack_check(pack,"240cf6bf13c082c24c93d92ab47a5e76cadb799beb4fe162d2665e9fbc12ccd1")
argv=[sys.executable,"-X","utf8",str(REPO/"scripts/verify_run_checkpoint.py"),"--cli",str(cli),"--test-driver",str(driver),"--previous-cli",str(previous),"--root",str(BASE/"matrix"),"--author-pack",str(pack),"--fixture-sha256","240cf6bf13c082c24c93d92ab47a5e76cadb799beb4fe162d2665e9fbc12ccd1"]
t=time.time_ns();p=subprocess.Popen(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=a.clean_environment());a.save_json(BASE/"running.json",{"argv":argv,"pid":p.pid,"started_ns":t,"real_model_calls":0})
race_errors=[]
def race():
 try:
  rdir=BASE/"race";rdir.mkdir();owned=rdir/"actual-race";env=a.clean_environment();env["NOETOME_RUN_RACE_TEST_ROOT"]=str(owned)
  args=[str(driver),"--exact","fixture_run::tests::control_request_rechecks_terminal_under_sqlite_writer_lock","--nocapture","--test-threads=1"]
  started=time.time_ns();q=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);stdout,stderr=q.communicate(timeout=120)
  (rdir/"stdout.bin").write_bytes(stdout);(rdir/"stderr.bin").write_bytes(stderr);a.save_json(rdir/"driver-receipt.json",{"argv":args,"pid":q.pid,"started_ns":started,"finished_ns":time.time_ns(),"exit_code":q.returncode,"driver_sha256":before["driver"]["sha256"],"stdout_sha256":a.sha(stdout),"stderr_sha256":a.sha(stderr),"explicit_test_environment":{"NOETOME_RUN_RACE_TEST_ROOT":str(owned)},"real_model_calls":0});a.require(q.returncode==0,"actual native transaction race test failed")
  raw=a.read_json(owned/"actual-race.json");a.require(raw["database_unchanged"] and raw["controls"]==[0,None] and raw["controller_result"]=={"Err":"RUN_TERMINAL"},"native race altered terminal database")
  fixture=a.canonical_selected_path(owned/"fixture");run=a.canonical_selected_path(owned/"run");r=a.Recorder(rdir/"independent-cli",cli,fixture);original=a.inventory(run)
  for op in ("status","resume"):
   value,_=r.command(("run",op,run) if op=="status" else ("run",op,fixture,run),label="independent native terminal race "+op);a.verify_finished(r,a.canonical_selected_path(pack),run,value,raw["worker_result"]["run_id"]);a.require(a.inventory(run)==original,"native terminal race followup modified original")
  r.finish({"status":"passed","producer":"independent_native_transaction_race_followup","actual_race_sha256":a.sha((owned/"actual-race.json").read_bytes()),"driver_receipt_sha256":a.sha((rdir/"driver-receipt.json").read_bytes())})
 except Exception as error:
  race_errors.append(str(error));a.save_json(BASE/"race-failure.json",{"status":"failed","error":str(error),"real_model_calls":0})
race_thread=threading.Thread(target=race);race_thread.start()
try:stdout,stderr=p.communicate(timeout=1200)
except subprocess.TimeoutExpired:
 p.kill();stdout,stderr=p.communicate();(BASE/"stdout.bin").write_bytes(stdout);(BASE/"stderr.bin").write_bytes(stderr);raise
(BASE/"stdout.bin").write_bytes(stdout);(BASE/"stderr.bin").write_bytes(stderr);race_thread.join(timeout=180);a.require(not race_thread.is_alive(),"race followup still running")
after={n:{"sha256":a.sha(path.read_bytes()),"byte_length":path.stat().st_size} for n,path in paths.items()};a.save_json(BASE/"selected-after.json",after)
a.save_json(BASE/"result.json",{"status":"passed" if p.returncode==0 and not race_errors else "failed","argv":argv,"pid":p.pid,"exit_code":p.returncode,"started_ns":t,"finished_ns":time.time_ns(),"stdout_sha256":a.sha(stdout),"stderr_sha256":a.sha(stderr),"selected_before_after_equal":before==after,"race_errors":race_errors,"scope":"current Native06 public complete bounded Run matrix and separate actual transaction race; POSIX permission not_run on Windows","real_model_calls":0})
a.require(before==after,"fixed native source/runtime changed");print(json.dumps({"status":"passed" if p.returncode==0 and not race_errors else "failed","pid":p.pid,"exit_code":p.returncode,"race_errors":race_errors,"base":str(BASE)}));sys.exit(p.returncode if p.returncode else (1 if race_errors else 0))
