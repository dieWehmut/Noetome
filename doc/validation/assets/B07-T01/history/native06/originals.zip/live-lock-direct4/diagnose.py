from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, time, traceback, types

BASE=Path(__file__).parent
NATIVE=Path(r'D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107')
CLI=NATIVE/'selected/noetome.exe'
DRIVER=NATIVE/'selected/noetome-cli-testdriver.exe'
sys.path.insert(0,str(NATIVE/'repo/scripts'))
spec=importlib.util.spec_from_file_location('frozen_checker',NATIVE/'repo/scripts/verify_run_checkpoint.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
fixture=NATIVE/'repo/fixtures/run-checkpoint-v1/fixture'
root=BASE/'run'
def pin(path):
    raw=Path(path).read_bytes();return {'sha256':hashlib.sha256(raw).hexdigest(),'byte_length':len(raw)}
before={str(p):pin(p) for p in (CLI,DRIVER,NATIVE/'repo/scripts/verify_run_checkpoint.py')}
calls=[];held=None
recorder=types.SimpleNamespace(root=BASE,fixture=fixture,driver_calls=[])
def command(label,args):
    argv=[str(CLI),*map(str,args)]
    started=time.monotonic();p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=checker.clean_environment())
    out,err=p.communicate(timeout=30)
    (BASE/(label+'.stdout.bin')).write_bytes(out);(BASE/(label+'.stderr.bin')).write_bytes(err)
    row={'label':label,'argv':argv,'pid':p.pid,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':pin(BASE/(label+'.stdout.bin')),'stderr':pin(BASE/(label+'.stderr.bin'))}
    calls.append(row);(BASE/'commands.json').write_text(json.dumps(calls,ensure_ascii=False,indent=2))
    assert p.returncode==0,err.decode('utf8','replace')
    return json.loads(out)
try:
    held=checker.HeldDriver(recorder,DRIVER,'fixture_run::tests::checkpoint_child',root,'unit_progress','render',1)
    lock=root/'control/worker.lock';info=lock.stat();lock_id=checker.actual_identity(lock)
    assert info.st_size==0 and info.st_nlink==1 and held.process.poll() is None
    try:
        raw=lock.read_bytes()
        lock_read={'read_succeeded':True,'byte_length':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    except PermissionError as error:
        lock_read={'read_succeeded':False,'error_type':type(error).__name__,'errno':error.errno,'winerror':getattr(error,'winerror',None),'message':str(error)}
    (BASE/'held-lock-observation.json').write_text(json.dumps({'handshake':held.handshake,'pid_alive':held.process.poll() is None,'metadata_size':info.st_size,'metadata_links':info.st_nlink,'actual_identity':lock_id,'python_read_observation':lock_read},ensure_ascii=False,indent=2))
    status=command('live-status',['run','status',root])
    assert status['run_status']=='running' and status['confirmed_units']==1 and held.process.poll() is None
    pause=command('live-pause',['run','pause',root])
    assert pause['run_status']=='running' and pause['controls']['acknowledged_sequence']==0 and calls[-1]['elapsed_seconds']<=2 and held.process.poll() is None
    assert status['run_id']==pause['run_id']==held.handshake['run_id'] and checker.actual_identity(lock)==lock_id and lock.stat().st_size==0
    held.release()
    paused=command('paused-status',['run','status',root])
    assert paused['run_status']=='paused' and paused['confirmed_units']==2 and paused['controls']['acknowledged_sequence']==1
    resumed=command('same-run-resume',['run','resume',fixture,root])
    assert resumed['run_status']=='succeeded' and resumed['confirmed_units']==6 and resumed['release_status']=='published' and resumed['run_id']==status['run_id']
    fake=types.SimpleNamespace(fixture=checker.canonical_selected_path(fixture))
    independently=checker.verify_finished(fake,NATIVE/'repo/fixtures/run-checkpoint-v1',checker.canonical_selected_path(root),resumed,status['run_id'])
    assert all(n==1 for n in independently['attempts'].values()) and checker.actual_identity(lock)==lock_id
    after={p:pin(p) for p in map(Path,before)}
    assert before=={str(k):v for k,v in after.items()}
    result={'status':'passed','producer':'independent_native_live_empty_lock_diagnostic','platform':sys.platform,'cli':pin(CLI),'driver':pin(DRIVER),'compiler_fingerprint':held.handshake['compiler_fingerprint'],'snapshot':pin(NATIVE/'snapshot.json'),'selected_build_receipt':pin(NATIVE/'selected-build-receipt.json'),'python_locked_empty_read':lock_read,'same_empty_lock_identity':True,'live_actual_status_and_pause_succeeded':True,'pause_actual_seconds':calls[1]['elapsed_seconds'],'after_release_paused_confirmed_units':2,'ordinary_resume_same_run_succeeded':True,'independent_finished':independently,'calls':calls,'drivers':recorder.driver_calls,'selected_source_before_after_equal':True,'scope':'selected06 PE and matching actual living driver; metadata/identity only for the genuinely locked empty file; no public code modifications','real_model_calls':0,'paid_calls':0}
    (BASE/'actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'passed','cli_count':len(calls),'live_lock_read':lock_read,'pause_seconds':calls[1]['elapsed_seconds']}))
except BaseException as error:
    if held is not None and held.process.poll() is None:held.force_stop()
    (BASE/'failure.json').write_text(json.dumps({'status':'failed','error_type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'calls':calls,'drivers':recorder.driver_calls},ensure_ascii=False,indent=2)+'\n')
    raise
