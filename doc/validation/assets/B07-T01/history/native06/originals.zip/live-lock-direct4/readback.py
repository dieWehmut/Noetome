from pathlib import Path
import hashlib,importlib.util,json,sys,types
B=Path(__file__).parent;N=Path(r'D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107')
sys.path.insert(0,str(N/'repo/scripts'))
s=importlib.util.spec_from_file_location('frozen_checker',N/'repo/scripts/verify_run_checkpoint.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def pin(p):
 r=Path(p).read_bytes();return {'sha256':hashlib.sha256(r).hexdigest(),'byte_length':len(r)}
root=c.canonical_selected_path(B/'run')
owner=c.read_json(root/'control/owner.json')
fixture=N/'repo/fixtures/run-checkpoint-v1/fixture'
assert owner['case_root']==str(fixture) and owner['case_identity']==c.actual_identity(fixture)
before=c.inventory(root)
out=c.read_json(B/'same-run-resume.stdout.bin')
checked=c.verify_finished(types.SimpleNamespace(fixture=fixture),N/'repo/fixtures/run-checkpoint-v1',root,out,owner['run_id'])
assert c.inventory(root)==before and all(v==1 for v in checked['attempts'].values())
calls=c.read_json(B/'commands.json');held=c.read_json(B/'held-lock-observation.json');driver=c.read_json(B/'drivers/001/receipt.json')
assert len(calls)==4 and all(x['exit_code']==0 for x in calls) and driver['exit_code']==0 and driver['action']=='released'
assert held['pid_alive'] and not held['python_read_observation']['read_succeeded'] and held['metadata_size']==0
assert c.actual_identity(root/'control/worker.lock')==held['actual_identity'] and (root/'control/worker.lock').stat().st_size==0
result={'producer':'native_live_empty_lock_postcheck','status':'passed','scope':'read-only independent author/SQLite/product readback of existing 4 CLI and 1 released-driver original; first postcheck case-path assumption failure retained, no new CLI or model calls','first_script_failure':pin(B/'failure.json'),'selected_build_receipt':pin(N/'selected-build-receipt.json'),'snapshot':pin(N/'snapshot.json'),'selected_cli':pin(N/'selected/noetome.exe'),'selected_driver':pin(N/'selected/noetome-cli-testdriver.exe'),'actual_live_lock':held,'calls':calls,'driver':driver,'independent_finished':checked,'whole_product_before_after_equal':True,'same_lock_identity':True}
(B/'readback-actual.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'passed','cli_count':4,'released_driver_count':1,'all_attempts_one':True,'actual_lock_permission_error':True}))
