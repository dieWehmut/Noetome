from pathlib import Path
import sys,subprocess,json,time,hashlib,os
BASE=Path(r"D:\Noetome\.artifacts\b07-t01-windows-empty-lock-focused-03-20261107")
REPO=BASE/"source-copy"
sys.path.insert(0,str(REPO/"scripts"));import verify_run_checkpoint as a
paths=("scripts/verify_run_checkpoint.py","tests/test_verify_run_checkpoint.py")
before={n:{"sha256":a.sha((REPO/n).read_bytes()),"byte_length":(REPO/n).stat().st_size} for n in paths};a.save_json(BASE/"source-before.json",before)
env=a.clean_environment();env["NOETOME_TEST_BINARY"]=r"D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107\selected\noetome.exe"
argv=[sys.executable,"-X","utf8","-m","unittest","discover","-s","tests","-p","test_verify_run_checkpoint.py","-v"]
t=time.time_ns();p=subprocess.Popen(argv,cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);pid=p.pid
stdout,stderr=p.communicate(timeout=180);(BASE/"stdout.bin").write_bytes(stdout);(BASE/"stderr.bin").write_bytes(stderr)
after={n:{"sha256":a.sha((REPO/n).read_bytes()),"byte_length":(REPO/n).stat().st_size} for n in paths};a.save_json(BASE/"source-after.json",after)
a.save_json(BASE/"result.json",{"status":"passed" if p.returncode==0 else "failed","pid":pid,"exit_code":p.returncode,"argv":argv,"started_ns":t,"finished_ns":time.time_ns(),"source_before_after_equal":before==after,"python":sys.version,"stdout_sha256":a.sha(stdout),"stderr_sha256":a.sha(stderr),"scope":"actual Windows focused tests and three ordinary native CLI main probes plus actual 0B/nonempty mandatory lock test; selected source-bound Native06 PE","real_model_calls":0})
print(stderr.decode("utf-8",errors="replace")[-1600:]);print(json.dumps({"exit_code":p.returncode,"sources":after}));sys.exit(p.returncode)
