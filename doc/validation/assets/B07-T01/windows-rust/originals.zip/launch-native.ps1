$ErrorActionPreference='Stop'
$env:PSExecutionPolicyPreference='Bypass'
& 'D:\Noetome\.artifacts\b03-t02-python312\Scripts\python.exe' -X utf8 'D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107\runner.py' run --base 'D:\Noetome\.artifacts\b07-t01-windows-final-06-20261107' --snapshot-sha256 'a572deb5902c617766fd0d558b2097c91e63e67779d98f5ea817b768dd9a9903'
exit $LASTEXITCODE
