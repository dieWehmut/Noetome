# 有界来源知识核对

状态：failed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-decision-excluded",
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
      "import_id": "1bb73cfc-536c-4738-8edd-c868c2e34ff3",
      "source_id": "79cc2bda-1bbc-4161-bea3-6a0f1425da74",
      "version_id": "284b31a4-8fbe-455d-b380-5f6f9419b418",
      "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "6f05424f-d880-4d89-9eea-a10c4580250f",
          "ordinal": 0,
          "resource_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 195,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。\n这是独立作者的工程例外测试，不是科学质量基准。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
    "import_id": "1bb73cfc-536c-4738-8edd-c868c2e34ff3",
    "source_id": "79cc2bda-1bbc-4161-bea3-6a0f1425da74",
    "version_id": "284b31a4-8fbe-455d-b380-5f6f9419b418",
    "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "2c2428ec72b95f7ba9178c07a68082fbc46943e6d3be197ab7cc535dcffbba9d",
        "byte_length": 2831
      },
      "decision.json": {
        "sha256": "2e3213c63ce538640eebeba3b9cbd37921d84a6f84b6cd0e74fa00cb81d3442c",
        "byte_length": 161
      },
      "gold.json": {
        "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
        "byte_length": 704
      },
      "review.json": {
        "sha256": "acae59cea8be9488a4587417060cd694866663d0acf150ea6d708f8e4e09efd2",
        "byte_length": 547
      }
    },
    "gold_sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "issue_codes": [
        "VERIFY_EXCLUSION"
      ]
    }
  ],
  "candidate_results": [
    {
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_EXCLUSION",
      "expected": "included",
      "actual": "excluded"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "atom-speed"
        ],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "excluded",
          "exclusion_reason": "author fact omitted",
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "import_id": "1bb73cfc-536c-4738-8edd-c868c2e34ff3",
          "manifest_sha256": null,
          "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "parse_id": null,
          "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
          "source_id": "79cc2bda-1bbc-4161-bea3-6a0f1425da74",
          "version_id": "284b31a4-8fbe-455d-b380-5f6f9419b418"
        },
        "request_id": "synthetic-decision-excluded"
      },
      "actual": {
        "binding": {
          "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "import_id": "1bb73cfc-536c-4738-8edd-c868c2e34ff3",
          "manifest_sha256": null,
          "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "parse_id": null,
          "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
          "source_id": "79cc2bda-1bbc-4161-bea3-6a0f1425da74",
          "version_id": "284b31a4-8fbe-455d-b380-5f6f9419b418"
        },
        "request_id": "synthetic-decision-excluded"
      }
    },
    {
      "category": "duplicate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "evidence-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 124,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 195,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "evidence-speed",
        "excerpt_end_byte": 124,
        "excerpt_sha256": "8787abb6f05367771604433544ea4a73b7537e8182a3c9ea0e0420cf90c461f8",
        "excerpt_start_byte": 0,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 124,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "evidence-speed",
          "excerpt_end_byte": 124,
          "excerpt_sha256": "8787abb6f05367771604433544ea4a73b7537e8182a3c9ea0e0420cf90c461f8",
          "excerpt_start_byte": 0,
          "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A 速度",
            "concept_id": "concept-speed",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [
          "在本夹具的样例 A 中"
        ],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [
          "在本夹具的样例 A 中"
        ],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 1,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "7b98ad197fa7f073a090b298801af6bf86fff7837bedd6d430342e2a621cabba",
      "byte_length": 145
    },
    "candidates-original.json": {
      "sha256": "2c2428ec72b95f7ba9178c07a68082fbc46943e6d3be197ab7cc535dcffbba9d",
      "byte_length": 2831
    },
    "decision-original.json": {
      "sha256": "2e3213c63ce538640eebeba3b9cbd37921d84a6f84b6cd0e74fa00cb81d3442c",
      "byte_length": 161
    },
    "gold-original.json": {
      "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
      "byte_length": 704
    },
    "review-original.json": {
      "sha256": "acae59cea8be9488a4587417060cd694866663d0acf150ea6d708f8e4e09efd2",
      "byte_length": 547
    },
    "source-snapshot.json": {
      "sha256": "665ed31db8e99ac7dfdcfff8f18238eaf1f4830034f0e620f6f6e7c88cb13fd4",
      "byte_length": 1085
    }
  }
}
```
