# 有界来源知识核对

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-unknown-author",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
      "import_id": "1ed3e1f7-b5c7-4e90-a8d7-56d6066bff24",
      "source_id": "be57233a-236a-4ef8-b1b2-98b31c06bcce",
      "version_id": "08706757-9ab1-46d4-b6f6-78b78bfaa74b",
      "content_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
      "normalized_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a05729e4-ee97-46e8-bb7d-9809bd0f933e",
          "ordinal": 0,
          "resource_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 120,
        "text": "在本夹具的样例 A 中，速度未知。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
    "import_id": "1ed3e1f7-b5c7-4e90-a8d7-56d6066bff24",
    "source_id": "be57233a-236a-4ef8-b1b2-98b31c06bcce",
    "version_id": "08706757-9ab1-46d4-b6f6-78b78bfaa74b",
    "content_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
    "normalized_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "2ba22522074ff9d7ba1659b13841ae1c4761b450d185ea349ad52ff6ad180e4e",
        "byte_length": 2801
      },
      "decision.json": {
        "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
        "byte_length": 144
      },
      "gold.json": {
        "sha256": "c7d64409d6b5ef78aa12e4bcd85ae377366e9a5de90f3d816da837cf15485914",
        "byte_length": 707
      },
      "review.json": {
        "sha256": "e58818fdc742d73cc3e79c9205c1f6c4635b303ffa2ab1eb934016b8d0b19d36",
        "byte_length": 547
      }
    },
    "gold_sha256": "c7d64409d6b5ef78aa12e4bcd85ae377366e9a5de90f3d816da837cf15485914"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "needs_review",
      "issue_codes": [
        "VERIFY_UNKNOWN"
      ]
    }
  ],
  "candidate_results": [
    {
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "needs_review",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "atom-speed"
        ],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
          "import_id": "1ed3e1f7-b5c7-4e90-a8d7-56d6066bff24",
          "manifest_sha256": null,
          "normalized_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
          "parse_id": null,
          "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
          "source_id": "be57233a-236a-4ef8-b1b2-98b31c06bcce",
          "version_id": "08706757-9ab1-46d4-b6f6-78b78bfaa74b"
        },
        "request_id": "synthetic-unknown-author"
      },
      "actual": {
        "binding": {
          "content_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
          "import_id": "1ed3e1f7-b5c7-4e90-a8d7-56d6066bff24",
          "manifest_sha256": null,
          "normalized_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
          "parse_id": null,
          "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
          "source_id": "be57233a-236a-4ef8-b1b2-98b31c06bcce",
          "version_id": "08706757-9ab1-46d4-b6f6-78b78bfaa74b"
        },
        "request_id": "synthetic-unknown-author"
      }
    },
    {
      "category": "duplicate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度未知，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "evidence-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 120,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "evidence-speed",
        "excerpt_end_byte": 120,
        "excerpt_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
        "excerpt_start_byte": 0,
        "quote": "在本夹具的样例 A 中，速度未知。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 120,
        "quote": "在本夹具的样例 A 中，速度未知。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "evidence-speed",
          "excerpt_end_byte": 120,
          "excerpt_sha256": "a5cc90e451d1e608815b2874b8d8512bb5bcb87fc08d96c9b0f4d8eb5a606947",
          "excerpt_start_byte": 0,
          "quote": "在本夹具的样例 A 中，速度未知。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A 速度",
            "concept_id": "concept-speed",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度未知，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度未知，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "needs_review",
      "code": "VERIFY_UNKNOWN",
      "expected": {
        "value": null,
        "value_status": "unknown"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": null,
        "value": null,
        "value_status": "unknown"
      }
    },
    {
      "category": "unit",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": null,
      "actual": {
        "measurement": null,
        "qualifiers": [
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [
          "在本夹具的样例 A 中"
        ],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 120,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [
          "在本夹具的样例 A 中"
        ],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": null
      },
      "actual": [
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 0,
    "needs_review": 1,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 1,
      "unprocessed": 0,
      "status": "needs_review"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2611d784b88de75004087a44592c7c5faa055cdba358071107494a72ad3630b8",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "2ba22522074ff9d7ba1659b13841ae1c4761b450d185ea349ad52ff6ad180e4e",
      "byte_length": 2801
    },
    "decision-original.json": {
      "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
      "byte_length": 144
    },
    "gold-original.json": {
      "sha256": "c7d64409d6b5ef78aa12e4bcd85ae377366e9a5de90f3d816da837cf15485914",
      "byte_length": 707
    },
    "review-original.json": {
      "sha256": "e58818fdc742d73cc3e79c9205c1f6c4635b303ffa2ab1eb934016b8d0b19d36",
      "byte_length": 547
    },
    "source-snapshot.json": {
      "sha256": "99e3aea14734fdf1cac1a307a20b5cabc2b0591cd98f0b2e098cfbf50eaf6316",
      "byte_length": 1008
    }
  }
}
```
