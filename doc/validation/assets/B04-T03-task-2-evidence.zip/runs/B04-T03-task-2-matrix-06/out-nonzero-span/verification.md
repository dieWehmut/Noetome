# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-nonzero-span",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 2
      }
    ],
    "binding": {
      "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
      "import_id": "975bdcfe-3931-4e9a-8458-a64bd6a718ca",
      "source_id": "10708760-806f-4d02-a223-77e8907b891d",
      "version_id": "f767808a-1d3b-450d-af2f-0ecba32100ab",
      "content_sha256": "aea82fee4fbf5670ce58dfa5bc6b9550c3335fff4c5863123ed9384f03804560",
      "normalized_sha256": "0fecefbd557cb56799eba80f81af5ae22999cc7a399cbbe5c2c118b4e67d3520",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "dcf91484-cc61-4bf2-819c-2955a8757b82",
          "ordinal": 2,
          "resource_sha256": "0fecefbd557cb56799eba80f81af5ae22999cc7a399cbbe5c2c118b4e67d3520"
        },
        "source_status": "parsed",
        "start_byte": 9,
        "end_byte": 134,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
    "import_id": "975bdcfe-3931-4e9a-8458-a64bd6a718ca",
    "source_id": "10708760-806f-4d02-a223-77e8907b891d",
    "version_id": "f767808a-1d3b-450d-af2f-0ecba32100ab",
    "content_sha256": "aea82fee4fbf5670ce58dfa5bc6b9550c3335fff4c5863123ed9384f03804560",
    "normalized_sha256": "0fecefbd557cb56799eba80f81af5ae22999cc7a399cbbe5c2c118b4e67d3520",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "d35c76c5b923149659f50132c03c6e3d10e5c92edbaba1ef3573863479fd5b56",
        "byte_length": 2821
      },
      "decision.json": {
        "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
        "byte_length": 144
      },
      "gold.json": {
        "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
        "byte_length": 704
      },
      "review.json": {
        "sha256": "5560d64368419e5d9cb9a8e8d95d2b7206346c915cf2e0e05c78e22e5223ae4d",
        "byte_length": 547
      }
    },
    "gold_sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "atom-speed"
        ],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "aea82fee4fbf5670ce58dfa5bc6b9550c3335fff4c5863123ed9384f03804560",
          "import_id": "975bdcfe-3931-4e9a-8458-a64bd6a718ca",
          "manifest_sha256": null,
          "normalized_sha256": "0fecefbd557cb56799eba80f81af5ae22999cc7a399cbbe5c2c118b4e67d3520",
          "parse_id": null,
          "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
          "source_id": "10708760-806f-4d02-a223-77e8907b891d",
          "version_id": "f767808a-1d3b-450d-af2f-0ecba32100ab"
        },
        "request_id": "synthetic-nonzero-span"
      },
      "actual": {
        "binding": {
          "content_sha256": "aea82fee4fbf5670ce58dfa5bc6b9550c3335fff4c5863123ed9384f03804560",
          "import_id": "975bdcfe-3931-4e9a-8458-a64bd6a718ca",
          "manifest_sha256": null,
          "normalized_sha256": "0fecefbd557cb56799eba80f81af5ae22999cc7a399cbbe5c2c118b4e67d3520",
          "parse_id": null,
          "project_id": "c369507e-3640-4167-ac35-467f02f23df6",
          "source_id": "10708760-806f-4d02-a223-77e8907b891d",
          "version_id": "f767808a-1d3b-450d-af2f-0ecba32100ab"
        },
        "request_id": "synthetic-nonzero-span"
      }
    },
    {
      "category": "duplicate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "evidence-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 133,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 134,
        "start_byte": 9,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "evidence-speed",
        "excerpt_end_byte": 133,
        "excerpt_sha256": "8787abb6f05367771604433544ea4a73b7537e8182a3c9ea0e0420cf90c461f8",
        "excerpt_start_byte": 9,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 133,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 9
      },
      "actual": [
        {
          "evidence_id": "evidence-speed",
          "excerpt_end_byte": 133,
          "excerpt_sha256": "8787abb6f05367771604433544ea4a73b7537e8182a3c9ea0e0420cf90c461f8",
          "excerpt_start_byte": 9,
          "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A 速度",
            "concept_id": "concept-speed",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [
          "在本夹具的样例 A 中"
        ],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 9,
      "end_byte": 134,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [
          "在本夹具的样例 A 中"
        ],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "6bd868fdc86aa3d9379a2dc3f32177f227b60de03807c3c470104c3e22b31493",
      "byte_length": 140
    },
    "candidates-original.json": {
      "sha256": "d35c76c5b923149659f50132c03c6e3d10e5c92edbaba1ef3573863479fd5b56",
      "byte_length": 2821
    },
    "decision-original.json": {
      "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
      "byte_length": 144
    },
    "gold-original.json": {
      "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
      "byte_length": 704
    },
    "knowledge-ir.json": {
      "sha256": "ea91e6bc5c5feec4ec514658e8bab8422d2ead74c10a3e53a5d5693690fc8481",
      "byte_length": 11955
    },
    "review-original.json": {
      "sha256": "5560d64368419e5d9cb9a8e8d95d2b7206346c915cf2e0e05c78e22e5223ae4d",
      "byte_length": 547
    },
    "source-snapshot.json": {
      "sha256": "a64ea631e1c52ba6c210e4aceaf2e8b1d4a9039f409e8ed6273fd9b39338fdb2",
      "byte_length": 1014
    }
  }
}
```
