# 选定扫描公式重建预览报告

状态：needs_review；预览：blocked；知识：pending；科学质量：not_run；发布：false。

识别模式：local_http_test；实际网络尝试：1。价格、Token tokenizer 和账单未知；原始 TeX 未知。

选定原扫描区域、单请求正文、实际 HTTP 原响应、已核实用量与语义核对分开保存；本地人工 HTTP 服务只验证工程契约。

```json
{
  "schema_version": 1,
  "producer": "knowledge_scan_formula",
  "scope": "selected_scan_formula_v1",
  "request_id": "daa12497-f7ad-4cc8-b3ab-f9570e7a66e0",
  "status": "needs_review",
  "preview_status": "blocked",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 1,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "scan_formula",
    "selection_id": "scan_scalar_unreadable_sign",
    "title": "单页扫描公式符号缺损",
    "source_kind": "scanned_page",
    "pdf": {
      "file": "page.pdf",
      "sha256": "ee33b3e6bf16cb972ae438c4c310757de8a85aaba4bfa206964a98a056aa3c00"
    },
    "page": {
      "file": "page.png",
      "sha256": "eb34efd27cfa1bc70bd9d274c0d9bf92eb91bf9e56997bfeb188041cddcb8097",
      "page": 1,
      "canvas": [
        800,
        1000
      ]
    },
    "region": {
      "file": "region.png",
      "sha256": "7a22e31bb437a46687f26d5264d5e31befe837fee962b6198f73db2886a8d81f",
      "bounds": [
        120,
        175,
        560,
        200
      ],
      "legibility": "unreadable"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "3c9ec361aa7fb88a84d108483db2f503b394d137888b595b4eaf83a660196443"
    }
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_scan_declaration",
    "expression": null,
    "symbols": [
      {
        "symbol": "x",
        "definition": "Reported displacement.",
        "unit": "mg"
      },
      {
        "symbol": "a",
        "definition": "Input amount.",
        "unit": "mg"
      },
      {
        "symbol": "b",
        "definition": "Positive scale.",
        "unit": "dimensionless"
      },
      {
        "symbol": "i",
        "definition": "Sample index.",
        "unit": "dimensionless"
      }
    ],
    "conditions": [
      "a_i >= 0.",
      "b_i > 0."
    ],
    "ranges": [
      "i in {1, 2}.",
      "x_i <= 0."
    ],
    "exceptions": [
      "If b_i = 0, the expression is undefined."
    ],
    "uncertainties": [
      {
        "kind": "sign",
        "description": "Missing scan material covers the sign before the fraction; that sign is unknown."
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "region_match": "passed",
    "recognition": "needs_review",
    "expression_match": "needs_review",
    "symbol_definitions": "needs_review",
    "semantic_review": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "decision": {
    "representation": null,
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": [
      "SCAN_REGION_UNREADABLE",
      "SCAN_CRITICAL_SYMBOL_UNKNOWN",
      "SCAN_SEMANTICS_UNKNOWN",
      "SCAN_RECOGNITION_UNCERTAIN",
      "SCAN_RECOGNITION_FAILED"
    ]
  },
  "recognition": {
    "schema_version": 1,
    "recognized_tex": null,
    "uncertainties": [
      {
        "kind": "sign",
        "description": "The selected critical mark is obscured; cannot transcribe it."
      }
    ]
  },
  "api": {
    "actual_model": "noetome-test-artificial-returned-model",
    "confidence": null,
    "configured_model": "noetome-test-independent-scan",
    "endpoint": "http://127.0.0.1:59606/v1/chat/completions",
    "errors": [],
    "finish_reason": "stop",
    "http_request_id": null,
    "http_status": 200,
    "provider": "openai_chat_completions",
    "request_strategy": "tangmao-vision-scan-v1",
    "response_complete": true,
    "response_id": "noetome-test-independent-response",
    "response_receipt": {
      "byte_length": 494,
      "omission_reason": null,
      "sha256": "2a9ad397ee8be440f54f1fdb977c0a4e25221bdedeed048ca22d890fa1805f75"
    },
    "service_tier": null,
    "transport_mode": "local_http_test",
    "usage": {
      "input_reserved_tokens": 8505,
      "model_tokenizer": null,
      "model_usage": {
        "input_tokens": 100,
        "output_tokens": 30,
        "total_tokens": 130
      },
      "model_usage_status": "validated",
      "network_attempts": 1,
      "paid_calls": 0,
      "price_usd": null,
      "raw_model_usage": {
        "completion_tokens": 30,
        "prompt_tokens": 100,
        "total_tokens": 130
      },
      "real_model_calls": 0,
      "request_utf8_bytes": 7481,
      "reservation_policy": "request_utf8_bytes_plus_1024_v1",
      "reserved_tokens": 16697
    }
  },
  "recognition_request_fingerprint": {
    "sha256": "c80c05bd5f940dd742746bcdf5fe609bda43a1b132d423c1b066fcdc11112821",
    "byte_length": 7481
  },
  "recognition_response_fingerprint": {
    "sha256": "2a9ad397ee8be440f54f1fdb977c0a4e25221bdedeed048ca22d890fa1805f75",
    "byte_length": 494
  },
  "tokens": null,
  "plan_fingerprint": null,
  "inputs": {
    "original.pdf": {
      "sha256": "ee33b3e6bf16cb972ae438c4c310757de8a85aaba4bfa206964a98a056aa3c00",
      "byte_length": 41073
    },
    "original.png": {
      "sha256": "7a22e31bb437a46687f26d5264d5e31befe837fee962b6198f73db2886a8d81f",
      "byte_length": 4525
    },
    "page.png": {
      "sha256": "eb34efd27cfa1bc70bd9d274c0d9bf92eb91bf9e56997bfeb188041cddcb8097",
      "byte_length": 49763
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-api-config.json": {
      "sha256": "27d19ce65d1fcb37cde9361bba95a3ba22e1331ab758bf0774fa535915b43ef9",
      "byte_length": 624
    },
    "source-case.json": {
      "sha256": "d4afeedc1da24fa292c204e9b40b8a0271a91f426e1389e5e890af11f2b908aa",
      "byte_length": 842
    },
    "source-semantics.json": {
      "sha256": "3c9ec361aa7fb88a84d108483db2f503b394d137888b595b4eaf83a660196443",
      "byte_length": 845
    }
  },
  "files": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "0c3e6218c184bebecf2e61b1a6e27e80e99ccfc7ac228e5fae7d443f6d780364",
      "byte_length": 162
    },
    "original.pdf": {
      "sha256": "ee33b3e6bf16cb972ae438c4c310757de8a85aaba4bfa206964a98a056aa3c00",
      "byte_length": 41073
    },
    "original.png": {
      "sha256": "7a22e31bb437a46687f26d5264d5e31befe837fee962b6198f73db2886a8d81f",
      "byte_length": 4525
    },
    "page.png": {
      "sha256": "eb34efd27cfa1bc70bd9d274c0d9bf92eb91bf9e56997bfeb188041cddcb8097",
      "byte_length": 49763
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "recognition.json": {
      "sha256": "7dbbd8030d4836b003eaa06ebc2771f68b21d55ab69d89c2f81cb75b2f1ed069",
      "byte_length": 196
    },
    "request-body.json": {
      "sha256": "c80c05bd5f940dd742746bcdf5fe609bda43a1b132d423c1b066fcdc11112821",
      "byte_length": 7481
    },
    "request.json": {
      "sha256": "89ddd9e8d20d2f55e95d8c548110821c008655b00feb67e8cece0063417916ea",
      "byte_length": 1491
    },
    "response.bin": {
      "sha256": "2a9ad397ee8be440f54f1fdb977c0a4e25221bdedeed048ca22d890fa1805f75",
      "byte_length": 494
    },
    "source-api-config.json": {
      "sha256": "27d19ce65d1fcb37cde9361bba95a3ba22e1331ab758bf0774fa535915b43ef9",
      "byte_length": 624
    },
    "source-case.json": {
      "sha256": "d4afeedc1da24fa292c204e9b40b8a0271a91f426e1389e5e890af11f2b908aa",
      "byte_length": 842
    },
    "source-semantics.json": {
      "sha256": "3c9ec361aa7fb88a84d108483db2f503b394d137888b595b4eaf83a660196443",
      "byte_length": 845
    }
  }
}
```
