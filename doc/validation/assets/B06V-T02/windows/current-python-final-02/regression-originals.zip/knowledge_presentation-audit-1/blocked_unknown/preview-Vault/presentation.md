# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "e8566265-1c23-45ab-831d-304206c356c2",
  "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "c4b88c90a60b28122f5f411fa4304322a8f69413531f512d735b189fb5d5ebc9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "561fa5a0b30c0ce8ea58a0f2a5118027ac6c5b9eb012260f172dabeb911930f5",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "7314615f3dbe1847c0475cafe696fa323cdf3d5f747160abb6e060d620686615",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "1fff76a999d7367fbf4e1e0302e19f71b4870289f1333b6b4e10f9bef5096c48",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "2ef46cbd6da8f096fb9ee7c0deb9da333bf1ace8cbd18a960a675f826c051d50",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9aff8ddafb7c110486a4c0637ac573f301b7330a36d65b22ff92f5ea3eff5083",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "e86a4d102ec0d052eac133d2ccd7337c8bbc4f4077480f9a23a00b277a90b382",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "5877f147876fd35c23ceff51a4026fda1aa30f154758c09bf21da4820557583c",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c77f982a54f5b11ce49e862bb424e1ba281f61ee960e2c945bfd00563a3edbe2",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "76ac1f92aa07f9d31b486dfb9d495ad2de4b9f2099da13d9d975ff3517027856",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4f22c5452b78f08ac16486d2f5718df5ec80b59d50dea3390e5508a1d37083b6",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "3f4dd4be53e04ef199a61408726f3b166cfd05d7726eaa4a0b6f81cce5fc64d0",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "9edabf2db9d3f61ca75bd451fb1522a0afa373a35e1491e27fa720674cc3f142",
      "byte_length": 14422
    },
    ".selection-original.json": {
      "sha256": "1d8ea8883cd9be73d2873d8cca0931e92209dd271d5a0f728660bdbd39cbb474",
      "byte_length": 4326
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "c4b88c90a60b28122f5f411fa4304322a8f69413531f512d735b189fb5d5ebc9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "561fa5a0b30c0ce8ea58a0f2a5118027ac6c5b9eb012260f172dabeb911930f5",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "7314615f3dbe1847c0475cafe696fa323cdf3d5f747160abb6e060d620686615",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "1fff76a999d7367fbf4e1e0302e19f71b4870289f1333b6b4e10f9bef5096c48",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "2ef46cbd6da8f096fb9ee7c0deb9da333bf1ace8cbd18a960a675f826c051d50",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9aff8ddafb7c110486a4c0637ac573f301b7330a36d65b22ff92f5ea3eff5083",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "e86a4d102ec0d052eac133d2ccd7337c8bbc4f4077480f9a23a00b277a90b382",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "5877f147876fd35c23ceff51a4026fda1aa30f154758c09bf21da4820557583c",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c77f982a54f5b11ce49e862bb424e1ba281f61ee960e2c945bfd00563a3edbe2",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "76ac1f92aa07f9d31b486dfb9d495ad2de4b9f2099da13d9d975ff3517027856",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4f22c5452b78f08ac16486d2f5718df5ec80b59d50dea3390e5508a1d37083b6",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "3f4dd4be53e04ef199a61408726f3b166cfd05d7726eaa4a0b6f81cce5fc64d0",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "9edabf2db9d3f61ca75bd451fb1522a0afa373a35e1491e27fa720674cc3f142",
      "byte_length": 14422
    },
    ".owner.json": {
      "sha256": "9ab7d2cf5cdb87dc616b0f1e7afc3aa507774cd9bdde90104ab0f7457d523a72",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "1d8ea8883cd9be73d2873d8cca0931e92209dd271d5a0f728660bdbd39cbb474",
      "byte_length": 4326
    }
  }
}
```
