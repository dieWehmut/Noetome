# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：1；条件不适用：1；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "5db211be-10c8-4b54-911b-2a484b860dc3",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
        "import_id": "585cca0b-0a22-4428-957f-821b58a5b535",
        "source_id": "88ccb7d3-fadb-4a4b-b7b7-1ff67373343d",
        "version_id": "ca3d175e-559e-45d1-9999-e2438eec0dac",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "585cca0b-0a22-4428-957f-821b58a5b535",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
              "source_id": "88ccb7d3-fadb-4a4b-b7b7-1ff67373343d",
              "version_id": "ca3d175e-559e-45d1-9999-e2438eec0dac"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "585cca0b-0a22-4428-957f-821b58a5b535",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
              "source_id": "88ccb7d3-fadb-4a4b-b7b7-1ff67373343d",
              "version_id": "ca3d175e-559e-45d1-9999-e2438eec0dac"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "1fff76a999d7367fbf4e1e0302e19f71b4870289f1333b6b4e10f9bef5096c48",
          "byte_length": 2714
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "2ef46cbd6da8f096fb9ee7c0deb9da333bf1ace8cbd18a960a675f826c051d50",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "9aff8ddafb7c110486a4c0637ac573f301b7330a36d65b22ff92f5ea3eff5083",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "e86a4d102ec0d052eac133d2ccd7337c8bbc4f4077480f9a23a00b277a90b382",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "5877f147876fd35c23ceff51a4026fda1aa30f154758c09bf21da4820557583c",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
        "import_id": "6df33c53-0c01-4ba2-9256-3144bfc43336",
        "source_id": "2e74e63b-019a-459d-9193-34c73c19ba79",
        "version_id": "d7ce16c9-d0ed-4636-bfdf-f97ec105e3fa",
        "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "import_id": "6df33c53-0c01-4ba2-9256-3144bfc43336",
              "manifest_sha256": null,
              "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "parse_id": null,
              "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
              "source_id": "2e74e63b-019a-459d-9193-34c73c19ba79",
              "version_id": "d7ce16c9-d0ed-4636-bfdf-f97ec105e3fa"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "import_id": "6df33c53-0c01-4ba2-9256-3144bfc43336",
              "manifest_sha256": null,
              "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "parse_id": null,
              "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
              "source_id": "2e74e63b-019a-459d-9193-34c73c19ba79",
              "version_id": "d7ce16c9-d0ed-4636-bfdf-f97ec105e3fa"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 12 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 B 的速度为 12 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 12 m/s。",
          "actual": "样例 B 的速度为 12 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "c77f982a54f5b11ce49e862bb424e1ba281f61ee960e2c945bfd00563a3edbe2",
          "byte_length": 2714
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "76ac1f92aa07f9d31b486dfb9d495ad2de4b9f2099da13d9d975ff3517027856",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "4f22c5452b78f08ac16486d2f5718df5ec80b59d50dea3390e5508a1d37083b6",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "3f4dd4be53e04ef199a61408726f3b166cfd05d7726eaa4a0b6f81cce5fc64d0",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "9edabf2db9d3f61ca75bd451fb1522a0afa373a35e1491e27fa720674cc3f142",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-3066e098d94a2c09773976d929a4e99eb3c869d22def95eac92ac6cbbf8dea11",
      "input_id": "a",
      "binding": {
        "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
        "import_id": "585cca0b-0a22-4428-957f-821b58a5b535",
        "source_id": "88ccb7d3-fadb-4a4b-b7b7-1ff67373343d",
        "version_id": "ca3d175e-559e-45d1-9999-e2438eec0dac",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "134bc592-7050-4128-9a47-d568e64de480",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
        "sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee"
      },
      "occurrence_id": "occ-ef7fc08f2a4921aeed4eb84873ab1796197bcb1c19cc21d04afa6c7d3443bda8",
      "input_id": "b",
      "binding": {
        "project_id": "4cc6e1b5-1a82-473f-8614-a81046c74504",
        "import_id": "6df33c53-0c01-4ba2-9256-3144bfc43336",
        "source_id": "2e74e63b-019a-459d-9193-34c73c19ba79",
        "version_id": "d7ce16c9-d0ed-4636-bfdf-f97ec105e3fa",
        "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "0dd45647-7873-4d40-b6df-62563812cc8e",
          "ordinal": 0,
          "resource_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的速度为 12 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-1cb6452246bd8530c319e5d336f11e2c966ec217796d57498133663bbc1a5e86",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-ef7fc08f2a4921aeed4eb84873ab1796197bcb1c19cc21d04afa6c7d3443bda8"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-54516b1c095b8bd73dec78d42296074e142d06e548c6f0f120a1a9c70fc43eae",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-3066e098d94a2c09773976d929a4e99eb3c869d22def95eac92ac6cbbf8dea11"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-3066e098d94a2c09773976d929a4e99eb3c869d22def95eac92ac6cbbf8dea11",
      "right_occurrence_id": "occ-ef7fc08f2a4921aeed4eb84873ab1796197bcb1c19cc21d04afa6c7d3443bda8",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-3066e098d94a2c09773976d929a4e99eb3c869d22def95eac92ac6cbbf8dea11",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    },
    {
      "occurrence_id": "occ-ef7fc08f2a4921aeed4eb84873ab1796197bcb1c19cc21d04afa6c7d3443bda8",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 1,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 1,
    "failed": 0,
    "needs_review": 1,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c4b88c90a60b28122f5f411fa4304322a8f69413531f512d735b189fb5d5ebc9",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "1d8ea8883cd9be73d2873d8cca0931e92209dd271d5a0f728660bdbd39cbb474",
      "byte_length": 4326
    },
    "identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "1fff76a999d7367fbf4e1e0302e19f71b4870289f1333b6b4e10f9bef5096c48",
      "byte_length": 2714
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "2ef46cbd6da8f096fb9ee7c0deb9da333bf1ace8cbd18a960a675f826c051d50",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "9aff8ddafb7c110486a4c0637ac573f301b7330a36d65b22ff92f5ea3eff5083",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "e86a4d102ec0d052eac133d2ccd7337c8bbc4f4077480f9a23a00b277a90b382",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "5877f147876fd35c23ceff51a4026fda1aa30f154758c09bf21da4820557583c",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "c77f982a54f5b11ce49e862bb424e1ba281f61ee960e2c945bfd00563a3edbe2",
      "byte_length": 2714
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    "input-b--knowledge-ir.json": {
      "sha256": "76ac1f92aa07f9d31b486dfb9d495ad2de4b9f2099da13d9d975ff3517027856",
      "byte_length": 9252
    },
    "input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "4f22c5452b78f08ac16486d2f5718df5ec80b59d50dea3390e5508a1d37083b6",
      "byte_length": 974
    },
    "input-b--verification.json": {
      "sha256": "3f4dd4be53e04ef199a61408726f3b166cfd05d7726eaa4a0b6f81cce5fc64d0",
      "byte_length": 13988
    },
    "input-b--verification.md": {
      "sha256": "9edabf2db9d3f61ca75bd451fb1522a0afa373a35e1491e27fa720674cc3f142",
      "byte_length": 14422
    }
  }
}
```
