# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "ad2411d5-2915-46b3-9e53-1fe72a978eb5",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "61000000-0000-4000-8000-000000000001",
      "display_name": "速度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000002",
      "display_name": "密度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000003",
      "display_name": "样例 B"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
        "import_id": "c1a56c9d-164e-4b41-b879-f4e0e950cf66",
        "source_id": "2ce6e649-9d3e-4be5-b20d-ff633c024a2c",
        "version_id": "b6726066-e111-4eed-85c9-696ca0107436",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-density"
            ],
            "decision": {
              "atom_ids": [
                "a-density"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "c1a56c9d-164e-4b41-b879-f4e0e950cf66",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
              "source_id": "2ce6e649-9d3e-4be5-b20d-ff633c024a2c",
              "version_id": "b6726066-e111-4eed-85c9-696ca0107436"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "c1a56c9d-164e-4b41-b879-f4e0e950cf66",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
              "source_id": "2ce6e649-9d3e-4be5-b20d-ff633c024a2c",
              "version_id": "b6726066-e111-4eed-85c9-696ca0107436"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "速度",
              "密度"
            ],
            "compound": "速度 密度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "密度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "kg/m³",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "kg/m³",
          "actual": {
            "measurement": "kg/m³",
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg/m³"
          },
          "actual": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "d2dfd35b6b68ec53ad5f917c139d82025c09b4727068e9ea43cd41b6aa05f637",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
          "byte_length": 143
        },
        "gold-original.json": {
          "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "380f5804cbc60c84ba9c3ecfd5f604d413b21ddcd389f314acc29906743258c6",
          "byte_length": 12391
        },
        "review-original.json": {
          "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
          "byte_length": 508
        },
        "source-snapshot.json": {
          "sha256": "c1117a33c43cf61f765869d2142e9d5628321ec91afa9610124b0e1d63239b2b",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "f3603d3424f57a098ddd959a0bc4cc875af845366c704c7bfd626ac4d4ebf5ec",
          "byte_length": 16868
        },
        "verification.md": {
          "sha256": "836f90d3ef2432b5a394cc5fbcbd2bc7045b8b8c760ef02c4bfcd986b93a3adc",
          "byte_length": 17302
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
        "import_id": "4d25028a-8cec-4658-a324-794785ed0606",
        "source_id": "71a49f5f-4d69-4676-a4bf-4f1151e4f5b7",
        "version_id": "95732b59-ff08-493b-938a-7adfc7c72536",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "4d25028a-8cec-4658-a324-794785ed0606",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
              "source_id": "71a49f5f-4d69-4676-a4bf-4f1151e4f5b7",
              "version_id": "95732b59-ff08-493b-938a-7adfc7c72536"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "4d25028a-8cec-4658-a324-794785ed0606",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
              "source_id": "71a49f5f-4d69-4676-a4bf-4f1151e4f5b7",
              "version_id": "95732b59-ff08-493b-938a-7adfc7c72536"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "a3b20f0747dd1279293a12f4789baa0c41bab521936d69211530d548477a7482",
          "byte_length": 3047
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "e66798da85e3ce1d2cd9b1e9d90c7efd3e36ceba9cc90d446401d9f0c64c0d22",
          "byte_length": 12339
        },
        "review-original.json": {
          "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "1ac7c8fde5f332ddde501acf4f8f4a78315f1dcfee1479b81a7e7d6c77d3cd73",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "8d5b90439732e29de8c74f53ee94006c32962ce337d21212f67f3ccf89e90a7e",
          "byte_length": 16821
        },
        "verification.md": {
          "sha256": "0b8614eb767b502f2517f7529053208c995cd5f6bf4ee3355e2364f3d52fde24",
          "byte_length": 17255
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2"
      },
      "occurrence_id": "occ-2d39763ed648999a0b4ff8aeae0fafe66c92db8ffb639421ad9c78c591138324",
      "input_id": "a",
      "binding": {
        "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
        "import_id": "c1a56c9d-164e-4b41-b879-f4e0e950cf66",
        "source_id": "2ce6e649-9d3e-4be5-b20d-ff633c024a2c",
        "version_id": "b6726066-e111-4eed-85c9-696ca0107436",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "799e33d6-8156-4a4a-b064-3c664708b826",
          "ordinal": 0,
          "resource_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "密度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-density",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg/m³",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
          "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000002"
      ],
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value": "2",
      "unit_value": "kg/m³",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a"
      },
      "occurrence_id": "occ-95808f4bf60b3c973b901bd65c4e71534fa1e95a8388d9bdceebb0ea3124da6c",
      "input_id": "b",
      "binding": {
        "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
        "import_id": "4d25028a-8cec-4658-a324-794785ed0606",
        "source_id": "71a49f5f-4d69-4676-a4bf-4f1151e4f5b7",
        "version_id": "95732b59-ff08-493b-938a-7adfc7c72536",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "cbabf631-2489-444c-af23-ee9c939eb462",
          "ordinal": 0,
          "resource_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000003"
      ],
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "2",
      "unit": "kg/m³",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-2d39763ed648999a0b4ff8aeae0fafe66c92db8ffb639421ad9c78c591138324"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-95808f4bf60b3c973b901bd65c4e71534fa1e95a8388d9bdceebb0ea3124da6c"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-2d39763ed648999a0b4ff8aeae0fafe66c92db8ffb639421ad9c78c591138324",
      "right_occurrence_id": "occ-95808f4bf60b3c973b901bd65c4e71534fa1e95a8388d9bdceebb0ea3124da6c",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-2d39763ed648999a0b4ff8aeae0fafe66c92db8ffb639421ad9c78c591138324",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-95808f4bf60b3c973b901bd65c4e71534fa1e95a8388d9bdceebb0ea3124da6c",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "601188f0bef04a508c4ab1eacd74b72fa3e0fecdfb7decd276631916f55912a9",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "e48b61be445c6c3dd6904506e6aa1a0c4e1e05a5af3396d376bcc94870fc705d",
      "byte_length": 41246
    },
    "coordination-original.json": {
      "sha256": "240558f7ed4a34c539498b4fdfd6d6d13fa1f8f1b7be6910d15d8374b8940061",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "d2dfd35b6b68ec53ad5f917c139d82025c09b4727068e9ea43cd41b6aa05f637",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    "input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "380f5804cbc60c84ba9c3ecfd5f604d413b21ddcd389f314acc29906743258c6",
      "byte_length": 12391
    },
    "input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    "input-a--source-snapshot.json": {
      "sha256": "c1117a33c43cf61f765869d2142e9d5628321ec91afa9610124b0e1d63239b2b",
      "byte_length": 1053
    },
    "input-a--verification.json": {
      "sha256": "f3603d3424f57a098ddd959a0bc4cc875af845366c704c7bfd626ac4d4ebf5ec",
      "byte_length": 16868
    },
    "input-a--verification.md": {
      "sha256": "836f90d3ef2432b5a394cc5fbcbd2bc7045b8b8c760ef02c4bfcd986b93a3adc",
      "byte_length": 17302
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "a3b20f0747dd1279293a12f4789baa0c41bab521936d69211530d548477a7482",
      "byte_length": 3047
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "e66798da85e3ce1d2cd9b1e9d90c7efd3e36ceba9cc90d446401d9f0c64c0d22",
      "byte_length": 12339
    },
    "input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "1ac7c8fde5f332ddde501acf4f8f4a78315f1dcfee1479b81a7e7d6c77d3cd73",
      "byte_length": 1053
    },
    "input-b--verification.json": {
      "sha256": "8d5b90439732e29de8c74f53ee94006c32962ce337d21212f67f3ccf89e90a7e",
      "byte_length": 16821
    },
    "input-b--verification.md": {
      "sha256": "0b8614eb767b502f2517f7529053208c995cd5f6bf4ee3355e2364f3d52fde24",
      "byte_length": 17255
    }
  }
}
```
