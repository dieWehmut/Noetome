# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "de472487-ca8f-453a-91f0-be8b0df34ffb",
  "project_id": "81c1aa04-9bf9-432f-b99f-4e03a4ad2ae4",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "129d587149a62fde05c983c202bfe60264874fb651062a06420a6dbf6bff859d",
    "byte_length": 37417
  },
  "plan_fingerprint": {
    "sha256": "bb76e1372d47f5db8bdea295342fc358a659b098e3fa41dd454cadd953d5ea0b",
    "byte_length": 16487
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "129d587149a62fde05c983c202bfe60264874fb651062a06420a6dbf6bff859d",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "cf7348618dd2a919dc70d17bde97d45953353824b6d461738f89b2d8427245d8",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d03bfb795160a0cb17c99bac7e4daf0898260cb5a7a79397bd920c3287e31534",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "fa47791c088c61c88520a20dba3a3db9ae8590ee2eca13faa8b34d8840dce88b",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f697f2085e506379f52ce1551607b7684a040d4bbdc544554bf30fa3f155f760",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "975fec70c264be18b8d91b3bff77eaf61cf9583c26a7f7cb42d58f1e03129ddc",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "638bc1efc97b8f09bb785e709ec56c61d59b4dcd1ff7ca901e1bcd211a9ea3f7",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "06265a9a380b47ae54b4d81980f2851710715770c9eef7e6ac513b6086eb6c18",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "ea5ee5b3be982dd76b7de5616790d6e2b903024361970d7875339c686f258197",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "44b5c02fb639785e4ce70c841bf4f8bac0fae0db64fd526677d235a9f8e23c73",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9e4e1f84c0ed59b07aab2d30dbf1fa0ab2363a81e82c0dfa8f78e76f6565936a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "d2f0c26164a43d28f83ff8927d848902a4e3770f8ccffbf41d1755b5fdc23667",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "8fefbdf9aa43434b847cf39453e2e25dad1fe2e5f6a59e71906753ec7b9f763d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "0ad6586d8cb2d216d2961b90be0640de40c3109bbf9b1e7c2187b84da02a317e",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "3359053d38704df8ef5183b9aafc4e8d4372b72d939b6c789cabfc50fed7ca73",
      "byte_length": 4328
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6a938d10c49c2e6f14b7aa3540a3f585bdf772400ec1d3fc7c3d0c39fbb3e103",
            "occ-d8b1d1c30596e62c5a1ee34e7c40510cf684bc0790269a65be820bab0011817a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6a938d10c49c2e6f14b7aa3540a3f585bdf772400ec1d3fc7c3d0c39fbb3e103"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-6a938d10c49c2e6f14b7aa3540a3f585bdf772400ec1d3fc7c3d0c39fbb3e103"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 262
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-d8b1d1c30596e62c5a1ee34e7c40510cf684bc0790269a65be820bab0011817a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 267,
          "end_byte": 275
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-d8b1d1c30596e62c5a1ee34e7c40510cf684bc0790269a65be820bab0011817a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 353,
          "end_byte": 499
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 276,
          "end_byte": 350
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-6a938d10c49c2e6f14b7aa3540a3f585bdf772400ec1d3fc7c3d0c39fbb3e103"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 207
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-d8b1d1c30596e62c5a1ee34e7c40510cf684bc0790269a65be820bab0011817a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "129d587149a62fde05c983c202bfe60264874fb651062a06420a6dbf6bff859d",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "cf7348618dd2a919dc70d17bde97d45953353824b6d461738f89b2d8427245d8",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d03bfb795160a0cb17c99bac7e4daf0898260cb5a7a79397bd920c3287e31534",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "fa47791c088c61c88520a20dba3a3db9ae8590ee2eca13faa8b34d8840dce88b",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f697f2085e506379f52ce1551607b7684a040d4bbdc544554bf30fa3f155f760",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "975fec70c264be18b8d91b3bff77eaf61cf9583c26a7f7cb42d58f1e03129ddc",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "638bc1efc97b8f09bb785e709ec56c61d59b4dcd1ff7ca901e1bcd211a9ea3f7",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "06265a9a380b47ae54b4d81980f2851710715770c9eef7e6ac513b6086eb6c18",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "ea5ee5b3be982dd76b7de5616790d6e2b903024361970d7875339c686f258197",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "44b5c02fb639785e4ce70c841bf4f8bac0fae0db64fd526677d235a9f8e23c73",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9e4e1f84c0ed59b07aab2d30dbf1fa0ab2363a81e82c0dfa8f78e76f6565936a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "d2f0c26164a43d28f83ff8927d848902a4e3770f8ccffbf41d1755b5fdc23667",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "8fefbdf9aa43434b847cf39453e2e25dad1fe2e5f6a59e71906753ec7b9f763d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "0ad6586d8cb2d216d2961b90be0640de40c3109bbf9b1e7c2187b84da02a317e",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "c19960155c5a5e2aff545f1a5098b4ee39b3dd16e176d1d1947d84ba0f2e6a50",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "3359053d38704df8ef5183b9aafc4e8d4372b72d939b6c789cabfc50fed7ca73",
      "byte_length": 4328
    },
    "plan.json": {
      "sha256": "bb76e1372d47f5db8bdea295342fc358a659b098e3fa41dd454cadd953d5ea0b",
      "byte_length": 16487
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503
    }
  }
}
```
