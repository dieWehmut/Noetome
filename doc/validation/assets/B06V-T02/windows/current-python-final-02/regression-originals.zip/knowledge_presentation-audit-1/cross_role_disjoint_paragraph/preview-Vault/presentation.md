# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "106e0796-6dda-4c59-a5d9-39665aad58b0",
  "project_id": "84b03062-a45f-440c-807e-d3cdc9874566",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "e48b61be445c6c3dd6904506e6aa1a0c4e1e05a5af3396d376bcc94870fc705d",
    "byte_length": 41246
  },
  "plan_fingerprint": {
    "sha256": "bf434ce6fe1a50f65b97cf9888420303be2d3fd5d8605a746465330b617df84c",
    "byte_length": 14692
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "e48b61be445c6c3dd6904506e6aa1a0c4e1e05a5af3396d376bcc94870fc705d",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "601188f0bef04a508c4ab1eacd74b72fa3e0fecdfb7decd276631916f55912a9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "e5e82156f9ab1f8ea27a6b6b3c7052081554c71ae71bea740021ef6c5b0df8f9",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "8107698ba6f4a0d2c2c7a6a2ef3e1c49db64bc8c9fcf0b950109cf93d13e44c2",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "d2dfd35b6b68ec53ad5f917c139d82025c09b4727068e9ea43cd41b6aa05f637",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "380f5804cbc60c84ba9c3ecfd5f604d413b21ddcd389f314acc29906743258c6",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "c1117a33c43cf61f765869d2142e9d5628321ec91afa9610124b0e1d63239b2b",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "f3603d3424f57a098ddd959a0bc4cc875af845366c704c7bfd626ac4d4ebf5ec",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "836f90d3ef2432b5a394cc5fbcbd2bc7045b8b8c760ef02c4bfcd986b93a3adc",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "a3b20f0747dd1279293a12f4789baa0c41bab521936d69211530d548477a7482",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e66798da85e3ce1d2cd9b1e9d90c7efd3e36ceba9cc90d446401d9f0c64c0d22",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "1ac7c8fde5f332ddde501acf4f8f4a78315f1dcfee1479b81a7e7d6c77d3cd73",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "8d5b90439732e29de8c74f53ee94006c32962ce337d21212f67f3ccf89e90a7e",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "0b8614eb767b502f2517f7529053208c995cd5f6bf4ee3355e2364f3d52fde24",
      "byte_length": 17255
    },
    ".selection-original.json": {
      "sha256": "240558f7ed4a34c539498b4fdfd6d6d13fa1f8f1b7be6910d15d8374b8940061",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-2d39763ed648999a0b4ff8aeae0fafe66c92db8ffb639421ad9c78c591138324"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 33,
          "end_byte": 197
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-95808f4bf60b3c973b901bd65c4e71534fa1e95a8388d9bdceebb0ea3124da6c"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 273,
          "end_byte": 437
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000001",
          "target_path": "对象-61000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 198,
          "end_byte": 271
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000003",
          "target_path": "对象-61000000-0000-4000-8000-000000000003.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 438,
          "end_byte": 511
        }
      ]
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000001.md",
      "note_id": "object-61000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-2d39763ed648999a0b4ff8aeae0fafe66c92db8ffb639421ad9c78c591138324"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 27,
          "end_byte": 320
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000003.md",
      "note_id": "object-61000000-0000-4000-8000-000000000003",
      "plan_revision": 1,
      "content_sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-95808f4bf60b3c973b901bd65c4e71534fa1e95a8388d9bdceebb0ea3124da6c"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 29,
          "end_byte": 322
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "e48b61be445c6c3dd6904506e6aa1a0c4e1e05a5af3396d376bcc94870fc705d",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "601188f0bef04a508c4ab1eacd74b72fa3e0fecdfb7decd276631916f55912a9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "e5e82156f9ab1f8ea27a6b6b3c7052081554c71ae71bea740021ef6c5b0df8f9",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "8107698ba6f4a0d2c2c7a6a2ef3e1c49db64bc8c9fcf0b950109cf93d13e44c2",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "d2dfd35b6b68ec53ad5f917c139d82025c09b4727068e9ea43cd41b6aa05f637",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "380f5804cbc60c84ba9c3ecfd5f604d413b21ddcd389f314acc29906743258c6",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "c1117a33c43cf61f765869d2142e9d5628321ec91afa9610124b0e1d63239b2b",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "f3603d3424f57a098ddd959a0bc4cc875af845366c704c7bfd626ac4d4ebf5ec",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "836f90d3ef2432b5a394cc5fbcbd2bc7045b8b8c760ef02c4bfcd986b93a3adc",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "a3b20f0747dd1279293a12f4789baa0c41bab521936d69211530d548477a7482",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e66798da85e3ce1d2cd9b1e9d90c7efd3e36ceba9cc90d446401d9f0c64c0d22",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "1ac7c8fde5f332ddde501acf4f8f4a78315f1dcfee1479b81a7e7d6c77d3cd73",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "8d5b90439732e29de8c74f53ee94006c32962ce337d21212f67f3ccf89e90a7e",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "0b8614eb767b502f2517f7529053208c995cd5f6bf4ee3355e2364f3d52fde24",
      "byte_length": 17255
    },
    ".owner.json": {
      "sha256": "e8ff32b9c00f57f4fe27ac1da4518c685ed532b76931b497f1e1a2ec6cb8ab92",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "240558f7ed4a34c539498b4fdfd6d6d13fa1f8f1b7be6910d15d8374b8940061",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "bf434ce6fe1a50f65b97cf9888420303be2d3fd5d8605a746465330b617df84c",
      "byte_length": 14692
    },
    "对象-61000000-0000-4000-8000-000000000001.md": {
      "sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322
    },
    "对象-61000000-0000-4000-8000-000000000003.md": {
      "sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324
    },
    "知识比较.md": {
      "sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513
    }
  }
}
```
