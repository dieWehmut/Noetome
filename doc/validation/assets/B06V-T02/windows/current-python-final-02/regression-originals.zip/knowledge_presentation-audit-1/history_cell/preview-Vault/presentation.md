# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "8802ff74-693e-48a0-9bb9-45ca20231de9",
  "project_id": "d69c9998-d613-439d-86e7-54d685042c34",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "973dcc120b4dd5a6e22439bc4c8c4ce585b362c3e86fb84c5a0cb52ecf1716e7",
    "byte_length": 61820
  },
  "plan_fingerprint": {
    "sha256": "d9e79ba946665aa81f0c969777757f9f00039dbeaa72e7fd02c6ca4b31c16b8e",
    "byte_length": 22900
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "973dcc120b4dd5a6e22439bc4c8c4ce585b362c3e86fb84c5a0cb52ecf1716e7",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "9ed673a0a24e62090a861f62e4ccf73d09ee4c6013e5d74923536e545f3cd66b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "b429d60aa0699cc75a2d17f755385b3479bb0e2345f2448fdc7488f6644c9940",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "909c8a3ad5df6091186f623e2d2cdb7b37d4ae2232de180ebad4f5ba54f9259a",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "fcf6012672ff85aea31328556bfb5b3062f02ebd2bd61e4fe56d57e370836769",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a2ec566f5e5f7e81d8dfd0464fde2ffcef4ae8f5cde12735f22395bc19335d59",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "25d839699ba9851f4eacc1721ca91611adf1684c4f1cba483ee20b9627d9356b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "279529d8d730ae9a7871df6c1f0fcd9ab9903786416927f16e1bac3c8d3c1a7e",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "630b63b410ec9e41c567b362dfa9eaf6e736c3669d2fad44ea6c56e3c4bf4c29",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "4a6678c7c5af51a8bf82ab1261e5ff9ebf3f0cfad4c5c8b2d7021248f70a50aa",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "aec0878fd4e178de86b05caede131377fafe126b5d02b9e7a179ceffe7f2b66b",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "035c6f28e0a5e357aabdcfa45306110ed79c017a8a450651c8e4310bd3d4e622",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "c5862a69ea0b6ad5df10541b0bec8795bf6e33b06fcadc55f1edb46fd6d341bb",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5e9411dd8d712133bed1f54ba36e0b34ad22d0cffbe087a03514dd4cf19584c4",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "8b1ac516a748ce8a44aeb86d41ce3c0713af71f48f09346285ab07f38ca5aaa6",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "37fdeb2f6f08c964452be939de0246a58bcfa641ae29fad198e84f3996ffca41",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "3fa8d0a654bd1f86de7edfa491b9ec21eae3197fb496020d074f5eb9868f20a2",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "3b881e881161b9b79c3e4c74777b982dba9a0d1ca7047e419b5ae5a56a62c4be",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "ee57b1b43c0f1a99ebbd49372a3642b2027e52bede9282becdcbe628aad5b32a",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "d9f7e49faeaebc26c1c4b04830fd920c51f64d6284c2d032ed0fdc28cba64ea5",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "02b9ac3e26c38da49252f068b0bae9ad4e340fe7233d7b7c39eaf2caa0bedacf",
      "byte_length": 692,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-065cbf7971c0339f390f1f484c00c8194c1d9faf387f7b97966eadcb217f943b",
            "occ-0a4791b42b60b345b212ab82dc7e273638b0f5825a855134cabed888df514eeb",
            "occ-fad751243f0ba5ab758ab11dce8a8701fb61ca13250a675503617637af029fb0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-065cbf7971c0339f390f1f484c00c8194c1d9faf387f7b97966eadcb217f943b",
            "occ-0a4791b42b60b345b212ab82dc7e273638b0f5825a855134cabed888df514eeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-065cbf7971c0339f390f1f484c00c8194c1d9faf387f7b97966eadcb217f943b",
            "occ-0a4791b42b60b345b212ab82dc7e273638b0f5825a855134cabed888df514eeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 451
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-fad751243f0ba5ab758ab11dce8a8701fb61ca13250a675503617637af029fb0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 456,
          "end_byte": 464
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-fad751243f0ba5ab758ab11dce8a8701fb61ca13250a675503617637af029fb0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 542,
          "end_byte": 688
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 465,
          "end_byte": 539
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-065cbf7971c0339f390f1f484c00c8194c1d9faf387f7b97966eadcb217f943b"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-0a4791b42b60b345b212ab82dc7e273638b0f5825a855134cabed888df514eeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-fad751243f0ba5ab758ab11dce8a8701fb61ca13250a675503617637af029fb0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "973dcc120b4dd5a6e22439bc4c8c4ce585b362c3e86fb84c5a0cb52ecf1716e7",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "9ed673a0a24e62090a861f62e4ccf73d09ee4c6013e5d74923536e545f3cd66b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "b429d60aa0699cc75a2d17f755385b3479bb0e2345f2448fdc7488f6644c9940",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "909c8a3ad5df6091186f623e2d2cdb7b37d4ae2232de180ebad4f5ba54f9259a",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "fcf6012672ff85aea31328556bfb5b3062f02ebd2bd61e4fe56d57e370836769",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a2ec566f5e5f7e81d8dfd0464fde2ffcef4ae8f5cde12735f22395bc19335d59",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "25d839699ba9851f4eacc1721ca91611adf1684c4f1cba483ee20b9627d9356b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "279529d8d730ae9a7871df6c1f0fcd9ab9903786416927f16e1bac3c8d3c1a7e",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "630b63b410ec9e41c567b362dfa9eaf6e736c3669d2fad44ea6c56e3c4bf4c29",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "4a6678c7c5af51a8bf82ab1261e5ff9ebf3f0cfad4c5c8b2d7021248f70a50aa",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "aec0878fd4e178de86b05caede131377fafe126b5d02b9e7a179ceffe7f2b66b",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "035c6f28e0a5e357aabdcfa45306110ed79c017a8a450651c8e4310bd3d4e622",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "c5862a69ea0b6ad5df10541b0bec8795bf6e33b06fcadc55f1edb46fd6d341bb",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5e9411dd8d712133bed1f54ba36e0b34ad22d0cffbe087a03514dd4cf19584c4",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "8b1ac516a748ce8a44aeb86d41ce3c0713af71f48f09346285ab07f38ca5aaa6",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "37fdeb2f6f08c964452be939de0246a58bcfa641ae29fad198e84f3996ffca41",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "3fa8d0a654bd1f86de7edfa491b9ec21eae3197fb496020d074f5eb9868f20a2",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "3b881e881161b9b79c3e4c74777b982dba9a0d1ca7047e419b5ae5a56a62c4be",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "ee57b1b43c0f1a99ebbd49372a3642b2027e52bede9282becdcbe628aad5b32a",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "04b628a5d7be9d79409090ee368b609fe7dbd6b2ae38187e61ac8720eb048e4d",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "d9f7e49faeaebc26c1c4b04830fd920c51f64d6284c2d032ed0fdc28cba64ea5",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "d9e79ba946665aa81f0c969777757f9f00039dbeaa72e7fd02c6ca4b31c16b8e",
      "byte_length": 22900
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "02b9ac3e26c38da49252f068b0bae9ad4e340fe7233d7b7c39eaf2caa0bedacf",
      "byte_length": 692
    }
  }
}
```
