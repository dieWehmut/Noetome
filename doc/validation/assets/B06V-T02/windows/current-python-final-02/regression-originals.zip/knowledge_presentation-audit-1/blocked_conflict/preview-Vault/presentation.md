# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "fb409ff3-c6ee-4799-b118-23ff1972c512",
  "project_id": "f3244be5-30f3-418e-9f64-daa7669422b1",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 1,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "d74ce6dfa1cd40110b0a75c837b22e1800f3da81f288f6611db6308ba23c213b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c2da1c4c0ae2e4549d7bab124143d626b40ed77224677e26c477293c5719deb5",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "b3ba9ccab6c7e51eca7637917838eeb2dd7dd7ac364eda31c51056b154ad88a1",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "9f68b0904f4c0ad6abc557ad8cc07c3148b67178788b45ab26ebc29bc4750fc0",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "739510407e41083e579871dc8dcd14389c3ab8fcf2139c5cdfa2aa6fbc1e4495",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "b261674fc9e78219feabb6c36fc0e9a52977f22ff6a50ceeefef79406072700f",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8ca2fa826307d2241b1122b7e3c7e9d87b4bd6ac198b5dcff253d275116c291f",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "a13b56a6a9a2f412c36b11a810efb5040dcd9c1c56fe0cfe0c8df9f68c3d25a1",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6a63644b2df55cd1e5eadd44a4939dce970c1f0f1759b05d458937c529b0454d",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "bd4ff591cd64a0887f01365e8f5f71a193ec419ec9add74c25eb1501e574f28a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0789f0c12acb383d9c6ac3770d3f73162fa7d715c725f97ea0013e56798ced1d",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "5433e1cf20977417f55ef8c4472b4b6a74a6031392aaa6b2e175223bef2f689e",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "bddbcb1826b01d5f5857a0cafd65d5377fa05f332d56af590e9a68c7740f3fac",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "4d3416c5f32ccb8b818956cc1a1c199209be2da70c458c033ef536de6251e975",
      "byte_length": 4330
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "d74ce6dfa1cd40110b0a75c837b22e1800f3da81f288f6611db6308ba23c213b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c2da1c4c0ae2e4549d7bab124143d626b40ed77224677e26c477293c5719deb5",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "b3ba9ccab6c7e51eca7637917838eeb2dd7dd7ac364eda31c51056b154ad88a1",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "9f68b0904f4c0ad6abc557ad8cc07c3148b67178788b45ab26ebc29bc4750fc0",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "739510407e41083e579871dc8dcd14389c3ab8fcf2139c5cdfa2aa6fbc1e4495",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "b261674fc9e78219feabb6c36fc0e9a52977f22ff6a50ceeefef79406072700f",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8ca2fa826307d2241b1122b7e3c7e9d87b4bd6ac198b5dcff253d275116c291f",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "a13b56a6a9a2f412c36b11a810efb5040dcd9c1c56fe0cfe0c8df9f68c3d25a1",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6a63644b2df55cd1e5eadd44a4939dce970c1f0f1759b05d458937c529b0454d",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "bd4ff591cd64a0887f01365e8f5f71a193ec419ec9add74c25eb1501e574f28a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0789f0c12acb383d9c6ac3770d3f73162fa7d715c725f97ea0013e56798ced1d",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "5433e1cf20977417f55ef8c4472b4b6a74a6031392aaa6b2e175223bef2f689e",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "bddbcb1826b01d5f5857a0cafd65d5377fa05f332d56af590e9a68c7740f3fac",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "9ebec0bc5832de937260a319819435c4429b9a7c362c0b673bb781de6bf2e3ee",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "4d3416c5f32ccb8b818956cc1a1c199209be2da70c458c033ef536de6251e975",
      "byte_length": 4330
    }
  }
}
```
