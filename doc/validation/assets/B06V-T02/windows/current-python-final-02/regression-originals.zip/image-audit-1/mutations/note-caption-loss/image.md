# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "50436b42-7f5f-4603-8343-6cb282693976",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "signed_arrows",
    "title": "图像保真样例 signed_arrows",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "842df03fe191041c24b099841c97ee7402eff40d3a350d907594153bb57abb51"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "response",
        "kind": "circle",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "positive",
        "label": "activates",
        "unit": "s^-1",
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c5efcb",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "svg_redraw",
    "fallback_reasons": [],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "6bb34988aa01920c39290698dfd70a504e8a210f148dde1470bbdded0b922dc8",
    "byte_length": 3460
  },
  "inputs": {
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "0ecc345bec924324376006434ea615da492ec2e3931921b10560aa877e8027e6",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "842df03fe191041c24b099841c97ee7402eff40d3a350d907594153bb57abb51",
      "byte_length": 2378
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "59743e067d4af4daf85d4234ee506e4ef20cd3b0ef49b0a1171bd41ce67f7ec6",
      "byte_length": 2552,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "image_embed",
          "source_field": "semantics",
          "start_byte": 84,
          "end_byte": 100
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 121,
          "end_byte": 141
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 191,
          "end_byte": 195
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 220,
          "end_byte": 224
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 249,
          "end_byte": 253
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 278,
          "end_byte": 284
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 309,
          "end_byte": 330
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 361,
          "end_byte": 377
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 416,
          "end_byte": 424
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 449,
          "end_byte": 455
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 480,
          "end_byte": 488
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 513,
          "end_byte": 517
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 542,
          "end_byte": 563
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 594,
          "end_byte": 611
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 650,
          "end_byte": 656
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 681,
          "end_byte": 685
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 710,
          "end_byte": 716
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 741,
          "end_byte": 747
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 772,
          "end_byte": 793
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 824,
          "end_byte": 841
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 891,
          "end_byte": 895
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 926,
          "end_byte": 930
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 961,
          "end_byte": 969
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1000,
          "end_byte": 1009
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1040,
          "end_byte": 1049
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1080,
          "end_byte": 1087
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1118,
          "end_byte": 1126
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1151,
          "end_byte": 1160
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1185,
          "end_byte": 1189
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1214,
          "end_byte": 1222
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1261,
          "end_byte": 1265
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1296,
          "end_byte": 1304
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1335,
          "end_byte": 1341
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1372,
          "end_byte": 1381
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1412,
          "end_byte": 1421
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1452,
          "end_byte": 1459
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1490,
          "end_byte": 1498
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1523,
          "end_byte": 1531
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1556,
          "end_byte": 1560
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1585,
          "end_byte": 1593
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1655,
          "end_byte": 1664
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1689,
          "end_byte": 1693
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 1724,
          "end_byte": 1732
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 1763,
          "end_byte": 1770
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 1815,
          "end_byte": 1828
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 1853,
          "end_byte": 1861
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 1892,
          "end_byte": 1898
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 1929,
          "end_byte": 1936
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 1986,
          "end_byte": 1994
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2019,
          "end_byte": 2020
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2045,
          "end_byte": 2064
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2089,
          "end_byte": 2096
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2127,
          "end_byte": 2142
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2181,
          "end_byte": 2189
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2214,
          "end_byte": 2215
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2240,
          "end_byte": 2259
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2284,
          "end_byte": 2291
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2322,
          "end_byte": 2338
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2369,
          "end_byte": 2424
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2449,
          "end_byte": 2500
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2523,
          "end_byte": 2551
        }
      ]
    },
    {
      "relative_path": "redrawn.svg",
      "content_sha256": "ceef72176b1fdfd46fbaa9be31e2edaf1dd4df6c4ae691cf2e22c00634ea9d4c",
      "byte_length": 3577,
      "mappings": [
        {
          "kind": "canvas_background",
          "source_field": "case.dimensions",
          "start_byte": 88,
          "end_byte": 165
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 166,
          "end_byte": 283
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 284,
          "end_byte": 398
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 399,
          "end_byte": 516
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 517,
          "end_byte": 658
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 659,
          "end_byte": 801
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 802,
          "end_byte": 951
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 952,
          "end_byte": 1096
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 1097,
          "end_byte": 1242
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 1243,
          "end_byte": 1387
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 1388,
          "end_byte": 1504
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 1505,
          "end_byte": 1646
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 1647,
          "end_byte": 1808
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 1809,
          "end_byte": 1926
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 1927,
          "end_byte": 2068
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2069,
          "end_byte": 2230
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[0]",
          "start_byte": 2231,
          "end_byte": 2327
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 2328,
          "end_byte": 2468
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 2469,
          "end_byte": 2609
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 2610,
          "end_byte": 2757
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 2758,
          "end_byte": 2899
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[1]",
          "start_byte": 2900,
          "end_byte": 2996
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 2997,
          "end_byte": 3137
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 3138,
          "end_byte": 3280
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 3281,
          "end_byte": 3427
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 3428,
          "end_byte": 3569
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "6817c250ecde3f64af5d274f687fe2fb411db61180e33ed0a30009f91840708e",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "plan.json": {
      "sha256": "6bb34988aa01920c39290698dfd70a504e8a210f148dde1470bbdded0b922dc8",
      "byte_length": 3460
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "redrawn.svg": {
      "sha256": "ceef72176b1fdfd46fbaa9be31e2edaf1dd4df6c4ae691cf2e22c00634ea9d4c",
      "byte_length": 3577
    },
    "source-case.json": {
      "sha256": "0ecc345bec924324376006434ea615da492ec2e3931921b10560aa877e8027e6",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "842df03fe191041c24b099841c97ee7402eff40d3a350d907594153bb57abb51",
      "byte_length": 2378
    },
    "图像预览.md": {
      "sha256": "59743e067d4af4daf85d4234ee506e4ef20cd3b0ef49b0a1171bd41ce67f7ec6",
      "byte_length": 2552
    }
  }
}
```
