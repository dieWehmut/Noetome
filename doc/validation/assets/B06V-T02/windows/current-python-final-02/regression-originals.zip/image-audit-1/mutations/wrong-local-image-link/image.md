# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "56088795-9d14-4c93-812a-2e0e661cb496",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "unsupported_geometry",
    "title": "图像保真样例 unsupported_geometry",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c8e012111a2cfe1388dd2a254c9e4ffe5f13fff4b9bff133fe3dbd700ecbd85c"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "fcb59d02fd10698fc7109666b06463196a8c91c55aa21358c35f7a6604eb57dd"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "response",
        "kind": "unsupported",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "positive",
        "label": "activates",
        "unit": "s^-1",
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c5efcb",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "original_image",
    "fallback_reasons": [
      "IMAGE_GEOMETRY_UNSUPPORTED"
    ],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "97704b54ace4036e26704b2ac8e8b436c1967c07dde99d52c6fc25fd8b380178",
    "byte_length": 3523
  },
  "inputs": {
    "original.png": {
      "sha256": "c8e012111a2cfe1388dd2a254c9e4ffe5f13fff4b9bff133fe3dbd700ecbd85c",
      "byte_length": 22417
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "095c5b01e0c5bc37cbca57e3a987304c081ad9fefd336ea239982fe905d76536",
      "byte_length": 505
    },
    "source-semantics.json": {
      "sha256": "fcb59d02fd10698fc7109666b06463196a8c91c55aa21358c35f7a6604eb57dd",
      "byte_length": 2383
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "451122f2ba2bf1a7e8adfcfede187ed64efe96eeb4a9bd63ba58c75ca0f4bcac",
      "byte_length": 2706,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 74
        },
        {
          "kind": "image_embed",
          "source_field": "case.image",
          "start_byte": 91,
          "end_byte": 107
        },
        {
          "kind": "fallback_reason",
          "source_field": "decision.fallback_reasons[0]",
          "start_byte": 117,
          "end_byte": 186
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 211,
          "end_byte": 290
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 340,
          "end_byte": 344
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 369,
          "end_byte": 373
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 398,
          "end_byte": 402
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 427,
          "end_byte": 433
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 458,
          "end_byte": 479
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 510,
          "end_byte": 526
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 565,
          "end_byte": 573
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 598,
          "end_byte": 609
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 634,
          "end_byte": 642
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 667,
          "end_byte": 671
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 696,
          "end_byte": 717
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 748,
          "end_byte": 765
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 804,
          "end_byte": 810
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 835,
          "end_byte": 839
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 864,
          "end_byte": 870
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 895,
          "end_byte": 901
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 926,
          "end_byte": 947
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 978,
          "end_byte": 995
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 1045,
          "end_byte": 1049
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 1080,
          "end_byte": 1084
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 1115,
          "end_byte": 1123
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1154,
          "end_byte": 1163
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1194,
          "end_byte": 1203
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1234,
          "end_byte": 1241
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1272,
          "end_byte": 1280
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1305,
          "end_byte": 1314
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1339,
          "end_byte": 1343
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1368,
          "end_byte": 1376
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1415,
          "end_byte": 1419
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1450,
          "end_byte": 1458
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1489,
          "end_byte": 1495
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1526,
          "end_byte": 1535
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1566,
          "end_byte": 1575
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1606,
          "end_byte": 1613
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1644,
          "end_byte": 1652
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1677,
          "end_byte": 1685
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1710,
          "end_byte": 1714
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1739,
          "end_byte": 1747
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1809,
          "end_byte": 1818
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1843,
          "end_byte": 1847
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 1878,
          "end_byte": 1886
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 1917,
          "end_byte": 1924
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 1969,
          "end_byte": 1982
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 2007,
          "end_byte": 2015
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 2046,
          "end_byte": 2052
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 2083,
          "end_byte": 2090
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 2140,
          "end_byte": 2148
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2173,
          "end_byte": 2174
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2199,
          "end_byte": 2218
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2243,
          "end_byte": 2250
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2281,
          "end_byte": 2296
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2335,
          "end_byte": 2343
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2368,
          "end_byte": 2369
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2394,
          "end_byte": 2413
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2438,
          "end_byte": 2445
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2476,
          "end_byte": 2492
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2523,
          "end_byte": 2578
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2603,
          "end_byte": 2654
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2677,
          "end_byte": 2705
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "24099129d936afc774168e35f7e6a6766787f8b71ddcb7cd5c35c8cb3fd78765",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c8e012111a2cfe1388dd2a254c9e4ffe5f13fff4b9bff133fe3dbd700ecbd85c",
      "byte_length": 22417
    },
    "plan.json": {
      "sha256": "97704b54ace4036e26704b2ac8e8b436c1967c07dde99d52c6fc25fd8b380178",
      "byte_length": 3523
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "095c5b01e0c5bc37cbca57e3a987304c081ad9fefd336ea239982fe905d76536",
      "byte_length": 505
    },
    "source-semantics.json": {
      "sha256": "fcb59d02fd10698fc7109666b06463196a8c91c55aa21358c35f7a6604eb57dd",
      "byte_length": 2383
    },
    "图像预览.md": {
      "sha256": "451122f2ba2bf1a7e8adfcfede187ed64efe96eeb4a9bd63ba58c75ca0f4bcac",
      "byte_length": 2706
    }
  }
}
```
