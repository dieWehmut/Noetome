# 选定图像保真预览报告

状态：needs_review；预览：not_run；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "317bd64f-0899-48dc-8204-f9e07096ea30",
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "signed_arrows",
    "title": "图像保真样例 signed_arrows",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "a08dbdf66b8b416c6e84f443fdd50951337ddc222d92bdc73f14dbc47859a2af"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "outer",
        "kind": "circle",
        "bbox": [
          300,
          100,
          200,
          200
        ],
        "label": "Circle",
        "unit": null,
        "legend_id": null
      },
      {
        "id": "inner",
        "kind": "rect",
        "bbox": [
          300,
          100,
          40,
          40
        ],
        "label": "X",
        "unit": null,
        "legend_id": null
      }
    ],
    "relations": [],
    "spatial_relations": [
      {
        "id": "inside",
        "a": "inner",
        "b": "outer",
        "relation": "inside"
      }
    ],
    "legend": []
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "needs_review",
    "semantic_review": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "decision": {
    "representation": null,
    "fallback_reasons": [],
    "issue_codes": [
      "IMAGE_GEOMETRY_MISMATCH"
    ]
  },
  "plan_fingerprint": null,
  "inputs": {
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "3c42ff8fbed05f30917d05bc39ce7e93b382f32d8cdfbdc49b27fe21bc545214",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "a08dbdf66b8b416c6e84f443fdd50951337ddc222d92bdc73f14dbc47859a2af",
      "byte_length": 1006
    }
  },
  "files": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "b4a6c9065eb81b370eb37783dec9789977e06381a716d59f2592483d0909dc48",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "3c42ff8fbed05f30917d05bc39ce7e93b382f32d8cdfbdc49b27fe21bc545214",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "a08dbdf66b8b416c6e84f443fdd50951337ddc222d92bdc73f14dbc47859a2af",
      "byte_length": 1006
    }
  }
}
```
