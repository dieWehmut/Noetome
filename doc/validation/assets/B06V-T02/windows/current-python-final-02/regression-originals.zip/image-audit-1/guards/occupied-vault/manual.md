User-owned manual note.
