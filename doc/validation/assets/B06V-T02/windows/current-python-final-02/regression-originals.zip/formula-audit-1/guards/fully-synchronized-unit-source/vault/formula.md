# 选定公式保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "5dabb9b2-7b9a-452d-952b-9b88f775c4bc",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "native",
    "title": "公式保真样例 native",
    "source_kind": "tex",
    "tex": {
      "file": "original.tex",
      "sha256": "4fbab010e8618ed51cea0a2caac1aa469f2c06cbcbdc774f4f5f9bf12294cfdb"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "44d73484c71d3a81ce98262df8a8191cc3d5309bf0f17e2368044af1b8b6e112"
    },
    "region": {
      "file": "region.png",
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": "C_i(t) = -\\frac{a}{b} t^{2}",
    "symbols": [
      {
        "symbol": "C",
        "definition": "test concentration",
        "unit": null
      },
      {
        "symbol": "i",
        "definition": "selected integer sample index",
        "unit": null
      },
      {
        "symbol": "t",
        "definition": "elapsed time",
        "unit": "s"
      },
      {
        "symbol": "a",
        "definition": "positive scaling constant",
        "unit": "mmol/L"
      },
      {
        "symbol": "b",
        "definition": "positive nonzero divisor",
        "unit": "s^2"
      }
    ],
    "conditions": [
      "a > 0 and b > 0",
      "This is a fictional engineering example, not a scientific claim."
    ],
    "ranges": [
      "i = 1,2,3",
      "0 <= t <= 10 s"
    ],
    "exceptions": [
      "Do not apply outside the selected time interval."
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "passed",
    "symbol_definitions": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "native_math",
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": []
  },
  "tokens": [
    "C",
    "_",
    "i",
    "(",
    "t",
    ")",
    "=",
    "-",
    "\\frac",
    "{",
    "a",
    "}",
    "{",
    "b",
    "}",
    "t",
    "^",
    "{",
    "2",
    "}"
  ],
  "plan_fingerprint": {
    "sha256": "07958c6eab3489b237aa42336b419ddf6e2df90f9e2f047fbd88d210ff421647",
    "byte_length": 2289
  },
  "inputs": {
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "4fbab010e8618ed51cea0a2caac1aa469f2c06cbcbdc774f4f5f9bf12294cfdb",
      "byte_length": 29
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "d773957488505fa4e860fbcca7d910716569b88fc5ab44827bf6760fbec6ce6d",
      "byte_length": 715
    },
    "source-semantics.json": {
      "sha256": "44d73484c71d3a81ce98262df8a8191cc3d5309bf0f17e2368044af1b8b6e112",
      "byte_length": 842
    }
  },
  "files": [
    {
      "relative_path": "公式预览.md",
      "content_sha256": "5a334902727f34ae7c52bfb4d71d14a757c84c88aa3b45aecb93af6e2e096f5b",
      "byte_length": 1079,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 60
        },
        {
          "kind": "expression",
          "source_field": "tex",
          "start_byte": 80,
          "end_byte": 107
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[0].symbol",
          "start_byte": 162,
          "end_byte": 163
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[0].definition",
          "start_byte": 188,
          "end_byte": 206
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[0].unit",
          "start_byte": 231,
          "end_byte": 252
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[1].symbol",
          "start_byte": 291,
          "end_byte": 292
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[1].definition",
          "start_byte": 317,
          "end_byte": 346
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[1].unit",
          "start_byte": 371,
          "end_byte": 392
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[2].symbol",
          "start_byte": 431,
          "end_byte": 432
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[2].definition",
          "start_byte": 457,
          "end_byte": 469
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[2].unit",
          "start_byte": 494,
          "end_byte": 495
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[3].symbol",
          "start_byte": 534,
          "end_byte": 535
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[3].definition",
          "start_byte": 560,
          "end_byte": 585
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[3].unit",
          "start_byte": 610,
          "end_byte": 616
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[4].symbol",
          "start_byte": 655,
          "end_byte": 656
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[4].definition",
          "start_byte": 681,
          "end_byte": 705
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[4].unit",
          "start_byte": 730,
          "end_byte": 733
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[0]",
          "start_byte": 764,
          "end_byte": 779
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[1]",
          "start_byte": 793,
          "end_byte": 857
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[0]",
          "start_byte": 882,
          "end_byte": 891
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[1]",
          "start_byte": 905,
          "end_byte": 919
        },
        {
          "kind": "exception",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 944,
          "end_byte": 992
        },
        {
          "kind": "attachment_link",
          "source_field": "tex",
          "start_byte": 1015,
          "end_byte": 1041
        },
        {
          "kind": "attachment_link",
          "source_field": "region",
          "start_byte": 1043,
          "end_byte": 1077
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "9cb1d411eae868ca3765cf18b53f7642b9adc2890ca4e1d31601fdf2eb058811",
      "byte_length": 152
    },
    "compiled.tex": {
      "sha256": "ba13467e89656ca236d818e075c4c09dd5dca26dd6398ea03a7ea67dbf618733",
      "byte_length": 27
    },
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "4fbab010e8618ed51cea0a2caac1aa469f2c06cbcbdc774f4f5f9bf12294cfdb",
      "byte_length": 29
    },
    "plan.json": {
      "sha256": "07958c6eab3489b237aa42336b419ddf6e2df90f9e2f047fbd88d210ff421647",
      "byte_length": 2289
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "d773957488505fa4e860fbcca7d910716569b88fc5ab44827bf6760fbec6ce6d",
      "byte_length": 715
    },
    "source-semantics.json": {
      "sha256": "44d73484c71d3a81ce98262df8a8191cc3d5309bf0f17e2368044af1b8b6e112",
      "byte_length": 842
    },
    "公式预览.md": {
      "sha256": "5a334902727f34ae7c52bfb4d71d14a757c84c88aa3b45aecb93af6e2e096f5b",
      "byte_length": 1079
    }
  }
}
```
