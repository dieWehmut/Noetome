# 选定公式保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "f97263d0-3111-4005-a167-31aa364feae2",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "unknown_macro",
    "title": "公式保真样例 unknown_macro",
    "source_kind": "tex",
    "tex": {
      "file": "original.tex",
      "sha256": "527bdcf53998080a0c3f88f8d06f1064d6c74bd1f74e974db57ee6aea47eb29e"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "e0445343e7fd841a1972d577e2c47cd6f31c424c65e85c21ffea24428f69cd9b"
    },
    "region": {
      "file": "region.png",
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": "u = \\mystery{x}",
    "symbols": [
      {
        "symbol": "u",
        "definition": "unknown test quantity",
        "unit": null
      },
      {
        "symbol": "x",
        "definition": "test coordinate",
        "unit": "mm"
      }
    ],
    "conditions": [
      "a > 0 and b > 0",
      "This is a fictional engineering example, not a scientific claim."
    ],
    "ranges": [
      "i = 1,2,3",
      "0 <= t <= 10 s"
    ],
    "exceptions": [
      "Do not apply outside the selected time interval."
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "needs_review",
    "symbol_definitions": "needs_review",
    "semantic_review": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "formula_image",
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": []
  },
  "tokens": null,
  "plan_fingerprint": null,
  "inputs": {
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "527bdcf53998080a0c3f88f8d06f1064d6c74bd1f74e974db57ee6aea47eb29e",
      "byte_length": 16
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "cd43b52477b750589495c8006e9e6186b12d300afb4c4aa6f5e95941835221c9",
      "byte_length": 729
    },
    "source-semantics.json": {
      "sha256": "e0445343e7fd841a1972d577e2c47cd6f31c424c65e85c21ffea24428f69cd9b",
      "byte_length": 523
    }
  },
  "files": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "b64efbf5e5db564a23830728cbd8a5a01a11174148bd83f24df14103f5c08df6",
      "byte_length": 152
    },
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "527bdcf53998080a0c3f88f8d06f1064d6c74bd1f74e974db57ee6aea47eb29e",
      "byte_length": 16
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "cd43b52477b750589495c8006e9e6186b12d300afb4c4aa6f5e95941835221c9",
      "byte_length": 729
    },
    "source-semantics.json": {
      "sha256": "e0445343e7fd841a1972d577e2c47cd6f31c424c65e85c21ffea24428f69cd9b",
      "byte_length": 523
    }
  }
}
```
