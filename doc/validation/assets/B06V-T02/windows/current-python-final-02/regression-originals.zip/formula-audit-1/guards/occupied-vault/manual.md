Manual notes
