# 选定公式保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定公式/原区域工程核对；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_formula",
  "scope": "selected_formula_fidelity_v1",
  "request_id": "7ff27f3f-9f0d-4aff-975b-02ca9c27db59",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "formula_fidelity",
    "selection_id": "native",
    "title": "公式保真样例 native",
    "source_kind": "tex",
    "tex": {
      "file": "original.tex",
      "sha256": "4fbab010e8618ed51cea0a2caac1aa469f2c06cbcbdc774f4f5f9bf12294cfdb"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "c5000cb132abcb3fa9e70487530a944443df003bbdc5bac35e39f0c3e301bede"
    },
    "region": {
      "file": "region.png",
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "page": 1,
      "canvas": [
        1000,
        600
      ],
      "bounds": [
        100,
        120,
        800,
        240
      ],
      "legibility": "clear"
    },
    "data_available": false
  },
  "semantics": {
    "schema_version": 1,
    "expression": "C_i(t) = -\\frac{a}{b} t^{2}",
    "symbols": [
      {
        "symbol": "C",
        "definition": "test concentration",
        "unit": "mmol/L"
      },
      {
        "symbol": "i",
        "definition": "selected integer sample index",
        "unit": null
      },
      {
        "symbol": "t",
        "definition": "elapsed time",
        "unit": "s"
      },
      {
        "symbol": "a",
        "definition": "positive scaling constant",
        "unit": "mmol/L"
      },
      {
        "symbol": "b",
        "definition": "positive nonzero divisor",
        "unit": "s^2"
      }
    ],
    "conditions": [],
    "ranges": [
      "i = 1,2,3",
      "0 <= t <= 10 s"
    ],
    "exceptions": [
      "Do not apply outside the selected time interval."
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "expression_match": "passed",
    "symbol_definitions": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "native_math",
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": []
  },
  "tokens": [
    "C",
    "_",
    "i",
    "(",
    "t",
    ")",
    "=",
    "-",
    "\\frac",
    "{",
    "a",
    "}",
    "{",
    "b",
    "}",
    "t",
    "^",
    "{",
    "2",
    "}"
  ],
  "plan_fingerprint": {
    "sha256": "6432abf9283581b9f7063e526b509f1116981019c7ccfa9b636394fe83bd1a68",
    "byte_length": 2190
  },
  "inputs": {
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "4fbab010e8618ed51cea0a2caac1aa469f2c06cbcbdc774f4f5f9bf12294cfdb",
      "byte_length": 29
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "5d4aed1f5270b8591bcb50baa0c9dd8caaa82ad13458610bd7211914508ecda8",
      "byte_length": 715
    },
    "source-semantics.json": {
      "sha256": "c5000cb132abcb3fa9e70487530a944443df003bbdc5bac35e39f0c3e301bede",
      "byte_length": 749
    }
  },
  "files": [
    {
      "relative_path": "公式预览.md",
      "content_sha256": "ccbb3de5786ca7085cc0c635780c0d71bf608ee733d5bed2207989427089d4af",
      "byte_length": 983,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 60
        },
        {
          "kind": "expression",
          "source_field": "tex",
          "start_byte": 80,
          "end_byte": 107
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[0].symbol",
          "start_byte": 162,
          "end_byte": 163
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[0].definition",
          "start_byte": 188,
          "end_byte": 206
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[0].unit",
          "start_byte": 231,
          "end_byte": 237
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[1].symbol",
          "start_byte": 276,
          "end_byte": 277
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[1].definition",
          "start_byte": 302,
          "end_byte": 331
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[1].unit",
          "start_byte": 356,
          "end_byte": 377
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[2].symbol",
          "start_byte": 416,
          "end_byte": 417
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[2].definition",
          "start_byte": 442,
          "end_byte": 454
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[2].unit",
          "start_byte": 479,
          "end_byte": 480
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[3].symbol",
          "start_byte": 519,
          "end_byte": 520
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[3].definition",
          "start_byte": 545,
          "end_byte": 570
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[3].unit",
          "start_byte": 595,
          "end_byte": 601
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[4].symbol",
          "start_byte": 640,
          "end_byte": 641
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[4].definition",
          "start_byte": 666,
          "end_byte": 690
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[4].unit",
          "start_byte": 715,
          "end_byte": 718
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[0]",
          "start_byte": 786,
          "end_byte": 795
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[1]",
          "start_byte": 809,
          "end_byte": 823
        },
        {
          "kind": "exception",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 848,
          "end_byte": 896
        },
        {
          "kind": "attachment_link",
          "source_field": "tex",
          "start_byte": 919,
          "end_byte": 945
        },
        {
          "kind": "attachment_link",
          "source_field": "region",
          "start_byte": 947,
          "end_byte": 981
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "e802b2348cd4d7edc8ff330fdd09422784eaf857975e1b1c84c1b5891c2b01e9",
      "byte_length": 152
    },
    "compiled.tex": {
      "sha256": "ba13467e89656ca236d818e075c4c09dd5dca26dd6398ea03a7ea67dbf618733",
      "byte_length": 27
    },
    "original.png": {
      "sha256": "ee03e4bb36f52dc0c4eb604b31b751c282fc84539a805562bbc0e4c542ad2e59",
      "byte_length": 6656
    },
    "original.tex": {
      "sha256": "4fbab010e8618ed51cea0a2caac1aa469f2c06cbcbdc774f4f5f9bf12294cfdb",
      "byte_length": 29
    },
    "plan.json": {
      "sha256": "6432abf9283581b9f7063e526b509f1116981019c7ccfa9b636394fe83bd1a68",
      "byte_length": 2190
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-case.json": {
      "sha256": "5d4aed1f5270b8591bcb50baa0c9dd8caaa82ad13458610bd7211914508ecda8",
      "byte_length": 715
    },
    "source-semantics.json": {
      "sha256": "c5000cb132abcb3fa9e70487530a944443df003bbdc5bac35e39f0c3e301bede",
      "byte_length": 749
    },
    "公式预览.md": {
      "sha256": "ccbb3de5786ca7085cc0c635780c0d71bf608ee733d5bed2207989427089d4af",
      "byte_length": 983
    }
  }
}
```
