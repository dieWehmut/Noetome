$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32.SafeHandles;
namespace Noetome {
    // This narrow job contains the selected CLI after Process.Start. It is not
    // a file/network sandbox and does not remove the pre-assignment spawn window.
    public sealed class ScanInvokeJob : IDisposable {
        [StructLayout(LayoutKind.Sequential)] private struct BasicLimit {
            public long ProcessTime, JobTime; public uint Flags;
            public UIntPtr MinimumWorkingSet, MaximumWorkingSet; public uint ActiveLimit;
            public UIntPtr Affinity; public uint Priority, Scheduling;
        }
        [StructLayout(LayoutKind.Sequential)] private struct IoCounters {
            public ulong Reads, Writes, Other, ReadBytes, WriteBytes, OtherBytes;
        }
        [StructLayout(LayoutKind.Sequential)] private struct ExtendedLimit {
            public BasicLimit Basic; public IoCounters Io;
            public UIntPtr ProcessMemory, JobMemory, PeakProcessMemory, PeakJobMemory;
        }
        [StructLayout(LayoutKind.Sequential)] private struct Accounting {
            public long User, Kernel, PeriodUser, PeriodKernel;
            public uint Faults, TotalProcesses, ActiveProcesses, TerminatedProcesses;
        }
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] private static extern IntPtr CreateJobObject(IntPtr attributes, string name);
        [DllImport("kernel32.dll", SetLastError=true)] private static extern bool SetInformationJobObject(IntPtr job, int kind, ref ExtendedLimit value, uint length);
        [DllImport("kernel32.dll", SetLastError=true)] private static extern bool QueryInformationJobObject(IntPtr job, int kind, out Accounting value, uint length, IntPtr returned);
        [DllImport("kernel32.dll", SetLastError=true)] private static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
        [DllImport("kernel32.dll", SetLastError=true)] private static extern bool TerminateJobObject(IntPtr job, uint code);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
        private IntPtr handle;
        public ScanInvokeJob() {
            handle=CreateJobObject(IntPtr.Zero,null);
            if (handle==IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
            var limits=new ExtendedLimit(); limits.Basic.Flags=0x2000u;
            if (!SetInformationJobObject(handle,9,ref limits,(uint)Marshal.SizeOf(typeof(ExtendedLimit)))) {
                int error=Marshal.GetLastWin32Error(); Dispose(); throw new Win32Exception(error);
            }
        }
        public void Assign(Process process) {
            if (!AssignProcessToJobObject(handle,process.Handle)) throw new Win32Exception(Marshal.GetLastWin32Error());
        }
        public uint ActiveProcesses() {
            Accounting info;
            if (!QueryInformationJobObject(handle,1,out info,(uint)Marshal.SizeOf(typeof(Accounting)),IntPtr.Zero)) throw new Win32Exception(Marshal.GetLastWin32Error());
            return info.ActiveProcesses;
        }
        public void Terminate() {
            if (!TerminateJobObject(handle,2)) throw new Win32Exception(Marshal.GetLastWin32Error());
        }
        public bool WaitEmpty(int milliseconds) {
            var watch=Stopwatch.StartNew();
            do {
                if (ActiveProcesses()==0) return true;
                System.Threading.Thread.Sleep(20);
            } while (watch.ElapsedMilliseconds<milliseconds);
            return ActiveProcesses()==0;
        }
        public void Dispose() { if (handle!=IntPtr.Zero) { CloseHandle(handle); handle=IntPtr.Zero; } }
    }
    public static class ScanInvokeNative {
        private sealed class JsonScope {
            public bool Object, Key;
            public readonly HashSet<string> Names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }
        public static void UniqueJsonKeys(string json) {
            var stack=new Stack<JsonScope>();
            for (int i=0;i<json.Length;i++) {
                char c=json[i];
                if (c=='"') {
                    var value=new StringBuilder(); bool closed=false;
                    while (++i<json.Length) {
                        c=json[i]; if (c=='"') { closed=true; break; }
                        if (c=='\\') {
                            if (++i>=json.Length) throw new IOException("invalid-json");
                            c=json[i];
                            if (c=='u') {
                                if (i+4>=json.Length) throw new IOException("invalid-json");
                                value.Append((char)Convert.ToInt32(json.Substring(i+1,4),16)); i+=4; continue;
                            }
                            if (c=='b') c='\b'; else if (c=='f') c='\f'; else if (c=='n') c='\n';
                            else if (c=='r') c='\r'; else if (c=='t') c='\t';
                            else if (c!='"' && c!='\\' && c!='/') throw new IOException("invalid-json");
                        }
                        value.Append(c);
                    }
                    if (!closed) throw new IOException("invalid-json");
                    if (stack.Count>0 && stack.Peek().Object && stack.Peek().Key) {
                        if (!stack.Peek().Names.Add(value.ToString())) throw new IOException("duplicate-json-field");
                        stack.Peek().Key=false;
                    }
                } else if (c=='{' || c=='[') stack.Push(new JsonScope {Object=c=='{',Key=c=='{'});
                else if (c=='}' || c==']') { if (stack.Count==0) throw new IOException("invalid-json"); stack.Pop(); }
                else if (c==',' && stack.Count>0 && stack.Peek().Object) stack.Peek().Key=true;
            }
            if (stack.Count!=0) throw new IOException("invalid-json");
        }
        private static int Hex(char value) {
            if (value>='0' && value<='9') return value-'0';
            if (value>='a' && value<='f') return value-'a'+10;
            if (value>='A' && value<='F') return value-'A'+10;
            return -1;
        }
        private static bool Escape(string value, int offset, out char decoded, out int length) {
            decoded='\0'; length=0;
            if (offset+1>=value.Length || value[offset]!='\\') return false;
            switch (value[offset+1]) {
                case '"': decoded='"'; break;
                case '\\': decoded='\\'; break;
                case '/': decoded='/'; break;
                case 'b': decoded='\b'; break;
                case 'f': decoded='\f'; break;
                case 'n': decoded='\n'; break;
                case 'r': decoded='\r'; break;
                case 't': decoded='\t'; break;
                case 'u':
                    if (offset+5>=value.Length) return false;
                    int code=0;
                    for (int index=offset+2;index<offset+6;index++) {
                        int digit=Hex(value[index]); if (digit<0) return false;
                        code=code*16+digit;
                    }
                    decoded=(char)code; length=6; return true;
                default: return false;
            }
            length=2; return true;
        }
        private static string DecodeEscapes(string value, out bool changed) {
            changed=false; var result=new StringBuilder(value.Length);
            for (int offset=0;offset<value.Length;offset++) {
                char decoded; int length;
                if (Escape(value,offset,out decoded,out length)) {
                    result.Append(decoded); offset+=length-1; changed=true;
                } else result.Append(value[offset]);
            }
            return changed ? result.ToString() : value;
        }
        public static bool CredentialEchoOrUncertain(string value, string secret) {
            if (String.IsNullOrEmpty(secret)) return false;
            string normalized=secret;
            for (int round=0;round<32;round++) {
                bool changed; normalized=DecodeEscapes(normalized,out changed);
                if (!changed) break;
            }
            // Literal key escapes can decode before a mixed-depth suffix appears.
            // Compare their normalized form too; tiny escaped keys are ambiguous.
            if (normalized.Length==0 || (normalized.Length<4 && normalized!=secret)) return value.Length!=0;
            for (int offset=0;offset<normalized.Length;offset++) {
                char ignored; int length;
                if (Escape(normalized,offset,out ignored,out length)) return value.Length!=0;
            }
            string decoded=value;
            // Decode raw/mixed JSON escapes as well as nested serialized strings.
            // Check each intermediate value before its literal key escapes change.
            for (int round=0;round<32;round++) {
                if (decoded.IndexOf(secret,StringComparison.OrdinalIgnoreCase)>=0 || decoded.IndexOf(normalized,StringComparison.OrdinalIgnoreCase)>=0) return true;
                bool changed; decoded=DecodeEscapes(decoded,out changed);
                if (!changed) return false;
            }
            if (decoded.IndexOf(secret,StringComparison.OrdinalIgnoreCase)>=0 || decoded.IndexOf(normalized,StringComparison.OrdinalIgnoreCase)>=0) return true;
            // A remaining decodable layer exceeds the bound: omit the whole value.
            for (int offset=0;offset<decoded.Length;offset++) {
                char ignored; int length;
                if (Escape(decoded,offset,out ignored,out length)) return true;
            }
            return false;
        }
        [StructLayout(LayoutKind.Sequential)] private struct Info {
            public uint Attributes, CreationLow, CreationHigh, AccessLow, AccessHigh;
            public uint WriteLow, WriteHigh, VolumeSerial, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
        }
        [DllImport("kernel32.dll", SetLastError=true)] private static extern bool GetFileInformationByHandle(SafeFileHandle handle, out Info info);
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] private static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
        public static bool Ordinary(SafeFileHandle handle, bool directory) {
            Info info; if (!GetFileInformationByHandle(handle, out info)) throw new Win32Exception(Marshal.GetLastWin32Error());
            return (info.Attributes & 0x400u)==0 && ((info.Attributes & 0x10u)!=0)==directory && (directory || info.Links==1);
        }
        public static SafeFileHandle DirectoryGuard(string name) {
            var handle=CreateFile(name,0x80u,3u,IntPtr.Zero,3u,0x02200000u,IntPtr.Zero);
            if (handle.IsInvalid) throw new Win32Exception(Marshal.GetLastWin32Error());
            if (!Ordinary(handle,true)) { handle.Dispose(); throw new IOException("directory-link"); }
            return handle;
        }
        public static async Task<string> ReadBounded(Stream stream, int maximum) {
            using (var memory=new MemoryStream()) {
                var buffer=new byte[8192]; int count;
                while ((count=await stream.ReadAsync(buffer,0,buffer.Length).ConfigureAwait(false))!=0) {
                    if (memory.Length+count>maximum) throw new IOException("output-limit");
                    memory.Write(buffer,0,count);
                }
                return new UTF8Encoding(false,true).GetString(memory.ToArray());
            }
        }
    }
}
'@
$rows=@(); $root=[Noetome.ScanInvokeJob]
foreach ($n in @('BasicLimit','IoCounters','ExtendedLimit','Accounting')) {
 $t=$root.GetNestedType($n,[Reflection.BindingFlags]::NonPublic)
 $fields=@(); foreach ($f in $t.GetFields([Reflection.BindingFlags]'Public,Instance')) { $fields+=@{name=$f.Name;offset=[int][Runtime.InteropServices.Marshal]::OffsetOf($t,$f.Name);type=$f.FieldType.FullName} }
 $rows+=@{name=$n;size=[Runtime.InteropServices.Marshal]::SizeOf([Activator]::CreateInstance($t));fields=$fields}
}
$job=New-Object Noetome.ScanInvokeJob; $active=$job.ActiveProcesses(); $empty=$job.WaitEmpty(50); $job.Dispose(); $job.Dispose(); $disposedQueryRejected=$false
try {$null=$job.ActiveProcesses()} catch {$disposedQueryRejected=$true}
$src=New-Object 'System.Threading.Tasks.TaskCompletionSource[int]';$src.SetException((New-Object System.IO.IOException('public-audit-fault')))
@{powerShell=$PSVersionTable.PSVersion.ToString();pointer_size=[IntPtr]::Size;structures=$rows;fresh_job_active=$active;fresh_job_empty=$empty;double_dispose_succeeded=$true;disposed_query_rejected=$disposedQueryRejected;faulted_task=@{IsCompleted=$src.Task.IsCompleted;IsFaulted=$src.Task.IsFaulted;Status=$src.Task.Status.ToString()}}|ConvertTo-Json -Depth 8
