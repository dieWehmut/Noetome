import os,sys,unittest,json,importlib.util
from pathlib import Path
root=Path(__file__).parent
os.environ['PATH']=str(Path(os.environ['SystemRoot'])/'System32'/'WindowsPowerShell'/'v1.0')+os.pathsep+str(Path(os.environ['ProgramFiles'])/'PowerShell'/'7')+os.pathsep+os.environ['PATH']
os.environ['NOETOME_SCAN_TEST_EVIDENCE']=str(root/'evidence')
spec=importlib.util.spec_from_file_location('probe',root/'repo/tests/test_scan_api_credential.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
suite=unittest.TestSuite([m.ScanCredentials_powershell('test_parent_exit_with_inherited_pipes_is_bounded_and_descendant_terminated')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
(root/'test-result.json').write_text(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'success':result.wasSuccessful(),'real_http_calls':0}))
sys.exit(0 if result.wasSuccessful() else 1)
