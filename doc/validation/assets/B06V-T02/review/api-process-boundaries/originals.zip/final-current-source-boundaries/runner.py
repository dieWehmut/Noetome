import os,sys,unittest,json,importlib.util,platform,hashlib
from pathlib import Path
root=Path(__file__).parent
sys.stdout=open(root/'stdout.txt','w',encoding='utf-8');sys.stderr=open(root/'stderr.txt','w',encoding='utf-8')
os.environ['PATH']=str(Path(os.environ['SystemRoot'])/'System32'/'WindowsPowerShell'/'v1.0')+os.pathsep+r'C:\Users\Lyinn\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell'+os.pathsep+os.environ['PATH']
os.environ['NOETOME_SCAN_TEST_EVIDENCE']=str(root/'evidence')
spec=importlib.util.spec_from_file_location('probe',root/'repo/tests/test_scan_api_credential.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
names=['test_parent_exit_with_inherited_pipes_is_bounded_and_descendant_terminated','test_live_parent_and_descendant_timeout_preserves_pending_budget','test_output_limit_terminates_observed_tree_and_retains_failure_receipt']
suite=unittest.TestSuite([getattr(m,cls)(name) for cls in ['ScanCredentials_powershell','ScanCredentials_pwsh'] for name in names])
result=unittest.TextTestRunner(verbosity=2).run(suite)
(root/'test-result.json').write_text(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'success':result.wasSuccessful(),'real_http_calls':0,'python':sys.version,'platform':platform.platform(),'test_ids':[cls+'.'+name for cls in ['ScanCredentials_powershell','ScanCredentials_pwsh'] for name in names],'source_binding_after':[{'path':x['path'],'sha256':hashlib.sha256((root/'repo'/x['path']).read_bytes()).hexdigest()} for x in json.loads((root/'source.json').read_bytes())]}))
sys.exit(0 if result.wasSuccessful() else 1)
