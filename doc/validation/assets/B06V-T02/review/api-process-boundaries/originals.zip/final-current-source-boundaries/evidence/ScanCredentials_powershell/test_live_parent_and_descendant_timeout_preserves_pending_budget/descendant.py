import json,os,time
from pathlib import Path
Path('descendant-started.json').write_text(json.dumps({'pid':os.getpid(),'parent_pid':os.getppid()}))
time.sleep(180)
