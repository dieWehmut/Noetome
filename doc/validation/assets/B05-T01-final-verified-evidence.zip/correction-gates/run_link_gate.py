from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[3]
LABEL = sys.argv[1]
COMMANDS = {
    'red': [sys.executable, '-X', 'utf8', '-m', 'unittest', 'test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_rereview_duplicate_support_cannot_inflate_evidence', '-v'],
    'green': [sys.executable, '-X', 'utf8', '-m', 'unittest', 'test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_rereview_duplicate_support_cannot_inflate_evidence', 'test_knowledge_coordination_verifier.CoordinationVerifierTests.test_final_review_support_link_order_is_preserved', '-v'],
    'module': [sys.executable, '-X', 'utf8', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_knowledge_coordination_verifier.py', '-v'],
    'full': [sys.executable, '-X', 'utf8', '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py'],
    'audit': [sys.executable, '-X', 'utf8', str(REPO / 'scripts/verify_knowledge_coordination.py'), 'audit', str(REPO / 'target/debug/noetome.exe'), str(REPO / 'target/compiler-temp/b05-t01-link-fixed-audit-a21963d8eaf94c648cac483ea62e1cf3')],
}

def fp(path):
    raw = Path(path).read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

source_names = list(json.loads((REPO / '.superpowers/sdd/B05-T01_COORDINATION_PLAN/root-final-python-01-receipt.json').read_bytes())['source_files_before'])
source_before = {name: fp(REPO / name) for name in source_names}
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
record = {'schema_version': 1, 'label': LABEL, 'started_at_utc': datetime.now(timezone.utc).isoformat(),
          'argv': COMMANDS[LABEL], 'cwd': str(REPO), 'head_before': head, 'source_files_before': source_before,
          'cli_before': fp(REPO / 'target/debug/noetome.exe')}
environment = dict(os.environ, PYTHONPATH=str(REPO / 'tests'), NOETOME_TEST_PYTHON=sys.executable, NOETOME_PDF_PYTHON=sys.executable)
record['runtime'] = {key: environment.get(key) for key in ('TEMP', 'TMP', 'NOETOME_TEST_PYTHON', 'NOETOME_PDF_PYTHON')}
print('START ' + LABEL, flush=True)
started = time.monotonic()
result = subprocess.run(COMMANDS[LABEL], cwd=REPO, env=environment, capture_output=True, timeout=240)
record.update(elapsed_seconds=time.monotonic()-started, exit_code=result.returncode)
for role, raw in (('stdout', result.stdout), ('stderr', result.stderr)):
    path = ROOT / (LABEL + '-' + role + '.txt')
    with path.open('xb') as stream:
        stream.write(raw)
    record[role] = {'path': str(path), **fp(path)}
record['source_files_after'] = {name: fp(REPO / name) for name in source_names}
record['source_unchanged'] = record['source_files_before'] == record['source_files_after']
record['cli_after'] = fp(REPO / 'target/debug/noetome.exe')
record['head_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
with (ROOT / (LABEL + '-receipt.json')).open('x', encoding='utf-8') as stream:
    json.dump(record, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(result.stdout.decode('utf-8', 'replace')[-3000:])
print(result.stderr.decode('utf-8', 'replace')[-7500:])
print(json.dumps({key: record[key] for key in ('label', 'exit_code', 'source_unchanged', 'elapsed_seconds')}))
assert record['source_unchanged'] and record['cli_before'] == record['cli_after']
raise SystemExit(result.returncode)
