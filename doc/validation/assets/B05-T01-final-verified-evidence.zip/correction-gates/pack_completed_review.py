from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from datetime import datetime, timezone
import hashlib, json, re, subprocess, sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[3]
REVIEW = REPO / 'target/compiler-temp/b05-t01-final-rereview-a21963d8eaf94c648cac483ea62e1cf3'
AUDIT = REPO / 'target/compiler-temp/b05-t01-link-fixed-audit-a21963d8eaf94c648cac483ea62e1cf3'
ASSETS = REPO / 'doc/validation/assets'
expected_report_sha = sys.argv[1]
assert re.fullmatch('[a-f0-9]{64}', expected_report_sha)

def fp(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}

def write_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')

report = (REVIEW / 'final-rereview-report.md').read_bytes()
assert fp(report)['sha256'] == expected_report_sha
with (ASSETS / 'B05-T01-final-rereview-1.md').open('xb') as stream:
    stream.write(report)
assert (REVIEW / 'final-rereview-report.md').read_bytes() == report
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
assert head == '2618752028557d15e8fb5a1828f243cf3f25f935'
final = json.loads((ROOT / 'full-receipt.json').read_bytes())
for name, pin in final['source_files_after'].items():
    assert fp((REPO / name).read_bytes()) == pin, name
assert fp((REPO / 'target/debug/noetome.exe').read_bytes()) == final['cli_after']
runtime = {'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(), 'product_head': head,
           'status': 'verification_passed_ready_for_task_completion', 'final_source_files': final['source_files_after'],
           'final_cli_fingerprint': final['cli_after'], 'rust': {'passed': 561, 'unchanged_dependency_files_reused': 152},
           'python_module_tests': 35, 'python_full_tests': 143, 'ordinary_audit': {'scenarios': 33, 'commands': 56, 'protected_groups': 29},
           'rereview': {'original_findings_addressed': 5, 'introduced_duplicate_pair_finding_addressed': True, 'original_targeted_scenarios': 11, 'original_targeted_commands': 24, 'introduced_probe_commands': 3, 'correction_check_commands': 2, 'final_report': fp(report)},
           'scope': 'Self-authored Text coordination. Original failures and interim NO remain preserved. Scientific quality not_run, research not_requested, unpublished; no new PDF/scientific/cross-platform/performance claim.',
           'task_log_and_git_push': 'Executed after evidence packaging; this record does not preclaim a task status change or remote push.'}
write_new(ROOT / 'final-verified-runtime.json', runtime)
with (ASSETS / 'B05-T01-final-verified-runtime.json').open('xb') as stream:
    stream.write((ROOT / 'final-verified-runtime.json').read_bytes())
members = {}
def add(path, name):
    assert name not in members
    st = path.stat()
    members[name] = {'source': str(path), **fp(path.read_bytes()), 'identity': [st.st_dev, st.st_ino], 'mtime_ns': st.st_mtime_ns, 'link_count': st.st_nlink}
def tree(path, prefix):
    for child in sorted(path.iterdir()):
        st = child.lstat()
        assert not child.is_symlink() and not getattr(st, 'st_file_attributes', 0) & 0x400
        if child.is_dir():
            tree(child, prefix + '/' + child.name)
        elif child.is_file():
            add(child, prefix + '/' + child.name)
        else:
            raise AssertionError('nonordinary selected artifact')
tree(ROOT, 'correction-gates')
tree(AUDIT, 'latest-ordinary-audit')
tree(REVIEW, 'bounded-rereview')
red_stderr = (ROOT / 'red-stderr.txt').read_text(encoding='utf-8')
red_root = Path(re.search(r'AssertionError not raised : root=([^\r\n]+)', red_stderr).group(1))
assert red_root.name.startswith('noetome-coordination-verifier-')
tree(red_root, 'actual-duplicate-pair-red')
boundary = json.loads((REPO / '.superpowers/sdd/B05-T01_COORDINATION_PLAN/final-fix-13fb5f0be4ec46beabc94220b55c078d/rust-boundary-root-inspection.json').read_bytes())
external = {}
for item in boundary['roots']:
    before = json.loads((REPO / item['root'] / 'protection-before.json').read_bytes())
    for name, pin in before.items():
        path = Path(name.removeprefix('\\\\?\\'))
        if path.parent == REPO / 'target/compiler-temp' and path.name.startswith('coordination-external-sentinel-'):
            assert fp(path.read_bytes()) == pin
            external[path] = pin
assert len(external) == 12
for path in sorted(external):
    add(path, 'previous-controller-boundary-sentinels/' + path.name)
audit = json.loads((AUDIT / 'audit.json').read_bytes())
for name in audit['protected_after']:
    path = Path(name)
    if path.is_file() and path.name.startswith('coordination-sentinel-'):
        add(path, 'latest-audit-external-sentinel/' + path.name)
receipt_path = ROOT / 'completed-review-package-receipt.json'
write_new(receipt_path, {'schema_version': 1, 'product_head': head, 'original_member_count': len(members), 'original_members': members,
                         'scope': runtime['scope'], 'no_product_cli_or_model_calls_during_archive': True,
                         'previous_controller_sentinel_count': len(external), 'limits': 'ZIP preserves raw bytes; original filesystem identities and link counts are recorded, not recreated by ZIP.'})
add(receipt_path, 'correction-gates/completed-review-package-receipt.json')
archive = ASSETS / 'B05-T01-final-verified-evidence.zip'
with ZipFile(archive, 'x', ZIP_DEFLATED, compresslevel=9) as zip_file:
    for name, pin in sorted(members.items()):
        raw = Path(pin['source']).read_bytes()
        assert fp(raw) == {key: pin[key] for key in ('sha256', 'byte_length')}
        zip_file.writestr(name, raw)
with ZipFile(archive) as zip_file:
    assert zip_file.testzip() is None and set(zip_file.namelist()) == set(members)
    for name, pin in members.items():
        assert fp(zip_file.read(name)) == {key: pin[key] for key in ('sha256', 'byte_length')}
        path = Path(pin['source']); st = path.stat()
        assert fp(path.read_bytes()) == {key: pin[key] for key in ('sha256', 'byte_length')}
        assert [st.st_dev, st.st_ino] == pin['identity'] and st.st_mtime_ns == pin['mtime_ns'] and st.st_nlink == pin['link_count']
manifest = {'schema_version': 1, 'archive': archive.relative_to(REPO).as_posix(), **fp(archive.read_bytes()), 'member_count': len(members),
            'members': members, 'original_selected_files_unchanged': True, 'no_product_cli_or_model_calls_during_archive': True, 'scope': runtime['scope']}
write_new(ASSETS / 'B05-T01-final-verified-evidence-manifest.json', manifest)
print(json.dumps({key: value for key, value in manifest.items() if key != 'members'}, ensure_ascii=False))
