# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

显式身份重复／互补范围；完整来源、原对象、证据与分母见以下事实，与 coordination.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "99e1c9c3-3117-4b27-958a-0476d7c37637",
  "scope": "explicit_identity_duplicate_complement_v1",
  "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "display_name": "速度"
    },
    {
      "canonical_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "display_name": "质量"
    },
    {
      "canonical_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "display_name": "样例 A"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
        "import_id": "8571807c-1dad-424d-8474-6d3dd5248787",
        "source_id": "7daca3d3-3bc2-42a2-a1af-a822d229d7ac",
        "version_id": "d5b038e2-89a8-4a98-b71e-bb7562001b68",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "8571807c-1dad-424d-8474-6d3dd5248787",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
              "source_id": "7daca3d3-3bc2-42a2-a1af-a822d229d7ac",
              "version_id": "d5b038e2-89a8-4a98-b71e-bb7562001b68"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "8571807c-1dad-424d-8474-6d3dd5248787",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
              "source_id": "7daca3d3-3bc2-42a2-a1af-a822d229d7ac",
              "version_id": "d5b038e2-89a8-4a98-b71e-bb7562001b68"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "975509b2c70d45100fbac27b2bcda42fc1c4961ffe1e9ec9c75fd82a4056eecf",
          "byte_length": 2979
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
          "byte_length": 727
        },
        "knowledge-ir.json": {
          "sha256": "012473e24e2d513b80f711d9c0f1702631496f6513f33750c0618bd073dae31b",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "046b6e21d9de4f62c4c8308ab7cb94aa88c0e840dd12edfa23dd16b06b9ef8a9",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "fcbaebdf743ebd3c208d748c2d350ffd395eff9250d50d6ec779bff01977fc7a",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "0fc940fef468a426c9b5531641364b5b61a3ab0045baa45e9c6624c1a1ea2a3d",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
        "import_id": "0d78819f-9c59-426e-b0e1-c7db830a266e",
        "source_id": "4a06b718-2683-4667-bea1-d21c1b94ed59",
        "version_id": "dec9490f-4489-45d6-aa15-c53ffb821e6d",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "0d78819f-9c59-426e-b0e1-c7db830a266e",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
              "source_id": "4a06b718-2683-4667-bea1-d21c1b94ed59",
              "version_id": "dec9490f-4489-45d6-aa15-c53ffb821e6d"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "0d78819f-9c59-426e-b0e1-c7db830a266e",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
              "source_id": "4a06b718-2683-4667-bea1-d21c1b94ed59",
              "version_id": "dec9490f-4489-45d6-aa15-c53ffb821e6d"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "d1551637f2c30a86655dfa2d6586daa0a6d6c7628bf4733d94862a5b21bc7b35",
          "byte_length": 2979
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
          "byte_length": 727
        },
        "knowledge-ir.json": {
          "sha256": "9e2b85d7e78644fd8681b315f65a4e91914c07c8e5f062506a645245eb1f69dc",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "923d97cfaf86b7f268bd0b0919b9249bbbd750cd26ce836ea0a676751d6cf31a",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "0de250cffdf889310cadea183a5932ca5075e8c26f03bb6c883b92112eaf03b4",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "b362fe5f775e376ede30b6a14657c0bff756ecad4b187c3a9e6850eb3f810c6c",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
        "import_id": "c639deac-b1fe-4d74-885a-33cb7bc655b1",
        "source_id": "7ad52c04-4c5c-47b6-a9ac-7970dc48124d",
        "version_id": "83054015-6f5a-46ad-9ce7-f707c22e1d94",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "c639deac-b1fe-4d74-885a-33cb7bc655b1",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
              "source_id": "7ad52c04-4c5c-47b6-a9ac-7970dc48124d",
              "version_id": "83054015-6f5a-46ad-9ce7-f707c22e1d94"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "c639deac-b1fe-4d74-885a-33cb7bc655b1",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
              "source_id": "7ad52c04-4c5c-47b6-a9ac-7970dc48124d",
              "version_id": "83054015-6f5a-46ad-9ce7-f707c22e1d94"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 104,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 105,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 104,
            "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 104,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 104,
              "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "4a706fbf42c0483696f9b686a9dceca485c0c4d3e73c3e0775c3152d0b4b945f",
          "byte_length": 2971
        },
        "decision-original.json": {
          "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "470a34066224aa9c499ea0fa4be0ce66ce86a5be3efad7496037f4bdf4f2ae63",
          "byte_length": 721
        },
        "knowledge-ir.json": {
          "sha256": "c6d7c07139a50506c598edddd9a0c8727367583b0f8c381361b2fd1ae87b0e91",
          "byte_length": 12036
        },
        "review-original.json": {
          "sha256": "1ed0986c4e18951a7f1eb24ea315d841b99896d28b890bc69eda33aba47c1fe4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "a422dc7e67215fc6077f7693dd0f0c8d98615b11db2bb8c358070e910618738a",
          "byte_length": 994
        },
        "verification.json": {
          "sha256": "a1ad3587508e1510ca7edc89ab46a72e5604f6b02b3d81b6f2796d4c0592d39e",
          "byte_length": 16533
        },
        "verification.md": {
          "sha256": "298c19d9f6b876bb1ba14af85dad2d97282aa1a20ccca6ea79b30c42fa3831c1",
          "byte_length": 16967
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "occurrence_id": "occ-06c5d402f24362f486370b06de9fcbb20c1411e216dbfe0c517e20eaa5ffe563",
      "input_id": "b",
      "binding": {
        "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
        "import_id": "0d78819f-9c59-426e-b0e1-c7db830a266e",
        "source_id": "4a06b718-2683-4667-bea1-d21c1b94ed59",
        "version_id": "dec9490f-4489-45d6-aa15-c53ffb821e6d",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f443d540-7fda-4eee-8ed0-e4032bc5cb14",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-20c79789d73bacd3b1f7643a5e5cab9bb257dbf2c775d51933a73a743cc7a1ff",
      "input_id": "c",
      "binding": {
        "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
        "import_id": "c639deac-b1fe-4d74-885a-33cb7bc655b1",
        "source_id": "7ad52c04-4c5c-47b6-a9ac-7970dc48124d",
        "version_id": "83054015-6f5a-46ad-9ce7-f707c22e1d94",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a800fd4e-6e9e-45cc-8eb1-1022e8e8e8e7",
          "ordinal": 0,
          "resource_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 105,
        "text": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 104,
          "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
          "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "51fa59a0-255f-4867-836c-aa39bdc01906",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-c311aa0ba990bb3865dc20dd76f854ec1b88b57b5ed7bc2ce228cb12a2488425",
      "input_id": "a",
      "binding": {
        "project_id": "bf3157a2-b4c4-47c7-baa8-cbc5ce07effa",
        "import_id": "8571807c-1dad-424d-8474-6d3dd5248787",
        "source_id": "7daca3d3-3bc2-42a2-a1af-a822d229d7ac",
        "version_id": "d5b038e2-89a8-4a98-b71e-bb7562001b68",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "e6c8090f-1912-4ff2-8e26-e2353cb4ea4d",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "fact_id": "fact-2176d0ef755e6f1de61cf485f79a5805b933ddc9487e83fcd12064c305a175a4",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-06c5d402f24362f486370b06de9fcbb20c1411e216dbfe0c517e20eaa5ffe563",
        "occ-c311aa0ba990bb3865dc20dd76f854ec1b88b57b5ed7bc2ce228cb12a2488425"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "fact_id": "fact-6bc62067e5e15c97430ccb915d046434ef2b5edab41254cf60e7ef28f896d03b",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-20c79789d73bacd3b1f7643a5e5cab9bb257dbf2c775d51933a73a743cc7a1ff"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "left_occurrence_id": "occ-06c5d402f24362f486370b06de9fcbb20c1411e216dbfe0c517e20eaa5ffe563",
      "right_occurrence_id": "occ-20c79789d73bacd3b1f7643a5e5cab9bb257dbf2c775d51933a73a743cc7a1ff",
      "relation": "complement",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-06c5d402f24362f486370b06de9fcbb20c1411e216dbfe0c517e20eaa5ffe563",
      "right_occurrence_id": "occ-c311aa0ba990bb3865dc20dd76f854ec1b88b57b5ed7bc2ce228cb12a2488425",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-20c79789d73bacd3b1f7643a5e5cab9bb257dbf2c775d51933a73a743cc7a1ff",
      "right_occurrence_id": "occ-c311aa0ba990bb3865dc20dd76f854ec1b88b57b5ed7bc2ce228cb12a2488425",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "totals": {
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 2,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "ff0480a9489ffd24f4222a3a44c18409d06ea86315434aff8538ec606302b956",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "732db3384b1565754c7cce11be457b82e2fccfe8354a620ce3829ac35e62d043",
      "byte_length": 55920
    },
    "coordination-original.json": {
      "sha256": "e9303ebaafb956c46a4d0bf478ef6720fb30c742de118eab9cda21d116a6e7f4",
      "byte_length": 6404
    },
    "identity-original.json": {
      "sha256": "419d4155e834d9774b862516ffddc125a381c2c6cf36f35cc02cc1992d492048",
      "byte_length": 1616
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "975509b2c70d45100fbac27b2bcda42fc1c4961ffe1e9ec9c75fd82a4056eecf",
      "byte_length": 2979
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
      "byte_length": 727
    },
    "input-a--knowledge-ir.json": {
      "sha256": "012473e24e2d513b80f711d9c0f1702631496f6513f33750c0618bd073dae31b",
      "byte_length": 12081
    },
    "input-a--review-original.json": {
      "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "046b6e21d9de4f62c4c8308ab7cb94aa88c0e840dd12edfa23dd16b06b9ef8a9",
      "byte_length": 996
    },
    "input-a--verification.json": {
      "sha256": "fcbaebdf743ebd3c208d748c2d350ffd395eff9250d50d6ec779bff01977fc7a",
      "byte_length": 16573
    },
    "input-a--verification.md": {
      "sha256": "0fc940fef468a426c9b5531641364b5b61a3ab0045baa45e9c6624c1a1ea2a3d",
      "byte_length": 17007
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "d1551637f2c30a86655dfa2d6586daa0a6d6c7628bf4733d94862a5b21bc7b35",
      "byte_length": 2979
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
      "byte_length": 727
    },
    "input-b--knowledge-ir.json": {
      "sha256": "9e2b85d7e78644fd8681b315f65a4e91914c07c8e5f062506a645245eb1f69dc",
      "byte_length": 12081
    },
    "input-b--review-original.json": {
      "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "923d97cfaf86b7f268bd0b0919b9249bbbd750cd26ce836ea0a676751d6cf31a",
      "byte_length": 996
    },
    "input-b--verification.json": {
      "sha256": "0de250cffdf889310cadea183a5932ca5075e8c26f03bb6c883b92112eaf03b4",
      "byte_length": 16573
    },
    "input-b--verification.md": {
      "sha256": "b362fe5f775e376ede30b6a14657c0bff756ecad4b187c3a9e6850eb3f810c6c",
      "byte_length": 17007
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "4a706fbf42c0483696f9b686a9dceca485c0c4d3e73c3e0775c3152d0b4b945f",
      "byte_length": 2971
    },
    "input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    "input-c--gold-original.json": {
      "sha256": "470a34066224aa9c499ea0fa4be0ce66ce86a5be3efad7496037f4bdf4f2ae63",
      "byte_length": 721
    },
    "input-c--knowledge-ir.json": {
      "sha256": "c6d7c07139a50506c598edddd9a0c8727367583b0f8c381361b2fd1ae87b0e91",
      "byte_length": 12036
    },
    "input-c--review-original.json": {
      "sha256": "1ed0986c4e18951a7f1eb24ea315d841b99896d28b890bc69eda33aba47c1fe4",
      "byte_length": 510
    },
    "input-c--source-snapshot.json": {
      "sha256": "a422dc7e67215fc6077f7693dd0f0c8d98615b11db2bb8c358070e910618738a",
      "byte_length": 994
    },
    "input-c--verification.json": {
      "sha256": "a1ad3587508e1510ca7edc89ab46a72e5604f6b02b3d81b6f2796d4c0592d39e",
      "byte_length": 16533
    },
    "input-c--verification.md": {
      "sha256": "298c19d9f6b876bb1ba14af85dad2d97282aa1a20ccca6ea79b30c42fa3831c1",
      "byte_length": 16967
    }
  }
}
```
