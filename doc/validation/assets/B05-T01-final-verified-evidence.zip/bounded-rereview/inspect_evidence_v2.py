from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import zipfile

REPO = Path('D:/Noetome')
ROOT = Path(__file__).resolve().parent
FIX = REPO / '.superpowers/sdd/B05-T01_COORDINATION_PLAN/final-fix-13fb5f0be4ec46beabc94220b55c078d'
ASSETS = REPO / 'doc/validation/assets'
BASE = 'f76496ad87b163603471dfc98b362bd2bd2895a9'
HEAD = 'ae2858031f947ef22e28328af2b094b498106f32'
CLI = REPO / 'target/debug/noetome.exe'


def fp_bytes(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'byte_length': len(data)}


def fp(path):
    return fp_bytes(Path(path).read_bytes())


def new_bytes(path, data):
    path = Path(path)
    assert path.resolve().is_relative_to(ROOT), path
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def new_json(path, data):
    new_bytes(path, (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))


def inventory(path):
    path = Path(path)
    result = {}
    def visit(p):
        s = p.lstat()
        assert not p.is_symlink() and not getattr(s, 'st_file_attributes', 0) & 0x400, p
        name = p.relative_to(path).as_posix() if p != path else '.'
        entry = {'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns,
                 'kind': 'directory' if p.is_dir() else 'file', 'size': s.st_size}
        if p.is_file():
            assert s.st_nlink == 1, p
            entry.update(fp(p))
        else:
            assert p.is_dir(), p
        result[name] = entry
        if p.is_dir():
            for child in sorted(p.iterdir()):
                visit(child)
    visit(path)
    return result


def git(*args):
    run = subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True)
    return run.stdout


def source_files(manifest):
    return {name: fp(REPO / name) for name in manifest['source_files']}


def stream_checks(receipt):
    checked = {}
    for stream in ('stdout', 'stderr'):
        declared = receipt[stream]
        path = Path(declared['path'])
        assert path.resolve().is_relative_to(FIX), path
        observed = fp(path)
        assert observed == {k: declared[k] for k in ('sha256', 'byte_length')}, (path, observed)
        checked[stream] = {'path': str(path), **observed}
    return checked


def main():
    manifest = json.loads((FIX / 'final-fix-manifest.json').read_bytes())
    assert manifest['base'] == BASE and manifest['head'] == HEAD
    expected_cli = {'sha256': '2016a13f7bd23e86df5f4b2500b2eb45059fa7dd35157f9b4f1041c8a42b4efd', 'byte_length': 17975296}
    assert fp(CLI) == manifest['cli_fingerprint'] == expected_cli
    assert fp(FIX / 'final-fix.patch') == manifest['patch_fingerprint']
    assert manifest['patch_fingerprint']['sha256'] == '21b8a14011cb1178b194cda9e9260b1c29ae3826b456d76fd960a29f615f5882'
    actual_sources = source_files(manifest)
    assert actual_sources == manifest['source_files']
    assert len(actual_sources) == 154
    changed_product = git('diff', '--name-only', HEAD, '--', 'crates', 'scripts', 'tests', 'Cargo.toml', 'Cargo.lock').decode('utf-8')
    assert not changed_product, changed_product
    pinned_diff = git('diff', '--binary', BASE, HEAD)
    patch_equals_git = pinned_diff == (FIX / 'final-fix.patch').read_bytes()
    protected = {
        'probe_zip': inventory(ASSETS / 'B05-T01-final-review-probes.zip'),
        'probe_manifest': inventory(ASSETS / 'B05-T01-final-review-probes-manifest.json'),
        'original_review': inventory(ASSETS / 'B05-T01-final-review.md'),
        'fixed_evidence': inventory(FIX),
    }
    snapshot = dict(schema_version=1, captured_at=datetime.now(timezone.utc).isoformat(),
                    branch=git('branch', '--show-current').decode().strip(),
                    head=git('rev-parse', 'HEAD').decode().strip(),
                    git_status=git('status', '--short').decode('utf-8'),
                    source_files=actual_sources, cli=fp(CLI), protected=protected,
                    user_deletions={name: (REPO / name).exists() for name in ('docs/Noetome-PRD-v1.0.html', 'docs/Noetome-PRD-v1.0.md')})
    assert not any(snapshot['user_deletions'].values())
    new_json(ROOT / 'review-before-2.json', snapshot)

    receipts = {}
    green_labels = ['rust-fmt', 'rust-check', 'rust-workspace', 'python-module', 'python-full', 'python-audit',
                    'rust-owner-green', 'rust-author-green', 'python-role-green', 'python-support-green', 'python-schema-green']
    red_labels = ['rust-red', 'rust-corrected-red', 'python-schema-red', 'python-final-review-red']
    for label in green_labels + red_labels:
        receipt = json.loads((FIX / (label + '-receipt.json')).read_bytes())
        streams = stream_checks(receipt)
        before, after = receipt['source_files_before'], receipt['source_files_after']
        assert before == after, label
        assert receipt['source_unchanged'] is True, label
        if label in green_labels:
            assert receipt['exit_code'] == 0, (label, receipt['exit_code'])
            if label in green_labels[:6]:
                assert before == actual_sources, label
        else:
            assert receipt['exit_code'] != 0, label
        stdout = Path(receipt['stdout']['path']).read_text(encoding='utf-8')
        stderr = Path(receipt['stderr']['path']).read_text(encoding='utf-8')
        combined = stdout + '\n' + stderr
        suite_rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)
        counts = {'suites': len(suite_rows), 'passed': sum(int(row[1]) for row in suite_rows),
                  'failed': sum(int(row[2]) for row in suite_rows), 'ignored': sum(int(row[3]) for row in suite_rows)} if suite_rows else None
        receipts[label] = dict(argv=receipt['argv'], exit_code=receipt['exit_code'], streams=streams,
                               sources_checked=len(before), unchanged=True, current_source_differences=[key for key in actual_sources if actual_sources[key] != before[key]], rust_counts=counts,
                               python_ran=re.findall(r'Ran (\d+) tests? in', combined),
                               raw_failure_lines=[line for line in combined.splitlines()
                                                  if any(token in line for token in ('FAIL:', 'FAILED', 'left:', 'right:', 'AssertionError:'))],
                               final_lines=combined.splitlines()[-12:], cli_before=receipt['cli_before'], cli_after=receipt['cli_after'])
    assert receipts['rust-workspace']['rust_counts'] == {'suites': 16, 'passed': 561, 'failed': 0, 'ignored': 0}
    assert receipts['python-module']['python_ran'] == ['34']
    assert receipts['python-full']['python_ran'] == ['142']
    assert receipts['rust-corrected-red']['rust_counts']['failed'] == 3
    assert receipts['python-full']['cli_before'] != receipts['python-full']['cli_after']

    audit_root = REPO / 'target/compiler-temp/b05-t01-final-fixed-audit-final-fix-13fb5f0be4ec46beabc94220b55c078d'
    audit = json.loads((audit_root / 'audit.json').read_bytes())
    assert audit['scenario_count'] == len(audit['scenarios']) == 33
    assert audit['command_count'] == len(audit['calls']) == 56
    assert audit['cli_fingerprint'] == expected_cli
    assert audit['network_calls'] == audit['paid_calls'] == 0
    assert audit['protected_before'] == audit['protected_after'] and audit['protection_passed'] is True
    stream_count = 0
    for call in audit['calls']:
        assert call['exit_code'] == call['expected_exit'], call['name']
        assert call['argv'][0] == str(CLI)
        for kind in ('stdout', 'stderr'):
            saved = call[kind]
            path = Path(saved['path'])
            assert path.resolve().is_relative_to(audit_root), path
            assert fp(path) == {k: saved[k] for k in ('sha256', 'byte_length')}, path
            stream_count += 1
        expected_receipt_path = audit_root / (f"command-{call['index']:03d}-" + call['name'] + '.json')
        assert json.loads(expected_receipt_path.read_bytes()) == call
    # Reuse only the verifier's ordinary filesystem inventory helper, not its knowledge oracle.
    import sys
    sys.path.insert(0, str(REPO / 'scripts'))
    from verify_knowledge_coordination import inventory as audit_inventory
    actual_audit_protected = {}
    for name, before in audit['protected_before'].items():
        path = Path(name)
        actual = audit_inventory(path) if path.is_dir() else fp(path)
        assert actual == before, name
        actual_audit_protected[name] = actual
    assert len(actual_audit_protected) == 29

    original_zip = ASSETS / 'B05-T01-final-review-probes.zip'
    original_zip_fp = fp(original_zip)
    assert original_zip_fp == {'sha256': '9163f306bb515f5fa1e98c9e3e463e48e8655424a47d45dc2067b8054da0dd20', 'byte_length': 817152}
    copied_zip = ROOT / 'archives/final-review-probes.zip'
    new_bytes(copied_zip, original_zip.read_bytes())
    assert fp(copied_zip) == original_zip_fp
    probe_manifest = json.loads((ASSETS / 'B05-T01-final-review-probes-manifest.json').read_bytes())
    print('probe_manifest_keys=' + json.dumps(list(probe_manifest)))
    listed = probe_manifest.get('members', probe_manifest.get('files'))
    assert type(listed) is list and len(listed) == 598
    expected_members = {entry['member']: {key: entry[key] for key in ('sha256', 'byte_length')} for entry in listed}
    with zipfile.ZipFile(copied_zip) as archive:
        entries = archive.infolist()
        assert len(entries) == 598 and len({e.filename for e in entries}) == 598
        assert archive.testzip() is None
        for entry in entries:
            relative = PurePosixPath(entry.filename)
            assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in entry.filename and ':' not in entry.filename
            assert not entry.is_dir() and (entry.external_attr >> 16) & 0o170000 != 0o120000
            data = archive.read(entry)
            assert fp_bytes(data) == expected_members[entry.filename], entry.filename
            new_bytes(ROOT / 'pristine-probes' / Path(*relative.parts), data)
    print('public_prefixes=' + json.dumps(dict(Counter(e.filename.split('/')[0] for e in entries)), ensure_ascii=False))
    print('support_order_layout=' + json.dumps([e.filename for e in entries if e.filename.startswith('support-order/')], ensure_ascii=False))
    print('schema3_text_layout=' + json.dumps([e.filename for e in entries if e.filename.startswith('schema3-text/')], ensure_ascii=False))
    result = dict(schema_version=1, range={'base': BASE, 'head': HEAD}, current_product_matches_head=True,
                  source_files_checked=154, source_files_match_fix_manifest=True, cli=expected_cli,
                  fix_patch=manifest['patch_fingerprint'], patch_bytes_equal_git_diff=patch_equals_git,
                  git_diff_fingerprint=fp_bytes(pinned_diff), receipts=receipts,
                  audit={'scenarios': 33, 'commands': 56, 'command_stream_hashes': stream_count,
                         'protected_groups_checked': len(actual_audit_protected), 'actual_originals_match': True,
                         'audit_file': str(audit_root / 'audit.json'), 'audit_fingerprint': fp(audit_root / 'audit.json')},
                  probe_zip={'fingerprint': original_zip_fp, 'members_checked': len(entries), 'crc': 'all_passed'},
                  caveat='Python full and Cargo ran concurrently; Python full CLI changed through normal rebuild. Source fingerprints stayed fixed.')
    new_json(ROOT / 'evidence-inspection.json', result)
    new_json(ROOT / 'pristine-inventory.json', inventory(ROOT / 'pristine-probes'))
    print('INSPECTION_OK ' + json.dumps({'sources': 154, 'rust': 561, 'python': 142, 'audit_scenarios': 33, 'probe_members': 598}))


if __name__ == '__main__':
    main()
