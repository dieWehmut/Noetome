from pathlib import Path
import json

import run_probes as probes
from inspect_evidence_v2 import ROOT, inventory, new_json, fp


def main():
    initial = probes.read_json(ROOT / 'probe-group-1.json')
    probes.ROWS.extend(initial['scenarios'])
    receipts = sorted((ROOT / 'commands').glob('*.receipt.json'))
    assert len(receipts) == 18
    parsed = {}
    for receipt_path in receipts:
        r = probes.read_json(receipt_path)
        assert r['protection_unchanged'] and r['protected_before'] == r['protected_after']
        assert r['exit_code'] == r['expected_exit']
        assert r['code_before'] == r['code_after'] == probes.PIN['source_files']
        assert r['cli_before'] == r['cli_after'] == probes.FIXED_CLI
        for name in ('stdout', 'stderr'):
            assert fp(r[name]['path']) == {k: r[name][k] for k in ('sha256', 'byte_length')}
        probes.CALLS.append({key: r[key] for key in ('index', 'label', 'argv', 'exit_code', 'expected_exit', 'stdout', 'stderr')} | {'receipt': str(receipt_path)})
        parsed[r['label']] = r
    assert [c['index'] for c in probes.CALLS] == list(range(1, 19))
    for label, change in [('schema-config-only', 'config'), ('schema-metadata-only', 'metadata'),
                          ('schema-user-version-only', 'user_version'), ('sql-project-id-only', 'project_id')]:
        derivation = probes.read_json(ROOT / 'probes' / label / 'fixture-derivation.json')
        coordinate, check = parsed[label + '-coordinate'], parsed[label + '-check']
        assert coordinate['exit_code'] == 3 and check['exit_code'] == 1
        probes.ROWS.append(dict(name=label, change=change, schema_after=derivation['schema_after'],
                               coordinate_exit=3, check_exit=1,
                               coordinate_stderr=Path(coordinate['stderr']['path']).read_text(encoding='utf-8'),
                               check_diagnostic=Path(check['stderr']['path']).read_text(encoding='utf-8').strip(),
                               no_success_ir=True, source_project_frozen_before_commands=True))
    owner_check = Path(parsed['owner-version-two-check']['stderr']['path']).read_text(encoding='utf-8').strip()
    assert owner_check == 'coordination verifier: artifact fingerprint mismatch: .owner.json'
    assert parsed['owner-version-two-coordinate']['exit_code'] == 2
    assert 'COORD_SCHEMA' in Path(parsed['owner-version-two-coordinate']['stderr']['path']).read_text(encoding='utf-8')
    probes.ROWS.append(dict(name='owner-version-two', coordinate_exit=2, coordinate_diagnostic='COORD_SCHEMA',
                           independent_auxiliary_check_exit=1, independent_auxiliary_check_diagnostic=owner_check,
                           independent_check_limitation='Owner pin was refreshed in case but not the original source report; independent check rejects its earlier artifact-integrity guard. This does not prove its owner-version diagnostic and is not used for that claim.',
                           no_success_ir=True, owner_only_changed_before_freeze=True,
                           all_original_ir_gold_candidate_bytes_retained=True))

    # The earlier harness expected a label from role_text(), but that helper delegates
    # the blank/oversized rejection to text() with the label below. No product code
    # or already prepared fixture is changed; author cases have not yet run.
    original_check = probes.check
    def check_with_actual_label(label, project, case, output, gold, expected=0, diagnostic=None, extras=()):
        if diagnostic == 'source role text type/limit':
            diagnostic = 'text type/limit'
        return original_check(label, project, case, output, gold, expected, diagnostic, extras)
    probes.check = check_with_actual_label
    probes.author_case('gold-v2-blank-author', 2, '   ', 'COORD_SCHEMA')
    probes.ROWS[-1]['check_diagnostic'] = 'text type/limit'
    probes.author_case('gold-v2-long-author', 2, 'a' * 2048, 'COORD_INPUT_LIMIT')
    probes.ROWS[-1]['check_diagnostic'] = 'text type/limit'
    assert len(probes.CALLS) == 24 and len(probes.ROWS) == 11
    summary = dict(schema_version=1, calls=probes.CALLS, scenarios=probes.ROWS, scenario_count=11,
                   command_count=24, all_observed_exits_match_expectations=True,
                   cli=probes.FIXED_CLI, current_source_files=probes.PIN['source_files'],
                   source_code_and_cli_unchanged=True, inputs_ir_gold_project_and_sentinel_unchanged=True,
                   model_calls=0, network_calls=0, paid_calls=0,
                   role_set_source_proof='Python: set(cm[referenced matches]) == {selected role}; Rust: BTreeSet(mapped IDs) len1/contains. Both permit multiple original components mapped to the same one canonical ID.',
                   preserved_harness_failures=[
                       dict(path=str(ROOT / 'launch-inspection-1.receipt.json'), cause='Inspection treated intermediate scoped green sources as final unchanged 154-file sources. Final six receipts match current bytes; intermediate receipts legitimately predate remaining fixes.'),
                       dict(path=str(ROOT / 'launch-probes-finish.receipt.json'), cause='Public baseline Gold2 retains nonempty exceptions; harness aborted before any author CLI rather than drop factual fields to synthesize Gold1. Both live author probes use original Gold2 unchanged facts; shared GoldInput V1/V2 author guard is reviewed by source.'),
                       dict(path=str(ROOT / 'launch-probes-two.receipt.json'), cause='Auxiliary independent owner check rejected its earlier artifact fingerprint guard; harness incorrectly expected the later owner version label. The ordinary CLI already showed required COORD_SCHEMA/2. No old receipt or input was changed and no behavior was relabeled.')])
    new_json(ROOT / 'probe-summary.json', summary)
    print(json.dumps({'scenarios': 11, 'commands': 24, 'exits_match': True,
                      'owner_auxiliary_python_limit_preserved': True}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
