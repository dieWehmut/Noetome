from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def fingerprint(path):
    data = Path(path).read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'byte_length': len(data)}


def inventory(path):
    path = Path(path)
    result = {}
    def visit(p):
        s = p.lstat()
        assert not p.is_symlink() and not getattr(s, 'st_file_attributes', 0) & 0x400
        name = p.relative_to(path).as_posix() if p != path else '.'
        entry = {'device': s.st_dev, 'inode': s.st_ino, 'mtime_ns': s.st_mtime_ns,
                 'kind': 'directory' if p.is_dir() else 'file', 'size': s.st_size}
        if p.is_file():
            assert s.st_nlink == 1
            entry.update(fingerprint(p))
        else:
            assert p.is_dir()
        result[name] = entry
        if p.is_dir():
            for child in sorted(p.iterdir()):
                visit(child)
    visit(path)
    return result


def main():
    # Only this agent's retained evidence is read; no current product/source/CLI
    # read occurs while the controller applies the authorized single-item fix.
    original = json.loads((ROOT / 'review-before-2.json').read_bytes())
    fixed_sources, fixed_cli = original['source_files'], original['cli']
    receipts = sorted((ROOT / 'commands').glob('*.receipt.json'))
    assert len(receipts) == 27
    results, protected = [], {}
    for path in receipts:
        receipt = json.loads(path.read_bytes())
        assert receipt['code_before'] == receipt['code_after'] == fixed_sources
        assert receipt['cli_before'] == receipt['cli_after'] == fixed_cli
        assert receipt['protected_before'] == receipt['protected_after'] and receipt['protection_unchanged']
        for kind in ('stdout', 'stderr'):
            stream = receipt[kind]
            assert fingerprint(stream['path']) == {key: stream[key] for key in ('sha256', 'byte_length')}
        for selected, before in receipt['protected_before'].items():
            p = Path(selected)
            assert p.resolve().is_relative_to(ROOT)
            actual = inventory(p)
            assert actual == before, selected
            protected[selected] = actual
        result = dict(index=receipt['index'], label=receipt['label'], receipt=str(path),
                      receipt_fingerprint=fingerprint(path), expected_exit=receipt['expected_exit'], actual_exit=receipt['exit_code'])
        results.append(result)
    assert [r['index'] for r in results] == list(range(1, 28))
    assert all(r['actual_exit'] == r['expected_exit'] for r in results[:26])
    assert results[-1]['actual_exit'] == 0 and results[-1]['expected_exit'] == 1
    assert inventory(ROOT / 'pristine-probes') == json.loads((ROOT / 'pristine-inventory.json').read_bytes())
    assert fingerprint(ROOT / 'archives/final-review-probes.zip') == {'sha256': '9163f306bb515f5fa1e98c9e3e463e48e8655424a47d45dc2067b8054da0dd20', 'byte_length': 817152}
    author_checks = []
    baseline = ROOT / 'probes/legal-original/case/bundle-b'
    for name in ('gold-v2-blank-author', 'gold-v2-long-author'):
        folder = ROOT / 'probes' / name
        bundle = folder / 'genuine-source-review-output'
        source_gold = json.loads((bundle / 'gold-original.json').read_bytes())
        old_gold = json.loads((baseline / 'gold-original.json').read_bytes())
        source_gold.pop('author'); old_gold.pop('author')
        assert source_gold == old_gold
        same = {}
        for file in ('candidates-original.json', 'decision-original.json', 'source-snapshot.json', 'knowledge-ir.json'):
            same[file] = (bundle / file).read_bytes() == (baseline / file).read_bytes()
            assert same[file], (name, file)
        manifest = json.loads((folder / 'case/coordination.json').read_bytes())
        pin = next(item['artifacts'] for item in manifest['inputs'] if item['input_id'] == 'b')
        assert pin == {file: fingerprint(folder / 'case/bundle-b' / file) for file in pin}
        author_checks.append({'name': name, 'source_gold_only_author_changed': True,
                              'candidate_decision_source_snapshot_original_ir_identical': same,
                              'all_nine_case_bundle_fingerprints_actual': True})
    interim = ROOT / 'interim-rereview-report.md'
    result = dict(schema_version=1, frozen_at=datetime.now(timezone.utc).isoformat(),
                  initial_immutable_head='ae2858031f947ef22e28328af2b094b498106f32',
                  current_product_reads_during_controller_fix=False,
                  initial_code_fingerprints=fixed_sources, initial_cli=fixed_cli,
                  receipts=results, receipt_count=27, stream_hash_count=54,
                  actual_selected_immutable_groups=len(protected), protected_after=protected,
                  pristine_archive_and_598_files_unchanged=True, author_actual_original_proofs=author_checks,
                  original_11_scenarios_24_commands_exits_match=True,
                  subsequent_coherent_duplicate_support_required_1_actual_0=True,
                  interim_report={'path': str(interim), **fingerprint(interim)})
    with (ROOT / 'initial-review-evidence-integrity.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'receipts': 27, 'stream_hashes': 54, 'protected_groups': len(protected),
                      'author_original_ir_bytes_identical': True, 'current_product_reads': False}))


if __name__ == '__main__':
    main()
