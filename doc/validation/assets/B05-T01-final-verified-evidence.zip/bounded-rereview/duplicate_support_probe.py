from __future__ import annotations

import copy
import json
from pathlib import Path
import sys

import run_probes as probes
from inspect_evidence_v2 import ROOT, REPO, CLI, fp, fp_bytes, new_bytes, new_json, inventory

sys.path.insert(0, str(REPO / 'scripts'))
from verify_knowledge_coordination import rebuild_source_report
from verify_extraction_knowledge import actual_source


def markdown_for(old_bytes, value):
    before, body = old_bytes.decode('utf-8').split('```json\n', 1)
    assert body.endswith('\n```\n')
    return (before + '```json\n' + json.dumps(value, ensure_ascii=False, indent=2) + '\n```\n').encode('utf-8')


def main():
    prior = probes.read_json(ROOT / 'probe-summary.json')
    probes.CALLS.extend(prior['calls'])
    assert len(probes.CALLS) == 24
    pristine = probes.CORPUS / 'support-order'
    folder = ROOT / 'probes' / 'duplicate-support-fix-regression'
    folder.mkdir(parents=True)
    project = probes.copy_tree_new(pristine / 'project', folder / 'project')
    coordination_gold = folder / 'gold.json'
    new_bytes(coordination_gold, (pristine / 'gold.json').read_bytes())
    external_gold_fp = fp(coordination_gold)
    assert probes.read_json(coordination_gold)['expected_evidence_links'] == 4
    old_bundle = pristine / 'case/bundle-a'
    raw = {name: (old_bundle / name).read_bytes() for name in probes.FILES}
    candidate = json.loads(raw['candidates-original.json'])
    original_links = copy.deepcopy(candidate['payload']['atoms'][0]['atom']['evidence_links'])
    assert [link['evidence_id'] for link in original_links] == ['a-support-second', 'a-support']
    duplicate_link = copy.deepcopy(original_links[0])
    candidate['payload']['atoms'][0]['atom']['evidence_links'] = [duplicate_link, copy.deepcopy(duplicate_link)]
    raw['candidates-original.json'] = probes.encoded(candidate)
    source_gold = json.loads(raw['gold-original.json'])
    review = json.loads(raw['review-original.json'])
    decision = json.loads(raw['decision-original.json'])
    review_case = folder / 'invalid-source-review-input'
    review_case.mkdir()
    new_bytes(review_case / 'review.json', raw['review-original.json'])
    for role, original in [('candidate_file', 'candidates-original.json'), ('gold_file', 'gold-original.json'), ('decision_file', 'decision-original.json')]:
        new_bytes(review_case / review[role], raw[original])
    ordinary_source_output = folder / 'ordinary-rejected-source-review'
    source_run = probes.run('duplicate-support-ordinary-source-review',
        [CLI, 'extract', 'verify', project, candidate['binding']['import_id'], review_case, ordinary_source_output],
        3, [project, review_case, coordination_gold], new_output=ordinary_source_output, diagnostic='EXTRACT_KNOWLEDGE')
    assert not (ordinary_source_output / 'knowledge-ir.json').exists()

    # Construct a deliberately forged passed source review in new memory/files.
    # The production Python rebuild helper is used only as an adversarial report
    # renderer, never as the admission oracle. Ordinary Rust rejection above is
    # the independent reference behavior; the external gold remains unchanged.
    source = actual_source(project, candidate['binding']['import_id'], review['selection'][0])
    inputs = {'review.json': raw['review-original.json'], review['candidate_file']: raw['candidates-original.json'],
              review['gold_file']: raw['gold-original.json'], review['decision_file']: raw['decision-original.json']}
    first_report = rebuild_source_report(candidate, source_gold, review, decision, source, inputs, raw)
    source_ir = json.loads(raw['knowledge-ir.json'])
    source_ir['atoms'] = candidate['payload']['atoms']
    source_ir['checks'] = first_report['checks']
    raw['knowledge-ir.json'] = probes.encoded(source_ir)
    forged_source_report = rebuild_source_report(candidate, source_gold, review, decision, source, inputs, raw)
    raw['verification.json'] = probes.encoded(forged_source_report)
    raw['verification.md'] = markdown_for(raw['verification.md'], forged_source_report)
    manifest = probes.read_json(pristine / 'case/coordination.json')
    item_a = next(i for i in manifest['inputs'] if i['input_id'] == 'a')
    item_a['artifacts'] = {name: fp_bytes(raw[name]) for name in probes.FILES}
    manifest_bytes = probes.encoded(manifest)
    case_overrides = {'bundle-a/' + name: raw[name] for name in probes.FILES}
    case_overrides['coordination.json'] = manifest_bytes
    case = probes.copy_tree_new(pristine / 'case', folder / 'coherently-forged-case', case_overrides)

    report = probes.read_json(pristine / 'output/coordination.json')
    input_a = next(i for i in report['inputs'] if i['input_id'] == 'a')
    input_a['source_bundle_fingerprints'] = item_a['artifacts']
    input_a['source_review_checks'] = forged_source_report['checks']
    occurrence_a = next(o for o in report['occurrences'] if o['input_id'] == 'a')
    occurrence_a['original_atom'] = candidate['payload']['atoms'][0]
    chosen = next(e for e in candidate['payload']['evidence'] if e['evidence_id'] == 'a-support-second')
    occurrence_a['original_evidence'] = [copy.deepcopy(chosen), copy.deepcopy(chosen)]
    assert report['totals']['evidence_links'] == 4
    coord_ir = probes.read_json(pristine / 'output/coordination-ir.json')
    coord_ir['inputs'] = report['inputs']
    coord_ir['occurrences'] = report['occurrences']
    forged_output_bytes = {p.name: p.read_bytes() for p in (pristine / 'output').iterdir()}
    forged_output_bytes['coordination-original.json'] = manifest_bytes
    for name in probes.FILES:
        forged_output_bytes['input-a--' + name] = raw[name]
    forged_output_bytes['coordination-ir.json'] = probes.encoded(coord_ir)
    report['artifacts'] = {name: fp_bytes(body) for name, body in forged_output_bytes.items()
                           if name not in ('coordination.json', 'coordination.md')}
    forged_output_bytes['coordination.json'] = probes.encoded(report)
    forged_output_bytes['coordination.md'] = markdown_for(forged_output_bytes['coordination.md'], report)
    output = folder / 'coherent-forged-output'
    output.mkdir()
    for name, body in forged_output_bytes.items():
        new_bytes(output / name, body)
    new_json(folder / 'forgery-construction.json', dict(
        classification='explicit synchronous forgery, never ordinary successful CLI output',
        original_support_links=original_links, forged_support_links=candidate['payload']['atoms'][0]['atom']['evidence_links'],
        original_payload_evidence_ids=[e['evidence_id'] for e in candidate['payload']['evidence']],
        forged_occurrence_original_evidence_ids=[e['evidence_id'] for e in occurrence_a['original_evidence']],
        author_gold_unchanged=external_gold_fp, expected_evidence_links=4, forged_report_evidence_links=4,
        actual_unique_support_links_in_input_a=1, declared_support_link_entries_in_input_a=2,
        synchronized=['original candidate atom links', 'four original role fingerprints', 'source IR atom/checks',
                      'source report artifacts/complete checks/Markdown', 'case nine-file pins',
                      'coordination-original copy', 'all input-a bundle copies', 'input-a checks/fingerprints',
                      'occurrence original atom/evidence', 'coordination IR', 'coordination artifacts/JSON/Markdown'],
        unchanged=['actual source project/SQL/bytes', 'author gold/value/unit/conditions/exceptions',
                   'identity map', 'original atom ID', 'two canonical fact IDs', 'three source occurrence IDs',
                   'four-entry evidence denominator'],
        renderer='production Python rebuild helper used only to make the attack coherent; ordinary Rust admission and actual independent check are behavioral oracles'))
    rejected = folder / 'ordinary-rejected-coordinate'
    probes.run('duplicate-support-ordinary-coordinate', [CLI, 'knowledge', 'coordinate', project, case, rejected],
               3, [project, review_case, ordinary_source_output, case, coordination_gold, output],
               new_output=rejected, diagnostic='EXTRACT_KNOWLEDGE')
    protected_before_check = probes.snapshot([project, review_case, ordinary_source_output, case, coordination_gold, output, probes.SENTINEL])
    expected_rejection = True
    assertion = None
    try:
        probes.check('duplicate-support-coherent-forgery-check', project, case, output, coordination_gold, 1,
                     extras=(review_case, ordinary_source_output))
    except AssertionError as error:
        assertion = str(error)
    call = probes.CALLS[-1]
    actual_check = json.loads(Path(call['stdout']['path']).read_bytes()) if call['exit_code'] == 0 else None
    assert probes.snapshot([project, review_case, ordinary_source_output, case, coordination_gold, output, probes.SENTINEL]) == protected_before_check
    assert fp(coordination_gold) == external_gold_fp
    result = dict(schema_version=1, calls=probes.CALLS[-3:], scope='new Important introduced by final support-order fix',
                  actual_ordinary_source_review_exit=3, actual_ordinary_coordinate_exit=3,
                  required_independent_check_exit=1, actual_independent_check_exit=call['exit_code'],
                  independent_result=actual_check, rejection_assertion=assertion,
                  false_acceptance=call['exit_code'] == 0 and actual_check['independently_verified'] is True,
                  source_project_and_gold_unchanged=True, public_material_only=True,
                  coherent_forgery=str(output), case=str(case), project=str(project), gold=str(coordination_gold),
                  regression_receipt=call['receipt'], construction=str(folder / 'forgery-construction.json'))
    new_json(ROOT / 'duplicate-support-result.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
