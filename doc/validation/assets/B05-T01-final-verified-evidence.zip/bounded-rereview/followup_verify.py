from __future__ import annotations

from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import time
import zipfile

from inspect_evidence_v2 import ROOT, REPO, CLI, fp, fp_bytes, inventory, new_bytes, new_json

BASE = 'ae2858031f947ef22e28328af2b094b498106f32'
HEAD = '2618752028557d15e8fb5a1828f243cf3f25f935'
GATE = REPO / '.superpowers/sdd/B05-T01_COORDINATION_PLAN/final-link-fix-a21963d8eaf94c648cac483ea62e1cf3'
PYTHON = Path('C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
ASSETS = REPO / 'doc/validation/assets'
ARCHIVE_NAME = 'B05-T01-final-link-probes.zip'
ARCHIVE_FP = {'sha256': 'dbc5226b986c0cb79b4c103e4730bd1eb82aee0398e86bfd7f3b287d92d7c69a', 'byte_length': 164287}
FOLLOWUP = ROOT / 'followup'


def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True).stdout


def current_sources(expected):
    return {name: fp(REPO / name) for name in expected}


def source_digest(sources):
    return fp_bytes(json.dumps(sources, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8'))['sha256']


def clone(source, destination):
    assert not destination.exists() and destination.resolve().is_relative_to(ROOT)
    inventory(source)
    destination.mkdir(parents=True)
    for original in sorted(source.rglob('*')):
        relative = original.relative_to(source)
        target = destination / relative
        if original.is_dir():
            target.mkdir(exist_ok=True)
        else:
            new_bytes(target, original.read_bytes())


def byte_inventory(path):
    return {name: {key: data[key] for key in ('sha256', 'byte_length')}
            for name, data in inventory(path).items() if data['kind'] == 'file'}


def inspect_gate(manifest, expected_sources):
    results = {}
    for label in ('red', 'green', 'module', 'full', 'audit'):
        receipt_path = GATE / (label + '-receipt.json')
        receipt = json.loads(receipt_path.read_bytes())
        assert receipt['source_files_before'] == receipt['source_files_after']
        assert receipt['source_unchanged'] is True
        if label != 'red':
            assert receipt['exit_code'] == 0 and receipt['source_files_before'] == expected_sources
        else:
            assert receipt['exit_code'] == 1
            assert receipt['source_files_before']['scripts/verify_knowledge_coordination.py'] == original_pin['source_files']['scripts/verify_knowledge_coordination.py']
            assert receipt['source_files_before']['tests/test_knowledge_coordination_verifier.py'] == expected_sources['tests/test_knowledge_coordination_verifier.py']
        assert receipt['cli_before'] == receipt['cli_after'] == manifest['cli_fingerprint']
        text = ''
        for stream_name in ('stdout', 'stderr'):
            saved = receipt[stream_name]
            path = Path(saved['path'])
            assert path.resolve().is_relative_to(GATE)
            assert fp(path) == {key: saved[key] for key in ('sha256', 'byte_length')}
            text += path.read_text(encoding='utf-8') + '\n'
        if label == 'red':
            assert 'AssertionError: AssertionError not raised' in text and 'FAILED (failures=1)' in text
        count = re.findall(r'Ran (\d+) tests? in ([0-9.]+)s', text)
        expected_counts = {'green': '2', 'module': '35', 'full': '143'}
        if label in expected_counts:
            assert len(count) == 1 and count[0][0] == expected_counts[label] and '\nOK\n' in text
        results[label] = dict(path=str(receipt_path), fingerprint=fp(receipt_path), argv=receipt['argv'],
                               exit_code=receipt['exit_code'], stdout=receipt['stdout'], stderr=receipt['stderr'],
                               sources_checked=len(receipt['source_files_before']), source_unchanged=True,
                               cli_unchanged=True, actual_unittest_count=count, head_at_run=receipt['head_before'])
    audit_root = Path(json.loads((GATE / 'audit-receipt.json').read_bytes())['argv'][-1])
    assert audit_root.resolve().is_relative_to(REPO / 'target/compiler-temp')
    audit_path = audit_root / 'audit.json'
    audit = json.loads(audit_path.read_bytes())
    assert len(audit['scenarios']) == audit['scenario_count'] == 33
    assert len(audit['calls']) == audit['command_count'] == 56
    assert audit['protected_before'] == audit['protected_after'] and audit['protection_passed']
    assert audit['network_calls'] == audit['paid_calls'] == 0
    assert audit['cli_fingerprint'] == manifest['cli_fingerprint']
    for call in audit['calls']:
        assert call['exit_code'] == call['expected_exit']
        path = audit_root / (f"command-{call['index']:03d}-" + call['name'] + '.json')
        assert json.loads(path.read_bytes()) == call
        for stream_name in ('stdout', 'stderr'):
            saved = call[stream_name]
            stream_path = Path(saved['path'])
            assert stream_path.resolve().is_relative_to(audit_root)
            assert fp(stream_path) == {key: saved[key] for key in ('sha256', 'byte_length')}
    sys.path.insert(0, str(REPO / 'scripts'))
    from verify_knowledge_coordination import inventory as audit_inventory
    for selected, before in audit['protected_before'].items():
        selected = Path(selected)
        observed = audit_inventory(selected) if selected.is_dir() else fp(selected)
        assert observed == before
    assert len(audit['protected_before']) == 29
    return dict(receipts=results, audit=dict(path=str(audit_path), fingerprint=fp(audit_path),
                 scenarios=33, commands=56, actual_command_stream_hashes_checked=112,
                 current_original_protection_groups_checked=29, unchanged=True))


def call_check(index, label, project, case, output, gold, expected_exit, diagnostic, sources, manifest):
    argv = [str(PYTHON), '-X', 'utf8', '-B', str(REPO / 'scripts/verify_knowledge_coordination.py'),
            'check', str(project), str(case), str(output), str(gold)]
    paths = [project, case, output, gold, ROOT / 'external-sentinel.txt',
             ROOT / 'probes/duplicate-support-fix-regression', ROOT / 'pristine-probes']
    before = {str(path): inventory(path) for path in paths}
    assert current_sources(sources) == sources and fp(CLI) == manifest['cli_fingerprint']
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['TEMP'] = env['TMP'] = str(ROOT / 'runtime-temp')
    started = time.monotonic()
    run = subprocess.run(argv, cwd=REPO, env=env, capture_output=True, timeout=40)
    stem = FOLLOWUP / 'commands' / (f'{index:03d}-' + label)
    streams = {}
    for name, data in (('stdout', run.stdout), ('stderr', run.stderr)):
        stream_path = stem.with_suffix('.' + name + '.txt')
        new_bytes(stream_path, data)
        streams[name] = dict(path=str(stream_path), **fp_bytes(data))
    after = {str(path): inventory(path) for path in paths}
    actual_sources = current_sources(sources)
    actual_cli = fp(CLI)
    receipt = dict(schema_version=1, index=index, label=label, argv=argv, cwd=str(REPO),
                   exit_code=run.returncode, expected_exit=expected_exit, elapsed_seconds=time.monotonic() - started,
                   immutable_base=BASE, immutable_head=HEAD, current_code_before=sources, current_code_after=actual_sources,
                   source_fingerprint_digest_sha256=source_digest(sources), cli_before=manifest['cli_fingerprint'], cli_after=actual_cli,
                   protected_before=before, protected_after=after, protection_unchanged=before == after,
                   diagnostic_required=diagnostic, **streams)
    new_json(stem.with_suffix('.receipt.json'), receipt)
    assert before == after and actual_sources == sources and actual_cli == manifest['cli_fingerprint']
    assert run.returncode == expected_exit
    if diagnostic:
        assert diagnostic in (run.stderr + run.stdout).decode('utf-8')
    result = dict(index=index, label=label, receipt=str(stem.with_suffix('.receipt.json')), exit_code=run.returncode,
                  expected_exit=expected_exit, stdout=streams['stdout'], stderr=streams['stderr'],
                  byte_preservation=True, current_code_cli_preserved=True)
    if expected_exit == 0:
        value = json.loads(run.stdout)
        assert value['status'] == 'passed' and value['independently_verified'] is True
        assert value['totals']['canonical_facts'] == 2 and value['totals']['source_occurrences'] == 3 and value['totals']['evidence_links'] == 4
        result['independent_result'] = value
    print(json.dumps({'index': index, 'label': label, 'exit_code': run.returncode, 'protected_unchanged': True}), flush=True)
    return result


original_pin = json.loads((ROOT / 'review-before-2.json').read_bytes())


def main():
    assert Path(sys.executable) == PYTHON
    FOLLOWUP.mkdir()
    manifest = json.loads((GATE / 'final-link-fix-manifest.json').read_bytes())
    assert manifest['base'] == BASE and manifest['head'] == HEAD
    assert fp(GATE / 'final-link-fix.patch') == manifest['patch_fingerprint']
    assert manifest['patch_fingerprint']['sha256'] == '1f3962030408972375f8a0aa499a05563d0ae965cdde3e5cebb9bc1db95e5c42'
    assert fp(CLI) == manifest['cli_fingerprint'] == original_pin['cli']
    sources = current_sources(manifest['current_source_files'])
    assert sources == manifest['current_source_files'] and len(sources) == 154
    difference = [name for name in sources if sources[name] != original_pin['source_files'][name]]
    assert set(difference) == {'scripts/verify_knowledge_coordination.py', 'tests/test_knowledge_coordination_verifier.py'}
    assert not git('diff', '--name-only', HEAD, '--', 'crates', 'scripts', 'tests', 'Cargo.toml', 'Cargo.lock').strip()
    assert git('diff', '--binary', BASE, HEAD) == (GATE / 'final-link-fix.patch').read_bytes()
    current_verifier = (REPO / 'scripts/verify_knowledge_coordination.py').read_text(encoding='utf-8')
    assert 'evidence_pairs = {(link["evidence_id"], link["relation"]) for link in evidence_links}' in current_verifier
    assert 'assert len(evidence_pairs) == len(evidence_links), "unique atom evidence links"' in current_verifier
    old_stdout = (ROOT / 'commands/027-duplicate-support-coherent-forgery-check.stdout.txt').read_bytes()
    assert json.loads(old_stdout)['independently_verified'] is True
    package_manifest = json.loads((ASSETS / 'B05-T01-final-link-probes-manifest.json').read_bytes())
    assert fp(ASSETS / ARCHIVE_NAME) == ARCHIVE_FP
    assert package_manifest['sha256'] == ARCHIVE_FP['sha256'] and package_manifest['member_count'] == 99
    assert type(package_manifest['members']) is dict and len(package_manifest['members']) == 99
    copied_zip = FOLLOWUP / 'archives/final-link-probes.zip'
    new_bytes(copied_zip, (ASSETS / ARCHIVE_NAME).read_bytes())
    corpus = FOLLOWUP / 'pristine-link-probes'
    with zipfile.ZipFile(copied_zip) as archive:
        entries = archive.infolist()
        assert len(entries) == len({entry.filename for entry in entries}) == 99 and archive.testzip() is None
        assert {entry.filename for entry in entries} == set(package_manifest['members'])
        for entry in entries:
            relative = PurePosixPath(entry.filename)
            assert not relative.is_absolute() and '..' not in relative.parts and '\\' not in entry.filename and ':' not in entry.filename
            assert not entry.is_dir() and (entry.external_attr >> 16) & 0o170000 != 0o120000
            data = archive.read(entry)
            declared = package_manifest['members'][entry.filename]
            assert fp_bytes(data) == {key: declared[key] for key in ('sha256', 'byte_length')}
            new_bytes(corpus / Path(*relative.parts), data)
    assert (ASSETS / 'B05-T01-final-rereview-interim.md').read_bytes() == (ROOT / 'interim-rereview-report.md').read_bytes()
    artifact_protected = {str(path): inventory(path) for path in (GATE, ASSETS / ARCHIVE_NAME,
                    ASSETS / 'B05-T01-final-link-probes-manifest.json', ASSETS / 'B05-T01-final-rereview-interim.md')}
    baseline_duplicate = ROOT / 'probes/duplicate-support-fix-regression'
    packaged_duplicate = corpus / 'duplicate-support'
    for relative in ('project', 'coherently-forged-case', 'coherent-forged-output'):
        assert byte_inventory(packaged_duplicate / relative) == byte_inventory(baseline_duplicate / relative)
    assert fp(packaged_duplicate / 'gold.json') == fp(baseline_duplicate / 'gold.json')
    gate_results = inspect_gate(manifest, sources)
    source_before = dict(schema_version=1, base=BASE, head=HEAD, source_files=sources,
                         source_digest_sha256=source_digest(sources), cli=manifest['cli_fingerprint'],
                         changed_source_files=difference, unchanged_source_count=152,
                         git_head=git('rev-parse', 'HEAD').decode().strip(), git_status=git('status', '--short').decode('utf-8'))
    new_json(FOLLOWUP / 'source-before.json', source_before)
    negative_root = FOLLOWUP / 'duplicate-support-check'
    clone(packaged_duplicate, negative_root)
    negative = call_check(28, 'duplicate-support-rejected', negative_root / 'project', negative_root / 'coherently-forged-case',
                          negative_root / 'coherent-forged-output', negative_root / 'gold.json', 1, 'unique atom evidence links', sources, manifest)
    positive_root = FOLLOWUP / 'legal-support-order-check'
    clone(ROOT / 'pristine-probes/support-order', positive_root)
    positive = call_check(29, 'legal-support-order-preserved', positive_root / 'project', positive_root / 'case',
                          positive_root / 'output', positive_root / 'gold.json', 0, None, sources, manifest)
    report = json.loads((positive_root / 'output/coordination.json').read_bytes())
    occurrence = next(o for o in report['occurrences'] if o['input_id'] == 'a')
    assert [e['evidence_id'] for e in occurrence['original_evidence']] == ['a-support-second', 'a-support']
    assert current_sources(sources) == sources and fp(CLI) == manifest['cli_fingerprint']
    assert {path: inventory(path) for path in map(Path, artifact_protected)} == {Path(path): value for path, value in artifact_protected.items()}
    assert not (REPO / 'docs/Noetome-PRD-v1.0.html').exists() and not (REPO / 'docs/Noetome-PRD-v1.0.md').exists()
    result = dict(schema_version=1, scope='Only correction of the introduced duplicate-support Important; no repeat of original 11 scenarios or broad suites',
                  base=BASE, head=HEAD, production_delta_lines=3, changed_source_files=difference,
                  source_digest_sha256=source_digest(sources), current_source_files=sources, cli=manifest['cli_fingerprint'],
                  gate_results=gate_results, package={'archive': str(ASSETS / ARCHIVE_NAME), 'fingerprint': ARCHIVE_FP, 'members': 99, 'crc': 'all_passed'},
                  behavior_results=[negative, positive], new_check_commands=2, total_new_review_commands=29,
                  initial_negative_required_1_actual_0_preserved=True, duplicate_support_important='ADDRESSED',
                  original_five='ADDRESSED; evidence retained without rerun', new_critical_or_important=[],
                  shared_evidence_id_different_relation_source_proof='The tuple includes both evidence_id and relation; equal IDs with different relation values remain two distinct set elements, matching Rust. No evidence-id-only deduplication was added.',
                  rust_561_reused_by_152_unchanged_files=True, artifacts_and_originals_unchanged=True,
                  user_deletions_preserved=True, final_git_status=git('status', '--short').decode('utf-8'))
    new_json(FOLLOWUP / 'followup-evidence-inspection.json', result)
    print(json.dumps({'new_checks': 2, 'duplicate_forgery_exit': 1, 'legal_support_order_exit': 0,
                      'module': 35, 'full_python': 143, 'audit': [33, 56, 29],
                      'sources': 154, 'changed': difference, 'important': 'ADDRESSED'}), flush=True)


if __name__ == '__main__':
    main()
