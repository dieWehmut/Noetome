from __future__ import annotations

from contextlib import closing
from datetime import datetime, timezone
import copy
import json
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time
import uuid

from inspect_evidence_v2 import REPO, ROOT, CLI, HEAD, fp, fp_bytes, inventory, new_bytes, new_json, source_files

PYTHON = Path('C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
CORPUS = ROOT / 'pristine-probes'
FIX_MANIFEST = REPO / '.superpowers/sdd/B05-T01_COORDINATION_PLAN/final-fix-13fb5f0be4ec46beabc94220b55c078d/final-fix-manifest.json'
PIN = json.loads(FIX_MANIFEST.read_bytes())
FIXED_CLI = PIN['cli_fingerprint']
FILES = ['.owner.json', 'review-original.json', 'candidates-original.json', 'gold-original.json',
         'decision-original.json', 'source-snapshot.json', 'knowledge-ir.json', 'verification.json', 'verification.md']
ENV = os.environ.copy()
ENV['PYTHONDONTWRITEBYTECODE'] = '1'
ENV['TEMP'] = ENV['TMP'] = str(ROOT / 'runtime-temp')
SENTINEL = ROOT / 'external-sentinel.txt'
CALLS = []
ROWS = []


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def read_json(path):
    return json.loads(Path(path).read_bytes())


def copy_tree_new(source, destination, overrides=None):
    source, destination = Path(source), Path(destination)
    assert destination.resolve().is_relative_to(ROOT) and not destination.exists()
    inventory(source)
    overrides = overrides or {}
    destination.mkdir(parents=True)
    for path in sorted(source.rglob('*')):
        relative = path.relative_to(source)
        if path.is_dir():
            (destination / relative).mkdir(exist_ok=True)
        else:
            new_bytes(destination / relative, overrides.get(relative.as_posix(), path.read_bytes()))
    assert set(overrides).issubset({p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()})
    return destination


def snapshot(paths):
    return {str(Path(p)): inventory(Path(p)) for p in paths}


def state(path):
    return {'exists': False} if not Path(path).exists() else {'exists': True, 'inventory': inventory(path)}


def run(label, argv, expected_exit, protected, new_output=None, diagnostic=None):
    index = len(CALLS) + 1
    stem = ROOT / 'commands' / (f'{index:03d}-' + label)
    if new_output is not None:
        assert not Path(new_output).exists(), new_output
    protected = [*protected, SENTINEL]
    before = snapshot(protected)
    current_code = source_files(PIN)
    current_cli = fp(CLI)
    assert current_code == PIN['source_files'] and current_cli == FIXED_CLI
    started = time.monotonic()
    result = subprocess.run([str(arg) for arg in argv], cwd=REPO, env=ENV, capture_output=True, timeout=40)
    streams = {}
    for name, data in (('stdout', result.stdout), ('stderr', result.stderr)):
        path = stem.with_suffix('.' + name + '.txt')
        new_bytes(path, data)
        streams[name] = {'path': str(path), **fp_bytes(data)}
    after = snapshot(protected)
    code_after, cli_after = source_files(PIN), fp(CLI)
    receipt = dict(schema_version=1, index=index, label=label, started_at=datetime.now(timezone.utc).isoformat(),
                   argv=[str(arg) for arg in argv], cwd=str(REPO), exit_code=result.returncode,
                   expected_exit=expected_exit, elapsed_seconds=time.monotonic() - started,
                   cli_before=current_cli, cli_after=cli_after, code_before=current_code, code_after=code_after,
                   protected_before=before, protected_after=after, protection_unchanged=before == after,
                   new_output=None if new_output is None else dict(path=str(new_output), before={'exists': False}, after=state(new_output)),
                   diagnostic=diagnostic, **streams)
    new_json(stem.with_suffix('.receipt.json'), receipt)
    CALLS.append({'index': index, 'label': label, 'argv': receipt['argv'], 'exit_code': result.returncode,
                  'expected_exit': expected_exit, 'receipt': str(stem.with_suffix('.receipt.json')),
                  'stdout': streams['stdout'], 'stderr': streams['stderr']})
    print(json.dumps(dict(index=index, label=label, exit_code=result.returncode, expected_exit=expected_exit,
                          protected_unchanged=before == after), ensure_ascii=False), flush=True)
    assert before == after, label + ': protected input changed'
    assert current_code == code_after and current_cli == cli_after, label + ': current code/CLI changed'
    assert result.returncode == expected_exit, (label, result.returncode, result.stderr.decode('utf-8', errors='replace'))
    if diagnostic:
        assert diagnostic in (result.stderr + result.stdout).decode('utf-8'), label + ': diagnostic did not match'
    if new_output is not None and expected_exit != 0:
        assert not (Path(new_output) / 'coordination-ir.json').exists(), label
    return result


def check(label, project, case, output, gold, expected=0, diagnostic=None, extras=()):
    return run(label, [PYTHON, '-X', 'utf8', '-B', REPO / 'scripts/verify_knowledge_coordination.py',
                       'check', project, case, output, gold], expected,
               [project, case, output, gold, *extras], diagnostic=diagnostic)


def standard_fixture(name, project_source, case_source, gold_source, overrides=None):
    folder = ROOT / 'probes' / name
    assert not folder.exists()
    folder.mkdir(parents=True)
    project = copy_tree_new(project_source, folder / 'project')
    case = copy_tree_new(case_source, folder / 'case', overrides)
    gold = folder / 'gold.json'
    new_bytes(gold, Path(gold_source).read_bytes())
    assert read_json(project / 'project.json')['project_id'] == read_json(case / 'coordination.json')['project_id']
    return folder, project, case, gold


def coordinate_success(name, project_source, case_source, gold_source):
    folder, project, case, gold = standard_fixture(name, project_source, case_source, gold_source)
    output = folder / 'ordinary-output'
    result = run(name + '-coordinate', [CLI, 'knowledge', 'coordinate', project, case, output], 0,
                 [project, case, gold], new_output=output)
    report = read_json(output / 'coordination.json')
    assert json.loads(result.stdout) == report
    assert report['status'] == 'passed' and report['published'] is False
    assert report['scientific_quality'] == 'not_run' and report['research_status'] == 'not_requested'
    assert report['network_calls'] == report['paid_calls'] == 0
    checked = check(name + '-check', project, case, output, gold)
    independent = json.loads(checked.stdout)
    assert independent['status'] == 'passed' and independent['independently_verified'] is True
    assert independent['totals'] == report['totals']
    row = dict(name=name, kind='ordinary_coordinate_and_independent_check', project=str(project), case=str(case),
               output=str(output), gold=str(gold), totals=report['totals'], independently_verified=True)
    ROWS.append(row)
    return folder, project, case, gold, output, report


def schema_tuple(project):
    manifest = read_json(project / 'project.json')
    with closing(sqlite3.connect((project / 'project.sqlite').as_uri() + '?mode=ro&immutable=1', uri=True)) as db:
        metadata = db.execute('SELECT project_id, schema_version FROM project_metadata').fetchall()
        user_version = db.execute('PRAGMA user_version').fetchone()[0]
    return dict(config_schema=manifest['schema_version'], config_id=manifest['project_id'], metadata=metadata, user_version=user_version)


def group_one():
    new_bytes(SENTINEL, b'B05-T01 final re-review external public synthetic sentinel\n')
    baseline = coordinate_success('legal-original', CORPUS / 'support-order/project',
                                  CORPUS / 'schema3-text/case', CORPUS / 'schema3-text/gold.json')
    assert baseline[-1]['totals']['evidence_links'] == 3
    assert baseline[-1]['totals']['canonical_facts'] == 2
    assert schema_tuple(baseline[1])['config_schema'] == 2
    support = coordinate_success('support-order', CORPUS / 'support-order/project',
                                 CORPUS / 'support-order/case', CORPUS / 'support-order/gold.json')
    report = support[-1]
    a = next(o for o in report['occurrences'] if o['input_id'] == 'a')
    evidence_ids = [e['evidence_id'] for e in a['original_evidence']]
    links = [link['evidence_id'] for link in a['original_atom']['atom']['evidence_links'] if link['relation'] == 'supports']
    candidate = read_json(support[2] / 'bundle-a/candidates-original.json')
    payload_order = [e['evidence_id'] for e in candidate['payload']['evidence']]
    assert evidence_ids == links == ['a-support-second', 'a-support']
    assert payload_order == ['a-support', 'a-support-second']
    assert report['totals']['evidence_links'] == 4 and report['totals']['source_occurrences'] == 3
    old_checks = read_json(support[2] / 'bundle-a/verification.json')['checks']
    new_checks = next(i for i in report['inputs'] if i['input_id'] == 'a')['source_review_checks']
    assert old_checks == new_checks
    ROWS[-1].update(original_evidence_ids=evidence_ids, support_link_ids=links,
                    unchanged_payload_evidence_order=payload_order, upstream_source_checks_order_unchanged=True)
    schema3 = coordinate_success('schema3-text', CORPUS / 'schema3-text/project',
                                 CORPUS / 'schema3-text/case', CORPUS / 'schema3-text/gold.json')
    versions = schema_tuple(schema3[1])
    assert versions['config_schema'] == versions['user_version'] == versions['metadata'][0][1] == 3
    assert all(read_json(schema3[2] / ('bundle-' + i) / 'review-original.json')['selection'] == [{'kind': 'text', 'ordinal': 0}] for i in 'abc')
    ROWS[-1].update(schema_versions=versions, selected_source_kinds=['text', 'text', 'text'], new_pdf_registration=False)
    ambiguous = standard_fixture('ambiguous-role', CORPUS / 'ambiguous-role/project',
                                 CORPUS / 'ambiguous-role/case', CORPUS / 'ambiguous-role/gold.json')
    folder, project, case, gold = ambiguous
    output = folder / 'rejected-output'
    forged = copy_tree_new(CORPUS / 'ambiguous-role/forged-output', folder / 'retained-coherent-forgery')
    run('ambiguous-role-coordinate', [CLI, 'knowledge', 'coordinate', project, case, output], 2,
        [project, case, gold, forged], new_output=output, diagnostic='COORD_IDENTITY')
    check('ambiguous-role-coherent-forgery-check', project, case, forged, gold, 1, 'original subject/property role')
    ROWS.append(dict(name='ambiguous-role', ordinary_coordinate_exit=2, ordinary_diagnostic='COORD_IDENTITY',
                     coherent_forgery_check_exit=1, check_diagnostic='original subject/property role',
                     forged_output_classification='explicit synchronous forgery; not ordinary CLI successful output',
                     no_success_ir=True, case=str(case), project=str(project), gold=str(gold), forged_output=str(forged)))
    new_json(ROOT / 'probe-group-1.json', dict(schema_version=1, calls=CALLS, scenarios=ROWS))
    print('GROUP_ONE_OK', flush=True)


def mismatch_case(label, change):
    baseline = ROOT / 'probes/legal-original'
    folder, project, case, gold = standard_fixture(label, baseline / 'project', baseline / 'case', baseline / 'gold.json')
    legitimate_output = copy_tree_new(baseline / 'ordinary-output', folder / 'retained-legitimate-output')
    before = schema_tuple(project)
    if change == 'config':
        config = read_json(project / 'project.json')
        config['schema_version'] = 3
        # Only this newly created fixture is changed before its input freeze.
        with (project / 'project.json').open('wb') as stream:
            stream.write(encoded(config))
    else:
        with closing(sqlite3.connect(project / 'project.sqlite')) as db:
            with db:
                if change == 'metadata':
                    db.execute('PRAGMA ignore_check_constraints=ON')
                    db.execute('UPDATE project_metadata SET schema_version=3')
                elif change == 'user_version':
                    db.execute('PRAGMA user_version=3')
                elif change == 'project_id':
                    db.execute('UPDATE project_metadata SET project_id=?', (str(uuid.uuid4()),))
                else:
                    raise AssertionError(change)
    after = schema_tuple(project)
    new_json(folder / 'fixture-derivation.json', dict(kind='new copied fixture only; frozen after this mutation',
             change=change, schema_before=before, schema_after=after, sqlite_connection_explicitly_closed=True))
    expected_check = {'config': 'project SQL schema version', 'metadata': 'project SQL schema version',
                      'user_version': 'project user version', 'project_id': 'project SQL identity'}[change]
    output = folder / 'rejected-output'
    result = run(label + '-coordinate', [CLI, 'knowledge', 'coordinate', project, case, output], 3,
                 [project, case, gold, legitimate_output], new_output=output, diagnostic='PROJECT_')
    checked = check(label + '-check', project, case, legitimate_output, gold, 1, expected_check)
    ROWS.append(dict(name=label, change=change, schema_after=after, coordinate_exit=3, check_exit=1,
                     coordinate_stderr=result.stderr.decode('utf-8'), check_diagnostic=expected_check,
                     no_success_ir=True, source_project_frozen_before_commands=True))


def owner_case():
    baseline = ROOT / 'probes/legal-original'
    owner = read_json(baseline / 'case/bundle-b/.owner.json')
    owner['schema_version'] = 2
    owner_bytes = encoded(owner)
    manifest = read_json(baseline / 'case/coordination.json')
    item = next(i for i in manifest['inputs'] if i['input_id'] == 'b')
    item['artifacts']['.owner.json'] = fp_bytes(owner_bytes)
    overrides = {'bundle-b/.owner.json': owner_bytes, 'coordination.json': encoded(manifest)}
    folder, project, case, gold = standard_fixture('owner-version-two', baseline / 'project', baseline / 'case', baseline / 'gold.json', overrides)
    retained = copy_tree_new(baseline / 'ordinary-output', folder / 'copied-valid-result-for-invalid-owner')
    output = folder / 'rejected-output'
    run('owner-version-two-coordinate', [CLI, 'knowledge', 'coordinate', project, case, output], 2,
        [project, case, gold, retained], new_output=output, diagnostic='COORD_SCHEMA')
    check('owner-version-two-check', project, case, retained, gold, 1, 'source owner/schema_version: value')
    ROWS.append(dict(name='owner-version-two', coordinate_exit=2, coordinate_diagnostic='COORD_SCHEMA',
                     check_exit=1, check_diagnostic='source owner/schema_version: value', no_success_ir=True,
                     owner_only_changed_before_freeze=True, all_original_ir_gold_candidate_bytes_retained=True))


def author_case(name, version, author, error):
    baseline = ROOT / 'probes/legal-original'
    folder = ROOT / 'probes' / name
    folder.mkdir(parents=True)
    project = copy_tree_new(baseline / 'project', folder / 'project')
    review_dir = folder / 'prepared-author-review'
    review_dir.mkdir()
    old_bundle = baseline / 'case/bundle-b'
    review = read_json(old_bundle / 'review-original.json')
    gold_input = read_json(old_bundle / 'gold-original.json')
    gold_input['schema_version'] = version
    if version == 1:
        assert not gold_input['exceptions'] and gold_input['value_status'] == 'known'
        del gold_input['exceptions']
        del gold_input['value_status']
    gold_input['author'] = author
    gold_bytes = encoded(gold_input)
    review['gold_sha256'] = fp_bytes(gold_bytes)['sha256']
    new_bytes(review_dir / 'review.json', encoded(review))
    new_bytes(review_dir / review['gold_file'], gold_bytes)
    for role, original in [('candidate_file', 'candidates-original.json'), ('decision_file', 'decision-original.json')]:
        new_bytes(review_dir / review[role], (old_bundle / original).read_bytes())
    coordination_gold = folder / 'gold.json'
    new_bytes(coordination_gold, (baseline / 'gold.json').read_bytes())
    candidate = read_json(old_bundle / 'candidates-original.json')
    source_output = folder / 'genuine-source-review-output'
    prepared = run(name + '-source-review', [CLI, 'extract', 'verify', project, candidate['binding']['import_id'], review_dir, source_output], 0,
                   [project, review_dir, coordination_gold], new_output=source_output)
    assert read_json(source_output / 'verification.json')['status'] == 'passed'
    assert set(p.name for p in source_output.iterdir()) == set(FILES)
    assert (source_output / 'gold-original.json').read_bytes() == gold_bytes
    override = {'bundle-b/' + name: (source_output / name).read_bytes() for name in FILES}
    manifest = read_json(baseline / 'case/coordination.json')
    next(i for i in manifest['inputs'] if i['input_id'] == 'b')['artifacts'] = {name: fp(source_output / name) for name in FILES}
    override['coordination.json'] = encoded(manifest)
    case = copy_tree_new(baseline / 'case', folder / 'case', override)
    new_json(folder / 'author-derivation.json', dict(author_schema_version=version, author_utf8_bytes=len(author.encode('utf-8')),
             boundary='blank' if not author.strip() else '2048 UTF8 bytes', source_review_generated_by_ordinary_cli=True,
             all_nine_case_bundle_bytes_from_genuine_source_review=True, source_review_exit=0,
             original_candidate_decision_unchanged=True, new_gold_created_before_source_review=True))
    retained = copy_tree_new(baseline / 'ordinary-output', folder / 'copied-valid-result-for-invalid-author')
    output = folder / 'rejected-output'
    run(name + '-coordinate', [CLI, 'knowledge', 'coordinate', project, case, output], 2,
        [project, review_dir, coordination_gold, case, source_output, retained], new_output=output, diagnostic=error)
    check(name + '-check', project, case, retained, coordination_gold, 1, 'source role text type/limit', extras=(review_dir, source_output))
    ROWS.append(dict(name=name, original_gold_schema_version=version, author_utf8_bytes=len(author.encode('utf-8')),
                     genuine_source_review_exit=0, coordinate_exit=2, coordinate_diagnostic=error,
                     check_exit=1, check_diagnostic='source role text type/limit', no_success_ir=True,
                     copied_result_classification='deliberately copied valid baseline against invalid author input; not claimed as CLI coordination success'))


def group_two():
    previous = read_json(ROOT / 'probe-group-1.json')
    CALLS.extend(previous['calls'])
    ROWS.extend(previous['scenarios'])
    for label, change in [('schema-config-only', 'config'), ('schema-metadata-only', 'metadata'),
                          ('schema-user-version-only', 'user_version'), ('sql-project-id-only', 'project_id')]:
        mismatch_case(label, change)
    owner_case()
    author_case('gold-v1-blank-author', 1, '   ', 'COORD_SCHEMA')
    author_case('gold-v2-long-author', 2, 'a' * 2048, 'COORD_INPUT_LIMIT')
    assert len(CALLS) == 24 and len(ROWS) == 11
    new_json(ROOT / 'probe-group-2.json', dict(schema_version=1, calls=CALLS, scenarios=ROWS,
                     cli=FIXED_CLI, current_source_files=PIN['source_files'],
                     originals_and_outputs_preserved=True, model_calls=0, network_calls=0,
                     positive_mapped_id_set_proof='Python set(cm[referenced matches]) == {selected role}; Rust BTreeSet(mapped IDs) len1/contains. No count on original components.'))
    print('GROUP_TWO_OK', flush=True)


if __name__ == '__main__':
    assert Path(sys.executable) == PYTHON
    if sys.argv[1:] == ['one']:
        group_one()
    elif sys.argv[1:] == ['two']:
        group_two()
    else:
        raise AssertionError('expected group one/two')
