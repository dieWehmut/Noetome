# PDF 单文件解析沙盒

| 字段 | 值 |
| --- | --- |
| schema_version | 1 |
| report_kind | pdf_parse_sandbox |
| status | parsed |
| input_sha256 | 1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457 |
| input_byte_length | 873 |
| parser | pdfplumber 0.11.9 / pdfminer.six 20251230 / noetome-pdf-text-v1 / crop-pt-lines-v1 / Python 3.12.14 |
| page_count | 1 |
| parsed_page_count | 1 |
| needs_review_page_count | 0 |
| failed_page_count | 0 |
| manifest_path | parser/pdf-manifest.json |
| manifest_sha256 | f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046 |
| elapsed_ms | 264 |
| resource_bytes | 25955 |

物理索引从0开始；显示物理页为索引+1；印刷页码未确认。知识抽取、OCR与科学验证未运行。

| 物理索引 | 显示物理页 | 状态 |
| --- | --- | --- |
| 0 | 1 | parsed |

| 问题 | 来源单元 | 原因 |
| --- | --- | --- |
