from pathlib import Path
from collections import Counter
import hashlib,json,re,sys,zipfile
ROOT=Path(__file__).resolve().parent;REPO=Path('D:/Noetome');SDD=REPO/'.superpowers/sdd/B05-T01_COORDINATION_PLAN'
sys.path.insert(0,str(REPO/'scripts'))
import verify_knowledge_coordination as v
result={'reviewed_range':{'base':'ea4d900d14f47f453855ad1277afb3a808dbec0a','head':'f76496ad87b163603471dfc98b362bd2bd2895a9'},'receipts':[],'archives':[]}
for name in ['task1-fix1-fmt-receipt.json','task1-fix1-check-receipt.json','task1-fix1-workspace-receipt.json','root-final-python-01-receipt.json','task2-fix1-final-module-receipt.json','task2-fix1-audit-receipt.json','task2-fix1-check-receipt.json']:
    receipt=json.loads((SDD/name).read_bytes())
    assert receipt['exit_code']==0 and receipt['source_files_before']==receipt['source_files_after']
    for path,pin in receipt['source_files_after'].items():
        assert v.fingerprint((REPO/path).read_bytes())==pin, ('current source bytes',name,path)
    outputs={}
    for stream in ('stdout','stderr'):
        pin=receipt[stream];raw=Path(pin['path']).read_bytes()
        assert v.fingerprint(raw)=={k:pin[k] for k in ('sha256','byte_length')}
        outputs[stream]=raw.decode('utf-8')
    entry=dict(name=name,exit_code=0,head_before=receipt['head_before'],head_after=receipt['head_after'],source_files=len(receipt['source_files_before']),before_after_current_bytes_match=True,raw_stream_hashes_match=True)
    if name=='task1-fix1-workspace-receipt.json':
        suites=[list(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',outputs['stdout'])]
        assert len(suites)==16 and [sum(s[i] for s in suites) for i in range(3)]==[558,0,0]
        entry.update(suites=16,passed=558,failed=0,ignored=0,cli=receipt['cli'])
    if name in ('root-final-python-01-receipt.json','task2-fix1-final-module-receipt.json'):
        matches=re.findall(r'Ran (\d+) tests in ([\d.]+)s',outputs['stderr']);assert len(matches)==1
        count=int(matches[0][0]);assert count==(138 if name.startswith('root-') else 30)
        assert re.search(r'\nOK\s*$',outputs['stderr'])
        entry.update(tests=count,test_seconds=float(matches[0][1]),result='OK')
    result['receipts'].append(entry)
for label in ('source-review-fixture','rust-evidence','python-evidence'):
    manifest_path=REPO/('doc/validation/assets/B05-T01-'+label+'-manifest.json')
    manifest=json.loads(manifest_path.read_bytes())
    archive_path=REPO/manifest['archive'];pin=v.fingerprint(archive_path.read_bytes())
    assert pin=={k:manifest[k] for k in ('sha256','byte_length')}
    with zipfile.ZipFile(archive_path) as archive:
        assert len(archive.infolist())==manifest['member_count']
        assert archive.testzip() is None
        for member in manifest['members']:
            assert v.fingerprint(archive.read(member['member']))=={k:member[k] for k in ('sha256','byte_length')}
    result['archives'].append(dict(archive=manifest['archive'],**pin,member_count=manifest['member_count'],listed_members_verified=len(manifest['members']),crc_passed=True))

audit_root=REPO/'target/compiler-temp/task2-coordinate-audit-fix1-01'
audit=json.loads((audit_root/'audit.json').read_bytes())
assert audit['scenario_count']==33 and audit['command_count']==56 and len(audit['calls'])==56
for call in audit['calls']:
    assert call['exit_code']==call['expected_exit']
    for stream in ('stdout','stderr'):
        pin=call[stream]
        assert v.fingerprint(Path(pin['path']).read_bytes())=={k:pin[k] for k in ('sha256','byte_length')}
    receipt_path=Path(call['stdout']['path'].removesuffix('.stdout.txt')+'.json')
    assert json.loads(receipt_path.read_bytes())==call
assert audit['protected_before']==audit['protected_after']
for path,pin in audit['protected_before'].items():
    p=Path(path)
    after=v.inventory(p) if p.is_dir() else v.fingerprint(p.read_bytes())
    assert after==pin,('protected original',path)
assert audit['network_calls']==audit['paid_calls']==0
result['audit']=dict(root=str(audit_root),scenarios=33,commands=56,expected_exits_and_112_stream_hashes_verified=True,actual_exit_counts=dict(Counter(str(c['exit_code']) for c in audit['calls'])),protected_groups=len(audit['protected_before']),all_before_after_and_current_originals_match=True)

# Inspect preserved first failure logs without recasting them as passing tests.
for name,expected_failures in [('task1-fix1-red-receipt.json',7),('task2-fix1-real-red-receipt.json',13)]:
    receipt=json.loads((SDD/name).read_bytes());assert receipt['exit_code']!=0
    for stream in ('stdout','stderr'):
        pin=receipt[stream]
        assert v.fingerprint(Path(pin['path']).read_bytes())=={k:pin[k] for k in ('sha256','byte_length')}
    joined='\n'.join(Path(receipt[s]['path']).read_text(encoding='utf-8') for s in ('stdout','stderr'))
    if name.startswith('task1'):
        assert '0 passed; 7 failed' in joined
    else:
        assert 'failures=13' in joined and 'AssertionError not raised' in joined
result['retained_failure_receipts_verified']=['task1-fix1-red (7 failures)','task2-fix1-real-red (13 mistaken acceptances)']
result['final_source_hashes']={p:v.fingerprint((REPO/p).read_bytes()) for p in ('scripts/verify_knowledge_coordination.py','tests/test_knowledge_coordination_verifier.py','target/debug/noetome.exe')}
with (ROOT/'evidence-inspection.json').open('xb') as stream:stream.write(v.encoded(result))
print(json.dumps(result,ensure_ascii=False,indent=2))