from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/Noetome'); BASE=ROOT/'baseline'
sys.path.insert(0,str(REPO/'scripts'))
import verify_knowledge_coordination as v
CLI=REPO/'target/debug/noetome.exe'
PY=Path('C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
RECORD={'root':str(ROOT),'cli_fingerprint':v.fingerprint(CLI.read_bytes()),'calls':[],'scenarios':[]}
BEFORE=v.inventory(BASE)
def save(path,value):
    assert Path(path).resolve().is_relative_to(ROOT)
    Path(path).write_bytes(v.encoded(value))
def call(name,args,protected=(),environment=None):
    before=[v.inventory(p) for p in protected]
    started=time.monotonic()
    run=subprocess.run(list(map(str,args)),capture_output=True,timeout=45,env=environment)
    out,err=ROOT/(name+'.stdout.txt'),ROOT/(name+'.stderr.txt')
    assert not out.exists() and not err.exists()
    out.write_bytes(run.stdout);err.write_bytes(run.stderr)
    after=[v.inventory(p) for p in protected]
    receipt={'name':name,'argv':list(map(str,args)),'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':{'path':str(out),**v.fingerprint(run.stdout)},'stderr':{'path':str(err),**v.fingerprint(run.stderr)},'protected_paths':list(map(str,protected)),'before':before,'after':after,'unchanged':before==after}
    save(ROOT/(name+'.receipt.json'),receipt)
    RECORD['calls'].append({k:receipt[k] for k in ('name','argv','exit_code','stdout','stderr','unchanged')})
    assert before==after
    return run
def clone(name):
    folder=ROOT/name;folder.mkdir()
    for sub in ('project','case'):
        shutil.copytree(BASE/sub,folder/sub)
    (folder/'gold.json').write_bytes((BASE/'gold.json').read_bytes())
    return folder,folder/'project',folder/'case'
def check(name,folder,project,case,output):
    return call(name,[PY,'-B','-X','utf8',REPO/'scripts/verify_knowledge_coordination.py','check',project,case,output,folder/'gold.json'],(project,case,output))

# Ordinary PDF registration upgrades the copied project; coordinate still uses
# only the original three Text spans. This is project compatibility, not PDF coordination.
folder,project,case=clone('schema3-text')
pdf=folder/'single-page.pdf';pdf.write_bytes((REPO/'fixtures/pdf-text-v1/single-page.pdf').read_bytes())
run=call('schema3-text-source-import',[CLI,'source','import',project,pdf],(case,pdf,folder/'gold.json'),dict(os.environ,NOETOME_PDF_PYTHON=str(PY)))
assert run.returncode==0,run.stderr.decode()
manifest=v.strict_json((project/'project.json').read_bytes())
assert manifest['schema_version']==3
out=folder/'output'
run=call('schema3-text-coordinate',[CLI,'knowledge','coordinate',project,case,out],(project,case))
assert run.returncode==0,run.stderr.decode()
verified=check('schema3-text-python-check',folder,project,case,out)
RECORD['scenarios'].append({'name':'schema3-text','project_schema_version':3,'selected_input_kinds':['text','text','text'],'coordinate_exit':run.returncode,'python_check_exit':verified.returncode,'python_error':verified.stderr.decode()})

# Owner version remains a String/u32 DTO and its value is checked as semantics.
folder,project,case=clone('owner-version')
p=case/'bundle-a/.owner.json';owner=v.strict_json(p.read_bytes());owner['schema_version']=2;save(p,owner)
m=v.strict_json((case/'coordination.json').read_bytes());item=m['inputs'][0]
item['artifacts']={n:v.fingerprint((case/item['review_bundle']/n).read_bytes()) for n in v.FILES}
save(case/'coordination.json',m)
run=call('owner-version-coordinate',[CLI,'knowledge','coordinate',project,case,folder/'output'],(project,case))
RECORD['scenarios'].append({'name':'owner-version','coordinate_exit':run.returncode,'coordinate_error':run.stderr.decode(),'success_ir_exists':(folder/'output/coordination-ir.json').exists()})

# The coordinator projects GoldInput into Gold before validating author text.
folder,project,case=clone('blank-gold-author')
m=v.strict_json((case/'coordination.json').read_bytes())
v.Audit.coherent_role_change(m,case,'gold','author','   ')
save(case/'coordination.json',m)
out=folder/'output';run=call('blank-gold-author-coordinate',[CLI,'knowledge','coordinate',project,case,out],(project,case))
verified=check('blank-gold-author-python-check',folder,project,case,out) if run.returncode==0 else None
RECORD['scenarios'].append({'name':'blank-gold-author','coordinate_exit':run.returncode,'coordinate_error':run.stderr.decode(),'python_check_exit':verified.returncode if verified else None,'python_error':verified.stderr.decode() if verified else None})

assert v.inventory(BASE)==BEFORE
assert v.fingerprint(CLI.read_bytes())==RECORD['cli_fingerprint']
RECORD['baseline_preserved']=True
save(ROOT/'phase2-summary.json',RECORD)
print(json.dumps({'root':str(ROOT),'scenarios':RECORD['scenarios'],'baseline_preserved':True},ensure_ascii=False,indent=2))