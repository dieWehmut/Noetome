from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, sys, time, uuid, zipfile
ROOT = Path(__file__).resolve().parent
REPO = Path('D:/Noetome')
sys.path.insert(0, str(REPO / 'scripts'))
import verify_knowledge_coordination as v
CLI = REPO / 'target/debug/noetome.exe'
PY = Path('C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
ASSET = REPO / 'doc/validation/assets/B05-T01-source-review-fixture.zip'
BASE = ROOT / 'baseline'
RESULT = {'root': str(ROOT), 'cli_fingerprint': v.fingerprint(CLI.read_bytes()), 'python_source_fingerprint': v.fingerprint((REPO/'scripts/verify_knowledge_coordination.py').read_bytes()), 'calls': [], 'checks': [], 'scenarios': []}

def save(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(ROOT)
    path.write_bytes(v.encoded(value))

def call(name, argv, protected=()):
    before = [v.inventory(Path(p)) for p in protected]
    started = time.monotonic()
    run = subprocess.run(list(map(str, argv)), capture_output=True, timeout=45)
    stem = ROOT / name
    outpath, errpath = stem.with_suffix('.stdout.txt'), stem.with_suffix('.stderr.txt')
    assert not outpath.exists() and not errpath.exists()
    outpath.write_bytes(run.stdout); errpath.write_bytes(run.stderr)
    after = [v.inventory(Path(p)) for p in protected]
    receipt = {'name':name, 'argv':list(map(str,argv)), 'exit_code':run.returncode, 'elapsed_seconds':time.monotonic()-started, 'stdout':{'path':str(outpath), **v.fingerprint(run.stdout)}, 'stderr':{'path':str(errpath), **v.fingerprint(run.stderr)}, 'protected_paths':list(map(str,protected)), 'before':before, 'after':after, 'unchanged':before==after}
    save(stem.with_suffix('.receipt.json'), receipt)
    RESULT['calls'].append({k:receipt[k] for k in ('name','argv','exit_code','stdout','stderr','unchanged')})
    assert before == after, 'read-only command changed inputs: '+name
    return run

def check(name, project, case, output, gold):
    before=[v.inventory(p) for p in (project,case,output)]
    try:
        result=v.verify_report(project,case,output,gold)
        outcome={'accepted':True,'result':result}
    except Exception as exc:
        outcome={'accepted':False,'error_type':type(exc).__name__,'diagnostic':str(exc)}
    after=[v.inventory(p) for p in (project,case,output)]
    assert before==after
    save(ROOT/(name+'.direct-check.json'), dict(outcome, protected_paths=list(map(str,(project,case,output))),before=before,after=after,unchanged=True))
    RESULT['checks'].append(dict(name=name,**outcome,unchanged=True))
    return outcome

def prepare(name, mutate_candidate, expected_evidence=3):
    folder=ROOT/name; folder.mkdir()
    project, case=folder/'project',folder/'case'
    shutil.copytree(BASE/'project',project)
    shutil.copytree(BASE/'case',case,ignore=lambda path,names:['bundle-a'] if Path(path)==BASE/'case' else [])
    gold=v.strict_json((BASE/'gold.json').read_bytes())
    gold['expected_evidence_links']=expected_evidence
    gold_raw=v.encoded(gold); (folder/'gold.json').write_bytes(gold_raw)
    save(folder/'gold-frozen-before-candidate.json',dict(gold_fingerprint=v.fingerprint(gold_raw), fact_origin='public pre-authored gold; only support-link count changed where stated',before_candidate=True))
    original=BASE/'case/bundle-a'
    candidate=v.strict_json((original/'candidates-original.json').read_bytes())
    mutate_candidate(candidate)
    review=v.strict_json((original/'review-original.json').read_bytes())
    roles=folder/'review-a'; roles.mkdir()
    (roles/'review.json').write_bytes((original/'review-original.json').read_bytes())
    (roles/review['candidate_file']).write_bytes(v.encoded(candidate))
    (roles/review['gold_file']).write_bytes((original/'gold-original.json').read_bytes())
    (roles/review['decision_file']).write_bytes((original/'decision-original.json').read_bytes())
    run=call(name+'-source-review',[CLI,'extract','verify',project,candidate['binding']['import_id'],roles,case/'bundle-a'],[project,roles])
    assert run.returncode==0, run.stderr.decode()
    manifest=v.strict_json((case/'coordination.json').read_bytes())
    first=next(i for i in manifest['inputs'] if i['input_id']=='a')
    first['artifacts']={n:v.fingerprint((case/first['review_bundle']/n).read_bytes()) for n in v.FILES}
    save(case/'coordination.json',manifest)
    return folder,project,case,gold_raw,candidate

assert RESULT['cli_fingerprint']['sha256']=='97ebd64ec0a2fe84e08a64e5a126f5b61e81adb24deb43b65de7be7aef809203'
assert v.fingerprint(ASSET.read_bytes())['sha256']=='56226f12ff26f6e4199029e2c0230cfaecc5048b00272410b161bafc7e15682f'
ignore=subprocess.run(['git','check-ignore',str(ROOT)],cwd=REPO,capture_output=True)
assert ignore.returncode==0, ignore.stderr.decode()
RESULT['ignored_root']=ignore.stdout.decode().strip()
BASE.mkdir()
with zipfile.ZipFile(ASSET) as archive:
    assert len(archive.infolist())==131
    for member in archive.infolist():
        name=Path(member.filename)
        assert not name.is_absolute() and '..' not in name.parts and '\\' not in member.filename and ':' not in member.filename
        target=BASE/name
        assert target.resolve().is_relative_to(BASE)
        if member.is_dir(): target.mkdir(parents=True,exist_ok=True)
        else:
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:stream.write(archive.read(member))
BASE_BEFORE=v.inventory(BASE)
assert check('baseline',BASE/'project',BASE/'case',BASE/'output',(BASE/'gold.json').read_bytes())['accepted']

# Legal source_review with two supports, listed in a different order by the atom.
def reverse_supports(candidate):
    payload=candidate['payload']; second=copy.deepcopy(payload['evidence'][0]); second['evidence_id']='a-support-second'
    payload['evidence'].append(second)
    links=payload['atoms'][0]['atom']['evidence_links']
    links.insert(0,{'evidence_id':second['evidence_id'],'relation':'supports'})
folder,project,case,gold,candidate=prepare('support-order',reverse_supports,4)
output=folder/'output'
run=call('support-order-coordinate',[CLI,'knowledge','coordinate',project,case,output],[project,case])
assert run.returncode==0, run.stderr.decode()
r=v.strict_json(run.stdout); occurrence=next(o for o in r['occurrences'] if o['input_id']=='a')
outcome=check('support-order',project,case,output,gold)
verification=call('support-order-python-check',[PY,'-B','-X','utf8',REPO/'scripts/verify_knowledge_coordination.py','check',project,case,output,folder/'gold.json'],[project,case,output])
RESULT['scenarios'].append({'name':'support-order','source_review_exit':0,'coordinate_exit':run.returncode,'python_check_exit':verification.returncode,'retained_support_ids':[e['evidence_id'] for e in occurrence['original_evidence']],'payload_evidence_ids':[e['evidence_id'] for e in candidate['payload']['evidence']],'totals':r['totals'],'direct_check':outcome})

# Source-reviewed aliases make two distinct canonical IDs match the subject.
def ambiguous_alias(candidate):
    candidate['payload']['concepts'][1]['aliases'].append('样例 A')
folder,project,case,gold,candidate=prepare('ambiguous-role',ambiguous_alias)
run=call('ambiguous-role-coordinate',[CLI,'knowledge','coordinate',project,case,folder/'rejected-output'],[project,case])
forged=folder/'forged-output';shutil.copytree(BASE/'output',forged)
report=v.strict_json((forged/'coordination.json').read_bytes())
manifest_raw=(case/'coordination.json').read_bytes();manifest=v.strict_json(manifest_raw)
item=next(i for i in manifest['inputs'] if i['input_id']=='a')
source_report=v.strict_json((case/item['review_bundle']/'verification.json').read_bytes())
for name in v.FILES:
    (forged/('input-a--'+name)).write_bytes((case/item['review_bundle']/name).read_bytes())
(forged/'coordination-original.json').write_bytes(manifest_raw)
coord_input=next(i for i in report['inputs'] if i['input_id']=='a')
coord_input.update(source_review_checks=source_report['checks'],source_bundle_fingerprints=item['artifacts'])
next(o for o in report['occurrences'] if o['input_id']=='a')['original_concepts']=candidate['payload']['concepts']
v.Audit.rewrite_forgery(forged,report)
outcome=check('ambiguous-role-forgery',project,case,forged,gold)
verification=call('ambiguous-role-python-check',[PY,'-B','-X','utf8',REPO/'scripts/verify_knowledge_coordination.py','check',project,case,forged,folder/'gold.json'],[project,case,forged])
RESULT['scenarios'].append({'name':'ambiguous-role','source_review_exit':0,'coordinate_exit':run.returncode,'coordinate_error':run.stderr.decode(),'python_forged_check_exit':verification.returncode,'direct_check':outcome})

assert v.inventory(BASE)==BASE_BEFORE, 'public baseline copy changed'
assert v.fingerprint(CLI.read_bytes())==RESULT['cli_fingerprint']
assert v.fingerprint((REPO/'scripts/verify_knowledge_coordination.py').read_bytes())==RESULT['python_source_fingerprint']
RESULT['baseline_preserved']=True
save(ROOT/'probe-summary.json',RESULT)
print(json.dumps({'root':str(ROOT),'scenarios':RESULT['scenarios'],'baseline_preserved':True},ensure_ascii=False,indent=2))