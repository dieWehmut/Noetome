# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

显式身份重复／互补范围；完整来源、原对象、证据与分母见以下事实，与 coordination.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "3dbd1230-ae82-499e-828c-371c8ff5c067",
  "scope": "explicit_identity_duplicate_complement_v1",
  "project_id": "24d06e69-696f-4347-a597-555dea009a69",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "display_name": "速度"
    },
    {
      "canonical_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "display_name": "质量"
    },
    {
      "canonical_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "display_name": "样例 A"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "24d06e69-696f-4347-a597-555dea009a69",
        "import_id": "18648d6f-45aa-4752-b510-3a190eaaadfc",
        "source_id": "d2686102-039d-4ccc-bda9-c28ce3500cca",
        "version_id": "bb498c61-4c4e-4b5b-a96c-d3b34a8d3c03",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "18648d6f-45aa-4752-b510-3a190eaaadfc",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "24d06e69-696f-4347-a597-555dea009a69",
              "source_id": "d2686102-039d-4ccc-bda9-c28ce3500cca",
              "version_id": "bb498c61-4c4e-4b5b-a96c-d3b34a8d3c03"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "18648d6f-45aa-4752-b510-3a190eaaadfc",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "24d06e69-696f-4347-a597-555dea009a69",
              "source_id": "d2686102-039d-4ccc-bda9-c28ce3500cca",
              "version_id": "bb498c61-4c4e-4b5b-a96c-d3b34a8d3c03"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [
                  "样例 A"
                ],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "review-original.json": {
          "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
          "byte_length": 509
        },
        "candidates-original.json": {
          "sha256": "69a65447b50782f88b31c046e2882e08f63984906fb0cf2c70dccd9c9bf636ea",
          "byte_length": 3009
        },
        "gold-original.json": {
          "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
          "byte_length": 726
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "source-snapshot.json": {
          "sha256": "69d8332a9f2f6184e24708a0453c5cec8b4eb7e4650ef9e4abdfc8dd56d01bee",
          "byte_length": 996
        },
        "knowledge-ir.json": {
          "sha256": "4e55bb5985929a541a78ee046656d9d11911ce02c8dea51bac2e865e4e004d4b",
          "byte_length": 12145
        },
        "verification.json": {
          "sha256": "bfad91103806dccdb07e9d234e7a44f508ac128d5ac13139c2f0cc3e785f045c",
          "byte_length": 16611
        },
        "verification.md": {
          "sha256": "8fc1289c65ee9dce6a93357ab05a7bad3662b4b46639ac10366f9a6a311065c6",
          "byte_length": 17045
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "24d06e69-696f-4347-a597-555dea009a69",
        "import_id": "4b3726b3-bed4-4ee4-a6b3-4efe0499db5f",
        "source_id": "31763a84-5ce1-4d10-ac0d-0d6ca6315cb5",
        "version_id": "d6815201-b2ff-4570-88db-821a5f229b6d",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "4b3726b3-bed4-4ee4-a6b3-4efe0499db5f",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "24d06e69-696f-4347-a597-555dea009a69",
              "source_id": "31763a84-5ce1-4d10-ac0d-0d6ca6315cb5",
              "version_id": "d6815201-b2ff-4570-88db-821a5f229b6d"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "4b3726b3-bed4-4ee4-a6b3-4efe0499db5f",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "24d06e69-696f-4347-a597-555dea009a69",
              "source_id": "31763a84-5ce1-4d10-ac0d-0d6ca6315cb5",
              "version_id": "d6815201-b2ff-4570-88db-821a5f229b6d"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "8f72935eac35bcd87cf951194a5448d31b6d5c7e558787ba6b556a36f32c7067",
          "byte_length": 2978
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
          "byte_length": 726
        },
        "knowledge-ir.json": {
          "sha256": "2fc0a78acf4122e2c1cfc5fd06d7a7f492e30763ad46c145919c29f2b034b0c5",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "fd34a45419c99d449b28b04e9c3f83d6e40240cfe5f0a67a8ae94123acfffd8e",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "12ca75378b03aee05a3571c025cdff63e646f6d0bed9d6561055cce898fb94e3",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "3321bd7df6fe6fd059eead388d44ded0f33bda420531c9de79c9a46f4959f061",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "24d06e69-696f-4347-a597-555dea009a69",
        "import_id": "78bbd451-28d8-4da0-81d6-29b3abbdffe2",
        "source_id": "4d63212a-d916-4056-8825-feb083bfe0bc",
        "version_id": "f809f8a1-c636-484b-95a1-8fe77bc8cbcb",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "78bbd451-28d8-4da0-81d6-29b3abbdffe2",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "24d06e69-696f-4347-a597-555dea009a69",
              "source_id": "4d63212a-d916-4056-8825-feb083bfe0bc",
              "version_id": "f809f8a1-c636-484b-95a1-8fe77bc8cbcb"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "78bbd451-28d8-4da0-81d6-29b3abbdffe2",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "24d06e69-696f-4347-a597-555dea009a69",
              "source_id": "4d63212a-d916-4056-8825-feb083bfe0bc",
              "version_id": "f809f8a1-c636-484b-95a1-8fe77bc8cbcb"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 104,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 105,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 104,
            "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 104,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 104,
              "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "ae2b3937530e7ce93ff3538e22708b07790229939fc528253b164e2b1c41ee4e",
          "byte_length": 2970
        },
        "decision-original.json": {
          "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
          "byte_length": 139
        },
        "gold-original.json": {
          "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
          "byte_length": 720
        },
        "knowledge-ir.json": {
          "sha256": "ebbd2ccbc3eb4fd615caf79efbedbef2f869ac3e6f1ba31ba5df04e20dc2b8f0",
          "byte_length": 12036
        },
        "review-original.json": {
          "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "b68ebaf5874d0d6ea52e00bff62612b62aea64cae19cbc678a92a1c56ef4df4b",
          "byte_length": 994
        },
        "verification.json": {
          "sha256": "6246087731737ce85881e8dc29c6b50564667cf020be6d3753391c9f513d45d8",
          "byte_length": 16533
        },
        "verification.md": {
          "sha256": "839234acb6061cfac1e14010b34b46ada61ba02d4eafc729eb5866b2921166e0",
          "byte_length": 16967
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "occurrence_id": "occ-39dbbb1fc509590cff50906b6244485836448bccf4200d99ebd2e1cc64f9e23f",
      "input_id": "b",
      "binding": {
        "project_id": "24d06e69-696f-4347-a597-555dea009a69",
        "import_id": "4b3726b3-bed4-4ee4-a6b3-4efe0499db5f",
        "source_id": "31763a84-5ce1-4d10-ac0d-0d6ca6315cb5",
        "version_id": "d6815201-b2ff-4570-88db-821a5f229b6d",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "53b3db1c-2e16-4014-a920-2fab46d7bb2b",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-4827c389b82696c050aa044157086f64b8cb99f48347dbad39f9c7630c76fc7a",
      "input_id": "c",
      "binding": {
        "project_id": "24d06e69-696f-4347-a597-555dea009a69",
        "import_id": "78bbd451-28d8-4da0-81d6-29b3abbdffe2",
        "source_id": "4d63212a-d916-4056-8825-feb083bfe0bc",
        "version_id": "f809f8a1-c636-484b-95a1-8fe77bc8cbcb",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "dcfc7a8b-cabb-43e2-b17e-33187859b571",
          "ordinal": 0,
          "resource_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 105,
        "text": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 104,
          "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
          "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "51fa59a0-255f-4867-836c-aa39bdc01906",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-5b77be6a6c984320b1242a4e9ecc1fb66d46434b7b851aea6b173327b7ea2762",
      "input_id": "a",
      "binding": {
        "project_id": "24d06e69-696f-4347-a597-555dea009a69",
        "import_id": "18648d6f-45aa-4752-b510-3a190eaaadfc",
        "source_id": "d2686102-039d-4ccc-bda9-c28ce3500cca",
        "version_id": "bb498c61-4c4e-4b5b-a96c-d3b34a8d3c03",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "ac7a0286-ced4-41b1-a472-25ec1740b262",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "aliases": [],
          "canonical_name": "样例 A",
          "concept_id": "a-subject",
          "needs_full_explanation": true,
          "revision": 1
        },
        {
          "aliases": [
            "样例 A"
          ],
          "canonical_name": "速度",
          "concept_id": "a-property",
          "needs_full_explanation": true,
          "revision": 1
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "fact_id": "fact-2176d0ef755e6f1de61cf485f79a5805b933ddc9487e83fcd12064c305a175a4",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-39dbbb1fc509590cff50906b6244485836448bccf4200d99ebd2e1cc64f9e23f",
        "occ-5b77be6a6c984320b1242a4e9ecc1fb66d46434b7b851aea6b173327b7ea2762"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "fact_id": "fact-6bc62067e5e15c97430ccb915d046434ef2b5edab41254cf60e7ef28f896d03b",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-4827c389b82696c050aa044157086f64b8cb99f48347dbad39f9c7630c76fc7a"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "left_occurrence_id": "occ-39dbbb1fc509590cff50906b6244485836448bccf4200d99ebd2e1cc64f9e23f",
      "right_occurrence_id": "occ-4827c389b82696c050aa044157086f64b8cb99f48347dbad39f9c7630c76fc7a",
      "relation": "complement",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-39dbbb1fc509590cff50906b6244485836448bccf4200d99ebd2e1cc64f9e23f",
      "right_occurrence_id": "occ-5b77be6a6c984320b1242a4e9ecc1fb66d46434b7b851aea6b173327b7ea2762",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-4827c389b82696c050aa044157086f64b8cb99f48347dbad39f9c7630c76fc7a",
      "right_occurrence_id": "occ-5b77be6a6c984320b1242a4e9ecc1fb66d46434b7b851aea6b173327b7ea2762",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "totals": {
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c726dee2db34c62695f9816ddcf1e34c8bda579967a845fe26a7d1498dc38ea1",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "a05f540963d4da8328f80d085cf377819bd74c83414b8fc2e677750420d34190",
      "byte_length": 56000
    },
    "coordination-original.json": {
      "sha256": "143d0c142b20465d7fe0ce86aaf851081806075a91715863963c837e6fda78e7",
      "byte_length": 6404
    },
    "identity-original.json": {
      "sha256": "419d4155e834d9774b862516ffddc125a381c2c6cf36f35cc02cc1992d492048",
      "byte_length": 1616
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "69a65447b50782f88b31c046e2882e08f63984906fb0cf2c70dccd9c9bf636ea",
      "byte_length": 3009
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
      "byte_length": 726
    },
    "input-a--knowledge-ir.json": {
      "sha256": "4e55bb5985929a541a78ee046656d9d11911ce02c8dea51bac2e865e4e004d4b",
      "byte_length": 12145
    },
    "input-a--review-original.json": {
      "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "69d8332a9f2f6184e24708a0453c5cec8b4eb7e4650ef9e4abdfc8dd56d01bee",
      "byte_length": 996
    },
    "input-a--verification.json": {
      "sha256": "bfad91103806dccdb07e9d234e7a44f508ac128d5ac13139c2f0cc3e785f045c",
      "byte_length": 16611
    },
    "input-a--verification.md": {
      "sha256": "8fc1289c65ee9dce6a93357ab05a7bad3662b4b46639ac10366f9a6a311065c6",
      "byte_length": 17045
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "8f72935eac35bcd87cf951194a5448d31b6d5c7e558787ba6b556a36f32c7067",
      "byte_length": 2978
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "c8879dcb96df2b3581001f7be54f8386ac28cddaea893e6e5e7589fdd94f4f2e",
      "byte_length": 726
    },
    "input-b--knowledge-ir.json": {
      "sha256": "2fc0a78acf4122e2c1cfc5fd06d7a7f492e30763ad46c145919c29f2b034b0c5",
      "byte_length": 12081
    },
    "input-b--review-original.json": {
      "sha256": "ee8d18cbd1f42c3b54a4402ecaf99fdde7e38d56e540f8d0c0c7360f8b438db4",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "fd34a45419c99d449b28b04e9c3f83d6e40240cfe5f0a67a8ae94123acfffd8e",
      "byte_length": 996
    },
    "input-b--verification.json": {
      "sha256": "12ca75378b03aee05a3571c025cdff63e646f6d0bed9d6561055cce898fb94e3",
      "byte_length": 16573
    },
    "input-b--verification.md": {
      "sha256": "3321bd7df6fe6fd059eead388d44ded0f33bda420531c9de79c9a46f4959f061",
      "byte_length": 17007
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "ae2b3937530e7ce93ff3538e22708b07790229939fc528253b164e2b1c41ee4e",
      "byte_length": 2970
    },
    "input-c--decision-original.json": {
      "sha256": "72dcf7e8547b89e1acb5ccd39543e77dc705626cdf117040934703a691bc4cb2",
      "byte_length": 139
    },
    "input-c--gold-original.json": {
      "sha256": "9452d70104b425af74ea3593bf236a721b96dfb3d99bf343cb12724017842a59",
      "byte_length": 720
    },
    "input-c--knowledge-ir.json": {
      "sha256": "ebbd2ccbc3eb4fd615caf79efbedbef2f869ac3e6f1ba31ba5df04e20dc2b8f0",
      "byte_length": 12036
    },
    "input-c--review-original.json": {
      "sha256": "84537fee7154d8c1113d5cafd3b4ce34574ea18b9a7817c83799003af6a3e276",
      "byte_length": 509
    },
    "input-c--source-snapshot.json": {
      "sha256": "b68ebaf5874d0d6ea52e00bff62612b62aea64cae19cbc678a92a1c56ef4df4b",
      "byte_length": 994
    },
    "input-c--verification.json": {
      "sha256": "6246087731737ce85881e8dc29c6b50564667cf020be6d3753391c9f513d45d8",
      "byte_length": 16533
    },
    "input-c--verification.md": {
      "sha256": "839234acb6061cfac1e14010b34b46ada61ba02d4eafc729eb5866b2921166e0",
      "byte_length": 16967
    }
  }
}
```
