from pathlib import Path
import json, shutil, sqlite3, subprocess, sys, time
ROOT=Path(__file__).resolve().parent;BASE=ROOT/'baseline';REPO=Path('D:/Noetome')
sys.path.insert(0,str(REPO/'scripts'))
import verify_knowledge_coordination as v
CLI=REPO/'target/debug/noetome.exe';PY=Path('C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
BEFORE=v.inventory(BASE);RESULT={'scenarios':[],'calls':[]}
def save(path,value):
    assert Path(path).resolve().is_relative_to(ROOT)
    Path(path).write_bytes(v.encoded(value))
def call(name,args,protected):
    before=[v.inventory(p) for p in protected];start=time.monotonic()
    r=subprocess.run(list(map(str,args)),capture_output=True,timeout=45)
    out,err=ROOT/(name+'.stdout.txt'),ROOT/(name+'.stderr.txt');assert not out.exists() and not err.exists()
    out.write_bytes(r.stdout);err.write_bytes(r.stderr)
    after=[v.inventory(p) for p in protected]
    receipt=dict(name=name,argv=list(map(str,args)),exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,stdout=dict(path=str(out),**v.fingerprint(r.stdout)),stderr=dict(path=str(err),**v.fingerprint(r.stderr)),protected_paths=list(map(str,protected)),before=before,after=after,unchanged=before==after)
    save(ROOT/(name+'.receipt.json'),receipt);RESULT['calls'].append({k:receipt[k] for k in ('name','argv','exit_code','stdout','stderr','unchanged')});assert before==after
    return r

def clone(name):
    folder=ROOT/name;folder.mkdir()
    for n in ('project','case','output'):shutil.copytree(BASE/n,folder/n)
    (folder/'gold.json').write_bytes((BASE/'gold.json').read_bytes())
    return folder,folder/'project',folder/'case'
folder,project,case=clone('schema-pair-mismatch')
with sqlite3.connect(project/'project.sqlite') as db:db.execute('PRAGMA user_version=3')
run=call('schema-pair-mismatch-coordinate',[CLI,'knowledge','coordinate',project,case,folder/'rejected-output'],(project,case))
checked=call('schema-pair-mismatch-python-check',[PY,'-B','-X','utf8',REPO/'scripts/verify_knowledge_coordination.py','check',project,case,folder/'output',folder/'gold.json'],(project,case,folder/'output'))
RESULT['scenarios'].append(dict(name='schema-pair-mismatch',manifest_schema_version=2,sql_metadata_schema_version=2,sql_user_version=3,coordinate_exit=run.returncode,coordinate_error=run.stderr.decode(),python_check_exit=checked.returncode,python_result=checked.stdout.decode()))

folder,project,case=clone('gold-author-text-limit')
m=v.strict_json((case/'coordination.json').read_bytes());v.Audit.coherent_role_change(m,case,'gold','author','A'*2048);save(case/'coordination.json',m)
run=call('gold-author-text-limit-coordinate',[CLI,'knowledge','coordinate',project,case,folder/'new-output'],(project,case))
checked=call('gold-author-text-limit-python-check',[PY,'-B','-X','utf8',REPO/'scripts/verify_knowledge_coordination.py','check',project,case,folder/'new-output',folder/'gold.json'],(project,case,folder/'new-output')) if run.returncode==0 else None
RESULT['scenarios'].append(dict(name='gold-author-text-limit',gold_author_utf8_bytes=2048,contract_text_limit=1024,coordinate_exit=run.returncode,coordinate_error=run.stderr.decode(),python_check_exit=checked.returncode if checked else None,python_error=checked.stderr.decode() if checked else None))
assert v.inventory(BASE)==BEFORE
RESULT['baseline_preserved']=True;save(ROOT/'phase3-summary.json',RESULT)
print(json.dumps(RESULT['scenarios'],ensure_ascii=False,indent=2))