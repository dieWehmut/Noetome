from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
label = sys.argv[1]
assert label.replace('-', '').replace('_', '').isalnum()
argv = [sys.executable, '-X', 'utf8', '-B', *sys.argv[2:]]
stem = root / ('launch-' + label)
for suffix in ('.stdout.txt', '.stderr.txt', '.receipt.json'):
    assert not stem.with_suffix(suffix).exists()
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
temporary = root / 'runtime-temp'
temporary.mkdir(exist_ok=True)
env['TEMP'] = env['TMP'] = str(temporary)
started = time.monotonic()
run = subprocess.run(argv, cwd='D:/Noetome', env=env, capture_output=True, timeout=55)
streams = {}
for name, data in (('stdout', run.stdout), ('stderr', run.stderr)):
    path = stem.with_suffix('.' + name + '.txt')
    with path.open('xb') as stream:
        stream.write(data)
    streams[name] = dict(path=str(path), sha256=hashlib.sha256(data).hexdigest(), byte_length=len(data))
receipt = dict(schema_version=1, captured_at=datetime.now(timezone.utc).isoformat(), argv=argv,
               cwd='D:/Noetome', exit_code=run.returncode, elapsed_seconds=time.monotonic() - started, **streams)
with stem.with_suffix('.receipt.json').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
sys.stdout.buffer.write(run.stdout)
sys.stderr.buffer.write(run.stderr)
print('CAPTURED ' + json.dumps(dict(exit_code=run.returncode, receipt=str(stem.with_suffix('.receipt.json')))))
sys.exit(run.returncode)
