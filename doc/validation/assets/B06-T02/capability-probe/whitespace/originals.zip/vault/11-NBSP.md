# NBSP

仅为自造渲染能力探针，无科学含义，不是 Noetome 产品输出。

```mermaid
flowchart TD
  n0["甲 乙"]
  n1["甲 乙"]
  n0 --> n1
```

