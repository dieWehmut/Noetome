$p=Get-Process -Id 27960 -ErrorAction SilentlyContinue
$l=Get-NetTCPConnection -LocalPort 59046 -State Listen -ErrorAction SilentlyContinue
@{ownedPidAbsent=($null -eq $p);ownedListenerAbsent=($null -eq $l)} | ConvertTo-Json -Compress
