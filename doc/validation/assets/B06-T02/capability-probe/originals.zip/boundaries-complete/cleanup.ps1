$p=Get-Process -Id 2472 -ErrorAction SilentlyContinue
$l=Get-NetTCPConnection -LocalPort 62135 -State Listen -ErrorAction SilentlyContinue
@{ownedPidAbsent=($null -eq $p);ownedListenerAbsent=($null -eq $l)} | ConvertTo-Json -Compress
