$p=Get-Process -Id 1716 -ErrorAction SilentlyContinue
$l=Get-NetTCPConnection -LocalPort 60498 -State Listen -ErrorAction SilentlyContinue
@{ownedPidAbsent=($null -eq $p);ownedListenerAbsent=($null -eq $l)} | ConvertTo-Json -Compress
