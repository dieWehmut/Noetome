$p=Get-Process -Id 15240 -ErrorAction SilentlyContinue
$l=Get-NetTCPConnection -LocalPort 54803 -State Listen -ErrorAction SilentlyContinue
@{ownedPidAbsent=($null -eq $p);ownedListenerAbsent=($null -eq $l)} | ConvertTo-Json -Compress
