from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time,uuid
sys.path.insert(0,'scripts')
from verify_extraction_knowledge import actual_source
repo=Path.cwd();fixture=repo/'fixtures/process-flow-v1';root=repo/'target'/('process-flow-red-'+uuid.uuid4().hex);root.mkdir(parents=True)
def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
freeze=json.loads((fixture/'frozen-sha256.json').read_bytes())
for name,expected in freeze['files'].items():assert pin((fixture/name).read_bytes())==expected
shutil.copytree(fixture,root/'frozen-authors');cli=root/'noetome';shutil.copyfile(repo/'target/debug/noetome',cli);cli.chmod(0o755)
write(root/'before.json',{'fixture_manifest':pin((fixture/'frozen-sha256.json').read_bytes()),'cli':pin(cli.read_bytes()),'head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'phase':'frozen_before_any_cli_calls'})
commands=[]
def command(label,args):
 argv=[str(cli),*map(str,args)];start=time.monotonic();run=subprocess.run(argv,capture_output=True,timeout=40)
 (root/(label+'.stdout.bin')).write_bytes(run.stdout);(root/(label+'.stderr.bin')).write_bytes(run.stderr)
 rec={'label':label,'argv':argv,'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':pin(run.stdout),'stderr':pin(run.stderr)};commands.append(rec);write(root/(label+'.receipt.json'),rec)
 return run
project=root/'project';assert command('project-init',['project','init',project]).returncode==0
source=root/'selected-linear.txt';source.write_bytes((fixture/'linear.txt').read_bytes())
imported=command('source-import',['source','import',project,source]);assert imported.returncode==0
result=json.loads(imported.stdout);selected=actual_source(project,result['import_id'],{'kind':'text','ordinal':0})
write(root/'actual-source.json',selected)
assert selected['units'][0]['text'].encode()==source.read_bytes()
case=root/'case';case.mkdir();gold=(fixture/'gold-linear.json').read_bytes();(case/'gold.json').write_bytes(gold)
write(case/'process-review.json',{'schema_version':1,'purpose':'process_source_review','project_id':selected['binding']['project_id'],'import_id':selected['binding']['import_id'],'selection':[{'kind':'text','ordinal':0}],'gold_file':'gold.json','gold_sha256':hashlib.sha256(gold).hexdigest()})
profile=root/'profile.json';profile.write_bytes((fixture/'profile-obsidian_1_6_7_flowchart.json').read_bytes())
review=root/'process-review-output';vault=root/'new-flow-Vault'
r=command('process-review-red',['knowledge','process-review',project,case,review])
f=command('flow-red',['knowledge','flow',project,case,review,profile,vault])
assert r.returncode==2 and f.returncode==2
assert not review.exists() and not vault.exists()
assert b'process-review' in r.stderr and b'flow' in f.stderr
write(root/'result.json',{'status':'red_new_commands_missing','commands':commands,'review_output_exists':review.exists(),'vault_exists':vault.exists(),'scope':'Real project + ordinary text import + actual SourceSession-compatible SQL/resource readback; old CLI rejects both new verbs before filesystem reads. No fake passed process IR was manufactured.','source_bytes_match_selected_request_unit':True})
Path('/tmp/noetome-process-flow-red-root.txt').write_text(str(root))
print(json.dumps({'root':str(root),'process_review_exit':r.returncode,'process_review_stderr':r.stderr.decode(),'flow_exit':f.returncode,'flow_stderr':f.stderr.decode(),'outputs_absent':True},ensure_ascii=False,indent=2),flush=True)
