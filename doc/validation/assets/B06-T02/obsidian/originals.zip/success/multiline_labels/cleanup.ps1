$ErrorActionPreference='Stop'
    $profilePath='D:\Noetome\target\compiler-temp\b06-product-obsidian-20261105-f\multiline_labels\profile'
    $receiptPid=67328
    $receiptPort=55107
    $candidates=@(Get-CimInstance Win32_Process -Filter "Name='Obsidian.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($profilePath) })
    $owned=@()
    foreach($candidate in $candidates) {
      if ($receiptPid -eq 0 -or $candidate.ProcessId -eq $receiptPid) {
        $owned += $candidate.ProcessId
        taskkill.exe /PID $candidate.ProcessId /T /F | Out-Null
      }
    }
    Start-Sleep -Milliseconds 300
    $remaining=@(Get-CimInstance Win32_Process -Filter "Name='Obsidian.exe'" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($profilePath) })
    $pidState=if($receiptPid -ne 0){Get-Process -Id $receiptPid -ErrorAction SilentlyContinue}else{$null}
    $listener=if($receiptPort -ne 0){Get-NetTCPConnection -LocalPort $receiptPort -State Listen -ErrorAction SilentlyContinue}else{$null}
    @{ownedPid=$receiptPid;ownedPort=$receiptPort;ownedPidAbsent=($null -eq $pidState);ownedListenerAbsent=($null -eq $listener);profileProcessCount=$remaining.Count;emergencyTerminated=$owned;checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
    