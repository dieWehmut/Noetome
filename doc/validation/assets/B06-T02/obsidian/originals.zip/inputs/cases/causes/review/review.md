# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "eeda5a6d-c2fa-40a0-a36c-a062e179cd58",
  "binding": {
    "project_id": "09d353c3-631f-44e7-ba00-096d6eba3fed",
    "import_id": "8f343e70-2198-4aba-9b9e-ff611520875c",
    "source_id": "efb69757-1532-4d8c-b574-016e6c8b8603",
    "version_id": "6f658f09-9268-4eb9-aadf-c1f30b09d816",
    "content_sha256": "f6d0f41c4585e4e44e20c6743783b014d86fe0c38408e2fbf5e69646728dde8f",
    "normalized_sha256": "f6d0f41c4585e4e44e20c6743783b014d86fe0c38408e2fbf5e69646728dde8f",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "演示指示器触发规则",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "施加演示触发信号",
        "description": "把触发信号设为有效状态",
        "criterion": null,
        "inputs": [
          "演示触发命令"
        ],
        "outputs": [
          "有效触发信号"
        ],
        "conditions": [
          "演示模式开启"
        ],
        "exceptions": [
          "电源断开时不施加信号"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "指示器亮起",
        "description": "表示演示规则规定的亮灯响应",
        "criterion": null,
        "inputs": [
          "有效触发信号"
        ],
        "outputs": [
          "亮灯响应"
        ],
        "conditions": [
          "演示指示器可用"
        ],
        "exceptions": [
          "指示器断开时无响应"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "登记观察结果",
        "description": "登记实际观察到的指示器状态",
        "criterion": null,
        "inputs": [
          "观察到的指示器状态"
        ],
        "outputs": [
          "观察记录"
        ],
        "conditions": [
          "观察已完成"
        ],
        "exceptions": [
          "无法观察时登记待复核"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "causes",
        "branch_outcome": null,
        "conditions": [
          "演示电路完整"
        ],
        "exceptions": [
          "指示器断开时该作用不成立"
        ]
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "亮灯状态已观察"
        ],
        "exceptions": [
          "观察中断时暂停登记"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 147,
        "quote": "过程：\"演示指示器触发规则\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 850,
        "end_byte": 963,
        "quote": "关系 r1：s1 导致 s2。条件：[\"演示电路完整\"]。例外：[\"指示器断开时该作用不成立\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 964,
        "end_byte": 1080,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"亮灯状态已观察\"]。例外：[\"观察中断时暂停登记\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 148,
        "end_byte": 384,
        "quote": "步骤 s1：\"施加演示触发信号\"。说明：\"把触发信号设为有效状态\"。输入：[\"演示触发命令\"]。输出：[\"有效触发信号\"]。条件：[\"演示模式开启\"]。例外：[\"电源断开时不施加信号\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 385,
        "end_byte": 612,
        "quote": "步骤 s2：\"指示器亮起\"。说明：\"表示演示规则规定的亮灯响应\"。输入：[\"有效触发信号\"]。输出：[\"亮灯响应\"]。条件：[\"演示指示器可用\"]。例外：[\"指示器断开时无响应\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 613,
        "end_byte": 849,
        "quote": "步骤 s3：\"登记观察结果\"。说明：\"登记实际观察到的指示器状态\"。输入：[\"观察到的指示器状态\"]。输出：[\"观察记录\"]。条件：[\"观察已完成\"]。例外：[\"无法观察时登记待复核\"]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 1,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 1,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 1,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 1,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
  "ir_fingerprint": {
    "sha256": "839adb7cbba88a078afdc5bc78c35d2a78b73a1fc7df7e877bc80e8330284504",
    "byte_length": 7196
  },
  "inputs": {
    ".case.json": {
      "sha256": "919f637c987c7888c48dee12c1c3ea71cb8debba52cd31de47b9ecf12ccbeeaf",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
      "byte_length": 3978
    },
    ".source.json": {
      "sha256": "8fc4cde8fc9859b21c4a985c9067553176d94968b9b501b22528ad2f1240abf6",
      "byte_length": 2028
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "919f637c987c7888c48dee12c1c3ea71cb8debba52cd31de47b9ecf12ccbeeaf",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
      "byte_length": 3978
    },
    ".owner.json": {
      "sha256": "6f9b3a56cc57964c24bf78c7a728dd5569406d94c33a8c8d532c75c5e0403334",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "8fc4cde8fc9859b21c4a985c9067553176d94968b9b501b22528ad2f1240abf6",
      "byte_length": 2028
    },
    "process-ir.json": {
      "sha256": "839adb7cbba88a078afdc5bc78c35d2a78b73a1fc7df7e877bc80e8330284504",
      "byte_length": 7196
    }
  }
}
```
