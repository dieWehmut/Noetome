# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "34e211c6-fbb3-42b0-92b7-cb9e2be15e1b",
  "binding": {
    "project_id": "09d353c3-631f-44e7-ba00-096d6eba3fed",
    "import_id": "8f343e70-2198-4aba-9b9e-ff611520875c",
    "source_id": "efb69757-1532-4d8c-b574-016e6c8b8603",
    "version_id": "6f658f09-9268-4eb9-aadf-c1f30b09d816",
    "content_sha256": "f6d0f41c4585e4e44e20c6743783b014d86fe0c38408e2fbf5e69646728dde8f",
    "normalized_sha256": "f6d0f41c4585e4e44e20c6743783b014d86fe0c38408e2fbf5e69646728dde8f",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "issues": [],
  "process_document": {
    "process": {
      "title": "演示指示器触发规则",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "施加演示触发信号",
        "description": "把触发信号设为有效状态",
        "criterion": null,
        "inputs": [
          "演示触发命令"
        ],
        "outputs": [
          "有效触发信号"
        ],
        "conditions": [
          "演示模式开启"
        ],
        "exceptions": [
          "电源断开时不施加信号"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "指示器亮起",
        "description": "表示演示规则规定的亮灯响应",
        "criterion": null,
        "inputs": [
          "有效触发信号"
        ],
        "outputs": [
          "亮灯响应"
        ],
        "conditions": [
          "演示指示器可用"
        ],
        "exceptions": [
          "指示器断开时无响应"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "登记观察结果",
        "description": "登记实际观察到的指示器状态",
        "criterion": null,
        "inputs": [
          "观察到的指示器状态"
        ],
        "outputs": [
          "观察记录"
        ],
        "conditions": [
          "观察已完成"
        ],
        "exceptions": [
          "无法观察时登记待复核"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "causes",
        "branch_outcome": null,
        "conditions": [
          "演示电路完整"
        ],
        "exceptions": [
          "指示器断开时该作用不成立"
        ]
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "亮灯状态已观察"
        ],
        "exceptions": [
          "观察中断时暂停登记"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 147,
        "quote": "过程：\"演示指示器触发规则\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 850,
        "end_byte": 963,
        "quote": "关系 r1：s1 导致 s2。条件：[\"演示电路完整\"]。例外：[\"指示器断开时该作用不成立\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 964,
        "end_byte": 1080,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"亮灯状态已观察\"]。例外：[\"观察中断时暂停登记\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 148,
        "end_byte": 384,
        "quote": "步骤 s1：\"施加演示触发信号\"。说明：\"把触发信号设为有效状态\"。输入：[\"演示触发命令\"]。输出：[\"有效触发信号\"]。条件：[\"演示模式开启\"]。例外：[\"电源断开时不施加信号\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 385,
        "end_byte": 612,
        "quote": "步骤 s2：\"指示器亮起\"。说明：\"表示演示规则规定的亮灯响应\"。输入：[\"有效触发信号\"]。输出：[\"亮灯响应\"]。条件：[\"演示指示器可用\"]。例外：[\"指示器断开时无响应\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 613,
        "end_byte": 849,
        "quote": "步骤 s3：\"登记观察结果\"。说明：\"登记实际观察到的指示器状态\"。输入：[\"观察到的指示器状态\"]。输出：[\"观察记录\"]。条件：[\"观察已完成\"]。例外：[\"无法观察时登记待复核\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": "flowchart",
  "decision": {
    "rule_id": "verified_directed_acyclic_flow_v1",
    "reason": "来源明确给出完整有向无环关系，且所选目标的当前图形及标签配置已有实测依据。",
    "fallback_reasons": []
  },
  "review_ir_fingerprint": {
    "sha256": "839adb7cbba88a078afdc5bc78c35d2a78b73a1fc7df7e877bc80e8330284504",
    "byte_length": 7196
  },
  "plan_fingerprint": {
    "sha256": "95e975518cd1cd8406dca0cd0001367d22150a903d9c14c48f3fefbd387c5f55",
    "byte_length": 13476
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 1,
    "content_mappings": 13,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "flow_edges": 2,
    "flow_nodes": 3,
    "inhibits_relations": 0,
    "links": 7,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "rendered_notes": 2,
    "sequence_relations": 1,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "919f637c987c7888c48dee12c1c3ea71cb8debba52cd31de47b9ecf12ccbeeaf",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
      "byte_length": 3978
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "919f637c987c7888c48dee12c1c3ea71cb8debba52cd31de47b9ecf12ccbeeaf",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
      "byte_length": 3978
    },
    ".review-.owner.json": {
      "sha256": "6f9b3a56cc57964c24bf78c7a728dd5569406d94c33a8c8d532c75c5e0403334",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "8fc4cde8fc9859b21c4a985c9067553176d94968b9b501b22528ad2f1240abf6",
      "byte_length": 2028
    },
    ".review-process-ir.json": {
      "sha256": "839adb7cbba88a078afdc5bc78c35d2a78b73a1fc7df7e877bc80e8330284504",
      "byte_length": 7196
    },
    ".review-review.json": {
      "sha256": "b9111a72c064c1bc7e4a776b01471c59d2dc177c8d6e9f704e4f7b26298dafab",
      "byte_length": 7774
    },
    ".review-review.md": {
      "sha256": "4993cc4825bba242096257e83ac72343c86f59ac2ec60ef627a4f275759cf1a5",
      "byte_length": 7957
    },
    ".source.json": {
      "sha256": "8fc4cde8fc9859b21c4a985c9067553176d94968b9b501b22528ad2f1240abf6",
      "byte_length": 2028
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "9ce9f6d51098b41fcbb3aac140ff7e74b8619f0772bf2a13e9f6480c47d7f53f",
      "byte_length": 807,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 83
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 97,
          "end_byte": 358
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n0",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 388,
          "end_byte": 420
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n1",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 421,
          "end_byte": 444
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n2",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 445,
          "end_byte": 471
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_edge",
          "item_id": "e0",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 472,
          "end_byte": 493
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_edge",
          "item_id": "e1",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 494,
          "end_byte": 515
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 521,
          "end_byte": 575
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 576,
          "end_byte": 621
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 622,
          "end_byte": 667
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s3",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 668,
          "end_byte": 713
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 714,
          "end_byte": 759
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r2",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 760,
          "end_byte": 805
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "6949511865e29f66340b02f9e0c48a74820f87b9ee80112c315e4fa13cd02448",
      "byte_length": 1624,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 181
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 209,
          "end_byte": 490
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 518,
          "end_byte": 790
        },
        {
          "section_id": "step_s3",
          "block_id": "s3",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 818,
          "end_byte": 1099
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 1127,
          "end_byte": 1331
        },
        {
          "section_id": "relation_r2",
          "block_id": "r2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r2",
            "s2",
            "s3"
          ],
          "start_byte": 1359,
          "end_byte": 1551
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 1574,
          "end_byte": 1622
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "919f637c987c7888c48dee12c1c3ea71cb8debba52cd31de47b9ecf12ccbeeaf",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
      "byte_length": 3978
    },
    ".owner.json": {
      "sha256": "73aabb7714475be63015966e1c4388dd5afbf99ab72dd4d3c60f1ffcb099520c",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "919f637c987c7888c48dee12c1c3ea71cb8debba52cd31de47b9ecf12ccbeeaf",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "081ca1637cc0b58deed117392bfc51c96154c5d225609be6b145a18a5f41fe1d",
      "byte_length": 3978
    },
    ".review-.owner.json": {
      "sha256": "6f9b3a56cc57964c24bf78c7a728dd5569406d94c33a8c8d532c75c5e0403334",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "8fc4cde8fc9859b21c4a985c9067553176d94968b9b501b22528ad2f1240abf6",
      "byte_length": 2028
    },
    ".review-process-ir.json": {
      "sha256": "839adb7cbba88a078afdc5bc78c35d2a78b73a1fc7df7e877bc80e8330284504",
      "byte_length": 7196
    },
    ".review-review.json": {
      "sha256": "b9111a72c064c1bc7e4a776b01471c59d2dc177c8d6e9f704e4f7b26298dafab",
      "byte_length": 7774
    },
    ".review-review.md": {
      "sha256": "4993cc4825bba242096257e83ac72343c86f59ac2ec60ef627a4f275759cf1a5",
      "byte_length": 7957
    },
    ".source.json": {
      "sha256": "8fc4cde8fc9859b21c4a985c9067553176d94968b9b501b22528ad2f1240abf6",
      "byte_length": 2028
    },
    "plan.json": {
      "sha256": "95e975518cd1cd8406dca0cd0001367d22150a903d9c14c48f3fefbd387c5f55",
      "byte_length": 13476
    },
    "流程总览.md": {
      "sha256": "9ce9f6d51098b41fcbb3aac140ff7e74b8619f0772bf2a13e9f6480c47d7f53f",
      "byte_length": 807
    },
    "过程明细.md": {
      "sha256": "6949511865e29f66340b02f9e0c48a74820f87b9ee80112c315e4fa13cd02448",
      "byte_length": 1624
    }
  }
}
```
