# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "c50090a3-96be-4173-a86b-4a34ba838464",
  "project_id": "7f4ab0d3-d721-4ba8-a7cb-3b5520cb50e0",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "5b40746cd357eb28ac274b4a36646d1557347cad07a28e0cfe8020a90b072b84",
    "byte_length": 37417
  },
  "plan_fingerprint": {
    "sha256": "5ccfa94c246429bfeff4dce860635f134d9991b91c00f50509a4d8a5cc3bd897",
    "byte_length": 16487
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "5b40746cd357eb28ac274b4a36646d1557347cad07a28e0cfe8020a90b072b84",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "549edd9795efb0bb3213433fe37421a3226b90592b9fc61d273d15569af80ad3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ea5b99e91d181b23d0b7606a5c7eb289f041bf176fb4999a299c145e5d39de4a",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "226b2bea6ebf0fd9d076fa60325eaa760121d641fcdee794001bf2b518b03925",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ab402d5bf494521b60eeffb828ac6f6fb826351ef311da94a9fa962155114f4c",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "8cf2b0755541f9ddccad91e9dbb3dbb49abb7ad962a182f02ac05cea9ccc5e06",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "3ee6240d621b1ddbe4f2341030963a6d909331ca70f132307c5cd4c9a3896eed",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "d9c0e99488a5d62a4aee3886d4679d8fc75df9fe7d5ef2933c0203068bd53c91",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "41b37ab7ee63eef55bb4dacb7a41ac557c7de740a27c59f9c16b0fd0ddf79175",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9fbd9e058890bead87f7f842881d8abe604b67928298baa54e5adf328ae1322c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "92bbf0dbd20dcd534f22517835b2fde6df818313b31af758bd33a12a0f5bc52f",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "792338fbeef3a083da5fcd35dfe0a18f12ac250e073218b7813418f0809540ef",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b725a9941145c7a78daf559547a036efbd696a1df468b9c042c291b13f35060a",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8004ffe3c54a7180b4545bbb78b87f16bcc1e0f00a90405bac97403d4d703438",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "d507440f83663b63849c8c84e6f9f71c515c7e257db9f6a23bfd5159dd921a5e",
      "byte_length": 4328
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0bf6df375c76f25864b0b98c6c7016eec9c3947afa0e789a7233dc6055208a30",
            "occ-621a1c4c23c7057fe0f5e574be01b13ffcc79aaec12acefe2e2aa43e71c4ccb1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0bf6df375c76f25864b0b98c6c7016eec9c3947afa0e789a7233dc6055208a30"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-0bf6df375c76f25864b0b98c6c7016eec9c3947afa0e789a7233dc6055208a30"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 262
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-621a1c4c23c7057fe0f5e574be01b13ffcc79aaec12acefe2e2aa43e71c4ccb1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 267,
          "end_byte": 275
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-621a1c4c23c7057fe0f5e574be01b13ffcc79aaec12acefe2e2aa43e71c4ccb1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 353,
          "end_byte": 499
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 276,
          "end_byte": 350
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-0bf6df375c76f25864b0b98c6c7016eec9c3947afa0e789a7233dc6055208a30"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 207
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-621a1c4c23c7057fe0f5e574be01b13ffcc79aaec12acefe2e2aa43e71c4ccb1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "5b40746cd357eb28ac274b4a36646d1557347cad07a28e0cfe8020a90b072b84",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "549edd9795efb0bb3213433fe37421a3226b90592b9fc61d273d15569af80ad3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ea5b99e91d181b23d0b7606a5c7eb289f041bf176fb4999a299c145e5d39de4a",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "226b2bea6ebf0fd9d076fa60325eaa760121d641fcdee794001bf2b518b03925",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ab402d5bf494521b60eeffb828ac6f6fb826351ef311da94a9fa962155114f4c",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "8cf2b0755541f9ddccad91e9dbb3dbb49abb7ad962a182f02ac05cea9ccc5e06",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "3ee6240d621b1ddbe4f2341030963a6d909331ca70f132307c5cd4c9a3896eed",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "d9c0e99488a5d62a4aee3886d4679d8fc75df9fe7d5ef2933c0203068bd53c91",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "41b37ab7ee63eef55bb4dacb7a41ac557c7de740a27c59f9c16b0fd0ddf79175",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9fbd9e058890bead87f7f842881d8abe604b67928298baa54e5adf328ae1322c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "92bbf0dbd20dcd534f22517835b2fde6df818313b31af758bd33a12a0f5bc52f",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "792338fbeef3a083da5fcd35dfe0a18f12ac250e073218b7813418f0809540ef",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b725a9941145c7a78daf559547a036efbd696a1df468b9c042c291b13f35060a",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8004ffe3c54a7180b4545bbb78b87f16bcc1e0f00a90405bac97403d4d703438",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "b31d1d320094774621b43d9bf8748a33eab8c0aef9cb9330b0875477793c0ee6",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "d507440f83663b63849c8c84e6f9f71c515c7e257db9f6a23bfd5159dd921a5e",
      "byte_length": 4328
    },
    "plan.json": {
      "sha256": "5ccfa94c246429bfeff4dce860635f134d9991b91c00f50509a4d8a5cc3bd897",
      "byte_length": 16487
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503
    }
  }
}
```
