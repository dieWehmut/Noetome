# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "9d6a439a-c3e3-4ef5-af11-9ac402680fb4",
  "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "ed9bbed587e1b10ecb92495e8d69608d7e0dde20f356b9a455a0eb1130a24e49",
    "byte_length": 41246
  },
  "plan_fingerprint": {
    "sha256": "4fcfff7264e2276898352459ed10af047a81b11fa9139d63eb7f423eca9d00ef",
    "byte_length": 14692
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "ed9bbed587e1b10ecb92495e8d69608d7e0dde20f356b9a455a0eb1130a24e49",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "5777015c1bb3ac0d112fa48b43afacfd236894abcd18b09d7860b5a579f2e43d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "0b662ffbefca8f74bb0b0c92b2b94c663295034eae60c250f4de5ef59ace12d0",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "22638ea1424ef52293a418c1e98280c6ee2f8d51a57259631caf2dedaa645581",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "397164bc304db845614c8f15204a1232b8db07eeaeb54de38c770672a2cd7105",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "5e060d16e52a1239c2f0d580c6d4fa05ae64627043170e5d2374ba1bdc278449",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "24b38be2ee2ae29fce2289878b50f8b376e0e22054914520045f3528713f1b96",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "54c4410d55efb54ad4eb4d95bd689f3ad8200eb4ebcae02ea7beb3faf2128f2d",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "be4f27b808ab1348a9b81d9975f954f926cde7491335614d100350b89d797086",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "85e3a4b3514b88a843d28b196be75832d35fbc77f2c393cbc9851576414a90b5",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b2b3c3337a878b02680e1b513147be30b1355c96d277dc72d8fab3052dbbe867",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "09ead42a72648a6595e99d7fc4a552dc31ca7afb016dfdf7435e681dbb3de5c5",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "5e323a817a9b51158ca39880e2073f3843fe087e19109333ea24b0f74ccea655",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "b4588f6c4e052dedfa841726ad79213f3f2f9325b8ce0191ea1528be372a0154",
      "byte_length": 17255
    },
    ".selection-original.json": {
      "sha256": "484fbde7cba07ddc8462559d61f215e5e3113ad855bfa2e89b99ca66b72606ee",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-e56c03320c81f3d50cefd7afae062608ff3e4275b9173d41dc66419dcde545c2"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 33,
          "end_byte": 197
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-e5d78c56ba7cbd985eb1ebbbc4fbbc106e9f79cb76c716c6c9851ebabe921e3f"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 273,
          "end_byte": 437
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000001",
          "target_path": "对象-61000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 198,
          "end_byte": 271
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000003",
          "target_path": "对象-61000000-0000-4000-8000-000000000003.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 438,
          "end_byte": 511
        }
      ]
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000001.md",
      "note_id": "object-61000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-e56c03320c81f3d50cefd7afae062608ff3e4275b9173d41dc66419dcde545c2"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 27,
          "end_byte": 320
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000003.md",
      "note_id": "object-61000000-0000-4000-8000-000000000003",
      "plan_revision": 1,
      "content_sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-e5d78c56ba7cbd985eb1ebbbc4fbbc106e9f79cb76c716c6c9851ebabe921e3f"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 29,
          "end_byte": 322
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "ed9bbed587e1b10ecb92495e8d69608d7e0dde20f356b9a455a0eb1130a24e49",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "5777015c1bb3ac0d112fa48b43afacfd236894abcd18b09d7860b5a579f2e43d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "0b662ffbefca8f74bb0b0c92b2b94c663295034eae60c250f4de5ef59ace12d0",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "22638ea1424ef52293a418c1e98280c6ee2f8d51a57259631caf2dedaa645581",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "397164bc304db845614c8f15204a1232b8db07eeaeb54de38c770672a2cd7105",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "5e060d16e52a1239c2f0d580c6d4fa05ae64627043170e5d2374ba1bdc278449",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "24b38be2ee2ae29fce2289878b50f8b376e0e22054914520045f3528713f1b96",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "54c4410d55efb54ad4eb4d95bd689f3ad8200eb4ebcae02ea7beb3faf2128f2d",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "be4f27b808ab1348a9b81d9975f954f926cde7491335614d100350b89d797086",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "85e3a4b3514b88a843d28b196be75832d35fbc77f2c393cbc9851576414a90b5",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b2b3c3337a878b02680e1b513147be30b1355c96d277dc72d8fab3052dbbe867",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "09ead42a72648a6595e99d7fc4a552dc31ca7afb016dfdf7435e681dbb3de5c5",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "5e323a817a9b51158ca39880e2073f3843fe087e19109333ea24b0f74ccea655",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "b4588f6c4e052dedfa841726ad79213f3f2f9325b8ce0191ea1528be372a0154",
      "byte_length": 17255
    },
    ".owner.json": {
      "sha256": "f879d25005bd0d151a64209d5d23482ac73654a0480b2e7f9306e762b48a0cf6",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "484fbde7cba07ddc8462559d61f215e5e3113ad855bfa2e89b99ca66b72606ee",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "4fcfff7264e2276898352459ed10af047a81b11fa9139d63eb7f423eca9d00ef",
      "byte_length": 14692
    },
    "对象-61000000-0000-4000-8000-000000000001.md": {
      "sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322
    },
    "对象-61000000-0000-4000-8000-000000000003.md": {
      "sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324
    },
    "知识比较.md": {
      "sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513
    }
  }
}
```
