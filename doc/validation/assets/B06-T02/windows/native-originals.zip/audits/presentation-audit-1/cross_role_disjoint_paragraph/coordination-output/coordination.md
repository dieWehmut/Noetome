# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "983d67da-84ff-446e-9e56-4dbe39a22373",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "61000000-0000-4000-8000-000000000001",
      "display_name": "速度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000002",
      "display_name": "密度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000003",
      "display_name": "样例 B"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
        "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
        "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
        "version_id": "181ef724-17ad-4933-ba20-f35386bffb05",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-density"
            ],
            "decision": {
              "atom_ids": [
                "a-density"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
              "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
              "version_id": "181ef724-17ad-4933-ba20-f35386bffb05"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
              "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
              "version_id": "181ef724-17ad-4933-ba20-f35386bffb05"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "速度",
              "密度"
            ],
            "compound": "速度 密度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "密度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "kg/m³",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "kg/m³",
          "actual": {
            "measurement": "kg/m³",
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg/m³"
          },
          "actual": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "397164bc304db845614c8f15204a1232b8db07eeaeb54de38c770672a2cd7105",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
          "byte_length": 143
        },
        "gold-original.json": {
          "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "5e060d16e52a1239c2f0d580c6d4fa05ae64627043170e5d2374ba1bdc278449",
          "byte_length": 12391
        },
        "review-original.json": {
          "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
          "byte_length": 508
        },
        "source-snapshot.json": {
          "sha256": "24b38be2ee2ae29fce2289878b50f8b376e0e22054914520045f3528713f1b96",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "54c4410d55efb54ad4eb4d95bd689f3ad8200eb4ebcae02ea7beb3faf2128f2d",
          "byte_length": 16868
        },
        "verification.md": {
          "sha256": "be4f27b808ab1348a9b81d9975f954f926cde7491335614d100350b89d797086",
          "byte_length": 17302
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
        "import_id": "ffda6687-a041-4001-865d-c722741e2f09",
        "source_id": "132341ff-b4d1-4797-ad56-3d8899c45a7d",
        "version_id": "4dccf905-1399-4659-8001-e22d4df8a4d4",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "ffda6687-a041-4001-865d-c722741e2f09",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
              "source_id": "132341ff-b4d1-4797-ad56-3d8899c45a7d",
              "version_id": "4dccf905-1399-4659-8001-e22d4df8a4d4"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "ffda6687-a041-4001-865d-c722741e2f09",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
              "source_id": "132341ff-b4d1-4797-ad56-3d8899c45a7d",
              "version_id": "4dccf905-1399-4659-8001-e22d4df8a4d4"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "85e3a4b3514b88a843d28b196be75832d35fbc77f2c393cbc9851576414a90b5",
          "byte_length": 3047
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "b2b3c3337a878b02680e1b513147be30b1355c96d277dc72d8fab3052dbbe867",
          "byte_length": 12339
        },
        "review-original.json": {
          "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "09ead42a72648a6595e99d7fc4a552dc31ca7afb016dfdf7435e681dbb3de5c5",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "5e323a817a9b51158ca39880e2073f3843fe087e19109333ea24b0f74ccea655",
          "byte_length": 16821
        },
        "verification.md": {
          "sha256": "b4588f6c4e052dedfa841726ad79213f3f2f9325b8ce0191ea1528be372a0154",
          "byte_length": 17255
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2"
      },
      "occurrence_id": "occ-e56c03320c81f3d50cefd7afae062608ff3e4275b9173d41dc66419dcde545c2",
      "input_id": "a",
      "binding": {
        "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
        "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
        "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
        "version_id": "181ef724-17ad-4933-ba20-f35386bffb05",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "74fbf78b-a5cb-4ba7-851f-c02f942221d8",
          "ordinal": 0,
          "resource_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "密度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-density",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg/m³",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
          "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000002"
      ],
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value": "2",
      "unit_value": "kg/m³",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a"
      },
      "occurrence_id": "occ-e5d78c56ba7cbd985eb1ebbbc4fbbc106e9f79cb76c716c6c9851ebabe921e3f",
      "input_id": "b",
      "binding": {
        "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
        "import_id": "ffda6687-a041-4001-865d-c722741e2f09",
        "source_id": "132341ff-b4d1-4797-ad56-3d8899c45a7d",
        "version_id": "4dccf905-1399-4659-8001-e22d4df8a4d4",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "c604aad2-fb89-4fc9-bf18-16327f475f38",
          "ordinal": 0,
          "resource_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000003"
      ],
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "2",
      "unit": "kg/m³",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-e56c03320c81f3d50cefd7afae062608ff3e4275b9173d41dc66419dcde545c2"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-e5d78c56ba7cbd985eb1ebbbc4fbbc106e9f79cb76c716c6c9851ebabe921e3f"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-e56c03320c81f3d50cefd7afae062608ff3e4275b9173d41dc66419dcde545c2",
      "right_occurrence_id": "occ-e5d78c56ba7cbd985eb1ebbbc4fbbc106e9f79cb76c716c6c9851ebabe921e3f",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-e56c03320c81f3d50cefd7afae062608ff3e4275b9173d41dc66419dcde545c2",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-e5d78c56ba7cbd985eb1ebbbc4fbbc106e9f79cb76c716c6c9851ebabe921e3f",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "5777015c1bb3ac0d112fa48b43afacfd236894abcd18b09d7860b5a579f2e43d",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "ed9bbed587e1b10ecb92495e8d69608d7e0dde20f356b9a455a0eb1130a24e49",
      "byte_length": 41246
    },
    "coordination-original.json": {
      "sha256": "484fbde7cba07ddc8462559d61f215e5e3113ad855bfa2e89b99ca66b72606ee",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "397164bc304db845614c8f15204a1232b8db07eeaeb54de38c770672a2cd7105",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    "input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "5e060d16e52a1239c2f0d580c6d4fa05ae64627043170e5d2374ba1bdc278449",
      "byte_length": 12391
    },
    "input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    "input-a--source-snapshot.json": {
      "sha256": "24b38be2ee2ae29fce2289878b50f8b376e0e22054914520045f3528713f1b96",
      "byte_length": 1053
    },
    "input-a--verification.json": {
      "sha256": "54c4410d55efb54ad4eb4d95bd689f3ad8200eb4ebcae02ea7beb3faf2128f2d",
      "byte_length": 16868
    },
    "input-a--verification.md": {
      "sha256": "be4f27b808ab1348a9b81d9975f954f926cde7491335614d100350b89d797086",
      "byte_length": 17302
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "85e3a4b3514b88a843d28b196be75832d35fbc77f2c393cbc9851576414a90b5",
      "byte_length": 3047
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "b2b3c3337a878b02680e1b513147be30b1355c96d277dc72d8fab3052dbbe867",
      "byte_length": 12339
    },
    "input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "09ead42a72648a6595e99d7fc4a552dc31ca7afb016dfdf7435e681dbb3de5c5",
      "byte_length": 1053
    },
    "input-b--verification.json": {
      "sha256": "5e323a817a9b51158ca39880e2073f3843fe087e19109333ea24b0f74ccea655",
      "byte_length": 16821
    },
    "input-b--verification.md": {
      "sha256": "b4588f6c4e052dedfa841726ad79213f3f2f9325b8ce0191ea1528be372a0154",
      "byte_length": 17255
    }
  }
}
```
