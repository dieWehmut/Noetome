# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "e2759726-1ddc-40ef-8b43-8af269b07c86",
  "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "f0a2ea13bccd772d0fbf58bd3fd506bcada340b5ed06a963bd006eae698c6634",
    "byte_length": 61685
  },
  "plan_fingerprint": {
    "sha256": "90b02882d0eeccba69030eccd2a27e5e92763de8aced95b24542aa6d44ec8df4",
    "byte_length": 22658
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "f0a2ea13bccd772d0fbf58bd3fd506bcada340b5ed06a963bd006eae698c6634",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "9f85fe017d7ee70485cd19e70dc700fe5d63405e5762d785bc1922f28674dca4",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "659050d58128f763852c855710c49fe1520d9592471239ca74fb71fa0489fb09",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "a4afabae60a9c2447e777804ddfc76c86b843b3cd979c0b4c4db0a6ffb7888a2",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "3cf49fd284cdbcabcd6bfa4c4552b343352af861391a9639fb3ca6d85c8a25d6",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e28bff493626cf813a4fc2ba0200671ba864d60ea94901b59f004fea85ef8b17",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "46caefc0fa2ed91eec5fd3bc2f9e91f30d56e852219ed4277073176d423794c6",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "24cdd207a1031bf07cca7c5e6fe3d9f9823c667393d6f5b316d102e522331195",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "3c1804356770e3c493090f25ca6a43bf4ae865651fe3fe52d5b5a4fe36f5d01c",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "399b5c342eaad8bde4ef8ce8c95e4da1f55fee146a0d0589ac75fa2096f80582",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "7d07617bc75f716d963fd80e7bb9e816ee1c652068000c3c1331c12bf4f9bcaa",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0f578a54e6eecfcb68e524392a51f47ef91444d79bdaca8a10bb3896242dab61",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "66a82090ef1359f2927fd9a0ffddb2e978a7b1454798841575ad3e15476f9eac",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "c2383b9f283855ff86c4c5c5a7e6940d3da40be96758cff6d1209cdf1873647f",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "f47c1aec33ba78856a362168f0237127d701e680ba83e7bad297ac614ba660dc",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "fc271df68f8ee64aad17d4cc4d95026e558fcfeb981088aab4adb1883b7d672f",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "830440b0e5e10810ea58ff1b3e29c2d7e3af9e7f7acf3b3b5ed3d3cc67973a07",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "3fdfdd28df1bfc6503de5e789a41306d1c01084374ae3fee07cf5fb29003b594",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "2d352f64a2cbb3d78afdc4041f06821af27eaf413ddbd5797586d9d3d7c9b18f",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "9f2ed549089f91dccb5d901f4ee2b177cbd81cf368c2dca526be6d99d9eb88e7",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6fd68eef0ebc6f19c8112090ca224f58aa3561d36cb830b71660ce08b5e2dec3",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
            "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6",
            "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
            "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
            "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "f0a2ea13bccd772d0fbf58bd3fd506bcada340b5ed06a963bd006eae698c6634",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "9f85fe017d7ee70485cd19e70dc700fe5d63405e5762d785bc1922f28674dca4",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "659050d58128f763852c855710c49fe1520d9592471239ca74fb71fa0489fb09",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "a4afabae60a9c2447e777804ddfc76c86b843b3cd979c0b4c4db0a6ffb7888a2",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "3cf49fd284cdbcabcd6bfa4c4552b343352af861391a9639fb3ca6d85c8a25d6",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e28bff493626cf813a4fc2ba0200671ba864d60ea94901b59f004fea85ef8b17",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "46caefc0fa2ed91eec5fd3bc2f9e91f30d56e852219ed4277073176d423794c6",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "24cdd207a1031bf07cca7c5e6fe3d9f9823c667393d6f5b316d102e522331195",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "3c1804356770e3c493090f25ca6a43bf4ae865651fe3fe52d5b5a4fe36f5d01c",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "399b5c342eaad8bde4ef8ce8c95e4da1f55fee146a0d0589ac75fa2096f80582",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "7d07617bc75f716d963fd80e7bb9e816ee1c652068000c3c1331c12bf4f9bcaa",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0f578a54e6eecfcb68e524392a51f47ef91444d79bdaca8a10bb3896242dab61",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "66a82090ef1359f2927fd9a0ffddb2e978a7b1454798841575ad3e15476f9eac",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "c2383b9f283855ff86c4c5c5a7e6940d3da40be96758cff6d1209cdf1873647f",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "f47c1aec33ba78856a362168f0237127d701e680ba83e7bad297ac614ba660dc",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "fc271df68f8ee64aad17d4cc4d95026e558fcfeb981088aab4adb1883b7d672f",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "830440b0e5e10810ea58ff1b3e29c2d7e3af9e7f7acf3b3b5ed3d3cc67973a07",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "3fdfdd28df1bfc6503de5e789a41306d1c01084374ae3fee07cf5fb29003b594",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "2d352f64a2cbb3d78afdc4041f06821af27eaf413ddbd5797586d9d3d7c9b18f",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "31511672c30474b8de43b0d22e10ff8ef831998d42b08032665e3c3d87b57a1f",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "9f2ed549089f91dccb5d901f4ee2b177cbd81cf368c2dca526be6d99d9eb88e7",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "90b02882d0eeccba69030eccd2a27e5e92763de8aced95b24542aa6d44ec8df4",
      "byte_length": 22658
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "6fd68eef0ebc6f19c8112090ca224f58aa3561d36cb830b71660ce08b5e2dec3",
      "byte_length": 542
    }
  }
}
```
