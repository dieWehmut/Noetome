# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "2e0b3572-bc7b-4463-9403-5036b22ae1e4",
  "project_id": "76b690fb-5587-44f9-9399-08c3af678769",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "6f7e5143207d2af3ef30929340196085f14c9b6d9297bc6524c24d027c25b559",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c81fc3c6832d4423bce37fc61013ba73075401ecf313b0686bbdc5e75ecdfc20",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "935e163f90ed090fa6a83c4b4a12ea4f4e5592421deb22fd9b6f065ed093f993",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "6748ba241ccadfbe09de052dd0025dd775591c7a2f4734f33b8af65399e8b780",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "4189a69a5e8814eb995bb8754b4eeb46c16061f0d84d993ae976c8ace9b79e5a",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "6535d3db91877c95f252c7ee8d38d2fbeb1a329b971aa95604bee895c6216ae6",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "ce08f7fbe85dbfaf97c085e67a9766e85694becca913f87d730eb75789cf853a",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "0d33051377a6202ae84e4f93127dda4a82788a81a4d7f20a3083eca37dbd1648",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2d87a07d05e8e4d7e6cf6b2708927565086cc56e4c85c59777d392f957e2b733",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "f030ed607463e179c71bec9ef26fc2f0cd0aee71f44f3982d7cbc2884a5e1a32",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2d941a789e38d0b191410b61ea695f2b55339f2ab99d78ffe2c73159f93fc6c2",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "3ec5c6b9f298e9d695d118127fc10b9eec76dcce60604a6f8add0f16ecf3f682",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "cf2380259c10bc46a7faec9bce47f41388eef869cd57e3743ae6e41bf0739489",
      "byte_length": 14422
    },
    ".selection-original.json": {
      "sha256": "5ea00168f7a2beb808fae70d6d774248d37f9bea1fa6c3b4bdb2b363f9801400",
      "byte_length": 4326
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "6f7e5143207d2af3ef30929340196085f14c9b6d9297bc6524c24d027c25b559",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c81fc3c6832d4423bce37fc61013ba73075401ecf313b0686bbdc5e75ecdfc20",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "935e163f90ed090fa6a83c4b4a12ea4f4e5592421deb22fd9b6f065ed093f993",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "6748ba241ccadfbe09de052dd0025dd775591c7a2f4734f33b8af65399e8b780",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "4189a69a5e8814eb995bb8754b4eeb46c16061f0d84d993ae976c8ace9b79e5a",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "6535d3db91877c95f252c7ee8d38d2fbeb1a329b971aa95604bee895c6216ae6",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "ce08f7fbe85dbfaf97c085e67a9766e85694becca913f87d730eb75789cf853a",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "0d33051377a6202ae84e4f93127dda4a82788a81a4d7f20a3083eca37dbd1648",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2d87a07d05e8e4d7e6cf6b2708927565086cc56e4c85c59777d392f957e2b733",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "f030ed607463e179c71bec9ef26fc2f0cd0aee71f44f3982d7cbc2884a5e1a32",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2d941a789e38d0b191410b61ea695f2b55339f2ab99d78ffe2c73159f93fc6c2",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "3ec5c6b9f298e9d695d118127fc10b9eec76dcce60604a6f8add0f16ecf3f682",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "cf2380259c10bc46a7faec9bce47f41388eef869cd57e3743ae6e41bf0739489",
      "byte_length": 14422
    },
    ".owner.json": {
      "sha256": "835c672a5631acd981eefa0d2211fd7423c6d561dbd95205d7e0e8467627bf2f",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "5ea00168f7a2beb808fae70d6d774248d37f9bea1fa6c3b4bdb2b363f9801400",
      "byte_length": 4326
    }
  }
}
```
