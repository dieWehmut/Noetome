# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "552b19fa-92c5-455a-bae5-225c862d6d08",
  "project_id": "c9999c64-3d12-4dd2-a819-703227294fa6",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 2,
    "table_cells": 6,
    "missing_cells": 1,
    "rendered_notes": 3,
    "content_mappings": 12,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "8d45759ae9e704571382e7a1c1267e870bbac60971a1a384a0ecaad03c813240",
    "byte_length": 61731
  },
  "plan_fingerprint": {
    "sha256": "d8b84f4e9cd847061bc4ec116a57bae02314b36958cdb0ba8e42faf588932024",
    "byte_length": 24184
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "8d45759ae9e704571382e7a1c1267e870bbac60971a1a384a0ecaad03c813240",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "58270395f6fc4213066315800e96f63ad4fb7532031701473d7e8869cd9c032d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9123cbe6fb3510dd57fc714f9d63973ad02caf894fd41e487e90ce8758f1b37e",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "7dacec7cc63721c714363ab2f380d97d7eed5c7e97498b7aab67ffa7acf90ab9",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "54d19572e3ee0afcce9afc114fe4e6d5f7b85885b31de6fd610b6ef061be7647",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "1eebbe97e6f50789d117f5e6b3e79bd71f17aa9da58f5d4a3ba5d032fe41bbf4",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9225e51cb3c60f03945e7d70cd30b8dd82a789645fdc43dd17406ca4896a0269",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "9a45821c47103bc957dcf9e604c4845db47d0725e088e978e5fa4866e473e4b9",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "ff9a01731fb026b2e52d5d7aa60a3ada9cc3becb836af802fafa23dfea95824e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "db82f2500c23fc09e2bd62e753ecf6432aabc7c3bab7c18c5b64b6d42ee2e3d7",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "691b857125d045d0e4b73c8502c19dac7b0cc4f57d17541dac117d1d2a14c860",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "416e9c8b6cf8a679cce151a95247c2e395674a12dbee3293885df6ce6fb9cf06",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "9d5efd08c0ea1a25625eaf3c0029960debd684d641dc37e5b0807347db0c5d97",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "4a2171fb5ef09ef0494d8072683a08b26c9a4c41ecd0402e791688b2bc3a8592",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "2a2c2bea031ff8b798eea5eb998d5fd5fb74893c63a36a36a46fc1c76619132c",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "22ae8e90ddc6429e105e81bba61fe7ee68d7c39e26b71b0eb90a80a315488185",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "f7a49b393ec1e00edeb7e463b919144adabf6040fbecbcefecc348421f53af89",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "f7fc2e0b90a15514e358649208c79904164e03defa40626c232160757a598e43",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "c81750d059e1efd09de87ca9ecf3e2f1d58c61c4f117fd828ffa0fef217234e2",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "2b3160b491a225f07e730a28f709428f5e3735199cd33b9a3256482108efdcd3",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "b800e3978a2f80cf64bca290c7b4ad2f1b590c43c223f8ac769058def1e2e6b5",
      "byte_length": 727,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-70e7817e48ca9cf4fcea4195978ce8b5b01ea92cce7496a3cc65dc26055b5327",
            "occ-b1ad665306be573b7974922a6f1d4152440d74210bd1bb25cafd920a2d1600a3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2281b565f154ae0ddd5a5d5d88079ecb9e2ae50747b93aeb7e278476609b4e77"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 53,
          "end_byte": 59
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2281b565f154ae0ddd5a5d5d88079ecb9e2ae50747b93aeb7e278476609b4e77",
            "occ-b1ad665306be573b7974922a6f1d4152440d74210bd1bb25cafd920a2d1600a3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 84,
          "end_byte": 92
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-b1ad665306be573b7974922a6f1d4152440d74210bd1bb25cafd920a2d1600a3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 170,
          "end_byte": 316
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-2281b565f154ae0ddd5a5d5d88079ecb9e2ae50747b93aeb7e278476609b4e77"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 319,
          "end_byte": 462
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-70e7817e48ca9cf4fcea4195978ce8b5b01ea92cce7496a3cc65dc26055b5327"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 467,
          "end_byte": 475
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-70e7817e48ca9cf4fcea4195978ce8b5b01ea92cce7496a3cc65dc26055b5327"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 553,
          "end_byte": 699
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "missing",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 702,
          "end_byte": 723
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 93,
          "end_byte": 167
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 476,
          "end_byte": 550
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-2281b565f154ae0ddd5a5d5d88079ecb9e2ae50747b93aeb7e278476609b4e77"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-b1ad665306be573b7974922a6f1d4152440d74210bd1bb25cafd920a2d1600a3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-70e7817e48ca9cf4fcea4195978ce8b5b01ea92cce7496a3cc65dc26055b5327"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "8d45759ae9e704571382e7a1c1267e870bbac60971a1a384a0ecaad03c813240",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "58270395f6fc4213066315800e96f63ad4fb7532031701473d7e8869cd9c032d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9123cbe6fb3510dd57fc714f9d63973ad02caf894fd41e487e90ce8758f1b37e",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "7dacec7cc63721c714363ab2f380d97d7eed5c7e97498b7aab67ffa7acf90ab9",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "54d19572e3ee0afcce9afc114fe4e6d5f7b85885b31de6fd610b6ef061be7647",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "1eebbe97e6f50789d117f5e6b3e79bd71f17aa9da58f5d4a3ba5d032fe41bbf4",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9225e51cb3c60f03945e7d70cd30b8dd82a789645fdc43dd17406ca4896a0269",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "9a45821c47103bc957dcf9e604c4845db47d0725e088e978e5fa4866e473e4b9",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "ff9a01731fb026b2e52d5d7aa60a3ada9cc3becb836af802fafa23dfea95824e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "db82f2500c23fc09e2bd62e753ecf6432aabc7c3bab7c18c5b64b6d42ee2e3d7",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "691b857125d045d0e4b73c8502c19dac7b0cc4f57d17541dac117d1d2a14c860",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "416e9c8b6cf8a679cce151a95247c2e395674a12dbee3293885df6ce6fb9cf06",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "9d5efd08c0ea1a25625eaf3c0029960debd684d641dc37e5b0807347db0c5d97",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "4a2171fb5ef09ef0494d8072683a08b26c9a4c41ecd0402e791688b2bc3a8592",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "2a2c2bea031ff8b798eea5eb998d5fd5fb74893c63a36a36a46fc1c76619132c",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "22ae8e90ddc6429e105e81bba61fe7ee68d7c39e26b71b0eb90a80a315488185",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "f7a49b393ec1e00edeb7e463b919144adabf6040fbecbcefecc348421f53af89",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "f7fc2e0b90a15514e358649208c79904164e03defa40626c232160757a598e43",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "c81750d059e1efd09de87ca9ecf3e2f1d58c61c4f117fd828ffa0fef217234e2",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "81bf26733769a43a01cb12f7e271fcf9b932180ca9a065d383ff8351e8369722",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "2b3160b491a225f07e730a28f709428f5e3735199cd33b9a3256482108efdcd3",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "d8b84f4e9cd847061bc4ec116a57bae02314b36958cdb0ba8e42faf588932024",
      "byte_length": 24184
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "b800e3978a2f80cf64bca290c7b4ad2f1b590c43c223f8ac769058def1e2e6b5",
      "byte_length": 727
    }
  }
}
```
