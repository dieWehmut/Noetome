# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "1d221569-edca-4998-a279-84b57fef3a3e",
  "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000007"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "24e268de22edf33880f67437fa526b57f0b58a2cc7ff57eb0a11a183a2804410",
    "byte_length": 41454
  },
  "plan_fingerprint": {
    "sha256": "3e734ca612f5c4c5bc16c8a3cb1fb8030e2958b107c618555d37f57c3b3cdb03",
    "byte_length": 17326
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "24e268de22edf33880f67437fa526b57f0b58a2cc7ff57eb0a11a183a2804410",
      "byte_length": 41454
    },
    ".coordination-owner.json": {
      "sha256": "037b33cffa8b40e06efdbc834bac38a746d42b7f1c173865f461d84673c004aa",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "5d743c4ff9a14d17b65976fabad54108b67d1bcc168865c5da97dd4b45f0fb05",
      "byte_length": 44925
    },
    ".coordination-report.md": {
      "sha256": "80d4c5fa325c37ebf37fcb47283a78fd2385c2aff1331de30572e4bf5c89930b",
      "byte_length": 45400
    },
    ".identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "fddb20df3bd5b519beee1810fcdc64640de93a8cb65fe8bb775e775c6329ff70",
      "byte_length": 3077
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "952908a34b65c48b517a32ceeb7f6fc548a7d05648ada6dafa8869393d1b08c3",
      "byte_length": 12416
    },
    ".input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    ".input-a--source-snapshot.json": {
      "sha256": "35cd22fa0c897fe88f2bc68c853472b25d3c9c1c2d28b4984508d89bc615be64",
      "byte_length": 1067
    },
    ".input-a--verification.json": {
      "sha256": "b48771989ecda555c2a1dda77bb4e7fb1f136b679f64ba4beeaa7d015d22f0a5",
      "byte_length": 16897
    },
    ".input-a--verification.md": {
      "sha256": "923b45714e83e874093cdfcac00bc6a465ad85b8f7f2698b725dd1bbe4b969bc",
      "byte_length": 17331
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "0c29b8bc28318e93ae4650ac33ca627104bf72e8692272eff204afcc0cc383c7",
      "byte_length": 3086
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6196114781a75151c2e75a86a2fb81059ca77599f51645c6672f513d2671943a",
      "byte_length": 12452
    },
    ".input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    ".input-b--source-snapshot.json": {
      "sha256": "ec4656d40f2c532ebfcae8f0136cb6ed6db9a29a91c48adce5c0ec58c313622a",
      "byte_length": 1070
    },
    ".input-b--verification.json": {
      "sha256": "2f25bd286d0b30ef2775712e6e60c66ad1dab0b19d255d9f4b423a7bdc22f32c",
      "byte_length": 16930
    },
    ".input-b--verification.md": {
      "sha256": "0d656a9d23059b0bb1a8f1ced4ee858fb85e1a8b900bcefbdbbd803b188d769f",
      "byte_length": 17364
    },
    ".selection-original.json": {
      "sha256": "12173d19841ca2f3224a5fd3d4267d8726e9f698d81233d30a5118b64a842998",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "4a4a6b90d1b1a40d8940f5a374c58770b541092feb21682a9bf080be167dd046",
      "byte_length": 571,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e",
            "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 44,
          "end_byte": 60
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005"
          ],
          "start_byte": 79,
          "end_byte": 95
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [
            "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1"
          ],
          "occurrence_ids": [
            "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 173,
          "end_byte": 320
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006"
          ],
          "start_byte": 325,
          "end_byte": 342
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [
            "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4"
          ],
          "occurrence_ids": [
            "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 420,
          "end_byte": 567
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000005",
          "target_path": "对象-60000000-0000-4000-8000-000000000005.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 96,
          "end_byte": 170
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000006",
          "target_path": "对象-60000000-0000-4000-8000-000000000006.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 343,
          "end_byte": 417
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000005.md",
      "note_id": "object-60000000-0000-4000-8000-000000000005",
      "plan_revision": 1,
      "content_sha256": "c1d81677e3427713647012adadf77d97e2760151d89113f4339a6212f09674f5",
      "byte_length": 375,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1"
          ],
          "occurrence_ids": [
            "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 37,
          "end_byte": 373
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000006.md",
      "note_id": "object-60000000-0000-4000-8000-000000000006",
      "plan_revision": 1,
      "content_sha256": "0cf17e09e21f541849ee41cc70f8d2f0012d38126cad2ca41dcf8b41f216d615",
      "byte_length": 378,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4"
          ],
          "occurrence_ids": [
            "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 38,
          "end_byte": 376
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "24e268de22edf33880f67437fa526b57f0b58a2cc7ff57eb0a11a183a2804410",
      "byte_length": 41454
    },
    ".coordination-owner.json": {
      "sha256": "037b33cffa8b40e06efdbc834bac38a746d42b7f1c173865f461d84673c004aa",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "5d743c4ff9a14d17b65976fabad54108b67d1bcc168865c5da97dd4b45f0fb05",
      "byte_length": 44925
    },
    ".coordination-report.md": {
      "sha256": "80d4c5fa325c37ebf37fcb47283a78fd2385c2aff1331de30572e4bf5c89930b",
      "byte_length": 45400
    },
    ".identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "fddb20df3bd5b519beee1810fcdc64640de93a8cb65fe8bb775e775c6329ff70",
      "byte_length": 3077
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "952908a34b65c48b517a32ceeb7f6fc548a7d05648ada6dafa8869393d1b08c3",
      "byte_length": 12416
    },
    ".input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    ".input-a--source-snapshot.json": {
      "sha256": "35cd22fa0c897fe88f2bc68c853472b25d3c9c1c2d28b4984508d89bc615be64",
      "byte_length": 1067
    },
    ".input-a--verification.json": {
      "sha256": "b48771989ecda555c2a1dda77bb4e7fb1f136b679f64ba4beeaa7d015d22f0a5",
      "byte_length": 16897
    },
    ".input-a--verification.md": {
      "sha256": "923b45714e83e874093cdfcac00bc6a465ad85b8f7f2698b725dd1bbe4b969bc",
      "byte_length": 17331
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "0c29b8bc28318e93ae4650ac33ca627104bf72e8692272eff204afcc0cc383c7",
      "byte_length": 3086
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6196114781a75151c2e75a86a2fb81059ca77599f51645c6672f513d2671943a",
      "byte_length": 12452
    },
    ".input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    ".input-b--source-snapshot.json": {
      "sha256": "ec4656d40f2c532ebfcae8f0136cb6ed6db9a29a91c48adce5c0ec58c313622a",
      "byte_length": 1070
    },
    ".input-b--verification.json": {
      "sha256": "2f25bd286d0b30ef2775712e6e60c66ad1dab0b19d255d9f4b423a7bdc22f32c",
      "byte_length": 16930
    },
    ".input-b--verification.md": {
      "sha256": "0d656a9d23059b0bb1a8f1ced4ee858fb85e1a8b900bcefbdbbd803b188d769f",
      "byte_length": 17364
    },
    ".owner.json": {
      "sha256": "cf955dbf382079873a739f2688861bfe2a2a51eefa035c752558a5974565d489",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "12173d19841ca2f3224a5fd3d4267d8726e9f698d81233d30a5118b64a842998",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "3e734ca612f5c4c5bc16c8a3cb1fb8030e2958b107c618555d37f57c3b3cdb03",
      "byte_length": 17326
    },
    "对象-60000000-0000-4000-8000-000000000005.md": {
      "sha256": "c1d81677e3427713647012adadf77d97e2760151d89113f4339a6212f09674f5",
      "byte_length": 375
    },
    "对象-60000000-0000-4000-8000-000000000006.md": {
      "sha256": "0cf17e09e21f541849ee41cc70f8d2f0012d38126cad2ca41dcf8b41f216d615",
      "byte_length": 378
    },
    "知识比较.md": {
      "sha256": "4a4a6b90d1b1a40d8940f5a374c58770b541092feb21682a9bf080be167dd046",
      "byte_length": 571
    }
  }
}
```
