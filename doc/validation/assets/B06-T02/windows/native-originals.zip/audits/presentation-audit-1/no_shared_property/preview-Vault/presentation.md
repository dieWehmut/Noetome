# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "65818922-0ba9-4fed-ac26-bc38aa11c95b",
  "project_id": "0a8a13fd-b710-4888-b028-6abf09b5b2af",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "34ae4a6cf89d569ccb95728088e6b168279b282a6e71448bde19add472df873e",
    "byte_length": 41373
  },
  "plan_fingerprint": {
    "sha256": "a97d0b7b37bc9700469f1875c62a962913b0fb6b81df3332066c7bc2b644d31f",
    "byte_length": 14709
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "34ae4a6cf89d569ccb95728088e6b168279b282a6e71448bde19add472df873e",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "aee6d049aa6003d6487bb398f75208ed31ee4d76f14f9d2f820ce2a07b821c9d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "601f569f57baea130d0b819ef1e691aeeacdde23a38127a187f2c3add22c6224",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "136b1cf1767b564a035a0f336398927d652c97cf89c31c1a12375fbacfb67751",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "4fb2954b250f71435f53a73bd1db79ea2511b0dd128a331b9da0716e20de4a01",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "65fa86b905a00cd38a0f09c18e0c87c5931edd2b370df2fe85f7ea90109b1a6f",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2ec5d9c0d30b84dd82d69a055dda4dbcb1f69f21122465e528654bb0fd50b7da",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "93a1103f8be3675539658c425dd89b80ea70b1d676abcc51bb7f827b3df5fcbe",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e2eae3291b974d3cedc18fe3725de5cf1f28c30c139fb56da8bda21910fb0bce",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "bd1b2c08d0e48518f224bed61ec53d9dc7b2b03106882a2b2e5255c832f19435",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "3c1622013bf5a364ee59490f509b30fcf715ff558a655a010865620974dc35c2",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0a478737143a282811fa6586796c547566d03f69c9d6d1b687213e1374b9062d",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "1cb12b998e25b8a6e130bded78b9fe1fadfa617b09688d1312b7ccc280c2597f",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "f999f19acbc1fae5865fbc4c31aada1268e10054d40323c9a13c2992052d4197",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "25470e3a42850d6a37a1c19cba61eb4c3d473443bef6e48883c7558ba7051a75",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-5de99e5d6c08d98ad717eadbb904288a906e445de62c0135752a64f4fee04e36"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-a9153abee5532f482212ced2559e05cf7d3cdbd8fc4417ef56552079fddf62e5"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-a9153abee5532f482212ced2559e05cf7d3cdbd8fc4417ef56552079fddf62e5"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-5de99e5d6c08d98ad717eadbb904288a906e445de62c0135752a64f4fee04e36"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "34ae4a6cf89d569ccb95728088e6b168279b282a6e71448bde19add472df873e",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "aee6d049aa6003d6487bb398f75208ed31ee4d76f14f9d2f820ce2a07b821c9d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "601f569f57baea130d0b819ef1e691aeeacdde23a38127a187f2c3add22c6224",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "136b1cf1767b564a035a0f336398927d652c97cf89c31c1a12375fbacfb67751",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "4fb2954b250f71435f53a73bd1db79ea2511b0dd128a331b9da0716e20de4a01",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "65fa86b905a00cd38a0f09c18e0c87c5931edd2b370df2fe85f7ea90109b1a6f",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2ec5d9c0d30b84dd82d69a055dda4dbcb1f69f21122465e528654bb0fd50b7da",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "93a1103f8be3675539658c425dd89b80ea70b1d676abcc51bb7f827b3df5fcbe",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e2eae3291b974d3cedc18fe3725de5cf1f28c30c139fb56da8bda21910fb0bce",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "bd1b2c08d0e48518f224bed61ec53d9dc7b2b03106882a2b2e5255c832f19435",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "3c1622013bf5a364ee59490f509b30fcf715ff558a655a010865620974dc35c2",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0a478737143a282811fa6586796c547566d03f69c9d6d1b687213e1374b9062d",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "1cb12b998e25b8a6e130bded78b9fe1fadfa617b09688d1312b7ccc280c2597f",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "f999f19acbc1fae5865fbc4c31aada1268e10054d40323c9a13c2992052d4197",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "0614a322f9f235cf36b9b8aa25e91b477efa2ed403e95da4edfcf78026707b28",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "25470e3a42850d6a37a1c19cba61eb4c3d473443bef6e48883c7558ba7051a75",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "a97d0b7b37bc9700469f1875c62a962913b0fb6b81df3332066c7bc2b644d31f",
      "byte_length": 14709
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323
    },
    "知识比较.md": {
      "sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514
    }
  }
}
```
