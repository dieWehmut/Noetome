# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "a4824c0c-62fa-4e50-a5d9-ce84fc7a580c",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000005",
      "display_name": "甲容器 [α]"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000006",
      "display_name": "乙容器（β）"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000007",
      "display_name": "速率 | 测量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
        "import_id": "d5949410-d4dc-4b66-967c-c441e8f10414",
        "source_id": "540ad8c3-9fde-4e49-ad00-58d2a7b2efd0",
        "version_id": "d23c915b-0837-428a-bb4b-9faccaf7c8ab",
        "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "import_id": "d5949410-d4dc-4b66-967c-c441e8f10414",
              "manifest_sha256": null,
              "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "parse_id": null,
              "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
              "source_id": "540ad8c3-9fde-4e49-ad00-58d2a7b2efd0",
              "version_id": "d23c915b-0837-428a-bb4b-9faccaf7c8ab"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "import_id": "d5949410-d4dc-4b66-967c-c441e8f10414",
              "manifest_sha256": null,
              "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "parse_id": null,
              "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
              "source_id": "540ad8c3-9fde-4e49-ad00-58d2a7b2efd0",
              "version_id": "d23c915b-0837-428a-bb4b-9faccaf7c8ab"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 176,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 177,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 176,
            "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 176,
            "quote": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 176,
              "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "甲容器 [α]",
              "速率 | 测量"
            ],
            "compound": "甲容器 [α] 速率 | 测量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "甲容器 [α]",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速率 | 测量",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "actual": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "x < 2",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "计数范围 [1,2]",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          },
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "读数 * 异常时不适用",
          "actual": {
            "body": [
              "读数*异常时不适用"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": [
            "读数 * 异常时不适用"
          ],
          "actual": [
            "读数*异常时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "contexts": [],
            "exceptions": [
              "读数 * 异常时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "fddb20df3bd5b519beee1810fcdc64640de93a8cb65fe8bb775e775c6329ff70",
          "byte_length": 3077
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
          "byte_length": 780
        },
        "knowledge-ir.json": {
          "sha256": "952908a34b65c48b517a32ceeb7f6fc548a7d05648ada6dafa8869393d1b08c3",
          "byte_length": 12416
        },
        "review-original.json": {
          "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
          "byte_length": 525
        },
        "source-snapshot.json": {
          "sha256": "35cd22fa0c897fe88f2bc68c853472b25d3c9c1c2d28b4984508d89bc615be64",
          "byte_length": 1067
        },
        "verification.json": {
          "sha256": "b48771989ecda555c2a1dda77bb4e7fb1f136b679f64ba4beeaa7d015d22f0a5",
          "byte_length": 16897
        },
        "verification.md": {
          "sha256": "923b45714e83e874093cdfcac00bc6a465ad85b8f7f2698b725dd1bbe4b969bc",
          "byte_length": 17331
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
        "import_id": "4dce2f2b-3867-48cf-8c4b-a81b7978135c",
        "source_id": "4aa205d5-fe8e-43dc-a0c2-62fe6d02660f",
        "version_id": "dc7b8bdd-b6bf-47ff-99cc-9cdcd9fb476b",
        "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "import_id": "4dce2f2b-3867-48cf-8c4b-a81b7978135c",
              "manifest_sha256": null,
              "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "parse_id": null,
              "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
              "source_id": "4aa205d5-fe8e-43dc-a0c2-62fe6d02660f",
              "version_id": "dc7b8bdd-b6bf-47ff-99cc-9cdcd9fb476b"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "import_id": "4dce2f2b-3867-48cf-8c4b-a81b7978135c",
              "manifest_sha256": null,
              "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "parse_id": null,
              "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
              "source_id": "4aa205d5-fe8e-43dc-a0c2-62fe6d02660f",
              "version_id": "dc7b8bdd-b6bf-47ff-99cc-9cdcd9fb476b"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 179,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 180,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 179,
            "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 179,
            "quote": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 179,
              "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "乙容器（β）",
              "速率 | 测量"
            ],
            "compound": "乙容器（β） 速率 | 测量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "乙容器（β）",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速率 | 测量",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "actual": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "x < 2",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "计数范围 [1,2]",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          },
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "读数 * 异常时不适用",
          "actual": {
            "body": [
              "读数*异常时不适用"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": [
            "读数 * 异常时不适用"
          ],
          "actual": [
            "读数*异常时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "contexts": [],
            "exceptions": [
              "读数 * 异常时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "0c29b8bc28318e93ae4650ac33ca627104bf72e8692272eff204afcc0cc383c7",
          "byte_length": 3086
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
          "byte_length": 789
        },
        "knowledge-ir.json": {
          "sha256": "6196114781a75151c2e75a86a2fb81059ca77599f51645c6672f513d2671943a",
          "byte_length": 12452
        },
        "review-original.json": {
          "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
          "byte_length": 528
        },
        "source-snapshot.json": {
          "sha256": "ec4656d40f2c532ebfcae8f0136cb6ed6db9a29a91c48adce5c0ec58c313622a",
          "byte_length": 1070
        },
        "verification.json": {
          "sha256": "2f25bd286d0b30ef2775712e6e60c66ad1dab0b19d255d9f4b423a7bdc22f32c",
          "byte_length": 16930
        },
        "verification.md": {
          "sha256": "0d656a9d23059b0bb1a8f1ced4ee858fb85e1a8b900bcefbdbbd803b188d769f",
          "byte_length": 17364
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 176,
        "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
        "sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42"
      },
      "occurrence_id": "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e",
      "input_id": "a",
      "binding": {
        "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
        "import_id": "d5949410-d4dc-4b66-967c-c441e8f10414",
        "source_id": "540ad8c3-9fde-4e49-ad00-58d2a7b2efd0",
        "version_id": "d23c915b-0837-428a-bb4b-9faccaf7c8ab",
        "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "06279728-6668-473d-aa4e-df62d25ab8bd",
          "ordinal": 0,
          "resource_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 177,
        "text": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "甲容器 [α]",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速率 | 测量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "qualifiers": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "x < 2",
            "计数范围 [1,2]"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 176,
          "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
          "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000005",
        "60000000-0000-4000-8000-000000000007"
      ],
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "x < 2",
        "计数范围 [1,2]"
      ],
      "exceptions": [
        "读数 * 异常时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 179,
        "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
        "sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8"
      },
      "occurrence_id": "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11",
      "input_id": "b",
      "binding": {
        "project_id": "01c9dafb-ad3b-42d9-b56b-0718a3514522",
        "import_id": "4dce2f2b-3867-48cf-8c4b-a81b7978135c",
        "source_id": "4aa205d5-fe8e-43dc-a0c2-62fe6d02660f",
        "version_id": "dc7b8bdd-b6bf-47ff-99cc-9cdcd9fb476b",
        "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f10b8cdb-ede4-48f1-b5b0-8e8454e68c97",
          "ordinal": 0,
          "resource_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 180,
        "text": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "乙容器（β）",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速率 | 测量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "qualifiers": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "x < 2",
            "计数范围 [1,2]"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 179,
          "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
          "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000006",
        "60000000-0000-4000-8000-000000000007"
      ],
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "x < 2",
        "计数范围 [1,2]"
      ],
      "exceptions": [
        "读数 * 异常时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4",
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "x<2",
        "计数范围[1,2]"
      ],
      "exceptions": [
        "读数*异常时不适用"
      ],
      "occurrence_ids": [
        "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1",
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "x<2",
        "计数范围[1,2]"
      ],
      "exceptions": [
        "读数*异常时不适用"
      ],
      "occurrence_ids": [
        "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e",
      "right_occurrence_id": "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-0d3daf87667f69718f2c11711c28c170247f593adaf498eb059c2dafa6d0448e",
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-a13758fdda739d459118d325d0aab660006af318107deb49c6c21c03f8d97c11",
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "037b33cffa8b40e06efdbc834bac38a746d42b7f1c173865f461d84673c004aa",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "24e268de22edf33880f67437fa526b57f0b58a2cc7ff57eb0a11a183a2804410",
      "byte_length": 41454
    },
    "coordination-original.json": {
      "sha256": "12173d19841ca2f3224a5fd3d4267d8726e9f698d81233d30a5118b64a842998",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "fddb20df3bd5b519beee1810fcdc64640de93a8cb65fe8bb775e775c6329ff70",
      "byte_length": 3077
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    "input-a--knowledge-ir.json": {
      "sha256": "952908a34b65c48b517a32ceeb7f6fc548a7d05648ada6dafa8869393d1b08c3",
      "byte_length": 12416
    },
    "input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    "input-a--source-snapshot.json": {
      "sha256": "35cd22fa0c897fe88f2bc68c853472b25d3c9c1c2d28b4984508d89bc615be64",
      "byte_length": 1067
    },
    "input-a--verification.json": {
      "sha256": "b48771989ecda555c2a1dda77bb4e7fb1f136b679f64ba4beeaa7d015d22f0a5",
      "byte_length": 16897
    },
    "input-a--verification.md": {
      "sha256": "923b45714e83e874093cdfcac00bc6a465ad85b8f7f2698b725dd1bbe4b969bc",
      "byte_length": 17331
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "0c29b8bc28318e93ae4650ac33ca627104bf72e8692272eff204afcc0cc383c7",
      "byte_length": 3086
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    "input-b--knowledge-ir.json": {
      "sha256": "6196114781a75151c2e75a86a2fb81059ca77599f51645c6672f513d2671943a",
      "byte_length": 12452
    },
    "input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    "input-b--source-snapshot.json": {
      "sha256": "ec4656d40f2c532ebfcae8f0136cb6ed6db9a29a91c48adce5c0ec58c313622a",
      "byte_length": 1070
    },
    "input-b--verification.json": {
      "sha256": "2f25bd286d0b30ef2775712e6e60c66ad1dab0b19d255d9f4b423a7bdc22f32c",
      "byte_length": 16930
    },
    "input-b--verification.md": {
      "sha256": "0d656a9d23059b0bb1a8f1ced4ee858fb85e1a8b900bcefbdbbd803b188d769f",
      "byte_length": 17364
    }
  }
}
```
