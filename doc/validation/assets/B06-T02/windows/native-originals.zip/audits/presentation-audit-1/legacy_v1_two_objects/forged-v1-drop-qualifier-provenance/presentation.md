# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "d0554ee5-b62d-42aa-8723-f9c93ec089c6",
  "project_id": "30624af2-f44c-4704-894c-3216396ba5bb",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "1321115ed965114f2b232ab78b899fb9946d917471d52b7932ba8d4a60506b02",
    "byte_length": 38360
  },
  "plan_fingerprint": {
    "sha256": "a6430c41beb6467b1532a159baef5172440bf747f039dc37732b433705b8209c",
    "byte_length": 16372
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "1321115ed965114f2b232ab78b899fb9946d917471d52b7932ba8d4a60506b02",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "20d3485d0298fe3112178d511e05febf00dd25cadf1ea7453fe3563bf0cbd01f",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "a7e9ef56b46a630b5855dc558bf3f0f21ed975dff708e9ae933c288df0cb512d",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "0dd1f7952f40266b51d1d8e4becf002e0ff57f20514b1bd548e7f40865af5531",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "b4cd85cd2820e6e4bedc363d6a61443a2c8cef78ffd3cfdcbf0a2e21e7807f39",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b0691f0e17acfe4f64564abae97640c88d3804ed44dba3d7c92a344d35d89bfd",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "e3db64418da9756b5418fb1f6aba02cc9d32e390f214d1f4fc39ec639edfd712",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "4ca2d384f19af41cf878da7c4a66479862861d17e047a4bcce3e48e1703b66ac",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "280be371319b971646d046a727a47609bfc5a51ab2aa9ad834dc5ba525eef50f",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "992d3962eb938f5158e399f744371a48fea6175f711522eacfafd4aa226ec260",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9d30e5bf3cca3d502b97a785820e6dee16cae15f15c7f6aafa85bafed242bb54",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "1a5fef200b2da5fee7be7b878faf9dc1c464f0fbe7168de792ce05f5bb58fad2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "aa9dc45f583cfb04e6c118ac805f74650fc76fc8506fb6b0e7a4631eeded9399",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "e2b5f9f3ee82be103cc918fda15a3b0e546ccdfc10adff22f380e33cb7dc9bd9",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "ee5f763142de2bfd86f34e584059b6dc03ab5595cb38ae87ef124132ccb7583a",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-179569e89d1e96793fc094c2a29fd9ea93c7af06c1e0f168c3592bea108bf750",
            "occ-79ac75ad479281111f05f71ea9a13812d75f092e270777b037233aa14d4b123d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-79ac75ad479281111f05f71ea9a13812d75f092e270777b037233aa14d4b123d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-79ac75ad479281111f05f71ea9a13812d75f092e270777b037233aa14d4b123d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-179569e89d1e96793fc094c2a29fd9ea93c7af06c1e0f168c3592bea108bf750"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 332,
          "end_byte": 340
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-179569e89d1e96793fc094c2a29fd9ea93c7af06c1e0f168c3592bea108bf750"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 418,
          "end_byte": 590
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 341,
          "end_byte": 415
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-79ac75ad479281111f05f71ea9a13812d75f092e270777b037233aa14d4b123d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-179569e89d1e96793fc094c2a29fd9ea93c7af06c1e0f168c3592bea108bf750"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "1321115ed965114f2b232ab78b899fb9946d917471d52b7932ba8d4a60506b02",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "20d3485d0298fe3112178d511e05febf00dd25cadf1ea7453fe3563bf0cbd01f",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "a7e9ef56b46a630b5855dc558bf3f0f21ed975dff708e9ae933c288df0cb512d",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "0dd1f7952f40266b51d1d8e4becf002e0ff57f20514b1bd548e7f40865af5531",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "b4cd85cd2820e6e4bedc363d6a61443a2c8cef78ffd3cfdcbf0a2e21e7807f39",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b0691f0e17acfe4f64564abae97640c88d3804ed44dba3d7c92a344d35d89bfd",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "e3db64418da9756b5418fb1f6aba02cc9d32e390f214d1f4fc39ec639edfd712",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "4ca2d384f19af41cf878da7c4a66479862861d17e047a4bcce3e48e1703b66ac",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "280be371319b971646d046a727a47609bfc5a51ab2aa9ad834dc5ba525eef50f",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "992d3962eb938f5158e399f744371a48fea6175f711522eacfafd4aa226ec260",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9d30e5bf3cca3d502b97a785820e6dee16cae15f15c7f6aafa85bafed242bb54",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "1a5fef200b2da5fee7be7b878faf9dc1c464f0fbe7168de792ce05f5bb58fad2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "aa9dc45f583cfb04e6c118ac805f74650fc76fc8506fb6b0e7a4631eeded9399",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "e2b5f9f3ee82be103cc918fda15a3b0e546ccdfc10adff22f380e33cb7dc9bd9",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "6fa527822e3c3531554ef57644f7bce6761cbccb59a52c135d951b23d8916e1c",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "ee5f763142de2bfd86f34e584059b6dc03ab5595cb38ae87ef124132ccb7583a",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "a6430c41beb6467b1532a159baef5172440bf747f039dc37732b433705b8209c",
      "byte_length": 16372
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594
    }
  }
}
```
