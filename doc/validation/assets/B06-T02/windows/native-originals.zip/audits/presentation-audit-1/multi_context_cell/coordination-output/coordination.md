# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：3；条件未知：0；条件不适用：0；时间已知：3；时间未知：0；条件并列关系：1；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "4869b7b9-dfde-499e-87be-ccd2989f1d4b",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
        "import_id": "70ddcb6e-003e-449c-87e4-c28001c71398",
        "source_id": "65efe04f-ac6c-4dba-b66b-35d9b0827c77",
        "version_id": "19837a37-f69f-48a8-8be7-ce8827057e99",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "70ddcb6e-003e-449c-87e4-c28001c71398",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
              "source_id": "65efe04f-ac6c-4dba-b66b-35d9b0827c77",
              "version_id": "19837a37-f69f-48a8-8be7-ce8827057e99"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "70ddcb6e-003e-449c-87e4-c28001c71398",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
              "source_id": "65efe04f-ac6c-4dba-b66b-35d9b0827c77",
              "version_id": "19837a37-f69f-48a8-8be7-ce8827057e99"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "3cf49fd284cdbcabcd6bfa4c4552b343352af861391a9639fb3ca6d85c8a25d6",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "e28bff493626cf813a4fc2ba0200671ba864d60ea94901b59f004fea85ef8b17",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "46caefc0fa2ed91eec5fd3bc2f9e91f30d56e852219ed4277073176d423794c6",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "24cdd207a1031bf07cca7c5e6fe3d9f9823c667393d6f5b316d102e522331195",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "3c1804356770e3c493090f25ca6a43bf4ae865651fe3fe52d5b5a4fe36f5d01c",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
        "import_id": "ca32047d-aa4b-4967-a2d1-cf7f082667ff",
        "source_id": "7c8e9315-cfac-44f1-9a07-71a791c03548",
        "version_id": "ddb43c2b-65aa-4044-ab25-034a9151d51d",
        "content_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
        "normalized_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
              "import_id": "ca32047d-aa4b-4967-a2d1-cf7f082667ff",
              "manifest_sha256": null,
              "normalized_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
              "parse_id": null,
              "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
              "source_id": "7c8e9315-cfac-44f1-9a07-71a791c03548",
              "version_id": "ddb43c2b-65aa-4044-ab25-034a9151d51d"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
              "import_id": "ca32047d-aa4b-4967-a2d1-cf7f082667ff",
              "manifest_sha256": null,
              "normalized_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
              "parse_id": null,
              "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
              "source_id": "7c8e9315-cfac-44f1-9a07-71a791c03548",
              "version_id": "ddb43c2b-65aa-4044-ab25-034a9151d51d"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "79a53e2075a84b755f1d052070249d7b1ddcc4df5942e790429aba9cecab1e37",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "79a53e2075a84b755f1d052070249d7b1ddcc4df5942e790429aba9cecab1e37",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "399b5c342eaad8bde4ef8ce8c95e4da1f55fee146a0d0589ac75fa2096f80582",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "7d07617bc75f716d963fd80e7bb9e816ee1c652068000c3c1331c12bf4f9bcaa",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "0f578a54e6eecfcb68e524392a51f47ef91444d79bdaca8a10bb3896242dab61",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "66a82090ef1359f2927fd9a0ffddb2e978a7b1454798841575ad3e15476f9eac",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "c2383b9f283855ff86c4c5c5a7e6940d3da40be96758cff6d1209cdf1873647f",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
        "import_id": "0ae68110-ded4-4ead-8654-4328f0f50784",
        "source_id": "b0279b21-5cc5-4182-9aea-eb63dbe16b5b",
        "version_id": "87411e36-fe2b-4f00-9670-919c53d46cf9",
        "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
        "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-speed"
            ],
            "decision": {
              "atom_ids": [
                "c-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
              "import_id": "0ae68110-ded4-4ead-8654-4328f0f50784",
              "manifest_sha256": null,
              "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
              "parse_id": null,
              "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
              "source_id": "b0279b21-5cc5-4182-9aea-eb63dbe16b5b",
              "version_id": "87411e36-fe2b-4f00-9670-919c53d46cf9"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
              "import_id": "0ae68110-ded4-4ead-8654-4328f0f50784",
              "manifest_sha256": null,
              "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
              "parse_id": null,
              "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
              "source_id": "b0279b21-5cc5-4182-9aea-eb63dbe16b5b",
              "version_id": "87411e36-fe2b-4f00-9670-919c53d46cf9"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "befb0f8255b79a2ec7dee20cc69acaeb05e88ccbdd799be37af9635e537a75df",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "befb0f8255b79a2ec7dee20cc69acaeb05e88ccbdd799be37af9635e537a75df",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "actual": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "11",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "unit": "m/s",
            "value": "11",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 B",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "f47c1aec33ba78856a362168f0237127d701e680ba83e7bad297ac614ba660dc",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "fc271df68f8ee64aad17d4cc4d95026e558fcfeb981088aab4adb1883b7d672f",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "830440b0e5e10810ea58ff1b3e29c2d7e3af9e7f7acf3b3b5ed3d3cc67973a07",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "3fdfdd28df1bfc6503de5e789a41306d1c01084374ae3fee07cf5fb29003b594",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "2d352f64a2cbb3d78afdc4041f06821af27eaf413ddbd5797586d9d3d7c9b18f",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "79a53e2075a84b755f1d052070249d7b1ddcc4df5942e790429aba9cecab1e37"
      },
      "occurrence_id": "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
      "input_id": "b",
      "binding": {
        "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
        "import_id": "ca32047d-aa4b-4967-a2d1-cf7f082667ff",
        "source_id": "7c8e9315-cfac-44f1-9a07-71a791c03548",
        "version_id": "ddb43c2b-65aa-4044-ab25-034a9151d51d",
        "content_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
        "normalized_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "001f552d-2afe-4bd0-acf1-8803d229c753",
          "ordinal": 0,
          "resource_sha256": "3a6fa5e4b6ececb207be03a8b3706ddc94155dfe41c3ff255a90d4e248ba4317"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "79a53e2075a84b755f1d052070249d7b1ddcc4df5942e790429aba9cecab1e37",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "c-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "sha256": "befb0f8255b79a2ec7dee20cc69acaeb05e88ccbdd799be37af9635e537a75df"
      },
      "occurrence_id": "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6",
      "input_id": "c",
      "binding": {
        "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
        "import_id": "0ae68110-ded4-4ead-8654-4328f0f50784",
        "source_id": "b0279b21-5cc5-4182-9aea-eb63dbe16b5b",
        "version_id": "87411e36-fe2b-4f00-9670-919c53d46cf9",
        "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
        "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "d8097991-edde-4a67-a9a9-141da9899e4f",
          "ordinal": 0,
          "resource_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "11",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 B"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "befb0f8255b79a2ec7dee20cc69acaeb05e88ccbdd799be37af9635e537a75df",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "11",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 B"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb",
      "input_id": "a",
      "binding": {
        "project_id": "4696d6ef-46e2-478b-a9f8-2c9938548109",
        "import_id": "70ddcb6e-003e-449c-87e4-c28001c71398",
        "source_id": "65efe04f-ac6c-4dba-b66b-35d9b0827c77",
        "version_id": "19837a37-f69f-48a8-8be7-ce8827057e99",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4273a897-f3c6-4712-bff1-e79722dbadc4",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "11",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例B",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
      "right_occurrence_id": "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6",
      "relation": "separate_object",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
      "right_occurrence_id": "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb",
      "relation": "condition_variant",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6",
      "right_occurrence_id": "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-824d343cf4fa41e53b3281ac0b6ce26b1a6fe4237732e6b0d08a7d31e30ad8ce",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-8cef4df681cfee4b57dc625d0b663a2e5035f7c62cc4c74bf39757ab88b8d2a6",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-ed74e6eb1c14bec5cac3cb8945ec0e897219898dab7f068e168913e9b0dbeaeb",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 1,
    "historical_relations": 0,
    "known_condition_occurrences": 3,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 3,
    "undated_occurrences": 0,
    "context_evidence_links": 3,
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 3,
    "canonical_facts": 3,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 0,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "9f85fe017d7ee70485cd19e70dc700fe5d63405e5762d785bc1922f28674dca4",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "f0a2ea13bccd772d0fbf58bd3fd506bcada340b5ed06a963bd006eae698c6634",
      "byte_length": 61685
    },
    "coordination-original.json": {
      "sha256": "9f2ed549089f91dccb5d901f4ee2b177cbd81cf368c2dca526be6d99d9eb88e7",
      "byte_length": 6402
    },
    "identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "3cf49fd284cdbcabcd6bfa4c4552b343352af861391a9639fb3ca6d85c8a25d6",
      "byte_length": 3057
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "e28bff493626cf813a4fc2ba0200671ba864d60ea94901b59f004fea85ef8b17",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "46caefc0fa2ed91eec5fd3bc2f9e91f30d56e852219ed4277073176d423794c6",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "24cdd207a1031bf07cca7c5e6fe3d9f9823c667393d6f5b316d102e522331195",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "3c1804356770e3c493090f25ca6a43bf4ae865651fe3fe52d5b5a4fe36f5d01c",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "399b5c342eaad8bde4ef8ce8c95e4da1f55fee146a0d0589ac75fa2096f80582",
      "byte_length": 3057
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "7d07617bc75f716d963fd80e7bb9e816ee1c652068000c3c1331c12bf4f9bcaa",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "0f578a54e6eecfcb68e524392a51f47ef91444d79bdaca8a10bb3896242dab61",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "66a82090ef1359f2927fd9a0ffddb2e978a7b1454798841575ad3e15476f9eac",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "c2383b9f283855ff86c4c5c5a7e6940d3da40be96758cff6d1209cdf1873647f",
      "byte_length": 17303
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "f47c1aec33ba78856a362168f0237127d701e680ba83e7bad297ac614ba660dc",
      "byte_length": 3057
    },
    "input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    "input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    "input-c--knowledge-ir.json": {
      "sha256": "fc271df68f8ee64aad17d4cc4d95026e558fcfeb981088aab4adb1883b7d672f",
      "byte_length": 12394
    },
    "input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    "input-c--source-snapshot.json": {
      "sha256": "830440b0e5e10810ea58ff1b3e29c2d7e3af9e7f7acf3b3b5ed3d3cc67973a07",
      "byte_length": 1056
    },
    "input-c--verification.json": {
      "sha256": "3fdfdd28df1bfc6503de5e789a41306d1c01084374ae3fee07cf5fb29003b594",
      "byte_length": 16869
    },
    "input-c--verification.md": {
      "sha256": "2d352f64a2cbb3d78afdc4041f06821af27eaf413ddbd5797586d9d3d7c9b18f",
      "byte_length": 17303
    }
  }
}
```
