# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "f02c3a1c-f4ba-48e9-926d-239b23c27165",
  "project_id": "f13447a7-e489-49ad-ab84-ddf2474737c6",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "732e9deebeae6e839c9c72332f936ee6aa1a988af5918c58737ef90d9184a772",
    "byte_length": 41343
  },
  "plan_fingerprint": {
    "sha256": "7f6dce239995a3b9f5f2f7c0063dd5d9d6848d075a60a5bef03df546f95aae64",
    "byte_length": 17164
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "732e9deebeae6e839c9c72332f936ee6aa1a988af5918c58737ef90d9184a772",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "ad65e1d1ffa00f9fceba08caa28870cd5bd38055737f96c15e261dc0ef8862f1",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "7e8c776f1c40ba33f773371539217cfbc815d0fdabe63e41dead115add0d65d5",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "4778afb647582081c2f91b2e079f33fe760a070eb934c2fde1b5a1b62a27948e",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e5afbd9c392f5733dfeff35b56b48bf324bfc00c30829ca1a0cbee004cc77012",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "06be29b1c86e8996a324a80d63a3eaccad47d7f97a9a317eebab2a7ca7e76683",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "70d462f8b69387bbf691ba34a097d21b099dc5ae11d1f4ab408858f9a5c31beb",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "a9ef6d1b006308f69d7aac9156820c4c91f1df20fbaee1205dd750b74501b418",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "8b1bf01497b25699a41ae22a53e4e97bc09514fdfb4c8d8c5f138b1d6118442d",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "b02811df064300a6727e6e5f0067026250cd14b377455f9e20e60a1cbae541f0",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6070130d1cdd1e88d936d99816fa2a2793d38f43447482998db9e7d20f618eec",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "f3347ecc114df92c0dcd54489f630e0d9398c96a7719a504230f7d8fd3a706a8",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "0f8de8b4d006e0fa71972bece0a73cfbac5054cad0fca560cff139112683dc9e",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "b86d4e0061f550815b16c4ee4affa998bd43346ea9d61dc7f10b0941dc0a8c22",
      "byte_length": 17319
    },
    ".selection-original.json": {
      "sha256": "cf1011fec61a48cdd76435f10251c5863aab5e88f403254ee0e2848d692bd412",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0a73c03cb9733d685e32c9dcc8271bf82cda8e4e501b4c2d4726323ba5d9d143",
            "occ-d5c40cd41281ff273941ae99dbb046fea43bd3f92d36ebf40b11c9c2c875ef8a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-d5c40cd41281ff273941ae99dbb046fea43bd3f92d36ebf40b11c9c2c875ef8a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-d5c40cd41281ff273941ae99dbb046fea43bd3f92d36ebf40b11c9c2c875ef8a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0a73c03cb9733d685e32c9dcc8271bf82cda8e4e501b4c2d4726323ba5d9d143"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-0a73c03cb9733d685e32c9dcc8271bf82cda8e4e501b4c2d4726323ba5d9d143"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 539
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-d5c40cd41281ff273941ae99dbb046fea43bd3f92d36ebf40b11c9c2c875ef8a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-0a73c03cb9733d685e32c9dcc8271bf82cda8e4e501b4c2d4726323ba5d9d143"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 329
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "732e9deebeae6e839c9c72332f936ee6aa1a988af5918c58737ef90d9184a772",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "ad65e1d1ffa00f9fceba08caa28870cd5bd38055737f96c15e261dc0ef8862f1",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "7e8c776f1c40ba33f773371539217cfbc815d0fdabe63e41dead115add0d65d5",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "4778afb647582081c2f91b2e079f33fe760a070eb934c2fde1b5a1b62a27948e",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e5afbd9c392f5733dfeff35b56b48bf324bfc00c30829ca1a0cbee004cc77012",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "06be29b1c86e8996a324a80d63a3eaccad47d7f97a9a317eebab2a7ca7e76683",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "70d462f8b69387bbf691ba34a097d21b099dc5ae11d1f4ab408858f9a5c31beb",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "a9ef6d1b006308f69d7aac9156820c4c91f1df20fbaee1205dd750b74501b418",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "8b1bf01497b25699a41ae22a53e4e97bc09514fdfb4c8d8c5f138b1d6118442d",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "b02811df064300a6727e6e5f0067026250cd14b377455f9e20e60a1cbae541f0",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6070130d1cdd1e88d936d99816fa2a2793d38f43447482998db9e7d20f618eec",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "f3347ecc114df92c0dcd54489f630e0d9398c96a7719a504230f7d8fd3a706a8",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "0f8de8b4d006e0fa71972bece0a73cfbac5054cad0fca560cff139112683dc9e",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "b86d4e0061f550815b16c4ee4affa998bd43346ea9d61dc7f10b0941dc0a8c22",
      "byte_length": 17319
    },
    ".owner.json": {
      "sha256": "51f72bdd1f96b6beb90d2e503e1df58bfcec48655a0b26dae11f2d2e8878ce16",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "cf1011fec61a48cdd76435f10251c5863aab5e88f403254ee0e2848d692bd412",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "7f6dce239995a3b9f5f2f7c0063dd5d9d6848d075a60a5bef03df546f95aae64",
      "byte_length": 17164
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331
    },
    "知识比较.md": {
      "sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543
    }
  }
}
```
