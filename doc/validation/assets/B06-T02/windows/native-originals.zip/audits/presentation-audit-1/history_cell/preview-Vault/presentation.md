# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "d48fd331-d7e9-4fae-8ce8-b5324def2217",
  "project_id": "681664b7-9e84-4f7b-a8dc-d3cbbcce8f36",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "cf083c727d0f399e4462be9d8862c6a08be3a7028f0c9f20cd783a459f1a4209",
    "byte_length": 61820
  },
  "plan_fingerprint": {
    "sha256": "1e757cb77e3ef98efd8368e53fa43387ce0d384072b5b391ddc7d6c2e06a681a",
    "byte_length": 22900
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "cf083c727d0f399e4462be9d8862c6a08be3a7028f0c9f20cd783a459f1a4209",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "b597423146fb85ce594577138c92070112d6a31988a0a8741349fe4dd343794c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d8869b6b628ee3e4e130da4ebb39f7051eb7922d5754ca74d0c22b1558ae6be1",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "56dcb1d9d5aa0e3d655b6bca40c09e691dcd3bf6c8632edcd21a8e25cdc14c47",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "b4b4d3ba1de4319b13203295f6707def08980670dba21a24fed2302682296263",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "db334df68ca8d48c42898c6d977c88a095aa5c9a5af909d2f9a3089430ce91a8",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "98180ded9486be4ee9227f5bbc6b88e82f4d17c6de59cd7b5e70046a950f15b5",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "563da2071994fd5a2786c5fa8715b3c4ffddb55b9d00d6d5db59ed29acb3940a",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "451095bb52bcc39d8555aae71acdd7047ee5f61ac3a78dc225fae45400b4a35e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c0d2b1870fa6c5b9d93be8fb243a44b01b903dfe1c10e5bac0459fab76d2b180",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b9f20bf15dc15942ae9a7f732101c1fe0c7d1dfe0ac70f041557a94b1cfe78da",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "694f423ea9cd04ec3a2a9879aae2ca01d78b82c790a451f03bc45dca6cdc1bde",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "15d8ba919a505eba4da0f203e6ab75977f447dd32dc3b870754991ab6b1e247f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "29cbdef4be195a49cef2aeca2085c092504e985d38205470a170f375b690a537",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "29313e5c6ae299c1a9387ed27bf520bf2cc26adf27d2586908709747700fc07a",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "89e43f89f75fc605d37af4d7c05d7c055a51d3e932c5e2bd22d2d90d1bce87f8",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "3bf2e1569c787e7e1a9373aedc0548bc1d6780719dcb51ef3fae49e671672d72",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "c9ba0da7be6abde49a0158c017f6736fa6399b4e9742ebe27b5914e409366a11",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "49e1e2a9c3ae3d476e73fbc7a43342c86f8314240111d3a393d6935f8b9c6b88",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "7ada30807567d13b5a9ba7e429c0110a6ed0073788b1cd4ae2eee48eb0e05077",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "02b9ac3e26c38da49252f068b0bae9ad4e340fe7233d7b7c39eaf2caa0bedacf",
      "byte_length": 692,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-01c8d2d020b1e57037ddb8d127b7b8edad8c790be5b27a7ed24c5646f0c63f5b",
            "occ-2a6bb65913552788b12de8fc28b184e21568a886f5a0c8e158cad246a9fd1dbe",
            "occ-d740a022f6842f9cfdaa408296b909f8526202996a021fe2910dbf6d7b5fceef"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-01c8d2d020b1e57037ddb8d127b7b8edad8c790be5b27a7ed24c5646f0c63f5b",
            "occ-2a6bb65913552788b12de8fc28b184e21568a886f5a0c8e158cad246a9fd1dbe"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-01c8d2d020b1e57037ddb8d127b7b8edad8c790be5b27a7ed24c5646f0c63f5b",
            "occ-2a6bb65913552788b12de8fc28b184e21568a886f5a0c8e158cad246a9fd1dbe"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 451
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-d740a022f6842f9cfdaa408296b909f8526202996a021fe2910dbf6d7b5fceef"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 456,
          "end_byte": 464
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-d740a022f6842f9cfdaa408296b909f8526202996a021fe2910dbf6d7b5fceef"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 542,
          "end_byte": 688
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 465,
          "end_byte": 539
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-01c8d2d020b1e57037ddb8d127b7b8edad8c790be5b27a7ed24c5646f0c63f5b"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2a6bb65913552788b12de8fc28b184e21568a886f5a0c8e158cad246a9fd1dbe"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-d740a022f6842f9cfdaa408296b909f8526202996a021fe2910dbf6d7b5fceef"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "cf083c727d0f399e4462be9d8862c6a08be3a7028f0c9f20cd783a459f1a4209",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "b597423146fb85ce594577138c92070112d6a31988a0a8741349fe4dd343794c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d8869b6b628ee3e4e130da4ebb39f7051eb7922d5754ca74d0c22b1558ae6be1",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "56dcb1d9d5aa0e3d655b6bca40c09e691dcd3bf6c8632edcd21a8e25cdc14c47",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "b4b4d3ba1de4319b13203295f6707def08980670dba21a24fed2302682296263",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "db334df68ca8d48c42898c6d977c88a095aa5c9a5af909d2f9a3089430ce91a8",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "98180ded9486be4ee9227f5bbc6b88e82f4d17c6de59cd7b5e70046a950f15b5",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "563da2071994fd5a2786c5fa8715b3c4ffddb55b9d00d6d5db59ed29acb3940a",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "451095bb52bcc39d8555aae71acdd7047ee5f61ac3a78dc225fae45400b4a35e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c0d2b1870fa6c5b9d93be8fb243a44b01b903dfe1c10e5bac0459fab76d2b180",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b9f20bf15dc15942ae9a7f732101c1fe0c7d1dfe0ac70f041557a94b1cfe78da",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "694f423ea9cd04ec3a2a9879aae2ca01d78b82c790a451f03bc45dca6cdc1bde",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "15d8ba919a505eba4da0f203e6ab75977f447dd32dc3b870754991ab6b1e247f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "29cbdef4be195a49cef2aeca2085c092504e985d38205470a170f375b690a537",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "29313e5c6ae299c1a9387ed27bf520bf2cc26adf27d2586908709747700fc07a",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "89e43f89f75fc605d37af4d7c05d7c055a51d3e932c5e2bd22d2d90d1bce87f8",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "3bf2e1569c787e7e1a9373aedc0548bc1d6780719dcb51ef3fae49e671672d72",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "c9ba0da7be6abde49a0158c017f6736fa6399b4e9742ebe27b5914e409366a11",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "49e1e2a9c3ae3d476e73fbc7a43342c86f8314240111d3a393d6935f8b9c6b88",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "6f21ab791764fffa042e703ac068e684e907f96495043f7d0310f230d7186881",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "7ada30807567d13b5a9ba7e429c0110a6ed0073788b1cd4ae2eee48eb0e05077",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "1e757cb77e3ef98efd8368e53fa43387ce0d384072b5b391ddc7d6c2e06a681a",
      "byte_length": 22900
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "02b9ac3e26c38da49252f068b0bae9ad4e340fe7233d7b7c39eaf2caa0bedacf",
      "byte_length": 692
    }
  }
}
```
