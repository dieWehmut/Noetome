# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
      "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
      "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
      "version_id": "181ef724-17ad-4933-ba20-f35386bffb05",
      "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
      "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "74fbf78b-a5cb-4ba7-851f-c02f942221d8",
          "ordinal": 0,
          "resource_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
    "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
    "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
    "version_id": "181ef724-17ad-4933-ba20-f35386bffb05",
    "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
    "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "397164bc304db845614c8f15204a1232b8db07eeaeb54de38c770672a2cd7105",
        "byte_length": 3052
      },
      "decision.json": {
        "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
        "byte_length": 143
      },
      "gold.json": {
        "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
        "byte_length": 735
      },
      "review.json": {
        "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
        "byte_length": 508
      }
    },
    "gold_sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "速度",
    "property": "密度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-density"
        ],
        "decision": {
          "atom_ids": [
            "a-density"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
          "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
          "manifest_sha256": null,
          "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
          "parse_id": null,
          "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
          "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
          "version_id": "181ef724-17ad-4933-ba20-f35386bffb05"
        },
        "request_id": "synthetic-coordination-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
          "import_id": "36fd37e0-1d85-44e1-8960-a03aa7f026b0",
          "manifest_sha256": null,
          "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
          "parse_id": null,
          "project_id": "063336cf-e912-4e6e-988e-153ec67d2fa6",
          "source_id": "ab8092ee-67f6-4c72-ba91-d6809bb9a814",
          "version_id": "181ef724-17ad-4933-ba20-f35386bffb05"
        },
        "request_id": "synthetic-coordination-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 162,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 163,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 162,
        "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
        "excerpt_start_byte": 0,
        "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 162,
        "quote": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 162,
          "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
          "excerpt_start_byte": 0,
          "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "速度",
          "密度"
        ],
        "compound": "速度 密度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "密度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
      "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "2",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用所选样例"
        ],
        "unit": "kg/m³",
        "value": "2",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "kg/m³",
      "actual": {
        "measurement": "kg/m³",
        "qualifiers": [
          "kg/m³",
          "温度 20 ℃",
          "仅适用所选样例",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用所选样例"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用所选样例"
        ],
        "qualifiers": [
          "kg/m³",
          "温度 20 ℃",
          "仅适用所选样例",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "仅适用所选样例",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用所选样例"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用所选样例"
        ],
        "qualifiers": [
          "kg/m³",
          "温度 20 ℃",
          "仅适用所选样例",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用所选样例"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用所选样例"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用所选样例"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "kg/m³",
          "温度 20 ℃",
          "仅适用所选样例",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-density",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用所选样例"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "kg/m³"
      },
      "actual": [
        "kg/m³",
        "温度 20 ℃",
        "仅适用所选样例",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "397164bc304db845614c8f15204a1232b8db07eeaeb54de38c770672a2cd7105",
      "byte_length": 3052
    },
    "decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    "gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    "knowledge-ir.json": {
      "sha256": "5e060d16e52a1239c2f0d580c6d4fa05ae64627043170e5d2374ba1bdc278449",
      "byte_length": 12391
    },
    "review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    "source-snapshot.json": {
      "sha256": "24b38be2ee2ae29fce2289878b50f8b376e0e22054914520045f3528713f1b96",
      "byte_length": 1053
    }
  }
}
```
