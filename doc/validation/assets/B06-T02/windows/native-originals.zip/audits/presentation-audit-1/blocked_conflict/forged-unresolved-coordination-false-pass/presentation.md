# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "1e49e1b9-7801-45d2-9447-12015b23a317",
  "project_id": "fa567c44-0351-483c-8649-86e657917a40",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 1,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "ef6420319a9f32ebee3bf331c5b8c3cae5e30c6a6f41e005c4d1f0f77a3ca2fb",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "21d05e1110c4951fddd2b83bb51c15866523664a4d83d542661270bfbc4af89d",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "25b2a4addb9df75a324194558e706843219d5048ebb918d6fda9a6c0fcccba08",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "fbb60eddd4e601facd495b05ea7ad8b159f7781a66279fd7011cf9c08cf23508",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b659c982f3b1fc3a9374e38541b50170a450746e38df4cf3acb537e063522db6",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "57ff300e1c29b0f31a53413fdb5a6ab7f834ff4d79ce482e516febb4da2a3033",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "7c9a2da52a8e9f5ba801879fbb76af2f58b56d1d3db26a2757bb85a0b0efc765",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "ca603a963129f0725f184c9b5911f05fd1570010e2ab730082dcfd40904fbaf6",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "4a922f230bdf74e95f2d0768d4fef71f58f046a89daedbab53606048e804890a",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "841bf1bea3cc6cd031482bcddb2a7a71472f00110b713a882c8c640e79bbc7f3",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9baa29c8b887cf37751fa2d8ab5cdde244bf5167c9a9ebd022dd0102b2717032",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "f29ef797604984bccb27ac3ca8f76304d026c34ca8ed2d90448fe9f8a8676ad8",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5b9e9eb50559b5a7df45fdb6a78a8f70d9bc3f5961e520cf2c5a789480aabad2",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "15de7633dc285ef4d6e01b814bc0a8c6ca8deb861dbdb98130cec3eaafb3554d",
      "byte_length": 4330
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "ef6420319a9f32ebee3bf331c5b8c3cae5e30c6a6f41e005c4d1f0f77a3ca2fb",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "21d05e1110c4951fddd2b83bb51c15866523664a4d83d542661270bfbc4af89d",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "25b2a4addb9df75a324194558e706843219d5048ebb918d6fda9a6c0fcccba08",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "fbb60eddd4e601facd495b05ea7ad8b159f7781a66279fd7011cf9c08cf23508",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b659c982f3b1fc3a9374e38541b50170a450746e38df4cf3acb537e063522db6",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "57ff300e1c29b0f31a53413fdb5a6ab7f834ff4d79ce482e516febb4da2a3033",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "7c9a2da52a8e9f5ba801879fbb76af2f58b56d1d3db26a2757bb85a0b0efc765",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "ca603a963129f0725f184c9b5911f05fd1570010e2ab730082dcfd40904fbaf6",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "4a922f230bdf74e95f2d0768d4fef71f58f046a89daedbab53606048e804890a",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "841bf1bea3cc6cd031482bcddb2a7a71472f00110b713a882c8c640e79bbc7f3",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9baa29c8b887cf37751fa2d8ab5cdde244bf5167c9a9ebd022dd0102b2717032",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "f29ef797604984bccb27ac3ca8f76304d026c34ca8ed2d90448fe9f8a8676ad8",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5b9e9eb50559b5a7df45fdb6a78a8f70d9bc3f5961e520cf2c5a789480aabad2",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "6b402007128d1e82aa0eb679e785146fc89031257ac836af8d01464dcc87ad03",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "15de7633dc285ef4d6e01b814bc0a8c6ca8deb861dbdb98130cec3eaafb3554d",
      "byte_length": 4330
    }
  }
}
```
