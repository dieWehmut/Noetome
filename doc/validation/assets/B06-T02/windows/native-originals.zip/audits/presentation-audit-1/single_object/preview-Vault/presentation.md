# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "4ad1e748-230e-4b61-b28f-c72e88f6cffd",
  "project_id": "fd8b009a-e611-4423-abd2-97bd309290ea",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 2,
    "source_occurrences": 3,
    "objects": 1,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 2,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SINGLE_OBJECT_TEXT",
    "reason": "选定事实仅涉及一个对象，以正文保留各属性、条件和原始表述。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "5a4fee95ce1590a470a88f645603e6b7b780a6d5dd1fda2420c7e0f9d00e8f63",
    "byte_length": 60938
  },
  "plan_fingerprint": {
    "sha256": "c73d9b2cce661799f59b1f00326d96a9ba7eb2c24674f1faa85f38dfe6fca9a3",
    "byte_length": 18202
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "5a4fee95ce1590a470a88f645603e6b7b780a6d5dd1fda2420c7e0f9d00e8f63",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "94f37a43c35f3268b85f4c4ed60f7d03eb493494b2e15bb96e7e2da9cf9e8275",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3ec32c69625037153fff3846e4ee717f00b1a2343f0f852078f3f32e63f6ed99",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "55d7eace3ea07fae361df58d9ea9c2c0574295b72e9f952afe9fa6ee17b6503b",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "36e8a8c21a488f9aa801d0d9ecdacdbf923916771c3ea263a8a98e63224bf04f",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "4c6c2c6c0c7378193aa2c32e3e29f9afba0da8c4181041f360b81c37db658e92",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "5b99c1a7d995704c7dfa9c8433a934797e1fbf5119b1bea1e3e83f98ec6e3988",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "12ab7869bcf484fa753335d9e5f70bd4a610d94ce5d4e02899d3484062ef5ac5",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e0a5fd5ca4cca02004946be959310d6fa8662ab6a00a09579ef7415eac8e8efe",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2418b5587c7b8b6938e625a399545c525dba18de62f5f9f1df4a13f0b794b852",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "8c75db82d526938c00e87667b4d4571cc8836220824eacde9c6df91452f89e0e",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "60e9e219b52bdc233f0aff37e0c9019e7d298e5a7e2e4dff568974b5886954aa",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "47b9f5af3819c2c42016f36386c6652fd42ee01f670c657704eb5bfcdb5efe34",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "f6761171c4bf6d7179a9e1b37fe02013bf4158fc381c2289e334a46d69b12fcb",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "4a514ed5362a613076bf9a8d0e95b7a09b73128aee42893524d0c33e251831eb",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "0f33810907a5cacf8cb3b08e8a660cdaef25896d406ff3565d4fee86f5538378",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "6c3faee85881686938c67405103645254a36b18d6d701f582818020ae6459689",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "2459f49055da117fdc8b09e8d27c6dce530c39443942c1bc55f9c43a51ba2073",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "94a53b86007009e5452ea3d79cb21d52f2e49be2fd425685bb00dd0ee831f3e0",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "ed725603016dc6a33302198d540fe01e19b3978d9c21b4837a47dd0f7cf9e837",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-2a8082372467c270320ad3308e08c615c05ce48eff5d427a65ed5dc383742e45"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-27bc14106feb7d08099e130dc6901faeba18e95305f1c64caeb327ea728def7e",
            "occ-c26d218c914f55421fc7c16ea476151d27c98df742733eaa8c37bb3f4699db72"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-2a8082372467c270320ad3308e08c615c05ce48eff5d427a65ed5dc383742e45"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-27bc14106feb7d08099e130dc6901faeba18e95305f1c64caeb327ea728def7e",
            "occ-c26d218c914f55421fc7c16ea476151d27c98df742733eaa8c37bb3f4699db72"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "5a4fee95ce1590a470a88f645603e6b7b780a6d5dd1fda2420c7e0f9d00e8f63",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "94f37a43c35f3268b85f4c4ed60f7d03eb493494b2e15bb96e7e2da9cf9e8275",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3ec32c69625037153fff3846e4ee717f00b1a2343f0f852078f3f32e63f6ed99",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "55d7eace3ea07fae361df58d9ea9c2c0574295b72e9f952afe9fa6ee17b6503b",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "36e8a8c21a488f9aa801d0d9ecdacdbf923916771c3ea263a8a98e63224bf04f",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "4c6c2c6c0c7378193aa2c32e3e29f9afba0da8c4181041f360b81c37db658e92",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "5b99c1a7d995704c7dfa9c8433a934797e1fbf5119b1bea1e3e83f98ec6e3988",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "12ab7869bcf484fa753335d9e5f70bd4a610d94ce5d4e02899d3484062ef5ac5",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e0a5fd5ca4cca02004946be959310d6fa8662ab6a00a09579ef7415eac8e8efe",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2418b5587c7b8b6938e625a399545c525dba18de62f5f9f1df4a13f0b794b852",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "8c75db82d526938c00e87667b4d4571cc8836220824eacde9c6df91452f89e0e",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "60e9e219b52bdc233f0aff37e0c9019e7d298e5a7e2e4dff568974b5886954aa",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "47b9f5af3819c2c42016f36386c6652fd42ee01f670c657704eb5bfcdb5efe34",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "f6761171c4bf6d7179a9e1b37fe02013bf4158fc381c2289e334a46d69b12fcb",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "4a514ed5362a613076bf9a8d0e95b7a09b73128aee42893524d0c33e251831eb",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "0f33810907a5cacf8cb3b08e8a660cdaef25896d406ff3565d4fee86f5538378",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "6c3faee85881686938c67405103645254a36b18d6d701f582818020ae6459689",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "2459f49055da117fdc8b09e8d27c6dce530c39443942c1bc55f9c43a51ba2073",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "94a53b86007009e5452ea3d79cb21d52f2e49be2fd425685bb00dd0ee831f3e0",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "048ba091eafb0e00b6b2a5dd26ef8661d8a278b6afa472b33ab5ff1ef01b5a59",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "ed725603016dc6a33302198d540fe01e19b3978d9c21b4837a47dd0f7cf9e837",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "c73d9b2cce661799f59b1f00326d96a9ba7eb2c24674f1faa85f38dfe6fca9a3",
      "byte_length": 18202
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "知识比较.md": {
      "sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514
    }
  }
}
```
