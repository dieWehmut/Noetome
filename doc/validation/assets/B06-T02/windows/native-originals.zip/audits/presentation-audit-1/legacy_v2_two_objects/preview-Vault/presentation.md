# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "0a0711ae-7909-4b40-9558-3618d88bdd1f",
  "project_id": "b1604ec1-fdb5-4f3f-9f99-05f87de2b6f0",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "d22a750b0af4e9ba16b53635e172d683d7be5f63f9d589464cfdc21478b4ac00",
    "byte_length": 40500
  },
  "plan_fingerprint": {
    "sha256": "48e1ca1bdf621db6d51f4ae5291a75dee9085737bb92352160cc9f5bd0d82f1b",
    "byte_length": 17586
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "d22a750b0af4e9ba16b53635e172d683d7be5f63f9d589464cfdc21478b4ac00",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "2051ab2b832e7a4dbc32f774f36139ddc4246f700f0e36cf9507becbfde84d39",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3c71ca1b728ed821a40da204180feab993d011377393caec8674dfe52581f78b",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "2f05495ea69d99c47ba8f5ff45bed81c3d965a27a0f7c4062d7944a7d3992f1d",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "9f739037833201dab8d54200f1c1a10b8c618c7cb4e70139314130c168ea7806",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "ee75a39f0bc216e813b94f54d2d318dac611a9db2bb8a769674da6cb3c1eb7f1",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "555831a8e78038acc3beb6963f21c5b64afcf83f2ba454b0311042979c7c67a9",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8651fd710b0f44c9e2b572d80b9f68fc7ee05aaaf4f34df1608e016fdc00ded7",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7280286d0aed0159c5e1f2cdd7e1fbc1a455e8f836fa04bc8669b05b94af2d6b",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "8ae5844df8290555e2b7230af5875bd341ef002a60ff20c2bab299a37f751643",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "dadc340bd8ef2bb65a9a41b24f44985ec0e2d5cbf7f58292150b5f322708edce",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "63d1c459f6994273ff9e21e465b75ac45fd2f175a436711f36dcc2285b373691",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "625ca7744a10bf9f3add9ec611fe633c4060ce1e71051b147603619c9c913a37",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "a2b40693a3c8836f3e1879fc7c4292dddfb5994c923097619554bf321c619e53",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "db17fd2f6b0558bb83bb0038a5f5f2a7b9d341d87963351d1bca36f661608772",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6a41ff57479a3655f2e8198391fb65da73505bb6ea0f0bbc95464b4394bc5951",
            "occ-e31ffb6157a5066e159218469135c61bbd7761ef5c496070e9a6819c115c5517"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6a41ff57479a3655f2e8198391fb65da73505bb6ea0f0bbc95464b4394bc5951"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-6a41ff57479a3655f2e8198391fb65da73505bb6ea0f0bbc95464b4394bc5951"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-e31ffb6157a5066e159218469135c61bbd7761ef5c496070e9a6819c115c5517"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-e31ffb6157a5066e159218469135c61bbd7761ef5c496070e9a6819c115c5517"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-6a41ff57479a3655f2e8198391fb65da73505bb6ea0f0bbc95464b4394bc5951"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-e31ffb6157a5066e159218469135c61bbd7761ef5c496070e9a6819c115c5517"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "d22a750b0af4e9ba16b53635e172d683d7be5f63f9d589464cfdc21478b4ac00",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "2051ab2b832e7a4dbc32f774f36139ddc4246f700f0e36cf9507becbfde84d39",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3c71ca1b728ed821a40da204180feab993d011377393caec8674dfe52581f78b",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "2f05495ea69d99c47ba8f5ff45bed81c3d965a27a0f7c4062d7944a7d3992f1d",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "9f739037833201dab8d54200f1c1a10b8c618c7cb4e70139314130c168ea7806",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "ee75a39f0bc216e813b94f54d2d318dac611a9db2bb8a769674da6cb3c1eb7f1",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "555831a8e78038acc3beb6963f21c5b64afcf83f2ba454b0311042979c7c67a9",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8651fd710b0f44c9e2b572d80b9f68fc7ee05aaaf4f34df1608e016fdc00ded7",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7280286d0aed0159c5e1f2cdd7e1fbc1a455e8f836fa04bc8669b05b94af2d6b",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "8ae5844df8290555e2b7230af5875bd341ef002a60ff20c2bab299a37f751643",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "dadc340bd8ef2bb65a9a41b24f44985ec0e2d5cbf7f58292150b5f322708edce",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "63d1c459f6994273ff9e21e465b75ac45fd2f175a436711f36dcc2285b373691",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "625ca7744a10bf9f3add9ec611fe633c4060ce1e71051b147603619c9c913a37",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "a2b40693a3c8836f3e1879fc7c4292dddfb5994c923097619554bf321c619e53",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "11d0ac2b674b1ea4e80ce3cd67db63465e5ce6e490b9d5d28897f126e15c5d82",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "db17fd2f6b0558bb83bb0038a5f5f2a7b9d341d87963351d1bca36f661608772",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "48e1ca1bdf621db6d51f4ae5291a75dee9085737bb92352160cc9f5bd0d82f1b",
      "byte_length": 17586
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542
    }
  }
}
```
