# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "b85910a1-eb1c-40fb-bb47-f444722e3e5f",
  "project_id": "c7242294-a471-4b8a-aaaf-41888bf30666",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "fa85e83c3774d26ab2b7d757c04d0180eaf5bd0b1ec1ddae3618ba2dcd3635de",
    "byte_length": 41320
  },
  "plan_fingerprint": {
    "sha256": "aefc28f3f5570db5aaffb20c4a614f3c362565625da3ee23721a0c917785adb5",
    "byte_length": 17102
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "fa85e83c3774d26ab2b7d757c04d0180eaf5bd0b1ec1ddae3618ba2dcd3635de",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "10516b6b661d1fa6ec36e5f9fddafbe0f383389403c3d01f26aa3578ee04467d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "71b5fa34f7c16f5bb706cca78727ae00e2c30fd394c1f900cc88f45d63d9e7c4",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "6a9a5b7dec175065fa3c291ffcfaf90c4c53c3fb2406bdd399500a5258ca3fe7",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "b8643138d8f1d10e338b3b205c1eef9761cffb47293d42d714fc0cb81a4175e5",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "f900f7960681c631b53f5ca8c190c45f3a4a600179b6f29966e7ff24df7f46e9",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "a53d4d369e3f6f5733507325ec82b58bef94862ccbbdc7be2f96701cbb720882",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "daa6dc10ed1a25d8e9a14f63143c8b245337e947359cc2e9b5d0b1d4f404feba",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "a653e9ca5a5b4ecedcb631a32928680fde10b44ae3ed4b71a9c4defc4b977e58",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "5d0365aeed75e6aa8aea824913ab7768b6d97bd14da7da5565a6744ec4260e46",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "ea01702ebe03e89b45d9773ef098bd60e93d265e94f785c2d129465b2b8e10e7",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "354837b806feaec431104ecc90f5a0e4ea2db5f39894c1008e4003fcbea750f3",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "8f697521b02c04d73f6f7d3d473c5f2900f0699599f29006446a69d7a8379412",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "137455fe86919607a4a65ea47b92a33f012075baa7da2a59f1b4125e15a47866",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "54cbef126d97c8817d1e1db9749eb14ac580dc76fb32a7493b5c84b01600ad33",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "80ac8df889ba88f0d4e5d47616b080a282e820991359ef207574db1b477d0d7f",
      "byte_length": 533,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6a6d8e4e2346b722684a3ea43359763259d00ccb2a9033ccc7a04a6024688f95",
            "occ-8cbb2cc27b803e7c5542ad36dc2c415e0abeb0d0ced2335df0e62e4377fb2dea"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-8cbb2cc27b803e7c5542ad36dc2c415e0abeb0d0ced2335df0e62e4377fb2dea"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-8cbb2cc27b803e7c5542ad36dc2c415e0abeb0d0ced2335df0e62e4377fb2dea"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6a6d8e4e2346b722684a3ea43359763259d00ccb2a9033ccc7a04a6024688f95"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-6a6d8e4e2346b722684a3ea43359763259d00ccb2a9033ccc7a04a6024688f95"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 529
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-8cbb2cc27b803e7c5542ad36dc2c415e0abeb0d0ced2335df0e62e4377fb2dea"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "70e5404516793b6fd7c6923319874891ff869333a792ba0612639251779cb20d",
      "byte_length": 320,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-6a6d8e4e2346b722684a3ea43359763259d00ccb2a9033ccc7a04a6024688f95"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 318
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "fa85e83c3774d26ab2b7d757c04d0180eaf5bd0b1ec1ddae3618ba2dcd3635de",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "10516b6b661d1fa6ec36e5f9fddafbe0f383389403c3d01f26aa3578ee04467d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "71b5fa34f7c16f5bb706cca78727ae00e2c30fd394c1f900cc88f45d63d9e7c4",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "6a9a5b7dec175065fa3c291ffcfaf90c4c53c3fb2406bdd399500a5258ca3fe7",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "b8643138d8f1d10e338b3b205c1eef9761cffb47293d42d714fc0cb81a4175e5",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "f900f7960681c631b53f5ca8c190c45f3a4a600179b6f29966e7ff24df7f46e9",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "a53d4d369e3f6f5733507325ec82b58bef94862ccbbdc7be2f96701cbb720882",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "daa6dc10ed1a25d8e9a14f63143c8b245337e947359cc2e9b5d0b1d4f404feba",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "a653e9ca5a5b4ecedcb631a32928680fde10b44ae3ed4b71a9c4defc4b977e58",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "5d0365aeed75e6aa8aea824913ab7768b6d97bd14da7da5565a6744ec4260e46",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "ea01702ebe03e89b45d9773ef098bd60e93d265e94f785c2d129465b2b8e10e7",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "354837b806feaec431104ecc90f5a0e4ea2db5f39894c1008e4003fcbea750f3",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "8f697521b02c04d73f6f7d3d473c5f2900f0699599f29006446a69d7a8379412",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "137455fe86919607a4a65ea47b92a33f012075baa7da2a59f1b4125e15a47866",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "fb5b5874c08ea9c02529ea003e263a23276287c8ff8d04412c27be70f1bb2601",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "54cbef126d97c8817d1e1db9749eb14ac580dc76fb32a7493b5c84b01600ad33",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "aefc28f3f5570db5aaffb20c4a614f3c362565625da3ee23721a0c917785adb5",
      "byte_length": 17102
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "70e5404516793b6fd7c6923319874891ff869333a792ba0612639251779cb20d",
      "byte_length": 320
    },
    "知识比较.md": {
      "sha256": "80ac8df889ba88f0d4e5d47616b080a282e820991359ef207574db1b477d0d7f",
      "byte_length": 533
    }
  }
}
```
