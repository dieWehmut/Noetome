"""Independent process source/oracle and finite output-reader regressions."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("verify_process_flow", ROOT / "scripts/verify_process_flow.py")
V = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(V)
FIXTURE = ROOT / "fixtures/process-flow-v1"


class ProcessAuthorTests(unittest.TestCase):
    def source(self, name="linear"):
        return (FIXTURE / (name + ".txt")).read_bytes()

    def document(self, name="linear"):
        return V.parse_source(self.source(name))[0]

    def profile(self, name="obsidian_1_6_7_flowchart"):
        return json.loads((FIXTURE / ("profile-" + name + ".json")).read_bytes())

    def test_all_sixteen_frozen_sources_gold_and_expected_independently_agree(self):
        self.assertEqual(len(V.verify_fixture()["cases"]), 16)

    def test_unsigned_changes_cannot_become_new_author_truth(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for file in FIXTURE.iterdir():
                (root / file.name).write_bytes(file.read_bytes())
            changed = json.loads((root / "expected-linear.json").read_bytes())
            changed["nodes"][0]["description"] = "伪造但同步的说明"
            V.save(root / "expected-linear.json", changed)
            with self.assertRaises(AssertionError):
                V.verify_fixture(root)

    def test_json_words_and_punctuation_do_not_change_statement_boundaries(self):
        raw = self.source().decode().replace('"登记卡片"', json.dumps('登记。条件：[x] | "卡片"', ensure_ascii=False), 1).encode()
        doc, unknown, count = V.parse_source(raw)
        self.assertEqual(doc["steps"][0]["label"], '登记。条件：[x] | "卡片"')
        self.assertEqual(unknown, []); self.assertEqual(count, 6)
        for evidence in doc["evidence"]:
            self.assertEqual(raw[evidence["start_byte"]:evidence["end_byte"]].decode(), evidence["quote"])

    def test_multiline_and_tab_are_literal_text_not_extra_source_statements(self):
        doc, unknown, count = V.parse_source(self.source("multiline_labels"))
        self.assertEqual(unknown, []); self.assertEqual(count, len(doc["evidence"]))
        self.assertTrue(any("\n" in s["label"] and "\t" in s["label"] for s in doc["steps"]))
        self.assertEqual(V.classify(doc, self.profile())[0:2], ("ordered_list", ["FLOW_LABEL_WHITESPACE_FALLBACK"]))

    def test_source_order_is_not_execution_order(self):
        raw = self.source("complex_labels")
        doc, unknown, _ = V.parse_source(raw)
        self.assertLess(raw.index(b"s2"), raw.index(b"\ns1") if b"\ns1" in raw else len(raw))
        self.assertEqual([s["id"] for s in doc["steps"]], ["s1", "s2", "s3"])
        self.assertEqual(V.classify(doc, self.profile())[2], ["s1", "s2", "s3"])
        self.assertEqual(unknown, [])

    def test_unknown_tail_and_negation_are_counted_and_not_affirmed(self):
        doc, unknown, count = V.parse_source(self.source("negated_relation"))
        self.assertEqual(len(unknown), 1); self.assertIn("不导致", unknown[0])
        self.assertEqual(doc["relations"], []); self.assertEqual(count, 4)
        _, tail, count = V.parse_source(self.source("unparsed_tail"))
        self.assertEqual(tail, ["补充：另有未描述的人工决定。"]); self.assertEqual(count, 7)

    def test_source_template_suffix_and_extra_blank_line_are_not_ignored(self):
        for raw in (self.source() + b"\n", self.source().rstrip(b"\n") + " 未说明。\n".encode()):
            with self.subTest(raw=raw[-30:]):
                _, unmatched, _ = V.parse_source(raw)
                self.assertEqual(len(unmatched), 1)

    def test_forbidden_control_hidden_markup_and_autolinks_are_rejected(self):
        illegal = ["\r", "\x00", "\x7f", "\x85", "%%hidden", "[[wikilink]]", "![x]",
                   "<b>x", "<123@example>", "[x] (url)", "[x]\t[label]", "[x]:url"]
        for value in illegal:
            raw = self.source().decode().replace('"登记卡片"', json.dumps("标题" + value), 1).encode()
            with self.subTest(value=repr(value)), self.assertRaises(AssertionError):
                V.parse_source(raw)

    def test_strict_gold_fields_types_and_nullable_values(self):
        gold = json.loads((FIXTURE / "gold-linear.json").read_bytes())
        mutations = [("schema_version", True), ("published", False), ("scientific_quality", "passed")]
        for key, value in mutations:
            changed = copy.deepcopy(gold); changed[key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                V.gold_document(changed)
        for key in ("criterion", "exceptions", "inputs"):
            changed = copy.deepcopy(gold); del changed["steps"][0][key]
            with self.subTest(missing=key), self.assertRaises(AssertionError):
                V.gold_document(changed)

    def test_gold_requires_one_nonoverlapping_byte_evidence_per_object(self):
        for mutation in (lambda d: d["evidence"].pop(),
                         lambda d: d["evidence"][1].update(start_byte=1),
                         lambda d: d["evidence"][1].update(object_id="process")):
            doc = self.document(); mutation(doc)
            with self.assertRaises(AssertionError):
                V.document_schema(doc)

    def test_semantic_blockers_are_not_compatibility_fallback(self):
        cases = {"correlation":"FLOW_CORRELATION_UNDIRECTED", "direction_unknown":"FLOW_DIRECTION_UNKNOWN",
            "missing_branch":"FLOW_DECISION_INCOMPLETE", "cycle":"FLOW_UNSUPPORTED_CYCLE",
            "missing_connection":"FLOW_DISCONNECTED", "unknown_criterion":"FLOW_UNKNOWN_CRITERION"}
        for name, issue in cases.items():
            for profile in (self.profile(), self.profile("unverified_flowchart")):
                with self.subTest(name=name, profile=profile["profile_id"]):
                    self.assertEqual(V.classify(self.document(name), profile), (None, [issue], []))

    def test_effect_types_direction_and_conditions_are_all_author_semantics(self):
        for name, category, key, changed_value in [
            ("linear", "relations", "left", "s2"), ("causes", "relations", "kind", "promotes"),
            ("inhibits", "relations", "kind", "causes"), ("branch", "relations", "branch_outcome", False),
            ("linear", "steps", "conditions", []), ("linear", "relations", "exceptions", []),
            ("linear", "steps", "outputs", ["未知"]), ("linear", "steps", "description", "已丢原说明")]:
            doc = self.document(name)
            target = next((r for r in doc[category] if r.get("kind") == "branch"), doc[category][0])
            target[key] = changed_value
            expected = json.loads((FIXTURE / ("expected-" + name + ".json")).read_bytes())
            with self.subTest(name=name, key=key), self.assertRaises(AssertionError):
                V.verify_expectation(expected, doc, [], len(doc["evidence"]), self.profile())


if __name__ == "__main__":
    unittest.main()
