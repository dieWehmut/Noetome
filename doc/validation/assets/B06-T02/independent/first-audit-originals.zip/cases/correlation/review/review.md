# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "f8d5803b-3a60-48a0-b6bd-35a0ba699b2f",
  "binding": {
    "project_id": "293a160f-e8c6-4f88-9b5b-ec8db92b3284",
    "import_id": "5dfa2d03-54d4-47b5-97f9-240051b5309a",
    "source_id": "8b405670-ece5-435e-959e-0fa6da20ea1a",
    "version_id": "d2e08a65-312e-4dd4-85a8-375cf081e59e",
    "content_sha256": "605b5e749cf18dfae20b4af47e75eb3b035ea10596b991cbc7ccb7c6424b9e42",
    "normalized_sha256": "605b5e749cf18dfae20b4af47e75eb3b035ea10596b991cbc7ccb7c6424b9e42",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "演示计数共同变化观察",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "按钮点击计数",
        "description": "记录同一时段的按钮点击次数",
        "criterion": null,
        "inputs": [
          "按钮点击记录"
        ],
        "outputs": [
          "点击计数"
        ],
        "conditions": [
          "记录时段相同"
        ],
        "exceptions": [
          "缺少记录时标为未知"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "指示灯闪烁计数",
        "description": "记录同一时段的指示灯闪烁次数",
        "criterion": null,
        "inputs": [
          "闪烁记录"
        ],
        "outputs": [
          "闪烁计数"
        ],
        "conditions": [
          "记录时段相同"
        ],
        "exceptions": [
          "缺少记录时标为未知"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "correlates",
        "branch_outcome": null,
        "conditions": [
          "仅限本次演示记录"
        ],
        "exceptions": [
          "未建立因果方向"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 150,
        "quote": "过程：\"演示计数共同变化观察\"。入口：s1。目标：[\"s2\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 607,
        "end_byte": 715,
        "quote": "关系 r1：s1 与 s2 相关。条件：[\"仅限本次演示记录\"]。例外：[\"未建立因果方向\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 151,
        "end_byte": 378,
        "quote": "步骤 s1：\"按钮点击计数\"。说明：\"记录同一时段的按钮点击次数\"。输入：[\"按钮点击记录\"]。输出：[\"点击计数\"]。条件：[\"记录时段相同\"]。例外：[\"缺少记录时标为未知\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 379,
        "end_byte": 606,
        "quote": "步骤 s2：\"指示灯闪烁计数\"。说明：\"记录同一时段的指示灯闪烁次数\"。输入：[\"闪烁记录\"]。输出：[\"闪烁计数\"]。条件：[\"记录时段相同\"]。例外：[\"缺少记录时标为未知\"]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 1,
    "decision_steps": 0,
    "evidence_records": 4,
    "inhibits_relations": 0,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 1,
    "decision_steps": 0,
    "evidence_records": 4,
    "inhibits_relations": 0,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
  "ir_fingerprint": {
    "sha256": "f939bd73d552042b6406b89f7c78e2c9f9b9c87c59ee998784a480860feddb7c",
    "byte_length": 5187
  },
  "inputs": {
    ".case.json": {
      "sha256": "0a42ec06d78de14a98b7006d240b5ec1038d36742f67c6524249af119093edf7",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
      "byte_length": 2697
    },
    ".source.json": {
      "sha256": "ca3f81015be9cfd72feed0440d3374ac8d4fdfb886e5dabdbed6d70684053869",
      "byte_length": 1644
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "0a42ec06d78de14a98b7006d240b5ec1038d36742f67c6524249af119093edf7",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
      "byte_length": 2697
    },
    ".owner.json": {
      "sha256": "d92d0713b5632f1c2a3b5d7d3e626f9a27e7b3e775269bb31763db000b39811a",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "ca3f81015be9cfd72feed0440d3374ac8d4fdfb886e5dabdbed6d70684053869",
      "byte_length": 1644
    },
    "process-ir.json": {
      "sha256": "f939bd73d552042b6406b89f7c78e2c9f9b9c87c59ee998784a480860feddb7c",
      "byte_length": 5187
    }
  }
}
```
