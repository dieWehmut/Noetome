# 有据流程表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "55f6c1a2-d28b-4f9a-bb4d-0708278c8b22",
  "binding": {
    "project_id": "293a160f-e8c6-4f88-9b5b-ec8db92b3284",
    "import_id": "5dfa2d03-54d4-47b5-97f9-240051b5309a",
    "source_id": "8b405670-ece5-435e-959e-0fa6da20ea1a",
    "version_id": "d2e08a65-312e-4dd4-85a8-375cf081e59e",
    "content_sha256": "605b5e749cf18dfae20b4af47e75eb3b035ea10596b991cbc7ccb7c6424b9e42",
    "normalized_sha256": "605b5e749cf18dfae20b4af47e75eb3b035ea10596b991cbc7ccb7c6424b9e42",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_CORRELATION_UNDIRECTED"
  ],
  "issues": [
    {
      "code": "FLOW_CORRELATION_UNDIRECTED",
      "object_ids": [
        "r1"
      ],
      "message": "来源只说明相关性，不能推定执行或因果方向。"
    }
  ],
  "process_document": {
    "process": {
      "title": "演示计数共同变化观察",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "按钮点击计数",
        "description": "记录同一时段的按钮点击次数",
        "criterion": null,
        "inputs": [
          "按钮点击记录"
        ],
        "outputs": [
          "点击计数"
        ],
        "conditions": [
          "记录时段相同"
        ],
        "exceptions": [
          "缺少记录时标为未知"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "指示灯闪烁计数",
        "description": "记录同一时段的指示灯闪烁次数",
        "criterion": null,
        "inputs": [
          "闪烁记录"
        ],
        "outputs": [
          "闪烁计数"
        ],
        "conditions": [
          "记录时段相同"
        ],
        "exceptions": [
          "缺少记录时标为未知"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "correlates",
        "branch_outcome": null,
        "conditions": [
          "仅限本次演示记录"
        ],
        "exceptions": [
          "未建立因果方向"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 150,
        "quote": "过程：\"演示计数共同变化观察\"。入口：s1。目标：[\"s2\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 607,
        "end_byte": 715,
        "quote": "关系 r1：s1 与 s2 相关。条件：[\"仅限本次演示记录\"]。例外：[\"未建立因果方向\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 151,
        "end_byte": 378,
        "quote": "步骤 s1：\"按钮点击计数\"。说明：\"记录同一时段的按钮点击次数\"。输入：[\"按钮点击记录\"]。输出：[\"点击计数\"]。条件：[\"记录时段相同\"]。例外：[\"缺少记录时标为未知\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 379,
        "end_byte": 606,
        "quote": "步骤 s2：\"指示灯闪烁计数\"。说明：\"记录同一时段的指示灯闪烁次数\"。输入：[\"闪烁记录\"]。输出：[\"闪烁计数\"]。条件：[\"记录时段相同\"]。例外：[\"缺少记录时标为未知\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": null,
  "decision": null,
  "review_ir_fingerprint": {
    "sha256": "f939bd73d552042b6406b89f7c78e2c9f9b9c87c59ee998784a480860feddb7c",
    "byte_length": 5187
  },
  "plan_fingerprint": null,
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 0,
    "correlates_relations": 1,
    "decision_steps": 0,
    "evidence_records": 4,
    "flow_edges": 0,
    "flow_nodes": 0,
    "inhibits_relations": 0,
    "links": 0,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "rendered_notes": 0,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "0a42ec06d78de14a98b7006d240b5ec1038d36742f67c6524249af119093edf7",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
      "byte_length": 2697
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "0a42ec06d78de14a98b7006d240b5ec1038d36742f67c6524249af119093edf7",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
      "byte_length": 2697
    },
    ".review-.owner.json": {
      "sha256": "d92d0713b5632f1c2a3b5d7d3e626f9a27e7b3e775269bb31763db000b39811a",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "ca3f81015be9cfd72feed0440d3374ac8d4fdfb886e5dabdbed6d70684053869",
      "byte_length": 1644
    },
    ".review-process-ir.json": {
      "sha256": "f939bd73d552042b6406b89f7c78e2c9f9b9c87c59ee998784a480860feddb7c",
      "byte_length": 5187
    },
    ".review-review.json": {
      "sha256": "54d54424b6b510a55a25825fa57afa8b7a2041149adae75c123ea5864df85bdf",
      "byte_length": 6405
    },
    ".review-review.md": {
      "sha256": "29597135086327444b4e4ca05706b73b245be4d7acad19f3725e9044da3678a0",
      "byte_length": 6588
    },
    ".source.json": {
      "sha256": "ca3f81015be9cfd72feed0440d3374ac8d4fdfb886e5dabdbed6d70684053869",
      "byte_length": 1644
    }
  },
  "files": [],
  "artifacts": {
    ".case.json": {
      "sha256": "0a42ec06d78de14a98b7006d240b5ec1038d36742f67c6524249af119093edf7",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
      "byte_length": 2697
    },
    ".owner.json": {
      "sha256": "5bac0788ac209dbe07634b7b6ec93c0ec995e01db6bca9b18e7e19c6c3ede5ba",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "0a42ec06d78de14a98b7006d240b5ec1038d36742f67c6524249af119093edf7",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "45805ea950c5a3363b65ad3cf79e6e5488710b255fa321f863701afa1018a3e9",
      "byte_length": 2697
    },
    ".review-.owner.json": {
      "sha256": "d92d0713b5632f1c2a3b5d7d3e626f9a27e7b3e775269bb31763db000b39811a",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "ca3f81015be9cfd72feed0440d3374ac8d4fdfb886e5dabdbed6d70684053869",
      "byte_length": 1644
    },
    ".review-process-ir.json": {
      "sha256": "f939bd73d552042b6406b89f7c78e2c9f9b9c87c59ee998784a480860feddb7c",
      "byte_length": 5187
    },
    ".review-review.json": {
      "sha256": "54d54424b6b510a55a25825fa57afa8b7a2041149adae75c123ea5864df85bdf",
      "byte_length": 6405
    },
    ".review-review.md": {
      "sha256": "29597135086327444b4e4ca05706b73b245be4d7acad19f3725e9044da3678a0",
      "byte_length": 6588
    },
    ".source.json": {
      "sha256": "ca3f81015be9cfd72feed0440d3374ac8d4fdfb886e5dabdbed6d70684053869",
      "byte_length": 1644
    }
  }
}
```
