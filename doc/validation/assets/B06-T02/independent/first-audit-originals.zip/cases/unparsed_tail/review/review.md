# 有界过程来源核对

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "8711e4a3-930e-4fe2-b72c-607e80a9ab3f",
  "binding": {
    "project_id": "01389b6a-542a-41f9-a40c-447439a5f157",
    "import_id": "d9ff35bd-24ff-4599-9294-55ac7523e50a",
    "source_id": "7e51cd74-8ba8-4907-acf7-9589b866c051",
    "version_id": "2ebd0ea1-a843-4402-8739-ae975a95aea4",
    "content_sha256": "e35f7250f900bf3da5f4af2118671ebe533fe58edd5493a0827fb599827a4978",
    "normalized_sha256": "e35f7250f900bf3da5f4af2118671ebe533fe58edd5493a0827fb599827a4978",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "needs_review",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "needs_review",
    "gold_match": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "PROCESS_UNPARSED_TEXT"
  ],
  "unparsed_statements": 1,
  "parsed_document": null,
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 2,
    "source_statements": 7,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 1
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 2,
    "source_statements": 7,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 1
  },
  "gold_sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
  "ir_fingerprint": null,
  "inputs": {
    ".case.json": {
      "sha256": "2ca6b5fb8a4ab5b6efc0a0778883335a344f0ec8d59fd75afea4b58a0eb6ea7a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".source.json": {
      "sha256": "ee32656754b2c970918c106d4d3daece403e1722db4b224cee30182990c798c6",
      "byte_length": 1982
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "2ca6b5fb8a4ab5b6efc0a0778883335a344f0ec8d59fd75afea4b58a0eb6ea7a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".owner.json": {
      "sha256": "1aa717ceda303970d29ce73fecf7127d4a28db5db90e8d49e4727d96d02c7e38",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "ee32656754b2c970918c106d4d3daece403e1722db4b224cee30182990c798c6",
      "byte_length": 1982
    }
  }
}
```
