# 有据流程表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "b0855415-6650-48ab-ba32-6742fabfbd6c",
  "binding": {
    "project_id": "01389b6a-542a-41f9-a40c-447439a5f157",
    "import_id": "d9ff35bd-24ff-4599-9294-55ac7523e50a",
    "source_id": "7e51cd74-8ba8-4907-acf7-9589b866c051",
    "version_id": "2ebd0ea1-a843-4402-8739-ae975a95aea4",
    "content_sha256": "e35f7250f900bf3da5f4af2118671ebe533fe58edd5493a0827fb599827a4978",
    "normalized_sha256": "e35f7250f900bf3da5f4af2118671ebe533fe58edd5493a0827fb599827a4978",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "needs_review",
    "model_support": "not_run",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_SOURCE_UNVERIFIED"
  ],
  "issues": [
    {
      "code": "FLOW_SOURCE_UNVERIFIED",
      "object_ids": [],
      "message": "过程来源核对尚未通过，未运行流程规划。"
    }
  ],
  "process_document": null,
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": null,
  "decision": null,
  "review_ir_fingerprint": null,
  "plan_fingerprint": null,
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "flow_edges": 0,
    "flow_nodes": 0,
    "inhibits_relations": 0,
    "links": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "rendered_notes": 0,
    "sequence_relations": 2,
    "source_statements": 7,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 1
  },
  "inputs": {
    ".case.json": {
      "sha256": "2ca6b5fb8a4ab5b6efc0a0778883335a344f0ec8d59fd75afea4b58a0eb6ea7a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "2ca6b5fb8a4ab5b6efc0a0778883335a344f0ec8d59fd75afea4b58a0eb6ea7a",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".review-.owner.json": {
      "sha256": "1aa717ceda303970d29ce73fecf7127d4a28db5db90e8d49e4727d96d02c7e38",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "ee32656754b2c970918c106d4d3daece403e1722db4b224cee30182990c798c6",
      "byte_length": 1982
    },
    ".review-review.json": {
      "sha256": "3bb79fe088c99c39b9e6ee046752367f78c40be7b9cdc26bf8926176d2a343b1",
      "byte_length": 3469
    },
    ".review-review.md": {
      "sha256": "13af9f582b13ddd9eb6227c604fd31579817a021636105cae46a486dbdfcd560",
      "byte_length": 3658
    },
    ".source.json": {
      "sha256": "ee32656754b2c970918c106d4d3daece403e1722db4b224cee30182990c798c6",
      "byte_length": 1982
    }
  },
  "files": [],
  "artifacts": {
    ".case.json": {
      "sha256": "2ca6b5fb8a4ab5b6efc0a0778883335a344f0ec8d59fd75afea4b58a0eb6ea7a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".owner.json": {
      "sha256": "3963d7e903cd2bd7825fd655f01047b11da1ad76292d3a38c54af9726ebf135c",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "2ca6b5fb8a4ab5b6efc0a0778883335a344f0ec8d59fd75afea4b58a0eb6ea7a",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".review-.owner.json": {
      "sha256": "1aa717ceda303970d29ce73fecf7127d4a28db5db90e8d49e4727d96d02c7e38",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "ee32656754b2c970918c106d4d3daece403e1722db4b224cee30182990c798c6",
      "byte_length": 1982
    },
    ".review-review.json": {
      "sha256": "3bb79fe088c99c39b9e6ee046752367f78c40be7b9cdc26bf8926176d2a343b1",
      "byte_length": 3469
    },
    ".review-review.md": {
      "sha256": "13af9f582b13ddd9eb6227c604fd31579817a021636105cae46a486dbdfcd560",
      "byte_length": 3658
    },
    ".source.json": {
      "sha256": "ee32656754b2c970918c106d4d3daece403e1722db4b224cee30182990c798c6",
      "byte_length": 1982
    }
  }
}
```
