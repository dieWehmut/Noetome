# 有据流程表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "fa511dbe-310c-4be0-89ad-5a7d3692c3b5",
  "binding": {
    "project_id": "e16da084-3bcb-4df5-aa83-a0b20c676de7",
    "import_id": "02b42e64-0235-4ee9-8129-e8dd3c25c958",
    "source_id": "2f8bf75f-1e2e-4d44-aa1b-b53a960539bf",
    "version_id": "0de741d2-146e-4c52-9a4e-6af951b8ae09",
    "content_sha256": "44aedea9105702e683ca7372af060b9df57921450ff29fbcb9ce3bf5593c60ff",
    "normalized_sha256": "44aedea9105702e683ca7372af060b9df57921450ff29fbcb9ce3bf5593c60ff",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "needs_review",
    "model_support": "not_run",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_SOURCE_UNVERIFIED"
  ],
  "issues": [
    {
      "code": "FLOW_SOURCE_UNVERIFIED",
      "object_ids": [],
      "message": "过程来源核对尚未通过，未运行流程规划。"
    }
  ],
  "process_document": null,
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": null,
  "decision": null,
  "review_ir_fingerprint": null,
  "plan_fingerprint": null,
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 3,
    "flow_edges": 0,
    "flow_nodes": 0,
    "inhibits_relations": 0,
    "links": 0,
    "node_conditions": 2,
    "node_exceptions": 0,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 3,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 0,
    "rendered_notes": 0,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 1
  },
  "inputs": {
    ".case.json": {
      "sha256": "51fd0f6a6e4916ba2bba4d4e2dd467ba25e1624a0edebbbdb70fec8355eee96b",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
      "byte_length": 1957
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "51fd0f6a6e4916ba2bba4d4e2dd467ba25e1624a0edebbbdb70fec8355eee96b",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
      "byte_length": 1957
    },
    ".review-.owner.json": {
      "sha256": "9d3a2d9a27a7ad74cbd135466d9416774a6b48a0c22638527ced99df6cc01e5e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "64e759072c388e59e8e9e1ee12bf8a062ee7cdeb218ff96fbca44bdd0b0dbdf8",
      "byte_length": 1494
    },
    ".review-review.json": {
      "sha256": "8568d5960965b3fb45265ab1e0991c3f65148dd050f6a03935d7d816f0c94260",
      "byte_length": 3469
    },
    ".review-review.md": {
      "sha256": "e24a03edf70c81b2c8ae8b1d2801bcd7cc75f3791529ea693cf4dbce19423cfc",
      "byte_length": 3658
    },
    ".source.json": {
      "sha256": "64e759072c388e59e8e9e1ee12bf8a062ee7cdeb218ff96fbca44bdd0b0dbdf8",
      "byte_length": 1494
    }
  },
  "files": [],
  "artifacts": {
    ".case.json": {
      "sha256": "51fd0f6a6e4916ba2bba4d4e2dd467ba25e1624a0edebbbdb70fec8355eee96b",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
      "byte_length": 1957
    },
    ".owner.json": {
      "sha256": "c75bf911d316af16f328baa1d0c8c444dfc943db1730ba3ae1db9c2365081dce",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "51fd0f6a6e4916ba2bba4d4e2dd467ba25e1624a0edebbbdb70fec8355eee96b",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
      "byte_length": 1957
    },
    ".review-.owner.json": {
      "sha256": "9d3a2d9a27a7ad74cbd135466d9416774a6b48a0c22638527ced99df6cc01e5e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "64e759072c388e59e8e9e1ee12bf8a062ee7cdeb218ff96fbca44bdd0b0dbdf8",
      "byte_length": 1494
    },
    ".review-review.json": {
      "sha256": "8568d5960965b3fb45265ab1e0991c3f65148dd050f6a03935d7d816f0c94260",
      "byte_length": 3469
    },
    ".review-review.md": {
      "sha256": "e24a03edf70c81b2c8ae8b1d2801bcd7cc75f3791529ea693cf4dbce19423cfc",
      "byte_length": 3658
    },
    ".source.json": {
      "sha256": "64e759072c388e59e8e9e1ee12bf8a062ee7cdeb218ff96fbca44bdd0b0dbdf8",
      "byte_length": 1494
    }
  }
}
```
