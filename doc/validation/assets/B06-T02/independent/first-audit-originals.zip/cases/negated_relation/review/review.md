# 有界过程来源核对

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "f21ace76-f891-4a6c-aff1-592722338405",
  "binding": {
    "project_id": "e16da084-3bcb-4df5-aa83-a0b20c676de7",
    "import_id": "02b42e64-0235-4ee9-8129-e8dd3c25c958",
    "source_id": "2f8bf75f-1e2e-4d44-aa1b-b53a960539bf",
    "version_id": "0de741d2-146e-4c52-9a4e-6af951b8ae09",
    "content_sha256": "44aedea9105702e683ca7372af060b9df57921450ff29fbcb9ce3bf5593c60ff",
    "normalized_sha256": "44aedea9105702e683ca7372af060b9df57921450ff29fbcb9ce3bf5593c60ff",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "needs_review",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "needs_review",
    "gold_match": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "PROCESS_UNPARSED_TEXT"
  ],
  "unparsed_statements": 1,
  "parsed_document": null,
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 3,
    "inhibits_relations": 0,
    "node_conditions": 2,
    "node_exceptions": 0,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 3,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 0,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 1
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 3,
    "inhibits_relations": 0,
    "node_conditions": 2,
    "node_exceptions": 0,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 3,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 0,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 1
  },
  "gold_sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
  "ir_fingerprint": null,
  "inputs": {
    ".case.json": {
      "sha256": "51fd0f6a6e4916ba2bba4d4e2dd467ba25e1624a0edebbbdb70fec8355eee96b",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
      "byte_length": 1957
    },
    ".source.json": {
      "sha256": "64e759072c388e59e8e9e1ee12bf8a062ee7cdeb218ff96fbca44bdd0b0dbdf8",
      "byte_length": 1494
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "51fd0f6a6e4916ba2bba4d4e2dd467ba25e1624a0edebbbdb70fec8355eee96b",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "825c28a4fd708e16f326b518eefc18906def70b982e30947563cde3683120d2c",
      "byte_length": 1957
    },
    ".owner.json": {
      "sha256": "9d3a2d9a27a7ad74cbd135466d9416774a6b48a0c22638527ced99df6cc01e5e",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "64e759072c388e59e8e9e1ee12bf8a062ee7cdeb218ff96fbca44bdd0b0dbdf8",
      "byte_length": 1494
    }
  }
}
```
