# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "fbb2a803-0e11-4d55-b087-3618d169c651",
  "binding": {
    "project_id": "677ce974-8cf9-47e3-a67e-2c6b6ed36a0e",
    "import_id": "ce0fb2c0-0550-406c-9266-91edf8c43703",
    "source_id": "d0e19e77-f003-4599-903a-d37a5415363f",
    "version_id": "dcf87672-6154-42b1-becd-b9701a285734",
    "content_sha256": "757ed13a2c164a044c8794e8d6a9eadc0be5b4a1b9f93ce538d6802f322f1d1f",
    "normalized_sha256": "757ed13a2c164a044c8794e8d6a9eadc0be5b4a1b9f93ce538d6802f322f1d1f",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "演示信号关系待核对",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "信号 A",
        "description": "表示演示信号 A",
        "criterion": null,
        "inputs": [
          "A 的记录"
        ],
        "outputs": [
          "A 的状态"
        ],
        "conditions": [
          "记录可读"
        ],
        "exceptions": [
          "记录缺失时未知"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "信号 B",
        "description": "表示演示信号 B",
        "criterion": null,
        "inputs": [
          "B 的记录"
        ],
        "outputs": [
          "B 的状态"
        ],
        "conditions": [
          "记录可读"
        ],
        "exceptions": [
          "记录缺失时未知"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "unknown",
        "branch_outcome": null,
        "conditions": [
          "仅知两者存在关系"
        ],
        "exceptions": [
          "不能据名称顺序补方向"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 147,
        "quote": "过程：\"演示信号关系待核对\"。入口：s1。目标：[\"s2\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 506,
        "end_byte": 635,
        "quote": "关系 r1：s1 与 s2 的方向未说明。条件：[\"仅知两者存在关系\"]。例外：[\"不能据名称顺序补方向\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 148,
        "end_byte": 326,
        "quote": "步骤 s1：\"信号 A\"。说明：\"表示演示信号 A\"。输入：[\"A 的记录\"]。输出：[\"A 的状态\"]。条件：[\"记录可读\"]。例外：[\"记录缺失时未知\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 327,
        "end_byte": 505,
        "quote": "步骤 s2：\"信号 B\"。说明：\"表示演示信号 B\"。输入：[\"B 的记录\"]。输出：[\"B 的状态\"]。条件：[\"记录可读\"]。例外：[\"记录缺失时未知\"]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "inhibits_relations": 0,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 1,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "inhibits_relations": 0,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 1,
    "unparsed_statements": 0
  },
  "gold_sha256": "f1884079d6ab220bf0a0b303cc84fcc330a0e8f290330205e5a6dd2da4ed252f",
  "ir_fingerprint": {
    "sha256": "d9f233ea3dd992823001c9c0594a4e3d7fdc57faad69006bae97cff4e3b86866",
    "byte_length": 4932
  },
  "inputs": {
    ".case.json": {
      "sha256": "63844df77792cf79eab9c1ed1788331ae4f6e30a283c9354275772953cb58c7b",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "f1884079d6ab220bf0a0b303cc84fcc330a0e8f290330205e5a6dd2da4ed252f",
      "byte_length": 2522
    },
    ".source.json": {
      "sha256": "2d982dc232ba674eccf07ee605401ea7a3c2804156a07ee9077b604bc3393b04",
      "byte_length": 1564
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "63844df77792cf79eab9c1ed1788331ae4f6e30a283c9354275772953cb58c7b",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "f1884079d6ab220bf0a0b303cc84fcc330a0e8f290330205e5a6dd2da4ed252f",
      "byte_length": 2522
    },
    ".owner.json": {
      "sha256": "108bf74119ff8bc3850a80c54c15ec109aa55f1d40a0b0ada9c089f3baef1db9",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "2d982dc232ba674eccf07ee605401ea7a3c2804156a07ee9077b604bc3393b04",
      "byte_length": 1564
    },
    "process-ir.json": {
      "sha256": "d9f233ea3dd992823001c9c0594a4e3d7fdc57faad69006bae97cff4e3b86866",
      "byte_length": 4932
    }
  }
}
```
