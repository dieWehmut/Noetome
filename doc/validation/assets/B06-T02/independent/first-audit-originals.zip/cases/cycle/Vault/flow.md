# 有据流程表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "e69eff4b-2459-4b5f-b623-6ba8afce5c42",
  "binding": {
    "project_id": "fce357a1-187f-4fd5-a0f9-fcbb3150c260",
    "import_id": "69aa1387-85e4-488f-9371-c8b340d5db88",
    "source_id": "7732bd68-b4bc-4988-8d95-5423203aa2ed",
    "version_id": "cc2eed46-99d6-4482-a316-7aaa2f1d036e",
    "content_sha256": "324cc2986b7d4c734275e359517fa32f331d50d7fc7fcfaa33c17b92b515e286",
    "normalized_sha256": "324cc2986b7d4c734275e359517fa32f331d50d7fc7fcfaa33c17b92b515e286",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_UNSUPPORTED_CYCLE"
  ],
  "issues": [
    {
      "code": "FLOW_UNSUPPORTED_CYCLE",
      "object_ids": [
        "s1",
        "s2",
        "s3"
      ],
      "message": "来源关系含有循环，本版流程模型未支持循环表达。"
    }
  ],
  "process_document": {
    "process": {
      "title": "循环复核演示",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "登记待复核项",
        "description": "登记本轮待复核项",
        "criterion": null,
        "inputs": [
          "待复核项"
        ],
        "outputs": [
          "登记项"
        ],
        "conditions": [
          "条目可读"
        ],
        "exceptions": [
          "条目缺失时暂停"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "复核登记项",
        "description": "按演示规则复核登记项",
        "criterion": null,
        "inputs": [
          "登记项"
        ],
        "outputs": [
          "复核结果"
        ],
        "conditions": [
          "登记完成"
        ],
        "exceptions": [
          "依据不足时暂停"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "重置为待复核",
        "description": "将结果重新置为待复核并进入下一轮",
        "criterion": null,
        "inputs": [
          "复核结果"
        ],
        "outputs": [
          "待复核项"
        ],
        "conditions": [
          "演示循环开启"
        ],
        "exceptions": [
          "循环开关关闭时停止"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "登记完成"
        ],
        "exceptions": []
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "复核完成"
        ],
        "exceptions": []
      },
      {
        "id": "r3",
        "left": "s3",
        "right": "s1",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "演示循环开启"
        ],
        "exceptions": [
          "循环开关关闭时停止"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 138,
        "quote": "过程：\"循环复核演示\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 757,
        "end_byte": 835,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[\"登记完成\"]。例外：[]。"
      },
      {
        "object_id": "r2",
        "start_byte": 836,
        "end_byte": 914,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"复核完成\"]。例外：[]。"
      },
      {
        "object_id": "r3",
        "start_byte": 915,
        "end_byte": 1028,
        "quote": "关系 r3：s3 完成后执行 s1。条件：[\"演示循环开启\"]。例外：[\"循环开关关闭时停止\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 139,
        "end_byte": 330,
        "quote": "步骤 s1：\"登记待复核项\"。说明：\"登记本轮待复核项\"。输入：[\"待复核项\"]。输出：[\"登记项\"]。条件：[\"条目可读\"]。例外：[\"条目缺失时暂停\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 331,
        "end_byte": 525,
        "quote": "步骤 s2：\"复核登记项\"。说明：\"按演示规则复核登记项\"。输入：[\"登记项\"]。输出：[\"复核结果\"]。条件：[\"登记完成\"]。例外：[\"依据不足时暂停\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 526,
        "end_byte": 756,
        "quote": "步骤 s3：\"重置为待复核\"。说明：\"将结果重新置为待复核并进入下一轮\"。输入：[\"复核结果\"]。输出：[\"待复核项\"]。条件：[\"演示循环开启\"]。例外：[\"循环开关关闭时停止\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": null,
  "decision": null,
  "review_ir_fingerprint": {
    "sha256": "0dbc9067a76c5651566422adfda68f03c7e5b2888c1865a17dc934b28d7e933d",
    "byte_length": 7403
  },
  "plan_fingerprint": null,
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 7,
    "flow_edges": 0,
    "flow_nodes": 0,
    "inhibits_relations": 0,
    "links": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 7,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 3,
    "relation_exceptions": 1,
    "relations": 3,
    "rendered_notes": 0,
    "sequence_relations": 3,
    "source_statements": 7,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "221a5f64dd9d19781cecd57761911cf85b34b4e3e5272b8c37fffb7bb95c0e4a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "75c855c1ae1da4436333c1b43a74408131a74d6401e348221e11f4ae902fb630",
      "byte_length": 4080
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "221a5f64dd9d19781cecd57761911cf85b34b4e3e5272b8c37fffb7bb95c0e4a",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "75c855c1ae1da4436333c1b43a74408131a74d6401e348221e11f4ae902fb630",
      "byte_length": 4080
    },
    ".review-.owner.json": {
      "sha256": "97d14150d1e1b37b14ccacb3b46a7f6df22ed227591b606971b00679c32913cf",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "570681afa765457469d3640a37c33101ca97046d35af7bef0e5dd7595c27d122",
      "byte_length": 1977
    },
    ".review-process-ir.json": {
      "sha256": "0dbc9067a76c5651566422adfda68f03c7e5b2888c1865a17dc934b28d7e933d",
      "byte_length": 7403
    },
    ".review-review.json": {
      "sha256": "bf92a208359fdc129dfd266a78a919c199b6a258a5f004046534a789f694ec37",
      "byte_length": 7906
    },
    ".review-review.md": {
      "sha256": "55ccf2115050e52099eff8945fc2f5180db25e7caab55f51c9cdae767748962c",
      "byte_length": 8089
    },
    ".source.json": {
      "sha256": "570681afa765457469d3640a37c33101ca97046d35af7bef0e5dd7595c27d122",
      "byte_length": 1977
    }
  },
  "files": [],
  "artifacts": {
    ".case.json": {
      "sha256": "221a5f64dd9d19781cecd57761911cf85b34b4e3e5272b8c37fffb7bb95c0e4a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "75c855c1ae1da4436333c1b43a74408131a74d6401e348221e11f4ae902fb630",
      "byte_length": 4080
    },
    ".owner.json": {
      "sha256": "efe7d2ad7b22a07e37ba8e7b1dc4884f1388fb1acccb57fc2a948dcee0456abc",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "221a5f64dd9d19781cecd57761911cf85b34b4e3e5272b8c37fffb7bb95c0e4a",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "75c855c1ae1da4436333c1b43a74408131a74d6401e348221e11f4ae902fb630",
      "byte_length": 4080
    },
    ".review-.owner.json": {
      "sha256": "97d14150d1e1b37b14ccacb3b46a7f6df22ed227591b606971b00679c32913cf",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "570681afa765457469d3640a37c33101ca97046d35af7bef0e5dd7595c27d122",
      "byte_length": 1977
    },
    ".review-process-ir.json": {
      "sha256": "0dbc9067a76c5651566422adfda68f03c7e5b2888c1865a17dc934b28d7e933d",
      "byte_length": 7403
    },
    ".review-review.json": {
      "sha256": "bf92a208359fdc129dfd266a78a919c199b6a258a5f004046534a789f694ec37",
      "byte_length": 7906
    },
    ".review-review.md": {
      "sha256": "55ccf2115050e52099eff8945fc2f5180db25e7caab55f51c9cdae767748962c",
      "byte_length": 8089
    },
    ".source.json": {
      "sha256": "570681afa765457469d3640a37c33101ca97046d35af7bef0e5dd7595c27d122",
      "byte_length": 1977
    }
  }
}
```
