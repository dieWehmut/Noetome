# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "89e51c30-6ffb-4cd7-b1ab-50e408da3c30",
  "binding": {
    "project_id": "a4655b2d-1191-4579-bc59-9e49e8a92157",
    "import_id": "2e7b2557-d734-46a1-9a0c-f165029625a8",
    "source_id": "7e92cba4-a60a-43c5-907b-6d0f538a5220",
    "version_id": "dc134d2c-6b0f-4905-881e-37f3056df2e6",
    "content_sha256": "ed70d6507618841afffdedd6bd28a0ab0df4e8ce91f5a30006fbec45d09d41cd",
    "normalized_sha256": "ed70d6507618841afffdedd6bd28a0ab0df4e8ce91f5a30006fbec45d09d41cd",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "未知判据的分流说明",
      "entry": "d1",
      "goals": [
        "s1",
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": []
    },
    "steps": [
      {
        "id": "d1",
        "kind": "decision",
        "label": "执行待明确的判定",
        "description": "来源未列明实际判据",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "未知"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "判据未确认前不能执行"
        ]
      },
      {
        "id": "s1",
        "kind": "step",
        "label": "真支处理",
        "description": "只记录真支去向",
        "criterion": null,
        "inputs": [
          "真支卡片"
        ],
        "outputs": [
          "真支结果"
        ],
        "conditions": [],
        "exceptions": []
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "假支处理",
        "description": "只记录假支去向",
        "criterion": null,
        "inputs": [
          "假支卡片"
        ],
        "outputs": [
          "假支结果"
        ],
        "conditions": [],
        "exceptions": []
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "d1",
        "right": "s1",
        "kind": "branch",
        "branch_outcome": true,
        "conditions": [],
        "exceptions": []
      },
      {
        "id": "r2",
        "left": "d1",
        "right": "s2",
        "kind": "branch",
        "branch_outcome": false,
        "conditions": [],
        "exceptions": []
      }
    ],
    "evidence": [
      {
        "object_id": "d1",
        "start_byte": 127,
        "end_byte": 346,
        "quote": "判定 d1：\"执行待明确的判定\"。判据：null。说明：\"来源未列明实际判据\"。输入：[\"样例卡\"]。输出：[\"未知\"]。条件：[\"卡片可读\"]。例外：[\"判据未确认前不能执行\"]。"
      },
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 126,
        "quote": "过程：\"未知判据的分流说明\"。入口：d1。目标：[\"s1\",\"s2\"]。条件：[\"演示模式开启\"]。例外：[]。"
      },
      {
        "object_id": "r1",
        "start_byte": 645,
        "end_byte": 718,
        "quote": "关系 r1：d1 的判据为真时执行 s1。条件：[]。例外：[]。"
      },
      {
        "object_id": "r2",
        "start_byte": 719,
        "end_byte": 792,
        "quote": "关系 r2：d1 的判据为假时执行 s2。条件：[]。例外：[]。"
      },
      {
        "object_id": "s1",
        "start_byte": 347,
        "end_byte": 495,
        "quote": "步骤 s1：\"真支处理\"。说明：\"只记录真支去向\"。输入：[\"真支卡片\"]。输出：[\"真支结果\"]。条件：[]。例外：[]。"
      },
      {
        "object_id": "s2",
        "start_byte": 496,
        "end_byte": 644,
        "quote": "步骤 s2：\"假支处理\"。说明：\"只记录假支去向\"。输入：[\"假支卡片\"]。输出：[\"假支结果\"]。条件：[]。例外：[]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 2,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 0,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 2,
    "sequence_relations": 0,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 2,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 0,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 2,
    "sequence_relations": 0,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
  "ir_fingerprint": {
    "sha256": "01e9fc0dcfe8db26cfeeb71393972436033001a6eaad5c8786defdd37f0cd986",
    "byte_length": 6089
  },
  "inputs": {
    ".case.json": {
      "sha256": "ab2c969e0163b7d40486882084e27aa3c4079a17064a2f7e079a101384020012",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".source.json": {
      "sha256": "59ffec74176f1d35be22e03079fd9bbbb5de66978a517a768b9f3ae4a558549d",
      "byte_length": 1723
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "ab2c969e0163b7d40486882084e27aa3c4079a17064a2f7e079a101384020012",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".owner.json": {
      "sha256": "39b27d33bea2246c53a2cace266088f66844b54173977e4d41af7af17680bbb5",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "59ffec74176f1d35be22e03079fd9bbbb5de66978a517a768b9f3ae4a558549d",
      "byte_length": 1723
    },
    "process-ir.json": {
      "sha256": "01e9fc0dcfe8db26cfeeb71393972436033001a6eaad5c8786defdd37f0cd986",
      "byte_length": 6089
    }
  }
}
```
