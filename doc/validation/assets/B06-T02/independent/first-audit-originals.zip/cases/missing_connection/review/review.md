# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "aa37ecc1-8e24-42c4-b39b-9ef1f5378a01",
  "binding": {
    "project_id": "af37caa9-c1fb-4618-a92e-54deba991819",
    "import_id": "9f34dad9-be65-4e5b-afd8-991811dbf7c6",
    "source_id": "ad290285-5af7-441e-a21f-5c14abc438db",
    "version_id": "1b3810a3-edff-4a13-8f13-42436f9f0e11",
    "content_sha256": "23cffd99265d0c001c3a0edc181e66a67c6328c03cecbe3a23c5b1f3214609f6",
    "normalized_sha256": "23cffd99265d0c001c3a0edc181e66a67c6328c03cecbe3a23c5b1f3214609f6",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "归档连接缺失的说明",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "接收卡片",
        "description": "接收样例卡",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "已接收卡"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "破损卡暂停"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "校对卡片",
        "description": "校对已接收卡的编号",
        "criterion": null,
        "inputs": [
          "已接收卡"
        ],
        "outputs": [
          "已校对卡"
        ],
        "conditions": [
          "接收完成"
        ],
        "exceptions": [
          "编号缺失时暂停"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "归档卡片",
        "description": "目标是归档，但来源未说明从校对到归档的关系",
        "criterion": null,
        "inputs": [
          "可归档卡"
        ],
        "outputs": [
          "归档条目"
        ],
        "conditions": [
          "归档依据完整"
        ],
        "exceptions": [
          "连接未核对前不能启动"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "接收完成"
        ],
        "exceptions": [
          "破损卡不进入校对"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 147,
        "quote": "过程：\"归档连接缺失的说明\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 754,
        "end_byte": 858,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[\"接收完成\"]。例外：[\"破损卡不进入校对\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 148,
        "end_byte": 318,
        "quote": "步骤 s1：\"接收卡片\"。说明：\"接收样例卡\"。输入：[\"样例卡\"]。输出：[\"已接收卡\"]。条件：[\"卡片可读\"]。例外：[\"破损卡暂停\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 319,
        "end_byte": 510,
        "quote": "步骤 s2：\"校对卡片\"。说明：\"校对已接收卡的编号\"。输入：[\"已接收卡\"]。输出：[\"已校对卡\"]。条件：[\"接收完成\"]。例外：[\"编号缺失时暂停\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 511,
        "end_byte": 753,
        "quote": "步骤 s3：\"归档卡片\"。说明：\"目标是归档，但来源未说明从校对到归档的关系\"。输入：[\"可归档卡\"]。输出：[\"归档条目\"]。条件：[\"归档依据完整\"]。例外：[\"连接未核对前不能启动\"]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 5,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 5,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 1,
    "source_statements": 5,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 5,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 5,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 1,
    "source_statements": 5,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "1938924f3f9cf40936ebbd89932c021ec86e5db84b49338464b84c44d7a0ce2c",
  "ir_fingerprint": {
    "sha256": "a948b1395f4874a9bbacbe1d96892f205522f372ce8651ee70091b5b07198ebf",
    "byte_length": 6101
  },
  "inputs": {
    ".case.json": {
      "sha256": "441c8f8a60c299fda219edb941b9b4ecde6ad3d92677334fe93f481a81277a42",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "1938924f3f9cf40936ebbd89932c021ec86e5db84b49338464b84c44d7a0ce2c",
      "byte_length": 3277
    },
    ".source.json": {
      "sha256": "89f72ec26c8edcaeede012253ed8913a0a69c4af4c1307ab48f6aaba2ae4dad3",
      "byte_length": 1800
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "441c8f8a60c299fda219edb941b9b4ecde6ad3d92677334fe93f481a81277a42",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "1938924f3f9cf40936ebbd89932c021ec86e5db84b49338464b84c44d7a0ce2c",
      "byte_length": 3277
    },
    ".owner.json": {
      "sha256": "ce147b57cbae0055eeda780b6fe5f0c969b6a82915bb8ea8994e30e92cc3ad0e",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "89f72ec26c8edcaeede012253ed8913a0a69c4af4c1307ab48f6aaba2ae4dad3",
      "byte_length": 1800
    },
    "process-ir.json": {
      "sha256": "a948b1395f4874a9bbacbe1d96892f205522f372ce8651ee70091b5b07198ebf",
      "byte_length": 6101
    }
  }
}
```
