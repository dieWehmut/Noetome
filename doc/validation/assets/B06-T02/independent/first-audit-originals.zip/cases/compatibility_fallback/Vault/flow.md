# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "40526084-1437-4007-ae83-d25c3cf10da6",
  "binding": {
    "project_id": "28a58e82-b492-46a7-b81d-42b7ada75ec1",
    "import_id": "721553d0-a375-41a8-ae3a-e40fca8536cb",
    "source_id": "1495f483-48fc-44f2-821f-0b89eb9ed5d3",
    "version_id": "51168915-8c27-4457-af5c-f6eba9a2e58e",
    "content_sha256": "f952adcc163a6ef12769dde6c9b6ab17262554229272005808cd27ba13f6f708",
    "normalized_sha256": "f952adcc163a6ef12769dde6c9b6ab17262554229272005808cd27ba13f6f708",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_TARGET_UNVERIFIED"
  ],
  "issues": [],
  "process_document": {
    "process": {
      "title": "样例卡片归档",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "卡片破损时暂停流程"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "登记卡片",
        "description": "接收样例卡并登记编号",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "已登记卡"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "编号缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "校对编号",
        "description": "将登记编号与卡片编号逐字比对",
        "criterion": null,
        "inputs": [
          "已登记卡"
        ],
        "outputs": [
          "已校对卡"
        ],
        "conditions": [
          "登记编号存在"
        ],
        "exceptions": [
          "编号不一致时停止"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "保存归档条目",
        "description": "保存已校对卡的归档条目",
        "criterion": null,
        "inputs": [
          "已校对卡"
        ],
        "outputs": [
          "归档条目"
        ],
        "conditions": [
          "校对已通过"
        ],
        "exceptions": [
          "存储不可用时保留待归档卡"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "登记完成"
        ],
        "exceptions": [
          "编号缺失时不进入校对"
        ]
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "编号一致"
        ],
        "exceptions": [
          "存储不可用时不写入"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 141,
        "quote": "过程：\"样例卡片归档\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"卡片破损时暂停流程\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 772,
        "end_byte": 882,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[\"登记完成\"]。例外：[\"编号缺失时不进入校对\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 883,
        "end_byte": 990,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"编号一致\"]。例外：[\"存储不可用时不写入\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 142,
        "end_byte": 333,
        "quote": "步骤 s1：\"登记卡片\"。说明：\"接收样例卡并登记编号\"。输入：[\"样例卡\"]。输出：[\"已登记卡\"]。条件：[\"卡片可读\"]。例外：[\"编号缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 334,
        "end_byte": 549,
        "quote": "步骤 s2：\"校对编号\"。说明：\"将登记编号与卡片编号逐字比对\"。输入：[\"已登记卡\"]。输出：[\"已校对卡\"]。条件：[\"登记编号存在\"]。例外：[\"编号不一致时停止\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 550,
        "end_byte": 771,
        "quote": "步骤 s3：\"保存归档条目\"。说明：\"保存已校对卡的归档条目\"。输入：[\"已校对卡\"]。输出：[\"归档条目\"]。条件：[\"校对已通过\"]。例外：[\"存储不可用时保留待归档卡\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "unverified_flowchart",
    "app": "Obsidian",
    "app_version": "unknown",
    "mermaid_version": "unknown",
    "flowchart_support": "unverified",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": "ordered_list",
  "decision": {
    "rule_id": "verified_relations_text_fallback_v1",
    "reason": "来源关系已通过流程语义检查；当前显示条件采用有据文字回退。",
    "fallback_reasons": [
      {
        "code": "FLOW_TARGET_UNVERIFIED",
        "object_ids": [],
        "message": "所选目标版本或标签配置尚无本版实测依据，使用保留完整关系的文字表达。"
      }
    ]
  },
  "review_ir_fingerprint": {
    "sha256": "eef8da9703a7c17e06f8d83dc0e4cafb32d572f6af9407a5427ad688867d4449",
    "byte_length": 6917
  },
  "plan_fingerprint": {
    "sha256": "62fa7ffa9882de4f9463e8495f08c3fa098735465d6253908a9ac2acfb83884d",
    "byte_length": 17261
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 14,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "flow_edges": 2,
    "flow_nodes": 3,
    "inhibits_relations": 0,
    "links": 12,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "rendered_notes": 2,
    "sequence_relations": 2,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "c4f7fa63a8bd8539214f9895cb32b949db71c05d83cc8f39972fce801c79cead",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".profile.json": {
      "sha256": "6d2b9ff852a55dba7544f0e7727fdd1e4ea06d4c8362bd9cef2175202cc3c319",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "c4f7fa63a8bd8539214f9895cb32b949db71c05d83cc8f39972fce801c79cead",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".review-.owner.json": {
      "sha256": "fa3ef11089e71daf93a0702b13906184d295e3141dfd7b7e9d3da70dc3495816",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "f892addd3595c9068f18838520822319380ae2fe1e82cf0278f7bd507ad3d744",
      "byte_length": 1937
    },
    ".review-process-ir.json": {
      "sha256": "eef8da9703a7c17e06f8d83dc0e4cafb32d572f6af9407a5427ad688867d4449",
      "byte_length": 6917
    },
    ".review-review.json": {
      "sha256": "a5ed558046d3e8eac06c646ca060c5f42cf04bda4e1a2f8ab334dbd596ab8f5f",
      "byte_length": 7586
    },
    ".review-review.md": {
      "sha256": "f25f122ffdedfc4b9dc4452e4c07f4a19024f7de6f9e8d018464685538ec8ccf",
      "byte_length": 7769
    },
    ".source.json": {
      "sha256": "f892addd3595c9068f18838520822319380ae2fe1e82cf0278f7bd507ad3d744",
      "byte_length": 1937
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "3d67b06a6f22af3ed1f9d13ba8f8fc2ab6d3fcb545f865d89e1b29bd4f7b8ac6",
      "byte_length": 2458,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 74
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 88,
          "end_byte": 349
        },
        {
          "section_id": "flow",
          "block_id": "fallback_reason",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 363,
          "end_byte": 465
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s1",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 788,
          "end_byte": 1063
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s2",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1136,
          "end_byte": 1435
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s3",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 1508,
          "end_byte": 1813
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r1",
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 1909,
          "end_byte": 2116
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r2",
          "source_object_ids": [
            "r2",
            "s2",
            "s3"
          ],
          "start_byte": 2189,
          "end_byte": 2399
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 471,
          "end_byte": 525
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 526,
          "end_byte": 571
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 572,
          "end_byte": 617
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s3",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 618,
          "end_byte": 663
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 664,
          "end_byte": 709
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r2",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 710,
          "end_byte": 755
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s1",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 1075,
          "end_byte": 1120
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s2",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1447,
          "end_byte": 1492
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s3",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s3",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 1825,
          "end_byte": 1870
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r1",
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 2128,
          "end_byte": 2173
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r2",
          "target_path": "过程明细.md",
          "target_heading": "关系-r2",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 2411,
          "end_byte": 2456
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "e3eb976672179d40a9c097e4174a487300c68adee25a9c1a3b9527223aefb4c9",
      "byte_length": 1507,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 175
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 203,
          "end_byte": 439
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 467,
          "end_byte": 727
        },
        {
          "section_id": "step_s3",
          "block_id": "s3",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 755,
          "end_byte": 1021
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 1049,
          "end_byte": 1226
        },
        {
          "section_id": "relation_r2",
          "block_id": "r2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r2",
            "s2",
            "s3"
          ],
          "start_byte": 1254,
          "end_byte": 1434
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 1457,
          "end_byte": 1505
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "c4f7fa63a8bd8539214f9895cb32b949db71c05d83cc8f39972fce801c79cead",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".owner.json": {
      "sha256": "fe2cc91a9f80deb9aec52433ecca9a29a577f4f2a73c5fa9e84e52cc20880cce",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "6d2b9ff852a55dba7544f0e7727fdd1e4ea06d4c8362bd9cef2175202cc3c319",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "c4f7fa63a8bd8539214f9895cb32b949db71c05d83cc8f39972fce801c79cead",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".review-.owner.json": {
      "sha256": "fa3ef11089e71daf93a0702b13906184d295e3141dfd7b7e9d3da70dc3495816",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "f892addd3595c9068f18838520822319380ae2fe1e82cf0278f7bd507ad3d744",
      "byte_length": 1937
    },
    ".review-process-ir.json": {
      "sha256": "eef8da9703a7c17e06f8d83dc0e4cafb32d572f6af9407a5427ad688867d4449",
      "byte_length": 6917
    },
    ".review-review.json": {
      "sha256": "a5ed558046d3e8eac06c646ca060c5f42cf04bda4e1a2f8ab334dbd596ab8f5f",
      "byte_length": 7586
    },
    ".review-review.md": {
      "sha256": "f25f122ffdedfc4b9dc4452e4c07f4a19024f7de6f9e8d018464685538ec8ccf",
      "byte_length": 7769
    },
    ".source.json": {
      "sha256": "f892addd3595c9068f18838520822319380ae2fe1e82cf0278f7bd507ad3d744",
      "byte_length": 1937
    },
    "plan.json": {
      "sha256": "62fa7ffa9882de4f9463e8495f08c3fa098735465d6253908a9ac2acfb83884d",
      "byte_length": 17261
    },
    "流程总览.md": {
      "sha256": "3d67b06a6f22af3ed1f9d13ba8f8fc2ab6d3fcb545f865d89e1b29bd4f7b8ac6",
      "byte_length": 2458
    },
    "过程明细.md": {
      "sha256": "e3eb976672179d40a9c097e4174a487300c68adee25a9c1a3b9527223aefb4c9",
      "byte_length": 1507
    }
  }
}
```
