# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "772094e7-3018-4040-b52f-d07bbd54beed",
  "binding": {
    "project_id": "28a58e82-b492-46a7-b81d-42b7ada75ec1",
    "import_id": "721553d0-a375-41a8-ae3a-e40fca8536cb",
    "source_id": "1495f483-48fc-44f2-821f-0b89eb9ed5d3",
    "version_id": "51168915-8c27-4457-af5c-f6eba9a2e58e",
    "content_sha256": "f952adcc163a6ef12769dde6c9b6ab17262554229272005808cd27ba13f6f708",
    "normalized_sha256": "f952adcc163a6ef12769dde6c9b6ab17262554229272005808cd27ba13f6f708",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "样例卡片归档",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "卡片破损时暂停流程"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "登记卡片",
        "description": "接收样例卡并登记编号",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "已登记卡"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "编号缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "校对编号",
        "description": "将登记编号与卡片编号逐字比对",
        "criterion": null,
        "inputs": [
          "已登记卡"
        ],
        "outputs": [
          "已校对卡"
        ],
        "conditions": [
          "登记编号存在"
        ],
        "exceptions": [
          "编号不一致时停止"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "保存归档条目",
        "description": "保存已校对卡的归档条目",
        "criterion": null,
        "inputs": [
          "已校对卡"
        ],
        "outputs": [
          "归档条目"
        ],
        "conditions": [
          "校对已通过"
        ],
        "exceptions": [
          "存储不可用时保留待归档卡"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "登记完成"
        ],
        "exceptions": [
          "编号缺失时不进入校对"
        ]
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "编号一致"
        ],
        "exceptions": [
          "存储不可用时不写入"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 141,
        "quote": "过程：\"样例卡片归档\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"卡片破损时暂停流程\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 772,
        "end_byte": 882,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[\"登记完成\"]。例外：[\"编号缺失时不进入校对\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 883,
        "end_byte": 990,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"编号一致\"]。例外：[\"存储不可用时不写入\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 142,
        "end_byte": 333,
        "quote": "步骤 s1：\"登记卡片\"。说明：\"接收样例卡并登记编号\"。输入：[\"样例卡\"]。输出：[\"已登记卡\"]。条件：[\"卡片可读\"]。例外：[\"编号缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 334,
        "end_byte": 549,
        "quote": "步骤 s2：\"校对编号\"。说明：\"将登记编号与卡片编号逐字比对\"。输入：[\"已登记卡\"]。输出：[\"已校对卡\"]。条件：[\"登记编号存在\"]。例外：[\"编号不一致时停止\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 550,
        "end_byte": 771,
        "quote": "步骤 s3：\"保存归档条目\"。说明：\"保存已校对卡的归档条目\"。输入：[\"已校对卡\"]。输出：[\"归档条目\"]。条件：[\"校对已通过\"]。例外：[\"存储不可用时保留待归档卡\"]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 2,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 2,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
  "ir_fingerprint": {
    "sha256": "eef8da9703a7c17e06f8d83dc0e4cafb32d572f6af9407a5427ad688867d4449",
    "byte_length": 6917
  },
  "inputs": {
    ".case.json": {
      "sha256": "c4f7fa63a8bd8539214f9895cb32b949db71c05d83cc8f39972fce801c79cead",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".source.json": {
      "sha256": "f892addd3595c9068f18838520822319380ae2fe1e82cf0278f7bd507ad3d744",
      "byte_length": 1937
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "c4f7fa63a8bd8539214f9895cb32b949db71c05d83cc8f39972fce801c79cead",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".owner.json": {
      "sha256": "fa3ef11089e71daf93a0702b13906184d295e3141dfd7b7e9d3da70dc3495816",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "f892addd3595c9068f18838520822319380ae2fe1e82cf0278f7bd507ad3d744",
      "byte_length": 1937
    },
    "process-ir.json": {
      "sha256": "eef8da9703a7c17e06f8d83dc0e4cafb32d572f6af9407a5427ad688867d4449",
      "byte_length": 6917
    }
  }
}
```
