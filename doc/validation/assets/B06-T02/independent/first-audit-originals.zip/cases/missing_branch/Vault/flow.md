# 有据流程表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "9cc8f149-2fe0-4d16-8dcc-91584c72f542",
  "binding": {
    "project_id": "ba86c93a-8a53-4e05-9056-64fa72b71892",
    "import_id": "1f7c0e45-8537-4cc2-af76-18bb6f020f5c",
    "source_id": "79072fe3-bf08-425e-ae57-8e8a316ebb0e",
    "version_id": "99f80ac9-6c50-494a-bebb-54336fdd9517",
    "content_sha256": "b51472e1fd81189cd3c21bdd5328307c4a9d0b083658b806ac3fcd7908b9764f",
    "normalized_sha256": "b51472e1fd81189cd3c21bdd5328307c4a9d0b083658b806ac3fcd7908b9764f",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_DECISION_INCOMPLETE"
  ],
  "issues": [
    {
      "code": "FLOW_DECISION_INCOMPLETE",
      "object_ids": [
        "d1"
      ],
      "message": "每个判定须恰有一条真分支和一条假分支，分支必须来自具有判据的判定。"
    }
  ],
  "process_document": {
    "process": {
      "title": "只有真支的签名说明",
      "entry": "d1",
      "goals": [
        "s1"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "d1",
        "kind": "decision",
        "label": "检查签名",
        "description": "只记录签名完整时的去向，未给出否支处理",
        "criterion": "签名完整",
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "签名判定结果"
        ],
        "conditions": [
          "签名区域可读"
        ],
        "exceptions": [
          "不可读时暂停"
        ]
      },
      {
        "id": "s1",
        "kind": "step",
        "label": "加入归档队列",
        "description": "接收判据为真的卡片",
        "criterion": null,
        "inputs": [
          "判据为真的卡片"
        ],
        "outputs": [
          "待归档卡"
        ],
        "conditions": [
          "签名完整"
        ],
        "exceptions": [
          "队列不可用时暂停"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "d1",
        "right": "s1",
        "kind": "branch",
        "branch_outcome": true,
        "conditions": [
          "签名区域可读"
        ],
        "exceptions": [
          "队列不可用时暂停"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "d1",
        "start_byte": 148,
        "end_byte": 401,
        "quote": "判定 d1：\"检查签名\"。判据：\"签名完整\"。说明：\"只记录签名完整时的去向，未给出否支处理\"。输入：[\"样例卡\"]。输出：[\"签名判定结果\"]。条件：[\"签名区域可读\"]。例外：[\"不可读时暂停\"]。"
      },
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 147,
        "quote": "过程：\"只有真支的签名说明\"。入口：d1。目标：[\"s1\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 612,
        "end_byte": 731,
        "quote": "关系 r1：d1 的判据为真时执行 s1。条件：[\"签名区域可读\"]。例外：[\"队列不可用时暂停\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 402,
        "end_byte": 611,
        "quote": "步骤 s1：\"加入归档队列\"。说明：\"接收判据为真的卡片\"。输入：[\"判据为真的卡片\"]。输出：[\"待归档卡\"]。条件：[\"签名完整\"]。例外：[\"队列不可用时暂停\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": null,
  "decision": null,
  "review_ir_fingerprint": {
    "sha256": "9052361b7fe70c91ef2ba0a98f9216b95a4386b65f6c97e8fc4693a09be1fa29",
    "byte_length": 5209
  },
  "plan_fingerprint": null,
  "totals": {
    "branch_relations": 1,
    "causes_relations": 0,
    "content_mappings": 0,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 4,
    "flow_edges": 0,
    "flow_nodes": 0,
    "inhibits_relations": 0,
    "links": 0,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "rendered_notes": 0,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "69b26b03b6d8ae5a2a7fa904da767a7c1db7c1c21b42ff17b9d2b2075b8ee995",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "d2b35b82e10641fffe40190c72d8b91bcae2cc2341c38311379528d47c4c1f81",
      "byte_length": 2701
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "69b26b03b6d8ae5a2a7fa904da767a7c1db7c1c21b42ff17b9d2b2075b8ee995",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "d2b35b82e10641fffe40190c72d8b91bcae2cc2341c38311379528d47c4c1f81",
      "byte_length": 2701
    },
    ".review-.owner.json": {
      "sha256": "0495b2beefb85c29d7e834c86a1f264593ee953570f715b483235f51ef0cf682",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "08abc831709ba7f3151056b9eb2d6ff30b62b1182d29f16069ebdc6f96b3bb65",
      "byte_length": 1662
    },
    ".review-process-ir.json": {
      "sha256": "9052361b7fe70c91ef2ba0a98f9216b95a4386b65f6c97e8fc4693a09be1fa29",
      "byte_length": 5209
    },
    ".review-review.json": {
      "sha256": "a42dd7dfba2b4590e7289c14a2064b2dd0f5c988ff9e98eb23af398a7d7974d7",
      "byte_length": 6409
    },
    ".review-review.md": {
      "sha256": "e297c19e987350fb7386d112fa2a9021338dacf68877368c7f63020045d64f6d",
      "byte_length": 6592
    },
    ".source.json": {
      "sha256": "08abc831709ba7f3151056b9eb2d6ff30b62b1182d29f16069ebdc6f96b3bb65",
      "byte_length": 1662
    }
  },
  "files": [],
  "artifacts": {
    ".case.json": {
      "sha256": "69b26b03b6d8ae5a2a7fa904da767a7c1db7c1c21b42ff17b9d2b2075b8ee995",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "d2b35b82e10641fffe40190c72d8b91bcae2cc2341c38311379528d47c4c1f81",
      "byte_length": 2701
    },
    ".owner.json": {
      "sha256": "3c509706e401dc7e1f1e785dd04007946a7fc59d5e849d255fd14de758fee90e",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "69b26b03b6d8ae5a2a7fa904da767a7c1db7c1c21b42ff17b9d2b2075b8ee995",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "d2b35b82e10641fffe40190c72d8b91bcae2cc2341c38311379528d47c4c1f81",
      "byte_length": 2701
    },
    ".review-.owner.json": {
      "sha256": "0495b2beefb85c29d7e834c86a1f264593ee953570f715b483235f51ef0cf682",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "08abc831709ba7f3151056b9eb2d6ff30b62b1182d29f16069ebdc6f96b3bb65",
      "byte_length": 1662
    },
    ".review-process-ir.json": {
      "sha256": "9052361b7fe70c91ef2ba0a98f9216b95a4386b65f6c97e8fc4693a09be1fa29",
      "byte_length": 5209
    },
    ".review-review.json": {
      "sha256": "a42dd7dfba2b4590e7289c14a2064b2dd0f5c988ff9e98eb23af398a7d7974d7",
      "byte_length": 6409
    },
    ".review-review.md": {
      "sha256": "e297c19e987350fb7386d112fa2a9021338dacf68877368c7f63020045d64f6d",
      "byte_length": 6592
    },
    ".source.json": {
      "sha256": "08abc831709ba7f3151056b9eb2d6ff30b62b1182d29f16069ebdc6f96b3bb65",
      "byte_length": 1662
    }
  }
}
```
