# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "8b950d2d-132f-4917-be39-a4fcc025bb48",
  "binding": {
    "project_id": "d67a93bf-0bf9-4382-9f99-d0641355ad24",
    "import_id": "fa06fc9e-ed2e-4372-ba21-caffda85b5c3",
    "source_id": "288144fa-6f1e-4f1f-82d5-a4748c892631",
    "version_id": "44b543f6-ed92-4971-9f62-a291507fe1a6",
    "content_sha256": "07ffaee58e8b3f349addf15fd2eb7df5a49357fa808c65fc5728bb2c1bd7d076",
    "normalized_sha256": "07ffaee58e8b3f349addf15fd2eb7df5a49357fa808c65fc5728bb2c1bd7d076",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_LABEL_WHITESPACE_FALLBACK"
  ],
  "issues": [],
  "process_document": {
    "process": {
      "title": "多行标签的保真流程",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [],
      "exceptions": [
        "不可读资料需复核"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "检查\n卡片\t[α]",
        "description": "完整保留来源标签中的换行和制表符",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "检查结果"
        ],
        "conditions": [],
        "exceptions": [
          "卡片缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "记录检查结果",
        "description": "记录来源明示的检查结果",
        "criterion": null,
        "inputs": [
          "检查结果"
        ],
        "outputs": [
          "检查记录"
        ],
        "conditions": [
          "检查完成"
        ],
        "exceptions": []
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [],
        "exceptions": [
          "检查未完成时不得登记"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 127,
        "quote": "过程：\"多行标签的保真流程\"。入口：s1。目标：[\"s2\"]。条件：[]。例外：[\"不可读资料需复核\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 513,
        "end_byte": 609,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[]。例外：[\"检查未完成时不得登记\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 128,
        "end_byte": 331,
        "quote": "步骤 s1：\"检查\\n卡片\\t[α]\"。说明：\"完整保留来源标签中的换行和制表符\"。输入：[\"样例卡\"]。输出：[\"检查结果\"]。条件：[]。例外：[\"卡片缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 332,
        "end_byte": 512,
        "quote": "步骤 s2：\"记录检查结果\"。说明：\"记录来源明示的检查结果\"。输入：[\"检查结果\"]。输出：[\"检查记录\"]。条件：[\"检查完成\"]。例外：[]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": "ordered_list",
  "decision": {
    "rule_id": "verified_relations_text_fallback_v1",
    "reason": "来源关系已通过流程语义检查；当前显示条件采用有据文字回退。",
    "fallback_reasons": [
      {
        "code": "FLOW_LABEL_WHITESPACE_FALLBACK",
        "object_ids": [
          "s1"
        ],
        "message": "图标签含换行或制表符；已测图形标签会压缩其视觉空白，改用预格式文字保留原字符。"
      }
    ]
  },
  "review_ir_fingerprint": {
    "sha256": "d131865bde3cd61cae768867083ab8df4ae86301d79173e9580249915e0836e8",
    "byte_length": 4773
  },
  "plan_fingerprint": {
    "sha256": "d7b8d5f58a2d66c270dccd9563b94aa1d51e5fa8b22bdb9684266a6055cd49d7",
    "byte_length": 12476
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 10,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "flow_edges": 1,
    "flow_nodes": 2,
    "inhibits_relations": 0,
    "links": 8,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 0,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 1,
    "relations": 1,
    "rendered_notes": 2,
    "sequence_relations": 1,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "92832016789665fea133bfcc8900ca79fc44772c4dedad6f0699bbc4145d51f9",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "92832016789665fea133bfcc8900ca79fc44772c4dedad6f0699bbc4145d51f9",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".review-.owner.json": {
      "sha256": "6cf0a8ce5410d9605862360b7438b7cc8489da943c21117bde3be7087f06ee13",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "a7f313349a7d2fdfc04f6e5281a694ae68a544496ce01ac851258ee4da17eb55",
      "byte_length": 1532
    },
    ".review-process-ir.json": {
      "sha256": "d131865bde3cd61cae768867083ab8df4ae86301d79173e9580249915e0836e8",
      "byte_length": 4773
    },
    ".review-review.json": {
      "sha256": "5319345c1546663e5fe0dcdb41ad18bba312480f413f3a90e77bbf0afce670f3",
      "byte_length": 6104
    },
    ".review-review.md": {
      "sha256": "82f788f3741f3548d43ef5e93784c16b20cce0701ff7549b3cbfc810eb769a5f",
      "byte_length": 6287
    },
    ".source.json": {
      "sha256": "a7f313349a7d2fdfc04f6e5281a694ae68a544496ce01ac851258ee4da17eb55",
      "byte_length": 1532
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "e4c61160889b9ddb1f0e54951408229b404ae3308d1670393d9de8e4bd3fc7da",
      "byte_length": 1756,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 83
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 97,
          "end_byte": 358
        },
        {
          "section_id": "flow",
          "block_id": "fallback_reason",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 372,
          "end_byte": 489
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s1",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 720,
          "end_byte": 1024
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s2",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1097,
          "end_byte": 1377
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r1",
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 1473,
          "end_byte": 1697
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 495,
          "end_byte": 549
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 550,
          "end_byte": 595
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 596,
          "end_byte": 641
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 642,
          "end_byte": 687
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s1",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 1036,
          "end_byte": 1081
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s2",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1389,
          "end_byte": 1434
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r1",
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 1709,
          "end_byte": 1754
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "d9f133b91f0db5c51fa403ec3a95bae2611e7a73da75878eefc5f5d77c72b2d1",
      "byte_length": 1040,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 180
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 208,
          "end_byte": 473
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 501,
          "end_byte": 745
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 773,
          "end_byte": 967
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 990,
          "end_byte": 1038
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "92832016789665fea133bfcc8900ca79fc44772c4dedad6f0699bbc4145d51f9",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".owner.json": {
      "sha256": "1c5d3a67a0ab02f5ce0b3c0e1d45bd45b4499700c08064d2fe0dd7eac0077a0c",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "92832016789665fea133bfcc8900ca79fc44772c4dedad6f0699bbc4145d51f9",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".review-.owner.json": {
      "sha256": "6cf0a8ce5410d9605862360b7438b7cc8489da943c21117bde3be7087f06ee13",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "a7f313349a7d2fdfc04f6e5281a694ae68a544496ce01ac851258ee4da17eb55",
      "byte_length": 1532
    },
    ".review-process-ir.json": {
      "sha256": "d131865bde3cd61cae768867083ab8df4ae86301d79173e9580249915e0836e8",
      "byte_length": 4773
    },
    ".review-review.json": {
      "sha256": "5319345c1546663e5fe0dcdb41ad18bba312480f413f3a90e77bbf0afce670f3",
      "byte_length": 6104
    },
    ".review-review.md": {
      "sha256": "82f788f3741f3548d43ef5e93784c16b20cce0701ff7549b3cbfc810eb769a5f",
      "byte_length": 6287
    },
    ".source.json": {
      "sha256": "a7f313349a7d2fdfc04f6e5281a694ae68a544496ce01ac851258ee4da17eb55",
      "byte_length": 1532
    },
    "plan.json": {
      "sha256": "d7b8d5f58a2d66c270dccd9563b94aa1d51e5fa8b22bdb9684266a6055cd49d7",
      "byte_length": 12476
    },
    "流程总览.md": {
      "sha256": "e4c61160889b9ddb1f0e54951408229b404ae3308d1670393d9de8e4bd3fc7da",
      "byte_length": 1756
    },
    "过程明细.md": {
      "sha256": "d9f133b91f0db5c51fa403ec3a95bae2611e7a73da75878eefc5f5d77c72b2d1",
      "byte_length": 1040
    }
  }
}
```
