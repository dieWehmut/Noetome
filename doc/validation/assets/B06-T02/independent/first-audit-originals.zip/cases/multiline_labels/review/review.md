# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "693a557e-87b4-4f35-940e-cff5f22542f1",
  "binding": {
    "project_id": "d67a93bf-0bf9-4382-9f99-d0641355ad24",
    "import_id": "fa06fc9e-ed2e-4372-ba21-caffda85b5c3",
    "source_id": "288144fa-6f1e-4f1f-82d5-a4748c892631",
    "version_id": "44b543f6-ed92-4971-9f62-a291507fe1a6",
    "content_sha256": "07ffaee58e8b3f349addf15fd2eb7df5a49357fa808c65fc5728bb2c1bd7d076",
    "normalized_sha256": "07ffaee58e8b3f349addf15fd2eb7df5a49357fa808c65fc5728bb2c1bd7d076",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "多行标签的保真流程",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [],
      "exceptions": [
        "不可读资料需复核"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "检查\n卡片\t[α]",
        "description": "完整保留来源标签中的换行和制表符",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "检查结果"
        ],
        "conditions": [],
        "exceptions": [
          "卡片缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "记录检查结果",
        "description": "记录来源明示的检查结果",
        "criterion": null,
        "inputs": [
          "检查结果"
        ],
        "outputs": [
          "检查记录"
        ],
        "conditions": [
          "检查完成"
        ],
        "exceptions": []
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [],
        "exceptions": [
          "检查未完成时不得登记"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 127,
        "quote": "过程：\"多行标签的保真流程\"。入口：s1。目标：[\"s2\"]。条件：[]。例外：[\"不可读资料需复核\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 513,
        "end_byte": 609,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[]。例外：[\"检查未完成时不得登记\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 128,
        "end_byte": 331,
        "quote": "步骤 s1：\"检查\\n卡片\\t[α]\"。说明：\"完整保留来源标签中的换行和制表符\"。输入：[\"样例卡\"]。输出：[\"检查结果\"]。条件：[]。例外：[\"卡片缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 332,
        "end_byte": 512,
        "quote": "步骤 s2：\"记录检查结果\"。说明：\"记录来源明示的检查结果\"。输入：[\"检查结果\"]。输出：[\"检查记录\"]。条件：[\"检查完成\"]。例外：[]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "inhibits_relations": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 0,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 1,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "inhibits_relations": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 0,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 1,
    "relations": 1,
    "sequence_relations": 1,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
  "ir_fingerprint": {
    "sha256": "d131865bde3cd61cae768867083ab8df4ae86301d79173e9580249915e0836e8",
    "byte_length": 4773
  },
  "inputs": {
    ".case.json": {
      "sha256": "92832016789665fea133bfcc8900ca79fc44772c4dedad6f0699bbc4145d51f9",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".source.json": {
      "sha256": "a7f313349a7d2fdfc04f6e5281a694ae68a544496ce01ac851258ee4da17eb55",
      "byte_length": 1532
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "92832016789665fea133bfcc8900ca79fc44772c4dedad6f0699bbc4145d51f9",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".owner.json": {
      "sha256": "6cf0a8ce5410d9605862360b7438b7cc8489da943c21117bde3be7087f06ee13",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "a7f313349a7d2fdfc04f6e5281a694ae68a544496ce01ac851258ee4da17eb55",
      "byte_length": 1532
    },
    "process-ir.json": {
      "sha256": "d131865bde3cd61cae768867083ab8df4ae86301d79173e9580249915e0836e8",
      "byte_length": 4773
    }
  }
}
```
