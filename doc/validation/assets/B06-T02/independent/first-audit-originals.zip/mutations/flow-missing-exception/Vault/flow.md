# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "1c14b441-c5ea-43ae-9993-53f4ea1060f1",
  "binding": {
    "project_id": "621e59d7-a0e4-40e7-a238-7fddb6579fd0",
    "import_id": "12456ce1-7ffe-44ce-951c-0c2b9d7ce9f6",
    "source_id": "7648d8c2-4297-4338-aeb0-0f7940173926",
    "version_id": "06a01cf7-09dc-47ed-859b-6ed340f32631",
    "content_sha256": "f952adcc163a6ef12769dde6c9b6ab17262554229272005808cd27ba13f6f708",
    "normalized_sha256": "f952adcc163a6ef12769dde6c9b6ab17262554229272005808cd27ba13f6f708",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "issues": [],
  "process_document": {
    "process": {
      "title": "样例卡片归档",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "卡片破损时暂停流程"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "登记卡片",
        "description": "接收样例卡并登记编号",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "已登记卡"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "编号缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "校对编号",
        "description": "将登记编号与卡片编号逐字比对",
        "criterion": null,
        "inputs": [
          "已登记卡"
        ],
        "outputs": [
          "已校对卡"
        ],
        "conditions": [
          "登记编号存在"
        ],
        "exceptions": [
          "编号不一致时停止"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "保存归档条目",
        "description": "保存已校对卡的归档条目",
        "criterion": null,
        "inputs": [
          "已校对卡"
        ],
        "outputs": [
          "归档条目"
        ],
        "conditions": [
          "校对已通过"
        ],
        "exceptions": [
          "存储不可用时保留待归档卡"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "登记完成"
        ],
        "exceptions": [
          "编号缺失时不进入校对"
        ]
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "编号一致"
        ],
        "exceptions": [
          "存储不可用时不写入"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 141,
        "quote": "过程：\"样例卡片归档\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"卡片破损时暂停流程\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 772,
        "end_byte": 882,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[\"登记完成\"]。例外：[\"编号缺失时不进入校对\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 883,
        "end_byte": 990,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"编号一致\"]。例外：[\"存储不可用时不写入\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 142,
        "end_byte": 333,
        "quote": "步骤 s1：\"登记卡片\"。说明：\"接收样例卡并登记编号\"。输入：[\"样例卡\"]。输出：[\"已登记卡\"]。条件：[\"卡片可读\"]。例外：[\"编号缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 334,
        "end_byte": 549,
        "quote": "步骤 s2：\"校对编号\"。说明：\"将登记编号与卡片编号逐字比对\"。输入：[\"已登记卡\"]。输出：[\"已校对卡\"]。条件：[\"登记编号存在\"]。例外：[\"编号不一致时停止\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 550,
        "end_byte": 771,
        "quote": "步骤 s3：\"保存归档条目\"。说明：\"保存已校对卡的归档条目\"。输入：[\"已校对卡\"]。输出：[\"归档条目\"]。条件：[\"校对已通过\"]。例外：[\"存储不可用时保留待归档卡\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": "flowchart",
  "decision": {
    "rule_id": "verified_directed_acyclic_flow_v1",
    "reason": "来源明确给出完整有向无环关系，且所选目标的当前图形及标签配置已有实测依据。",
    "fallback_reasons": []
  },
  "review_ir_fingerprint": {
    "sha256": "eb37edb4e4ee0446ba3a49bf9a450e412dfd1404eef9445e899d8c3df1f63c72",
    "byte_length": 6917
  },
  "plan_fingerprint": {
    "sha256": "0528c81a9917272ccb4639f089ca6c4b1d909b491c44bde3c3f0f79bf6aa81c3",
    "byte_length": 13149
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 13,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "flow_edges": 2,
    "flow_nodes": 3,
    "inhibits_relations": 0,
    "links": 7,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "rendered_notes": 2,
    "sequence_relations": 2,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "1b0d5b3b8276dfdfbbd274b5b20228caeb274395f00cd6b80b52c4353a5e4f1f",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "1b0d5b3b8276dfdfbbd274b5b20228caeb274395f00cd6b80b52c4353a5e4f1f",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".review-.owner.json": {
      "sha256": "5af898aa44136f2d045d7ee9701bec20089733fb0a403fd2474bdcd242df4b4e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "73edfe525187e84c7c0dad0825a0e079d50056bb5035e5f46fbbdd38519b51b6",
      "byte_length": 1937
    },
    ".review-process-ir.json": {
      "sha256": "eb37edb4e4ee0446ba3a49bf9a450e412dfd1404eef9445e899d8c3df1f63c72",
      "byte_length": 6917
    },
    ".review-review.json": {
      "sha256": "eab0d405473a5f0ac81eb8bb86dd3f5947f757e4daccc1171b6362656956c95d",
      "byte_length": 7586
    },
    ".review-review.md": {
      "sha256": "06c930b0ac7b03cd6baed4f886c790a19612d2a910d5933d10da1e539569f01f",
      "byte_length": 7769
    },
    ".source.json": {
      "sha256": "73edfe525187e84c7c0dad0825a0e079d50056bb5035e5f46fbbdd38519b51b6",
      "byte_length": 1937
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "8d95d4d84795ab5d2188ad3df2baf50d4652773d3fa3f3b10b22bbf600ce9eef",
      "byte_length": 783,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 74
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 88,
          "end_byte": 349
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n0",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 379,
          "end_byte": 399
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n1",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 400,
          "end_byte": 420
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n2",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 421,
          "end_byte": 447
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_edge",
          "item_id": "e0",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 448,
          "end_byte": 469
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_edge",
          "item_id": "e1",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 470,
          "end_byte": 491
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 497,
          "end_byte": 551
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 552,
          "end_byte": 597
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 598,
          "end_byte": 643
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s3",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 644,
          "end_byte": 689
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 690,
          "end_byte": 735
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r2",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 736,
          "end_byte": 781
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "a5fd74fd63317dd07469dd966e1049b9ca3f9c57a8b1e5d738aa58873876aa7d",
      "byte_length": 1495,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 175
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 203,
          "end_byte": 439
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 467,
          "end_byte": 727
        },
        {
          "section_id": "step_s3",
          "block_id": "s3",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 755,
          "end_byte": 1021
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 1049,
          "end_byte": 1226
        },
        {
          "section_id": "relation_r2",
          "block_id": "r2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r2",
            "s2",
            "s3"
          ],
          "start_byte": 1254,
          "end_byte": 1434
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 1457,
          "end_byte": 1505
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "1b0d5b3b8276dfdfbbd274b5b20228caeb274395f00cd6b80b52c4353a5e4f1f",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".owner.json": {
      "sha256": "dcaf728b975c9a92749d626c93166864b8aebc665f9cb393cf9e7f043c1a81ed",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "1b0d5b3b8276dfdfbbd274b5b20228caeb274395f00cd6b80b52c4353a5e4f1f",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "247a94cfac745c5947f9902c3ad3569b47eb3c8a0de16c5b0b9fe6607b834ceb",
      "byte_length": 3790
    },
    ".review-.owner.json": {
      "sha256": "5af898aa44136f2d045d7ee9701bec20089733fb0a403fd2474bdcd242df4b4e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "73edfe525187e84c7c0dad0825a0e079d50056bb5035e5f46fbbdd38519b51b6",
      "byte_length": 1937
    },
    ".review-process-ir.json": {
      "sha256": "eb37edb4e4ee0446ba3a49bf9a450e412dfd1404eef9445e899d8c3df1f63c72",
      "byte_length": 6917
    },
    ".review-review.json": {
      "sha256": "eab0d405473a5f0ac81eb8bb86dd3f5947f757e4daccc1171b6362656956c95d",
      "byte_length": 7586
    },
    ".review-review.md": {
      "sha256": "06c930b0ac7b03cd6baed4f886c790a19612d2a910d5933d10da1e539569f01f",
      "byte_length": 7769
    },
    ".source.json": {
      "sha256": "73edfe525187e84c7c0dad0825a0e079d50056bb5035e5f46fbbdd38519b51b6",
      "byte_length": 1937
    },
    "plan.json": {
      "sha256": "0528c81a9917272ccb4639f089ca6c4b1d909b491c44bde3c3f0f79bf6aa81c3",
      "byte_length": 13149
    },
    "流程总览.md": {
      "sha256": "8d95d4d84795ab5d2188ad3df2baf50d4652773d3fa3f3b10b22bbf600ce9eef",
      "byte_length": 783
    },
    "过程明细.md": {
      "sha256": "a5fd74fd63317dd07469dd966e1049b9ca3f9c57a8b1e5d738aa58873876aa7d",
      "byte_length": 1495
    }
  }
}
```
