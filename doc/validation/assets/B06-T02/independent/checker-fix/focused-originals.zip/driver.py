from pathlib import Path
import copy,hashlib,json,shutil,sqlite3,subprocess,sys,time,uuid
repo=Path.cwd();sys.path.insert(0,str(repo/'scripts'));import verify_process_flow as v
root=Path('/tmp')/('noetome-process-checker-fix-'+uuid.uuid4().hex);root.mkdir()
Path('/tmp/noetome-process-checker-fix-root.txt').write_text(str(root))
(root/'driver.py').write_bytes(Path(__file__).read_bytes())
assets=repo/'doc/validation/assets/B06-T02/independent/checker-fix'
old=root/'before-tools';old.mkdir()
(old/'verify_process_flow.py').write_bytes((assets/'before-verify_process_flow.py').read_bytes())
for name in ['verify_extraction_knowledge.py','verify_knowledge_coordination.py','verify_knowledge_conflicts.py']:
 (old/name).write_bytes((repo/'scripts'/name).read_bytes())
current=repo/'scripts/verify_process_flow.py';cli=root/'noetome';shutil.copyfile(repo/'target/debug/noetome',cli);cli.chmod(0o755)
for p in [current,repo/'tests/test_verify_process_flow.py']:(root/('after-'+p.name)).write_bytes(p.read_bytes())
commands=[]
def pins(directory):return v.pins(v.tree(directory))
def command(label,argv,expect):
 before={str(p):pins(p) for p in protect};start=time.monotonic();run=subprocess.run(list(map(str,argv)),capture_output=True,timeout=60)
 (root/(label+'.stdout.bin')).write_bytes(run.stdout);(root/(label+'.stderr.bin')).write_bytes(run.stderr)
 after={str(p):pins(p) for p in protect}
 record=dict(label=label,argv=list(map(str,argv)),exit_code=run.returncode,elapsed_seconds=time.monotonic()-start,stdout=v.fingerprint(run.stdout),stderr=v.fingerprint(run.stderr),input_before=before,input_after=after)
 v.save(root/(label+'.receipt.json'),record);commands.append(record);assert before==after
 assert run.returncode in expect,(label,run.returncode,run.stderr.decode());return run
# Same exact existing peer reproductions, read-only; retain their original results.
protect=[]
for category,path in [('blocker','/tmp/noetome-b06-checker-blocker-review-04a72d5759b848fe9cd5930032e1290b'),('path','/tmp/noetome-b06-checker-source-path-review-1d5531d2832447c19eef92ce4540263f')]:
 origin=Path(path);original=json.loads((origin/'result.json').read_bytes());(root/(category+'-original-result.json')).write_bytes((origin/'result.json').read_bytes())
 for row in original['commands'][:2]:
  argv=row['argv'];argv[0]=sys.executable;argv[1]=str(current);protect=[Path(argv[i]) for i in [3,4,5,7]]
  command(category+'-'+row.get('name','')+'-after',argv,[0] if row['name']=='baseline' else [1])
# Complete synchronized local source forgery, preserving actual source path rules.
origin=Path('/tmp/noetome-process-flow-audit-first.txt').read_text().strip();source=Path(origin)/'cases/linear'
def sync_binding(folder):
 project=folder/'project';case=folder/'case';review=folder/'review';vault=folder/'Vault'
 config=json.loads((case/'process-review.json').read_bytes());selected=v.actual_source(project,config['import_id'],config['selection'][0])
 snapshot=dict(schema_version=1,binding=selected['binding'],units=selected['units'])
 (review/'.source.json').write_bytes(v.encoded(snapshot))
 ir=json.loads((review/'process-ir.json').read_bytes());ir['binding']=selected['binding'];ir['unit']=selected['units'][0]
 (review/'process-ir.json').write_bytes(v.encoded(ir))
 r=json.loads((review/'review.json').read_bytes());r['binding']=selected['binding'];(review/'review.json').write_bytes(v.encoded(r));v.refresh_review(review)
 for name,raw in v.tree(review).items():(vault/('.review-'+name)).write_bytes(raw)
 (vault/'.source.json').write_bytes(v.encoded(snapshot))
 r=json.loads((vault/'flow.json').read_bytes());r['binding']=selected['binding'];r['review_ir_fingerprint']=v.fingerprint((review/'process-ir.json').read_bytes())
 r['inputs']={name:v.fingerprint((vault/name).read_bytes()) for name in r['inputs']}
 (vault/'flow.json').write_bytes(v.encoded(r));v.refresh_flow(vault)
for kind in ['raw-normalization','truncated-negative-tail']:
 folder=root/kind;shutil.copytree(source,folder);project=folder/'project'
 db=sqlite3.connect(project/'project.sqlite');db.row_factory=sqlite3.Row;version=dict(db.execute('SELECT * FROM source_versions').fetchone());cache=project/'.noetome-sources'/version['version_id']
 if kind=='raw-normalization':
  raw='这不是规范缓存中的过程来源。\n'.encode();(cache/'raw.bin').write_bytes(raw)
  db.execute('UPDATE source_versions SET content_sha256=?, byte_length=?',(v.fingerprint(raw)['sha256'],len(raw)))
 else:
  raw=(cache/'raw.bin').read_bytes()+'关系 r3：s1 不导致 s3。条件：[]。例外：[]。\n'.encode()
  (cache/'raw.bin').write_bytes(raw);(cache/'normalized.txt').write_bytes(raw)
  db.execute('UPDATE source_versions SET content_sha256=?, byte_length=?, normalized_sha256=?',(v.fingerprint(raw)['sha256'],len(raw),v.fingerprint(raw)['sha256']))
  # Deliberately retain the old complete-looking six-line SQL span and its SHA.
 db.commit();db.close();sync_binding(folder)
 args=['check',folder/'project',folder/'case',folder/'review',folder/'profile.json',folder/'Vault',repo/'fixtures/process-flow-v1/expected-linear.json']
 protect=[folder/'project',folder/'case',folder/'review',folder/'Vault']
 command(kind+'-before',[sys.executable,old/'verify_process_flow.py',*args],[0])
 command(kind+'-after',[sys.executable,current,*args],[1])
 command(kind+'-rust',[cli,'knowledge','flow',folder/'project',folder/'case',folder/'review',folder/'profile.json',folder/'rust-rejected'],[2,3])
 assert not (folder/'rust-rejected').exists()
# Fresh ordinary import with nonzero selection, author unit bytes frozen before calls.
positive=root/'prefixed-positive';positive.mkdir();project=positive/'project';case=positive/'case';case.mkdir()
raw='# 前置标题\n\n'.encode()+(repo/'fixtures/process-flow-v1/linear.txt').read_bytes()
source_path=positive/'source.txt';source_path.write_bytes(raw);gold=(repo/'fixtures/process-flow-v1/gold-linear.json').read_bytes();(case/'gold.json').write_bytes(gold)
profile=positive/'profile.json';profile.write_bytes((repo/'fixtures/process-flow-v1/profile-obsidian_1_6_7_flowchart.json').read_bytes())
v.save(positive/'frozen-before-cli.json',{'source':v.fingerprint(raw),'gold':v.fingerprint(gold),'expected':v.fingerprint((repo/'fixtures/process-flow-v1/expected-linear.json').read_bytes()),'selection':[{'kind':'text','ordinal':2}]})
protect=[];command('prefixed-project',[cli,'project','init',project],[0]);imported=command('prefixed-import',[cli,'source','import',project,source_path],[0]);iid=json.loads(imported.stdout)['import_id']
selected=v.actual_source(project,iid,{'kind':'text','ordinal':2});assert selected['units'][0]['text'].encode()==(repo/'fixtures/process-flow-v1/linear.txt').read_bytes()
v.save(case/'process-review.json',dict(schema_version=1,purpose='process_source_review',project_id=selected['binding']['project_id'],import_id=iid,selection=[{'kind':'text','ordinal':2}],gold_file='gold.json',gold_sha256=v.fingerprint(gold)['sha256']))
protect=[project,case];review=positive/'review';vault=positive/'Vault';command('prefixed-review',[cli,'knowledge','process-review',project,case,review],[0])
protect=[project,case,review];command('prefixed-flow',[cli,'knowledge','flow',project,case,review,profile,vault],[0])
protect=[project,case,review,vault];command('prefixed-independent-check',[sys.executable,current,'check',project,case,review,profile,vault,repo/'fixtures/process-flow-v1/expected-linear.json'],[0])
protect=[];command('targeted-python',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_verify_process_flow.py','-v'],[0])
result=dict(status='passed',root=str(root),commands=commands,cli=v.fingerprint(cli.read_bytes()),checker=v.fingerprint(current.read_bytes()),tests=v.fingerprint((repo/'tests/test_verify_process_flow.py').read_bytes()),counts={'targeted_python_tests':28,'commands':len(commands),'new_ordinary_positive_cli':4},scope='Focused original forgeries and raw-derived-source proof; no second full audit')
v.save(root/'result.json',result);print(json.dumps({k:result[k] for k in ['status','root','counts','checker','tests']},ensure_ascii=False,indent=2))
