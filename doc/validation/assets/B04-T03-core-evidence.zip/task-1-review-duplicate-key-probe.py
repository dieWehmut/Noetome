import hashlib,json,pathlib,subprocess
SDK=pathlib.Path(__file__).resolve().parent
e=json.loads((SDK/'task-1-review-evidence.json').read_text(encoding='utf-8'))
prior=e['focused_probe']['calls'][-1]
root=pathlib.Path(prior['root']).parent/'duplicate_json_atoms_count_corrected'
case=root/'case'
case.mkdir(parents=True)
baseline=pathlib.Path(e['focused_probe']['calls'][0]['root'])/'case'
for kind in ['gold','review']:
    (case/(kind+'.json')).write_bytes((baseline/(kind+'.json')).read_bytes())
candidate=json.loads((baseline/'candidates.json').read_bytes())
candidate['payload']['atoms'][0]['measurement']['value']='10'
decision=json.loads((baseline/'decision.json').read_bytes())
decision['disposition']='included'
(case/'decision.json').write_text(json.dumps(decision,ensure_ascii=False),encoding='utf-8')
payload=json.dumps(candidate['payload'],ensure_ascii=False)
bad=json.dumps(candidate,ensure_ascii=False).replace(payload,payload[:-1]+', "atoms": []}',1)
# Verify fixture setup preserves two payload atoms keys in otherwise readable JSON.
assert bad.count('"atoms"')==2
assert json.loads(bad)['payload']['atoms']==[]
(case/'candidates.json').write_text(bad,encoding='utf-8')
cmd=prior['command'][:-2]+[str(case),str(root/'output')]
run=subprocess.run(cmd,capture_output=True,timeout=40)
(root/'stdout.json').write_bytes(run.stdout)
(root/'stderr.txt').write_bytes(run.stderr)
(root/'exit.txt').write_text(str(run.returncode),encoding='utf-8')
r=json.loads(run.stdout)
checks=[{'name':'corrected_duplicate_key:'+n,'passed':v} for n,v in [
 ('fixture_valid_json',json.loads(bad)['payload']['atoms']==[]),
 ('fixture_duplicate_atoms',bad.count('"atoms"')==2),
 ('exit3',run.returncode==3),
 ('no_ir',not (root/'output/knowledge-ir.json').exists()),
 ('zero_count_bug_reproduced',r['totals']['candidate_atoms']==0 and r['candidate_results']==[]),
 ('schema_rejected', 'VERIFY_SCHEMA' in r['expected_results'][0]['issue_codes'])]]
e['checks'].extend(checks)
e['focused_probe']['setup_correction']='Initial duplicate-key probe appended at the end of the outer object instead of payload and produced malformed JSON. Its failed zero-count assertion is retained. Corrected probe verifies JSON readability and two payload atoms keys before execution.'
e['focused_probe']['corrected_duplicate_key']={'command':cmd,'exit':run.returncode,'root':str(root),'totals':r['totals'],'assertions':checks}
for p in root.rglob('*'):
    if p.is_file():
        b=p.read_bytes()
        e['fingerprints'][str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
e['assertion_count']=len(e['checks'])
e['assertions_passed']=sum(c['passed'] for c in e['checks'])
(SDK/'task-1-review-evidence.json').write_text(json.dumps(e,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'assertions':e['assertion_count'],'passed':e['assertions_passed'],'result':e['focused_probe']['corrected_duplicate_key']},ensure_ascii=True,indent=2))
