import copy, hashlib, json, pathlib, subprocess, uuid, zipfile

SDK = pathlib.Path(__file__).resolve().parent
ROOT = SDK.parents[2]
binary = ROOT/'target/debug/noetome.exe'
evidence = json.loads((SDK/'task-1-review-evidence.json').read_text(encoding='utf-8'))
archive = zipfile.ZipFile(SDK/'task-1-cli-evidence.zip')
manifest = json.loads((SDK/'task-1-cli-evidence-manifest.json').read_text(encoding='utf-8-sig'))
selected = next(r for r in evidence['rows'] if r['status']=='passed' and r['gold_value_status']=='known' and r['totals']['additional_source_concepts']==0)
record = next(r for r in manifest['roots'] if pathlib.PureWindowsPath(r['root']).name==selected['root'])
project = pathlib.Path(record['root'])/'source 中文'
def fingerprint(p):
    b=p.read_bytes()
    return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'mtime_ns':p.stat().st_mtime_ns}
def snapshot():
    return {str(p.relative_to(project)):fingerprint(p) for p in project.rglob('*') if p.is_file()}
source_before = snapshot()
binary_before = fingerprint(binary)
scratch = SDK/('task-1-review-probes-'+str(uuid.uuid4()))
scratch.mkdir()
prefix=selected['root']+'/review inputs/'
raw={kind:archive.read(prefix+kind+'.json') for kind in ['review','gold','decision','candidates']}
original=json.loads(raw['candidates'])
calls=[]
assertions=[]
def check(name,result):
    assertions.append({'name':name,'passed':bool(result)})
for variant in ['pending_wrong_fact','needs_review_wrong_fact','duplicate_id_borrows_conditions','duplicate_json_atoms_count']:
    runroot=scratch/variant
    case=runroot/'case'
    case.mkdir(parents=True)
    candidate=copy.deepcopy(original)
    decision=json.loads(raw['decision'])
    if variant in ['pending_wrong_fact','needs_review_wrong_fact']:
        decision['disposition']='pending' if variant.startswith('pending') else 'needs_review'
        candidate['payload']['atoms'][0]['measurement']['value']='11'
    elif variant=='duplicate_id_borrows_conditions':
        good=copy.deepcopy(candidate['payload']['atoms'][0])
        candidate['payload']['atoms'][0]['measurement']['conditions']=[]
        candidate['payload']['atoms'][0]['atom']['qualifiers']=['m/s','结冰时不适用']
        candidate['payload']['atoms'].append(good)
    candidate_bytes=json.dumps(candidate,ensure_ascii=False).encode()
    if variant=='duplicate_json_atoms_count':
        candidate_bytes=candidate_bytes[:-2]+b', "atoms": []}}'
    for kind in ['review','gold']:
        (case/(kind+'.json')).write_bytes(raw[kind])
    (case/'decision.json').write_text(json.dumps(decision,ensure_ascii=False),encoding='utf-8')
    (case/'candidates.json').write_bytes(candidate_bytes)
    before={p.name:fingerprint(p) for p in case.iterdir()}
    command=[str(binary),'extract','verify',str(project),original['binding']['import_id'],str(case),str(runroot/'output')]
    run=subprocess.run(command,capture_output=True,timeout=40)
    (runroot/'stdout.json').write_bytes(run.stdout)
    (runroot/'stderr.txt').write_bytes(run.stderr)
    (runroot/'exit.txt').write_text(str(run.returncode),encoding='utf-8')
    report=json.loads(run.stdout)
    check(variant+':exit3',run.returncode==3)
    check(variant+':no_ir',not (runroot/'output/knowledge-ir.json').exists())
    check(variant+':inputs_unchanged',before=={p.name:fingerprint(p) for p in case.iterdir()})
    check(variant+':stderr_empty',not run.stderr)
    if variant.endswith('wrong_fact'):
        check(variant+':failed_fact_check',any(c['category']=='fact' and c['status']=='failed' for c in report['checks']))
        check(variant+':confirmed_erased_fact_failure',report['quality']['fact']['failed']==0)
    elif variant=='duplicate_id_borrows_conditions':
        checks=[c for c in report['checks'] if c['category']=='condition']
        check(variant+':confirmed_primary_failed',all(c['status']=='failed' for c in checks[:2]))
        check(variant+':confirmed_borrowed_passes',report['quality']['condition']['passed']==2 and report['quality']['condition']['failed']==0)
    else:
        check(variant+':contains_duplicate_keys',candidate_bytes.count(b'"atoms"')==2)
        check(variant+':confirmed_zero_count',report['totals']['candidate_atoms']==0 and report['candidate_results']==[])
    calls.append({'variant':variant,'command':command,'exit':run.returncode,'root':str(runroot),'status':report['status'],'totals':report['totals'],'quality_fact':report['quality']['fact'],'quality_condition':report['quality']['condition'],'candidate_results':report['candidate_results'],'expected_result':report['expected_results'][0]})
check('synthetic_source_unchanged',snapshot()==source_before)
check('binary_unchanged',fingerprint(binary)==binary_before)
evidence['focused_probe']={'reason':'Unanswered combinations: status precedence, duplicate-ID quality borrowing, duplicate-JSON count ambiguity. Existing ordinary CLI only; no suite/build/network/live input.', 'calls':calls,'assertions':assertions,'source_project':str(project),'source_snapshot_before':source_before,'source_snapshot_after':snapshot(),'binary_before':binary_before,'binary_after':fingerprint(binary)}
evidence['checks'].extend(assertions)
evidence['assertion_count']=len(evidence['checks'])
evidence['assertions_passed']=sum(c['passed'] for c in evidence['checks'])
for p in scratch.rglob('*'):
    if p.is_file():
        evidence['fingerprints'][str(p)]=fingerprint(p)
evidence['scope']='Read-only Task1 exact f11100d..1d4793c code/index/HEAD; archived evidence audit plus four focused ordinary-CLI synthetic probes; only new SDK outputs. No build/suite/network/model/live/private access.'
(SDK/'task-1-review-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'assertions':evidence['assertion_count'],'passed':evidence['assertions_passed'],'calls':calls},ensure_ascii=False,indent=2))
