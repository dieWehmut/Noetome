import hashlib,json,pathlib
SDK=pathlib.Path(__file__).resolve().parent
ROOT=SDK.parents[2]
p=SDK/'task-1-review-evidence.json'
e=json.loads(p.read_text(encoding='utf-8'))
def fp(p):
    b=p.read_bytes()
    return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b),'mtime_ns':p.stat().st_mtime_ns}
def check(name,passed):
    e['checks'].append({'name':name,'passed':bool(passed)})
check('archive_aggregate_sha',fp(SDK/'task-1-cli-evidence.zip')['sha256']==e['archive_manifest_other_fields']['archive_sha256'])
check('binary_after_all_focused_probes',fp(ROOT/'target/debug/noetome.exe')==e['focused_probe']['binary_before'])
project=pathlib.Path(e['focused_probe']['source_project'])
after={str(q.relative_to(project)):fp(q) for q in project.rglob('*') if q.is_file()}
check('synthetic_source_after_all_focused_probes',after==e['focused_probe']['source_snapshot_before'])
e['focused_probe']['source_snapshot_after_final']=after
manifest=json.loads((SDK/'task-1-final-sha.json').read_text(encoding='utf-8-sig'))
check('all_owned_tested_files_unchanged_after_probes',all(all(fp(ROOT/name)[k]==v for k,v in item.items()) for name,item in manifest.items()))
for name in ['task-1-review-audit.py','task-1-review-probes.py','task-1-review-duplicate-key-probe.py','task-1-review-finalize.py','task-1-review.md']:
    e['fingerprints'][str(SDK/name)]=fp(SDK/name)
for name in ['crates/noetome-cli/src/sidecar_workspace.rs','crates/noetome-cli/src/extraction.rs']:
    e['fingerprints'][str(ROOT/name)]=fp(ROOT/name)
e['assertion_count']=len(e['checks'])
e['assertions_passed']=sum(c['passed'] for c in e['checks'])
e['assertion_definition']='Number of explicitly recorded predicate evaluations in checks. Two additional Python assert fixture preconditions also executed successfully in the corrected duplicate-key probe; these are not counted twice as they match recorded fixture_valid_json/fixture_duplicate_atoms checks.'
e['assessment']={'spec_compliance':'issues_found','code_quality':'needs_fixes','findings':[{'id':'R1','priority':2,'file':'crates/noetome-cli/src/extraction_review.rs','line':629},{'id':'R2','priority':2,'file':'crates/noetome-cli/src/extraction_review.rs','line':618},{'id':'R3','priority':2,'file':'crates/noetome-cli/src/extraction_verify.rs','line':288}],'retained_reviewer_setup_failures':1}
p.write_text(json.dumps(e,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'assertions':e['assertion_count'],'passed':e['assertions_passed'],'fingerprints':len(e['fingerprints']),'failed_checks':[c for c in e['checks'] if not c['passed']],'binary':fp(ROOT/'target/debug/noetome.exe')},ensure_ascii=True))
