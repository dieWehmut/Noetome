"""Preserve completed Task 1 evidence without deleting its SDD workspace."""
from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]
ASSETS = REPO / "doc" / "validation" / "assets"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def receipt(path: Path) -> dict:
    data = path.read_bytes()
    return {"sha256": digest(data), "byte_length": len(data)}


def main() -> None:
    copies = {
        "task-1-report.md": "B04-T03-core-implementation.md",
        "task-1-review.md": "B04-T03-core-review.md",
        "task-1-rereview-1.md": "B04-T03-core-fix-review.md",
        "task-1-red.log": "B04-T03-core-initial-red.log",
        "task-1-fix-1-red.log": "B04-T03-core-fix-red.log",
        "task-1-fix-1-integration.log": "B04-T03-core-final-integration.log",
        "task-1-final-guards.log": "B04-T03-core-guards.log",
        "task-1-fix-1-fmt.log": "B04-T03-core-fmt.log",
        "task-1-fix-1-check.log": "B04-T03-core-check.log",
    }
    archive = ASSETS / "B04-T03-core-evidence.zip"
    manifest = ASSETS / "B04-T03-core-assets-manifest.json"
    selected = sorted(p for p in SDK.glob("task-1*") if p.is_file())
    selected.extend(SDK / name for name in (
        "review-f11100d..1d4793c.diff",
        "review-1d4793c..3abed63.diff",
        "promote-core-evidence.py",
    ))
    before = {p.name: receipt(p) for p in selected}
    destinations = [archive, manifest, *(ASSETS / n for n in copies.values())]
    assert all(not p.exists() for p in destinations), "Evidence destinations must be new"
    assertions = []
    for original, target in copies.items():
        raw = (SDK / original).read_bytes()
        with (ASSETS / target).open("xb") as stream:
            stream.write(raw)
        assert (ASSETS / target).read_bytes() == raw, target
        assertions.append({"check": "copy_bytes_equal", "source": original, "target": target, "passed": True})
    with ZipFile(archive, "x", ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in selected:
            bundle.write(path, path.name)
    with ZipFile(archive) as bundle:
        assert len(bundle.namelist()) == len(before)
        assertions.append({"check": "archive_entry_count", "actual": len(bundle.namelist()), "expected": len(before), "passed": True})
        for name, expected in before.items():
            raw = bundle.read(name)
            assert {"sha256": digest(raw), "byte_length": len(raw)} == expected, name
            assertions.append({"check": "archive_entry_receipt", "entry": name, "passed": True})
    for path in selected:
        assert receipt(path) == before[path.name], path.name
        assertions.append({"check": "source_unchanged", "source": path.name, "passed": True})
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    document = {
        "schema_version": 1,
        "purpose": "preserve_completed_source_review_core_evidence",
        "head_at_promotion": head,
        "source_workspace": str(SDK),
        "source_entries": before,
        "archive": {"path": archive.name, **receipt(archive)},
        "readable_copies": {target: {"source": source, **receipt(ASSETS / target)} for source, target in copies.items()},
        "assertions": assertions,
        "checks": {"actual": len(assertions), "passed": sum(c["passed"] for c in assertions), "failed": 0},
        "original_sdd_workspace_retained": True,
        "network_calls": 0,
        "paid_calls": 0,
    }
    with manifest.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(document, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"archive": document["archive"], "entries": len(before), "copies": len(copies), "checks": document["checks"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
