"""Read-only scoped re-review of retained Task 1 Fix 1 evidence; no CLI/build run."""
import datetime
import hashlib
import json
import pathlib
import re
import zipfile

ROOT = pathlib.Path('D:/Noetome')
SDK = ROOT / '.superpowers/sdd/B04-T03_REVIEW_PLAN'
EVIDENCE = SDK / 'task-1-rereview-1-evidence.json'
checks = []
rows = []
fingerprints = {}
setup_events = [{
    'command': 'initial read-only archive metadata inspection (python -c)',
    'exit': 1,
    'cause': 'read_text used Windows GBK default for UTF8 manifest; UnicodeDecodeError',
    'resolution': 'explicit UTF8 reads and -X utf8; no product invocation or product assertion',
}, {
    'command': 'first scoped audit invocation',
    'exit': 1,
    'cause': 'RED manifest has binary_sha256 rather than GREEN archive_sha256; metadata KeyError',
    'resolution': 'check archive hash only where present; independently verify every RED member receipt',
    'partial_results': 'Incomplete audit attempt excluded from completed-run totals; no product failure.',
}, {
    'command': 'second scoped audit invocation',
    'exit': 1,
    'cause': 'Regex matched source fixture backticks inside the embedded JSON string',
    'resolution': 'Use JSON raw_decode after the opening Markdown JSON fence',
    'partial_results': 'Incomplete audit attempt excluded from completed-run totals; no product failure.',
}]

def receipt(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'byte_length': len(data)}

def read(path):
    data = path.read_bytes()
    fingerprints[str(path)] = receipt(data)
    return data

def check(label, actual, expected=True):
    checks.append({'name': label, 'actual': actual, 'expected': expected, 'passed': actual == expected})

protected_paths = [ROOT / p for p in (
    'target/debug/noetome.exe',
    'crates/noetome-cli/src/extraction_review.rs',
    'crates/noetome-cli/src/extraction_verify.rs',
    'crates/noetome-cli/tests/extraction_verify.rs',
    'doc/execution/B04-T03_REVIEW_PLAN.md',
    'doc/technical/EXTRACTION_REVIEW_CONTRACT.md',
    '.git/HEAD', '.git/index',
)]
head_text = (ROOT / '.git/HEAD').read_text(encoding='utf8').strip()
if head_text.startswith('ref: '):
    protected_paths.append(ROOT / '.git' / head_text[5:])
before = {str(p): {**receipt(read(p)), 'mtime_ns': p.stat().st_mtime_ns} for p in protected_paths}
check('HEAD matches bound Fix1 head', protected_paths[-1].read_text(encoding='utf8').strip(), '3abed632ff7e8533c90ec5cd92f462149da872de')
sha_claims = json.loads(read(SDK / 'task-1-fix-1-final-sha.json'))
for path, claim in sha_claims.items():
    check('current final receipt ' + path, receipt(read(ROOT / path)), claim)
check('binary explicit bound SHA', before[str(ROOT / 'target/debug/noetome.exe')]['sha256'], '5246e09d18fbff0b1404e3ba13a9fc52f9c61b02bc7fa7b6ad8066f83ec94326')
check('exact provided fix diff byte length', len(read(SDK / 'review-1d4793c..3abed63.diff')), 25301)

test_names = (
    'fix1_workflow_preserves_observed_category_failures',
    'fix1_source_and_unknown_review_preserve_known_condition_failure',
    'fix1_same_id_primary_checks_cannot_borrow_passes',
    'fix1_duplicate_json_keys_keep_actual_counts_unknown',
)
for phase, passed, failed, filtered in [('red', 0, 4, 20), ('green', 4, 0, 20), ('integration', 24, 0, 0)]:
    log = read(SDK / f'task-1-fix-1-{phase}.log').decode('utf8')
    for name in test_names:
        check(f'{phase}: {name} recorded outcome', f'test {name} ... ' + ('FAILED' if phase == 'red' else 'ok') in log)
    check(f'{phase}: summary', f'{passed} passed; {failed} failed; 0 ignored; 0 measured; {filtered} filtered out' in log)
check('retained fmt log empty', len(read(SDK / 'task-1-fix-1-fmt.log')), 0)
check('retained check log completion', 'Finished `dev` profile' in read(SDK / 'task-1-fix-1-check.log').decode('utf8'))

def parse_candidate(data):
    duplicates = []
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                duplicates.append(key)
            result[key] = value
        return result
    try:
        return json.loads(data, object_pairs_hook=pairs), duplicates, None
    except (ValueError, UnicodeDecodeError) as exc:
        return None, duplicates, str(exc)

for phase, count in [('red', 4), ('green', 48)]:
    manifest = json.loads(read(SDK / f'task-1-fix-1-{phase}-calls-manifest.json'))
    archive = SDK / f'task-1-fix-1-{phase}-calls.zip'
    archive_receipt = receipt(read(archive))
    if 'archive_sha256' in manifest:
        check(f'{phase}: archive hash', archive_receipt['sha256'], manifest['archive_sha256'])
    if 'binary_sha256' in manifest:
        check(f'{phase}: original reviewed RED binary', manifest['binary_sha256'], '6fdcbca416252b3e8d0cdcd36bb5208c77ff0c3f97dd21bedad32ddf8c266a7d')
    check(f'{phase}: report call count', len(manifest['calls']), count)
    with zipfile.ZipFile(archive) as z:
        expected_members = []
        for call in manifest['calls']:
            prefix = pathlib.PureWindowsPath(call['root']).name + '/'
            file_data = {}
            for name, claim in call['files'].items():
                member = prefix + name
                expected_members.append(member)
                file_data[name] = z.read(member)
                check(f'{phase}/{prefix}{name}: manifest receipt', receipt(file_data[name]), claim)
            report = json.loads(file_data['new output/verification.json'])
            candidate, duplicates, parse_error = parse_candidate(file_data['review inputs/candidates.json'])
            decision = json.loads(file_data['review inputs/decision.json'])
            gold = json.loads(file_data['review inputs/gold.json'])
            check(f'{phase}/{prefix}: CLI exit saved', int(file_data['cli-exit.txt']), call['exit'])
            check(f'{phase}/{prefix}: stdout JSON equals saved', json.loads(file_data['cli-stdout.json']), report)
            markdown = file_data['new output/verification.md'].decode('utf8')
            embedded = markdown.split('```json', 1)[1].lstrip()
            markdown_json, end = json.JSONDecoder().raw_decode(embedded)
            check(f'{phase}/{prefix}: Markdown JSON equals saved', markdown_json, report)
            check(f'{phase}/{prefix}: Markdown closing fence', embedded[end:].lstrip().startswith('```'))
            for name in ('candidates', 'decision', 'gold', 'review'):
                check(f'{phase}/{prefix}: original {name} bytes', file_data[f'new output/{name}-original.json'], file_data[f'review inputs/{name}.json'])
                # Avoid storing complete selected content in assertion records.
                checks[-1]['actual'] = receipt(checks[-1]['actual'])
                checks[-1]['expected'] = receipt(checks[-1]['expected'])
            for name, claim in report['artifacts'].items():
                check(f'{phase}/{prefix}: report artifact {name}', receipt(file_data['new output/' + name]), claim)
            check(f'{phase}/{prefix}: expected denominator', report['totals']['expected_atoms'], 1)
            check(f'{phase}/{prefix}: totals partition', sum(report['totals'][k] for k in ('passed', 'failed', 'needs_review', 'unprocessed')), 1)
            check(f'{phase}/{prefix}: no-IR gate', ('new output/knowledge-ir.json' in file_data), report['status'] == 'passed')
            for key, value in [('scientific_quality', 'not_run'), ('research_status', 'not_requested'), ('published', False), ('network_calls', 0), ('paid_calls', 0)]:
                check(f'{phase}/{prefix}: {key}', report[key], value)
            for category, q in report['quality'].items():
                check(f'{phase}/{prefix}: quality {category} partition', sum(q[k] for k in ('passed', 'failed', 'needs_review', 'unprocessed')), q['expected'])
                if phase == 'green':
                    state = 'not_applicable' if q['expected'] == 0 else 'failed' if q['failed'] else 'needs_review' if q['needs_review'] else 'unprocessed' if q['unprocessed'] else 'passed'
                    check(f'{phase}/{prefix}: quality {category} status precedence', q['status'], state)
            if call['exit'] == 0:
                ir = json.loads(file_data['new output/knowledge-ir.json'])
                for entity in ('atoms', 'concepts', 'evidence'):
                    check(f'{phase}/{prefix}: IR preserves {entity}', ir[entity], candidate['payload'][entity])
            row = {'phase': phase, 'root': call['root'], 'exit': call['exit'], 'command': call.get('command'), 'candidate_parse_error': parse_error,
                   'duplicate_keys': duplicates, 'disposition': decision['disposition'], 'source_status': report['scope']['units'][0]['source_status'],
                   'gold_unknown': gold.get('value_status') == 'unknown', 'totals': report['totals'], 'status': report['status'],
                   'quality': report['quality'], 'checks': report['checks'], 'candidate_results': report['candidate_results'], 'selectors': []}
            atoms = candidate.get('payload', {}).get('atoms', []) if isinstance(candidate, dict) else []
            first = atoms[0] if atoms else {}
            wrong_fact = first.get('measurement', {}).get('value') == '11' and gold.get('value') == '10'
            wrong_binding = candidate is not None and candidate.get('binding', {}).get('source_id') == 'wrong'
            if wrong_fact and decision['disposition'] in ('pending', 'needs_review'):
                row['selectors'].append('R1_wrong_fact_' + decision['disposition'])
                check(f'{phase}/{prefix}: R1 fact failed', report['quality']['fact']['failed'], 0 if phase == 'red' else 1)
                if phase == 'green':
                    check(f'{phase}/{prefix}: R1 observed evidence passed', report['quality']['evidence']['passed'], 1)
                    check(f'{phase}/{prefix}: R1 failed candidate retained', report['candidate_results'][0]['status'], 'failed')
            if wrong_binding and decision['disposition'] in ('pending', 'needs_review'):
                row['selectors'].append('R1_wrong_binding_' + decision['disposition'])
                if phase == 'green':
                    check(f'{phase}/{prefix}: R1 binding failed', report['quality']['binding']['failed'], 1)
                    check(f'{phase}/{prefix}: R1 binding candidate failed', report['candidate_results'][0]['status'], 'failed')
            if wrong_fact and row['source_status'] == 'needs_review':
                row['selectors'].append('R1_source_review_wrong_fact')
                check(f'{phase}/{prefix}: R1 source review fact failed', report['quality']['fact']['failed'], 0 if phase == 'red' else 1)
            if row['gold_unknown'] and first.get('measurement', {}).get('conditions') == [] and len(gold['conditions']) == 2:
                row['selectors'].append('R1_unknown_missing_conditions')
                if phase == 'green':
                    check(f'{phase}/{prefix}: R1 unknown retains known failures', report['quality']['condition']['failed'], 2)
                    check(f'{phase}/{prefix}: R1 unknown fact review', report['quality']['fact']['needs_review'], 1)
            if len(atoms) == 2 and atoms[0]['atom']['atom_id'] == atoms[1]['atom']['atom_id'] and atoms[0]['measurement']['conditions'] == []:
                row['selectors'].append('R2_same_ID_bad_primary_good_second')
                check(f'{phase}/{prefix}: R2 primary passes', report['quality']['condition']['passed'], 2 if phase == 'red' else 0)
                check(f'{phase}/{prefix}: R2 primary failures', report['quality']['condition']['failed'], 0 if phase == 'red' else 2)
                check(f'{phase}/{prefix}: R2 actual candidate count', report['totals']['candidate_atoms'], 2)
                check(f'{phase}/{prefix}: R2 duplicate count', report['totals']['duplicate_atoms'], 1)
                if phase == 'green':
                    check(f'{phase}/{prefix}: R2 second has no first condition diagnostic', 'VERIFY_CONDITION' not in report['candidate_results'][1]['issue_codes'])
            if duplicates and parse_error is None:
                row['selectors'].append('R3_readable_duplicate_' + '_'.join(sorted(set(duplicates))))
                if phase == 'green':
                    for key in ('candidate_atoms', 'unexpected_atoms', 'duplicate_atoms'):
                        check(f'{phase}/{prefix}: R3 {key} unknown', report['totals'][key], None)
                    check(f'{phase}/{prefix}: R3 no recovered objects', report['candidate_results'], [])
                    check(f'{phase}/{prefix}: R3 schema diagnostic', any(c['code'] == 'VERIFY_SCHEMA' for c in report['checks']))
                else:
                    check(f'{phase}/{prefix}: original R3 false zero reproduced', report['totals']['candidate_atoms'], 0)
            rows.append(row)
        check(f'{phase}: manifest covers all unique archive members', sorted(z.namelist()), sorted(expected_members))

required_selectors = ('R1_wrong_fact_pending', 'R1_wrong_fact_needs_review', 'R1_wrong_binding_pending', 'R1_wrong_binding_needs_review', 'R1_source_review_wrong_fact', 'R1_unknown_missing_conditions', 'R2_same_ID_bad_primary_good_second', 'R3_readable_duplicate_payload', 'R3_readable_duplicate_atoms')
for selector in required_selectors:
    check('GREEN archived coverage: ' + selector, any(selector in r['selectors'] for r in rows if r['phase'] == 'green'))
after = {str(p): {**receipt(p.read_bytes()), 'mtime_ns': p.stat().st_mtime_ns} for p in protected_paths}
for path, state in before.items():
    check('protected file unchanged: ' + path, after[path], state)
evidence = {
    'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': {'fix_base': '1d4793c4b1b6015c30735b65d8a1fcae5130ea09', 'head': '3abed632ff7e8533c90ec5cd92f462149da872de', 'CLI_invocations': 0, 'builds': 0, 'suite_reruns': 0},
    'command': 'python -X utf8 .superpowers/sdd/B04-T03_REVIEW_PLAN/task-1-rereview-1-audit.py',
    'setup_events': setup_events, 'protected_before': before, 'protected_after': after,
    'fingerprints': fingerprints, 'archive_rows': rows, 'assertions': checks,
    'totals': {'executed': len(checks), 'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks), 'archived_calls': len(rows)},
    'limitations': ['Only retained synthetic archives inspected; no original sixth input/PDF/private/network/model reads.', 'Archived logs examined and compared to recorded data; no suite run or source-project concurrency test.', 'Read-only source/index/HEAD; only this SDK audit and evidence files written.'],
}
EVIDENCE.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(evidence['totals']))
print(json.dumps([{'phase': r['phase'], 'root': r['root'], 'selectors': r['selectors']} for r in rows if r['selectors']], ensure_ascii=False))
for c in checks:
    if not c['passed']:
        print('FAILED ' + json.dumps(c, ensure_ascii=False))
raise SystemExit(1 if evidence['totals']['failed'] else 0)
