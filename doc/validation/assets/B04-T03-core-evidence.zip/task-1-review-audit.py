import hashlib, json, pathlib, re, zipfile

SDK = pathlib.Path(__file__).resolve().parent
ROOT = SDK.parents[2]
checks = []
fingerprints = {}
def check(name, result, detail=None):
    checks.append({'name': name, 'passed': bool(result), 'detail': detail})
def fp(data):
    return {'sha256': hashlib.sha256(data).hexdigest(), 'byte_length': len(data)}
def read(path):
    data = path.read_bytes()
    fingerprints[str(path)] = fp(data)
    return data
manifest = json.loads(read(SDK / 'task-1-final-sha.json'))
for name, expected in manifest.items():
    check('current_exact_tested_file:' + name, fp(read(ROOT / name)) == expected)
evidence_manifest = json.loads(read(SDK / 'task-1-cli-evidence-manifest.json'))
archive_bytes = read(SDK / 'task-1-cli-evidence.zip')
archive = zipfile.ZipFile(SDK / 'task-1-cli-evidence.zip')
rows = []
quality_mismatches = []
for root in evidence_manifest['roots']:
    prefix = pathlib.PureWindowsPath(root['root']).name
    for name, expected in root['files'].items():
        check('archive_fingerprint:' + prefix + '/' + name, fp(archive.read(prefix + '/' + name)) == expected)
    def get(name):
        return archive.read(prefix + '/' + name)
    report = json.loads(get('new output/verification.json'))
    candidate = json.loads(get('review inputs/candidates.json'))
    gold = json.loads(get('review inputs/gold.json'))
    decision = json.loads(get('review inputs/decision.json'))
    markdown = get('new output/verification.md').decode('utf-8')
    check('stdout_saved:' + prefix, json.loads(get('cli-stdout.json')) == report)
    check('dual_reports:' + prefix, json.loads(markdown.split('```json\n')[1].split('\n```')[0]) == report)
    check('exit:' + prefix, int(get('cli-exit.txt')) == root['exit'])
    check('empty_stderr:' + prefix, get('cli-stderr.txt') == b'')
    check('expected_denominator:' + prefix, report['totals']['expected_atoms'] == 1 and sum(report['totals'][k] for k in ['passed','failed','needs_review','unprocessed']) == 1)
    check('actual_count:' + prefix, report['totals']['candidate_atoms'] == len(candidate['payload']['atoms']))
    check('unpublished_scope:' + prefix, report['published'] is False and report['scientific_quality'] == 'not_run' and report['research_status'] == 'not_requested' and report['network_calls'] == 0 and report['paid_calls'] == 0)
    for kind in ['candidates','decision','gold','review']:
        check('preserved_input:' + prefix + '/' + kind, get('review inputs/' + kind + '.json') == get('new output/' + kind + '-original.json'))
    for name, expected in report['artifacts'].items():
        check('reported_fingerprint:' + prefix + '/' + name, fp(get('new output/' + name)) == expected)
    ir_name = prefix + '/new output/knowledge-ir.json'
    check('ir_only_passed:' + prefix, (ir_name in archive.namelist()) == (root['exit'] == 0))
    if ir_name in archive.namelist():
        ir = json.loads(archive.read(ir_name))
        check('ir_preserves_payload:' + prefix, all(ir[k] == candidate['payload'][k] for k in ['concepts','atoms','evidence']))
        check('ir_source_match:' + prefix, ir['source_match'] == 'passed' and ir['binding'] == report['binding'])
    for category, quality in report['quality'].items():
        check('quality_partition:' + prefix + '/' + category, sum(quality[k] for k in ['passed','failed','needs_review','unprocessed']) == quality['expected'])
        failed_checks = [c for c in report['checks'] if c['category'] == category and c['status'] == 'failed']
        if failed_checks and quality['expected'] and not quality['failed']:
            quality_mismatches.append({'root': prefix, 'category': category, 'quality': quality, 'failed_checks': failed_checks})
    rows.append({'root': prefix, 'status': report['status'], 'disposition': decision['disposition'], 'gold_value_status': gold.get('value_status','known'), 'source_status': report['scope']['units'][0]['source_status'], 'totals': report['totals'], 'issue_codes': report['expected_results'][0]['issue_codes']})
check('archived_run_count', len(rows) == 26)
logs = {}
for name, expected in [('task-1-final-integration-3.log', '20 passed; 0 failed'), ('task-1-final-guards.log','6 passed; 0 failed'), ('task-1-final-fmt.log',None), ('task-1-final-check.log','Finished `dev`'), ('task-1-red.log','10 failed')]:
    content = read(SDK / name).decode('utf-8-sig')
    logs[name] = content
    if expected:
        check('retained_log_summary:' + name, expected in content)
    if name != 'task-1-red.log':
        check('no_warning_in_final_log:' + name, re.search(r'(?im)^warning(?:\[|:)',content) is None)
diff = read(SDK / 'review-f11100d..1d4793c.diff').decode('utf-8-sig').splitlines()
line_map = {}
name = None
for line in diff:
    if line.startswith('+++ b/'):
        name = line[6:]
        line_map[name] = {}
    elif line.startswith('@@'):
        next_line = int(re.search(r'\+(\d+)', line).group(1))
    elif name and line and line[0] in ' +':
        line_map[name][next_line] = line[1:]
        next_line += 1
snippets = {}
for file, ranges in {
 'crates/noetome-cli/src/extraction_review.rs':[(550,648)],
 'crates/noetome-cli/src/extraction_verify.rs':[(273,340)],
}.items():
    snippets[file] = {str(n):s for n,s in line_map[file].items() if any(a<=n<=b for a,b in ranges)}
for name in ['task-1-review-brief.md','task-1-brief.md','task-1-report.md','task-1-red-sha.txt','task-1-hardlink-guard-red.log','task-1-sourcefact-red.log','task-1-evidence-red.log']:
    read(SDK/name)
read(ROOT/'doc/technical/EXTRACTION_REVIEW_CONTRACT.md')
read(ROOT/'doc/execution/B04-T03_REVIEW_PLAN.md')
out = {'scope':'read-only Task1 exact f11100d..1d4793c; archive audit only; no executable or tests rerun', 'assertion_count':len(checks),'assertions_passed':sum(c['passed'] for c in checks),'checks':checks,'fingerprints':fingerprints,'archive_manifest_other_fields':{k:v for k,v in evidence_manifest.items() if k!='roots'}, 'rows':rows,'quality_check_conflicts':quality_mismatches,'verified_diff_lines':snippets}
(SDK/'task-1-review-evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'assertions':len(checks),'passed':sum(c['passed'] for c in checks),'rows':len(rows),'quality_conflicts':[{k:v for k,v in x.items() if k!='failed_checks'} for x in quality_mismatches], 'diff_lines':snippets},ensure_ascii=False,indent=2))
