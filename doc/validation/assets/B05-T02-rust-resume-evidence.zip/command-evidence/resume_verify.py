from pathlib import Path
import hashlib, json, os, re, subprocess, time
base=Path('D:/Noetome'); plan=base/'.superpowers/sdd/B05-T02_VARIANTS_PLAN'
python='C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
env=os.environ.copy(); env['NOETOME_TEST_PYTHON']=python; env['NOETOME_PDF_PYTHON']=python
def pin(path):
    b=Path(path).read_bytes(); return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
tracked=subprocess.check_output(['git','ls-files','-z','crates','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','scripts/cargo_local.ps1'],cwd=base).decode().split('\0')
files={str(base/n) for n in tracked if n}
files.update(str(p) for p in (base/'crates').rglob('*.rs'))
def snapshot(): return {p:pin(p) for p in sorted(files)}
result={'python_env':{k:env[k] for k in ['NOETOME_TEST_PYTHON','NOETOME_PDF_PYTHON']},'test_threads':4,'before':snapshot(),'commands':[]}
for name, command in [('fmt',"& './scripts/cargo_local.ps1' fmt --all --check"),('check',"& './scripts/cargo_local.ps1' check --workspace"),('workspace',"& './scripts/cargo_local.ps1' test --workspace '--' --test-threads=4 --nocapture")]:
    argv=['powershell.exe','-NoProfile','-Command',command]; start=time.time()
    stdout=plan/f'task-1-resume-{name}.stdout.txt'; stderr=plan/f'task-1-resume-{name}.stderr.txt'
    print(f'START {name}: {command}',flush=True)
    with stdout.open('wb') as out, stderr.open('wb') as err:
        p=subprocess.run(argv,cwd=base,env=env,stdout=out,stderr=err)
    elapsed=time.time()-start
    (plan/f'task-1-resume-{name}.exit').write_text(str(p.returncode))
    result['commands'].append({'argv':argv,'cwd':str(base),'start_unix':start,'elapsed_seconds':elapsed,'exit':p.returncode,'stdout':{'path':str(stdout),**pin(stdout)},'stderr':{'path':str(stderr),**pin(stderr)}})
    print(f'END {name}: exit={p.returncode}, seconds={elapsed:.2f}',flush=True)
    if p.returncode: break
result['after']=snapshot(); result['sources_unchanged']=result['before']==result['after']; result['cli']=pin(base/'target/debug/noetome.exe')
log=(plan/'task-1-resume-workspace.stdout.txt').read_text(encoding='utf-8-sig') if (plan/'task-1-resume-workspace.stdout.txt').exists() else ''
result['suites']=re.findall(r'test result: (.+)',log)
roots=[]
for m in re.finditer(r'prepared_variants_root=(.+?) case=(\S+)',log):
    root=Path(m[1]); before=json.loads((root/'protection-before.json').read_text(encoding='utf-8')); after=json.loads((root/'protection-after.json').read_text(encoding='utf-8'))
    assert before==after,str(root)
    for path,expected in after.items(): assert pin(path)==expected,path
    commands={}
    for p in root.glob('*-argv.json'):
        label=p.name[:-10]
        commands[label]={'argv':json.loads(p.read_text(encoding='utf-8')),'exit':int((root/f'{label}-exit.txt').read_text()),'files':{str(root/f'{label}-{n}'):pin(root/f'{label}-{n}') for n in ['argv.json','stdout.txt','stderr.txt','exit.txt']}}
    roots.append({'root':str(root),'case':m[2],'cli_sha256':(root/'cli-sha256.txt').read_text(),'commands':commands,'protected':after})
result['roots']=roots; result['root_count']=len(roots); result['root_cli_hashes']=sorted({r['cli_sha256'] for r in roots})
(plan/'task-1-resume-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['before','after','roots']},ensure_ascii=False,indent=2),flush=True)
