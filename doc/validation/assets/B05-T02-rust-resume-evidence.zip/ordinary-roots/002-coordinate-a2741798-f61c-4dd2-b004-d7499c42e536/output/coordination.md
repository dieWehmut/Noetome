# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：1。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "3e308e2e-cb5a-4bd2-ba69-5d7cc95a8458",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
        "import_id": "44aeff03-387f-452b-8d76-c97c584d2ce9",
        "source_id": "bf343314-82c4-4511-85f7-1cc1b123a42c",
        "version_id": "9f93ac45-44c9-48d9-9a31-877fa756155e",
        "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "import_id": "44aeff03-387f-452b-8d76-c97c584d2ce9",
              "manifest_sha256": null,
              "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "parse_id": null,
              "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
              "source_id": "bf343314-82c4-4511-85f7-1cc1b123a42c",
              "version_id": "9f93ac45-44c9-48d9-9a31-877fa756155e"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "import_id": "44aeff03-387f-452b-8d76-c97c584d2ce9",
              "manifest_sha256": null,
              "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
              "parse_id": null,
              "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
              "source_id": "bf343314-82c4-4511-85f7-1cc1b123a42c",
              "version_id": "9f93ac45-44c9-48d9-9a31-877fa756155e"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 275,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 276,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 275,
            "excerpt_sha256": "830b3266cbe04a521fc58d6c6e0260b9fb1e369940eb75fe11abf0fe17fdbc6b",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 196,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 85
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 275,
              "excerpt_sha256": "830b3266cbe04a521fc58d6c6e0260b9fb1e369940eb75fe11abf0fe17fdbc6b",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "ef84da7b32834f2aeeb5c1c8b4766d234844c468656cee018dd1b89706b5b8c6",
          "byte_length": 3166
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
          "byte_length": 743
        },
        "knowledge-ir.json": {
          "sha256": "02fd801add93d359b76fc1364c99803bc5d82605771cb12788e101c93229e8b3",
          "byte_length": 12722
        },
        "review-original.json": {
          "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "61ef9930a7df7e8f9190affeae29cdcf5f746d4fb6d865e5a5bbbd2551c6a2b6",
          "byte_length": 1168
        },
        "verification.json": {
          "sha256": "3390156446ec59ae238dc3d25aee2e3f3a738dc6c23b33707c7491f27e07349d",
          "byte_length": 17199
        },
        "verification.md": {
          "sha256": "a58555441ffe78dedbbb6ffd760ada8fd32b3795acc64db73f2016addb406038",
          "byte_length": 17633
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
        "import_id": "0c8d8565-23b7-4d89-85d4-683747dbfff3",
        "source_id": "e77a331b-7226-4fb1-9131-38fa4e979967",
        "version_id": "9c71ff0c-b3b1-47b6-8fff-84cc1176cba4",
        "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "import_id": "0c8d8565-23b7-4d89-85d4-683747dbfff3",
              "manifest_sha256": null,
              "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "parse_id": null,
              "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
              "source_id": "e77a331b-7226-4fb1-9131-38fa4e979967",
              "version_id": "9c71ff0c-b3b1-47b6-8fff-84cc1176cba4"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "import_id": "0c8d8565-23b7-4d89-85d4-683747dbfff3",
              "manifest_sha256": null,
              "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
              "parse_id": null,
              "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
              "source_id": "e77a331b-7226-4fb1-9131-38fa4e979967",
              "version_id": "9c71ff0c-b3b1-47b6-8fff-84cc1176cba4"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 276,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 277,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 276,
            "excerpt_sha256": "839f7bf75f7a23164b97d31d933c0f329a1e404c27803ea147f03712b3ef004e",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 197,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 85
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 276,
              "excerpt_sha256": "839f7bf75f7a23164b97d31d933c0f329a1e404c27803ea147f03712b3ef004e",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 277,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "25996fcacc5858c1db460926e18d61c5d8ad94374f83925904ebc9a4d8b0f768",
          "byte_length": 3169
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "348ff4ede1d58727c1a5f036aaab2e463402b5c37fa2628e96c7bd52d0e6eb6f",
          "byte_length": 12733
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "0f2f236fb6e1540c5cc119d07f3d85773497dc749c0a83a7aa9b4f06fa6ca678",
          "byte_length": 1169
        },
        "verification.json": {
          "sha256": "9bbb646980b0b93ecbb96d850585b402673d435709217c0a83f764ecfbaa9634",
          "byte_length": 17208
        },
        "verification.md": {
          "sha256": "7b08a0286a88fbbb53640568d6b0e59e802eb6b9b7e49ada06c89492ec197686",
          "byte_length": 17642
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 32,
        "end_byte": 196,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-089e0e89782debcf2fbaa614ee144ae536ff052912c8a56d2605f505c3cd11e4",
      "input_id": "a",
      "binding": {
        "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
        "import_id": "44aeff03-387f-452b-8d76-c97c584d2ce9",
        "source_id": "bf343314-82c4-4511-85f7-1cc1b123a42c",
        "version_id": "9f93ac45-44c9-48d9-9a31-877fa756155e",
        "content_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "normalized_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "e5afa75a-a2dc-4ab5-ac0d-2ee4fe58d299",
          "ordinal": 0,
          "resource_sha256": "68b9a1f15ffb44ad02ca9c94098f36b7d03d5e2ecb0d99d57390c7d454816ef2"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 276,
        "text": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 275,
          "excerpt_sha256": "830b3266cbe04a521fc58d6c6e0260b9fb1e369940eb75fe11abf0fe17fdbc6b",
          "quote": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2024"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 32,
        "end_byte": 197,
        "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96"
      },
      "occurrence_id": "occ-8af7377f24ea36cb164c69612c373ec6a7cbf24b32e10154aef4d0865c8a80d6",
      "input_id": "b",
      "binding": {
        "project_id": "dbaea4de-f20e-4bb9-8575-7b63d97a933a",
        "import_id": "0c8d8565-23b7-4d89-85d4-683747dbfff3",
        "source_id": "e77a331b-7226-4fb1-9131-38fa4e979967",
        "version_id": "9c71ff0c-b3b1-47b6-8fff-84cc1176cba4",
        "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "483a9be8-eb83-4047-b889-11059c23b6e7",
          "ordinal": 0,
          "resource_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 277,
        "text": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 276,
          "excerpt_sha256": "839f7bf75f7a23164b97d31d933c0f329a1e404c27803ea147f03712b3ef004e",
          "quote": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2024"
      },
      "fact_id": "fact-v2-54940b4aa46cc077b253f0197434c586029bbcdd699ddf5bbb60d32c8c20f632",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-8af7377f24ea36cb164c69612c373ec6a7cbf24b32e10154aef4d0865c8a80d6"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-089e0e89782debcf2fbaa614ee144ae536ff052912c8a56d2605f505c3cd11e4"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": "occ-089e0e89782debcf2fbaa614ee144ae536ff052912c8a56d2605f505c3cd11e4",
      "later_occurrence_id": "occ-8af7377f24ea36cb164c69612c373ec6a7cbf24b32e10154aef4d0865c8a80d6",
      "left_occurrence_id": "occ-089e0e89782debcf2fbaa614ee144ae536ff052912c8a56d2605f505c3cd11e4",
      "right_occurrence_id": "occ-8af7377f24ea36cb164c69612c373ec6a7cbf24b32e10154aef4d0865c8a80d6",
      "relation": "historical_evolution",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 1,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "959097f821d4d511c3d214c2ae2c36fcec03a006263affa3cf8dbdebebde8ac6",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "b0e7973f3e06369ddc3e67a252e09f563cc282541813ba61aaddf70e41ec6186",
      "byte_length": 41299
    },
    "coordination-original.json": {
      "sha256": "21e713a55a6466f56afb1bfcefd04ce1d63ff242c05d64bc9a346732ed631f07",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "895a85645a1d0b1a27d10ca2ba23c33ee6228603c58a716335f847e2299294c6",
      "byte_length": 1908
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "ef84da7b32834f2aeeb5c1c8b4766d234844c468656cee018dd1b89706b5b8c6",
      "byte_length": 3166
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "input-a--knowledge-ir.json": {
      "sha256": "02fd801add93d359b76fc1364c99803bc5d82605771cb12788e101c93229e8b3",
      "byte_length": 12722
    },
    "input-a--review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "61ef9930a7df7e8f9190affeae29cdcf5f746d4fb6d865e5a5bbbd2551c6a2b6",
      "byte_length": 1168
    },
    "input-a--verification.json": {
      "sha256": "3390156446ec59ae238dc3d25aee2e3f3a738dc6c23b33707c7491f27e07349d",
      "byte_length": 17199
    },
    "input-a--verification.md": {
      "sha256": "a58555441ffe78dedbbb6ffd760ada8fd32b3795acc64db73f2016addb406038",
      "byte_length": 17633
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "25996fcacc5858c1db460926e18d61c5d8ad94374f83925904ebc9a4d8b0f768",
      "byte_length": 3169
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "348ff4ede1d58727c1a5f036aaab2e463402b5c37fa2628e96c7bd52d0e6eb6f",
      "byte_length": 12733
    },
    "input-b--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "0f2f236fb6e1540c5cc119d07f3d85773497dc749c0a83a7aa9b4f06fa6ca678",
      "byte_length": 1169
    },
    "input-b--verification.json": {
      "sha256": "9bbb646980b0b93ecbb96d850585b402673d435709217c0a83f764ecfbaa9634",
      "byte_length": 17208
    },
    "input-b--verification.md": {
      "sha256": "7b08a0286a88fbbb53640568d6b0e59e802eb6b9b7e49ada06c89492ec197686",
      "byte_length": 17642
    }
  }
}
```
