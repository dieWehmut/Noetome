# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：1；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "023a8eaf-992f-4db5-99c9-70fff7207068",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
        "import_id": "b8def870-3078-4e1b-9057-7e5f01025bda",
        "source_id": "0e6718c6-c9cb-4d40-98ef-7942e914ded7",
        "version_id": "21b1fae6-6c91-460e-b4dd-68398265bf61",
        "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "import_id": "b8def870-3078-4e1b-9057-7e5f01025bda",
              "manifest_sha256": null,
              "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "parse_id": null,
              "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
              "source_id": "0e6718c6-c9cb-4d40-98ef-7942e914ded7",
              "version_id": "21b1fae6-6c91-460e-b4dd-68398265bf61"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "import_id": "b8def870-3078-4e1b-9057-7e5f01025bda",
              "manifest_sha256": null,
              "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "parse_id": null,
              "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
              "source_id": "0e6718c6-c9cb-4d40-98ef-7942e914ded7",
              "version_id": "21b1fae6-6c91-460e-b4dd-68398265bf61"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 285,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 284,
            "excerpt_sha256": "0f6603d227f82cc21db3984395af4897171a8045f038bfcdff3623cc1c741a04",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 284,
              "excerpt_sha256": "0f6603d227f82cc21db3984395af4897171a8045f038bfcdff3623cc1c741a04",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "39f3aa67025cd09526fb17fbcb0a6e43169fbedf12bd8e93938fb4a00881b8cc",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
          "byte_length": 743
        },
        "knowledge-ir.json": {
          "sha256": "d9d42c6cf77f597d5a0fe9d654cad254e0fbfd9dd373edf1c920b9d623108a6c",
          "byte_length": 12749
        },
        "review-original.json": {
          "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "f2ae2684f1d3b82a244f7acad6affc8ed646acd00084a6b9c39cb336cfc486fd",
          "byte_length": 1177
        },
        "verification.json": {
          "sha256": "e14e18979292b9983a2c7357cdf15ae18a0826b80bb9048dc5638eba9dc961cc",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "3a1722ccdbfe3c4b4d4b3b16746d266ce442368a8bc1c59761a0c9e8822e8f3a",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
        "import_id": "c2b3f14d-58cb-4141-b488-fc32b3a4f4a6",
        "source_id": "1631b022-c59c-4797-b5bf-9817d2aa3df8",
        "version_id": "49350da0-b5c1-447b-a6bc-dd30e863b12e",
        "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "import_id": "c2b3f14d-58cb-4141-b488-fc32b3a4f4a6",
              "manifest_sha256": null,
              "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "parse_id": null,
              "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
              "source_id": "1631b022-c59c-4797-b5bf-9817d2aa3df8",
              "version_id": "49350da0-b5c1-447b-a6bc-dd30e863b12e"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "import_id": "c2b3f14d-58cb-4141-b488-fc32b3a4f4a6",
              "manifest_sha256": null,
              "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "parse_id": null,
              "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
              "source_id": "1631b022-c59c-4797-b5bf-9817d2aa3df8",
              "version_id": "49350da0-b5c1-447b-a6bc-dd30e863b12e"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 286,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 285,
            "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 206,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 285,
              "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "82b4ee03f424a004ede933efa75b44be6be3c911dd4e17cf6765d1716f607d08",
          "byte_length": 3178
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "d486b604f704b0c3598179536224b2ad261c3bd14051949022fcd6d43377d5c7",
          "byte_length": 12760
        },
        "review-original.json": {
          "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "f410fe241f01739122c83d0a71465b443e67ecd5f371d8f98cb818c0a815b432",
          "byte_length": 1178
        },
        "verification.json": {
          "sha256": "85ebd6eca0543ef7bc3ad6ba39629b254ff5d84bd3ef7916804af2ca2e83c310",
          "byte_length": 17235
        },
        "verification.md": {
          "sha256": "acfe490aa8cb0a182c5ed0277bb3755afac177330064d78ddac31ac65e2cf86f",
          "byte_length": 17669
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2024"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 206,
        "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "1fe6dcc3588adb0a02e23dfb1b14cae10a4bc68518ccba7a1c59b92c5cb6f25d"
      },
      "occurrence_id": "occ-bede7d64115e55bd7660086f993e29bb7c2135be9baa678c1378ff8c6454693c",
      "input_id": "b",
      "binding": {
        "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
        "import_id": "c2b3f14d-58cb-4141-b488-fc32b3a4f4a6",
        "source_id": "1631b022-c59c-4797-b5bf-9817d2aa3df8",
        "version_id": "49350da0-b5c1-447b-a6bc-dd30e863b12e",
        "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "2e9be987-c4fe-450b-b521-81fb8f6603e1",
          "ordinal": 0,
          "resource_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 286,
        "text": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 285,
          "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
          "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-d2680a65a380e1e7301b77ca696cab398d1533e846134be3f17b7f5eb3c51e01",
      "input_id": "a",
      "binding": {
        "project_id": "94ccce31-a2a0-4eab-8aeb-43c567483904",
        "import_id": "b8def870-3078-4e1b-9057-7e5f01025bda",
        "source_id": "0e6718c6-c9cb-4d40-98ef-7942e914ded7",
        "version_id": "21b1fae6-6c91-460e-b4dd-68398265bf61",
        "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "d1d58087-ccf5-4030-a440-a5b526733a5d",
          "ordinal": 0,
          "resource_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 285,
        "text": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 284,
          "excerpt_sha256": "0f6603d227f82cc21db3984395af4897171a8045f038bfcdff3623cc1c741a04",
          "quote": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2024"
      },
      "fact_id": "fact-v2-08b51ab24bb2ec1be6823093943d2b7568cd7b139692e8f22bf79f8a263d7015",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-bede7d64115e55bd7660086f993e29bb7c2135be9baa678c1378ff8c6454693c"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-d2680a65a380e1e7301b77ca696cab398d1533e846134be3f17b7f5eb3c51e01"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-bede7d64115e55bd7660086f993e29bb7c2135be9baa678c1378ff8c6454693c",
      "right_occurrence_id": "occ-d2680a65a380e1e7301b77ca696cab398d1533e846134be3f17b7f5eb3c51e01",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 1,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "7ad0e2e58d533b8a5cbfbce1db32bde14125348919c8bf8efba0f7c72adf2d63",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "2d1037d8627283e0ae715b0cf3876d840b5700bdd2218dfe1e785a0424edabe7",
      "byte_length": 41236
    },
    "coordination-original.json": {
      "sha256": "48fcace030ae0ea519e3f0c2266eb2c5f14fef6d52a014c17e74abc9f7b7f7db",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "895a85645a1d0b1a27d10ca2ba23c33ee6228603c58a716335f847e2299294c6",
      "byte_length": 1908
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "39f3aa67025cd09526fb17fbcb0a6e43169fbedf12bd8e93938fb4a00881b8cc",
      "byte_length": 3175
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "input-a--knowledge-ir.json": {
      "sha256": "d9d42c6cf77f597d5a0fe9d654cad254e0fbfd9dd373edf1c920b9d623108a6c",
      "byte_length": 12749
    },
    "input-a--review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "f2ae2684f1d3b82a244f7acad6affc8ed646acd00084a6b9c39cb336cfc486fd",
      "byte_length": 1177
    },
    "input-a--verification.json": {
      "sha256": "e14e18979292b9983a2c7357cdf15ae18a0826b80bb9048dc5638eba9dc961cc",
      "byte_length": 17226
    },
    "input-a--verification.md": {
      "sha256": "3a1722ccdbfe3c4b4d4b3b16746d266ce442368a8bc1c59761a0c9e8822e8f3a",
      "byte_length": 17660
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "82b4ee03f424a004ede933efa75b44be6be3c911dd4e17cf6765d1716f607d08",
      "byte_length": 3178
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "d486b604f704b0c3598179536224b2ad261c3bd14051949022fcd6d43377d5c7",
      "byte_length": 12760
    },
    "input-b--review-original.json": {
      "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "f410fe241f01739122c83d0a71465b443e67ecd5f371d8f98cb818c0a815b432",
      "byte_length": 1178
    },
    "input-b--verification.json": {
      "sha256": "85ebd6eca0543ef7bc3ad6ba39629b254ff5d84bd3ef7916804af2ca2e83c310",
      "byte_length": 17235
    },
    "input-b--verification.md": {
      "sha256": "acfe490aa8cb0a182c5ed0277bb3755afac177330064d78ddac31ac65e2cf86f",
      "byte_length": 17669
    }
  }
}
```
