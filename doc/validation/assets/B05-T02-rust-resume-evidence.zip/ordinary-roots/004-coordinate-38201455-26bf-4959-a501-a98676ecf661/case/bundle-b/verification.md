# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
      "import_id": "8a9f840d-d41f-4cfa-a642-88d2a14f7afd",
      "source_id": "42412dd3-a0fa-479c-85e4-f2f5f5a8cc82",
      "version_id": "8e9d2c4a-ba88-4013-8db4-f2e8c856e624",
      "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
      "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "de9f36ea-0108-4fae-95b1-71b5fd69c855",
          "ordinal": 0,
          "resource_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 208,
        "text": "公开自造资料 unknown_condition/b。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
    "import_id": "8a9f840d-d41f-4cfa-a642-88d2a14f7afd",
    "source_id": "42412dd3-a0fa-479c-85e4-f2f5f5a8cc82",
    "version_id": "8e9d2c4a-ba88-4013-8db4-f2e8c856e624",
    "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
    "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "2edebd4b54709fc12c3ab1b21cdf46fe70e67d568531e7355c5a5eabaa3d197d",
        "byte_length": 2839
      },
      "decision.json": {
        "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
        "byte_length": 502
      },
      "review.json": {
        "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
        "byte_length": 509
      }
    },
    "gold_sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "import_id": "8a9f840d-d41f-4cfa-a642-88d2a14f7afd",
          "manifest_sha256": null,
          "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "parse_id": null,
          "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
          "source_id": "42412dd3-a0fa-479c-85e4-f2f5f5a8cc82",
          "version_id": "8e9d2c4a-ba88-4013-8db4-f2e8c856e624"
        },
        "request_id": "synthetic-coordination-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "import_id": "8a9f840d-d41f-4cfa-a642-88d2a14f7afd",
          "manifest_sha256": null,
          "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "parse_id": null,
          "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
          "source_id": "42412dd3-a0fa-479c-85e4-f2f5f5a8cc82",
          "version_id": "8e9d2c4a-ba88-4013-8db4-f2e8c856e624"
        },
        "request_id": "synthetic-coordination-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 207,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 208,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 207,
        "excerpt_sha256": "7cf6421ad574c8a2346a0c802b7abd23941f58bf15094a64c78bed74491dfe6e",
        "excerpt_start_byte": 0,
        "quote": "公开自造资料 unknown_condition/b。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 128,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 97
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 207,
          "excerpt_sha256": "7cf6421ad574c8a2346a0c802b7abd23941f58bf15094a64c78bed74491dfe6e",
          "excerpt_start_byte": 0,
          "quote": "公开自造资料 unknown_condition/b。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "2edebd4b54709fc12c3ab1b21cdf46fe70e67d568531e7355c5a5eabaa3d197d",
      "byte_length": 2839
    },
    "decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
      "byte_length": 502
    },
    "knowledge-ir.json": {
      "sha256": "15e7a2d1213a25b83e1aab79d413d587dd82e057ea18cf7409ef32ddd327e895",
      "byte_length": 9647
    },
    "review-original.json": {
      "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "b7843a13f39e0cb06609bd849ebfb50abdf45866be547c92e59e14d435b2aa5f",
      "byte_length": 1100
    }
  }
}
```
