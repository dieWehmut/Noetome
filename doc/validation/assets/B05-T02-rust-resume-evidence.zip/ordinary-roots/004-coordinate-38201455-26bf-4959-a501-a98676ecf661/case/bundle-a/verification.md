# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
      "import_id": "2b1e67dd-9244-4d9c-9876-4cbf6d6d286c",
      "source_id": "8643ceb0-0cc8-4d6b-8dd4-a81dd0d93a91",
      "version_id": "73e319af-c24c-4f1b-8028-82d6d5ccea01",
      "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
      "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f454b09b-4e19-4734-beee-519148bbe241",
          "ordinal": 0,
          "resource_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 208,
        "text": "公开自造资料 unknown_condition/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
    "import_id": "2b1e67dd-9244-4d9c-9876-4cbf6d6d286c",
    "source_id": "8643ceb0-0cc8-4d6b-8dd4-a81dd0d93a91",
    "version_id": "73e319af-c24c-4f1b-8028-82d6d5ccea01",
    "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
    "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "16cc6da7b27cb051c2d208d973f2c3b9309c4c9b21a96f588b0355cfd8d701f2",
        "byte_length": 2839
      },
      "decision.json": {
        "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
        "byte_length": 502
      },
      "review.json": {
        "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
        "byte_length": 509
      }
    },
    "gold_sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
          "import_id": "2b1e67dd-9244-4d9c-9876-4cbf6d6d286c",
          "manifest_sha256": null,
          "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
          "parse_id": null,
          "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
          "source_id": "8643ceb0-0cc8-4d6b-8dd4-a81dd0d93a91",
          "version_id": "73e319af-c24c-4f1b-8028-82d6d5ccea01"
        },
        "request_id": "synthetic-coordination-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
          "import_id": "2b1e67dd-9244-4d9c-9876-4cbf6d6d286c",
          "manifest_sha256": null,
          "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
          "parse_id": null,
          "project_id": "15197746-750e-4a54-9cef-01c7b8166e9b",
          "source_id": "8643ceb0-0cc8-4d6b-8dd4-a81dd0d93a91",
          "version_id": "73e319af-c24c-4f1b-8028-82d6d5ccea01"
        },
        "request_id": "synthetic-coordination-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 207,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 208,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 207,
        "excerpt_sha256": "b7cbdeffa18274c1c32668898f838adadce22a4f2465cf93937ecf3bd2698d44",
        "excerpt_start_byte": 0,
        "quote": "公开自造资料 unknown_condition/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 128,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 97
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 207,
          "excerpt_sha256": "b7cbdeffa18274c1c32668898f838adadce22a4f2465cf93937ecf3bd2698d44",
          "excerpt_start_byte": 0,
          "quote": "公开自造资料 unknown_condition/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "16cc6da7b27cb051c2d208d973f2c3b9309c4c9b21a96f588b0355cfd8d701f2",
      "byte_length": 2839
    },
    "decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "4d4fa7a2f56dbdf183ebf8a2987fa7c3a57d0a03e0d9ec2ff5413e02ce61d7b8",
      "byte_length": 502
    },
    "knowledge-ir.json": {
      "sha256": "4e5334939d02bd2bd02734fe53003f8f88a74070c1f988e9d296545a70b44f94",
      "byte_length": 9647
    },
    "review-original.json": {
      "sha256": "00d530bb24417975f107a143a3873480224d48e82d7c5e7bb82553aafe22a58a",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "e2a5da343d028a0224a257d2d48883519b1f51320c06e2c5374dde3c7bb623c5",
      "byte_length": 1100
    }
  }
}
```
