# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：3；条件未知：0；条件不适用：0；时间已知：0；时间未知：3；条件并列关系：2；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "94eaf772-802b-4dba-ba11-c22f8f0250ca",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
        "import_id": "112c54c8-7556-43e3-a8e4-d9abe893a67d",
        "source_id": "efba5f24-1565-4b1a-b7f9-bf2748c36738",
        "version_id": "e7b689e2-e240-49e1-ac4d-b2ea59b2789b",
        "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "import_id": "112c54c8-7556-43e3-a8e4-d9abe893a67d",
              "manifest_sha256": null,
              "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "parse_id": null,
              "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
              "source_id": "efba5f24-1565-4b1a-b7f9-bf2748c36738",
              "version_id": "e7b689e2-e240-49e1-ac4d-b2ea59b2789b"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "import_id": "112c54c8-7556-43e3-a8e4-d9abe893a67d",
              "manifest_sha256": null,
              "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "parse_id": null,
              "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
              "source_id": "efba5f24-1565-4b1a-b7f9-bf2748c36738",
              "version_id": "e7b689e2-e240-49e1-ac4d-b2ea59b2789b"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "83defc8d94cc7d4e1e3a0da40a8517cfac51dd0f1fb8cb20c9ef0131170ac3d9",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "83defc8d94cc7d4e1e3a0da40a8517cfac51dd0f1fb8cb20c9ef0131170ac3d9",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "4b70bf446bbc4a3309ca8e16327c150a4b003518af5d2f339f82ddc297f10831",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "ac509f3d010befd0e2ff8658ae28d921e3770c84f2482a5032ffc54cf399fe19",
          "byte_length": 12751
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "140360177bdae4965bfa9127799ae852af58bc3e1b34aa0211142882a100a2ed",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "d536f1cc80c6754cdaa62c87f1da6c23da233fa61c217f5036e23c79a426f89f",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "e7b5c4cebb248bcbea5d07a222eab044557474fe8a106316de0e2fbc3359782b",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
        "import_id": "e52bbdf7-5bf7-456d-a94d-11fc696dbacc",
        "source_id": "32e49c7e-5a75-48b3-8c4a-923ff89cad98",
        "version_id": "b638ff02-1343-4eff-8cfc-6ec72cc764c0",
        "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "import_id": "e52bbdf7-5bf7-456d-a94d-11fc696dbacc",
              "manifest_sha256": null,
              "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "parse_id": null,
              "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
              "source_id": "32e49c7e-5a75-48b3-8c4a-923ff89cad98",
              "version_id": "b638ff02-1343-4eff-8cfc-6ec72cc764c0"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "import_id": "e52bbdf7-5bf7-456d-a94d-11fc696dbacc",
              "manifest_sha256": null,
              "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "parse_id": null,
              "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
              "source_id": "32e49c7e-5a75-48b3-8c4a-923ff89cad98",
              "version_id": "b638ff02-1343-4eff-8cfc-6ec72cc764c0"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "5f828c851399019d51fb59a567e958219d542c770634e6705d5a6375af1308d0",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "5f828c851399019d51fb59a567e958219d542c770634e6705d5a6375af1308d0",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "91a40ac23dbbe1e33b40d767f0ccfcbcdf50b1389af18a779bd28c4883b9460c",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "f0dcae8cf5a32970a5bc54ca7065f109837c05963e4fc4a3274d84ce7f9bfca9",
          "byte_length": 12751
        },
        "review-original.json": {
          "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "ff1b39139e1f8d5cbd92046b25da949cba85749b6259a890f51052db4211e6e9",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "ff7931ee067686676e5f6496f181133c9fe18b976b26b5daf224a977e5c50f9d",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "199cd3ebbc5daa1080e18ca184aabf0fe0ceb705108a10c22fa2cb79734edb3c",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
        "import_id": "30c35cb2-9b0f-4e45-bbfe-f057ac98c1a7",
        "source_id": "ac7581d5-0acb-49b2-a582-8c714d92c463",
        "version_id": "66fa995b-bd39-47b4-b985-b8e8e65ecef2",
        "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-speed"
            ],
            "decision": {
              "atom_ids": [
                "c-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "import_id": "30c35cb2-9b0f-4e45-bbfe-f057ac98c1a7",
              "manifest_sha256": null,
              "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "parse_id": null,
              "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
              "source_id": "ac7581d5-0acb-49b2-a582-8c714d92c463",
              "version_id": "66fa995b-bd39-47b4-b985-b8e8e65ecef2"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "import_id": "30c35cb2-9b0f-4e45-bbfe-f057ac98c1a7",
              "manifest_sha256": null,
              "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "parse_id": null,
              "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
              "source_id": "ac7581d5-0acb-49b2-a582-8c714d92c463",
              "version_id": "66fa995b-bd39-47b4-b985-b8e8e65ecef2"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "2754b0a31c97bba9a7ac62166898c287a30c9f6811eff7446b0a6db51f778599",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "2754b0a31c97bba9a7ac62166898c287a30c9f6811eff7446b0a6db51f778599",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "317fd618166120699c2c6e3c86ef8ccb2ee95a1061138a43f20f4f84cf88d416",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "e8e28e18c51e21762ecdb9f91f637c2601ad1e0caca730d570fffd731dba0782",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "307e8260902b3d085f916556b0634de4284d0ce1efd32b2a6140696424e24bf5",
          "byte_length": 12751
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "066fbc3d8946b703f44ecf345fe99f78ce2973ed07a9cd6fcf5ae84596ea58e0",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "fe62e04a1f6359cf5200ce113ef39da94178f803e3ff1865bda2127f60d9eb42",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "6d08ef8a69e7fa8875534f765c9080e72ddc5ac265b28dcc0d32bf2aa76f5cac",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "c-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-8cc007169726b5e7a0c2b0b323139374140046dc21c353d63e0c172076767040",
      "input_id": "c",
      "binding": {
        "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
        "import_id": "30c35cb2-9b0f-4e45-bbfe-f057ac98c1a7",
        "source_id": "ac7581d5-0acb-49b2-a582-8c714d92c463",
        "version_id": "66fa995b-bd39-47b4-b985-b8e8e65ecef2",
        "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "5d614fdf-625c-4341-af16-66d355594bac",
          "ordinal": 0,
          "resource_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "2754b0a31c97bba9a7ac62166898c287a30c9f6811eff7446b0a6db51f778599",
          "quote": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-b94e189526f3dbd6905dc7ad786723717e237eb034ddc3841ae088614984d5fb",
      "input_id": "a",
      "binding": {
        "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
        "import_id": "112c54c8-7556-43e3-a8e4-d9abe893a67d",
        "source_id": "efba5f24-1565-4b1a-b7f9-bf2748c36738",
        "version_id": "e7b689e2-e240-49e1-ac4d-b2ea59b2789b",
        "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4714fc70-3d4d-41a6-873d-1a670175ad41",
          "ordinal": 0,
          "resource_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "83defc8d94cc7d4e1e3a0da40a8517cfac51dd0f1fb8cb20c9ef0131170ac3d9",
          "quote": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "cbecd5de19d013b2f86072ed6fc2f4dff377bf6c6293c62d73f8a3205f40f288"
      },
      "occurrence_id": "occ-ff0874738c8b28dc02d3471867840009371cd58abcec89173d1cf0e0732424c9",
      "input_id": "b",
      "binding": {
        "project_id": "ece92c87-19b5-4e59-9bcd-fe1be3ef340b",
        "import_id": "e52bbdf7-5bf7-456d-a94d-11fc696dbacc",
        "source_id": "32e49c7e-5a75-48b3-8c4a-923ff89cad98",
        "version_id": "b638ff02-1343-4eff-8cfc-6ec72cc764c0",
        "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "ba11e6bf-a338-4022-a040-0b52533cfa7c",
          "ordinal": 0,
          "resource_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "5f828c851399019d51fb59a567e958219d542c770634e6705d5a6375af1308d0",
          "quote": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-37b85ca43695cab4ad15df81b37b0522781319aa80d8bfb70a34f7d38f961b87",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-ff0874738c8b28dc02d3471867840009371cd58abcec89173d1cf0e0732424c9"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-8cc007169726b5e7a0c2b0b323139374140046dc21c353d63e0c172076767040",
        "occ-b94e189526f3dbd6905dc7ad786723717e237eb034ddc3841ae088614984d5fb"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-8cc007169726b5e7a0c2b0b323139374140046dc21c353d63e0c172076767040",
      "right_occurrence_id": "occ-b94e189526f3dbd6905dc7ad786723717e237eb034ddc3841ae088614984d5fb",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-8cc007169726b5e7a0c2b0b323139374140046dc21c353d63e0c172076767040",
      "right_occurrence_id": "occ-ff0874738c8b28dc02d3471867840009371cd58abcec89173d1cf0e0732424c9",
      "relation": "condition_variant",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-b94e189526f3dbd6905dc7ad786723717e237eb034ddc3841ae088614984d5fb",
      "right_occurrence_id": "occ-ff0874738c8b28dc02d3471867840009371cd58abcec89173d1cf0e0732424c9",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 2,
    "historical_relations": 0,
    "known_condition_occurrences": 3,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 3,
    "context_evidence_links": 3,
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "9fb32d0981c7c1e1b02535b9bb5bf59c9ed5c7548ea573626cc4d04805d93c83",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "8f50d2035da20f7c11950f6ba41e34a191e25625d1e35c5974fa734fb2928de6",
      "byte_length": 61019
    },
    "coordination-original.json": {
      "sha256": "b5c02e00797df152cc6fccd4dc3810a4bfb25057a62b5cf718aa08b3ede9bfa7",
      "byte_length": 6400
    },
    "identity-original.json": {
      "sha256": "bc3986a29b0fd84acef17474657fad1dd9c0975d8a4d54e1ab8cd62257cccda0",
      "byte_length": 2650
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "4b70bf446bbc4a3309ca8e16327c150a4b003518af5d2f339f82ddc297f10831",
      "byte_length": 3175
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-a--knowledge-ir.json": {
      "sha256": "ac509f3d010befd0e2ff8658ae28d921e3770c84f2482a5032ffc54cf399fe19",
      "byte_length": 12751
    },
    "input-a--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "140360177bdae4965bfa9127799ae852af58bc3e1b34aa0211142882a100a2ed",
      "byte_length": 1175
    },
    "input-a--verification.json": {
      "sha256": "d536f1cc80c6754cdaa62c87f1da6c23da233fa61c217f5036e23c79a426f89f",
      "byte_length": 17226
    },
    "input-a--verification.md": {
      "sha256": "e7b5c4cebb248bcbea5d07a222eab044557474fe8a106316de0e2fbc3359782b",
      "byte_length": 17660
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "91a40ac23dbbe1e33b40d767f0ccfcbcdf50b1389af18a779bd28c4883b9460c",
      "byte_length": 3175
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "f0dcae8cf5a32970a5bc54ca7065f109837c05963e4fc4a3274d84ce7f9bfca9",
      "byte_length": 12751
    },
    "input-b--review-original.json": {
      "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "ff1b39139e1f8d5cbd92046b25da949cba85749b6259a890f51052db4211e6e9",
      "byte_length": 1175
    },
    "input-b--verification.json": {
      "sha256": "ff7931ee067686676e5f6496f181133c9fe18b976b26b5daf224a977e5c50f9d",
      "byte_length": 17226
    },
    "input-b--verification.md": {
      "sha256": "199cd3ebbc5daa1080e18ca184aabf0fe0ceb705108a10c22fa2cb79734edb3c",
      "byte_length": 17660
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "317fd618166120699c2c6e3c86ef8ccb2ee95a1061138a43f20f4f84cf88d416",
      "byte_length": 3175
    },
    "input-c--decision-original.json": {
      "sha256": "e8e28e18c51e21762ecdb9f91f637c2601ad1e0caca730d570fffd731dba0782",
      "byte_length": 140
    },
    "input-c--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-c--knowledge-ir.json": {
      "sha256": "307e8260902b3d085f916556b0634de4284d0ce1efd32b2a6140696424e24bf5",
      "byte_length": 12751
    },
    "input-c--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-c--source-snapshot.json": {
      "sha256": "066fbc3d8946b703f44ecf345fe99f78ce2973ed07a9cd6fcf5ae84596ea58e0",
      "byte_length": 1175
    },
    "input-c--verification.json": {
      "sha256": "fe62e04a1f6359cf5200ce113ef39da94178f803e3ff1865bda2127f60d9eb42",
      "byte_length": 17226
    },
    "input-c--verification.md": {
      "sha256": "6d08ef8a69e7fa8875534f765c9080e72ddc5ac265b28dcc0d32bf2aa76f5cac",
      "byte_length": 17660
    }
  }
}
```
