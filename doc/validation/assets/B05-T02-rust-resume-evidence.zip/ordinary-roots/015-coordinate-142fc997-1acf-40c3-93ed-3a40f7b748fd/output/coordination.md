# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：1；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "b3a3ba48-b255-4ef2-8d90-3b14afc7b373",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
        "import_id": "44156e12-77dc-4a2a-8a64-2723a032db5e",
        "source_id": "6fa08dbd-43e4-4edc-b4f4-cbad803db57d",
        "version_id": "0bb5f831-7651-42a6-a347-27e5feb04138",
        "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "import_id": "44156e12-77dc-4a2a-8a64-2723a032db5e",
              "manifest_sha256": null,
              "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "parse_id": null,
              "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
              "source_id": "6fa08dbd-43e4-4edc-b4f4-cbad803db57d",
              "version_id": "0bb5f831-7651-42a6-a347-27e5feb04138"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "import_id": "44156e12-77dc-4a2a-8a64-2723a032db5e",
              "manifest_sha256": null,
              "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "parse_id": null,
              "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
              "source_id": "6fa08dbd-43e4-4edc-b4f4-cbad803db57d",
              "version_id": "0bb5f831-7651-42a6-a347-27e5feb04138"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 292,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 291,
            "excerpt_sha256": "3a377d0c0047e61517140a9e9d81a22d0109226858c9c6ddff7c6ccf12635769",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 212,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 100
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 291,
              "excerpt_sha256": "3a377d0c0047e61517140a9e9d81a22d0109226858c9c6ddff7c6ccf12635769",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "f65caaebcd3b1a3c1a317b243b8e0f46ccd5c52942d09b1e004373eb4c0f377c",
          "byte_length": 3184
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "2bd72197c159ac5c6d569e4e50eb976ac4283dc942d6b7660504ed3762b977be",
          "byte_length": 12779
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "a2235c244cf0fdd47cd40757c7703b5889da86fe7a625e0238a9656a8d9795fb",
          "byte_length": 1184
        },
        "verification.json": {
          "sha256": "c1aa0697c21e18248a803e6360139133d335771721fe9f708ffe2fa5b2bbf964",
          "byte_length": 17254
        },
        "verification.md": {
          "sha256": "6bcd4974c34f213c6cfed42430785cfe7a1a7e706ebefcd71712891d35c1447f",
          "byte_length": 17688
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
        "import_id": "3de319c4-939c-4921-bd24-cc6b42cb6ba0",
        "source_id": "7e1e86ed-e274-47c0-ae8c-f28ce8c9b542",
        "version_id": "01c85461-b68d-4cb7-9bd9-0ff8d349ac69",
        "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "import_id": "3de319c4-939c-4921-bd24-cc6b42cb6ba0",
              "manifest_sha256": null,
              "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "parse_id": null,
              "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
              "source_id": "7e1e86ed-e274-47c0-ae8c-f28ce8c9b542",
              "version_id": "01c85461-b68d-4cb7-9bd9-0ff8d349ac69"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "import_id": "3de319c4-939c-4921-bd24-cc6b42cb6ba0",
              "manifest_sha256": null,
              "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "parse_id": null,
              "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
              "source_id": "7e1e86ed-e274-47c0-ae8c-f28ce8c9b542",
              "version_id": "01c85461-b68d-4cb7-9bd9-0ff8d349ac69"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 294,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 295,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 294,
            "excerpt_sha256": "9e245f4dd2db8acf71a8f7b80bfcf356e8ce941df42a4c82be669c1d376eb45c",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 215,
            "quote": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
            "start_byte": 100
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 294,
              "excerpt_sha256": "9e245f4dd2db8acf71a8f7b80bfcf356e8ce941df42a4c82be669c1d376eb45c",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "11",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "11",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "幼年样本不适用",
          "actual": {
            "body": [
              "幼年样本不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": [
            "幼年样本不适用"
          ],
          "actual": [
            "幼年样本不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "幼年样本不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "幼年样本不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "0f313ee422df701df6143b7b4408468166b5972df3cb8ad9c24da953215489ef",
          "byte_length": 3193
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "952f1d39f3ed1444ab44b74d5b66839b713e2685264b6bc10fb538e022a7c1c1",
          "byte_length": 755
        },
        "knowledge-ir.json": {
          "sha256": "7f57b965814fcfa8510b4f5f99dbf9af7931de59b0d795764e4dc711be49b7f3",
          "byte_length": 12836
        },
        "review-original.json": {
          "sha256": "0ef7ce30c38760beb99e57b534681b1454dfbef8d0b4303c7776a8b3753f5c0f",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "79fa23f3717d26f028cd04f8c180f46fe72cc54b8e2bd8f6dfb3b2140b5abe3b",
          "byte_length": 1187
        },
        "verification.json": {
          "sha256": "6e518c4e7172f1565b797db1b5c6b445b90322c03cdea81f85f63e476a985511",
          "byte_length": 17305
        },
        "verification.md": {
          "sha256": "49506556e5ba4c1f98f87aec427394704b3d54abf1e4bfd13f082cf1c0224062",
          "byte_length": 17739
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 45,
        "end_byte": 212,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-15dca9e5ef9f91d055b545a83ef508f421ea46ced242b38e7b819ea3034b2ca7",
      "input_id": "a",
      "binding": {
        "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
        "import_id": "44156e12-77dc-4a2a-8a64-2723a032db5e",
        "source_id": "6fa08dbd-43e4-4edc-b4f4-cbad803db57d",
        "version_id": "0bb5f831-7651-42a6-a347-27e5feb04138",
        "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "1f78b397-77aa-495c-91fc-7502c7d9d3a0",
          "ordinal": 0,
          "resource_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 292,
        "text": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 291,
          "excerpt_sha256": "3a377d0c0047e61517140a9e9d81a22d0109226858c9c6ddff7c6ccf12635769",
          "quote": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 45,
        "end_byte": 215,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
        "sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8"
      },
      "occurrence_id": "occ-3c59d8081f2fa013a335a702404c299e93b7cc6e5c26fddc8f391d956d97b128",
      "input_id": "b",
      "binding": {
        "project_id": "1fb27e1c-6ea9-4a92-b262-2e341c36db4a",
        "import_id": "3de319c4-939c-4921-bd24-cc6b42cb6ba0",
        "source_id": "7e1e86ed-e274-47c0-ae8c-f28ce8c9b542",
        "version_id": "01c85461-b68d-4cb7-9bd9-0ff8d349ac69",
        "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "eea997a1-6771-44d0-9b94-d683ce6379a6",
          "ordinal": 0,
          "resource_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 295,
        "text": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "幼年样本不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "11",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 294,
          "excerpt_sha256": "9e245f4dd2db8acf71a8f7b80bfcf356e8ce941df42a4c82be669c1d376eb45c",
          "quote": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "11",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "幼年样本不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-3d9b6cb1be4c6856351dcef0e60f859de01fed6d6985d4845f0b5a0425d50b6a",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "11",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "幼年样本不适用"
      ],
      "occurrence_ids": [
        "occ-3c59d8081f2fa013a335a702404c299e93b7cc6e5c26fddc8f391d956d97b128"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-15dca9e5ef9f91d055b545a83ef508f421ea46ced242b38e7b819ea3034b2ca7"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-15dca9e5ef9f91d055b545a83ef508f421ea46ced242b38e7b819ea3034b2ca7",
      "right_occurrence_id": "occ-3c59d8081f2fa013a335a702404c299e93b7cc6e5c26fddc8f391d956d97b128",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 1,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d0d63cdef1f4b2bcfb88a9a588f69c48ecbd7d1675772ba0f7d82c831e9c02a2",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "9c9a9f6ef7415f89bc7ccdbccee94a02861dafe48959b14474b8c1fc8ec41bc0",
      "byte_length": 41366
    },
    "coordination-original.json": {
      "sha256": "96023581ed591a55e7f577e2371f9051b3bb0e6a44c46b742c26211557e19bc8",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "6a9c406cd047139f73a34d3145d78466d685c02f672df19627b08179b91762fc",
      "byte_length": 1904
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "f65caaebcd3b1a3c1a317b243b8e0f46ccd5c52942d09b1e004373eb4c0f377c",
      "byte_length": 3184
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-a--knowledge-ir.json": {
      "sha256": "2bd72197c159ac5c6d569e4e50eb976ac4283dc942d6b7660504ed3762b977be",
      "byte_length": 12779
    },
    "input-a--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "a2235c244cf0fdd47cd40757c7703b5889da86fe7a625e0238a9656a8d9795fb",
      "byte_length": 1184
    },
    "input-a--verification.json": {
      "sha256": "c1aa0697c21e18248a803e6360139133d335771721fe9f708ffe2fa5b2bbf964",
      "byte_length": 17254
    },
    "input-a--verification.md": {
      "sha256": "6bcd4974c34f213c6cfed42430785cfe7a1a7e706ebefcd71712891d35c1447f",
      "byte_length": 17688
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "0f313ee422df701df6143b7b4408468166b5972df3cb8ad9c24da953215489ef",
      "byte_length": 3193
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "952f1d39f3ed1444ab44b74d5b66839b713e2685264b6bc10fb538e022a7c1c1",
      "byte_length": 755
    },
    "input-b--knowledge-ir.json": {
      "sha256": "7f57b965814fcfa8510b4f5f99dbf9af7931de59b0d795764e4dc711be49b7f3",
      "byte_length": 12836
    },
    "input-b--review-original.json": {
      "sha256": "0ef7ce30c38760beb99e57b534681b1454dfbef8d0b4303c7776a8b3753f5c0f",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "79fa23f3717d26f028cd04f8c180f46fe72cc54b8e2bd8f6dfb3b2140b5abe3b",
      "byte_length": 1187
    },
    "input-b--verification.json": {
      "sha256": "6e518c4e7172f1565b797db1b5c6b445b90322c03cdea81f85f63e476a985511",
      "byte_length": 17305
    },
    "input-b--verification.md": {
      "sha256": "49506556e5ba4c1f98f87aec427394704b3d54abf1e4bfd13f082cf1c0224062",
      "byte_length": 17739
    }
  }
}
```
