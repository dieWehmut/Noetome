"""Read immutable review inputs and saved receipts; does not rerun suites/audits."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

R=Path('D:/Noetome'); W=R/'.superpowers/sdd/B05-T02_VARIANTS_PLAN'
def fp(b): return dict(sha256=hashlib.sha256(b).hexdigest(),byte_length=len(b))
def read(p): return json.loads(Path(p).read_bytes())
def check_stream(s):
    actual=fp(Path(s['path']).read_bytes())
    assert actual=={k:s[k] for k in actual},s['path']
    return dict(path=s['path'],**actual)

package=read(W/'whole-branch-package.json'); evidence={}
evidence['range']={k:package[k] for k in ('base','head')}
evidence['package']={}
for key in ('full_package','review_code_package'):
    p=package[key]; actual=fp(Path(p['path']).read_bytes()); assert actual=={k:p[k] for k in actual}
    evidence['package'][key]=actual
blobs=[]
for name,pin in package['changed_files'].items():
    body=subprocess.check_output(['git','show',package['head']+':'+name],cwd=R)
    assert fp(body)==pin,name
    blobs.append(dict(path=name,**pin))
evidence['immutable_git_blob_count']=len(blobs)
evidence['immutable_git_blobs']=blobs
rust=read(W/'task-1-resume-verification.json')
assert rust['before']==rust['after']
assert all(fp(Path(p).read_bytes())==v for p,v in rust['after'].items())
rust_cmds=[]
for c in rust['commands']:
    assert c['exit']==0
    rust_cmds.append(dict(argv=c['argv'],exit=c['exit'],stdout=check_stream(c['stdout']),stderr=check_stream(c['stderr'])))
raw=Path(rust['commands'][-1]['stdout']['path']).read_text(encoding='utf8')
suites=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
evidence['rust']=dict(commands=rust_cmds,current_dependency_pins=len(rust['after']),suites=len(suites),
    passed=sum(int(s[0]) for s in suites),failed=sum(int(s[1]) for s in suites),ignored=sum(int(s[2]) for s in suites),cli=rust['cli'])
evidence['python_receipts']=[]
for name in ['task-2-fix1-red','task-2-fix1-green','task-2-fix1-python','task-2-fix1-audit-v2-command','task-2-audit-old-stable-command']:
    d=read(W/(name+'.json')); assert d['before']==d['after']
    streams={k:check_stream(d[k]) for k in ['stdout','stderr']}
    stderr=Path(d['stderr']['path']).read_text(encoding='utf8')
    row=dict(name=name,argv=d['argv'],exit_code=d['exit_code'],streams=streams,source_pin_count=len(d['after']),
        raw_result_lines=[s for s in stderr.splitlines() if s.startswith(('Ran ','OK','FAILED'))])
    if name in ('task-2-fix1-green','task-2-fix1-python','task-2-fix1-audit-v2-command'):
        assert all(fp(Path(p).read_bytes())==v for p,v in d['after'].items())
        row['current_pins_match']=True
    evidence['python_receipts'].append(row)
evidence['audits']=[]
for name in ['task-2-fix1-audit-v2','task-2-audit-old-stable']:
    d=read(W/name/'audit.json'); assert d['protected_before']==d['protected_after']
    assert len(d['scenarios'])==d['scenario_count'] and len(d['calls'])==d['command_count']
    for c in d['calls']:
        check_stream(c['stdout']);check_stream(c['stderr'])
        assert c['exit_code']==c.get('expected_exit',c.get('expected_exit_code',c['exit_code']))
        if 'cli_before' in c:assert c['cli_before']==c['cli_after']==rust['cli']
    evidence['audits'].append(dict(name=name,scenarios=d['scenario_count'],calls=d['command_count'],
        protection_groups=len(d['protected_before']),stream_count=2*len(d['calls']),
        scenario_results=d['scenarios']))
evidence['coherent_outputs']=[]
unit=read(W/'task-2-unit-false-group.json')
for out in [W/'task-2-fix1-audit-v2'/'forged-deleted-condition',W/'task-2-fix1-audit-v2'/'forged-invented-time',Path(unit['output'])]:
    report=read(out/'coordination.json'); md=(out/'coordination.md').read_bytes()
    assert json.loads(md.split(b'```json\n',1)[1].split(b'\n```\n',1)[0])==report
    for n,pin in report['artifacts'].items():assert fp((out/n).read_bytes())==pin
    ir=out/'coordination-ir.json'
    if ir.exists():
        expected={k:v for k,v in report.items() if k not in ['report_kind','status','network_calls','paid_calls','artifacts']}
        assert read(ir)==dict(expected,revision=1)
    evidence['coherent_outputs'].append(dict(path=str(out),report_pin=fp((out/'coordination.json').read_bytes()),
        facts=len(report['facts']),occurrences=len(report['occurrences']),all_artifact_pins_match=True,
        markdown_json_equal=True,ir_equal=ir.exists()))
evidence['archives']=[]
for name in ['B05-T02-python-evidence-manifest.json','B05-T02-rust-resume-evidence-manifest.json']:
    manifest=read(R/'doc/validation/assets'/name); path=R/'doc/validation/assets'/manifest['archive']
    assert fp(path.read_bytes())==manifest['archive_fingerprint']
    with zipfile.ZipFile(path) as z:
        assert len(z.namelist())==len(set(z.namelist()))==manifest['member_count']
        assert set(z.namelist())==set(manifest['members'])
        # Sample actual sources, SQL, originals, both report forms and failures;
        # all blob bytes above are pinned, full member CRC was already recorded.
        selected=[]
        for suffix in ['project.sqlite','gold-original.json','candidates-original.json','source-snapshot.json','coordination.json','coordination.md','identity-original.json','task-2-fix1-red.stderr.txt','task-1-resume-workspace.stdout.txt']:
            matches=[n for n in z.namelist() if n.endswith(suffix)]
            if matches:
                n=matches[len(matches)//2];assert fp(z.read(n))==manifest['members'][n];selected.append(n)
    evidence['archives'].append(dict(path=str(path),member_count=manifest['member_count'],archive_pin=manifest['archive_fingerprint'],sampled_member_pins=selected,full_crc_not_repeated=True))
f=R/'fixtures/knowledge-coordination-v2'; authors=read(f/'authors.json'); frozen=read(f/'frozen-sha256.json')
for n,pin in frozen['files'].items():assert fp((f/n).read_bytes())==pin
evidence['author_cases']=[]
for c in authors['cases']:
    for i in c['inputs']:
        raw=(f/i['source_file']).read_text(encoding='utf8');g=i['gold'];ctx=i['context']
        assert raw.count(g['quote'])==1 and i['context_quote'] in raw
        assert i['context_quote'].split('\n')[1]==g['quote']==g['atom_content']
        assert ctx in c['identity']['atom_contexts']
        o=next(o for o in c['expected']['occurrences'] if o['input_id']==i['input_id'])
        assert all(o[k]==g[k] for k in ['value','unit','conditions','exceptions'])
        assert o['time']==ctx['time'] and o['applicability_status']==ctx['applicability_status']
    evidence['author_cases'].append(dict(name=c['name'],same_source=c['same_source'],
       facts=[{k:v for k,v in x.items() if k not in ['object_id','property_id','original_atom_ids','value_status']} for x in c['expected']['facts']],
       relations=c['expected']['relations'],totals=c['expected']['totals']))
evidence['frozen_file_count']=len(frozen['files'])
evidence['limitations']='Saved evidence inspection only; no passing suite/matrix rerun. Archive members were sampled, not all CRC/member bodies reread. Separate six-command nonzero-unit probe reproduced new P2.'
(W/'final-review-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(report=str(W/'final-review-evidence.json'),git_blobs=len(blobs),rust=evidence['rust']['passed'],python=[(x['name'],x['exit_code'],x['raw_result_lines']) for x in evidence['python_receipts']],audit_calls=sum(a['calls'] for a in evidence['audits']),frozen_files=evidence['frozen_file_count'],archives=[(x['member_count'],len(x['sampled_member_pins'])) for x in evidence['archives']]),ensure_ascii=False))
for c in evidence['author_cases']:
    print(json.dumps(dict(name=c['name'],same_source=c['same_source'],facts=c['facts'],relations=[(r['relation'],r['issue_code'],r['earlier_input_id'],r['later_input_id']) for r in c['relations']],totals=[c['totals'][k] for k in ['source_occurrences','retained_fact_groups','canonical_facts','passed','needs_review']]),ensure_ascii=False,separators=(',',':')))
