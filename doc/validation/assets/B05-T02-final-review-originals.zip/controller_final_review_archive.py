"""Preserve the immutable broad review and its ordinary valid-input RED."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import zipfile

REPO = Path(__file__).resolve().parents[3]
WORK = Path(__file__).resolve().parent
ASSETS = REPO / 'doc/validation/assets'
TARGET = ASSETS / 'B05-T02-final-review-originals.zip'
MANIFEST = ASSETS / 'B05-T02-final-review-originals.json'
assert not TARGET.exists() and not MANIFEST.exists()


def pin(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))


def load(path):
    return json.loads(path.read_bytes())


package = load(WORK / 'whole-branch-package.json')
for label in ('full_package', 'review_code_package'):
    entry = package[label]
    assert pin(Path(entry['path']).read_bytes()) == {k: entry[k] for k in ('sha256', 'byte_length')}
for name, expected in package['changed_files'].items():
    p = subprocess.run(['git', 'show', package['head'] + ':' + name], cwd=REPO, capture_output=True)
    assert p.returncode == 0 and pin(p.stdout) == expected, name
probe = load(WORK / 'final-review-offset-probe/evidence.json')
assert probe['actual_exit'] == 3 and probe['expected_exit'] == 0
assert probe['source_case_unchanged'] and probe['protected_originals_unchanged']
assert len(probe['calls']) == 6
assert [c['exit_code'] for c in probe['calls']] == [0, 0, 0, 0, 0, 3]
for call in probe['calls']:
    for stream in ('stdout', 'stderr'):
        e = call[stream]
        assert pin(Path(e['path']).read_bytes()) == {k: e[k] for k in ('sha256', 'byte_length')}
    assert call['cli_before'] == call['cli_after']


def files(root):
    pending = [root]
    while pending:
        directory = pending.pop()
        for entry in sorted(os.scandir(directory), key=lambda e: e.name):
            item = Path(entry.path)
            info = item.lstat()
            assert not getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT, item
            assert item.resolve().is_relative_to(WORK), item
            if entry.is_dir(follow_symlinks=False):
                pending.append(item)
            elif entry.is_file(follow_symlinks=False):
                assert info.st_nlink == 1, item
                yield item
            else:
                raise AssertionError(str(item))


selected = [WORK / name for name in (
    'progress.md', 'final-review.md', 'final-review-brief.md', 'final-review-evidence.json',
    'final-review-inspect.py', 'final-review-offset-probe.py', 'whole-branch-package.json',
    'review-whole-branch-code.diff', 'review-e1c3e08..b3a31ea.diff',
    'controller_final_review_archive.py',
    'final-review-archive-preparation-failure.json',
)]
selected += list(files(WORK / 'final-review-offset-probe'))
members = {}
with zipfile.ZipFile(TARGET, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(selected):
        raw = path.read_bytes()
        name = path.relative_to(WORK).as_posix()
        assert name not in members
        members[name] = pin(raw)
        archive.writestr(name, raw)
with zipfile.ZipFile(TARGET) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(members)
    for name, expected in members.items():
        assert pin(archive.read(name)) == expected
result = dict(created_at=datetime.now(timezone.utc).isoformat(), review_base=package['base'],
    review_head=package['head'], immutable_git_blobs_rechecked=len(package['changed_files']),
    actual_probe_commands=6, actual_probe_exit=3, expected_probe_exit=0,
    archive=pin(TARGET.read_bytes()), members=members, all_crc_and_member_bytes_checked=True,
    limitations='Preserves one pre-fix broad review and valid-input failure. It is not final fix acceptance, a new complete suite, or scientific validation.')
MANIFEST.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(dict(archive=str(TARGET), members=len(members), bytes=TARGET.stat().st_size,
    immutable_git_blobs=len(package['changed_files']), probe_commands=6, actual_exit=3), ensure_ascii=False))
