# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-final-offset-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 2
      }
    ],
    "binding": {
      "project_id": "95bd7aa9-7206-4584-bfaf-19bf14753a05",
      "import_id": "f2cc62a1-d17b-4bbe-a6e9-d8fb7ae9ef53",
      "source_id": "196a8a2d-6a9b-4332-b5c8-03b77e9ef4c0",
      "version_id": "0b11d941-eac7-446a-a298-4f023f96a52f",
      "content_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
      "normalized_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "b3894669-1512-4a35-b5f2-41761a62a281",
          "ordinal": 2,
          "resource_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf"
        },
        "source_status": "parsed",
        "start_byte": 25,
        "end_byte": 301,
        "text": "公开自造资料 history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "95bd7aa9-7206-4584-bfaf-19bf14753a05",
    "import_id": "f2cc62a1-d17b-4bbe-a6e9-d8fb7ae9ef53",
    "source_id": "196a8a2d-6a9b-4332-b5c8-03b77e9ef4c0",
    "version_id": "0b11d941-eac7-446a-a298-4f023f96a52f",
    "content_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
    "normalized_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "a6c6c1a5d53dc8a35cf7cc6bd7f09b1132a7d3390a2be4b8b21e2f4ea13adc4e",
        "byte_length": 3055
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
        "byte_length": 744
      },
      "review.json": {
        "sha256": "bd2970e25a726d2dc0e9639f183f8cb0cfe123809e879e229acfbfcee496df9f",
        "byte_length": 510
      }
    },
    "gold_sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
          "import_id": "f2cc62a1-d17b-4bbe-a6e9-d8fb7ae9ef53",
          "manifest_sha256": null,
          "normalized_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
          "parse_id": null,
          "project_id": "95bd7aa9-7206-4584-bfaf-19bf14753a05",
          "source_id": "196a8a2d-6a9b-4332-b5c8-03b77e9ef4c0",
          "version_id": "0b11d941-eac7-446a-a298-4f023f96a52f"
        },
        "request_id": "synthetic-final-offset-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
          "import_id": "f2cc62a1-d17b-4bbe-a6e9-d8fb7ae9ef53",
          "manifest_sha256": null,
          "normalized_sha256": "f1524543d7fb8e3408e174bbd97b0defe6583c23ac246037ae290f75a0277caf",
          "parse_id": null,
          "project_id": "95bd7aa9-7206-4584-bfaf-19bf14753a05",
          "source_id": "196a8a2d-6a9b-4332-b5c8-03b77e9ef4c0",
          "version_id": "0b11d941-eac7-446a-a298-4f023f96a52f"
        },
        "request_id": "synthetic-final-offset-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 57,
      "end_byte": 221,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 301,
        "start_byte": 25,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 221,
        "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
        "excerpt_start_byte": 57,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 221,
        "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 110
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 221,
          "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
          "excerpt_start_byte": 57,
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "8",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "8",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 25,
      "end_byte": 301,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d1beb6342eb4c810c0b967f5239406895e1e271a67557150293833853d163f2b",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "a6c6c1a5d53dc8a35cf7cc6bd7f09b1132a7d3390a2be4b8b21e2f4ea13adc4e",
      "byte_length": 3055
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "knowledge-ir.json": {
      "sha256": "1308918958836f573488af979587f72980d307257cfc1fa76c20c029b696876f",
      "byte_length": 12406
    },
    "review-original.json": {
      "sha256": "bd2970e25a726d2dc0e9639f183f8cb0cfe123809e879e229acfbfcee496df9f",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "958110357ec5d80028538958bf01c7d3426d6c8755ec640213192f3593828b7f",
      "byte_length": 1169
    }
  }
}
```
