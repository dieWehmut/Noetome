# SDD ledger — plan: doc/execution/B05-T02_VARIANTS_PLAN.md

Product task: B05-T02 only. Started through devlog tool; do not re-dispatch T01.
Branch: codex/b05-t02-condition-history, parent e1c3e0867304f3cbfab75e3d7fd2d579e777646a.
Spec: doc/technical/KNOWLEDGE_VARIANTS_CONTRACT.md.
Author inputs: fixtures/knowledge-coordination-v2/frozen-sha256.json (31 files, 14 cases/29 sources).

Current checkpoint: Task1 complete/Approved; Task2 fix round1 complete and scoped spec/quality Approved at 9751505aac38f4bac0689100bb521e0b6e60ad8b. Product B05-T02 remains in_progress pending one final whole-branch review, acceptance/log/commit/push and exact remote check. The chronological entries below remain intact.

Final package preparation at e79fb2e failed an extra all-fixture Git byte check: unsigned frozen-sha256.json manifest alone was old Git LF vs original working CRLF, JSON content identical. All31 signed author/Git bytes remain exact and immutable. Diagnostic saved publicly. Stage existing original manifest under adopted -text without editing working bytes, then rebuild package at new HEAD; reuse stable tests after unchanged source/input pins. No broad final reviewer was dispatched before this preparation correction.

## Preflight scan

| Tasks | Producer/consumer or internal comparison | Result |
| --- | --- | --- |
| 1 and 2 | Strict Schema2 case/map/context/facts/relations/totals; Python check consumes ordinary Rust files | Exact fields in reachable Spec; time key uses array status/precision/value in both languages; source-review DTO unchanged. |
| 1 and 2 | Rust owns crates; Python owns scripts/tests; authors are read-only for both | No shared edited file, no parallel implementation dispatch. |
| 1 | Frozen Gold2/value/conditions/exceptions and source_context envelope vs new CLI expectations | All 14 static cases checked before candidates. RED test compiles only against existing public CLI. Unknown groups kept separate, NA may merge. |
| 2 | Frozen expected vs independent rebuild and coherent forgeries | Positive schema RED against old verifier first; negative tests sync Markdown/IR/fingerprints and must prove source/author refusal. |
| 1 | Proposed file responsibilities vs final saves | Three v2 modules plus exact existing integration points; common IO/source guards preserved, no copied whole algorithm. |
| 2 | Proposed file responsibilities vs audit command | v2 checker and audit prep separated; old script only routes, v1 matrix unchanged. |

Spec self-review corrected time key to three-element array before fixture freeze to avoid serde/Python object-order differences. No unresolved scope conflict or ruling.
Task 1: pending.
Task 2: pending.

Author freeze commit: f718cb2c4e546c0cf3d2d34e2e233a988c486d52 (no production v2 changes).
Task 1: dispatch base f718cb2c4e546c0cf3d2d34e2e233a988c486d52; awaiting implementer report.

Fixture Git byte protection commit: c673b137e286ac4dfbd71163457fe151a7392ff5; all 31 author files match frozen hashes and Git blobs.
Task 1: corrected dispatch BASE c673b137e286ac4dfbd71163457fe151a7392ff5 (no implementation dispatched before this).

Ruling: 缺时间仅阻止需要时间才能分类的差异；已证明的重复/互补和完整条件变体可以保留unknown时间 — 依据已验T01无时间成功基线及T02条件并列目标，修正NEXT_STEPS中笼统表述；若要求所有无日期记录都复核，需调整v2状态及对应作者期望，原来源证据不变。

Ruling: 独立v2 verify_report沿用现有成功字典加AssertionError失败协议，不返回False字典 — 现有audit依赖异常拒绝伪造，保持原check退出0/1；若错误地更换协议会产生误接受，后续调用接口须按现有契约。Task2计划/brief在其派发前已修正。

Task2 named risk: existing source_bundle metadata rejects actual v2 support quote LF at metadata limit/control; controller direct admission cannot yet pass. No production source changed. Plan/brief now require closed v2 evidence-quote opt-in with default v1 unchanged and full source reconstruction retained; this is a pending Task2 validation gap, not Rust feature RED.

Task 1: genuine CLI RED independently inspected; 3 upstream B04 single-atom source reviews passed, 3 source IDs, COORD_SCHEMA/2 versus author0, no success IR. Public archive doc/validation/assets/B05-T02-cli-red.zip 113members/95386bytes SHA accfc1964577ea9c114f800ad0795d8914f81adb3fe80e24a4fe5f3ec8f51530. Two prep failures retained, not feature RED. Rust implementation continues.

2026-11-04 resumed under user's continuous-development request. Git HEAD 1f18ef9 is the genuine CLI RED commit; Task 1 Rust implementation/test files are uncommitted, no implementer report or review exists. Existing final fmt/check/focused/workspace exit files contain 0, focused log has 25 passed; these are historical claims pending exact source/CLI/raw-output reinspection. Resume Task 1 without recreating authors or discarding partial implementation, verify the receipt pins, then commit/review the complete c673b13..HEAD task range. Preserve the two user docs deletions and all old failure receipts. No product task status transition: B05-T02 remains the sole in_progress.

Task 1: resumed implementer /root/variants_rust. Controller read-only inspection matched 31 frozen author files/Git blobs, 9 Rust/test pins, historical final CLI, 61 roots/466 command artifacts/4459 protected-file comparisons. Historical archive doc/validation/assets/B05-T02-rust-evidence.zip has 5674 members/5929273 bytes, all CRC/member pins verified. Initial packaging device-prefix path comparison failure diagnosed with samefile and recorded; no reparse paths followed. Worker independently found missing complete argv/thread evidence and differing per-root/current CLI SHA, so controller requested one fresh stable fmt/check/workspace run with explicit threads, whole-source pins and actual CLI correspondence. This is a justified evidence-gap rerun, not repeated acceptance of historical summaries.

Task 1: complete (commits c673b13..af528d2, spec compliant and quality Approved; reviewer /root/variants_rust_review). New stable fmt/check/workspace 589 passed/0 failed/0 ignored, 17 result suites, explicit threads=4; controller independently rechecked 89 source/build files, 66 current-CLI roots/499 commands/146 upstream review successes/4824 protection pins and complete stream hashes. Fresh archive B05-T02-rust-resume-evidence.zip 6135 members/6555763 bytes, SHA df73302c16716d21267f3b74e78ddc8ec9033b1331bdefebe7094c4036bfe2da. Task review copy: doc/validation/assets/B05-T02-task1-review.md. Cross-task Python/author/archive/final acceptance/push gaps: author/archive Rust portions resolved by controller receipts; Python and final product gates still pending.
Task 1: minor (deferred): knowledge_coordination_v2_model.rs:68 DTO macro invocations could use one field per line; optional readability only, final review must triage.
Task 2: dispatch base af528d2; prerequisites Rust reviewed, author files untouched; full report expected at task-2-report.md.

Task 2: implementer /root/variants_python obtained genuine pre-production Python RED. Four test methods/17 positive subtest failures against old v1 gold_schema, exit1/17.100s, 16 ordinary v2 outputs with upstream success retained at target/python-variants-ea863af20921491db3eac892b1738b26. Raw log public copy doc/validation/assets/B05-T02-python-red.log; negative old-version refusal is not yet semantic-forgery GREEN. Independent v2 reconstruction/admission implementation continues.

Task 2 checkpoint: b83b33e and 1946e71 implement independent Python and tests. First stable full Python154/154 exited0 (101.171s); focused11/11, old35/35, ordinary v2 audit41 scenarios/119 actual calls and old audit33/56 passed with raw receipts. Before task review, implementer self-review identified top-level malformed case ([]/null/scalar) could leak AttributeError instead of required AssertionError; explicit object guard and five actual probes are being verified. A misplaced-test iteration is preserved. This is a concrete new boundary change; final same-code evidence and review still pending, no product complete transition.

Task 2 reviewed checkpoint 4f0940b: focused12/full155 passed, v2 audit41/119 and old33/56 current-code receipts inspected; all134 source/test pins and reviewed Rust89 pins agree. Reviewer /root/variants_python_review found one Important/P2: gold_schema wrongly uses globally unique strings() for original_atom_ids across input-qualified occurrences. Frozen not_applicable probe with a/b both a-speed rejected solely duplicate normalized string. Full task review spec/quality Needs fixes; no other blocker. Public review/probe: doc/validation/assets/B05-T02-task2-review.md and B05-T02-task2-shared-atom-probe.json. Default-login tool stall was diagnosed and retried read-only with login=false; no test-suite/CLI replay by reviewer.
Task 2: fix round 1/5 dispatched to original implementer /root/variants_python; remove only unauthorized cross-input uniqueness, preserve input pairing/per-input IDs, real source-backed RED/GREEN with original IDs unchanged and new v2 audit scene. Final product acceptance stays pending.

Task 2 fix1 RED: 14 test methods/3 failures at the old duplicate-normalized-string gate, raw task-2-fix1-red.json and streams preserved. New selected root target/python-variants-084180631cab4ef0a414d2f603232bf8/shared-original-atom-id contains author overrides frozen before CLI, two upstream review successes, ordinary coordinate0, distinct occurrence IDs and original a-speed retained twice. Two new valid positives are rejected by the old gate; a negative still reaches the wrong early gate before the fix. Contract clarified input-qualified IDs and paired expected members without changing wire version or frozen original fixtures.

2026-11-04 continuous goal resumed at b3a31ea. Actual existing final-review.md is present for exact e1c3e08..b3a31ea range (one final broad review; no re-dispatch). Final R1 Important is a source-coordinate coverage bug with six-call ordinary RED, valid upstream sources and independent context reconstruction; R2 repeats optional DTO readability. One final fix wave will handle both, then one scoped re-review. Product remains sole in_progress, prior failures retained; user docs deletions untouched.
