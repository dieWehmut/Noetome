# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "e7842582-7b60-41bd-a5ba-c622bca67b61",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "signed_arrows",
    "title": "图像保真样例 signed_arrows",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "4647154bc5258c9aacfa4c0fac7d355ecea93f8cb9137905e20bcd7430b23d8e"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "response",
        "kind": "circle",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "occluder",
        "kind": "rect",
        "bbox": [
          360,
          177,
          28,
          30
        ],
        "label": "X",
        "unit": null,
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "neutral",
        "label": "",
        "unit": null,
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c5efcb",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "svg_redraw",
    "fallback_reasons": [],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "5cc0536fc317d1af55c408f411a2bc747d1fdf2b99947f4404530e548cee147e",
    "byte_length": 3671
  },
  "inputs": {
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "60fd9e9b341ce370c135ed7d5b7e1b1ab9fc1fe9a44d88f9ec134d1155bcb25e",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "4647154bc5258c9aacfa4c0fac7d355ecea93f8cb9137905e20bcd7430b23d8e",
      "byte_length": 2563
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "2806a72289fa5d97bfb5c57823b6b291571b21884bc718eec837650956b104b0",
      "byte_length": 2858,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "image_embed",
          "source_field": "semantics",
          "start_byte": 84,
          "end_byte": 100
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 121,
          "end_byte": 200
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 250,
          "end_byte": 254
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 279,
          "end_byte": 283
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 308,
          "end_byte": 312
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 337,
          "end_byte": 343
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 368,
          "end_byte": 389
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 420,
          "end_byte": 436
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 475,
          "end_byte": 483
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 508,
          "end_byte": 514
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 539,
          "end_byte": 547
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 572,
          "end_byte": 576
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 601,
          "end_byte": 622
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 653,
          "end_byte": 670
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 709,
          "end_byte": 715
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 740,
          "end_byte": 744
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 769,
          "end_byte": 775
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 800,
          "end_byte": 806
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 831,
          "end_byte": 852
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 883,
          "end_byte": 900
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[3].id",
          "start_byte": 939,
          "end_byte": 947
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[3].kind",
          "start_byte": 972,
          "end_byte": 976
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[3].label",
          "start_byte": 1001,
          "end_byte": 1002
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[3].unit",
          "start_byte": 1027,
          "end_byte": 1048
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[3].legend_id",
          "start_byte": 1073,
          "end_byte": 1094
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[3].bbox",
          "start_byte": 1125,
          "end_byte": 1140
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 1190,
          "end_byte": 1194
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 1225,
          "end_byte": 1229
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 1260,
          "end_byte": 1268
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1299,
          "end_byte": 1308
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1339,
          "end_byte": 1348
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1379,
          "end_byte": 1386
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1417,
          "end_byte": 1424
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1449,
          "end_byte": 1449
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1474,
          "end_byte": 1495
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1520,
          "end_byte": 1528
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1567,
          "end_byte": 1571
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1602,
          "end_byte": 1610
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1641,
          "end_byte": 1647
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1678,
          "end_byte": 1687
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1718,
          "end_byte": 1727
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1758,
          "end_byte": 1765
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1796,
          "end_byte": 1804
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1829,
          "end_byte": 1837
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1862,
          "end_byte": 1866
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1891,
          "end_byte": 1899
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1961,
          "end_byte": 1970
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1995,
          "end_byte": 1999
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 2030,
          "end_byte": 2038
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 2069,
          "end_byte": 2076
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 2121,
          "end_byte": 2134
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 2159,
          "end_byte": 2167
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 2198,
          "end_byte": 2204
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 2235,
          "end_byte": 2242
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 2292,
          "end_byte": 2300
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2325,
          "end_byte": 2326
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2351,
          "end_byte": 2370
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2395,
          "end_byte": 2402
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2433,
          "end_byte": 2448
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2487,
          "end_byte": 2495
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2520,
          "end_byte": 2521
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2546,
          "end_byte": 2565
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2590,
          "end_byte": 2597
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2628,
          "end_byte": 2644
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2675,
          "end_byte": 2730
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2755,
          "end_byte": 2806
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2829,
          "end_byte": 2857
        }
      ]
    },
    {
      "relative_path": "redrawn.svg",
      "content_sha256": "50bfb8281e3a1c55f81cd84f5c2a61f0dec9afd1474cff99a44358dd3a76ee8b",
      "byte_length": 3546,
      "mappings": [
        {
          "kind": "canvas_background",
          "source_field": "case.dimensions",
          "start_byte": 88,
          "end_byte": 165
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 166,
          "end_byte": 283
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 284,
          "end_byte": 398
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 399,
          "end_byte": 516
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[3].bbox",
          "start_byte": 517,
          "end_byte": 634
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 635,
          "end_byte": 776
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 777,
          "end_byte": 919
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 920,
          "end_byte": 1069
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 1070,
          "end_byte": 1214
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 1215,
          "end_byte": 1360
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 1361,
          "end_byte": 1505
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[3].label",
          "start_byte": 1506,
          "end_byte": 1648
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 1649,
          "end_byte": 1765
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 1766,
          "end_byte": 1907
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 1908,
          "end_byte": 2069
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2070,
          "end_byte": 2187
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2188,
          "end_byte": 2329
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2330,
          "end_byte": 2491
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[0]",
          "start_byte": 2492,
          "end_byte": 2588
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 2589,
          "end_byte": 2729
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 2730,
          "end_byte": 2868
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[1]",
          "start_byte": 2869,
          "end_byte": 2965
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 2966,
          "end_byte": 3106
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 3107,
          "end_byte": 3249
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 3250,
          "end_byte": 3396
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 3397,
          "end_byte": 3538
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "9da3359a42b17018d4791c6d67f4d7474cf9758f7536b80a72feb966a9717533",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "plan.json": {
      "sha256": "5cc0536fc317d1af55c408f411a2bc747d1fdf2b99947f4404530e548cee147e",
      "byte_length": 3671
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "redrawn.svg": {
      "sha256": "50bfb8281e3a1c55f81cd84f5c2a61f0dec9afd1474cff99a44358dd3a76ee8b",
      "byte_length": 3546
    },
    "source-case.json": {
      "sha256": "60fd9e9b341ce370c135ed7d5b7e1b1ab9fc1fe9a44d88f9ec134d1155bcb25e",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "4647154bc5258c9aacfa4c0fac7d355ecea93f8cb9137905e20bcd7430b23d8e",
      "byte_length": 2563
    },
    "图像预览.md": {
      "sha256": "2806a72289fa5d97bfb5c57823b6b291571b21884bc718eec837650956b104b0",
      "byte_length": 2858
    }
  }
}
```
