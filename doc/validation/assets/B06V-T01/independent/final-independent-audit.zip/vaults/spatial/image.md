# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "efe54303-2426-4027-97b7-2e51dff0d33e",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "spatial",
    "title": "图像保真样例 spatial",
    "source_kind": "spatial",
    "image": {
      "file": "source.png",
      "sha256": "a1902fb8fa1f4d16dce59ed2644fe915b304ad6b19b5bc52b2b6d22d8afc80da"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "81299e484d86d606e0cc9aab66dfceea8eb0fdf76056b15c45ca594411f85754"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Selected spatial layout with containment, left and upper relationships.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "outer",
        "kind": "rect",
        "bbox": [
          360,
          80,
          500,
          260
        ],
        "label": "Compartment",
        "unit": null,
        "legend_id": null
      },
      {
        "id": "inner",
        "kind": "circle",
        "bbox": [
          690,
          160,
          140,
          140
        ],
        "label": "Inclusion",
        "unit": null,
        "legend_id": null
      },
      {
        "id": "reference",
        "kind": "rect",
        "bbox": [
          40,
          170,
          190,
          100
        ],
        "label": "Reference",
        "unit": null,
        "legend_id": null
      },
      {
        "id": "cover",
        "kind": "rect",
        "bbox": [
          690,
          20,
          140,
          50
        ],
        "label": "Cover",
        "unit": null,
        "legend_id": null
      }
    ],
    "relations": [],
    "spatial_relations": [
      {
        "id": "containment",
        "a": "inner",
        "b": "outer",
        "relation": "inside"
      },
      {
        "id": "left",
        "a": "reference",
        "b": "inner",
        "relation": "left_of"
      },
      {
        "id": "upper",
        "a": "cover",
        "b": "inner",
        "relation": "above"
      }
    ],
    "legend": []
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "svg_redraw",
    "fallback_reasons": [],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "f160bca82aaa639bd415f286efbc7eda185465d34368fe1b0fa49afcdf6c0b14",
    "byte_length": 2611
  },
  "inputs": {
    "original.png": {
      "sha256": "a1902fb8fa1f4d16dce59ed2644fe915b304ad6b19b5bc52b2b6d22d8afc80da",
      "byte_length": 17535
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "9e6f602ef4fbe57529068b51f1f81a1bab3820745624596888fc0f80503c55bf",
      "byte_length": 479
    },
    "source-semantics.json": {
      "sha256": "81299e484d86d606e0cc9aab66dfceea8eb0fdf76056b15c45ca594411f85754",
      "byte_length": 1627
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "f6072e3979867746364981df9eaee955295cb23a8bf98a8f8e674c4258521c0e",
      "byte_length": 1906,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 61
        },
        {
          "kind": "image_embed",
          "source_field": "semantics",
          "start_byte": 78,
          "end_byte": 94
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 115,
          "end_byte": 186
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 236,
          "end_byte": 241
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 266,
          "end_byte": 270
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 295,
          "end_byte": 306
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 331,
          "end_byte": 352
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 377,
          "end_byte": 398
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 429,
          "end_byte": 445
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 484,
          "end_byte": 489
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 514,
          "end_byte": 520
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 545,
          "end_byte": 554
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 579,
          "end_byte": 600
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 625,
          "end_byte": 646
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 677,
          "end_byte": 694
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 733,
          "end_byte": 742
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 767,
          "end_byte": 771
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 796,
          "end_byte": 805
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 830,
          "end_byte": 851
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 876,
          "end_byte": 897
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 928,
          "end_byte": 944
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[3].id",
          "start_byte": 983,
          "end_byte": 988
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[3].kind",
          "start_byte": 1013,
          "end_byte": 1017
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[3].label",
          "start_byte": 1042,
          "end_byte": 1047
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[3].unit",
          "start_byte": 1072,
          "end_byte": 1093
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[3].legend_id",
          "start_byte": 1118,
          "end_byte": 1139
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[3].bbox",
          "start_byte": 1170,
          "end_byte": 1185
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1258,
          "end_byte": 1269
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1294,
          "end_byte": 1299
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 1330,
          "end_byte": 1335
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 1366,
          "end_byte": 1372
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 1417,
          "end_byte": 1421
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 1446,
          "end_byte": 1455
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 1486,
          "end_byte": 1491
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 1522,
          "end_byte": 1529
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[2].id",
          "start_byte": 1574,
          "end_byte": 1579
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[2].a",
          "start_byte": 1604,
          "end_byte": 1609
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[2].b",
          "start_byte": 1640,
          "end_byte": 1645
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[2].relation",
          "start_byte": 1676,
          "end_byte": 1681
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 1723,
          "end_byte": 1778
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 1803,
          "end_byte": 1854
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 1877,
          "end_byte": 1905
        }
      ]
    },
    {
      "relative_path": "redrawn.svg",
      "content_sha256": "82f7317a04ecc15c4b23fb1ccd83e7fc095fa85e32c6813e66c5f2485d2cc8e5",
      "byte_length": 1232,
      "mappings": [
        {
          "kind": "canvas_background",
          "source_field": "case.dimensions",
          "start_byte": 88,
          "end_byte": 165
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 166,
          "end_byte": 281
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 282,
          "end_byte": 396
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 397,
          "end_byte": 516
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[3].bbox",
          "start_byte": 517,
          "end_byte": 631
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 632,
          "end_byte": 781
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 782,
          "end_byte": 929
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 930,
          "end_byte": 1081
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[3].label",
          "start_byte": 1082,
          "end_byte": 1224
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "9a22cf2acee43d70c58796884f766cca185fab7362df12d020c648fa5f192e4f",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "a1902fb8fa1f4d16dce59ed2644fe915b304ad6b19b5bc52b2b6d22d8afc80da",
      "byte_length": 17535
    },
    "plan.json": {
      "sha256": "f160bca82aaa639bd415f286efbc7eda185465d34368fe1b0fa49afcdf6c0b14",
      "byte_length": 2611
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "redrawn.svg": {
      "sha256": "82f7317a04ecc15c4b23fb1ccd83e7fc095fa85e32c6813e66c5f2485d2cc8e5",
      "byte_length": 1232
    },
    "source-case.json": {
      "sha256": "9e6f602ef4fbe57529068b51f1f81a1bab3820745624596888fc0f80503c55bf",
      "byte_length": 479
    },
    "source-semantics.json": {
      "sha256": "81299e484d86d606e0cc9aab66dfceea8eb0fdf76056b15c45ca594411f85754",
      "byte_length": 1627
    },
    "图像预览.md": {
      "sha256": "f6072e3979867746364981df9eaee955295cb23a8bf98a8f8e674c4258521c0e",
      "byte_length": 1906
    }
  }
}
```
