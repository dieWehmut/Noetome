# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "a88d38fd-fd41-40dd-a581-d6475535d59a",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "signed_arrows",
    "title": "图像保真样例 signed_arrows",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "43264705af55ec12ee169b938bee448641ee6220b95e108c791ca5724fcd2c91"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": null,
        "legend_id": null
      },
      {
        "id": "response",
        "kind": "circle",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "positive",
        "label": "activates",
        "unit": "s^-1",
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c5efcb",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "svg_redraw",
    "fallback_reasons": [],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "c91a5ddc20afb58dab6d1756e0dfb6a5cc428757d7542fd5540d6375860be23c",
    "byte_length": 3456
  },
  "inputs": {
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "9644d80fd20a0f8737b0b5d24591aa5296d137cd41366e858b0cc9e9ceeb0be4",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "43264705af55ec12ee169b938bee448641ee6220b95e108c791ca5724fcd2c91",
      "byte_length": 2374
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "c1e4c19890253dc95ad64aaf2caf070ba36a0d29a05cecc6301e7434b9812e5f",
      "byte_length": 2626,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "image_embed",
          "source_field": "semantics",
          "start_byte": 84,
          "end_byte": 100
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 121,
          "end_byte": 200
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 250,
          "end_byte": 254
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 279,
          "end_byte": 283
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 308,
          "end_byte": 312
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 337,
          "end_byte": 358
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 383,
          "end_byte": 404
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 435,
          "end_byte": 451
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 490,
          "end_byte": 498
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 523,
          "end_byte": 529
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 554,
          "end_byte": 562
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 587,
          "end_byte": 591
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 616,
          "end_byte": 637
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 668,
          "end_byte": 685
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 724,
          "end_byte": 730
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 755,
          "end_byte": 759
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 784,
          "end_byte": 790
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 815,
          "end_byte": 821
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 846,
          "end_byte": 867
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 898,
          "end_byte": 915
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 965,
          "end_byte": 969
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 1000,
          "end_byte": 1004
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 1035,
          "end_byte": 1043
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1074,
          "end_byte": 1083
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1114,
          "end_byte": 1123
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1154,
          "end_byte": 1161
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1192,
          "end_byte": 1200
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1225,
          "end_byte": 1234
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1259,
          "end_byte": 1263
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1288,
          "end_byte": 1296
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1335,
          "end_byte": 1339
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1370,
          "end_byte": 1378
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1409,
          "end_byte": 1415
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1446,
          "end_byte": 1455
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1486,
          "end_byte": 1495
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1526,
          "end_byte": 1533
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1564,
          "end_byte": 1572
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1597,
          "end_byte": 1605
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1630,
          "end_byte": 1634
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1659,
          "end_byte": 1667
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1729,
          "end_byte": 1738
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1763,
          "end_byte": 1767
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 1798,
          "end_byte": 1806
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 1837,
          "end_byte": 1844
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 1889,
          "end_byte": 1902
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 1927,
          "end_byte": 1935
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 1966,
          "end_byte": 1972
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 2003,
          "end_byte": 2010
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 2060,
          "end_byte": 2068
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2093,
          "end_byte": 2094
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2119,
          "end_byte": 2138
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2163,
          "end_byte": 2170
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2201,
          "end_byte": 2216
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2255,
          "end_byte": 2263
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2288,
          "end_byte": 2289
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2314,
          "end_byte": 2333
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2358,
          "end_byte": 2365
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2396,
          "end_byte": 2412
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2443,
          "end_byte": 2498
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2523,
          "end_byte": 2574
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2597,
          "end_byte": 2625
        }
      ]
    },
    {
      "relative_path": "redrawn.svg",
      "content_sha256": "a497f6a68c7feebcf9f0612d8d142509b8ba7d70d29d55b04c0eef36b63b87a5",
      "byte_length": 3434,
      "mappings": [
        {
          "kind": "canvas_background",
          "source_field": "case.dimensions",
          "start_byte": 88,
          "end_byte": 165
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 166,
          "end_byte": 283
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 284,
          "end_byte": 398
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 399,
          "end_byte": 516
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 517,
          "end_byte": 658
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 659,
          "end_byte": 808
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 809,
          "end_byte": 953
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 954,
          "end_byte": 1099
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 1100,
          "end_byte": 1244
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 1245,
          "end_byte": 1361
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 1362,
          "end_byte": 1503
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 1504,
          "end_byte": 1665
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 1666,
          "end_byte": 1783
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 1784,
          "end_byte": 1925
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 1926,
          "end_byte": 2087
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[0]",
          "start_byte": 2088,
          "end_byte": 2184
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 2185,
          "end_byte": 2325
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 2326,
          "end_byte": 2466
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 2467,
          "end_byte": 2614
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 2615,
          "end_byte": 2756
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[1]",
          "start_byte": 2757,
          "end_byte": 2853
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 2854,
          "end_byte": 2994
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 2995,
          "end_byte": 3137
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 3138,
          "end_byte": 3284
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 3285,
          "end_byte": 3426
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "6acd972e0797d00f9102a13df97da9c4fb358906cca9ad28aebb3c65411bcf2f",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "plan.json": {
      "sha256": "c91a5ddc20afb58dab6d1756e0dfb6a5cc428757d7542fd5540d6375860be23c",
      "byte_length": 3456
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "redrawn.svg": {
      "sha256": "a497f6a68c7feebcf9f0612d8d142509b8ba7d70d29d55b04c0eef36b63b87a5",
      "byte_length": 3434
    },
    "source-case.json": {
      "sha256": "9644d80fd20a0f8737b0b5d24591aa5296d137cd41366e858b0cc9e9ceeb0be4",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "43264705af55ec12ee169b938bee448641ee6220b95e108c791ca5724fcd2c91",
      "byte_length": 2374
    },
    "图像预览.md": {
      "sha256": "c1e4c19890253dc95ad64aaf2caf070ba36a0d29a05cecc6301e7434b9812e5f",
      "byte_length": 2626
    }
  }
}
```
