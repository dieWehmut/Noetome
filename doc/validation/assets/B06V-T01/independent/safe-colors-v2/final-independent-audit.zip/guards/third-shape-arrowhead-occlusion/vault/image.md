# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "d38db6a0-1f8f-45f9-9e02-6acb40ead6df",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "signed_arrows",
    "title": "图像保真样例 signed_arrows",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "4647154bc5258c9aacfa4c0fac7d355ecea93f8cb9137905e20bcd7430b23d8e"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "response",
        "kind": "circle",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "occluder",
        "kind": "rect",
        "bbox": [
          360,
          177,
          28,
          30
        ],
        "label": "X",
        "unit": null,
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "neutral",
        "label": "",
        "unit": null,
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c5efcb",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "original_image",
    "fallback_reasons": [
      "IMAGE_GEOMETRY_LAYOUT"
    ],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "8968716d65f4791e96e9953efac98ab09e37c698aa0025c9457d31c85b9134ba",
    "byte_length": 3710
  },
  "inputs": {
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "60fd9e9b341ce370c135ed7d5b7e1b1ab9fc1fe9a44d88f9ec134d1155bcb25e",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "4647154bc5258c9aacfa4c0fac7d355ecea93f8cb9137905e20bcd7430b23d8e",
      "byte_length": 2563
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "f70b0bd941bca8715fcf8b3e5b4f140b818dc520652d742822107029c1beb8a9",
      "byte_length": 2939,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "image_embed",
          "source_field": "case.image",
          "start_byte": 84,
          "end_byte": 101
        },
        {
          "kind": "fallback_reason",
          "source_field": "decision.fallback_reasons[0]",
          "start_byte": 111,
          "end_byte": 177
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 202,
          "end_byte": 281
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 331,
          "end_byte": 335
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 360,
          "end_byte": 364
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 389,
          "end_byte": 393
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 418,
          "end_byte": 424
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 449,
          "end_byte": 470
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 501,
          "end_byte": 517
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 556,
          "end_byte": 564
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 589,
          "end_byte": 595
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 620,
          "end_byte": 628
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 653,
          "end_byte": 657
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 682,
          "end_byte": 703
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 734,
          "end_byte": 751
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 790,
          "end_byte": 796
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 821,
          "end_byte": 825
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 850,
          "end_byte": 856
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 881,
          "end_byte": 887
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 912,
          "end_byte": 933
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 964,
          "end_byte": 981
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[3].id",
          "start_byte": 1020,
          "end_byte": 1028
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[3].kind",
          "start_byte": 1053,
          "end_byte": 1057
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[3].label",
          "start_byte": 1082,
          "end_byte": 1083
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[3].unit",
          "start_byte": 1108,
          "end_byte": 1129
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[3].legend_id",
          "start_byte": 1154,
          "end_byte": 1175
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[3].bbox",
          "start_byte": 1206,
          "end_byte": 1221
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 1271,
          "end_byte": 1275
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 1306,
          "end_byte": 1310
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 1341,
          "end_byte": 1349
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1380,
          "end_byte": 1389
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1420,
          "end_byte": 1429
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1460,
          "end_byte": 1467
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1498,
          "end_byte": 1505
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1530,
          "end_byte": 1530
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1555,
          "end_byte": 1576
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1601,
          "end_byte": 1609
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1648,
          "end_byte": 1652
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1683,
          "end_byte": 1691
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1722,
          "end_byte": 1728
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1759,
          "end_byte": 1768
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1799,
          "end_byte": 1808
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1839,
          "end_byte": 1846
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1877,
          "end_byte": 1885
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1910,
          "end_byte": 1918
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1943,
          "end_byte": 1947
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1972,
          "end_byte": 1980
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 2042,
          "end_byte": 2051
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 2076,
          "end_byte": 2080
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 2111,
          "end_byte": 2119
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 2150,
          "end_byte": 2157
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 2202,
          "end_byte": 2215
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 2240,
          "end_byte": 2248
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 2279,
          "end_byte": 2285
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 2316,
          "end_byte": 2323
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 2373,
          "end_byte": 2381
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2406,
          "end_byte": 2407
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2432,
          "end_byte": 2451
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2476,
          "end_byte": 2483
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2514,
          "end_byte": 2529
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2568,
          "end_byte": 2576
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2601,
          "end_byte": 2602
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2627,
          "end_byte": 2646
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2671,
          "end_byte": 2678
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2709,
          "end_byte": 2725
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2756,
          "end_byte": 2811
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2836,
          "end_byte": 2887
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2910,
          "end_byte": 2938
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "d66772252736bdb50cc972f09feb5ec0bde68cbd8699dd27275c8c3475c2d51b",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "plan.json": {
      "sha256": "8968716d65f4791e96e9953efac98ab09e37c698aa0025c9457d31c85b9134ba",
      "byte_length": 3710
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "60fd9e9b341ce370c135ed7d5b7e1b1ab9fc1fe9a44d88f9ec134d1155bcb25e",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "4647154bc5258c9aacfa4c0fac7d355ecea93f8cb9137905e20bcd7430b23d8e",
      "byte_length": 2563
    },
    "图像预览.md": {
      "sha256": "f70b0bd941bca8715fcf8b3e5b4f140b818dc520652d742822107029c1beb8a9",
      "byte_length": 2939
    }
  }
}
```
