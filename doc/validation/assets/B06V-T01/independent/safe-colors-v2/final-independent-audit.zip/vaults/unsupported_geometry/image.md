# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "4b04b5bd-8436-4d2f-a852-b750ef00d59f",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "unsupported_geometry",
    "title": "图像保真样例 unsupported_geometry",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c8e012111a2cfe1388dd2a254c9e4ffe5f13fff4b9bff133fe3dbd700ecbd85c"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "fcb59d02fd10698fc7109666b06463196a8c91c55aa21358c35f7a6604eb57dd"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": "mmol/L",
        "legend_id": null
      },
      {
        "id": "response",
        "kind": "unsupported",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "positive",
        "label": "activates",
        "unit": "s^-1",
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c5efcb",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "original_image",
    "fallback_reasons": [
      "IMAGE_GEOMETRY_UNSUPPORTED"
    ],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "9d5e81e877650906f5a53f7f9d05d42be66ce8fd80b81cc4dcf8be6a4c77616f",
    "byte_length": 3523
  },
  "inputs": {
    "original.png": {
      "sha256": "c8e012111a2cfe1388dd2a254c9e4ffe5f13fff4b9bff133fe3dbd700ecbd85c",
      "byte_length": 22417
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "095c5b01e0c5bc37cbca57e3a987304c081ad9fefd336ea239982fe905d76536",
      "byte_length": 505
    },
    "source-semantics.json": {
      "sha256": "fcb59d02fd10698fc7109666b06463196a8c91c55aa21358c35f7a6604eb57dd",
      "byte_length": 2383
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "6c17bfb6c9ec7fa67b7fcfc4ffa3990777369a4a8447d5dc07fc6665f2fc5b3d",
      "byte_length": 2707,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 74
        },
        {
          "kind": "image_embed",
          "source_field": "case.image",
          "start_byte": 91,
          "end_byte": 108
        },
        {
          "kind": "fallback_reason",
          "source_field": "decision.fallback_reasons[0]",
          "start_byte": 118,
          "end_byte": 187
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 212,
          "end_byte": 291
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 341,
          "end_byte": 345
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 370,
          "end_byte": 374
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 399,
          "end_byte": 403
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 428,
          "end_byte": 434
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 459,
          "end_byte": 480
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 511,
          "end_byte": 527
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 566,
          "end_byte": 574
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 599,
          "end_byte": 610
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 635,
          "end_byte": 643
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 668,
          "end_byte": 672
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 697,
          "end_byte": 718
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 749,
          "end_byte": 766
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 805,
          "end_byte": 811
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 836,
          "end_byte": 840
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 865,
          "end_byte": 871
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 896,
          "end_byte": 902
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 927,
          "end_byte": 948
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 979,
          "end_byte": 996
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 1046,
          "end_byte": 1050
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 1081,
          "end_byte": 1085
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 1116,
          "end_byte": 1124
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1155,
          "end_byte": 1164
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1195,
          "end_byte": 1204
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1235,
          "end_byte": 1242
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1273,
          "end_byte": 1281
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1306,
          "end_byte": 1315
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1340,
          "end_byte": 1344
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1369,
          "end_byte": 1377
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1416,
          "end_byte": 1420
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1451,
          "end_byte": 1459
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1490,
          "end_byte": 1496
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1527,
          "end_byte": 1536
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1567,
          "end_byte": 1576
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1607,
          "end_byte": 1614
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1645,
          "end_byte": 1653
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1678,
          "end_byte": 1686
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1711,
          "end_byte": 1715
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1740,
          "end_byte": 1748
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1810,
          "end_byte": 1819
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1844,
          "end_byte": 1848
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 1879,
          "end_byte": 1887
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 1918,
          "end_byte": 1925
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 1970,
          "end_byte": 1983
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 2008,
          "end_byte": 2016
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 2047,
          "end_byte": 2053
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 2084,
          "end_byte": 2091
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 2141,
          "end_byte": 2149
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2174,
          "end_byte": 2175
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2200,
          "end_byte": 2219
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2244,
          "end_byte": 2251
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2282,
          "end_byte": 2297
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2336,
          "end_byte": 2344
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2369,
          "end_byte": 2370
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2395,
          "end_byte": 2414
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2439,
          "end_byte": 2446
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2477,
          "end_byte": 2493
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2524,
          "end_byte": 2579
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2604,
          "end_byte": 2655
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2678,
          "end_byte": 2706
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "3c5663ac6671b50a667c5f1a9bca6361ce7d1b14b0a7d27368428e2d535cdf7f",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c8e012111a2cfe1388dd2a254c9e4ffe5f13fff4b9bff133fe3dbd700ecbd85c",
      "byte_length": 22417
    },
    "plan.json": {
      "sha256": "9d5e81e877650906f5a53f7f9d05d42be66ce8fd80b81cc4dcf8be6a4c77616f",
      "byte_length": 3523
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "095c5b01e0c5bc37cbca57e3a987304c081ad9fefd336ea239982fe905d76536",
      "byte_length": 505
    },
    "source-semantics.json": {
      "sha256": "fcb59d02fd10698fc7109666b06463196a8c91c55aa21358c35f7a6604eb57dd",
      "byte_length": 2383
    },
    "图像预览.md": {
      "sha256": "6c17bfb6c9ec7fa67b7fcfc4ffa3990777369a4a8447d5dc07fc6665f2fc5b3d",
      "byte_length": 2707
    }
  }
}
```
