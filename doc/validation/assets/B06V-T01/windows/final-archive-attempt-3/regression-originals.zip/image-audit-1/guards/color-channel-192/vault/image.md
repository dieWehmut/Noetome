# 选定图像保真预览报告

状态：passed；预览：rendered；知识：pending；科学质量：not_run；发布：false。

仅选定图像和手工结构声明工程核对；不执行自动图像理解；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_image",
  "scope": "selected_image_fidelity_v1",
  "request_id": "1f882b63-d717-4e93-a4de-21ab3e209fa9",
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "case": {
    "schema_version": 1,
    "purpose": "image_fidelity",
    "selection_id": "signed_arrows",
    "title": "图像保真样例 signed_arrows",
    "source_kind": "diagram",
    "image": {
      "file": "source.png",
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "aa96e8caf22463cad3b711cfc0e4400167e1ba632643e31ef5d267295e4e5489"
    },
    "dimensions": [
      960,
      520
    ],
    "readability": "clear"
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_image_declaration",
    "author": "independent_cc0_fixture_author",
    "complete": true,
    "data_available": false,
    "caption": "Fictional engineering diagram; manual source declaration, no image recognition.",
    "conditions": [
      "Only the selected schematic relationships are asserted."
    ],
    "exceptions": [
      "No scientific accuracy or measured data is claimed."
    ],
    "elements": [
      {
        "id": "feed",
        "kind": "rect",
        "bbox": [
          40,
          150,
          220,
          120
        ],
        "label": "Feed",
        "unit": "mmol/L",
        "legend_id": "positive"
      },
      {
        "id": "response",
        "kind": "circle",
        "bbox": [
          390,
          120,
          180,
          180
        ],
        "label": "Response",
        "unit": "a.u.",
        "legend_id": null
      },
      {
        "id": "output",
        "kind": "rect",
        "bbox": [
          700,
          150,
          220,
          120
        ],
        "label": "Outlet",
        "unit": "mmol/L",
        "legend_id": null
      }
    ],
    "relations": [
      {
        "id": "gain",
        "from": "feed",
        "to": "response",
        "start": [
          260,
          210
        ],
        "end": [
          390,
          210
        ],
        "direction": "forward",
        "effect": "positive",
        "label": "activates",
        "unit": "s^-1",
        "legend_id": "positive"
      },
      {
        "id": "loss",
        "from": "response",
        "to": "output",
        "start": [
          570,
          210
        ],
        "end": [
          700,
          210
        ],
        "direction": "forward",
        "effect": "negative",
        "label": "inhibits",
        "unit": "s^-1",
        "legend_id": "negative"
      }
    ],
    "spatial_relations": [
      {
        "id": "feed-left",
        "a": "feed",
        "b": "response",
        "relation": "left_of"
      },
      {
        "id": "response-left",
        "a": "response",
        "b": "output",
        "relation": "left_of"
      }
    ],
    "legend": [
      {
        "id": "positive",
        "label": "+",
        "meaning": "positive activation",
        "color": "#c0c0c0",
        "bbox": [
          40,
          360,
          360,
          45
        ]
      },
      {
        "id": "negative",
        "label": "-",
        "meaning": "negative inhibition",
        "color": "#f5c1c1",
        "bbox": [
          500,
          360,
          400,
          45
        ]
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "svg_supported": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "author_declaration": "passed",
    "geometry_review": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "svg_redraw",
    "fallback_reasons": [],
    "issue_codes": []
  },
  "plan_fingerprint": {
    "sha256": "d2cdcb8cf5cbfd408278152067e287da56227fc3747e4e97f4ae090f303b9965",
    "byte_length": 3466
  },
  "inputs": {
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "source-case.json": {
      "sha256": "f5420ef84bf923bd9eae85f002a4478d717b008501a992f632531032a347a532",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "aa96e8caf22463cad3b711cfc0e4400167e1ba632643e31ef5d267295e4e5489",
      "byte_length": 2384
    }
  },
  "files": [
    {
      "relative_path": "图像预览.md",
      "content_sha256": "8e9f99c2b8cb589db57148650db1d083934ceb074562e5bbcf64c88fe17d1f4d",
      "byte_length": 2598,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 35,
          "end_byte": 67
        },
        {
          "kind": "image_embed",
          "source_field": "semantics",
          "start_byte": 84,
          "end_byte": 100
        },
        {
          "kind": "caption",
          "source_field": "semantics.caption",
          "start_byte": 121,
          "end_byte": 200
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[0].id",
          "start_byte": 250,
          "end_byte": 254
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[0].kind",
          "start_byte": 279,
          "end_byte": 283
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 308,
          "end_byte": 312
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 337,
          "end_byte": 343
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[0].legend_id",
          "start_byte": 368,
          "end_byte": 376
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 407,
          "end_byte": 423
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[1].id",
          "start_byte": 462,
          "end_byte": 470
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[1].kind",
          "start_byte": 495,
          "end_byte": 501
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 526,
          "end_byte": 534
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 559,
          "end_byte": 563
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[1].legend_id",
          "start_byte": 588,
          "end_byte": 609
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 640,
          "end_byte": 657
        },
        {
          "kind": "element_id",
          "source_field": "semantics.elements[2].id",
          "start_byte": 696,
          "end_byte": 702
        },
        {
          "kind": "element_kind",
          "source_field": "semantics.elements[2].kind",
          "start_byte": 727,
          "end_byte": 731
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 756,
          "end_byte": 762
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 787,
          "end_byte": 793
        },
        {
          "kind": "element_legend",
          "source_field": "semantics.elements[2].legend_id",
          "start_byte": 818,
          "end_byte": 839
        },
        {
          "kind": "element_geometry",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 870,
          "end_byte": 887
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[0].id",
          "start_byte": 937,
          "end_byte": 941
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[0].from",
          "start_byte": 972,
          "end_byte": 976
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[0].to",
          "start_byte": 1007,
          "end_byte": 1015
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[0].start",
          "start_byte": 1046,
          "end_byte": 1055
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[0].end",
          "start_byte": 1086,
          "end_byte": 1095
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 1126,
          "end_byte": 1133
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 1164,
          "end_byte": 1172
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 1197,
          "end_byte": 1206
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 1231,
          "end_byte": 1235
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[0].legend_id",
          "start_byte": 1260,
          "end_byte": 1268
        },
        {
          "kind": "relation_id",
          "source_field": "semantics.relations[1].id",
          "start_byte": 1307,
          "end_byte": 1311
        },
        {
          "kind": "relation_from",
          "source_field": "semantics.relations[1].from",
          "start_byte": 1342,
          "end_byte": 1350
        },
        {
          "kind": "relation_to",
          "source_field": "semantics.relations[1].to",
          "start_byte": 1381,
          "end_byte": 1387
        },
        {
          "kind": "relation_start",
          "source_field": "semantics.relations[1].start",
          "start_byte": 1418,
          "end_byte": 1427
        },
        {
          "kind": "relation_end",
          "source_field": "semantics.relations[1].end",
          "start_byte": 1458,
          "end_byte": 1467
        },
        {
          "kind": "relation_direction",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 1498,
          "end_byte": 1505
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 1536,
          "end_byte": 1544
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 1569,
          "end_byte": 1577
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 1602,
          "end_byte": 1606
        },
        {
          "kind": "relation_legend",
          "source_field": "semantics.relations[1].legend_id",
          "start_byte": 1631,
          "end_byte": 1639
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].id",
          "start_byte": 1701,
          "end_byte": 1710
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].a",
          "start_byte": 1735,
          "end_byte": 1739
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].b",
          "start_byte": 1770,
          "end_byte": 1778
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[0].relation",
          "start_byte": 1809,
          "end_byte": 1816
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].id",
          "start_byte": 1861,
          "end_byte": 1874
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].a",
          "start_byte": 1899,
          "end_byte": 1907
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].b",
          "start_byte": 1938,
          "end_byte": 1944
        },
        {
          "kind": "spatial_relation",
          "source_field": "semantics.spatial_relations[1].relation",
          "start_byte": 1975,
          "end_byte": 1982
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[0].id",
          "start_byte": 2032,
          "end_byte": 2040
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 2065,
          "end_byte": 2066
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 2091,
          "end_byte": 2110
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[0].color",
          "start_byte": 2135,
          "end_byte": 2142
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 2173,
          "end_byte": 2188
        },
        {
          "kind": "legend_id",
          "source_field": "semantics.legend[1].id",
          "start_byte": 2227,
          "end_byte": 2235
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 2260,
          "end_byte": 2261
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2286,
          "end_byte": 2305
        },
        {
          "kind": "legend_color",
          "source_field": "semantics.legend[1].color",
          "start_byte": 2330,
          "end_byte": 2337
        },
        {
          "kind": "legend_geometry",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 2368,
          "end_byte": 2384
        },
        {
          "kind": "conditions",
          "source_field": "semantics.conditions[0]",
          "start_byte": 2415,
          "end_byte": 2470
        },
        {
          "kind": "exceptions",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 2495,
          "end_byte": 2546
        },
        {
          "kind": "attachment_link",
          "source_field": "case.image",
          "start_byte": 2569,
          "end_byte": 2597
        }
      ]
    },
    {
      "relative_path": "redrawn.svg",
      "content_sha256": "5caba6c1e20c6424873a7f91f4ede7aa07d595af0321288b686126cd71af4a40",
      "byte_length": 3577,
      "mappings": [
        {
          "kind": "canvas_background",
          "source_field": "case.dimensions",
          "start_byte": 88,
          "end_byte": 165
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[1].bbox",
          "start_byte": 166,
          "end_byte": 283
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[0].bbox",
          "start_byte": 284,
          "end_byte": 398
        },
        {
          "kind": "element_shape",
          "source_field": "semantics.elements[2].bbox",
          "start_byte": 399,
          "end_byte": 516
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[0].label",
          "start_byte": 517,
          "end_byte": 658
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[0].unit",
          "start_byte": 659,
          "end_byte": 801
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[1].label",
          "start_byte": 802,
          "end_byte": 951
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[1].unit",
          "start_byte": 952,
          "end_byte": 1096
        },
        {
          "kind": "element_label",
          "source_field": "semantics.elements[2].label",
          "start_byte": 1097,
          "end_byte": 1242
        },
        {
          "kind": "element_unit",
          "source_field": "semantics.elements[2].unit",
          "start_byte": 1243,
          "end_byte": 1387
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[0].bbox",
          "start_byte": 1388,
          "end_byte": 1504
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[0].label",
          "start_byte": 1505,
          "end_byte": 1646
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[0].meaning",
          "start_byte": 1647,
          "end_byte": 1808
        },
        {
          "kind": "legend_swatch",
          "source_field": "semantics.legend[1].bbox",
          "start_byte": 1809,
          "end_byte": 1926
        },
        {
          "kind": "legend_label",
          "source_field": "semantics.legend[1].label",
          "start_byte": 1927,
          "end_byte": 2068
        },
        {
          "kind": "legend_meaning",
          "source_field": "semantics.legend[1].meaning",
          "start_byte": 2069,
          "end_byte": 2230
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[0]",
          "start_byte": 2231,
          "end_byte": 2327
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[0].direction",
          "start_byte": 2328,
          "end_byte": 2468
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[0].effect",
          "start_byte": 2469,
          "end_byte": 2609
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[0].label",
          "start_byte": 2610,
          "end_byte": 2757
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[0].unit",
          "start_byte": 2758,
          "end_byte": 2899
        },
        {
          "kind": "relation_line",
          "source_field": "semantics.relations[1]",
          "start_byte": 2900,
          "end_byte": 2996
        },
        {
          "kind": "relation_head",
          "source_field": "semantics.relations[1].direction",
          "start_byte": 2997,
          "end_byte": 3137
        },
        {
          "kind": "relation_effect",
          "source_field": "semantics.relations[1].effect",
          "start_byte": 3138,
          "end_byte": 3280
        },
        {
          "kind": "relation_label",
          "source_field": "semantics.relations[1].label",
          "start_byte": 3281,
          "end_byte": 3427
        },
        {
          "kind": "relation_unit",
          "source_field": "semantics.relations[1].unit",
          "start_byte": 3428,
          "end_byte": 3569
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "35e8a76b6dab0ccd2576ff5c004157a3b10ba63fefd5f918712faf6dc0a6a176",
      "byte_length": 148
    },
    "original.png": {
      "sha256": "c010a5884ad8c0442a320bc57f61f17d6c01d828816426a4c3e28774c5dbd64f",
      "byte_length": 22138
    },
    "plan.json": {
      "sha256": "d2cdcb8cf5cbfd408278152067e287da56227fc3747e4e97f4ae090f303b9965",
      "byte_length": 3466
    },
    "profile.json": {
      "sha256": "ca6ddf79660ab307434f7b6add58fcc8371b2127b057798b3b39034c408ee9ce",
      "byte_length": 142
    },
    "redrawn.svg": {
      "sha256": "5caba6c1e20c6424873a7f91f4ede7aa07d595af0321288b686126cd71af4a40",
      "byte_length": 3577
    },
    "source-case.json": {
      "sha256": "f5420ef84bf923bd9eae85f002a4478d717b008501a992f632531032a347a532",
      "byte_length": 491
    },
    "source-semantics.json": {
      "sha256": "aa96e8caf22463cad3b711cfc0e4400167e1ba632643e31ef5d267295e4e5489",
      "byte_length": 2384
    },
    "图像预览.md": {
      "sha256": "8e9f99c2b8cb589db57148650db1d083934ceb074562e5bbcf64c88fe17d1f4d",
      "byte_length": 2598
    }
  }
}
```
