# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "928a27f1-8056-409e-aaca-9fb4c0260218",
  "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000007"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "0b6f315e495e6d25899a5162bb2d80e7e1185880886ae6a88120947a999ad20e",
    "byte_length": 41454
  },
  "plan_fingerprint": {
    "sha256": "2e82094355b31658cfc52e95e67923083162239081acd955a130414316e78a54",
    "byte_length": 17326
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "0b6f315e495e6d25899a5162bb2d80e7e1185880886ae6a88120947a999ad20e",
      "byte_length": 41454
    },
    ".coordination-owner.json": {
      "sha256": "c7029828d2ba09dc640f7ce68de69dbd54697f3e4113ddc147c35bda407f4389",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "505d36afbdc76448e410d229740dbe04575ef316d6acba2e8c54ec64d9be1bfe",
      "byte_length": 44925
    },
    ".coordination-report.md": {
      "sha256": "4f921bd868fe6ec8a62087e7e1867b4c504bbc9ee0a9db125a28c28efc627f95",
      "byte_length": 45400
    },
    ".identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ae353edc0b7525765b76566f4642109a31833f363dc86a6f2879c9a487551db0",
      "byte_length": 3077
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "803ead79532339108932b4dedee2f5019f907d655451fda0aab40fcfe720d1a4",
      "byte_length": 12416
    },
    ".input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    ".input-a--source-snapshot.json": {
      "sha256": "4ed89a1204d33ed695ea6d4ab2f62087ab33fc075683460a09de83326966c23c",
      "byte_length": 1067
    },
    ".input-a--verification.json": {
      "sha256": "43cc2b58eb8d8eb523e7337ce6cd87902e89a67707e62a5d25802b1d94b45e79",
      "byte_length": 16897
    },
    ".input-a--verification.md": {
      "sha256": "727004b90ce3ba23cb51234df07c8fde1ef187d85e4b01905d4680948377db47",
      "byte_length": 17331
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9ae0d8e5df47e0a6bc1a999604697f04756d47446c67b5e27bd49d635ff13829",
      "byte_length": 3086
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "5b1e72bf3a1056d95a01585d9417e8b797d746774b6caeb473105ee8b684b85e",
      "byte_length": 12452
    },
    ".input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    ".input-b--source-snapshot.json": {
      "sha256": "075dc33d75f38a0441c0cb12290ceed82fdb2f2f4af9c78d94f31a049a3f5a05",
      "byte_length": 1070
    },
    ".input-b--verification.json": {
      "sha256": "afabe80d71654bdb0a919d7235b651124194e677756848e378fc0acc5f3716a3",
      "byte_length": 16930
    },
    ".input-b--verification.md": {
      "sha256": "74b9feb6219261f63292fb7a55161f9b16bbc7589fef9cafcbb8b167d59637f0",
      "byte_length": 17364
    },
    ".selection-original.json": {
      "sha256": "5d3bec196d9d19da5839f8c8e2568d9060df07b74d1d4f4467cb43d0fe80a1c8",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "4a4a6b90d1b1a40d8940f5a374c58770b541092feb21682a9bf080be167dd046",
      "byte_length": 571,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa",
            "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 44,
          "end_byte": 60
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005"
          ],
          "start_byte": 79,
          "end_byte": 95
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [
            "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1"
          ],
          "occurrence_ids": [
            "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 173,
          "end_byte": 320
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006"
          ],
          "start_byte": 325,
          "end_byte": 342
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [
            "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4"
          ],
          "occurrence_ids": [
            "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 420,
          "end_byte": 567
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000005",
          "target_path": "对象-60000000-0000-4000-8000-000000000005.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 96,
          "end_byte": 170
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000006",
          "target_path": "对象-60000000-0000-4000-8000-000000000006.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 343,
          "end_byte": 417
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000005.md",
      "note_id": "object-60000000-0000-4000-8000-000000000005",
      "plan_revision": 1,
      "content_sha256": "c1d81677e3427713647012adadf77d97e2760151d89113f4339a6212f09674f5",
      "byte_length": 375,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1"
          ],
          "occurrence_ids": [
            "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 37,
          "end_byte": 373
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000006.md",
      "note_id": "object-60000000-0000-4000-8000-000000000006",
      "plan_revision": 1,
      "content_sha256": "0cf17e09e21f541849ee41cc70f8d2f0012d38126cad2ca41dcf8b41f216d615",
      "byte_length": 378,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4"
          ],
          "occurrence_ids": [
            "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 38,
          "end_byte": 376
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "0b6f315e495e6d25899a5162bb2d80e7e1185880886ae6a88120947a999ad20e",
      "byte_length": 41454
    },
    ".coordination-owner.json": {
      "sha256": "c7029828d2ba09dc640f7ce68de69dbd54697f3e4113ddc147c35bda407f4389",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "505d36afbdc76448e410d229740dbe04575ef316d6acba2e8c54ec64d9be1bfe",
      "byte_length": 44925
    },
    ".coordination-report.md": {
      "sha256": "4f921bd868fe6ec8a62087e7e1867b4c504bbc9ee0a9db125a28c28efc627f95",
      "byte_length": 45400
    },
    ".identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ae353edc0b7525765b76566f4642109a31833f363dc86a6f2879c9a487551db0",
      "byte_length": 3077
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "803ead79532339108932b4dedee2f5019f907d655451fda0aab40fcfe720d1a4",
      "byte_length": 12416
    },
    ".input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    ".input-a--source-snapshot.json": {
      "sha256": "4ed89a1204d33ed695ea6d4ab2f62087ab33fc075683460a09de83326966c23c",
      "byte_length": 1067
    },
    ".input-a--verification.json": {
      "sha256": "43cc2b58eb8d8eb523e7337ce6cd87902e89a67707e62a5d25802b1d94b45e79",
      "byte_length": 16897
    },
    ".input-a--verification.md": {
      "sha256": "727004b90ce3ba23cb51234df07c8fde1ef187d85e4b01905d4680948377db47",
      "byte_length": 17331
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9ae0d8e5df47e0a6bc1a999604697f04756d47446c67b5e27bd49d635ff13829",
      "byte_length": 3086
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "5b1e72bf3a1056d95a01585d9417e8b797d746774b6caeb473105ee8b684b85e",
      "byte_length": 12452
    },
    ".input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    ".input-b--source-snapshot.json": {
      "sha256": "075dc33d75f38a0441c0cb12290ceed82fdb2f2f4af9c78d94f31a049a3f5a05",
      "byte_length": 1070
    },
    ".input-b--verification.json": {
      "sha256": "afabe80d71654bdb0a919d7235b651124194e677756848e378fc0acc5f3716a3",
      "byte_length": 16930
    },
    ".input-b--verification.md": {
      "sha256": "74b9feb6219261f63292fb7a55161f9b16bbc7589fef9cafcbb8b167d59637f0",
      "byte_length": 17364
    },
    ".owner.json": {
      "sha256": "7175a5465e500b368e0b611c3da995064195aeb877f5f965c03bf316723da857",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "5d3bec196d9d19da5839f8c8e2568d9060df07b74d1d4f4467cb43d0fe80a1c8",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "2e82094355b31658cfc52e95e67923083162239081acd955a130414316e78a54",
      "byte_length": 17326
    },
    "对象-60000000-0000-4000-8000-000000000005.md": {
      "sha256": "c1d81677e3427713647012adadf77d97e2760151d89113f4339a6212f09674f5",
      "byte_length": 375
    },
    "对象-60000000-0000-4000-8000-000000000006.md": {
      "sha256": "0cf17e09e21f541849ee41cc70f8d2f0012d38126cad2ca41dcf8b41f216d615",
      "byte_length": 378
    },
    "知识比较.md": {
      "sha256": "4a4a6b90d1b1a40d8940f5a374c58770b541092feb21682a9bf080be167dd046",
      "byte_length": 571
    }
  }
}
```
