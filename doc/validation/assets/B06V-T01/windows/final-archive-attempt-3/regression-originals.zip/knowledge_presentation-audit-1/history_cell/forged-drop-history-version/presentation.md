# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "f07f42b2-67b2-4c4b-b6ab-1634c6f10baa",
  "project_id": "022f1fcd-e6a1-4c89-ab3a-14ad6e742bd9",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "8feb81a51d103c3e293e9f57d33c585523eb37cb5be146288266476ccb8df331",
    "byte_length": 61820
  },
  "plan_fingerprint": {
    "sha256": "4e329c7c056c9afa5496940bf4e7b42422e13ac5f68aa417efec661ee4b8df90",
    "byte_length": 22658
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "8feb81a51d103c3e293e9f57d33c585523eb37cb5be146288266476ccb8df331",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "55c7bcbe3b07da008edaaf308806f735be6507a6fa653bfa430cb8e004820062",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d2d4e47193a43e1c11ba134d1e21256226452cd2c4e782a21d8191f37ac4e670",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "d49afcba37dd980eebe30999e60993a87770ae8ceba831be71c5700356fa0254",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "31da1d395d1a349b46de394e1b06564acf3a29a0e117d2b525277982ea58cca8",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "97d74230dd189edb2488af9d076dfc5cb8076ae5d973e6f30e294c3ac9121e79",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "c0bbdcb084a2a4fd5186bf4fe4d010f4690b3b39a2da7a2b310374f512e4e7a3",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "6b193f9bbbdc102b1ddb12d3ecc55bc42fc91228a746333362bb57d5c81912d1",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "579ffc5700a955f3caaace579066efe2f8dc99656ee0367a55c9e565c0fc95c6",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9e05a1dd0c16aef9eb085922cecb3bf6624fb223be6d36c721c808ee0d52ed6c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "0bca89df9c351d6e582faee307e8018b6e8b0f368c8be93861d0d43e9ce07388",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "8b511d3497dd7d73f2566036bb70239f4fd46943454de91a9c3e383634fa10e2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "cdd4073893fed70f3c997ea9e4ec8dc9a16815cc8de26e6c939ee21fcd17c1e3",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "52e1d3d55b6a470f87b184ef8046b51b34338e7e7d4bab2373e3a94cc4a1983f",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "1bef0809dcfa1407e2ea9c87198c9e004332eb381e30176a52fe4c92b9b65d89",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "1e1a889f8240511a607d60a84c33cba45e5660223f9da0a36e44f547c2757e70",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "3bdde2e8453133d868494ea60e98bee1d246cb78dd0ab7669844acd9978022a6",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "066ff6392a5ea532fbd4945f275d4803064fcfa57d427ba1f9a27061d00ad193",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "ed2153322e69de24e7bf1ed51d168c567be0eb4a2f26129fd74cf53322d59aed",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "ff32efdf1bf7c9c9659c9d2924df093c39ad10444f58f844d11a96589eb9978e",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "211e25fe70e8827c0eef3c80cf1f756006e4024bc1d326fd9b24bffc25c8acdb",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0b1a16983c12fadbe9b4a885f265d8d4aa3fb7e43aa1cf0e67cc949fcb851e75",
            "occ-54007e2e53484b06830104db0beb4dd88f2a534cded33ef89b5266badd684ec5",
            "occ-be976f01010c6a6b45354f9154a8ad773b4a55f7f79cefd52cc00f290b3aee12"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0b1a16983c12fadbe9b4a885f265d8d4aa3fb7e43aa1cf0e67cc949fcb851e75",
            "occ-be976f01010c6a6b45354f9154a8ad773b4a55f7f79cefd52cc00f290b3aee12"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-0b1a16983c12fadbe9b4a885f265d8d4aa3fb7e43aa1cf0e67cc949fcb851e75",
            "occ-be976f01010c6a6b45354f9154a8ad773b4a55f7f79cefd52cc00f290b3aee12"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-54007e2e53484b06830104db0beb4dd88f2a534cded33ef89b5266badd684ec5"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-54007e2e53484b06830104db0beb4dd88f2a534cded33ef89b5266badd684ec5"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-0b1a16983c12fadbe9b4a885f265d8d4aa3fb7e43aa1cf0e67cc949fcb851e75"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-be976f01010c6a6b45354f9154a8ad773b4a55f7f79cefd52cc00f290b3aee12"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-54007e2e53484b06830104db0beb4dd88f2a534cded33ef89b5266badd684ec5"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "8feb81a51d103c3e293e9f57d33c585523eb37cb5be146288266476ccb8df331",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "55c7bcbe3b07da008edaaf308806f735be6507a6fa653bfa430cb8e004820062",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d2d4e47193a43e1c11ba134d1e21256226452cd2c4e782a21d8191f37ac4e670",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "d49afcba37dd980eebe30999e60993a87770ae8ceba831be71c5700356fa0254",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "31da1d395d1a349b46de394e1b06564acf3a29a0e117d2b525277982ea58cca8",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "97d74230dd189edb2488af9d076dfc5cb8076ae5d973e6f30e294c3ac9121e79",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "c0bbdcb084a2a4fd5186bf4fe4d010f4690b3b39a2da7a2b310374f512e4e7a3",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "6b193f9bbbdc102b1ddb12d3ecc55bc42fc91228a746333362bb57d5c81912d1",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "579ffc5700a955f3caaace579066efe2f8dc99656ee0367a55c9e565c0fc95c6",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9e05a1dd0c16aef9eb085922cecb3bf6624fb223be6d36c721c808ee0d52ed6c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "0bca89df9c351d6e582faee307e8018b6e8b0f368c8be93861d0d43e9ce07388",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "8b511d3497dd7d73f2566036bb70239f4fd46943454de91a9c3e383634fa10e2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "cdd4073893fed70f3c997ea9e4ec8dc9a16815cc8de26e6c939ee21fcd17c1e3",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "52e1d3d55b6a470f87b184ef8046b51b34338e7e7d4bab2373e3a94cc4a1983f",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "1bef0809dcfa1407e2ea9c87198c9e004332eb381e30176a52fe4c92b9b65d89",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "1e1a889f8240511a607d60a84c33cba45e5660223f9da0a36e44f547c2757e70",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "3bdde2e8453133d868494ea60e98bee1d246cb78dd0ab7669844acd9978022a6",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "066ff6392a5ea532fbd4945f275d4803064fcfa57d427ba1f9a27061d00ad193",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "ed2153322e69de24e7bf1ed51d168c567be0eb4a2f26129fd74cf53322d59aed",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "b4dbe33951727181a39dfdc8d616fca0b981e53ce833c009d406318e06a97c14",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "ff32efdf1bf7c9c9659c9d2924df093c39ad10444f58f844d11a96589eb9978e",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "4e329c7c056c9afa5496940bf4e7b42422e13ac5f68aa417efec661ee4b8df90",
      "byte_length": 22658
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "211e25fe70e8827c0eef3c80cf1f756006e4024bc1d326fd9b24bffc25c8acdb",
      "byte_length": 542
    }
  }
}
```
