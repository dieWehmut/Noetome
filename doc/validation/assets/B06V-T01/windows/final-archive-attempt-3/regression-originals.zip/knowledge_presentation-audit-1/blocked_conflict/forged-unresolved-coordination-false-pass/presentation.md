# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "e01fb3a9-d235-467e-bb91-b9221f998b8c",
  "project_id": "4e7cc45e-e0b6-41fb-a631-575e451411fb",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 1,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "0d38c68177f0c88134e11d510ba0d3bd06e91b7d245400019cffed80adc28df8",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "4a08509631d5df1dd4753fc74e4a737ac7f71f1866db26a1ae015d60f7a3592f",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "71523d57926290dbb047b191cc37c02e1fdd627282b6240830a88ed4725d0669",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "18ce6ae16552b6ce75ba61e97e86bd7b4a81e471b3e82be254d6fea594941f03",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "bb3365f641a86520bbce8328ef917a25eebe4381fff9c8ba2684ebf7947d214f",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2564ff591dde6a18b6d05bb300c421a2acc827b951850a07634d98f348c211e9",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "e8702890e0f9b15077a26e79517e9588b6b8a7549b227508df8694e53dca77e1",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "6c3616703b7da8b74aff2a0cb6df6c3cf8e46ab67cd98d218af2588961695619",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "20827c4945fbb2f3b38429de7dbe65bfd47ff19fbaf46df9bbd4d81e82e6a477",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b7f5f86173ee093c7f3069da96d8d6ea13b304b74364303fbf5cffb654b04eed",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "8c13e4c264dcbfc218f330548a98789708eab7b168c5d8afe56117d616061ae3",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b68aff858408083976380499233c030f767026fc45885d398e1517e45e8c25a0",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "4129c5bb815ccea2287173d3d433bcaa0cac9dc608a6d7be2cc0aed53ec16a78",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "8a48035861d30d563ddbe4cf10e148b0203ef166b23ace265598d5c85032af20",
      "byte_length": 4330
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "0d38c68177f0c88134e11d510ba0d3bd06e91b7d245400019cffed80adc28df8",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "4a08509631d5df1dd4753fc74e4a737ac7f71f1866db26a1ae015d60f7a3592f",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "71523d57926290dbb047b191cc37c02e1fdd627282b6240830a88ed4725d0669",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "18ce6ae16552b6ce75ba61e97e86bd7b4a81e471b3e82be254d6fea594941f03",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "bb3365f641a86520bbce8328ef917a25eebe4381fff9c8ba2684ebf7947d214f",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2564ff591dde6a18b6d05bb300c421a2acc827b951850a07634d98f348c211e9",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "e8702890e0f9b15077a26e79517e9588b6b8a7549b227508df8694e53dca77e1",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "6c3616703b7da8b74aff2a0cb6df6c3cf8e46ab67cd98d218af2588961695619",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "20827c4945fbb2f3b38429de7dbe65bfd47ff19fbaf46df9bbd4d81e82e6a477",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b7f5f86173ee093c7f3069da96d8d6ea13b304b74364303fbf5cffb654b04eed",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "8c13e4c264dcbfc218f330548a98789708eab7b168c5d8afe56117d616061ae3",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b68aff858408083976380499233c030f767026fc45885d398e1517e45e8c25a0",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "4129c5bb815ccea2287173d3d433bcaa0cac9dc608a6d7be2cc0aed53ec16a78",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "2be7a165dffcdeb99539763b28c3e7651485a8fec573678bcfe1bfcd36984a3b",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "8a48035861d30d563ddbe4cf10e148b0203ef166b23ace265598d5c85032af20",
      "byte_length": 4330
    }
  }
}
```
