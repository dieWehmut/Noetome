# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "70e01c55-af48-40c1-9f6e-401bf7d28e4f",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000005",
      "display_name": "甲容器 [α]"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000006",
      "display_name": "乙容器（β）"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000007",
      "display_name": "速率 | 测量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
        "import_id": "052a8e15-ffea-47a8-828f-3dd4d5ff338e",
        "source_id": "d29619a2-f7b6-4353-bb2a-93b49d8f53d5",
        "version_id": "0330866b-a3fb-4452-ae01-6f248d6af2bd",
        "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "import_id": "052a8e15-ffea-47a8-828f-3dd4d5ff338e",
              "manifest_sha256": null,
              "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "parse_id": null,
              "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
              "source_id": "d29619a2-f7b6-4353-bb2a-93b49d8f53d5",
              "version_id": "0330866b-a3fb-4452-ae01-6f248d6af2bd"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "import_id": "052a8e15-ffea-47a8-828f-3dd4d5ff338e",
              "manifest_sha256": null,
              "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "parse_id": null,
              "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
              "source_id": "d29619a2-f7b6-4353-bb2a-93b49d8f53d5",
              "version_id": "0330866b-a3fb-4452-ae01-6f248d6af2bd"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 176,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 177,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 176,
            "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 176,
            "quote": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 176,
              "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "甲容器 [α]",
              "速率 | 测量"
            ],
            "compound": "甲容器 [α] 速率 | 测量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "甲容器 [α]",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速率 | 测量",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "actual": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "x < 2",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "计数范围 [1,2]",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          },
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "读数 * 异常时不适用",
          "actual": {
            "body": [
              "读数*异常时不适用"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": [
            "读数 * 异常时不适用"
          ],
          "actual": [
            "读数*异常时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "contexts": [],
            "exceptions": [
              "读数 * 异常时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "ae353edc0b7525765b76566f4642109a31833f363dc86a6f2879c9a487551db0",
          "byte_length": 3077
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
          "byte_length": 780
        },
        "knowledge-ir.json": {
          "sha256": "803ead79532339108932b4dedee2f5019f907d655451fda0aab40fcfe720d1a4",
          "byte_length": 12416
        },
        "review-original.json": {
          "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
          "byte_length": 525
        },
        "source-snapshot.json": {
          "sha256": "4ed89a1204d33ed695ea6d4ab2f62087ab33fc075683460a09de83326966c23c",
          "byte_length": 1067
        },
        "verification.json": {
          "sha256": "43cc2b58eb8d8eb523e7337ce6cd87902e89a67707e62a5d25802b1d94b45e79",
          "byte_length": 16897
        },
        "verification.md": {
          "sha256": "727004b90ce3ba23cb51234df07c8fde1ef187d85e4b01905d4680948377db47",
          "byte_length": 17331
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
        "import_id": "18a9ae89-6ecc-4ae8-aaa0-766ed4630750",
        "source_id": "00fc4e67-5eb5-4413-8819-25a8ce81ab44",
        "version_id": "db6d06c0-582c-454d-a59f-d507afd8b896",
        "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "import_id": "18a9ae89-6ecc-4ae8-aaa0-766ed4630750",
              "manifest_sha256": null,
              "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "parse_id": null,
              "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
              "source_id": "00fc4e67-5eb5-4413-8819-25a8ce81ab44",
              "version_id": "db6d06c0-582c-454d-a59f-d507afd8b896"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "import_id": "18a9ae89-6ecc-4ae8-aaa0-766ed4630750",
              "manifest_sha256": null,
              "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "parse_id": null,
              "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
              "source_id": "00fc4e67-5eb5-4413-8819-25a8ce81ab44",
              "version_id": "db6d06c0-582c-454d-a59f-d507afd8b896"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 179,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 180,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 179,
            "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 179,
            "quote": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 179,
              "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "乙容器（β）",
              "速率 | 测量"
            ],
            "compound": "乙容器（β） 速率 | 测量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "乙容器（β）",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速率 | 测量",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "actual": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "x < 2",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "计数范围 [1,2]",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          },
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "读数 * 异常时不适用",
          "actual": {
            "body": [
              "读数*异常时不适用"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": [
            "读数 * 异常时不适用"
          ],
          "actual": [
            "读数*异常时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "contexts": [],
            "exceptions": [
              "读数 * 异常时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "9ae0d8e5df47e0a6bc1a999604697f04756d47446c67b5e27bd49d635ff13829",
          "byte_length": 3086
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
          "byte_length": 789
        },
        "knowledge-ir.json": {
          "sha256": "5b1e72bf3a1056d95a01585d9417e8b797d746774b6caeb473105ee8b684b85e",
          "byte_length": 12452
        },
        "review-original.json": {
          "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
          "byte_length": 528
        },
        "source-snapshot.json": {
          "sha256": "075dc33d75f38a0441c0cb12290ceed82fdb2f2f4af9c78d94f31a049a3f5a05",
          "byte_length": 1070
        },
        "verification.json": {
          "sha256": "afabe80d71654bdb0a919d7235b651124194e677756848e378fc0acc5f3716a3",
          "byte_length": 16930
        },
        "verification.md": {
          "sha256": "74b9feb6219261f63292fb7a55161f9b16bbc7589fef9cafcbb8b167d59637f0",
          "byte_length": 17364
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 179,
        "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
        "sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8"
      },
      "occurrence_id": "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa",
      "input_id": "b",
      "binding": {
        "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
        "import_id": "18a9ae89-6ecc-4ae8-aaa0-766ed4630750",
        "source_id": "00fc4e67-5eb5-4413-8819-25a8ce81ab44",
        "version_id": "db6d06c0-582c-454d-a59f-d507afd8b896",
        "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "067ab078-0e46-459a-b109-055e751053d8",
          "ordinal": 0,
          "resource_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 180,
        "text": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "乙容器（β）",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速率 | 测量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "qualifiers": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "x < 2",
            "计数范围 [1,2]"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 179,
          "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
          "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000006",
        "60000000-0000-4000-8000-000000000007"
      ],
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "x < 2",
        "计数范围 [1,2]"
      ],
      "exceptions": [
        "读数 * 异常时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 176,
        "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
        "sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42"
      },
      "occurrence_id": "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99",
      "input_id": "a",
      "binding": {
        "project_id": "388f0101-7543-453a-b942-699b043a7ad4",
        "import_id": "052a8e15-ffea-47a8-828f-3dd4d5ff338e",
        "source_id": "d29619a2-f7b6-4353-bb2a-93b49d8f53d5",
        "version_id": "0330866b-a3fb-4452-ae01-6f248d6af2bd",
        "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "5fa66099-6800-46cd-8399-07558a385944",
          "ordinal": 0,
          "resource_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 177,
        "text": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "甲容器 [α]",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速率 | 测量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "qualifiers": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "x < 2",
            "计数范围 [1,2]"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 176,
          "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
          "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000005",
        "60000000-0000-4000-8000-000000000007"
      ],
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "x < 2",
        "计数范围 [1,2]"
      ],
      "exceptions": [
        "读数 * 异常时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4",
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "x<2",
        "计数范围[1,2]"
      ],
      "exceptions": [
        "读数*异常时不适用"
      ],
      "occurrence_ids": [
        "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1",
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "x<2",
        "计数范围[1,2]"
      ],
      "exceptions": [
        "读数*异常时不适用"
      ],
      "occurrence_ids": [
        "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa",
      "right_occurrence_id": "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-19cc37f6229c74474398749127e696512cfa4429d31ac4a332bd775573d3cafa",
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-e5799cc0d2bffa3eb59a02d165ca034a2ad06b88be264092690509912674dd99",
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c7029828d2ba09dc640f7ce68de69dbd54697f3e4113ddc147c35bda407f4389",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "0b6f315e495e6d25899a5162bb2d80e7e1185880886ae6a88120947a999ad20e",
      "byte_length": 41454
    },
    "coordination-original.json": {
      "sha256": "5d3bec196d9d19da5839f8c8e2568d9060df07b74d1d4f4467cb43d0fe80a1c8",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "ae353edc0b7525765b76566f4642109a31833f363dc86a6f2879c9a487551db0",
      "byte_length": 3077
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    "input-a--knowledge-ir.json": {
      "sha256": "803ead79532339108932b4dedee2f5019f907d655451fda0aab40fcfe720d1a4",
      "byte_length": 12416
    },
    "input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    "input-a--source-snapshot.json": {
      "sha256": "4ed89a1204d33ed695ea6d4ab2f62087ab33fc075683460a09de83326966c23c",
      "byte_length": 1067
    },
    "input-a--verification.json": {
      "sha256": "43cc2b58eb8d8eb523e7337ce6cd87902e89a67707e62a5d25802b1d94b45e79",
      "byte_length": 16897
    },
    "input-a--verification.md": {
      "sha256": "727004b90ce3ba23cb51234df07c8fde1ef187d85e4b01905d4680948377db47",
      "byte_length": 17331
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "9ae0d8e5df47e0a6bc1a999604697f04756d47446c67b5e27bd49d635ff13829",
      "byte_length": 3086
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    "input-b--knowledge-ir.json": {
      "sha256": "5b1e72bf3a1056d95a01585d9417e8b797d746774b6caeb473105ee8b684b85e",
      "byte_length": 12452
    },
    "input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    "input-b--source-snapshot.json": {
      "sha256": "075dc33d75f38a0441c0cb12290ceed82fdb2f2f4af9c78d94f31a049a3f5a05",
      "byte_length": 1070
    },
    "input-b--verification.json": {
      "sha256": "afabe80d71654bdb0a919d7235b651124194e677756848e378fc0acc5f3716a3",
      "byte_length": 16930
    },
    "input-b--verification.md": {
      "sha256": "74b9feb6219261f63292fb7a55161f9b16bbc7589fef9cafcbb8b167d59637f0",
      "byte_length": 17364
    }
  }
}
```
