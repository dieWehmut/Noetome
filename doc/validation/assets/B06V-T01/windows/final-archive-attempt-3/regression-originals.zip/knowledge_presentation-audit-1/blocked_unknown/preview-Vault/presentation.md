# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "957b7ef1-5de0-4b1e-a9cf-c3116e0e260b",
  "project_id": "15ce1634-2f3d-42f2-acb2-3de253e97bf4",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "c8c38488f0352029a35b89cf47c6b9ce414983deaaad0d177a9c6b41806e47ee",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "6e2005df8951493e46a6dbef4a90da314217b217132142ba1a459de9d5c4dfb1",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "0f89a7c187e5d9339ea3dac29009309cdb45cebf8253dfd4894f61ed11874894",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "212ee194278a728c24749690676d08f62b1f769b552570613a25846d74308ab3",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a393a6c5f8f6001910cb069cc65f018dbcf7168bd61ddba55bf7d339ef3911cf",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f6ea7f9db89c0ed469e0935f896e294169cdf327a84ff2d29213cb2bdfc3c4c4",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "31cd7cc0d880fa349fc18baa44665484090f90ae174f26fa261dbf8d61b849eb",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "4e39a02a23af6c155189bca9c04c92ee9aa7cf04eeb03d318fb4f49b1df4ac24",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2db74f691ec63fb5308d2eee522a016b84a48b17639bd0375602fe6fa7570394",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "56e55d0e8e0759a84f8fc6b3190c494a9c6934dbc047baa098363c5d61d5c926",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "41c633d75d6f84b92288ef916c9bc8bb529ad23f3d64e1551f62b2a4ad5fe0ed",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "6b4f2db238090f16f44782e0875fdb6bffe8ac0af64114bc08ad3ad8689bc370",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "e1da58181813b681cfa6a8a0491e884a025e519884a1e928f881488862774b1e",
      "byte_length": 14422
    },
    ".selection-original.json": {
      "sha256": "f17072460df9e18901f2cbf403f6e64bd8692c730bb9826007043cf8a5f23617",
      "byte_length": 4326
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "c8c38488f0352029a35b89cf47c6b9ce414983deaaad0d177a9c6b41806e47ee",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "6e2005df8951493e46a6dbef4a90da314217b217132142ba1a459de9d5c4dfb1",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "0f89a7c187e5d9339ea3dac29009309cdb45cebf8253dfd4894f61ed11874894",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "212ee194278a728c24749690676d08f62b1f769b552570613a25846d74308ab3",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a393a6c5f8f6001910cb069cc65f018dbcf7168bd61ddba55bf7d339ef3911cf",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f6ea7f9db89c0ed469e0935f896e294169cdf327a84ff2d29213cb2bdfc3c4c4",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "31cd7cc0d880fa349fc18baa44665484090f90ae174f26fa261dbf8d61b849eb",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "4e39a02a23af6c155189bca9c04c92ee9aa7cf04eeb03d318fb4f49b1df4ac24",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2db74f691ec63fb5308d2eee522a016b84a48b17639bd0375602fe6fa7570394",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "56e55d0e8e0759a84f8fc6b3190c494a9c6934dbc047baa098363c5d61d5c926",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "41c633d75d6f84b92288ef916c9bc8bb529ad23f3d64e1551f62b2a4ad5fe0ed",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "6b4f2db238090f16f44782e0875fdb6bffe8ac0af64114bc08ad3ad8689bc370",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "e1da58181813b681cfa6a8a0491e884a025e519884a1e928f881488862774b1e",
      "byte_length": 14422
    },
    ".owner.json": {
      "sha256": "e55c877f54b3ca5ac06828aecc5bd356fae2952c7f2b39eb322aa65e0646286b",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "f17072460df9e18901f2cbf403f6e64bd8692c730bb9826007043cf8a5f23617",
      "byte_length": 4326
    }
  }
}
```
