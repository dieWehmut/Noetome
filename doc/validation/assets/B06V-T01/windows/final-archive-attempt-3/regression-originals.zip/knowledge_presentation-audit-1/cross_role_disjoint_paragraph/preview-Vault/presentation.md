# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "b888c17c-fbfd-429e-8ed0-d8baf290ac79",
  "project_id": "0895ec81-b8ce-428d-8f11-881a66137312",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "4f2006245129e1e47cd45e4f37fc706ffd558ec29611e77a0fecdbe7d1ed0ec4",
    "byte_length": 41246
  },
  "plan_fingerprint": {
    "sha256": "439fd27a2367fe184eeabe911584e209af50a1536d465427e15c2dd70ea4510c",
    "byte_length": 14692
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "4f2006245129e1e47cd45e4f37fc706ffd558ec29611e77a0fecdbe7d1ed0ec4",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "e20109d3992b18039647657053b4ea3158ddfe1f2040b7c6a34196526162ce06",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "10d711a4b59ed024ba1a4c4895a5279d3e742ae0a94be14ee68bfa58f4be5969",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "7b53b2914f25ed39c5e41aa98c20596ec011e0e91dd618d018a5eef5c2f7241e",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "4ade1c1d8bf65fccd74602f4902e33b2b397f670ed1c4bb98c34a608a41ba713",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "aa313da028c11915b36b871069283b89b83bbb947767534f04ad90c5a331b817",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2c342102c7bb0fa47046b06797333594af13ad55028312ced3541fb161da19f0",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "11cdb149a71d5d66f05889926e9113b7ea50492e41afc5c4af1fac5c68ed8f8b",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "5bbdd30804fe20904331cfa3d4ee3d437c711b9f54dbbce4ddf9b2f72cb5ae89",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "f6b245e1557a4a4219096b68c86bca8bd5868fa49352ede1274a6b5111f13b32",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9dd5a6a5f38dc99e6a31b5afb45c9f155e8b339207d21f46caa2490b65c02550",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2b42fb8b5be2f0709b3b7b01061ca50350aa2db8ca2d6c9e8597b7323e91fd2f",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "ab76e0e4d54a498c0fdbea445e679b1ff19dcafb3fe653deae3fc861d4c9b473",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "7d51965e2ed64d160736fe05f0deab4087752c286373b0fdfb4a8030223275b3",
      "byte_length": 17255
    },
    ".selection-original.json": {
      "sha256": "37e87b66daefe14d9030b75cbb63b8db19c09feaa041e4f5f37f55bcb96cd29d",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-773712b9fb350d019fd8e059ae02ef5528f45a8b2314bf28b78c5edfff41557d"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 33,
          "end_byte": 197
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-d6f18523214e072e47200fd18cd5fb535ca9735571d52ba4666cd02184207cc3"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 273,
          "end_byte": 437
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000001",
          "target_path": "对象-61000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 198,
          "end_byte": 271
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000003",
          "target_path": "对象-61000000-0000-4000-8000-000000000003.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 438,
          "end_byte": 511
        }
      ]
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000001.md",
      "note_id": "object-61000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-773712b9fb350d019fd8e059ae02ef5528f45a8b2314bf28b78c5edfff41557d"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 27,
          "end_byte": 320
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000003.md",
      "note_id": "object-61000000-0000-4000-8000-000000000003",
      "plan_revision": 1,
      "content_sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-d6f18523214e072e47200fd18cd5fb535ca9735571d52ba4666cd02184207cc3"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 29,
          "end_byte": 322
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "4f2006245129e1e47cd45e4f37fc706ffd558ec29611e77a0fecdbe7d1ed0ec4",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "e20109d3992b18039647657053b4ea3158ddfe1f2040b7c6a34196526162ce06",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "10d711a4b59ed024ba1a4c4895a5279d3e742ae0a94be14ee68bfa58f4be5969",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "7b53b2914f25ed39c5e41aa98c20596ec011e0e91dd618d018a5eef5c2f7241e",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "4ade1c1d8bf65fccd74602f4902e33b2b397f670ed1c4bb98c34a608a41ba713",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "aa313da028c11915b36b871069283b89b83bbb947767534f04ad90c5a331b817",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2c342102c7bb0fa47046b06797333594af13ad55028312ced3541fb161da19f0",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "11cdb149a71d5d66f05889926e9113b7ea50492e41afc5c4af1fac5c68ed8f8b",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "5bbdd30804fe20904331cfa3d4ee3d437c711b9f54dbbce4ddf9b2f72cb5ae89",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "f6b245e1557a4a4219096b68c86bca8bd5868fa49352ede1274a6b5111f13b32",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9dd5a6a5f38dc99e6a31b5afb45c9f155e8b339207d21f46caa2490b65c02550",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2b42fb8b5be2f0709b3b7b01061ca50350aa2db8ca2d6c9e8597b7323e91fd2f",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "ab76e0e4d54a498c0fdbea445e679b1ff19dcafb3fe653deae3fc861d4c9b473",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "7d51965e2ed64d160736fe05f0deab4087752c286373b0fdfb4a8030223275b3",
      "byte_length": 17255
    },
    ".owner.json": {
      "sha256": "9d532b1fbec433b4fd57749ac3cfc31a562eefcde5076665da6f1f429369fa70",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "37e87b66daefe14d9030b75cbb63b8db19c09feaa041e4f5f37f55bcb96cd29d",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "439fd27a2367fe184eeabe911584e209af50a1536d465427e15c2dd70ea4510c",
      "byte_length": 14692
    },
    "对象-61000000-0000-4000-8000-000000000001.md": {
      "sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322
    },
    "对象-61000000-0000-4000-8000-000000000003.md": {
      "sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324
    },
    "知识比较.md": {
      "sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513
    }
  }
}
```
