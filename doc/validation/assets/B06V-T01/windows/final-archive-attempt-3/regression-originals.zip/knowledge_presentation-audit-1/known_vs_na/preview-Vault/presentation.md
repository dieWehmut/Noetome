# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "393c4fc2-f098-4ceb-ad6f-3e283ccb8b9f",
  "project_id": "7536c3b5-165f-4a95-b3c1-e9bd93e13250",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "5f5d2e3523a73ac149aa26e56c2f59a26409113d169cdb0c1312b1305fff77b7",
    "byte_length": 37417
  },
  "plan_fingerprint": {
    "sha256": "bc30eefb43aaa536b723495921beb03875ad32b483dab329a4bd77f8fcc7e258",
    "byte_length": 16487
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "5f5d2e3523a73ac149aa26e56c2f59a26409113d169cdb0c1312b1305fff77b7",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "8d9d4d3c7545a900e3bf3f63d4b8f377d7f4d5064bf56fbaa96b40a289de1613",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9f92280b7eeba51b288cf82012a213ab68a39c99bfb59cc021e2960da1ce7e33",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "80a0708c9a4237914419aeb1149bc94d973221439b0411e76e933335fd425e01",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "2fb37064cfff32fe88d30203b85ce42236d4faf978fd16f2b4900c9847849a68",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "3d84e59f4851107c3869135c7af50a1b1f6447086326f96df200f7b47ea93469",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "e82c3493eb56ed1847cf10f2e3260af6835343208d81076a14ac02c4195f1eb9",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "d3e052919fdf3d3a52cb2aa5c72b2698f610b7178a8cd23b1ea9a895420c9d22",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "132b835063ecef3989a984a412af21743321722ba5088973d4eca360bff7bca8",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "10897d732d2df5b809858e4fa6ef395f762664c312d94db6e461503d8f38f50a",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9a7d3090457f5d24a052cece9757a67d038bfc9d84dfe66ec1d1f57b865edbfb",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "99907b4c7d3f1998b7ebb4a12a0e311396f4139f8e6b7e1328aa922e7b185575",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "3ff6733d349cd25e133c7dcc456ac8c163d27322e0f9f529360948f9ebb1aea6",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "b5c7ddbc93cc85321bde576fef351ecc0ca2eba3a0437686cba8811ae39dc95a",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "1641c25fb9a242b0833d9f753f92bb40eeb6f5f6c2195ed41a7486215f422c5a",
      "byte_length": 4328
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-ebd202f807fd3dd86e6864f80db559b666538cf866addbd089dd191fa1df4edd",
            "occ-f062bff748107ad43c486d45a75048aeb85ccf72739b5866e26961b1ccbb05ec"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-f062bff748107ad43c486d45a75048aeb85ccf72739b5866e26961b1ccbb05ec"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-f062bff748107ad43c486d45a75048aeb85ccf72739b5866e26961b1ccbb05ec"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 262
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-ebd202f807fd3dd86e6864f80db559b666538cf866addbd089dd191fa1df4edd"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 267,
          "end_byte": 275
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-ebd202f807fd3dd86e6864f80db559b666538cf866addbd089dd191fa1df4edd"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 353,
          "end_byte": 499
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 276,
          "end_byte": 350
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-f062bff748107ad43c486d45a75048aeb85ccf72739b5866e26961b1ccbb05ec"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 207
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-ebd202f807fd3dd86e6864f80db559b666538cf866addbd089dd191fa1df4edd"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "5f5d2e3523a73ac149aa26e56c2f59a26409113d169cdb0c1312b1305fff77b7",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "8d9d4d3c7545a900e3bf3f63d4b8f377d7f4d5064bf56fbaa96b40a289de1613",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9f92280b7eeba51b288cf82012a213ab68a39c99bfb59cc021e2960da1ce7e33",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "80a0708c9a4237914419aeb1149bc94d973221439b0411e76e933335fd425e01",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "2fb37064cfff32fe88d30203b85ce42236d4faf978fd16f2b4900c9847849a68",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "3d84e59f4851107c3869135c7af50a1b1f6447086326f96df200f7b47ea93469",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "e82c3493eb56ed1847cf10f2e3260af6835343208d81076a14ac02c4195f1eb9",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "d3e052919fdf3d3a52cb2aa5c72b2698f610b7178a8cd23b1ea9a895420c9d22",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "132b835063ecef3989a984a412af21743321722ba5088973d4eca360bff7bca8",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "10897d732d2df5b809858e4fa6ef395f762664c312d94db6e461503d8f38f50a",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9a7d3090457f5d24a052cece9757a67d038bfc9d84dfe66ec1d1f57b865edbfb",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "99907b4c7d3f1998b7ebb4a12a0e311396f4139f8e6b7e1328aa922e7b185575",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "3ff6733d349cd25e133c7dcc456ac8c163d27322e0f9f529360948f9ebb1aea6",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "b5c7ddbc93cc85321bde576fef351ecc0ca2eba3a0437686cba8811ae39dc95a",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "c923ff58e2a45de30bd3040ff2a3cbf09fc390e8bddb6706a3ac9395b1f197ba",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "1641c25fb9a242b0833d9f753f92bb40eeb6f5f6c2195ed41a7486215f422c5a",
      "byte_length": 4328
    },
    "plan.json": {
      "sha256": "bc30eefb43aaa536b723495921beb03875ad32b483dab329a4bd77f8fcc7e258",
      "byte_length": 16487
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503
    }
  }
}
```
