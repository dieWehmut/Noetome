# Public self-owned SVG capability probe

This authored probe does not prove final CLI image output.

![[probe.svg]]

![[probe-original.png]]

[[probe-original.png|Open selected local source PNG]]
