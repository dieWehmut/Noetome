"""Close the executed B04 plan and define exactly three unstarted B05 cards."""
import copy
import json
from pathlib import Path

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]
ledger_path = REPO / "dev-log/tasks.json"
ledger = json.loads(ledger_path.read_bytes())
before = copy.deepcopy(ledger)
assert ledger["current_batch"] == "B04R"
assert all(t["status"] == "done" for t in ledger["tasks"] if t["batch"] == "B04R")
assert not any(t["status"] == "in_progress" for t in ledger["tasks"])
remote = json.loads((ASSETS := REPO / "doc/validation/assets" / "B04-T03-final-closure-remote.json").read_bytes())
assert remote["passed"] and remote["local_head"] == remote["remote_head"] == "b3d40a02b0eb3a8905c190b2b78442a4c9121c29"
new_tasks = [
    {
        "id": "B05-T01", "title": "多来源重复归并与互补事实保留", "batch": "B05", "status": "todo",
        "depends_on": ["B04-T03"],
        "requirements": ["FR-08", "FR-09", "FR-10", "FR-26", "FR-40", "NFR-03", "NFR-07"],
        "acceptance": [
            "先冻结严格有版本协调契约、明确身份映射与独立作者gold；在同一明确测试项目中消费2至3份实际extract verify成功的单原子IR及完整核对依据，重新核对实际来源版本、SQL、资源、UTF8引文和原输入，不能只信source_match标志。",
            "三份来源的两个相同事实归并为一个事实并保留两份独立来源位置，第三份互补事实保持独立；规范概念ID来自明确映射且不随显示名称或输入顺序改变，原ID与来源引用均可追踪。",
            "先取得真实普通CLI行为RED；错绑定/同SHA跨来源误映射、遗漏第二份证据、错误归并、重复输入冒充独立来源、未处理条件差异及非法数量都必须被独立gold/字节/SQL校验拒绝或准确标为需复核。",
            "只写新的协调测试根，保留原IR、gold、来源项目和外部哨兵；JSON/Markdown同事实，实际输入/事实/证据分母分别可对账，未知保持未知，科学未运行且未发布，不写生产Vault或调用模型。",
            "普通协调CLI与独立Python校验实际通过，运行相关Rust/Python回归、日志及Git检查，新鲜审查修复后complete并分步提交推送；本项仅实现明确身份的有界重复/互补，不宣称完整概念归并撤销或三本真实教材融合。",
        ], "history": [],
    },
    {
        "id": "B05-T02", "title": "条件差异与历史观点的并列变体", "batch": "B05", "status": "todo",
        "depends_on": ["B05-T01"],
        "requirements": ["FR-09", "FR-10", "FR-26", "FR-40", "NFR-03"],
        "acceptance": [
            "在T01已验收的明确身份与实际来源链上，用调用前作者化的温度/样例适用范围/例外与明确时间样例先形成真实RED；不同条件、不同时间和未给出条件分别有独立expected。",
            "相同对象和属性在不同完整适用条件下保留并列数值和各自证据；时间演变仅在时间依据实际可追溯时分类为历史演变，不能从导入mtime、文件名或模型响应时间推定新旧观点。",
            "未知与不适用条件不当作相等空集合；不同单位保持原值和单位，未实现或无法证明的换算保持需复核，不用默认值/零或省略例外换取归并通过。",
            "JSON/Markdown/成功时的未发布协调IR一致表达变体、条件、时间和真实数量，输入顺序/名称变化不改身份或丢证据；有交换字段变化先显式版本处理，不向旧B04 IR塞未知字段。",
            "普通CLI及独立核对实际验证删除/改写条件、丢历史证据、伪造时间与单位误归并，并完成相关回归、新鲜审查、devlog/Git检查和正常推送；真实科学裁决、任意条件语义和自动单位换算不计作本项完成。",
        ], "history": [],
    },
    {
        "id": "B05-T03", "title": "真实冲突与证据不足的可追踪报告", "batch": "B05", "status": "todo",
        "depends_on": ["B05-T02"],
        "requirements": ["FR-10", "FR-26", "FR-40", "NFR-03", "NFR-07"],
        "acceptance": [
            "用明确同对象/属性/单位/完整条件而数值不相容的作者工程来源、反证和证据不足样例先取得真实RED；解析或引用错误先作为输入失败，不与合法观点并列。",
            "区分重复、互补、条件差异、历史演变、真实冲突和证据不足；冲突保留各方值、适用范围、来源版本/位置和处理记录，无证据不得显示已核实。",
            "默认保留各方并标需复核；第三份重复支持、来源更新或显式排序不得自动变成事实胜出理由，反证和历史依据不得被隐藏；不新增自动联网研究或科学权威裁决。",
            "争议与证据不足逐对象定位，真实通过/失败/需复核/未处理及未知数量可对账；双报告一致保留无冲突项与争议项，未解决必要冲突不产生成功协调IR或发布成功。",
            "普通CLI、独立篡改/遗漏/错误裁决测试、来源与新根保护、相关完整回归和新鲜审查实际通过后complete、提交推送；B05全部验收再根据实际结果规划下一批最多三项，不以工程样例宣称科学准确率或完整多教材知识覆盖。",
        ], "history": [],
    },
]
assert not {t["id"] for t in new_tasks}.intersection(t["id"] for t in ledger["tasks"])
ledger["tasks"].extend(new_tasks)
assert ledger["tasks"][:-3] == before["tasks"]
assert {k: v for k, v in ledger.items() if k != "tasks"} == {k: v for k, v in before.items() if k != "tasks"}

next_path = REPO / "doc/execution/NEXT_STEPS.md"
old = next_path.read_text(encoding="utf-8")
old = old.replace("# 近期开发步骤", "# B04/B04R 执行步骤（已归档）", 1)
old = old.replace("当前待实际日志complete和普通提交推送收束，下一批只规划。", "B04-T03已由devlog complete并check；收束提交b3d40a0已正常推送，ls-remote与本地完整SHA相等，下一批只规划。")
old = old.replace("- [ ] 执行真实普通CLI和独立核对脚本，保留来源/证据及输出保护验证，运行完整回归、日志检查和新鲜审查；complete并提交推送。B04全部验收后仅滚动展开下一批最多三项。", "- [x] 执行真实普通CLI和独立核对脚本，保留来源/证据及输出保护验证，运行完整回归、日志检查和新鲜审查；complete并提交推送。B04全部验收后仅滚动展开下一批最多三项。")
old = old.replace("\n\n真实状态", "\n\n本文件保留B04及B04R执行范围。B04-T03日志与远端收束已实际完成；[远端收据](../validation/assets/B04-T03-final-closure-remote.json)核对提交`b3d40a02b0eb3a8905c190b2b78442a4c9121c29`。当前批次入口见[近期步骤](NEXT_STEPS.md)，本归档中的先前进行中表述保留其当时背景。\n\n真实状态", 1)
with (REPO / "doc/execution/B04R_STEPS.md").open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(old)

plan_path = REPO / "doc/execution/B04-T03_REVIEW_PLAN.md"
plan = plan_path.read_text(encoding="utf-8")
assert "- [ ] **Step 5: 根最终完成。**" in plan
plan = plan.replace("- [ ] **Step 5: 根最终完成。**", "- [x] **Step 5: 根最终完成。**")
plan = plan.replace("- 当前唯一活动任务B04-T03；", "- 本计划执行期间唯一活动任务B04-T03；", 1)
plan = plan.replace("- [ ] 最终完整Rust/Python检查及most-capable整分支审查包含这一用户纠正；", "- [x] 最终完整Rust/Python检查及most-capable整分支审查包含这一用户纠正；")
plan += "\n最终收束：devlog complete及check实际通过，提交`b3d40a02b0eb3a8905c190b2b78442a4c9121c29`已正常推送并以ls-remote核对相同，[远端收据](../validation/assets/B04-T03-final-closure-remote.json)保留实际命令。B04R全部完成后仅新增下一批三张todo卡并切批次，不start产品实现；见[近期步骤](NEXT_STEPS.md)。\n"
plan_path.write_text(plan, encoding="utf-8", newline="\n")

next_text = """# 近期开发步骤

真实状态以[任务账本](../../dev-log/tasks.json)和[当前状态](../../dev-log/STATUS.md)为准。B04/B04R执行范围归档于[B04R步骤](B04R_STEPS.md)，来源核对和单行窗口实机结果分别见[B04-T03](../validation/B04-T03.md)及[窗口记录](../validation/B04-T03-ui-single-row.md)。

B04-T03已完成日志、审查修复、实际安装和普通推送；收束提交`b3d40a02b0eb3a8905c190b2b78442a4c9121c29`与远端相等。最后完整Rust532、Python108、前端10及原生16项和用户托盘/拖动确认有真实证据。所选模型配置/DPAPI继续保存并复用：累计30097、余额9969903、pending0，T03新增模型请求0。

下一批 **B05** 只含下面三张顺序执行卡，均为todo。本次只规划及切批次，不start；这些文件、命令与预期行为是后续实施目标，未作为已通过能力记录。

**目标**：在已验收的受控单来源核对上，先合并重复并保留互补，再区分条件和历史，最后呈现真正冲突与证据不足。

**架构**：Rust复用实际来源读取与输入/输出守卫，消费2至3份各含一个原子的成功source_review输出及核对依据。独立Python从作者gold、实际SQL/资源及原始输入验证协调结果；使用新的协调交换契约和输出根，保持B04原IR与项目Schema不变。

**技术**：现有Rust workspace/SQLite/严格JSON、Python标准库及现有CLI测试，不引入模型、向量库或完整图谱框架。

**依据**：[PRD FR-08/09/10/26/40](../requirements/PRD.md)、[已采纳决策](../requirements/DECISIONS.md)、[数据契约](../technical/DATA_CONTRACTS.md)、[来源核对契约](../technical/EXTRACTION_REVIEW_CONTRACT.md)及[测试标准](../standards/TESTING.md)。这是这些需求的有界工程实现，完整概念身份撤销、真实三教材融合、科学质量与长期维护仍需后续任务验收。

> 执行者：每项start后使用superpowers:subagent-driven-development或superpowers:executing-plans，先写当前单一账本任务的具体实施计划和接口，再落实真实RED、实现、独立审查和收束。子代理只分担当前任务，不各自启动后两张卡；每项complete、检查、提交推送后才顺序start下一项。

## 全局约束

- 同时最多一个in_progress；本批最多三张详细卡。既有失败和完整历史保留，状态通过devlog工具维护。
- B05先限定一个明确测试项目中的2至3份有界source_review依据，每份一个原子；新case清单上限64KiB，单份IR/候选/所选来源继续有界，不扩展任意长资料或全学科语言。
- 明确身份映射是本批前提；不凭名称、缩写、相似度或模型置信自动认定相同概念。显示名称与输入顺序不能换ID，原ID和每个独立来源位置必须保留。
- 只读明确选取的测试来源、原gold、IR和核对产物，输出只到新测试根。生产Vault、未知文件、人工内容和外部哨兵保持，普通CLI不提供强制覆盖或测试故障开关。
- 不读取凭据/模型配置，不发新模型或研究请求；保存服务和累计预算以后继续复用，不重复索要。fake/作者工程样例如实标记。
- 分别统计输入出现次数、规范事实、条件变体、来源位置和未解决项；没有可确认数组/字段时保持未知，不把成功解析、重复引用或零例外当成正确率。
- scientific_quality=not_run、research_status=not_requested、published=false；来源一致及协调通过不能宣称科学正确、98%正式准确率、200原子基准或完整覆盖。
- 未实现的单位换算、未知适用条件或没有时间证据均保持需复核。新旧来源、票数或排序不能自动裁定权威；没有解析/来源证据的条目先失败。
- 共享交换字段变化先明确版本及旧读取器影响，不向B04严格IR混入未知字段；不预建未来阶段空表。

## B05-T01 多来源重复归并与互补事实保留

**单一结果**：三份实际来源核对输出中的两个相同事实合为一个，第三份互补事实独立保留；规范身份和三处来源证据可独立对账。

**依赖**：B04-T03。关联FR-08/09/10/26/40、NFR-03/07的本项范围。

**文件责任**：新增`doc/technical/KNOWLEDGE_COORDINATION_CONTRACT.md`和本项实施计划；Rust协调/严格模型分别放`crates/noetome-cli/src/knowledge_coordinate.rs`及`knowledge_coordination_model.rs`，仅在CLI分发及必要输出owner增加接线。普通入口测试放`crates/noetome-cli/tests/knowledge_coordinate.rs`；独立作者三来源、身份映射和gold放`fixtures/knowledge-coordination-v1`。独立校验放`scripts/verify_knowledge_coordination.py`和`tests/test_knowledge_coordination_verifier.py`，真实验证放`doc/validation/B05-T01.md`及其资产。

**接口目标**：普通`knowledge coordinate <project> <coordination-case> <new-output>`读取严格版本清单、明确身份映射及2至3份已保存source_review依据；重新打开实际SourceSession并核对来源/四输入/IR/双报告关系。成功生成未发布`coordination-ir.json`与`coordination.json`/`coordination.md`；不能只读取报告passed标志。第一步先在新契约中冻结这些字段、状态、限额和失败输出，再写生产接线。

**顺序与验收**：

- [ ] 作者先固定三份公开工程短文、明确canonical ID和gold，再生成synthetic候选并用实际`extract verify`取得三份依据。两个同对象/属性/值/单位/完整条件/例外的事实应归并，第三个不同属性的互补事实应保留：规范事实2、独立来源出现3。
- [ ] 写普通CLI测试并在接线前取得真实行为RED；正确样例预期exit0和完整证据集合，错误样例必须有具体失败或需复核。编译/设置失败单独记录。
- [ ] 实现有界守卫与显式身份协调；规范ID不依赖显示名称/输入顺序，原ID可追。跨来源同SHA保留各自身份，同一输入重复引用不能冒充独立来源。未处理的条件/单位/时间差异保持需复核。
- [ ] 独立Python从固定gold和实际源SQL/资源核对两事实/三来源及JSON/Markdown/IR；篡改错来源/引文、丢第二证据、错误归并、数量填零、重复输入和既有/内嵌/链接输出必须被检测。输入和源前后不变。
- [ ] 运行针对性普通入口、独立脚本及必要完整回归，新鲜审查修复后用devlog complete附代码/真实产物，分步提交推送并核对远端。此时不把明确身份原型算成通用实体识别/归并撤销或真实教材质量验收。

预定行为验证：`./scripts/cargo_local.ps1 test -p noetome-cli --locked --offline --test knowledge_coordinate '--' --test-threads=4`；`python scripts/verify_knowledge_coordination.py --binary <absolute-noetome> --output <nonexistent-root>`；独立校验器用真实一致伪造报告先RED再GREEN。

## B05-T02 条件差异与历史观点的并列变体

**单一结果**：同一对象/属性在不同适用条件或有来源依据的时间背景下保持并列结论，不被错误去重或二选一。

**依赖**：B05-T01。关联FR-09/10/26/40、NFR-03的本项范围。

**文件责任**：扩展T01协调契约、逻辑、模型、普通CLI测试和独立校验，追加调用前作者化条件/时间样例；不改B04原IR或旧gold。验证记录放`doc/validation/B05-T02.md`及新资产。

**接口目标**：保留T01普通CLI与依据链；协调报告逐条表示条件变体/历史演变、原值/单位、时间证据与需复核项。若需新字段，先版本化严格协调交换，不让旧读取器静默接受未知字段。

**顺序与验收**：

- [ ] 先固定同对象同属性的T20C/T30C、样例适用范围与例外差异、明确时间和未给时间的独立expected，再写真实CLI和一致伪造报告RED。
- [ ] 条件差异保留原值与完整条件/例外；unknown/not_applicable分开，不能把未知条件当相等空集合，也不凭接近数值归并不同单位。
- [ ] 历史演变仅依据实际可追溯时间；导入mtime、文件名或响应时间不能充当观点新旧证据。没有时间依据或换算依据的关系保持需复核。
- [ ] 普通CLI/独立校验分别检测删除条件、丢历史证据、伪造时间、单位误归并；输入顺序与显示名称变化后ID/来源不丢。双报告和成功时IR同事实、真实数量与状态可对账。
- [ ] 相关回归、守卫、新鲜审查、日志及Git检查通过后complete、提交推送。任意条件理解、自动单位换算和科学裁决继续按后续实测处理。

预定行为验证沿用`tests/knowledge_coordinate.rs`普通入口与独立`scripts/verify_knowledge_coordination.py`，新gold在任何候选/CLI前写入；不再运行模型抽取。

## B05-T03 真实冲突与证据不足的可追踪报告

**单一结果**：真正不相容的有据结论和证据不足分别定位，保留各方原值、条件、历史与反证，无法裁定时准确显示需复核。

**依赖**：B05-T02。关联FR-10/26/40、NFR-03/07的本项范围。

**文件责任**：扩展同一协调契约/实现/普通入口/独立校验；作者工程冲突及证据不足样例只追加新case。真实记录放`doc/validation/B05-T03.md`及新资产，不引入联网研究、科学权威评分或生产发布。

**接口目标**：同一CLI报告重复/互补/条件差异/历史演变/真实冲突/证据不足及逐对象处理记录，未解决必要冲突exit3、无成功协调IR/发布；无冲突项和争议项都在双报告中保留。

**顺序与验收**：

- [ ] 作者先固定同对象/属性/单位/完整条件的10与12、第三份重复支持和缺证据样例，取得真实CLI与错误裁定报告RED。解析/引用错误先作为输入失败，不能包装成两种有效观点。
- [ ] 分类按实际对象、条件、时间和原值判定；冲突保留各方来源版本/位置。默认保留并需复核，来源排序、新旧或票数不构成自动胜出理由。
- [ ] 删除反证/历史依据、把未知填零、伪造已核实或无必要冲突却判失败均应被独立gold/来源核对检测；已通过无冲突项不丢失。
- [ ] JSON/Markdown相同表示真实分母和四状态、问题位置、依据及未解决原因；冲突或证据不足不产出成功协调IR。来源/原IR/作者gold和新根外哨兵保持。
- [ ] 普通CLI、独立篡改矩阵、必要完整回归和新鲜审查实际通过后complete、提交推送。B05三项全验收后再依据结果细化下一批最多三项。

预定行为验证继续同一普通入口/独立校验，加入正确冲突、条件差异非冲突、历史非冲突和不足证据等明确expected；工程冲突样例不证明自然科学裁决准确。

## 统一检查与交接

```text
./scripts/cargo_local.ps1 fmt --all --check
./scripts/cargo_local.ps1 check --workspace --locked --offline
./scripts/cargo_local.ps1 test --workspace --locked --offline '--' --test-threads=4
python -m unittest discover -s tests -p 'test_*.py'
python scripts/devlog.py check
git diff --check
```

Python使用本轮工具实际选定解释器；路径不硬编码进仓库程序。完整回归在相应产品改动后执行，不用重复B04实机安装证明新协调功能。每卡独立完成并推送后再start下一卡；当前仅规划，B05-T01是下次执行入口。
"""
next_path.write_text(next_text, encoding="utf-8", newline="\n")
ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"new_task_ids": [t["id"] for t in new_tasks], "all_todo_empty_history": all(t["status"] == "todo" and not t["history"] for t in new_tasks), "prior_15_tasks_and_history_unchanged": before["tasks"] == ledger["tasks"][:-3], "current_batch_not_manually_changed": ledger["current_batch"], "archive": "doc/execution/B04R_STEPS.md", "no_task_started": True}))
