from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import re

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]
parser = argparse.ArgumentParser()
parser.add_argument("--label", required=True)
parser.add_argument("--document", action="append", default=[])
args = parser.parse_args()
paths = [
    "README.md", "doc/README.md", "doc/standards/DESIGN.md", "doc/standards/TESTING.md",
    "doc/technical/DATA_CONTRACTS.md", "doc/technical/EXTRACTION_REVIEW_CONTRACT.md",
    "doc/execution/NEXT_STEPS.md", "doc/execution/B04-T03_REVIEW_PLAN.md",
    "doc/validation/B04-T03.md", "doc/validation/B04-T03-ui-single-row.md",
    *args.document,
]
paths = list(dict.fromkeys(paths))
checks = []
documents = {}
for name in paths:
    document = REPO / name
    data = document.read_bytes()
    documents[name] = {"sha256": hashlib.sha256(data).hexdigest(), "byte_length": len(data)}
    for target in re.findall(r'!?\[[^\]]*\]\(([^\n)]+)\)', data.decode("utf-8")):
        target = target.strip().split(' "', 1)[0].strip("<>")
        if re.match(r"^[a-z][a-z0-9+.-]*:", target, re.I) or target.startswith("#"):
            continue
        selected = (document.parent / target.split("#", 1)[0]).resolve()
        assert selected.exists(), (name, target)
        checks.append({"document": name, "target": target, "exists": True})
tested = json.loads((SDK / "root-final-fix-python-tests-command.json").read_bytes())["code_after"]
for name, receipt in tested.items():
    data = (REPO / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == receipt["sha256"] and len(data) == receipt["byte_length"], name
result = {
    "captured_at": datetime.now(timezone.utc).isoformat(), "documents": documents,
    "local_link_checks": checks, "local_links_passed": len(checks),
    "tested_product_source_files_unchanged": len(tested), "passed": True,
}
with (SDK / f"{args.label}-docs-check.json").open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"documents": len(paths), "local_links_passed": len(checks), "tested_source_files_unchanged": len(tested), "passed": True}))
