from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]
base = "b3d40a02b0eb3a8905c190b2b78442a4c9121c29"
old_bytes = subprocess.check_output(["git", "show", base + ":dev-log/tasks.json"], cwd=REPO)
old = json.loads(old_bytes)
data = (REPO / "dev-log/tasks.json").read_bytes()
ledger = json.loads(data)
cards = [task for task in ledger["tasks"] if task["batch"] == "B05"]
assert ledger["current_batch"] == "B05" and len(cards) == 3
assert [task["id"] for task in cards] == ["B05-T01", "B05-T02", "B05-T03"]
assert all(task["status"] == "todo" and task["history"] == [] for task in cards)
assert len(ledger["tasks"]) == len(old["tasks"]) + 3 == 18
assert ledger["tasks"][:-3] == old["tasks"]
assert ledger["history"][:-1] == old["history"]
event = ledger["history"][-1]
assert event["action"] == "batch" and event["from_batch"] == "B04R" and event["to_batch"] == "B05"
assert not any(task["status"] == "in_progress" for task in ledger["tasks"])
assert sum(task["status"] == "done" for task in ledger["tasks"]) == 15
text = (REPO / "doc/execution/NEXT_STEPS.md").read_text(encoding="utf-8")
assert re.findall(r"^## (B05-T\d+)", text, flags=re.M) == [task["id"] for task in cards]
prd = (REPO / "doc/requirements/PRD.md").read_text(encoding="utf-8")
for task in cards:
    assert f'## {task["id"]} {task["title"]}' in text
    assert len(task["acceptance"]) == 5 and task["depends_on"]
    assert all(req in prd for req in task["requirements"])
assert cards[0]["depends_on"] == ["B04-T03"]
assert cards[1]["depends_on"] == ["B05-T01"]
assert cards[2]["depends_on"] == ["B05-T02"]
assert "三项均todo" in (REPO / "doc/execution/ROADMAP.md").read_text(encoding="utf-8")
assert "- [ ] **Step 5: 根最终完成。**" not in (REPO / "doc/execution/B04-T03_REVIEW_PLAN.md").read_text(encoding="utf-8")
assert (REPO / "doc/execution/B04R_STEPS.md").exists()
assert not re.search(r"\bTBD\b|implement later|fill in details|添加适当错误处理", text, flags=re.I)
for phrase in ("明确身份映射", "未知", "时间证据", "science", "published=false"):
    if phrase == "science":
        assert "scientific_quality=not_run" in text
    else:
        assert phrase in text
tested = json.loads((SDK / "root-final-fix-python-tests-command.json").read_bytes())["code_after"]
for name, receipt in tested.items():
    current = (REPO / name).read_bytes()
    assert hashlib.sha256(current).hexdigest() == receipt["sha256"] and len(current) == receipt["byte_length"]
result = {
    "schema_version": 1, "captured_at": datetime.now(timezone.utc).isoformat(),
    "scope": "B04 closure rolling plan only, not B05 product validation",
    "current_batch": ledger["current_batch"], "task_ids": [task["id"] for task in cards],
    "all_new_tasks_todo_empty_history": True, "in_progress": 0, "done": 15,
    "all_prior_tasks_and_history_unchanged": True, "single_tool_batch_event_appended": True,
    "dependency_chain": {task["id"]: task["depends_on"] for task in cards},
    "ledger_before_sha256": hashlib.sha256(old_bytes).hexdigest(), "ledger_after_sha256": hashlib.sha256(data).hexdigest(),
    "spec_self_review": {
        "FR-08": "T01 uses explicit opaque identity mapping and preserves original IDs/evidence; automatic entity recognition/reversal remains outside this bounded batch",
        "FR-09": "T02 retains condition/exception/unit/time variants and distinguishes unknown from not_applicable",
        "FR-10": "T01/T02/T03 cover the six relation classes in order; default retains opposing evidence without authority voting",
        "FR-26_FR-40": "Selected actual source/SQL/UTF8 identity and same-fact dual reports with per-object issues required",
        "scope": "2 to 3 one-atom source_review inputs, no model/network/production Vault/scientific claim",
        "interfaces": "All cards retain one planned knowledge coordinate command; strict coordination contract is frozen in T01 before production wiring",
        "placeholders": "No TBD or undefined method references; only clearly unstarted task checkboxes and planned files/commands",
    },
    "tested_product_source_files_unchanged": len(tested),
    "new_product_task_started": False, "new_model_calls": 0,
    "passed": True,
}
output = REPO / "doc/validation/assets/B04-T03-final-b05-planning-check.json"
with output.open("x", encoding="utf-8", newline="\n") as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write("\n")
print(json.dumps({"current_batch": ledger["current_batch"], "new_tasks": len(cards), "old_done_tasks": 15, "prior_history_unchanged": True, "in_progress": 0, "tested_product_source_files_unchanged": len(tested), "passed": True}))
