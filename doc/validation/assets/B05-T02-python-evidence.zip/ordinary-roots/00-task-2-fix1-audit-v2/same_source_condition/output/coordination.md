# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "91adee11-062b-4c63-9c99-1a06a62b8ab1",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
        "import_id": "2e92e24a-543a-4c8b-92d4-25129157e989",
        "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
        "version_id": "e43d480b-7993-422f-9d8b-238b99249f15",
        "content_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
        "normalized_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
              "import_id": "2e92e24a-543a-4c8b-92d4-25129157e989",
              "manifest_sha256": null,
              "normalized_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
              "parse_id": null,
              "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
              "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
              "version_id": "e43d480b-7993-422f-9d8b-238b99249f15"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
              "import_id": "2e92e24a-543a-4c8b-92d4-25129157e989",
              "manifest_sha256": null,
              "normalized_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
              "parse_id": null,
              "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
              "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
              "version_id": "e43d480b-7993-422f-9d8b-238b99249f15"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 46,
          "end_byte": 213,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 293,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 213,
            "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
            "excerpt_start_byte": 46,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 213,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 101
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 213,
              "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
              "excerpt_start_byte": 46,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "e51e0ab069fe1ba96a397d24cc9248051004fe3af8d771577b185725d9b95d0b",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "92d21d0af635eaf1f190da2689bed4ad50c1e618e06ce732d9f134529ea09589",
          "byte_length": 12393
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "1ea2d41e63a7a0d435aa715b4b17d9a0e3c1e94c201b10a9ca88ca7ecb916a5d",
          "byte_length": 1185
        },
        "verification.json": {
          "sha256": "eeeb062e362c3dcb9cbb6c568b02d191a9b616cd3dfaaf0b60e72490b972cb9d",
          "byte_length": 16994
        },
        "verification.md": {
          "sha256": "a7357128da4b8d1926aa3cf91c1abe0b2d8243f895701683ad53547b38714c7e",
          "byte_length": 17428
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
        "import_id": "d2d5cf48-2096-4a9a-87c2-f91956480cc9",
        "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
        "version_id": "777026ac-09ca-47f4-9f6b-b0ebfb0cd18f",
        "content_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
        "normalized_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
              "import_id": "d2d5cf48-2096-4a9a-87c2-f91956480cc9",
              "manifest_sha256": null,
              "normalized_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
              "parse_id": null,
              "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
              "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
              "version_id": "777026ac-09ca-47f4-9f6b-b0ebfb0cd18f"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
              "import_id": "d2d5cf48-2096-4a9a-87c2-f91956480cc9",
              "manifest_sha256": null,
              "normalized_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
              "parse_id": null,
              "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
              "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
              "version_id": "777026ac-09ca-47f4-9f6b-b0ebfb0cd18f"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 46,
          "end_byte": 213,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 293,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 213,
            "excerpt_sha256": "cbecd5de19d013b2f86072ed6fc2f4dff377bf6c6293c62d73f8a3205f40f288",
            "excerpt_start_byte": 46,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 213,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 101
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 213,
              "excerpt_sha256": "cbecd5de19d013b2f86072ed6fc2f4dff377bf6c6293c62d73f8a3205f40f288",
              "excerpt_start_byte": 46,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 293,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "7cac3b4c38a7a03916ba8984fb025e826d04932ff4c0a92c0ff6ac749add82ae",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "32216502b92b7a51e2d12956c8381bebb1ed462c3789ef37e2f8a2e88d5494e6",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "309af89f60f00c4f757ebb59318ad2724a7fffcb13d45ce3d29cc17809244fb5",
          "byte_length": 12393
        },
        "review-original.json": {
          "sha256": "e44c5f5e2f0d340a45bbf3262c34067ae72182ae81440c389362246ce5ecccb4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "bf48b23d361805b7e0914b6f39392809812d061d5c017f19fbe31a9fb5f8754f",
          "byte_length": 1185
        },
        "verification.json": {
          "sha256": "68c75103129393cee45fb7981a817aa3269e41c0bdce355fffd707de21f0b19d",
          "byte_length": 16994
        },
        "verification.md": {
          "sha256": "50168725c10b78aaf3433acc6b4d15e0c944e951c7b66ee99cdf412304cd4533",
          "byte_length": 17428
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 46,
        "end_byte": 213,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "cbecd5de19d013b2f86072ed6fc2f4dff377bf6c6293c62d73f8a3205f40f288"
      },
      "occurrence_id": "occ-62afde5d1cbd1800e170666ca800fd87eb4415bbc09fd987ceff2adce3c334fd",
      "input_id": "b",
      "binding": {
        "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
        "import_id": "d2d5cf48-2096-4a9a-87c2-f91956480cc9",
        "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
        "version_id": "777026ac-09ca-47f4-9f6b-b0ebfb0cd18f",
        "content_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
        "normalized_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "bb81fb68-e362-4849-9868-5d9fb08ffb70",
          "ordinal": 0,
          "resource_sha256": "d87ba5d32ea0de5b4fe308e7aba34d4ade61c33f3fcf29a1066d006bcff1feeb"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 293,
        "text": "公开自造资料 same_source_condition/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 46,
          "excerpt_end_byte": 213,
          "excerpt_sha256": "cbecd5de19d013b2f86072ed6fc2f4dff377bf6c6293c62d73f8a3205f40f288",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 46,
        "end_byte": 213,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-8659ca31cd482bd4f5888fa04dbc84e0e1b9dc05b95f0ca177b833c1ad45b163",
      "input_id": "a",
      "binding": {
        "project_id": "4abc3cc5-c9e9-494e-87ce-a3affbb166e2",
        "import_id": "2e92e24a-543a-4c8b-92d4-25129157e989",
        "source_id": "f5ed6251-ba34-4786-a978-37cddd67bab1",
        "version_id": "e43d480b-7993-422f-9d8b-238b99249f15",
        "content_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
        "normalized_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "0e9a882f-02bf-480f-b670-97382fc39c6b",
          "ordinal": 0,
          "resource_sha256": "ee7c0380df7f5f2558e1c9e28dc9f4cbcdb3387cfb7298cc0807be73e590f1a1"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 293,
        "text": "公开自造资料 same_source_condition/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 46,
          "excerpt_end_byte": 213,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-37b85ca43695cab4ad15df81b37b0522781319aa80d8bfb70a34f7d38f961b87",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-62afde5d1cbd1800e170666ca800fd87eb4415bbc09fd987ceff2adce3c334fd"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-8659ca31cd482bd4f5888fa04dbc84e0e1b9dc05b95f0ca177b833c1ad45b163"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-62afde5d1cbd1800e170666ca800fd87eb4415bbc09fd987ceff2adce3c334fd",
      "right_occurrence_id": "occ-8659ca31cd482bd4f5888fa04dbc84e0e1b9dc05b95f0ca177b833c1ad45b163",
      "relation": "needs_review",
      "issue_code": "COORD_UNHANDLED_VERSION"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 1,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "6015cdeb43410626754b1cf8cb6c84fc821732eaec5364339d5f02ea191c15e3",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "39f28099f3962d1ef8fec00bd0072db2b9eea3da2eba29ffdf9929ebe9276695",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "16cc42dff84b0eefeedeb193f9ded9b6fa039e291aab08ec47726491b5d5be8d",
      "byte_length": 1905
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "e51e0ab069fe1ba96a397d24cc9248051004fe3af8d771577b185725d9b95d0b",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "92d21d0af635eaf1f190da2689bed4ad50c1e618e06ce732d9f134529ea09589",
      "byte_length": 12393
    },
    "input-a--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "1ea2d41e63a7a0d435aa715b4b17d9a0e3c1e94c201b10a9ca88ca7ecb916a5d",
      "byte_length": 1185
    },
    "input-a--verification.json": {
      "sha256": "eeeb062e362c3dcb9cbb6c568b02d191a9b616cd3dfaaf0b60e72490b972cb9d",
      "byte_length": 16994
    },
    "input-a--verification.md": {
      "sha256": "a7357128da4b8d1926aa3cf91c1abe0b2d8243f895701683ad53547b38714c7e",
      "byte_length": 17428
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "7cac3b4c38a7a03916ba8984fb025e826d04932ff4c0a92c0ff6ac749add82ae",
      "byte_length": 3052
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "32216502b92b7a51e2d12956c8381bebb1ed462c3789ef37e2f8a2e88d5494e6",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "309af89f60f00c4f757ebb59318ad2724a7fffcb13d45ce3d29cc17809244fb5",
      "byte_length": 12393
    },
    "input-b--review-original.json": {
      "sha256": "e44c5f5e2f0d340a45bbf3262c34067ae72182ae81440c389362246ce5ecccb4",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "bf48b23d361805b7e0914b6f39392809812d061d5c017f19fbe31a9fb5f8754f",
      "byte_length": 1185
    },
    "input-b--verification.json": {
      "sha256": "68c75103129393cee45fb7981a817aa3269e41c0bdce355fffd707de21f0b19d",
      "byte_length": 16994
    },
    "input-b--verification.md": {
      "sha256": "50168725c10b78aaf3433acc6b4d15e0c944e951c7b66ee99cdf412304cd4533",
      "byte_length": 17428
    }
  }
}
```
