# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
      "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
      "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
      "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7",
      "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
      "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "9deaa5cd-6bb4-4295-bb3a-8b5618024ae5",
          "ordinal": 0,
          "resource_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 288,
        "text": "公开自造资料 unit_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
    "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
    "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
    "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7",
    "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
    "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "f20e3915442b7ca2c839c42dfa4531971c6f7a7f823390bc3d02cd7920ff1526",
        "byte_length": 3056
      },
      "decision.json": {
        "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "a521e4d94a9b887dd8fbbada80ea28358e137d4b80f8128aa24ad972ee1eb378",
        "byte_length": 750
      },
      "review.json": {
        "sha256": "b7fe3b75bd69b7c1a6aba446762c3e4486a03b252727d614611b4fb06b939fdb",
        "byte_length": 510
      }
    },
    "gold_sha256": "a521e4d94a9b887dd8fbbada80ea28358e137d4b80f8128aa24ad972ee1eb378"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
          "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
          "manifest_sha256": null,
          "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
          "parse_id": null,
          "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
          "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
          "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7"
        },
        "request_id": "synthetic-variants-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
          "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
          "manifest_sha256": null,
          "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
          "parse_id": null,
          "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
          "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
          "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7"
        },
        "request_id": "synthetic-variants-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 40,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 288,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 208,
        "excerpt_sha256": "0bcb182ce84cceac1bf97268eaba4676568c87fb551e338b87f22aa2de69b452",
        "excerpt_start_byte": 40,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 208,
        "quote": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 95
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 208,
          "excerpt_sha256": "0bcb182ce84cceac1bf97268eaba4676568c87fb551e338b87f22aa2de69b452",
          "excerpt_start_byte": 40,
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "36",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "km/h",
        "value": "36",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "km/h",
      "actual": {
        "measurement": "km/h",
        "qualifiers": [
          "km/h",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "温度 30 ℃",
      "actual": {
        "body": [
          "温度30℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "km/h",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度30℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "km/h",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度30℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "km/h",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 288,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "km/h"
      },
      "actual": [
        "km/h",
        "温度 30 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "f20e3915442b7ca2c839c42dfa4531971c6f7a7f823390bc3d02cd7920ff1526",
      "byte_length": 3056
    },
    "decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "a521e4d94a9b887dd8fbbada80ea28358e137d4b80f8128aa24ad972ee1eb378",
      "byte_length": 750
    },
    "knowledge-ir.json": {
      "sha256": "d08d333486483575254e9e872197cf82fa1b3a5553c6627f772b08163dd67858",
      "byte_length": 12411
    },
    "review-original.json": {
      "sha256": "b7fe3b75bd69b7c1a6aba446762c3e4486a03b252727d614611b4fb06b939fdb",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "7f33e016b61e701c98d9d38245c90626959a602c21f8d1152291e2c40663403c",
      "byte_length": 1180
    }
  }
}
```
