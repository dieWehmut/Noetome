# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "2cec7e2c-be4a-4a98-b5db-18523c8d2493",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
        "import_id": "f3c837d4-5edc-474a-9083-3f7bab58f8de",
        "source_id": "da626289-572f-4eb0-87a5-5b7c8668598f",
        "version_id": "db38db94-35ae-4b29-9bb6-73a91df4b59f",
        "content_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
        "normalized_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
              "import_id": "f3c837d4-5edc-474a-9083-3f7bab58f8de",
              "manifest_sha256": null,
              "normalized_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
              "parse_id": null,
              "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
              "source_id": "da626289-572f-4eb0-87a5-5b7c8668598f",
              "version_id": "db38db94-35ae-4b29-9bb6-73a91df4b59f"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
              "import_id": "f3c837d4-5edc-474a-9083-3f7bab58f8de",
              "manifest_sha256": null,
              "normalized_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
              "parse_id": null,
              "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
              "source_id": "da626289-572f-4eb0-87a5-5b7c8668598f",
              "version_id": "db38db94-35ae-4b29-9bb6-73a91df4b59f"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 40,
          "end_byte": 207,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 287,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 207,
            "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
            "excerpt_start_byte": 40,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 207,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 95
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 207,
              "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
              "excerpt_start_byte": 40,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 287,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "7b012800dd075395f8993ccbd3859fedc602ce40495dc38104ca8d775d03cd97",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "b5a595d8ac5f281d570a5b951a3d65f16de0bdb91c0908a4ad67a7eb87715144",
          "byte_length": 12392
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "bacc59880fdbacb287b5ff827617c7c50cd968d35d79411fafc89e9fa77c99c6",
          "byte_length": 1179
        },
        "verification.json": {
          "sha256": "f1ceaee6af1d150d0cae4009f982348d432b099bb436b61ccae07af92cd558b3",
          "byte_length": 16987
        },
        "verification.md": {
          "sha256": "eeacca53d57bc3d16b90b5471b64f431b7627719c94530c74139a1292164529c",
          "byte_length": 17421
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
        "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
        "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
        "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7",
        "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
        "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
              "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
              "manifest_sha256": null,
              "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
              "parse_id": null,
              "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
              "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
              "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
              "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
              "manifest_sha256": null,
              "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
              "parse_id": null,
              "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
              "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
              "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 40,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 288,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 208,
            "excerpt_sha256": "0bcb182ce84cceac1bf97268eaba4676568c87fb551e338b87f22aa2de69b452",
            "excerpt_start_byte": 40,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 208,
            "quote": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 95
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 208,
              "excerpt_sha256": "0bcb182ce84cceac1bf97268eaba4676568c87fb551e338b87f22aa2de69b452",
              "excerpt_start_byte": 40,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "36",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "km/h",
            "value": "36",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "km/h",
          "actual": {
            "measurement": "km/h",
            "qualifiers": [
              "km/h",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "km/h",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "km/h",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "km/h",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "km/h"
          },
          "actual": [
            "km/h",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "f20e3915442b7ca2c839c42dfa4531971c6f7a7f823390bc3d02cd7920ff1526",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "a521e4d94a9b887dd8fbbada80ea28358e137d4b80f8128aa24ad972ee1eb378",
          "byte_length": 750
        },
        "knowledge-ir.json": {
          "sha256": "d08d333486483575254e9e872197cf82fa1b3a5553c6627f772b08163dd67858",
          "byte_length": 12411
        },
        "review-original.json": {
          "sha256": "b7fe3b75bd69b7c1a6aba446762c3e4486a03b252727d614611b4fb06b939fdb",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "7f33e016b61e701c98d9d38245c90626959a602c21f8d1152291e2c40663403c",
          "byte_length": 1180
        },
        "verification.json": {
          "sha256": "02e03f9753960d99882af8137367c8c45f20a5a0f8bc7671d26935ea83631b2e",
          "byte_length": 17003
        },
        "verification.md": {
          "sha256": "7fde3077749775fefa911645b2da4288511023553dba0437e3537e60da375e2e",
          "byte_length": 17437
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 40,
        "end_byte": 207,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-0470b1f84aee0a08420e53ccae2c8d41a5c2dbaec9cab479523bf6fd321c75cf",
      "input_id": "a",
      "binding": {
        "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
        "import_id": "f3c837d4-5edc-474a-9083-3f7bab58f8de",
        "source_id": "da626289-572f-4eb0-87a5-5b7c8668598f",
        "version_id": "db38db94-35ae-4b29-9bb6-73a91df4b59f",
        "content_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
        "normalized_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "8336f3ff-62c7-4789-9c69-ee6038a93e08",
          "ordinal": 0,
          "resource_sha256": "0e205027ac491366c92d38d3d2fa7f2ac6a6701c009a95657b8965b03844d6c6"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 287,
        "text": "公开自造资料 unit_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 40,
          "excerpt_end_byte": 207,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "invented-equivalent-unit",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 40,
        "end_byte": 208,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "0bcb182ce84cceac1bf97268eaba4676568c87fb551e338b87f22aa2de69b452"
      },
      "occurrence_id": "occ-36806c92ee8d885e2ab721632e5b0c2532d30cd17df90f28d2f4deb690638f93",
      "input_id": "b",
      "binding": {
        "project_id": "f96a52e8-c7cb-434d-a53b-91483db08486",
        "import_id": "c1b6c076-f69d-4bf1-9e9f-766d4110376a",
        "source_id": "fc56e7df-be0f-4d0e-9f50-7f915616850d",
        "version_id": "28a6600e-8c39-4469-83a8-bfa99d85a5c7",
        "content_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
        "normalized_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "9deaa5cd-6bb4-4295-bb3a-8b5618024ae5",
          "ordinal": 0,
          "resource_sha256": "2377eb8f6b5e693c62d8547eb54a004f83bf2326995a24793395875152e6b961"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 288,
        "text": "公开自造资料 unit_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "km/h",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "36",
          "unit": "km/h",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 40,
          "excerpt_end_byte": 208,
          "excerpt_sha256": "0bcb182ce84cceac1bf97268eaba4676568c87fb551e338b87f22aa2de69b452",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 36 km/h，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "36",
      "unit_value": "km/h",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-933d624a771ded2fc754b03a310018149843c49948701c67fa005048e457791e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "invented-equivalent-unit",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-0470b1f84aee0a08420e53ccae2c8d41a5c2dbaec9cab479523bf6fd321c75cf"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-97eda97842f6bf66eb8200d796c1b86b3ee95623e8ba958d86cfcef534c64451",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "36",
      "unit": "km/h",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-36806c92ee8d885e2ab721632e5b0c2532d30cd17df90f28d2f4deb690638f93"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNIT_NOT_COMPARABLE"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-0470b1f84aee0a08420e53ccae2c8d41a5c2dbaec9cab479523bf6fd321c75cf",
      "right_occurrence_id": "occ-36806c92ee8d885e2ab721632e5b0c2532d30cd17df90f28d2f4deb690638f93",
      "relation": "needs_review",
      "issue_code": "COORD_UNIT_NOT_COMPARABLE"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "71347fc8e1e6a7376bd0d2fa39f4002a58c96f1e3f6f2cb58dc562bf95585bf4",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "c35c4ce71064ef106f84731bda4f4de0dfe208f2c37a9763c63786c7592c23c4",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "16cc42dff84b0eefeedeb193f9ded9b6fa039e291aab08ec47726491b5d5be8d",
      "byte_length": 1905
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "7b012800dd075395f8993ccbd3859fedc602ce40495dc38104ca8d775d03cd97",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "b5a595d8ac5f281d570a5b951a3d65f16de0bdb91c0908a4ad67a7eb87715144",
      "byte_length": 12392
    },
    "input-a--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "bacc59880fdbacb287b5ff827617c7c50cd968d35d79411fafc89e9fa77c99c6",
      "byte_length": 1179
    },
    "input-a--verification.json": {
      "sha256": "f1ceaee6af1d150d0cae4009f982348d432b099bb436b61ccae07af92cd558b3",
      "byte_length": 16987
    },
    "input-a--verification.md": {
      "sha256": "eeacca53d57bc3d16b90b5471b64f431b7627719c94530c74139a1292164529c",
      "byte_length": 17421
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "f20e3915442b7ca2c839c42dfa4531971c6f7a7f823390bc3d02cd7920ff1526",
      "byte_length": 3056
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "a521e4d94a9b887dd8fbbada80ea28358e137d4b80f8128aa24ad972ee1eb378",
      "byte_length": 750
    },
    "input-b--knowledge-ir.json": {
      "sha256": "d08d333486483575254e9e872197cf82fa1b3a5553c6627f772b08163dd67858",
      "byte_length": 12411
    },
    "input-b--review-original.json": {
      "sha256": "b7fe3b75bd69b7c1a6aba446762c3e4486a03b252727d614611b4fb06b939fdb",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "7f33e016b61e701c98d9d38245c90626959a602c21f8d1152291e2c40663403c",
      "byte_length": 1180
    },
    "input-b--verification.json": {
      "sha256": "02e03f9753960d99882af8137367c8c45f20a5a0f8bc7671d26935ea83631b2e",
      "byte_length": 17003
    },
    "input-b--verification.md": {
      "sha256": "7fde3077749775fefa911645b2da4288511023553dba0437e3537e60da375e2e",
      "byte_length": 17437
    }
  }
}
```
