# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "9c16a891-06e3-45dd-83ea-b312c044303f",
      "import_id": "2eef1e65-6e6d-4df3-b6e2-4b9be55c504c",
      "source_id": "4aa78bd4-1e84-4f5a-bb5b-9639470bbba3",
      "version_id": "f657cc03-8d2e-4c44-849b-b9adbec76d8b",
      "content_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
      "normalized_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "429e6be1-400d-498d-bb94-116482bd70cd",
          "ordinal": 0,
          "resource_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 289,
        "text": "公开自造资料 undated_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "9c16a891-06e3-45dd-83ea-b312c044303f",
    "import_id": "2eef1e65-6e6d-4df3-b6e2-4b9be55c504c",
    "source_id": "4aa78bd4-1e84-4f5a-bb5b-9639470bbba3",
    "version_id": "f657cc03-8d2e-4c44-849b-b9adbec76d8b",
    "content_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
    "normalized_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "bc3baa679e70e337ccd99f8d6d9ea46bc89f0a63987712b587b28e73e3dc8055",
        "byte_length": 3049
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
        "byte_length": 744
      },
      "review.json": {
        "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
        "byte_length": 510
      }
    },
    "gold_sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
          "import_id": "2eef1e65-6e6d-4df3-b6e2-4b9be55c504c",
          "manifest_sha256": null,
          "normalized_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
          "parse_id": null,
          "project_id": "9c16a891-06e3-45dd-83ea-b312c044303f",
          "source_id": "4aa78bd4-1e84-4f5a-bb5b-9639470bbba3",
          "version_id": "f657cc03-8d2e-4c44-849b-b9adbec76d8b"
        },
        "request_id": "synthetic-variants-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
          "import_id": "2eef1e65-6e6d-4df3-b6e2-4b9be55c504c",
          "manifest_sha256": null,
          "normalized_sha256": "730cad725fae76df1c84c6f3b9711bdbdb49564f1d492ac39eff658f44bfbeee",
          "parse_id": null,
          "project_id": "9c16a891-06e3-45dd-83ea-b312c044303f",
          "source_id": "4aa78bd4-1e84-4f5a-bb5b-9639470bbba3",
          "version_id": "f657cc03-8d2e-4c44-849b-b9adbec76d8b"
        },
        "request_id": "synthetic-variants-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 43,
      "end_byte": 209,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 289,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 209,
        "excerpt_sha256": "03a488c379b8f3b20a746a1cb3af9c1dcc9464784fb47b8097cb8dcab23d2bc7",
        "excerpt_start_byte": 43,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 209,
        "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 98
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 209,
          "excerpt_sha256": "03a488c379b8f3b20a746a1cb3af9c1dcc9464784fb47b8097cb8dcab23d2bc7",
          "excerpt_start_byte": 43,
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "8",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "8",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 289,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "bc3baa679e70e337ccd99f8d6d9ea46bc89f0a63987712b587b28e73e3dc8055",
      "byte_length": 3049
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "knowledge-ir.json": {
      "sha256": "8d6da2a9e476a851deabdaa3da2717f54d86ae21d5c14bd8d247248831cc342c",
      "byte_length": 12381
    },
    "review-original.json": {
      "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "b2e0f58aed488be336971cd10ec3a6a3d8ff66b3871e8eb3c86b06fee2c9a516",
      "byte_length": 1181
    }
  }
}
```
