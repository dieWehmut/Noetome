# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "c2ff1a34-1e49-4bc8-b4cb-b59ffe96d6ee",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
        "import_id": "45456a5d-06ba-4161-b2a3-5a464a066d4a",
        "source_id": "ee486881-e9c8-42b3-b9dc-636f3bc5cfc5",
        "version_id": "583ea50b-c127-494f-a8c4-d9d61e379d52",
        "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "import_id": "45456a5d-06ba-4161-b2a3-5a464a066d4a",
              "manifest_sha256": null,
              "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "parse_id": null,
              "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
              "source_id": "ee486881-e9c8-42b3-b9dc-636f3bc5cfc5",
              "version_id": "583ea50b-c127-494f-a8c4-d9d61e379d52"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "import_id": "45456a5d-06ba-4161-b2a3-5a464a066d4a",
              "manifest_sha256": null,
              "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
              "parse_id": null,
              "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
              "source_id": "ee486881-e9c8-42b3-b9dc-636f3bc5cfc5",
              "version_id": "583ea50b-c127-494f-a8c4-d9d61e379d52"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 41,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 285,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 205,
            "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
            "excerpt_start_byte": 41,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 205,
              "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
              "excerpt_start_byte": 41,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "9d9a3ceae23e888c5b4a451dc21adb9d6fbdf73b7884dcb07db568c6d4e84176",
          "byte_length": 3047
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
          "byte_length": 744
        },
        "knowledge-ir.json": {
          "sha256": "557513d33d95513722692cc256a8a190aa62d0a98ae63f92951703137e8b8460",
          "byte_length": 12375
        },
        "review-original.json": {
          "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "e3fd831d486d0696bccd367c2f90045ddfa6eed35a7d0198194948a84c7112e9",
          "byte_length": 1177
        },
        "verification.json": {
          "sha256": "a18cbe329223bf28b3bd66e7d6d28cfcdf022b551ee1ca4ee8a3961a0d921c5d",
          "byte_length": 16973
        },
        "verification.md": {
          "sha256": "8549223e967e80b1894c2881ca06cc46868da0c9c5193761f0c6267d66b49094",
          "byte_length": 17407
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
        "import_id": "e54e9f8d-0e3c-475d-bfbe-88acca345225",
        "source_id": "e1f33669-484b-4017-a8e8-84d6ced658a4",
        "version_id": "45a41f65-6beb-43d8-97a8-6237a2631f84",
        "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "import_id": "e54e9f8d-0e3c-475d-bfbe-88acca345225",
              "manifest_sha256": null,
              "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "parse_id": null,
              "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
              "source_id": "e1f33669-484b-4017-a8e8-84d6ced658a4",
              "version_id": "45a41f65-6beb-43d8-97a8-6237a2631f84"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "import_id": "e54e9f8d-0e3c-475d-bfbe-88acca345225",
              "manifest_sha256": null,
              "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
              "parse_id": null,
              "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
              "source_id": "e1f33669-484b-4017-a8e8-84d6ced658a4",
              "version_id": "45a41f65-6beb-43d8-97a8-6237a2631f84"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 41,
          "end_byte": 209,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 289,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 209,
            "excerpt_sha256": "ca4f28e3b10d58599852553d33adadf8c9fdd441bf02819ba893fd3412ef7b8e",
            "excerpt_start_byte": 41,
            "quote": "适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 209,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 97
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 209,
              "excerpt_sha256": "ca4f28e3b10d58599852553d33adadf8c9fdd441bf02819ba893fd3412ef7b8e",
              "excerpt_start_byte": 41,
              "quote": "适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "26b4878979f2036417fef77ece51ca50db039e5d014bf349e98a2ae426090757",
          "byte_length": 3053
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "a8a9a14c1f18fe3507023ed97ebd9d2ca17e6666222906376570848c2399a34f",
          "byte_length": 12395
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "49b292de6680215136291c9adf8e9f8c9a6c34f808509ed2efa22efcb2691c76",
          "byte_length": 1181
        },
        "verification.json": {
          "sha256": "996208f0e92c282a54afd000855f31a3c3d89ae66619fbc2d61dacc132e72524",
          "byte_length": 16991
        },
        "verification.md": {
          "sha256": "85834f84759bc97a588cd6ef38e60b66403737b8e3fc40086f568cfa1cbc3363",
          "byte_length": 17425
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-45243a75940c9421e63df60d8f3467b9f7cbc66857cf87bcd50443e2552e10d2",
      "input_id": "a",
      "binding": {
        "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
        "import_id": "45456a5d-06ba-4161-b2a3-5a464a066d4a",
        "source_id": "ee486881-e9c8-42b3-b9dc-636f3bc5cfc5",
        "version_id": "583ea50b-c127-494f-a8c4-d9d61e379d52",
        "content_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "normalized_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "325e3002-5a50-4041-a247-7e8d0313331e",
          "ordinal": 0,
          "resource_sha256": "93de6c5d37a5b62fba9c5a0b2bb9199745f77328ef802dcf25ca278cd0bc917a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 285,
        "text": "公开自造资料 overlapping_time/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 41,
          "excerpt_end_byte": 205,
          "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "day",
          "value": "2020-12-01"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 209,
        "quote": "适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "ca4f28e3b10d58599852553d33adadf8c9fdd441bf02819ba893fd3412ef7b8e"
      },
      "occurrence_id": "occ-da35721d8b4a8f02dd4a2949f2e231d26192775651d89393c533115f9aaa4683",
      "input_id": "b",
      "binding": {
        "project_id": "e38323e0-13d8-4b86-9cee-2335139c6881",
        "import_id": "e54e9f8d-0e3c-475d-bfbe-88acca345225",
        "source_id": "e1f33669-484b-4017-a8e8-84d6ced658a4",
        "version_id": "45a41f65-6beb-43d8-97a8-6237a2631f84",
        "content_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "normalized_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "01f99177-db15-408f-af1a-c8cdc28ba2eb",
          "ordinal": 0,
          "resource_sha256": "a8246c7a5b566912bbd3df719898d4f0a5434faeca22eb426251f70f6c23c16a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 289,
        "text": "公开自造资料 overlapping_time/b。\n适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 41,
          "excerpt_end_byte": 209,
          "excerpt_sha256": "ca4f28e3b10d58599852553d33adadf8c9fdd441bf02819ba893fd3412ef7b8e",
          "quote": "适用条件：已列明；观点时间：2020-12-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "day",
        "value": "2020-12-01"
      },
      "fact_id": "fact-v2-686527072ebe4f9ab78283f0506fb4c6bcfb0eb6b3015aa82ed120defa1f9784",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-da35721d8b4a8f02dd4a2949f2e231d26192775651d89393c533115f9aaa4683"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-45243a75940c9421e63df60d8f3467b9f7cbc66857cf87bcd50443e2552e10d2"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_TIME_NOT_COMPARABLE"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": "occ-45243a75940c9421e63df60d8f3467b9f7cbc66857cf87bcd50443e2552e10d2",
      "later_occurrence_id": "occ-da35721d8b4a8f02dd4a2949f2e231d26192775651d89393c533115f9aaa4683",
      "left_occurrence_id": "occ-45243a75940c9421e63df60d8f3467b9f7cbc66857cf87bcd50443e2552e10d2",
      "right_occurrence_id": "occ-da35721d8b4a8f02dd4a2949f2e231d26192775651d89393c533115f9aaa4683",
      "relation": "historical_evolution",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "9c0b8f37c23264f86377d49d77e6891bf9605244c3b50390b34fa5d32b1db64b",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "49aed58295f3e6e9ab60c67ccbdaacefa5fbc14b53ca3f3733d5b5f4547313d5",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "2ebbaf6743fb114e643dc6b77a8629bccb42154cea4565d1d6402b6f6c683d5b",
      "byte_length": 1914
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "9d9a3ceae23e888c5b4a451dc21adb9d6fbdf73b7884dcb07db568c6d4e84176",
      "byte_length": 3047
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "input-a--knowledge-ir.json": {
      "sha256": "557513d33d95513722692cc256a8a190aa62d0a98ae63f92951703137e8b8460",
      "byte_length": 12375
    },
    "input-a--review-original.json": {
      "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "e3fd831d486d0696bccd367c2f90045ddfa6eed35a7d0198194948a84c7112e9",
      "byte_length": 1177
    },
    "input-a--verification.json": {
      "sha256": "a18cbe329223bf28b3bd66e7d6d28cfcdf022b551ee1ca4ee8a3961a0d921c5d",
      "byte_length": 16973
    },
    "input-a--verification.md": {
      "sha256": "8549223e967e80b1894c2881ca06cc46868da0c9c5193761f0c6267d66b49094",
      "byte_length": 17407
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "26b4878979f2036417fef77ece51ca50db039e5d014bf349e98a2ae426090757",
      "byte_length": 3053
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "a8a9a14c1f18fe3507023ed97ebd9d2ca17e6666222906376570848c2399a34f",
      "byte_length": 12395
    },
    "input-b--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "49b292de6680215136291c9adf8e9f8c9a6c34f808509ed2efa22efcb2691c76",
      "byte_length": 1181
    },
    "input-b--verification.json": {
      "sha256": "996208f0e92c282a54afd000855f31a3c3d89ae66619fbc2d61dacc132e72524",
      "byte_length": 16991
    },
    "input-b--verification.md": {
      "sha256": "85834f84759bc97a588cd6ef38e60b66403737b8e3fc40086f568cfa1cbc3363",
      "byte_length": 17425
    }
  }
}
```
