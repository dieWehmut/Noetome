# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：1。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "3e868ceb-3302-4f86-876c-e33c392f6282",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
        "import_id": "9177961a-b522-4667-aa4c-dcbc1890a9a1",
        "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
        "version_id": "e75bffa3-565f-4f71-90cd-60ed51101ab4",
        "content_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
        "normalized_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
              "import_id": "9177961a-b522-4667-aa4c-dcbc1890a9a1",
              "manifest_sha256": null,
              "normalized_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
              "parse_id": null,
              "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
              "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
              "version_id": "e75bffa3-565f-4f71-90cd-60ed51101ab4"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
              "import_id": "9177961a-b522-4667-aa4c-dcbc1890a9a1",
              "manifest_sha256": null,
              "normalized_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
              "parse_id": null,
              "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
              "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
              "version_id": "e75bffa3-565f-4f71-90cd-60ed51101ab4"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 44,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 288,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 208,
            "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
            "excerpt_start_byte": 44,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 208,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 97
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 208,
              "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
              "excerpt_start_byte": 44,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 288,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "b94403ceb8bcbe167a316ccf229a3bec66024f98d8eff180fd84d47992226464",
          "byte_length": 3047
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
          "byte_length": 744
        },
        "knowledge-ir.json": {
          "sha256": "9e22df739ecfbc75513588dda323efaab3b70ac457e5f1616ef3d6e3b458a75e",
          "byte_length": 12375
        },
        "review-original.json": {
          "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "f6b2ee3cb03beb85ee33bf4cd4886350060d6348021df47899996b7e5b7428fe",
          "byte_length": 1180
        },
        "verification.json": {
          "sha256": "b17760c7bb461e77051a76c9926ac30dce7a30977f8f7bd314e01ae4f6b6ce93",
          "byte_length": 16976
        },
        "verification.md": {
          "sha256": "1fa28ba34b8d53d446719ac7697212208193f671f381b09a91702fd120a3338c",
          "byte_length": 17410
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
        "import_id": "2be695d8-c1f6-4baa-8774-09432c3f2413",
        "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
        "version_id": "add3abc4-7bbf-4383-a171-8d2d55f45f22",
        "content_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
        "normalized_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
              "import_id": "2be695d8-c1f6-4baa-8774-09432c3f2413",
              "manifest_sha256": null,
              "normalized_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
              "parse_id": null,
              "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
              "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
              "version_id": "add3abc4-7bbf-4383-a171-8d2d55f45f22"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
              "import_id": "2be695d8-c1f6-4baa-8774-09432c3f2413",
              "manifest_sha256": null,
              "normalized_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
              "parse_id": null,
              "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
              "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
              "version_id": "add3abc4-7bbf-4383-a171-8d2d55f45f22"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 44,
          "end_byte": 209,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 289,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 209,
            "excerpt_sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96",
            "excerpt_start_byte": 44,
            "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 209,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 97
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 209,
              "excerpt_sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96",
              "excerpt_start_byte": 44,
              "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 289,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "09ebffbe2453b1e07357ba3195ddd14deb1ebf43377adaf5ea4508dd2fc5ab1a",
          "byte_length": 3050
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "9f2f86ef9333410fa6063cb1a7b6c978d829e8ecb468dee111057a846e94e591",
          "byte_length": 12386
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "75811e76a34e4f6ed3254c096a07a44bd3242b5970eb1280eac9d279106a5934",
          "byte_length": 1181
        },
        "verification.json": {
          "sha256": "c5e7f7f19525dbf226e84533b343c3a00b0d40e89855443d3470285e9c4d5da0",
          "byte_length": 16985
        },
        "verification.md": {
          "sha256": "efcf95c96db5197f7124ddde3fac41a7e182de25029ed7d681a445b4476aa235",
          "byte_length": 17419
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2024"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 44,
        "end_byte": 209,
        "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96"
      },
      "occurrence_id": "occ-12b99e6381fac8ebf6c28c9042ebf8c9fe92dd7277ab9a0982efdef97153bf9d",
      "input_id": "b",
      "binding": {
        "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
        "import_id": "2be695d8-c1f6-4baa-8774-09432c3f2413",
        "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
        "version_id": "add3abc4-7bbf-4383-a171-8d2d55f45f22",
        "content_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
        "normalized_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "27b69ea2-2bab-4564-952c-c2bd742f3225",
          "ordinal": 0,
          "resource_sha256": "62599709461bbfd2f68501de5bf1a037048e748bbbe9ffefd6959a72cc121a3d"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 289,
        "text": "公开自造资料 same_source_history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 44,
          "excerpt_end_byte": 209,
          "excerpt_sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96",
          "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 44,
        "end_byte": 208,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-843e819ecc7a7dd2915802ba95a768e0ba7c5b424810e8beeed3965e0d74c863",
      "input_id": "a",
      "binding": {
        "project_id": "6ab6ab3a-43c5-462d-8976-b3a598a5d655",
        "import_id": "9177961a-b522-4667-aa4c-dcbc1890a9a1",
        "source_id": "1d813a66-420d-43f2-a5f0-e732f4a336c6",
        "version_id": "e75bffa3-565f-4f71-90cd-60ed51101ab4",
        "content_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
        "normalized_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a74dce3f-3a8d-4d28-99e7-8c81271de8e8",
          "ordinal": 0,
          "resource_sha256": "65ad35d700efd6f2bf2d2288662a3b5888afd3e3938674765c016aa9be806596"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 288,
        "text": "公开自造资料 same_source_history/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 44,
          "excerpt_end_byte": 208,
          "excerpt_sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2024"
      },
      "fact_id": "fact-v2-54940b4aa46cc077b253f0197434c586029bbcdd699ddf5bbb60d32c8c20f632",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-12b99e6381fac8ebf6c28c9042ebf8c9fe92dd7277ab9a0982efdef97153bf9d"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-843e819ecc7a7dd2915802ba95a768e0ba7c5b424810e8beeed3965e0d74c863"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": "occ-843e819ecc7a7dd2915802ba95a768e0ba7c5b424810e8beeed3965e0d74c863",
      "later_occurrence_id": "occ-12b99e6381fac8ebf6c28c9042ebf8c9fe92dd7277ab9a0982efdef97153bf9d",
      "left_occurrence_id": "occ-12b99e6381fac8ebf6c28c9042ebf8c9fe92dd7277ab9a0982efdef97153bf9d",
      "right_occurrence_id": "occ-843e819ecc7a7dd2915802ba95a768e0ba7c5b424810e8beeed3965e0d74c863",
      "relation": "historical_evolution",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 1,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 1,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2fdae0973b393afd5b69a55682b69e004c54ad4912d5b0a7c4c5c1c85efe07f7",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "8914a7d1c0fe0eb427dac4947c40333ea08a6030d77b9f861061ad5e8e6aa69d",
      "byte_length": 40629
    },
    "coordination-original.json": {
      "sha256": "7e9d2432bb3e1a0576d82c62a54cc19c558b8c10d10ef2ec854ad6327ebc28d4",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "26b3eaacc421af9589f576e42fe09975f3535418a7e3700b73d2e47476378dfd",
      "byte_length": 1909
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "b94403ceb8bcbe167a316ccf229a3bec66024f98d8eff180fd84d47992226464",
      "byte_length": 3047
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "input-a--knowledge-ir.json": {
      "sha256": "9e22df739ecfbc75513588dda323efaab3b70ac457e5f1616ef3d6e3b458a75e",
      "byte_length": 12375
    },
    "input-a--review-original.json": {
      "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "f6b2ee3cb03beb85ee33bf4cd4886350060d6348021df47899996b7e5b7428fe",
      "byte_length": 1180
    },
    "input-a--verification.json": {
      "sha256": "b17760c7bb461e77051a76c9926ac30dce7a30977f8f7bd314e01ae4f6b6ce93",
      "byte_length": 16976
    },
    "input-a--verification.md": {
      "sha256": "1fa28ba34b8d53d446719ac7697212208193f671f381b09a91702fd120a3338c",
      "byte_length": 17410
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "09ebffbe2453b1e07357ba3195ddd14deb1ebf43377adaf5ea4508dd2fc5ab1a",
      "byte_length": 3050
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "9f2f86ef9333410fa6063cb1a7b6c978d829e8ecb468dee111057a846e94e591",
      "byte_length": 12386
    },
    "input-b--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "75811e76a34e4f6ed3254c096a07a44bd3242b5970eb1280eac9d279106a5934",
      "byte_length": 1181
    },
    "input-b--verification.json": {
      "sha256": "c5e7f7f19525dbf226e84533b343c3a00b0d40e89855443d3470285e9c4d5da0",
      "byte_length": 16985
    },
    "input-b--verification.md": {
      "sha256": "efcf95c96db5197f7124ddde3fac41a7e182de25029ed7d681a445b4476aa235",
      "byte_length": 17419
    }
  }
}
```
