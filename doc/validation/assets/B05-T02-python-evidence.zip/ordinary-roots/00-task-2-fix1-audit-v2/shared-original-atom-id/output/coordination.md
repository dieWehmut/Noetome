# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：0；条件不适用：2；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "3bf2cd1a-1b02-43fc-8381-ae9a547fd073",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
        "import_id": "a1901ee7-4a02-42fc-9f2d-70e53337198c",
        "source_id": "3d37b4c1-f3f4-4f3f-96b0-cb170fe24865",
        "version_id": "e93e2baf-bad6-4a07-954a-42345eaf9383",
        "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "import_id": "a1901ee7-4a02-42fc-9f2d-70e53337198c",
              "manifest_sha256": null,
              "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "parse_id": null,
              "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
              "source_id": "3d37b4c1-f3f4-4f3f-96b0-cb170fe24865",
              "version_id": "e93e2baf-bad6-4a07-954a-42345eaf9383"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "import_id": "a1901ee7-4a02-42fc-9f2d-70e53337198c",
              "manifest_sha256": null,
              "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "parse_id": null,
              "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
              "source_id": "3d37b4c1-f3f4-4f3f-96b0-cb170fe24865",
              "version_id": "e93e2baf-bad6-4a07-954a-42345eaf9383"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 39,
          "end_byte": 125,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 125,
            "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
            "excerpt_start_byte": 39,
            "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 125,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 125,
              "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
              "excerpt_start_byte": 39,
              "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "d51d467a69171abc06cdfeacd0f8ef259be6ef8f4610c60ee35b5f92f2d3a40f",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "5c6658349ead88fc5564f6d43cd532ca51f8ce14f1aaada0242df89ff5529657",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "016f81ca4c25e67753747c25da19e3d9ff31a2679fa37b0197bcb5e843198bf4",
          "byte_length": 1097
        },
        "verification.json": {
          "sha256": "928cbd4091be63acb66251438ad9acf0d64228a63866964356b9035e9e255254",
          "byte_length": 14128
        },
        "verification.md": {
          "sha256": "9cab92db22ee5f55cdd794dcb9bb094d7522a5bba3c53734f819b28d5488722c",
          "byte_length": 14562
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
        "import_id": "9ea98c85-8d71-4f6f-a2c7-c02422a356c9",
        "source_id": "a0a0f46c-c2ce-455d-b9f4-e3c1395a1237",
        "version_id": "56a5e708-894e-4554-8465-5024afe83c72",
        "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "import_id": "9ea98c85-8d71-4f6f-a2c7-c02422a356c9",
              "manifest_sha256": null,
              "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "parse_id": null,
              "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
              "source_id": "a0a0f46c-c2ce-455d-b9f4-e3c1395a1237",
              "version_id": "56a5e708-894e-4554-8465-5024afe83c72"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "import_id": "9ea98c85-8d71-4f6f-a2c7-c02422a356c9",
              "manifest_sha256": null,
              "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "parse_id": null,
              "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
              "source_id": "a0a0f46c-c2ce-455d-b9f4-e3c1395a1237",
              "version_id": "56a5e708-894e-4554-8465-5024afe83c72"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 39,
          "end_byte": 125,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 125,
            "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
            "excerpt_start_byte": 39,
            "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 125,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 125,
              "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
              "excerpt_start_byte": 39,
              "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "5629383b909c53e7584e3991490b992ad83646d926f64eb4523aed93762e102f",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "8b91d9e10c8cd689adcd7240b578edb6e9d2283c029defe2c867c5a4f8b70bd3",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "ba85d54d233f1b7024cdac173b2977e31825e0419745c5e4f77501501de8494d",
          "byte_length": 1097
        },
        "verification.json": {
          "sha256": "afdf509f40a7bee46e52c440b1e92187c60fb687fce76666d030d7ede72caff0",
          "byte_length": 14128
        },
        "verification.md": {
          "sha256": "16fd64cabd6d82e158546aae4f1c8a7c7ba06b71146a215807741949cf7688a5",
          "byte_length": 14562
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 39,
        "end_byte": 125,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf"
      },
      "occurrence_id": "occ-37c15179273c2455da1875fbc0520d4df23d3a4999c70681c8f538afba2a0580",
      "input_id": "a",
      "binding": {
        "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
        "import_id": "a1901ee7-4a02-42fc-9f2d-70e53337198c",
        "source_id": "3d37b4c1-f3f4-4f3f-96b0-cb170fe24865",
        "version_id": "e93e2baf-bad6-4a07-954a-42345eaf9383",
        "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "6f9604f1-a358-47a2-9286-ba9694a218d5",
          "ordinal": 0,
          "resource_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 205,
        "text": "公开自造资料 not_applicable/a。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 39,
          "excerpt_end_byte": 125,
          "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
          "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 39,
        "end_byte": 125,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf"
      },
      "occurrence_id": "occ-5ea94b42247a82f74bf56a26e0251fb22cea6809deecfdd12deb9519a1e16dd4",
      "input_id": "b",
      "binding": {
        "project_id": "3ed63c43-ab2e-46b0-b806-22817d1ccd92",
        "import_id": "9ea98c85-8d71-4f6f-a2c7-c02422a356c9",
        "source_id": "a0a0f46c-c2ce-455d-b9f4-e3c1395a1237",
        "version_id": "56a5e708-894e-4554-8465-5024afe83c72",
        "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "3eca903a-1ca7-408a-9dce-1a77812112e6",
          "ordinal": 0,
          "resource_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 205,
        "text": "公开自造资料 not_applicable/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 39,
          "excerpt_end_byte": 125,
          "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
          "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-1da6d05004f6bd481c6bb96052d871827dae806e88b506031ed6e8ce82b887f3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-37c15179273c2455da1875fbc0520d4df23d3a4999c70681c8f538afba2a0580",
        "occ-5ea94b42247a82f74bf56a26e0251fb22cea6809deecfdd12deb9519a1e16dd4"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-37c15179273c2455da1875fbc0520d4df23d3a4999c70681c8f538afba2a0580",
      "right_occurrence_id": "occ-5ea94b42247a82f74bf56a26e0251fb22cea6809deecfdd12deb9519a1e16dd4",
      "relation": "duplicate",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 2,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 1,
    "canonical_facts": 1,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 1,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "b55611da4ac11bed01a2959fcd8ea89e677c1e90f586ad2118f06c6bb3fdc191",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "17f6c7c54f2748ccdfe8856d2f85af29f1809231d6154bb761d6c911a38f2dc7",
      "byte_length": 32161
    },
    "coordination-original.json": {
      "sha256": "cb2e316d5fbf7f5c8fcbccf4e561a490291e287c0dddec01aeaa4a6e9a362060",
      "byte_length": 4327
    },
    "identity-original.json": {
      "sha256": "340030f49697ddbbe1c6752789aecb5389e59debc8ab88fc019ccae388026ff0",
      "byte_length": 1923
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "d51d467a69171abc06cdfeacd0f8ef259be6ef8f4610c60ee35b5f92f2d3a40f",
      "byte_length": 2710
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "5c6658349ead88fc5564f6d43cd532ca51f8ce14f1aaada0242df89ff5529657",
      "byte_length": 9270
    },
    "input-a--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "016f81ca4c25e67753747c25da19e3d9ff31a2679fa37b0197bcb5e843198bf4",
      "byte_length": 1097
    },
    "input-a--verification.json": {
      "sha256": "928cbd4091be63acb66251438ad9acf0d64228a63866964356b9035e9e255254",
      "byte_length": 14128
    },
    "input-a--verification.md": {
      "sha256": "9cab92db22ee5f55cdd794dcb9bb094d7522a5bba3c53734f819b28d5488722c",
      "byte_length": 14562
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "5629383b909c53e7584e3991490b992ad83646d926f64eb4523aed93762e102f",
      "byte_length": 2710
    },
    "input-b--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-b--knowledge-ir.json": {
      "sha256": "8b91d9e10c8cd689adcd7240b578edb6e9d2283c029defe2c867c5a4f8b70bd3",
      "byte_length": 9270
    },
    "input-b--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "ba85d54d233f1b7024cdac173b2977e31825e0419745c5e4f77501501de8494d",
      "byte_length": 1097
    },
    "input-b--verification.json": {
      "sha256": "afdf509f40a7bee46e52c440b1e92187c60fb687fce76666d030d7ede72caff0",
      "byte_length": 14128
    },
    "input-b--verification.md": {
      "sha256": "16fd64cabd6d82e158546aae4f1c8a7c7ba06b71146a215807741949cf7688a5",
      "byte_length": 14562
    }
  }
}
```
