# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
      "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
      "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
      "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43",
      "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
      "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f1dc7329-816f-4f6b-b01a-efaa742986cb",
          "ordinal": 0,
          "resource_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 205,
        "text": "公开自造资料 not_applicable/a。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
    "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
    "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
    "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43",
    "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
    "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "61d2b47b575d83d436472b47d51973d0b232815f2de88afce5a57f8cac16c2dd",
        "byte_length": 2710
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
        "byte_length": 503
      },
      "review.json": {
        "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
        "byte_length": 510
      }
    },
    "gold_sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
          "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
          "manifest_sha256": null,
          "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
          "parse_id": null,
          "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
          "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
          "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43"
        },
        "request_id": "synthetic-variants-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
          "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
          "manifest_sha256": null,
          "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
          "parse_id": null,
          "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
          "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
          "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43"
        },
        "request_id": "synthetic-variants-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 39,
      "end_byte": 125,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 205,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 125,
        "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
        "excerpt_start_byte": 39,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 125,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 94
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 125,
          "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
          "excerpt_start_byte": 39,
          "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 205,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "61d2b47b575d83d436472b47d51973d0b232815f2de88afce5a57f8cac16c2dd",
      "byte_length": 2710
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "knowledge-ir.json": {
      "sha256": "e164f9cef8f55f7107d3b9240c10ec7ffa71efffdbc039f0f4b01b3f9f3bd61e",
      "byte_length": 9270
    },
    "review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "dc131e9c63c4d52123b4251a3ebf78aa0e6134504a7dcb50e2ae0c049effddfb",
      "byte_length": 1097
    }
  }
}
```
