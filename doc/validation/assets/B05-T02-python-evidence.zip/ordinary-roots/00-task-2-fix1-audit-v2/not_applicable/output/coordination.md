# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：0；条件不适用：2；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "d56ee5fd-1841-463c-b0ec-b7c7257a4085",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
        "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
        "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
        "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43",
        "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
              "manifest_sha256": null,
              "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "parse_id": null,
              "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
              "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
              "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
              "manifest_sha256": null,
              "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
              "parse_id": null,
              "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
              "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
              "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 39,
          "end_byte": 125,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 125,
            "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
            "excerpt_start_byte": 39,
            "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 125,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 125,
              "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
              "excerpt_start_byte": 39,
              "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "61d2b47b575d83d436472b47d51973d0b232815f2de88afce5a57f8cac16c2dd",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "e164f9cef8f55f7107d3b9240c10ec7ffa71efffdbc039f0f4b01b3f9f3bd61e",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "dc131e9c63c4d52123b4251a3ebf78aa0e6134504a7dcb50e2ae0c049effddfb",
          "byte_length": 1097
        },
        "verification.json": {
          "sha256": "323744a7987a8eb620f43fc0d6fbb0519d0e04878f66844db81eea6bed74c99c",
          "byte_length": 14128
        },
        "verification.md": {
          "sha256": "3708fa4ae77fd63e18e6efcbebc1f07b0b55df2c162d13131ae977106659fe71",
          "byte_length": 14562
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
        "import_id": "d5eaffb9-b44b-4b0d-927a-2a97a6357fa7",
        "source_id": "bf256b66-5911-493e-a896-fc2d3eb002f4",
        "version_id": "b7224adb-0849-4e62-8bc6-69382255c968",
        "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "import_id": "d5eaffb9-b44b-4b0d-927a-2a97a6357fa7",
              "manifest_sha256": null,
              "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "parse_id": null,
              "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
              "source_id": "bf256b66-5911-493e-a896-fc2d3eb002f4",
              "version_id": "b7224adb-0849-4e62-8bc6-69382255c968"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "import_id": "d5eaffb9-b44b-4b0d-927a-2a97a6357fa7",
              "manifest_sha256": null,
              "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
              "parse_id": null,
              "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
              "source_id": "bf256b66-5911-493e-a896-fc2d3eb002f4",
              "version_id": "b7224adb-0849-4e62-8bc6-69382255c968"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 39,
          "end_byte": 125,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 125,
            "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
            "excerpt_start_byte": 39,
            "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 125,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 125,
              "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
              "excerpt_start_byte": 39,
              "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 205,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "28387f178d0107b1eb0d69af2e97502b5cccf064861822d51f22aa60abff834d",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "c22cc9d0346af80983f646945eee98fe2a3b7d440d25b2821591f7f13156dc68",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "bd1f11c6e3d0d51c80ed43b816e6940fdbd83817199670a14b66b168a450f6d8",
          "byte_length": 1097
        },
        "verification.json": {
          "sha256": "71315afc113e8bdf63c9ce7a3e46606419049e3168edeb7ac6e15269fa31a8f0",
          "byte_length": 14128
        },
        "verification.md": {
          "sha256": "8db7b051197ecfacb08f934a066f573598577c2a3a8f18a01c5fe0f676e93962",
          "byte_length": 14562
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 39,
        "end_byte": 125,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf"
      },
      "occurrence_id": "occ-7caf3160049b39c1f0151df96ed9761bcb3f4206b0e7c8fa09bb7eb6a925edbc",
      "input_id": "b",
      "binding": {
        "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
        "import_id": "d5eaffb9-b44b-4b0d-927a-2a97a6357fa7",
        "source_id": "bf256b66-5911-493e-a896-fc2d3eb002f4",
        "version_id": "b7224adb-0849-4e62-8bc6-69382255c968",
        "content_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "normalized_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "90680e00-f534-47d5-b927-60a25543c211",
          "ordinal": 0,
          "resource_sha256": "cf37ce8631af411368b22e43b57a5348aa1faa3720742b3cef46b1afd2e5223d"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 205,
        "text": "公开自造资料 not_applicable/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 39,
          "excerpt_end_byte": 125,
          "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
          "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 39,
        "end_byte": 125,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf"
      },
      "occurrence_id": "occ-e926ace6ad108b1b1fc6c968908a1b420d56697cd673a7b5f96b22978791cce4",
      "input_id": "a",
      "binding": {
        "project_id": "a6218d0c-369b-4831-be82-0404dce4035d",
        "import_id": "6f78d4a2-d016-4505-87c0-9b9b7ad2b60f",
        "source_id": "b6a3f372-29d2-4bf1-a734-550e355b7aed",
        "version_id": "977f89f7-b96f-4384-8eb2-7ba456c73b43",
        "content_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "normalized_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f1dc7329-816f-4f6b-b01a-efaa742986cb",
          "ordinal": 0,
          "resource_sha256": "f1828772faedc2e70b08b7e8ef93235d4ca9aaa7140746d7e57588a26ec68999"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 205,
        "text": "公开自造资料 not_applicable/a。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 39,
          "excerpt_end_byte": 125,
          "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
          "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-1da6d05004f6bd481c6bb96052d871827dae806e88b506031ed6e8ce82b887f3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-7caf3160049b39c1f0151df96ed9761bcb3f4206b0e7c8fa09bb7eb6a925edbc",
        "occ-e926ace6ad108b1b1fc6c968908a1b420d56697cd673a7b5f96b22978791cce4"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-7caf3160049b39c1f0151df96ed9761bcb3f4206b0e7c8fa09bb7eb6a925edbc",
      "right_occurrence_id": "occ-e926ace6ad108b1b1fc6c968908a1b420d56697cd673a7b5f96b22978791cce4",
      "relation": "duplicate",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 2,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 1,
    "canonical_facts": 1,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 1,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "744de43409f169da57a55208cd2e48590c97ac1e18f13db1092b73e15e293996",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "80144b7719505453b9d3ba9645df714d95dbe5931c57637a26aed23db1ff488e",
      "byte_length": 32161
    },
    "coordination-original.json": {
      "sha256": "4b0f5137f0bda9ee3b6e5920307d7e3ff65bbc0d3b257a2fc8d4e28b0a015156",
      "byte_length": 4327
    },
    "identity-original.json": {
      "sha256": "c4794140598a49d9010886960b7afa53055231b9c537f4c16a117077effc739c",
      "byte_length": 1923
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "61d2b47b575d83d436472b47d51973d0b232815f2de88afce5a57f8cac16c2dd",
      "byte_length": 2710
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "e164f9cef8f55f7107d3b9240c10ec7ffa71efffdbc039f0f4b01b3f9f3bd61e",
      "byte_length": 9270
    },
    "input-a--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "dc131e9c63c4d52123b4251a3ebf78aa0e6134504a7dcb50e2ae0c049effddfb",
      "byte_length": 1097
    },
    "input-a--verification.json": {
      "sha256": "323744a7987a8eb620f43fc0d6fbb0519d0e04878f66844db81eea6bed74c99c",
      "byte_length": 14128
    },
    "input-a--verification.md": {
      "sha256": "3708fa4ae77fd63e18e6efcbebc1f07b0b55df2c162d13131ae977106659fe71",
      "byte_length": 14562
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "28387f178d0107b1eb0d69af2e97502b5cccf064861822d51f22aa60abff834d",
      "byte_length": 2710
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-b--knowledge-ir.json": {
      "sha256": "c22cc9d0346af80983f646945eee98fe2a3b7d440d25b2821591f7f13156dc68",
      "byte_length": 9270
    },
    "input-b--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "bd1f11c6e3d0d51c80ed43b816e6940fdbd83817199670a14b66b168a450f6d8",
      "byte_length": 1097
    },
    "input-b--verification.json": {
      "sha256": "71315afc113e8bdf63c9ce7a3e46606419049e3168edeb7ac6e15269fa31a8f0",
      "byte_length": 14128
    },
    "input-b--verification.md": {
      "sha256": "8db7b051197ecfacb08f934a066f573598577c2a3a8f18a01c5fe0f676e93962",
      "byte_length": 14562
    }
  }
}
```
