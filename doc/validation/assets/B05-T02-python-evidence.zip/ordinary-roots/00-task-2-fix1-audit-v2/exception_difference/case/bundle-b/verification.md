# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
      "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
      "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
      "version_id": "8142817f-779e-4184-b37d-e9e80b359177",
      "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
      "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "5eee926d-559d-4fe8-ab5b-3a4607741ac5",
          "ordinal": 0,
          "resource_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 295,
        "text": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
    "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
    "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
    "version_id": "8142817f-779e-4184-b37d-e9e80b359177",
    "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
    "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "f2c5fb0abba3108dd7a53712488aaa9749bf4580b424d280e1c56e164d442da1",
        "byte_length": 3061
      },
      "decision.json": {
        "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "d01ec31a1de76e6920468a8907dec35b96ec48ab230973cffe827ca5c404ca05",
        "byte_length": 756
      },
      "review.json": {
        "sha256": "c966519f7f66d75796f73a1269afbe23d265420f0a242fbd7561c8b997750535",
        "byte_length": 510
      }
    },
    "gold_sha256": "d01ec31a1de76e6920468a8907dec35b96ec48ab230973cffe827ca5c404ca05"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
          "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
          "manifest_sha256": null,
          "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
          "parse_id": null,
          "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
          "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
          "version_id": "8142817f-779e-4184-b37d-e9e80b359177"
        },
        "request_id": "synthetic-variants-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
          "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
          "manifest_sha256": null,
          "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
          "parse_id": null,
          "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
          "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
          "version_id": "8142817f-779e-4184-b37d-e9e80b359177"
        },
        "request_id": "synthetic-variants-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 45,
      "end_byte": 215,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 295,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 215,
        "excerpt_sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8",
        "excerpt_start_byte": 45,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 215,
        "quote": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
        "start_byte": 100
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 215,
          "excerpt_sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8",
          "excerpt_start_byte": 45,
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
      "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "11",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "11",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "幼年样本不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "幼年样本不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "幼年样本不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": "幼年样本不适用",
      "actual": {
        "body": [
          "幼年样本不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "幼年样本不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": [
        "幼年样本不适用"
      ],
      "actual": [
        "幼年样本不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 295,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "幼年样本不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "幼年样本不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "f2c5fb0abba3108dd7a53712488aaa9749bf4580b424d280e1c56e164d442da1",
      "byte_length": 3061
    },
    "decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "d01ec31a1de76e6920468a8907dec35b96ec48ab230973cffe827ca5c404ca05",
      "byte_length": 756
    },
    "knowledge-ir.json": {
      "sha256": "e1d8456758e3c398303894c70c6ab4b5feafdf9a48e4c3f04e937822ce8b8fc9",
      "byte_length": 12450
    },
    "review-original.json": {
      "sha256": "c966519f7f66d75796f73a1269afbe23d265420f0a242fbd7561c8b997750535",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "3daf252e0d3092b26d02b7416db7df782ad018bbf0325fcbd3009950038e7345",
      "byte_length": 1187
    }
  }
}
```
