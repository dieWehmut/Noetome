# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
      "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
      "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
      "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883",
      "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
      "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "28791606-70cd-497d-9497-ff592dabeffb",
          "ordinal": 0,
          "resource_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 292,
        "text": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
    "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
    "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
    "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883",
    "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
    "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "43a7a96cbed8ab63cbdf5db31dba16b068c7ed0043480bfc860b95d34b11995d",
        "byte_length": 3052
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
        "byte_length": 747
      },
      "review.json": {
        "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
        "byte_length": 510
      }
    },
    "gold_sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
          "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
          "manifest_sha256": null,
          "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
          "parse_id": null,
          "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
          "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
          "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883"
        },
        "request_id": "synthetic-variants-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
          "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
          "manifest_sha256": null,
          "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
          "parse_id": null,
          "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
          "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
          "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883"
        },
        "request_id": "synthetic-variants-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 45,
      "end_byte": 212,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 292,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 212,
        "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
        "excerpt_start_byte": 45,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 212,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 100
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 212,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "excerpt_start_byte": 45,
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 292,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "43a7a96cbed8ab63cbdf5db31dba16b068c7ed0043480bfc860b95d34b11995d",
      "byte_length": 3052
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "knowledge-ir.json": {
      "sha256": "ec9fbd4175ddaf81337c2ac7933a4769b35f1f4f0964796f17f658e6786a2722",
      "byte_length": 12393
    },
    "review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "da0e273de64446bbd8732d00475eaa3ba69e80a8178261cc93efffeb6df19418",
      "byte_length": 1184
    }
  }
}
```
