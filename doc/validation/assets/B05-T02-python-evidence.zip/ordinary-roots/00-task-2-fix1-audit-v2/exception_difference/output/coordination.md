# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：1；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "5185ed98-18d2-427d-9b3a-421bb7a3dede",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
        "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
        "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
        "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883",
        "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
              "manifest_sha256": null,
              "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "parse_id": null,
              "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
              "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
              "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
              "manifest_sha256": null,
              "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
              "parse_id": null,
              "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
              "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
              "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 45,
          "end_byte": 212,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 292,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 212,
            "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
            "excerpt_start_byte": 45,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 212,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 100
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 212,
              "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
              "excerpt_start_byte": 45,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 292,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "43a7a96cbed8ab63cbdf5db31dba16b068c7ed0043480bfc860b95d34b11995d",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "ec9fbd4175ddaf81337c2ac7933a4769b35f1f4f0964796f17f658e6786a2722",
          "byte_length": 12393
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "da0e273de64446bbd8732d00475eaa3ba69e80a8178261cc93efffeb6df19418",
          "byte_length": 1184
        },
        "verification.json": {
          "sha256": "1d489eaaaf59eafa256eb88a09ba4da824dbc08fe465603b54a4ff96ccd4d590",
          "byte_length": 16993
        },
        "verification.md": {
          "sha256": "733a32db6d50e4f5528b590c0817226111ea05e9621a34a5088abaca0f0c9ff0",
          "byte_length": 17427
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
        "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
        "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
        "version_id": "8142817f-779e-4184-b37d-e9e80b359177",
        "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
              "manifest_sha256": null,
              "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "parse_id": null,
              "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
              "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
              "version_id": "8142817f-779e-4184-b37d-e9e80b359177"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
              "manifest_sha256": null,
              "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
              "parse_id": null,
              "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
              "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
              "version_id": "8142817f-779e-4184-b37d-e9e80b359177"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 45,
          "end_byte": 215,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 295,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 215,
            "excerpt_sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8",
            "excerpt_start_byte": 45,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 215,
            "quote": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
            "start_byte": 100
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 215,
              "excerpt_sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8",
              "excerpt_start_byte": 45,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "actual": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "11",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "11",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": "幼年样本不适用",
          "actual": {
            "body": [
              "幼年样本不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "幼年样本不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": [
            "幼年样本不适用"
          ],
          "actual": [
            "幼年样本不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 295,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "幼年样本不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "幼年样本不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "f2c5fb0abba3108dd7a53712488aaa9749bf4580b424d280e1c56e164d442da1",
          "byte_length": 3061
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "d01ec31a1de76e6920468a8907dec35b96ec48ab230973cffe827ca5c404ca05",
          "byte_length": 756
        },
        "knowledge-ir.json": {
          "sha256": "e1d8456758e3c398303894c70c6ab4b5feafdf9a48e4c3f04e937822ce8b8fc9",
          "byte_length": 12450
        },
        "review-original.json": {
          "sha256": "c966519f7f66d75796f73a1269afbe23d265420f0a242fbd7561c8b997750535",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "3daf252e0d3092b26d02b7416db7df782ad018bbf0325fcbd3009950038e7345",
          "byte_length": 1187
        },
        "verification.json": {
          "sha256": "69f2ed6059736379c67588ecc78ecb5b07b4f18906e54f23d28f4392b41fc936",
          "byte_length": 17044
        },
        "verification.md": {
          "sha256": "4899f81b701e8a95fec6a97c496ac9616344f9d5a33fd9a3c9a0f66d633cc35d",
          "byte_length": 17478
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 45,
        "end_byte": 212,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-17cb45e0b20e7f6ed5b4182772d92098192266c0b7280de00591fec5ecb1167a",
      "input_id": "a",
      "binding": {
        "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
        "import_id": "d79af145-6390-425e-a3ac-4c6600bda8ff",
        "source_id": "ec81aaab-6219-40f3-a438-da823158a329",
        "version_id": "5f58d6e0-fa86-4ba5-9904-c0d7b6679883",
        "content_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "normalized_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "28791606-70cd-497d-9497-ff592dabeffb",
          "ordinal": 0,
          "resource_sha256": "d97667d14cd0b610b3a860c839bb59dbd4ff384338f5b4027b9b066e8bd42994"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 292,
        "text": "公开自造资料 exception_difference/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 45,
          "excerpt_end_byte": 212,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 45,
        "end_byte": 215,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
        "sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8"
      },
      "occurrence_id": "occ-1b15ca5a711aabd05ae29f5f1e8d6fdb35c9ef51ad5ca3debf360b214b850cf6",
      "input_id": "b",
      "binding": {
        "project_id": "153f6022-a36e-4411-a7f4-0df938d9244b",
        "import_id": "3057b8c9-69bc-4640-bfd4-69f38b18fe8c",
        "source_id": "0f3bdc43-3ce6-400e-8636-76a23cb15ada",
        "version_id": "8142817f-779e-4184-b37d-e9e80b359177",
        "content_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "normalized_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "5eee926d-559d-4fe8-ab5b-3a4607741ac5",
          "ordinal": 0,
          "resource_sha256": "eb7da09f8109b6a26f168ed6df3dadb974c5f438fefd3136f4d4741e1e4df952"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 295,
        "text": "公开自造资料 exception_difference/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "幼年样本不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "11",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 45,
          "excerpt_end_byte": 215,
          "excerpt_sha256": "4435607dbe6447608e05a604a3e69b517a67ce8f30582e13b2bb3bbf954d36b8",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为幼年样本不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "11",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "幼年样本不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-3d9b6cb1be4c6856351dcef0e60f859de01fed6d6985d4845f0b5a0425d50b6a",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "11",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "幼年样本不适用"
      ],
      "occurrence_ids": [
        "occ-1b15ca5a711aabd05ae29f5f1e8d6fdb35c9ef51ad5ca3debf360b214b850cf6"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-17cb45e0b20e7f6ed5b4182772d92098192266c0b7280de00591fec5ecb1167a"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-17cb45e0b20e7f6ed5b4182772d92098192266c0b7280de00591fec5ecb1167a",
      "right_occurrence_id": "occ-1b15ca5a711aabd05ae29f5f1e8d6fdb35c9ef51ad5ca3debf360b214b850cf6",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 1,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "b16cb0b118ed38d5c59daaa0861b377362a16059af659a22ec07d5987714278a",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "5b400470042e6a49d7053de5e517d70c6bba38bb584907f92c7394ca4ea09a07",
      "byte_length": 40594
    },
    "coordination-original.json": {
      "sha256": "ac2c8f82af010fcca768f3e1d7222683a49df6e0deffb70ba796616a878550e0",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "16cc42dff84b0eefeedeb193f9ded9b6fa039e291aab08ec47726491b5d5be8d",
      "byte_length": 1905
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "43a7a96cbed8ab63cbdf5db31dba16b068c7ed0043480bfc860b95d34b11995d",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "ec9fbd4175ddaf81337c2ac7933a4769b35f1f4f0964796f17f658e6786a2722",
      "byte_length": 12393
    },
    "input-a--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "da0e273de64446bbd8732d00475eaa3ba69e80a8178261cc93efffeb6df19418",
      "byte_length": 1184
    },
    "input-a--verification.json": {
      "sha256": "1d489eaaaf59eafa256eb88a09ba4da824dbc08fe465603b54a4ff96ccd4d590",
      "byte_length": 16993
    },
    "input-a--verification.md": {
      "sha256": "733a32db6d50e4f5528b590c0817226111ea05e9621a34a5088abaca0f0c9ff0",
      "byte_length": 17427
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "f2c5fb0abba3108dd7a53712488aaa9749bf4580b424d280e1c56e164d442da1",
      "byte_length": 3061
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "d01ec31a1de76e6920468a8907dec35b96ec48ab230973cffe827ca5c404ca05",
      "byte_length": 756
    },
    "input-b--knowledge-ir.json": {
      "sha256": "e1d8456758e3c398303894c70c6ab4b5feafdf9a48e4c3f04e937822ce8b8fc9",
      "byte_length": 12450
    },
    "input-b--review-original.json": {
      "sha256": "c966519f7f66d75796f73a1269afbe23d265420f0a242fbd7561c8b997750535",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "3daf252e0d3092b26d02b7416db7df782ad018bbf0325fcbd3009950038e7345",
      "byte_length": 1187
    },
    "input-b--verification.json": {
      "sha256": "69f2ed6059736379c67588ecc78ecb5b07b4f18906e54f23d28f4392b41fc936",
      "byte_length": 17044
    },
    "input-b--verification.md": {
      "sha256": "4899f81b701e8a95fec6a97c496ac9616344f9d5a33fd9a3c9a0f66d633cc35d",
      "byte_length": 17478
    }
  }
}
```
