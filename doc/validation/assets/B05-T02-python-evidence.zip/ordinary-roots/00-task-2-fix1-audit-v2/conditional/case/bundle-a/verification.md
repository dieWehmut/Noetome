# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "b2a9aa14-3c29-42c4-a821-62bc93b8325e",
      "import_id": "33a4785b-8bb3-45c5-9f95-0850c27bef34",
      "source_id": "dd87d683-1277-4532-8f8d-2cf16f39d7b9",
      "version_id": "d4403f41-c555-4ac5-9090-294d4f9e0f5e",
      "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
      "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "1043da7e-1da1-4326-8104-79892fcde43e",
          "ordinal": 0,
          "resource_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "b2a9aa14-3c29-42c4-a821-62bc93b8325e",
    "import_id": "33a4785b-8bb3-45c5-9f95-0850c27bef34",
    "source_id": "dd87d683-1277-4532-8f8d-2cf16f39d7b9",
    "version_id": "d4403f41-c555-4ac5-9090-294d4f9e0f5e",
    "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
    "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "5fb528d519693981421c7745b4572e32d66cbbec08da043769461d05e882e415",
        "byte_length": 3052
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
        "byte_length": 747
      },
      "review.json": {
        "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
        "byte_length": 510
      }
    },
    "gold_sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
          "import_id": "33a4785b-8bb3-45c5-9f95-0850c27bef34",
          "manifest_sha256": null,
          "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
          "parse_id": null,
          "project_id": "b2a9aa14-3c29-42c4-a821-62bc93b8325e",
          "source_id": "dd87d683-1277-4532-8f8d-2cf16f39d7b9",
          "version_id": "d4403f41-c555-4ac5-9090-294d4f9e0f5e"
        },
        "request_id": "synthetic-variants-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
          "import_id": "33a4785b-8bb3-45c5-9f95-0850c27bef34",
          "manifest_sha256": null,
          "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
          "parse_id": null,
          "project_id": "b2a9aa14-3c29-42c4-a821-62bc93b8325e",
          "source_id": "dd87d683-1277-4532-8f8d-2cf16f39d7b9",
          "version_id": "d4403f41-c555-4ac5-9090-294d4f9e0f5e"
        },
        "request_id": "synthetic-variants-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 36,
      "end_byte": 203,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 283,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 203,
        "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
        "excerpt_start_byte": 36,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 203,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 91
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 203,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "excerpt_start_byte": 36,
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "5fb528d519693981421c7745b4572e32d66cbbec08da043769461d05e882e415",
      "byte_length": 3052
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "knowledge-ir.json": {
      "sha256": "052378216bff54431872b93ae6037818fcbbaffccb9d5bc43d317b35a736b273",
      "byte_length": 12392
    },
    "review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "3c5bf745947d3681eb2695cbd05820f99310abf115a1d18e64d638ca19b72258",
      "byte_length": 1175
    }
  }
}
```
