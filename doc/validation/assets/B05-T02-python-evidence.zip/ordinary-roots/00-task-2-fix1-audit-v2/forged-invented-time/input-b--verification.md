# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "a4dafd1a-393e-4b4d-9517-6cefcda78ff2",
      "import_id": "3b14b4d0-70fb-41f6-a6e4-53b389ee7b76",
      "source_id": "ba06dcf9-af66-4dfc-911a-95f2d9732275",
      "version_id": "82400826-ee07-4476-b725-1c3e8a7172ca",
      "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
      "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4ce99822-ae36-4d23-bb8f-9476674ee663",
          "ordinal": 0,
          "resource_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 277,
        "text": "公开自造资料 history/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "a4dafd1a-393e-4b4d-9517-6cefcda78ff2",
    "import_id": "3b14b4d0-70fb-41f6-a6e4-53b389ee7b76",
    "source_id": "ba06dcf9-af66-4dfc-911a-95f2d9732275",
    "version_id": "82400826-ee07-4476-b725-1c3e8a7172ca",
    "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
    "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "892c75a83fb1ff985edfad34ddaaf6ded5ce2d1fe90a03ab2f81b0867ad30081",
        "byte_length": 3050
      },
      "decision.json": {
        "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
        "byte_length": 747
      },
      "review.json": {
        "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
        "byte_length": 510
      }
    },
    "gold_sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
          "import_id": "3b14b4d0-70fb-41f6-a6e4-53b389ee7b76",
          "manifest_sha256": null,
          "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
          "parse_id": null,
          "project_id": "a4dafd1a-393e-4b4d-9517-6cefcda78ff2",
          "source_id": "ba06dcf9-af66-4dfc-911a-95f2d9732275",
          "version_id": "82400826-ee07-4476-b725-1c3e8a7172ca"
        },
        "request_id": "synthetic-variants-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
          "import_id": "3b14b4d0-70fb-41f6-a6e4-53b389ee7b76",
          "manifest_sha256": null,
          "normalized_sha256": "f8a149b8fb4dd45531b0f74b6257d108cad1650388bf30f5641f480f08c5db5b",
          "parse_id": null,
          "project_id": "a4dafd1a-393e-4b4d-9517-6cefcda78ff2",
          "source_id": "ba06dcf9-af66-4dfc-911a-95f2d9732275",
          "version_id": "82400826-ee07-4476-b725-1c3e8a7172ca"
        },
        "request_id": "synthetic-variants-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 32,
      "end_byte": 197,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 277,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 197,
        "excerpt_sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96",
        "excerpt_start_byte": 32,
        "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 197,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 85
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 197,
          "excerpt_sha256": "d52ca2fbd06455d979adf0b960ce63caeb5bbeb03a335ceb6e2c38aca1c53b96",
          "excerpt_start_byte": 32,
          "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 277,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "892c75a83fb1ff985edfad34ddaaf6ded5ce2d1fe90a03ab2f81b0867ad30081",
      "byte_length": 3050
    },
    "decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "knowledge-ir.json": {
      "sha256": "6ebb3d51cb3f7fc7e7ce01cc148e2ce32cfb946a81bb8c54bf057439ec0923d7",
      "byte_length": 12386
    },
    "review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "bc6290ac2b703aeaf64320bc86d5b80c4f9eadf1f9626e4ac71665117bba5998",
      "byte_length": 1169
    }
  }
}
```
