# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "d232d986-20d2-47c9-97c0-9a2ca0900b67",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
        "import_id": "a52ff15d-ac5f-4296-9ebb-6e1fdfa54dfa",
        "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
        "version_id": "d9f02f2c-743c-407b-bec9-432351b0675b",
        "content_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
        "normalized_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
              "import_id": "a52ff15d-ac5f-4296-9ebb-6e1fdfa54dfa",
              "manifest_sha256": null,
              "normalized_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
              "parse_id": null,
              "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
              "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
              "version_id": "d9f02f2c-743c-407b-bec9-432351b0675b"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
              "import_id": "a52ff15d-ac5f-4296-9ebb-6e1fdfa54dfa",
              "manifest_sha256": null,
              "normalized_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
              "parse_id": null,
              "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
              "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
              "version_id": "d9f02f2c-743c-407b-bec9-432351b0675b"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 44,
          "end_byte": 210,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 290,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 210,
            "excerpt_sha256": "03a488c379b8f3b20a746a1cb3af9c1dcc9464784fb47b8097cb8dcab23d2bc7",
            "excerpt_start_byte": 44,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 210,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 99
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 210,
              "excerpt_sha256": "03a488c379b8f3b20a746a1cb3af9c1dcc9464784fb47b8097cb8dcab23d2bc7",
              "excerpt_start_byte": 44,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 290,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "79c4ca3dfda841025bcc6246da08eb0f08f8bdf6b42352acfc573c873e86e47a",
          "byte_length": 3049
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
          "byte_length": 744
        },
        "knowledge-ir.json": {
          "sha256": "81726ae312bea87c48be227163d300bff033c0b0799bf985a4768b03e4d7032a",
          "byte_length": 12381
        },
        "review-original.json": {
          "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "2b3b98f33dff74008f4f3143614a5d8470af57dede51a91e9a300720efdadf43",
          "byte_length": 1182
        },
        "verification.json": {
          "sha256": "9d468536dd785b554e1a1dca517a6e9b5b2faffcc67b7fc5f1195f49e56a8ba9",
          "byte_length": 16982
        },
        "verification.md": {
          "sha256": "d4003e4bb84eeebdd4a4aa75172475f4ff1f50e0fbb01a3d518852480f50548a",
          "byte_length": 17416
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
        "import_id": "59ecaafd-1d0d-4e10-b402-24184e4513e6",
        "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
        "version_id": "1596b466-1383-4bb2-8d17-fcaa005ef5bf",
        "content_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
        "normalized_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
              "import_id": "59ecaafd-1d0d-4e10-b402-24184e4513e6",
              "manifest_sha256": null,
              "normalized_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
              "parse_id": null,
              "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
              "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
              "version_id": "1596b466-1383-4bb2-8d17-fcaa005ef5bf"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
              "import_id": "59ecaafd-1d0d-4e10-b402-24184e4513e6",
              "manifest_sha256": null,
              "normalized_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
              "parse_id": null,
              "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
              "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
              "version_id": "1596b466-1383-4bb2-8d17-fcaa005ef5bf"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 44,
          "end_byte": 211,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 291,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 211,
            "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
            "excerpt_start_byte": 44,
            "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 211,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 99
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 211,
              "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
              "excerpt_start_byte": 44,
              "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 291,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "2a900191d943e0731346a60dcd65530e830767f6d28c2bc7f31cdc09de2feaab",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "1e996998a535384eb9660bcf6f5245274b814d4a7797acf7ad9a6d614d8a9bbd",
          "byte_length": 12392
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "b8e3956602a1e107d7993619b1b3902d4a0cb6dc21e83eea440e2a8582185284",
          "byte_length": 1183
        },
        "verification.json": {
          "sha256": "6c70231e3f493b331c62d5be35b056c4677ab914b3ff88cc20c295e42dee0758",
          "byte_length": 16991
        },
        "verification.md": {
          "sha256": "9b10966eda6346228126002d7ea4be11e872b269805cde18de1da4e7f5e3373e",
          "byte_length": 17425
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 44,
        "end_byte": 211,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-769c4f22c0e508ab3018fcc9bc888426ab23f6daf6aa7285b1b13bf159311d1b",
      "input_id": "b",
      "binding": {
        "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
        "import_id": "59ecaafd-1d0d-4e10-b402-24184e4513e6",
        "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
        "version_id": "1596b466-1383-4bb2-8d17-fcaa005ef5bf",
        "content_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
        "normalized_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "7147a6ce-e81d-4e3b-b374-6078b7c6a3fa",
          "ordinal": 0,
          "resource_sha256": "e2dbada2f7f93ddb35b93e37814a298ca2f5eb9c0d43330fca1bbcb09522e5f6"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 291,
        "text": "公开自造资料 same_source_undated/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 44,
          "excerpt_end_byte": 211,
          "excerpt_sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 44,
        "end_byte": 210,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "03a488c379b8f3b20a746a1cb3af9c1dcc9464784fb47b8097cb8dcab23d2bc7"
      },
      "occurrence_id": "occ-840c32ba07180bba68769d12adef760f3d85c727d80abc489d9a77eb2757d393",
      "input_id": "a",
      "binding": {
        "project_id": "742ca9a4-d1ff-476a-b1ea-91fdea6253ec",
        "import_id": "a52ff15d-ac5f-4296-9ebb-6e1fdfa54dfa",
        "source_id": "132746e8-8e1a-45af-a0f2-3b46bfdf1cfc",
        "version_id": "d9f02f2c-743c-407b-bec9-432351b0675b",
        "content_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
        "normalized_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "797c9682-0b31-4f9f-a22e-2bf6fcf32b9d",
          "ordinal": 0,
          "resource_sha256": "b4e8f61a8ac2c037f579cf4c1aa564385cb6683a4635650e8c552046b10581f4"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 290,
        "text": "公开自造资料 same_source_undated/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 44,
          "excerpt_end_byte": 210,
          "excerpt_sha256": "03a488c379b8f3b20a746a1cb3af9c1dcc9464784fb47b8097cb8dcab23d2bc7",
          "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-769c4f22c0e508ab3018fcc9bc888426ab23f6daf6aa7285b1b13bf159311d1b"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-9ebe345547619ac95c8e9d4453b9cfec2fa458d8f8eb78c76af5f9ad99a8cccb",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-840c32ba07180bba68769d12adef760f3d85c727d80abc489d9a77eb2757d393"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNHANDLED_VERSION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-769c4f22c0e508ab3018fcc9bc888426ab23f6daf6aa7285b1b13bf159311d1b",
      "right_occurrence_id": "occ-840c32ba07180bba68769d12adef760f3d85c727d80abc489d9a77eb2757d393",
      "relation": "needs_review",
      "issue_code": "COORD_UNHANDLED_VERSION"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 1,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "26718321f45e84a1835b0828db73c4507ef9c860fb3c11d8be917bff790d650e",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "953963803736db745f59725c5caca1a393d36e2746926b23898b38bd98747888",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "16cc42dff84b0eefeedeb193f9ded9b6fa039e291aab08ec47726491b5d5be8d",
      "byte_length": 1905
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "79c4ca3dfda841025bcc6246da08eb0f08f8bdf6b42352acfc573c873e86e47a",
      "byte_length": 3049
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "input-a--knowledge-ir.json": {
      "sha256": "81726ae312bea87c48be227163d300bff033c0b0799bf985a4768b03e4d7032a",
      "byte_length": 12381
    },
    "input-a--review-original.json": {
      "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "2b3b98f33dff74008f4f3143614a5d8470af57dede51a91e9a300720efdadf43",
      "byte_length": 1182
    },
    "input-a--verification.json": {
      "sha256": "9d468536dd785b554e1a1dca517a6e9b5b2faffcc67b7fc5f1195f49e56a8ba9",
      "byte_length": 16982
    },
    "input-a--verification.md": {
      "sha256": "d4003e4bb84eeebdd4a4aa75172475f4ff1f50e0fbb01a3d518852480f50548a",
      "byte_length": 17416
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "2a900191d943e0731346a60dcd65530e830767f6d28c2bc7f31cdc09de2feaab",
      "byte_length": 3052
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "1e996998a535384eb9660bcf6f5245274b814d4a7797acf7ad9a6d614d8a9bbd",
      "byte_length": 12392
    },
    "input-b--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "b8e3956602a1e107d7993619b1b3902d4a0cb6dc21e83eea440e2a8582185284",
      "byte_length": 1183
    },
    "input-b--verification.json": {
      "sha256": "6c70231e3f493b331c62d5be35b056c4677ab914b3ff88cc20c295e42dee0758",
      "byte_length": 16991
    },
    "input-b--verification.md": {
      "sha256": "9b10966eda6346228126002d7ea4be11e872b269805cde18de1da4e7f5e3373e",
      "byte_length": 17425
    }
  }
}
```
