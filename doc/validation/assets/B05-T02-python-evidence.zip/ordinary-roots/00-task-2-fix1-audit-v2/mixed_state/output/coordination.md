# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：1；条件不适用：1；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "04c87442-8534-4509-94e5-eea761742ca4",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
        "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
        "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
        "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585",
        "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
              "manifest_sha256": null,
              "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "parse_id": null,
              "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
              "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
              "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
              "manifest_sha256": null,
              "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
              "parse_id": null,
              "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
              "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
              "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 36,
          "end_byte": 122,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 202,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 122,
            "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
            "excerpt_start_byte": 36,
            "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 122,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 122,
              "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
              "excerpt_start_byte": 36,
              "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "ec8c208b33b43ce75bfa1c93a359c786fc3b30c8960e802e23cdfceb00cd0303",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "eeea2fb66d2caf4671cfd930097842e343b9523c238d77516f930e503cbc6be8",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "2ebc5beec83e6122e2835ddfb07cf0d2f0cb6a510754ddf37537f1aac38bdc94",
          "byte_length": 1094
        },
        "verification.json": {
          "sha256": "afca05c2c0cdd0aa04e221e922b1b1ebedd3f142b35824df473378cf72c01dfb",
          "byte_length": 14125
        },
        "verification.md": {
          "sha256": "216f5a151aaeb0df85723266c8cc8ee3d2e06989e58b8f9ad568013eda2c61fa",
          "byte_length": 14559
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
        "import_id": "7f05ca6d-0947-4ebb-ba3d-dfe2c2f8bbe6",
        "source_id": "56a340ff-de43-48b3-a136-7b4312003de0",
        "version_id": "e76a4b06-a039-4174-8cc2-f2e8e036a54a",
        "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "import_id": "7f05ca6d-0947-4ebb-ba3d-dfe2c2f8bbe6",
              "manifest_sha256": null,
              "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "parse_id": null,
              "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
              "source_id": "56a340ff-de43-48b3-a136-7b4312003de0",
              "version_id": "e76a4b06-a039-4174-8cc2-f2e8e036a54a"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "import_id": "7f05ca6d-0947-4ebb-ba3d-dfe2c2f8bbe6",
              "manifest_sha256": null,
              "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
              "parse_id": null,
              "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
              "source_id": "56a340ff-de43-48b3-a136-7b4312003de0",
              "version_id": "e76a4b06-a039-4174-8cc2-f2e8e036a54a"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 36,
          "end_byte": 122,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 202,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 122,
            "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
            "excerpt_start_byte": 36,
            "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 122,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 122,
              "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
              "excerpt_start_byte": 36,
              "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 202,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "16f6f9e7711d18750a9ae6d11ec3110a7ba73fb6eee328275674dbd4f01f3630",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "4a0d980c997e11f21272b0c4fe87589da738c5fbad36a84df948b5ddd1c3f77c",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "2d45c56cb101e9bdb74efe4a14029128268283d003e7d0508f53119570a7e11f",
          "byte_length": 1094
        },
        "verification.json": {
          "sha256": "e92c5f9a47f019ecce21cf1a70d5cd25db5fa11c7d228bbeece55d55b3bcff43",
          "byte_length": 14125
        },
        "verification.md": {
          "sha256": "9169208764f6e6bc625219dcd8635b054b2808beb8e7afe1dec6992284092e42",
          "byte_length": 14559
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 122,
        "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c"
      },
      "occurrence_id": "occ-509c6e8bfa66d1fb345467b036dcb9b4b77660466f972ecb5c270438935a2840",
      "input_id": "a",
      "binding": {
        "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
        "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
        "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
        "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585",
        "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4d06affd-b6ab-445f-a1f2-711575a7773f",
          "ordinal": 0,
          "resource_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 202,
        "text": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 36,
          "excerpt_end_byte": 122,
          "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
          "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 122,
        "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf"
      },
      "occurrence_id": "occ-d83a719e4b1925c7b334b9439aef698590ffd1582f7416fc3cbc88c8c5a4899e",
      "input_id": "b",
      "binding": {
        "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
        "import_id": "7f05ca6d-0947-4ebb-ba3d-dfe2c2f8bbe6",
        "source_id": "56a340ff-de43-48b3-a136-7b4312003de0",
        "version_id": "e76a4b06-a039-4174-8cc2-f2e8e036a54a",
        "content_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "normalized_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "649de686-c73a-4ec3-b2fb-f74f0d48a785",
          "ordinal": 0,
          "resource_sha256": "a78dbb54f3da179af371bca0ba2207a81ebd2ce9ca5145b9f3d69a1c336cfd25"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 202,
        "text": "公开自造资料 mixed_state/b。\n适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 36,
          "excerpt_end_byte": 122,
          "excerpt_sha256": "75c281fda9af8e087ee00055f041e486b6037e8aacd15014fa3c32c3400be4bf",
          "quote": "适用条件：不适用；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-1da6d05004f6bd481c6bb96052d871827dae806e88b506031ed6e8ce82b887f3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-d83a719e4b1925c7b334b9439aef698590ffd1582f7416fc3cbc88c8c5a4899e"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-6d5eb47cae5b4f0839f4eaa589754fc9b88e5990f6cbf178896b09857a8d7ae1",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-509c6e8bfa66d1fb345467b036dcb9b4b77660466f972ecb5c270438935a2840"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-509c6e8bfa66d1fb345467b036dcb9b4b77660466f972ecb5c270438935a2840",
      "right_occurrence_id": "occ-d83a719e4b1925c7b334b9439aef698590ffd1582f7416fc3cbc88c8c5a4899e",
      "relation": "needs_review",
      "issue_code": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "5ad30aee111f43aa30fbf977bb11f4a3faf85a9f1f0b8205ec4144c578ec82e0",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "615da743a80a04ceb10c6173bb20203292650ba28606edf89bc3cd965978ed0c",
      "byte_length": 4327
    },
    "identity-original.json": {
      "sha256": "69d877a4e4ad2cc807060a8b52ee0513184613e9a079df57bb6deef04270e04f",
      "byte_length": 1916
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "ec8c208b33b43ce75bfa1c93a359c786fc3b30c8960e802e23cdfceb00cd0303",
      "byte_length": 2710
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "eeea2fb66d2caf4671cfd930097842e343b9523c238d77516f930e503cbc6be8",
      "byte_length": 9270
    },
    "input-a--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "2ebc5beec83e6122e2835ddfb07cf0d2f0cb6a510754ddf37537f1aac38bdc94",
      "byte_length": 1094
    },
    "input-a--verification.json": {
      "sha256": "afca05c2c0cdd0aa04e221e922b1b1ebedd3f142b35824df473378cf72c01dfb",
      "byte_length": 14125
    },
    "input-a--verification.md": {
      "sha256": "216f5a151aaeb0df85723266c8cc8ee3d2e06989e58b8f9ad568013eda2c61fa",
      "byte_length": 14559
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "16f6f9e7711d18750a9ae6d11ec3110a7ba73fb6eee328275674dbd4f01f3630",
      "byte_length": 2710
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-b--knowledge-ir.json": {
      "sha256": "4a0d980c997e11f21272b0c4fe87589da738c5fbad36a84df948b5ddd1c3f77c",
      "byte_length": 9270
    },
    "input-b--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "2d45c56cb101e9bdb74efe4a14029128268283d003e7d0508f53119570a7e11f",
      "byte_length": 1094
    },
    "input-b--verification.json": {
      "sha256": "e92c5f9a47f019ecce21cf1a70d5cd25db5fa11c7d228bbeece55d55b3bcff43",
      "byte_length": 14125
    },
    "input-b--verification.md": {
      "sha256": "9169208764f6e6bc625219dcd8635b054b2808beb8e7afe1dec6992284092e42",
      "byte_length": 14559
    }
  }
}
```
