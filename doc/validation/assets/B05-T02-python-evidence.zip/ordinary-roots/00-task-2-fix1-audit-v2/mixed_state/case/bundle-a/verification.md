# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
      "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
      "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
      "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585",
      "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
      "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "4d06affd-b6ab-445f-a1f2-711575a7773f",
          "ordinal": 0,
          "resource_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 202,
        "text": "公开自造资料 mixed_state/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
    "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
    "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
    "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585",
    "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
    "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "ec8c208b33b43ce75bfa1c93a359c786fc3b30c8960e802e23cdfceb00cd0303",
        "byte_length": 2710
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
        "byte_length": 503
      },
      "review.json": {
        "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
        "byte_length": 510
      }
    },
    "gold_sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
          "manifest_sha256": null,
          "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "parse_id": null,
          "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
          "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
          "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585"
        },
        "request_id": "synthetic-variants-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "import_id": "a5e29c2c-56f2-408d-b0bb-8c6b99a5eb6f",
          "manifest_sha256": null,
          "normalized_sha256": "34ad58a1af63a0e247c508a0dbeeecfe8cc8353495ebf8bef4d955a86a4d70c5",
          "parse_id": null,
          "project_id": "dc79f10a-07f1-46a3-a4a0-5eeda407d582",
          "source_id": "7bc4c228-f826-411f-8db2-7430d5fd3f00",
          "version_id": "3f639a1e-bff7-40d4-87d9-b7bdf3a04585"
        },
        "request_id": "synthetic-variants-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 36,
      "end_byte": 122,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 202,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 122,
        "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
        "excerpt_start_byte": 36,
        "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 122,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 91
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 122,
          "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
          "excerpt_start_byte": 36,
          "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 202,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "ec8c208b33b43ce75bfa1c93a359c786fc3b30c8960e802e23cdfceb00cd0303",
      "byte_length": 2710
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "knowledge-ir.json": {
      "sha256": "eeea2fb66d2caf4671cfd930097842e343b9523c238d77516f930e503cbc6be8",
      "byte_length": 9270
    },
    "review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "2ebc5beec83e6122e2835ddfb07cf0d2f0cb6a510754ddf37537f1aac38bdc94",
      "byte_length": 1094
    }
  }
}
```
