# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：1。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "31293790-90b0-4a31-ae3e-66cd6ba70394",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
        "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
        "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
        "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15",
        "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
              "manifest_sha256": null,
              "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "parse_id": null,
              "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
              "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
              "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
              "manifest_sha256": null,
              "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
              "parse_id": null,
              "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
              "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
              "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 36,
          "end_byte": 203,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 203,
            "excerpt_sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b",
            "excerpt_start_byte": 36,
            "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 92
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 203,
              "excerpt_sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b",
              "excerpt_start_byte": 36,
              "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "d220058a3fab376fd9f682dca770343516628bb5eb4b00c3bbd8360e0d493def",
          "byte_length": 3050
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
          "byte_length": 744
        },
        "knowledge-ir.json": {
          "sha256": "24ad286748c21a3ffd5a642a30d8a867a6f5c3a3f7c6b4b98a686627d83b455b",
          "byte_length": 12384
        },
        "review-original.json": {
          "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "19db0ad14091f035b337201f5f7092af06cbf6dd8ce60f2a3f8df459dcd4b4e4",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "dd0f9f512e544bc06e0f3fbb23bfecf3e99e221d5c3d1c86c6eedf859ec96363",
          "byte_length": 16977
        },
        "verification.md": {
          "sha256": "5073c3ceb2da09b6bd76988c59d7d3b54feab69dbf04139c6600a2a5aff6bff9",
          "byte_length": 17411
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
        "import_id": "5209148e-b32d-4cc9-8fcf-62cef78531b0",
        "source_id": "90a54796-d814-4e3f-8f1b-7d4ff78c6533",
        "version_id": "fcafd036-eeee-40b5-bf44-bedccfc14fc3",
        "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "import_id": "5209148e-b32d-4cc9-8fcf-62cef78531b0",
              "manifest_sha256": null,
              "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "parse_id": null,
              "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
              "source_id": "90a54796-d814-4e3f-8f1b-7d4ff78c6533",
              "version_id": "fcafd036-eeee-40b5-bf44-bedccfc14fc3"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "import_id": "5209148e-b32d-4cc9-8fcf-62cef78531b0",
              "manifest_sha256": null,
              "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
              "parse_id": null,
              "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
              "source_id": "90a54796-d814-4e3f-8f1b-7d4ff78c6533",
              "version_id": "fcafd036-eeee-40b5-bf44-bedccfc14fc3"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 36,
          "end_byte": 204,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 284,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 204,
            "excerpt_sha256": "e0f58b7cf2d5799bea0bd74cc1c2ed6f659bcf5a4ae7e0d3c9966d10450a922e",
            "excerpt_start_byte": 36,
            "quote": "适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 204,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 92
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 204,
              "excerpt_sha256": "e0f58b7cf2d5799bea0bd74cc1c2ed6f659bcf5a4ae7e0d3c9966d10450a922e",
              "excerpt_start_byte": 36,
              "quote": "适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "a1ca42bf0c39e67dc304ec9fdb3558d68ee21c4782b6eb85e4315ea060695cd9",
          "byte_length": 3053
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "443e8504b11058c635cb7343f0c58ee0089123dcc3ab716343d8d659df7f5ae3",
          "byte_length": 12395
        },
        "review-original.json": {
          "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "83bb9ea8be316e0e5b30344467e3bd108b7e2bcbb79489e2b414d0e3794e1edb",
          "byte_length": 1176
        },
        "verification.json": {
          "sha256": "96b3d9e8145c752310d613eee29fe165fb0638b2639609f9b77cbdad9c1dd2dc",
          "byte_length": 16986
        },
        "verification.md": {
          "sha256": "0e4d0cc32f48016b0b058323fea830ad0291d61be37ff663be87827f41845b48",
          "byte_length": 17420
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "day",
          "value": "2021-03-01"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 204,
        "quote": "适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "e0f58b7cf2d5799bea0bd74cc1c2ed6f659bcf5a4ae7e0d3c9966d10450a922e"
      },
      "occurrence_id": "occ-48a9266b288ed93a9346e2ee8ae1f0ff25c52276d6c211b6296043d3ffcaaa91",
      "input_id": "b",
      "binding": {
        "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
        "import_id": "5209148e-b32d-4cc9-8fcf-62cef78531b0",
        "source_id": "90a54796-d814-4e3f-8f1b-7d4ff78c6533",
        "version_id": "fcafd036-eeee-40b5-bf44-bedccfc14fc3",
        "content_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "normalized_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "de230376-8a7c-4b19-b056-b9589421b1b1",
          "ordinal": 0,
          "resource_sha256": "4d961357f78bf3bd4b124a26b72093cc09e884da8cc8d59b93c053b81ee393e6"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 284,
        "text": "公开自造资料 history_day/b。\n适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 36,
          "excerpt_end_byte": 204,
          "excerpt_sha256": "e0f58b7cf2d5799bea0bd74cc1c2ed6f659bcf5a4ae7e0d3c9966d10450a922e",
          "quote": "适用条件：已列明；观点时间：2021-03-01。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "day",
          "value": "2020-02-29"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b"
      },
      "occurrence_id": "occ-e870043eb322a7db273371b6590f8986de3f4e7935b1950c1f65988051f4b83e",
      "input_id": "a",
      "binding": {
        "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
        "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
        "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
        "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15",
        "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "fbff0dca-841a-4bff-ae48-e82289d21750",
          "ordinal": 0,
          "resource_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 history_day/a。\n适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 36,
          "excerpt_end_byte": 203,
          "excerpt_sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b",
          "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "day",
        "value": "2021-03-01"
      },
      "fact_id": "fact-v2-f33d043cd3c17059f036b14656b66ca72da724b38df13e7c1a7e3c960fb9e39e",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-48a9266b288ed93a9346e2ee8ae1f0ff25c52276d6c211b6296043d3ffcaaa91"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "day",
        "value": "2020-02-29"
      },
      "fact_id": "fact-v2-fb0ac5504b823990db44b646e73c5e6dda2c3305677f280783ea1a2914136ae3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-e870043eb322a7db273371b6590f8986de3f4e7935b1950c1f65988051f4b83e"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": "occ-e870043eb322a7db273371b6590f8986de3f4e7935b1950c1f65988051f4b83e",
      "later_occurrence_id": "occ-48a9266b288ed93a9346e2ee8ae1f0ff25c52276d6c211b6296043d3ffcaaa91",
      "left_occurrence_id": "occ-48a9266b288ed93a9346e2ee8ae1f0ff25c52276d6c211b6296043d3ffcaaa91",
      "right_occurrence_id": "occ-e870043eb322a7db273371b6590f8986de3f4e7935b1950c1f65988051f4b83e",
      "relation": "historical_evolution",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 1,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "898ab83727fcfb18de60475d9d24e6d99133dd8150a8885a8d957290bb0fa5fe",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "0e2781ac866bb1dea1da0da7e68a01b45e356f7e18c51a02bdd3af783c7f25aa",
      "byte_length": 40663
    },
    "coordination-original.json": {
      "sha256": "ce79d1d8c1e6d98cc3c684a1f2958c2abcbed19be13b1d4519e7c80b74c35f8d",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "78f3a262fa21f5e94d8e4b849871a1907c9578fa01c1bab481c4599068f965a9",
      "byte_length": 1919
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "d220058a3fab376fd9f682dca770343516628bb5eb4b00c3bbd8360e0d493def",
      "byte_length": 3050
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "input-a--knowledge-ir.json": {
      "sha256": "24ad286748c21a3ffd5a642a30d8a867a6f5c3a3f7c6b4b98a686627d83b455b",
      "byte_length": 12384
    },
    "input-a--review-original.json": {
      "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "19db0ad14091f035b337201f5f7092af06cbf6dd8ce60f2a3f8df459dcd4b4e4",
      "byte_length": 1175
    },
    "input-a--verification.json": {
      "sha256": "dd0f9f512e544bc06e0f3fbb23bfecf3e99e221d5c3d1c86c6eedf859ec96363",
      "byte_length": 16977
    },
    "input-a--verification.md": {
      "sha256": "5073c3ceb2da09b6bd76988c59d7d3b54feab69dbf04139c6600a2a5aff6bff9",
      "byte_length": 17411
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "a1ca42bf0c39e67dc304ec9fdb3558d68ee21c4782b6eb85e4315ea060695cd9",
      "byte_length": 3053
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "71d3b3847fd08f2cdbb808109fb08a93606c55b047c09e7c8213501f308b9336",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "443e8504b11058c635cb7343f0c58ee0089123dcc3ab716343d8d659df7f5ae3",
      "byte_length": 12395
    },
    "input-b--review-original.json": {
      "sha256": "f469db99fe2c7761bde3deb56f9a9a3ff7d886a1d6ec522bd6efdcb4ad7918b4",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "83bb9ea8be316e0e5b30344467e3bd108b7e2bcbb79489e2b414d0e3794e1edb",
      "byte_length": 1176
    },
    "input-b--verification.json": {
      "sha256": "96b3d9e8145c752310d613eee29fe165fb0638b2639609f9b77cbdad9c1dd2dc",
      "byte_length": 16986
    },
    "input-b--verification.md": {
      "sha256": "0e4d0cc32f48016b0b058323fea830ad0291d61be37ff663be87827f41845b48",
      "byte_length": 17420
    }
  }
}
```
