# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
      "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
      "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
      "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15",
      "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
      "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "fbff0dca-841a-4bff-ae48-e82289d21750",
          "ordinal": 0,
          "resource_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 history_day/a。\n适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
    "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
    "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
    "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15",
    "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
    "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "d220058a3fab376fd9f682dca770343516628bb5eb4b00c3bbd8360e0d493def",
        "byte_length": 3050
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
        "byte_length": 744
      },
      "review.json": {
        "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
        "byte_length": 510
      }
    },
    "gold_sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
          "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
          "manifest_sha256": null,
          "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
          "parse_id": null,
          "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
          "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
          "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15"
        },
        "request_id": "synthetic-variants-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
          "import_id": "0a175e2c-3046-44b3-b260-f3c9c4fa24b5",
          "manifest_sha256": null,
          "normalized_sha256": "046bac8821a0181af47249fc0f13fe6ed7b1bc7aa87fc8b5eebe4acff946e0dd",
          "parse_id": null,
          "project_id": "5d7863ee-275e-4489-8fbc-c27fc81e0c9d",
          "source_id": "1930136e-71a0-4618-8e3a-2681fc933cfe",
          "version_id": "de3f22ef-c3b9-4c1e-8c12-6d0a53bf7a15"
        },
        "request_id": "synthetic-variants-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 36,
      "end_byte": 203,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 283,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 203,
        "excerpt_sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b",
        "excerpt_start_byte": 36,
        "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 203,
        "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 92
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 203,
          "excerpt_sha256": "9c2b1f5fa60e6dec4803e60c5fee29949abaccadd99e5542e9205adf3e37ae3b",
          "excerpt_start_byte": 36,
          "quote": "适用条件：已列明；观点时间：2020-02-29。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "8",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "8",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 283,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "d220058a3fab376fd9f682dca770343516628bb5eb4b00c3bbd8360e0d493def",
      "byte_length": 3050
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "ab82709193f0e12388d64c8729e80650f65ed1c982e2af8f9eab57c4a1942548",
      "byte_length": 744
    },
    "knowledge-ir.json": {
      "sha256": "24ad286748c21a3ffd5a642a30d8a867a6f5c3a3f7c6b4b98a686627d83b455b",
      "byte_length": 12384
    },
    "review-original.json": {
      "sha256": "462de2e0f0feefb2ab92b89a395d5cdb8f816300173f4b29a6fd8de866dfdffd",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "19db0ad14091f035b337201f5f7092af06cbf6dd8ce60f2a3f8df459dcd4b4e4",
      "byte_length": 1175
    }
  }
}
```
