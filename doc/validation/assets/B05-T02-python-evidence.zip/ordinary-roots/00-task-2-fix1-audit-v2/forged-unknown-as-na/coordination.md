# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：2；条件不适用：0；时间已知：0；时间未知：2；条件并列关系：0；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "318a8666-6726-4747-a6cf-2437145f61b5",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
        "import_id": "89281381-4975-4f08-8080-25571d1d274b",
        "source_id": "063779d3-73db-4e93-8f84-e2ad737a45e0",
        "version_id": "ece7d865-853c-4ad6-930f-5875b1d62c6c",
        "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
        "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
              "import_id": "89281381-4975-4f08-8080-25571d1d274b",
              "manifest_sha256": null,
              "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
              "parse_id": null,
              "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
              "source_id": "063779d3-73db-4e93-8f84-e2ad737a45e0",
              "version_id": "ece7d865-853c-4ad6-930f-5875b1d62c6c"
            },
            "request_id": "synthetic-variants-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
              "import_id": "89281381-4975-4f08-8080-25571d1d274b",
              "manifest_sha256": null,
              "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
              "parse_id": null,
              "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
              "source_id": "063779d3-73db-4e93-8f84-e2ad737a45e0",
              "version_id": "ece7d865-853c-4ad6-930f-5875b1d62c6c"
            },
            "request_id": "synthetic-variants-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 42,
          "end_byte": 128,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 208,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 128,
            "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
            "excerpt_start_byte": 42,
            "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 128,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 97
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 128,
              "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
              "excerpt_start_byte": 42,
              "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "7a6ddc66d113976a40c4af3573cd38d10302b3d856c6b62453d82f22c2c12420",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "2ef740ea50bcaf526ad3d5a10bf3a11c639f00483e763c275a1aab9556961a87",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "db98375d59c526a47a95ba6d82ab0b408432b218e18407bda92de49955f1c9db",
          "byte_length": 1100
        },
        "verification.json": {
          "sha256": "c51126f2bccf10440424b6cc5a094e14e351da1f3b3d1ea31d073c854862ea84",
          "byte_length": 14131
        },
        "verification.md": {
          "sha256": "549b9bc5e1cd9885c5187c84e7e24c76ef6304d1fbdefbd172a99ce6affe0b44",
          "byte_length": 14565
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
        "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
        "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
        "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181",
        "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
        "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-variants-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
              "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
              "manifest_sha256": null,
              "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
              "parse_id": null,
              "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
              "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
              "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181"
            },
            "request_id": "synthetic-variants-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
              "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
              "manifest_sha256": null,
              "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
              "parse_id": null,
              "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
              "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
              "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181"
            },
            "request_id": "synthetic-variants-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 42,
          "end_byte": 128,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 208,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 128,
            "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
            "excerpt_start_byte": 42,
            "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 128,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 97
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 128,
              "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
              "excerpt_start_byte": 42,
              "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 208,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
          "byte_length": 138
        },
        "candidates-original.json": {
          "sha256": "d7cc7daf4a528dbf4e41dd037c3c7c21c2532e1e92e2a7790dc56e778eeb05f2",
          "byte_length": 2710
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "6a23b5286ca5cbff900ec8d73920675408a81b2522b1087bffeb6754c00667fc",
          "byte_length": 9270
        },
        "review-original.json": {
          "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "b819b93d63dd711eee0ceeb00dbf1720c02b7cd8ef720e032da82dd652e31b9e",
          "byte_length": 1100
        },
        "verification.json": {
          "sha256": "a9a582927d37df8b80209f01196d297c55844f83a77b3e884f0787cf20089f8a",
          "byte_length": 14131
        },
        "verification.md": {
          "sha256": "16ff4e42c31039e884ca9ecc9159d02d7a10abb49e58a873b40c5405f0c53b0e",
          "byte_length": 14565
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 42,
        "end_byte": 128,
        "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c"
      },
      "occurrence_id": "occ-09b5d36e1b6e5d135c53340af428db28d6c5a4161ba44e9555abc46d10add90e",
      "input_id": "a",
      "binding": {
        "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
        "import_id": "89281381-4975-4f08-8080-25571d1d274b",
        "source_id": "063779d3-73db-4e93-8f84-e2ad737a45e0",
        "version_id": "ece7d865-853c-4ad6-930f-5875b1d62c6c",
        "content_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
        "normalized_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "6812b609-66ac-4dad-a1f1-db1160f8fad2",
          "ordinal": 0,
          "resource_sha256": "938b54a42c75591ce286303aced11cb0bbac15184e66d248b8e8f96ae93101c5"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 208,
        "text": "公开自造资料 unknown_condition/a。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 42,
          "excerpt_end_byte": 128,
          "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
          "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 42,
        "end_byte": 128,
        "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c"
      },
      "occurrence_id": "occ-19d4dfbe17ad8a381f2e0bea46deae50c91340eb8ee42af414817f31a57daa63",
      "input_id": "b",
      "binding": {
        "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
        "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
        "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
        "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181",
        "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
        "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a93cef9e-0d2b-4eba-84cd-0884d3c3f4e3",
          "ordinal": 0,
          "resource_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 208,
        "text": "公开自造资料 unknown_condition/b。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 42,
          "excerpt_end_byte": 128,
          "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
          "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-1da6d05004f6bd481c6bb96052d871827dae806e88b506031ed6e8ce82b887f3",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-09b5d36e1b6e5d135c53340af428db28d6c5a4161ba44e9555abc46d10add90e"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-5f5fca90c42750af0f20bb3caff469c1e72eeb6a82ba41248def3b4de35d0321",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-19d4dfbe17ad8a381f2e0bea46deae50c91340eb8ee42af414817f31a57daa63"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-09b5d36e1b6e5d135c53340af428db28d6c5a4161ba44e9555abc46d10add90e",
      "right_occurrence_id": "occ-19d4dfbe17ad8a381f2e0bea46deae50c91340eb8ee42af414817f31a57daa63",
      "relation": "needs_review",
      "issue_code": "COORD_UNKNOWN_CONDITION"
    }
  ],
  "totals": {
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 2,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 2,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 0,
    "failed": 0,
    "needs_review": 2,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "1bfd7dd549b0f33c825c325ffc2cae6bf6f3942de4b4ba7736fa2615c82566e4",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "94da4bd7262253ee4d3233941c3d7890bf0a4a4b5174a6245f00f68bae31fe0e",
      "byte_length": 4327
    },
    "identity-original.json": {
      "sha256": "f93cf14ed96725d014e78d055f2d123d84b2e944ac7a191d49aa77849478257c",
      "byte_length": 1909
    },
    "input-a--.owner.json": {
      "sha256": "cfb6d0ee8910f51062570e45e2e0c88267447ac7397f1fb4060f02d631d07c38",
      "byte_length": 138
    },
    "input-a--candidates-original.json": {
      "sha256": "7a6ddc66d113976a40c4af3573cd38d10302b3d856c6b62453d82f22c2c12420",
      "byte_length": 2710
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "2ef740ea50bcaf526ad3d5a10bf3a11c639f00483e763c275a1aab9556961a87",
      "byte_length": 9270
    },
    "input-a--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "db98375d59c526a47a95ba6d82ab0b408432b218e18407bda92de49955f1c9db",
      "byte_length": 1100
    },
    "input-a--verification.json": {
      "sha256": "c51126f2bccf10440424b6cc5a094e14e351da1f3b3d1ea31d073c854862ea84",
      "byte_length": 14131
    },
    "input-a--verification.md": {
      "sha256": "549b9bc5e1cd9885c5187c84e7e24c76ef6304d1fbdefbd172a99ce6affe0b44",
      "byte_length": 14565
    },
    "input-b--.owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "input-b--candidates-original.json": {
      "sha256": "d7cc7daf4a528dbf4e41dd037c3c7c21c2532e1e92e2a7790dc56e778eeb05f2",
      "byte_length": 2710
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "input-b--knowledge-ir.json": {
      "sha256": "6a23b5286ca5cbff900ec8d73920675408a81b2522b1087bffeb6754c00667fc",
      "byte_length": 9270
    },
    "input-b--review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "b819b93d63dd711eee0ceeb00dbf1720c02b7cd8ef720e032da82dd652e31b9e",
      "byte_length": 1100
    },
    "input-b--verification.json": {
      "sha256": "a9a582927d37df8b80209f01196d297c55844f83a77b3e884f0787cf20089f8a",
      "byte_length": 14131
    },
    "input-b--verification.md": {
      "sha256": "16ff4e42c31039e884ca9ecc9159d02d7a10abb49e58a873b40c5405f0c53b0e",
      "byte_length": 14565
    }
  }
}
```
