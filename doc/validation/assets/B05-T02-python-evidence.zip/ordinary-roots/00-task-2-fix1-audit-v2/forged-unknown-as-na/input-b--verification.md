# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-variants-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
      "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
      "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
      "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181",
      "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
      "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a93cef9e-0d2b-4eba-84cd-0884d3c3f4e3",
          "ordinal": 0,
          "resource_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 208,
        "text": "公开自造资料 unknown_condition/b。\n适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
    "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
    "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
    "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181",
    "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
    "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "d7cc7daf4a528dbf4e41dd037c3c7c21c2532e1e92e2a7790dc56e778eeb05f2",
        "byte_length": 2710
      },
      "decision.json": {
        "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
        "byte_length": 503
      },
      "review.json": {
        "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
        "byte_length": 510
      }
    },
    "gold_sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
          "manifest_sha256": null,
          "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "parse_id": null,
          "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
          "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
          "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181"
        },
        "request_id": "synthetic-variants-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "import_id": "74cd250d-b5e3-4387-8478-680a24d81bd0",
          "manifest_sha256": null,
          "normalized_sha256": "c0bf5ccd1e89bfe483fa5a9d4c34713a3c0ebad05ab88f92a13904be0f49e950",
          "parse_id": null,
          "project_id": "2ea93418-b0cb-4943-a8a7-bfaa14a553ff",
          "source_id": "a4ae3f81-9233-4983-8143-39742e86c2a8",
          "version_id": "f6b940d0-e85b-4680-8bfc-b1c8479a0181"
        },
        "request_id": "synthetic-variants-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 42,
      "end_byte": 128,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 208,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 128,
        "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
        "excerpt_start_byte": 42,
        "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 128,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 97
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 128,
          "excerpt_sha256": "0da57d7468605d96fba52a10e44862e08bc100812024db2e8fc2ac8f9fad549c",
          "excerpt_start_byte": 42,
          "quote": "适用条件：未给出；观点时间：未给出。\n样例 A 的速度为 10 m/s。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 208,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "cb8805a7fb66dc9bd9c091ca2632fe527b7271a6c664ad182b5f07b1d6efa948",
      "byte_length": 138
    },
    "candidates-original.json": {
      "sha256": "d7cc7daf4a528dbf4e41dd037c3c7c21c2532e1e92e2a7790dc56e778eeb05f2",
      "byte_length": 2710
    },
    "decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "74ebc19839adf2b770338bbdd442d73f931e612a45cca368a87da5a3b7fb15bc",
      "byte_length": 503
    },
    "knowledge-ir.json": {
      "sha256": "6a23b5286ca5cbff900ec8d73920675408a81b2522b1087bffeb6754c00667fc",
      "byte_length": 9270
    },
    "review-original.json": {
      "sha256": "02c3a1659e4da6597d40c2cdd6fe3f0607933f15dacd3720e92eb396787f5050",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "b819b93d63dd711eee0ceeb00dbf1720c02b7cd8ef720e032da82dd652e31b9e",
      "byte_length": 1100
    }
  }
}
```
