import json
import hashlib
from pathlib import Path
import subprocess

repo=Path('D:/Noetome'); plan=Path(__file__).resolve().parent
def fp(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def load(path):
    return json.loads(path.read_bytes())
commands={}
for name in ('task-2-fix1-red','task-2-fix1-green','task-2-fix1-python','task-2-fix1-audit-v2-command'):
    r=load(plan/(name+'.json'))
    assert r['exit_code']==(1 if name.endswith('-red') else 0),name
    assert r['before']==r['after'],name
    for field in ('stdout','stderr'):
        pin=r[field]; assert fp(Path(pin['path']).read_bytes())=={k:pin[k] for k in ('sha256','byte_length')}
    commands[name]=dict(exit_code=r['exit_code'],elapsed_seconds=r['elapsed_seconds'],source_count=len(r['after']),streams_verified=True)
task1=load(plan/'task-1-resume-verification.json')
for path,pin in task1['before'].items():
    assert fp(Path(path).read_bytes())==pin,path
assert fp((repo/'target/debug/noetome.exe').read_bytes())==task1['cli']
audit=load(plan/'task-2-fix1-audit-v2/audit.json')
assert audit['protected_before']==audit['protected_after']
assert audit['source_before']==audit['source_after']
for call in audit['calls']:
    assert call['exit_code']==call['expected_exit']
    for field in ('stdout','stderr'):
        pin=call[field]; assert fp(Path(pin['path']).read_bytes())=={k:pin[k] for k in ('sha256','byte_length')}
folder=plan/'task-2-fix1-audit-v2/shared-original-atom-id'
gold=(folder/'gold.json').read_bytes()
assert fp(gold)==load(folder/'expected-pin.json')
assert load(folder/'frozen-authors/author.json')['expected']==json.loads(gold)
assert json.loads(gold)['facts'][0]['original_atom_ids']==['a-speed','a-speed']
report=load(folder/'output/coordination.json')
assert len(set(o['occurrence_id'] for o in report['occurrences']))==2
assert all(o['original_atom']['atom']['atom_id']=='a-speed' for o in report['occurrences'])
owned=('scripts/verify_knowledge_variants.py','scripts/knowledge_variants_audit.py','tests/test_knowledge_variants_verifier.py')
old=subprocess.run(['git','diff','--exit-code','4f0940bb82e34c83b531e91985ac6c9368d3eb84','--','scripts/verify_knowledge_coordination.py','crates','Cargo.toml','Cargo.lock'],cwd=repo,capture_output=True)
assert old.returncode==0 and not old.stdout
result=dict(commands=commands,cli=task1['cli'],rust_reused_source_count=len(task1['before']),old_default_and_rust_unchanged=True,
    audit_scenarios=audit['scenario_count'],audit_commands=len(audit['calls']),shared_expected_pin=fp(gold),
    shared_occurrence_ids=[o['occurrence_id'] for o in report['occurrences']],owned_pins={p:fp((repo/p).read_bytes()) for p in owned})
(plan/'task-2-fix1-inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
