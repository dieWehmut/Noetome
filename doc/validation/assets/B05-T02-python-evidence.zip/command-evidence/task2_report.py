import json
from pathlib import Path
import re

plan=Path(__file__).resolve().parent
inspection=json.loads((plan/'task-2-final-inspection.json').read_bytes())
rows=[]
for name,label in [('task-2-final-object-routing-corrected','Focused v2, 12/12'),('task-2-old-focused','Focused unchanged v1, 35/35'),
                   ('task-2-python-stable','Full stable Python, 155/155'),('task-2-audit-v2-stable-command','Ordinary audit-v2, 41 scenarios/119 CLI calls'),
                   ('task-2-audit-old-stable-command','Ordinary old audit, 33 scenarios/56 CLI calls'),
                   ('task-2-unit-false-group-command','Additional synchronized cross-unit false group refused')]:
    d=json.loads((plan/(name+'.json')).read_bytes())
    rows.append(f"| {label} | {d['exit_code']} | {d['elapsed_seconds']:.3f}s | `{name}.json` |")
pins='\n'.join(f"| `{path}` | {pin['byte_length']} | `{pin['sha256']}` |" for path,pin in inspection['owned_pins'].items())
roots=[]
for path in sorted(plan.glob('task-2-*.stdout.txt')):
    for line in path.read_text(encoding='utf8').splitlines():
        if 'Retained actual v2 test root:' in line:
            roots.append(f"- `{path.name}` → `{line.split('Retained actual v2 test root:',1)[1].strip()}`")
report=f'''# Task 2 report — independent Python Schema2 verification

Status: DONE. Task 2 review range: `af528d2..4f0940b`. Only the four assigned Python source/test files were committed. Controller docs/devlog/.gitattributes/evidence packaging/push remain controller-owned; both original `docs/Noetome-PRD-v1.0` deletions and all pre-existing dirty docs remain untouched. No status transition, new product task, subagent, production Vault, credential read, model call or network research occurred.

## Commits

- `b83b33e812e2394d020b21c6db4de27e8699f209` — independently reconstruct and audit v2 source-backed variants; strict routing and closed evidence quote LF admission.
- `1946e7105bac4a016bcfbbd1138d787ad8586062` — actual frozen-author CLI preparations and synchronized forgery behavior tests.
- `4f0940bb82e34c83b531e91985ac6c9368d3eb84` — self-review fix retaining AssertionError for malformed top-level case documents plus five explicit probes.

## Implemented behavior

`verify_knowledge_variants.py` independently rebuilds actual context adjacency, absolute UTF8 byte ranges and SHA, all actual supports, identity roles and exact original reference sets, complete normalized keys, per-occurrence unknown partitioning, Gregorian ranges/directions, ordered relationships, accumulated issue codes, every status partition and denominator. It compares the author's entire occurrences/groups/pairs/totals, all copied original bytes, independent unpublished IR, full JSON and exact user-visible Markdown preamble plus embedded snapshot. It does not adopt Rust counters, relations or expected facts. Unknown time remains permitted in proven duplicate/complement/condition variants; unknown applicability remains occurrence-separated and unresolved.

The unchanged nine-artifact source admission remains shared. Its explicit opt-in permits LF only under `candidate.payload.evidence[*].quote`; length bounds and all other fields retain their previous restrictions. Both default-v1 refusal and v2 successful complete admission were actually exercised. CR, tab, NUL, overlength quotes, other quote locations and non-quote fields remain rejected. Actual source/quote/SHA/range, original Gold2/review/decision, complete source report/IR/Markdown reconstruction, unique links and SQL/resource checks still execute. No monkeypatch or wholesale admission copy was used.

The established successful dictionary/AssertionError failure protocol remains intact. Routing requires integer Schema1/Schema2 and a JSON object; unsupported/mixed versions, boolean or float versions, duplicate keys and malformed documents fail through AssertionError. `check` retains 0/1 behavior. Both standalone v2 `check`/`audit` interfaces and wrapper `audit-v2` exist; the standalone check was actually executed against the conditional ordinary root.

## Genuine RED and retained failures

Before production v2 routing, the exact selected-runtime command was:

```text
C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8 -m unittest discover -s tests -p test_knowledge_variants_verifier.py -v
```

PowerShell retained its combined output as `{plan}/task-2-red.txt` and exit1 as `task-2-red.exit`. Four tests ran in 17.100s, with 17 positive/subtest failures at the immutable old gold-schema gate, while coherent negative probes rejected. Root `D:/Noetome/target/python-variants-ea863af20921491db3eac892b1738b26` retains 16 ordinary v2 outputs and all successful source-review command receipts; expected bytes and pins preceded every CLI call. This is a behavior RED, not a preparation failure.

The initial shell redirect combined streams. To preserve isolated streams and full outer argv/timing for the same old behavior, `task2_red_replay.py` independently loads the exact old module retrieved by `git show af528d2:scripts/verify_knowledge_coordination.py` into a separate module, without replacing any production function. `task-2-red-stream-replay.json` and matching raw stdout/stderr retain exit1, two tests/one expected positive failure against the original ordinary root; the synchronized negative still rejects. Retrieval bytes/SHA and actual argv are in `old-verifier-retrieval.json`; the source is `old-verifier-af528d2.py`. The replay supplements the original pre-routing RED and does not relabel it.

All intermediate receipts remain, including `task-2-green-final.json` (a test incorrectly compared the context slice to the whole prefixed/suffixed unit; corrected to the actual UTF8 slice/nonzero range) and `task-2-final-object-routing.json` (a newly added test loop was placed in the wrong helper; moved to its own test). Both were test-only iteration errors, corrected before final acceptance. No failed attempt was erased.

## Actual final verification

All commands use the selected absolute Python above, `-X utf8`, cwd `D:/Noetome`. `task2_run.py` preserves exact actual argv, separate complete stdout/stderr bytes and SHA/length, exits, elapsed wall time and current source/test/CLI/frozen-author before/after maps. The following command receipts all exited0:

| Check | Exit | Elapsed | Receipt relative to this plan workspace |
| --- | ---: | ---: | --- |
{chr(10).join(rows)}

Exact final test/audit command arguments after the runtime are:

```text
-m unittest discover -s tests -p test_knowledge_variants_verifier.py -v
-m unittest discover -s tests -p test_knowledge_coordination_verifier.py -v
-m unittest discover -s tests -p test_*.py
scripts/verify_knowledge_coordination.py audit-v2 D:/Noetome/target/debug/noetome.exe D:/Noetome/.superpowers/sdd/B05-T02_VARIANTS_PLAN/task-2-audit-v2-stable
scripts/verify_knowledge_coordination.py audit D:/Noetome/target/debug/noetome.exe D:/Noetome/.superpowers/sdd/B05-T02_VARIANTS_PLAN/task-2-audit-old-stable
```

Raw streams use each receipt stem with `.stdout.txt`/`.stderr.txt`. The initial full stable suite passed154/154; self-review subsequently found the concrete top-level routing exception gap, so one justified new focused/full/audit pass followed that new code/test change. Final full stable155/155 passed, no skipped tests. The final full suite also contains the unchanged old v1 tests. `task-2-diff-check.json` records `git diff --check` exit0; only unrelated existing document line-ending advisories were printed. Commit receipts retain actual git argv/output as well.

## Ordinary audits and semantic refusal

Final v2 audit: `{plan}/task-2-audit-v2-stable/audit.json`, 41 scenarios and119 real CLI calls. It includes all14 frozen cases (29 original author sources), multiple supports with retained ordering, input/mapping reorder plus display-name changes, and a selected new-project mtime scenario. All35 source-review preparations in the 16 initial positive roots exited0. The extra mtime coordinate used a new copied selected project/case with explicit timestamp946684800 and left source time unknown. Before calling CLI, each new root had its exact author expected bytes and fingerprint. Full ordinary stdout equals the persisted coordination JSON.

Fifteen synchronized output forgeries cover deleting/rewriting full conditions and exceptions, dropped context support, invented time, unknown→not_applicable, unknown default-zero, missing required null, omitted occurrence, identity/version misbinding, unit rewriting, forced overlapping historical order and false zero counters. Their fact IDs are recomputed from their forged displayed fields; JSON/Markdown/IR/artifact hashes are synchronized. Nine additional forged case declarations synchronize identity-original bytes and artifact pins; they reject at actual-source time/applicability/support/identity/schema/calendar gates. Reasons are retained per scenario, including `actual source time/status`, `exact actual background support set` and full `IR/report source/author reconstruction` paths. None of those checks relies on stale Markdown, IR or artifact hashes alone.

The additional `{plan}/task-2-unit-false-group.json` preserves all raw occurrences, forces the differing unit/value/condition occurrences into one group and synchronizes totals/Markdown/artifact pins. It actually rejects at `report source/author reconstruction/facts: length`; receipt and complete forged output are retained. This explicitly checks false grouping as well as the ordinary matrix's rewritten unit.

Final old audit: `{plan}/task-2-audit-old-stable/audit.json`, 33 scenarios/56 real CLI calls. Old audit remains Schema1 and all old admission/forgery behavior is preserved. Both final audits preserve original cases, project SQL/resources, old IR/gold and external human sentinels; final protection maps agree. Command receipts include full argv/cwd/exit/stdout/stderr/time; v2 additionally pins the actual CLI before and after each invocation and saves current source pins before/after the audit. Original earlier audit roots remain retained, never overwritten.

Focused roots are retained and discoverable from their raw stdout:

{chr(10).join(roots)}

## Exact pins and Rust evidence reuse

`task-2-final-inspection.json` and `task-2-final-inspection-command.json` independently rechecked complete final stream pins, every final source/test/CLI/author pin, all actual audit command streams/exits, and all89 Task1 source/build pins against current bytes. No mismatches occurred. Actual CLI remains `{inspection['cli']['sha256']}` / {inspection['cli']['byte_length']} bytes, identical to Task1's reviewed fresh binary. Frozen author file/Git-byte protection remains unchanged.

| Owned file | Bytes | SHA256 |
| --- | ---: | --- |
{pins}

No Rust suite was repeated. Direct dependency scan found no references from `crates`/`Cargo.toml` to these Python modules (`rg` exit1 with empty streams); Rust sidecar test Python calls concern unrelated PDF/sidecar scripts, which remain byte-identical. The reviewed589-test/17-suite Task1 run therefore remains applicable to unchanged Rust/build dependencies. The new ordinary Python audits supply the changed verifier call-boundary evidence separately. This does not infer a new Rust run from a Python test pass.

## Self-review and remaining work

Read the entire own diff and checked strict recursive equality/type gates (False vs0, 2.0 vs2), required nulls, identity sets/roles, actual-source LF admission, source context adjacency/uniqueness/nonzero UTF8 ranges, Gregorian ranges, relationship precedence/direction, unknown partitioning, complete support/original ordering, each denominator and all save/status/Markdown representations. No unresolved correctness or scope issue found. The malformed-case object guard was fixed and freshly tested before this report.

Controller still owns fresh Task2 and whole-branch reviews, final acceptance assets/standards/devlog checks, completing B05-T02 and ordinary push/exact remote HEAD verification. This task report does not claim product acceptance or B05-T03 work. Evidence remains self-authored/fake-provider engineering material; real scientific accuracy, arbitrary natural-language semantics, unit conversion, full PDF coordination, production-scale performance and non-Windows compatibility remain unmeasured. The initial RED's combined-stream limitation is explicitly preserved and supplemented by the immutable separated-stream replay.
'''
(plan/'task-2-report.md').write_text(report,encoding='utf8')
print(plan/'task-2-report.md')
