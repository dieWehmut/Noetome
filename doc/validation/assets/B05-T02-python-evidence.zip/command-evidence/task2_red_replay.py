"""Retain isolated streams for the immutable old-verifier RED replay."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest

plan = Path(__file__).resolve().parent
repo = Path('D:/Noetome')
sys.path.insert(0, str(repo / 'scripts'))
argv = ['git', 'show', 'af528d2:scripts/verify_knowledge_coordination.py']
run = subprocess.run(argv, cwd=repo, capture_output=True, check=True)
path = plan / 'old-verifier-af528d2.py'
path.write_bytes(run.stdout)
(plan/'old-verifier-retrieval.json').write_text(json.dumps(dict(argv=argv,exit_code=run.returncode,
    stdout_sha256=hashlib.sha256(run.stdout).hexdigest(),stderr=run.stderr.decode())),encoding='utf8')
spec = importlib.util.spec_from_file_location('immutable_old_coordination', path)
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
from knowledge_variants_audit import rewrite_output
import shutil
import uuid
folder = repo/'target/python-variants-ea863af20921491db3eac892b1738b26/conditional'
class OldVerifierRed(unittest.TestCase):
    def test_author_positive_requires_v2(self):
        self.assertTrue(old.verify_report(folder/'project',folder/'case',folder/'output',
            (folder/'gold.json').read_bytes())['independently_verified'])
    def test_synchronized_deleted_condition_is_rejected(self):
        destination = plan/('red-replay-forged-'+uuid.uuid4().hex)
        shutil.copytree(folder/'output',destination)
        report=json.loads((destination/'coordination.json').read_bytes())
        report['facts'][0]['conditions']=[]
        rewrite_output(destination,report)
        with self.assertRaises(AssertionError):
            old.verify_report(folder/'project',folder/'case',destination,(folder/'gold.json').read_bytes())
unittest.main(argv=[sys.argv[0], '-v'])
