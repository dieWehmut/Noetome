import hashlib
import json
from pathlib import Path
import subprocess

repo=Path('D:/Noetome'); plan=Path(__file__).resolve().parent
def fp(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def load(path):
    return json.loads(path.read_bytes())
task1=load(plan/'task-1-resume-verification.json')
for path,pin in task1['before'].items():
    assert fp(Path(path).read_bytes())==pin,path
assert fp((repo/'target/debug/noetome.exe').read_bytes())==task1['cli']
commands={}
for name in ('task-2-final-object-routing-corrected','task-2-python-stable','task-2-audit-v2-stable-command','task-2-audit-old-stable-command'):
    receipt=load(plan/(name+'.json'))
    assert receipt['exit_code']==0,name
    assert receipt['before']==receipt['after'],name
    for stream in ('stdout','stderr'):
        pin=receipt[stream]; assert fp(Path(pin['path']).read_bytes())=={k:pin[k] for k in ('sha256','byte_length')}
    for path,pin in receipt['after'].items():
        assert fp(Path(path).read_bytes())==pin,path
    commands[name]=dict(exit_code=0,source_pin_count=len(receipt['after']),streams_checked=True)
audits={}
for name in ('task-2-audit-v2-stable','task-2-audit-old-stable'):
    root=plan/name; audit=load(root/'audit.json')
    for call in audit['calls']:
        for stream in ('stdout','stderr'):
            pin=call[stream]; assert fp(Path(pin['path']).read_bytes())=={k:pin[k] for k in ('sha256','byte_length')}
        assert call['exit_code']==call['expected_exit']
    audits[name]=dict(scenarios=audit['scenario_count'],commands=len(audit['calls']))
owned=('scripts/verify_knowledge_coordination.py','scripts/verify_knowledge_variants.py','scripts/knowledge_variants_audit.py','tests/test_knowledge_variants_verifier.py')
scan=subprocess.run(['rg','-n','verify_knowledge_coordination|verify_knowledge_variants|knowledge_variants_audit','crates','Cargo.toml'],cwd=repo,capture_output=True)
assert scan.returncode==1 and not scan.stdout and not scan.stderr
result=dict(task1_reused_source_count=len(task1['before']),cli=task1['cli'],commands=commands,audits=audits,
    owned_pins={path:fp((repo/path).read_bytes()) for path in owned},dependency_scan=dict(argv=scan.args,exit_code=scan.returncode,stdout='',stderr=''))
(plan/'task-2-final-inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,ensure_ascii=False))
