"""Additional coherent false grouping preserving all actual raw occurrences."""
import json
from pathlib import Path
import shutil
import sys
import uuid
repo=Path('D:/Noetome'); plan=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'scripts'))
from knowledge_variants_audit import rewrite_output
from verify_knowledge_coordination import verify_report, strict_json, fingerprint, encoded
folder=plan/'task-2-audit-v2-stable/unit_difference'
output=plan/('unit-false-group-'+uuid.uuid4().hex)
shutil.copytree(folder/'output',output)
report=strict_json((output/'coordination.json').read_bytes())
report['facts'][0]['occurrence_ids']=sorted(o['occurrence_id'] for o in report['occurrences'])
report['facts']=report['facts'][:1]
report['totals'].update(retained_fact_groups=1,duplicate_occurrences=1)
rewrite_output(output,report)
try:
    verify_report(folder/'project',folder/'case',output,(folder/'gold.json').read_bytes())
except AssertionError as exc:
    reason=str(exc)
else:
    raise AssertionError('false cross-unit group accepted')
assert 'source/author reconstruction/facts' in reason,reason
assert strict_json((output/'coordination.md').read_bytes().split(b'```json\n')[1].split(b'\n```\n')[0])==report
for name,pin in report['artifacts'].items():
    assert fingerprint((output/name).read_bytes())==pin
receipt=dict(rejected=True,reason=reason,output=str(output),gold_fingerprint=fingerprint((folder/'gold.json').read_bytes()),
    report_fingerprint=fingerprint((output/'coordination.json').read_bytes()),original_occurrences_preserved=True,
    markdown_artifact_hashes_synchronized=True)
(plan/'task-2-unit-false-group.json').write_bytes(encoded(receipt))
print(json.dumps(receipt,ensure_ascii=False))
