# Binding scope

Spec: D:/Noetome/doc/technical/KNOWLEDGE_VARIANTS_CONTRACT.md

## Global Constraints

- 只消费同一实际项目内 2 至 3 份成功、单原子的 source_review 九件依据，沿用原 SourceSession、完整重建、身份映射和最终保存守卫。
- 新字段只进入独立协调 Schema2，不写回旧来源核对或 gold。v1 拒绝混入 v2 字段，v2 不默认为缺失字段填值，未知版本仍拒绝。owner 协议独立保持 Schema1。
- 成功范围固定为 `explicit_identity_condition_time_v2`，case purpose 固定为 `explicit_identity_condition_time`。
- 知识 `pending`、科学 `not_run`、研究 `not_requested`、`published=false`、网络及付费调用为实际 0。
- 禁止通过 mtime、文件名、导入/响应/运行时间或默认 0 推造 time。
- 规范化仍只去 Unicode 空白，不数值化、大小写折叠或单位换算。
- 报告 status=needs_review 时 canonical_facts=null、退出 3、不保存协调 IR，完整双报告和来源原件仍保存。
- 原概念、原子、链接顺序及全部支持依据不改写。
- 同时最多一个产品任务 in_progress；本计划两项内部工作都属于 B05-T02，不启动 B05-T03。保留用户两项旧 docs PRD 删除，不暂存或恢复。
- 普通提交和当前任务分支推送已获用户授权。代理只能提交自己的明确文件，不修改全局身份、不 force push、不写生产 Vault、不读凭据、不调用真实模型。


## Task 2: 独立 Python v2 重建与一致伪造门禁

**Files:**

- Create: `scripts/verify_knowledge_variants.py`（独立 v2 case/source/context/facts/report/IR 校验及普通 audit）。
- Create: `scripts/knowledge_variants_audit.py`（冻结作者准备、真实 argv/输出/指纹/保护及矩阵，供 verifier audit 委托）。
- Create: `tests/test_knowledge_variants_verifier.py`（作者正常样例与同步伪造的行为测试）。
- Modify: `scripts/verify_knowledge_coordination.py`（严格 schema 路由到 v2，保持旧 v1 check/audit；为共同source_bundle增加只由v2显式启用的原evidence.quote换行元数据校验，默认v1规则不变）。
- Read only: 全部作者 fixture、Task1 Rust 实现/报告及旧 Python 来源准入 helpers。

**Interfaces:**

- Consumes: Task1 的普通 Schema2 输出；`source_bundle(project,directory,pin)`、`actual_source`、`rebuild_source_report`、严格读文件/JSON/指纹/readonly 保护等已有 Python 原来源核对能力。不得调用 Rust 协调器计算 expected，不能共享 Rust v2 分组逻辑。
- Produces: 既有 `verify_report(project,case,output,gold)` 对严格 v1/v2 路由；新 `verify_knowledge_variants.verify_report(project:Path,case:Path,output:Path,gold:bytes)->dict` 沿用原调用协议，合法返回 `{"status":...,"independently_verified":True,"totals":...,"inputs":...}`，任何不符抛 `AssertionError`，wrapper check 捕获后退出 1；合法退出 0。不用False字典改变既有audit的异常门禁。
- Audit: `python scripts/verify_knowledge_coordination.py audit-v2 <absolute-cli> <nonexistent-root>`；旧 `audit` 仍为 v1。新脚本自身 `audit <absolute-cli> <nonexistent-root>` 和 `check <project> <case> <output> <gold>` 可独立使用。
- 作者 expected 固定 Schema2，包含 case 名、范围/状态、每组 values/units/fullconditions/exceptions/applicability/time/input及原 atom ID、原出现状态问题、pair 关系方向和每个 totals。只从作者文件/明确调用前参数读入。
- 已观察的共同准入边界：旧metadata递归拒绝所有控制字符，实际v2支持引文必含背景与事实之间的LF。共同source_bundle应有封闭的v2 opt-in，仅允许原candidate.payload.evidence[*].quote中实际来源支持的空白换行，仍执行原长度、全部字段、gold/review/decision元数据和实际来源/quote/SHA/范围重验；默认v1不变。禁止全局monkeypatch、跳过source_bundle或复制完整准入逻辑。

- [ ] **Step 1: 写合法 v2 被旧 verifier 拒绝的真实 RED 与一致伪造测试。**

```python
def test_conditional_report_matches_frozen_authors(self):
    self.assertTrue(verify_report(self.project, self.case, self.output,
                                 self.expected_raw)["independently_verified"])

def test_coherent_deleted_condition_is_rejected(self):
    forged = self.copy_to_new_output("deleted-condition")
    report = self.read_report(forged)
    report["facts"][0]["conditions"].pop()
    self.rewrite_report_markdown_ir_and_fingerprints(forged, report)
    with self.assertRaises(AssertionError):
        verify_report(self.project, self.case, forged, self.expected_raw)
```

Run: 选定 Python `-m unittest discover -s tests -p test_knowledge_variants_verifier.py -v`。Task1 实际合法输出在新生产 Python 接线前被旧 schema 校验拒绝，正例测试实际 RED；伪造测试不能仅因陈旧 MD/IR/artifact 失败。不要加入故意宽松的生产 verifier 来制造 RED。

- [ ] **Step 2: 从作者与实际来源分别重建，校验所有引用和字段。**

```python
# expected_raw 先严格验 Schema2/全部字段/作者文本/非负整数与 required null。
# 九件 source_bundle 独立重验，再实际 unit 与原 gold 唯一事实重建相邻背景。
# 原身份角色映射集合重新核对；v2 complete key 与 unknown 分区独立计算。
# 重建每对关系的公历区间和方向、四状态及全部 totals，逐字段 exact。
# 保存 owner/原字节副本/IR/完整 JSON 和 Markdown 独立检查，严禁仅 passed flag。
```

共用旧 helper 只限原 source_review 准入/IO；v2事实与关系重建用 Python 标准库独立实现。v2必须拒绝不支持/混合版本、重复 JSON 键、未知字段、bool计数、缺 null、原件替换、全部支持遗漏/重复、相邻性伪造、日期误配及不同单位伪同组。

- [ ] **Step 3: 普通 audit 从调用前作者 fixture 构造并保留完整证据。**

覆盖全部作者 case +同来源有/无时间 +顺序/显示名 +多支持 +coherent forgeries；保护原输入/项目真实资源/SQL/旧IR/gold及外部哨兵。新 audit 保存 CLI 前后 SHA/长度、每次实际 argv/exit/stdout/stderr/耗时、预期原字节指纹、逐场景 check 和保护前后；失败也保留 receipt，不能只记成功摘要。修改时间 metadata 只用明确选中测试资料与新案例，核对始终不改变来源时间分类。

- [ ] **Step 4: focused GREEN、旧模块和完整 Python 稳定门禁。**

Run new module；旧 `test_knowledge_coordination_verifier.py`；一次全部 `python -m unittest discover -s tests -p "test_*.py"`，实际记录数量和结果。普通 `audit-v2` 与旧 `audit` 各保存新根，不覆盖旧证据；只在新更改/失败时重复相关检查。

- [ ] **Step 5: commit、报告、任务审查后交 controller 完成全项。**

提交明确 Python 源和测试。报告保存 RED/GREEN、audit原件及严格指纹，controller 新鲜 task review 后追加标准/验收资产、运行devlog check与git diff --check，最终 whole-branch review及一波有界修复后 complete B05-T02、最终日志 commit、普通push并核对 exact远端HEAD。本计划不自动启动B05-T03。

## Runtime and controller boundaries

Work from D:/Noetome on the current codex/b05-t02-condition-history branch. User ordinary commits authorized, but push/devlog statuses/final standards are controller-owned. Do not start or complete B05-T02, do not start T03, do not edit docs/Noetome-PRD-v1.0.md or .html, do not spawn subagents. Source fixtures are frozen, do not edit any file there.

Use the selected Python runtime C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe with -X utf8; set NOETOME_TEST_PYTHON and NOETOME_PDF_PYTHON to it for Cargo via ./scripts/cargo_local.ps1. Never hardcode this runtime in tracked files. In PowerShell quote the Cargo delimiter as '--'. Approval policy never: omit sandbox_permissions. Record commands, raw output and source/CLI hashes to this plan workspace; preserve RED failures.

Follow implementer-prompt.md from C:/Users/Lyinn/.codex/plugins/cache/openai-api-curated/superpowers/0722921d/skills/subagent-driven-development. Return DONE/DONE_WITH_CONCERNS/NEEDS_CONTEXT/BLOCKED, commit hashes, a one-line test summary and report path; detailed evidence lives in task-2-report.md. Do not run broad tests repeatedly during iteration.
