import json
from pathlib import Path
import subprocess
import sys
import time
import hashlib

root = Path(__file__).resolve().parent
def fp(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))
name = sys.argv[1]
argv = (sys.argv[3:] if sys.argv[2] == '--external' else
        [sys.executable, '-X', 'utf8', *sys.argv[2:]])
repo = Path('D:/Noetome')
files = [*repo.glob('scripts/*.py'), *repo.glob('tests/test_*.py'), *repo.glob('crates/**/*.rs'), repo/'Cargo.toml', repo/'Cargo.lock', repo/'target/debug/noetome.exe', *repo.glob('fixtures/knowledge-coordination-v2/*')]
before = {str(p): fp(p.read_bytes()) for p in files if p.is_file()}
started = time.monotonic()
run = subprocess.run(argv, cwd=repo, capture_output=True)
out, err = root/(name+'.stdout.txt'), root/(name+'.stderr.txt')
out.write_bytes(run.stdout); err.write_bytes(run.stderr)
receipt = dict(argv=argv, cwd=str(repo), exit_code=run.returncode, elapsed_seconds=time.monotonic()-started,
               stdout=dict(path=str(out), **fp(run.stdout)), stderr=dict(path=str(err), **fp(run.stderr)),
               before=before, after={str(p): fp(p.read_bytes()) for p in files if p.is_file()})
(root/(name+'.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(exit_code=run.returncode,elapsed_seconds=receipt['elapsed_seconds'],receipt=str(root/(name+'.json')))))
sys.exit(run.returncode)
