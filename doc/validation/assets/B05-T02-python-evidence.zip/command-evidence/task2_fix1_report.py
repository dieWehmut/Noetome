import json
from pathlib import Path

plan=Path(__file__).resolve().parent
data=json.loads((plan/'task-2-fix1-inspection.json').read_bytes())
pins='\n'.join(f"| `{p}` | {f['byte_length']} | `{f['sha256']}` |" for p,f in data['owned_pins'].items())
green=(plan/'task-2-fix1-green.stdout.txt').read_text(encoding='utf8').strip()
text=f'''

## Task 2 fix round 1 — input-qualified original atom IDs

Status: DONE. This addendum supersedes the preceding final counts/pins for the three changed files. Scoped re-review range: `4f0940bb82e34c83b531e91985ac6c9368d3eb84..9751505aac38f4bac0689100bb521e0b6e60ad8b`. Commit `9751505aac38f4bac0689100bb521e0b6e60ad8b` — `fix(coordination): preserve input-qualified original atom identities`.

Read the complete `task-2-review.md` and `task-2-review-shared-atom-probe.json`, then checked existing v1 pairing rules and the named v2 identity contract using the receiving-code-review skill. Finding: **P2 — preserve input-qualified original atom IDs in author fact members.** The old `strings(item["original_atom_ids"])` imposed normalized global uniqueness on IDs belonging to separate input namespaces. The fix replaces only that v2 author-member uniqueness gate with a bounded list and per-element `text` validation. Equal-length pairing, unique input IDs, complete input partitioning and per-input actual identity matching remain. Original ID bytes are not normalized or renamed by verification.

### Actual source-backed regression and genuine RED

`VariantsAudit.prepare(..., shared_atom=True)` now creates an explicit new author override from the frozen `not_applicable` example. Its two distinct inputs retain the same original `a-speed` in candidates, decisions, atom mappings, context declarations, author occurrences and fact member arrays. Original frozen fixture files are read-only and untouched. Exact overridden author/expected/gold bytes and `expected-pin.json` are saved before project init or any CLI call; expected is never derived from CLI output. Each new source has its own registered identity and original support.

Before changing the production gate, executed:

```text
C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8 .superpowers/sdd/B05-T02_VARIANTS_PLAN/task2_run.py task-2-fix1-red -m unittest discover -s tests -p test_knowledge_variants_verifier.py -v
```

`{plan}/task-2-fix1-red.json` retains full underlying actual argv, separate stdout/stderr bytes/pins, exit1, timing25.938s and unchanged before/after source/CLI/frozen-author maps. Raw streams: `task-2-fix1-red.stdout.txt`, `task-2-fix1-red.stderr.txt`. Actual source-backed root: `D:/Noetome/target/python-variants-084180631cab4ef0a414d2f603232bf8/shared-original-atom-id`. Both source reviews exited0 and ordinary coordinate exited0 with two distinct occurrence IDs, one duplicate group and `a-speed` preserved twice. Fourteen tests ran; three failures reached the old `duplicate normalized string` gate: the two positive shared-ID checks and the missing-support negative test expecting its deeper reconstruction rejection. This is genuine schema behavior RED, not a preparation error. All original/earlier receipts remain.

### Covering tests and ordinary audit

Changed covering files:

- `scripts/verify_knowledge_variants.py` — only the v2 fact-member original-ID gate.
- `scripts/knowledge_variants_audit.py` — explicit pre-call author override plus ordinary shared-ID scenario.
- `tests/test_knowledge_variants_verifier.py` — `test_input_qualified_shared_original_atom_id`, shared scenario in all-author checking, and `test_shared_atom_members_retain_pairing_and_evidence_guards`.

The positive proves one retained group, two distinct actual occurrences and two original supports while retaining repeated original bytes. Negative probes actually reject unequal member lengths, non-list IDs, bool/empty/overlength ID elements, duplicated input IDs, a wrong per-input original identity, and a synchronized report/Markdown/IR/artifact forgery omitting input b's original support. The latter now reaches source/author reconstruction after the legal shared-ID author gate.

Final actual commands (each uses the selected absolute Python and `-X utf8` through `task2_run.py`):

| Receipt | Underlying command | Actual outcome |
| --- | --- | --- |
| `task-2-fix1-green.json` | `-m unittest discover -s tests -p test_knowledge_variants_verifier.py -v` | Exit0; **14/14**, 25.907s |
| `task-2-fix1-python.json` | `-m unittest discover -s tests -p test_*.py` | Exit0; **157/157**, 103.437s; no skipped tests |
| `task-2-fix1-audit-v2-command.json` | `scripts/verify_knowledge_coordination.py audit-v2 D:/Noetome/target/debug/noetome.exe D:/Noetome/.superpowers/sdd/B05-T02_VARIANTS_PLAN/task-2-fix1-audit-v2` | Exit0; **42 scenarios / 126 actual CLI calls**, 32.859s |
| `task-2-fix1-inspection-command.json` | `.superpowers/sdd/B05-T02_VARIANTS_PLAN/task2_fix1_inspect.py` | Exit0; command stream/source/CLI/author pins and protections independently rechecked |
| `task-2-fix1-diff-check.json` | `git diff --check` | Exit0; unrelated existing document line-ending advisories only |
| `task-2-fix1-commit.json` | `git commit -m "fix(coordination): preserve input-qualified original atom identities"` | Exit0; exact commit stream retained |

Each receipt has matching complete `.stdout.txt`/`.stderr.txt` files. GREEN root from actual stdout: `{green}`. Final audit: `{plan}/task-2-fix1-audit-v2/audit.json`, retaining all old scenarios plus the new ordinary shared-ID source-review/coordinate scenario. Author expected SHA/length is `{data['shared_expected_pin']['sha256']}` / {data['shared_expected_pin']['byte_length']} bytes; `frozen-authors/author.json` and `expected-pin.json` agree. Actual occurrence IDs are `{data['shared_occurrence_ids'][0]}` and `{data['shared_occurrence_ids'][1]}`.

### Pins, self-review and boundaries

`{plan}/task-2-fix1-inspection.json` checks all final stream hashes, before/after source maps, audit call exits/streams and protection maps. All89 Task1 source/build pins and the actual CLI remain unchanged: `{data['cli']['sha256']}` / {data['cli']['byte_length']} bytes. `git diff --exit-code 4f0940b -- scripts/verify_knowledge_coordination.py crates Cargo.toml Cargo.lock` is empty/exit0. Rust and default-v1 production paths therefore did not change; no redundant Rust or old-audit rerun occurred. The final full Python suite includes the old v1 regressions.

| Changed file | Bytes | SHA256 |
| --- | ---: | --- |
{pins}

Read the complete scoped diff. The new fixture only changes pre-declared test author IDs consistently before CLI; production retains input qualification and exact original bytes. List bounds and per-element text limits remain, and the unchanged later actual identity, partition and evidence checks close the new positive's negative boundaries. No unresolved issue found in this fix. Controller docs/log/status/archive/push work and user deletions remain untouched; fresh scoped re-review and final product acceptance are controller-owned. Fake-author engineering limits in the original report remain unchanged.
'''
with (plan/'task-2-report.md').open('a',encoding='utf8') as stream:
    stream.write(text)
print(plan/'task-2-report.md')
