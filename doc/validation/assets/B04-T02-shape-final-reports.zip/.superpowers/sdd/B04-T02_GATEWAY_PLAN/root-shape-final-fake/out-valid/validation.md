# 离线 fake 候选验证

状态：candidates_validated

请求：eb7517c5-6471-4360-b1bd-8d96b4c7faf1
来源版本：242712c0-31c8-4949-ba90-3c1e9fd0ce8a
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "eb7517c5-6471-4360-b1bd-8d96b4c7faf1",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "c9dbe714-37a7-4eb5-b5f0-650c659b5fb5",
    "source_id": "c30b0302-51ce-43fe-84d4-dc45a47054c8",
    "version_id": "242712c0-31c8-4949-ba90-3c1e9fd0ce8a",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "9dfaabeb9e1dfc281d31156b6250ed792eb007f35cf9ca68e170364268b7cc97",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "80328751fb046aa3d87fb232605a799b1b9a482622dabe7b6b40e0da4f7353c3",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "5c21a1bb704ec435e2c4c73e43b4737444a2c07d1b613328f8005e22152bd4a8",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "f8470ddae7cc2bb4a96d90e06d2d637752ccfc555d0e5b1c7152d7e9747d36b2",
      "byte_length": 2050
    }
  }
}
```
