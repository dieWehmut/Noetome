# 离线 fake 候选验证

状态：failed

请求：4baaca5a-f832-4504-a5c7-a1f9e7285759
来源版本：242712c0-31c8-4949-ba90-3c1e9fd0ce8a
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 141 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_OUTPUT_TOKENS: EXTRACT_OUTPUT_TOKENS：完整fake响应超过fake UTF-8字节token上限。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "4baaca5a-f832-4504-a5c7-a1f9e7285759",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "c9dbe714-37a7-4eb5-b5f0-650c659b5fb5",
    "source_id": "c30b0302-51ce-43fe-84d4-dc45a47054c8",
    "version_id": "242712c0-31c8-4949-ba90-3c1e9fd0ce8a",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 141,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_OUTPUT_TOKENS",
      "message": "EXTRACT_OUTPUT_TOKENS：完整fake响应超过fake UTF-8字节token上限。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "aeb6cc493ff2104b72608863cbbfda8aeb81a59343c0f3be07ecaee34c3a67d2",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "eec8a666124253d0aeecef75cb246a356456ed8284f82a5a44085cb9a268365c",
      "byte_length": 1357
    },
    "response.bin": {
      "sha256": "40e47e6df6600ba40e1afdfd1de2006fe92ce3c763aecaf652fa3a9b3760ae5a",
      "byte_length": 2050
    }
  }
}
```
