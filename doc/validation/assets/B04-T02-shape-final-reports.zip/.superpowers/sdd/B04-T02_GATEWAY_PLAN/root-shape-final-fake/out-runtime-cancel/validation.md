# 离线 fake 候选验证

状态：failed

请求：20c0bc20-3ecb-425c-9452-a76127327a0a
来源版本：242712c0-31c8-4949-ba90-3c1e9fd0ce8a
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 unknown 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_CANCELLED: EXTRACT_CANCELLED：请求已由取消信号停止。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "20c0bc20-3ecb-425c-9452-a76127327a0a",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "c9dbe714-37a7-4eb5-b5f0-650c659b5fb5",
    "source_id": "c30b0302-51ce-43fe-84d4-dc45a47054c8",
    "version_id": "242712c0-31c8-4949-ba90-3c1e9fd0ce8a",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": null,
    "output_bytes": null,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_CANCELLED",
      "message": "EXTRACT_CANCELLED：请求已由取消信号停止。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "c61661a11677649bbf82986f84e336e2f25a79387c9214c23e13fc4673d516db",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "7d825c6a8ec77b8684fc9a7c969247ce88df0b74e683d6e8c9b75bda3fefb08d",
      "byte_length": 1360
    }
  }
}
```
