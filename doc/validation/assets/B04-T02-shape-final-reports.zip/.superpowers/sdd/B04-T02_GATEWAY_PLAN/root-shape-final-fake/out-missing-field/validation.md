# 离线 fake 候选验证

状态：failed

请求：93c17762-18ab-4861-baa7-9fe09028ed72
来源版本：242712c0-31c8-4949-ba90-3c1e9fd0ce8a
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2027 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_RESPONSE_JSON: EXTRACT_RESPONSE_JSON：响应不符合严格JSON/schema：重复、额外、缺失字段及尾随数据均拒绝。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "93c17762-18ab-4861-baa7-9fe09028ed72",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "c9dbe714-37a7-4eb5-b5f0-650c659b5fb5",
    "source_id": "c30b0302-51ce-43fe-84d4-dc45a47054c8",
    "version_id": "242712c0-31c8-4949-ba90-3c1e9fd0ce8a",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2027,
    "output_bytes": 2027,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_RESPONSE_JSON",
      "message": "EXTRACT_RESPONSE_JSON：响应不符合严格JSON/schema：重复、额外、缺失字段及尾随数据均拒绝。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "0c1f3261ae6a0f36ce6036af456ed3cd0982b872a9ee75e74d5b026804e5fb54",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "0c0fdfa073ac6d11ae23094604fc2f3a2fd5bf4c3494fadfb27c2c1a48cbdab2",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "c5d909fb2c6b78bbd624a1c886470628fbfec2305be0ddaf3828e7c67f6e096c",
      "byte_length": 2027
    }
  }
}
```
