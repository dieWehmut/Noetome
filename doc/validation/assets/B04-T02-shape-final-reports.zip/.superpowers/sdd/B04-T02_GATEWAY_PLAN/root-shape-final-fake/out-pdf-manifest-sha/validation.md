# 离线 fake 候选验证

状态：failed

请求：156d0b7e-7bcc-4d87-8274-5c9a1c6b44ef
来源版本：24db56fd-b2f8-4214-81a9-608dee34a077
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_BINDING: EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "156d0b7e-7bcc-4d87-8274-5c9a1c6b44ef",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "0d789a54-ace3-4bd1-961c-439e95819342",
    "source_id": "05f00d57-88a8-41f4-a6ea-7f3c7ec0702f",
    "version_id": "24db56fd-b2f8-4214-81a9-608dee34a077",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "69ea18cb-3c11-45ad-888b-71c88e2cb3dd",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_BINDING",
      "message": "EXTRACT_SOURCE_BINDING：响应的请求、项目、导入、来源版本、解析或资源SHA与实际读取会话不一致。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "76457351a0c77f24e1bc20b067896e858e20417c37ae3984d7c9c713664caec8",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "63e013aee7a2bb41a4898b800103e2c376978bef093b34e094bc2af816e77adb",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "cba2aba279b548ec144a19eea33e45b3c0a237bf2dac3657b7fea3c9ba9fb958",
      "byte_length": 1935
    }
  }
}
```
