# 离线 fake 候选验证

状态：candidates_validated

请求：f9d6158e-4e27-495d-98a2-12be31aa23a4
来源版本：294ca72e-ff2f-4b7a-9535-ad8ce60b8d46
来源状态：needs_review
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 56 字节；输出 1898 计量单位；预留 8248 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "f9d6158e-4e27-495d-98a2-12be31aa23a4",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "42a45471-3bde-490b-84be-4acd4f582389",
    "source_id": "fb433cc7-f27e-4be9-b784-cab38fccf8f7",
    "version_id": "294ca72e-ff2f-4b7a-9535-ad8ce60b8d46",
    "content_sha256": "0f930cfb984cb91754ebeb8dc245e57ed490cf7fb3d487d8cf384011cd2f3c92",
    "normalized_sha256": "036f70c8257857485962d54674813b42fe4fe1d05adbf57e0bc7ac4aa9023ec5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "needs_review"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 56,
    "input_bytes": 56,
    "output_tokens": 1898,
    "output_bytes": 1898,
    "reserved_tokens": 8248,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "1978b910a4907dcd48b94870780994f17ae0b2d1ed3e5910263f4c9cd29ba9f5",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "0de44f3ee2f745b00af11f679dff763bce505b4c6147d93e43f3bbc665cfdf10",
      "byte_length": 2024
    },
    "request.json": {
      "sha256": "b8beb1f97c34961f555a48bd998538e7b41014288f72a67bbb25c5ab98fa4d87",
      "byte_length": 1282
    },
    "response.bin": {
      "sha256": "7e4f9425e19728b48c874b7cb1735f2f0b51a5057acb1d4b5e021ee874f3b063",
      "byte_length": 1898
    }
  }
}
```
