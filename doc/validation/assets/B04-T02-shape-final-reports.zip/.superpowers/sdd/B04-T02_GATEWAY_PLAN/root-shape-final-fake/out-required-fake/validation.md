# 离线 fake 候选验证

状态：failed

请求：34eb2a92-b4e4-48c9-bc7f-10b963f4a073
来源版本：242712c0-31c8-4949-ba90-3c1e9fd0ce8a
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2049 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_VERIFICATION: EXTRACT_VERIFICATION：候选必须保持unverified且required=false。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "34eb2a92-b4e4-48c9-bc7f-10b963f4a073",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "c9dbe714-37a7-4eb5-b5f0-650c659b5fb5",
    "source_id": "c30b0302-51ce-43fe-84d4-dc45a47054c8",
    "version_id": "242712c0-31c8-4949-ba90-3c1e9fd0ce8a",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2049,
    "output_bytes": 2049,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_VERIFICATION",
      "message": "EXTRACT_VERIFICATION：候选必须保持unverified且required=false。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "ae8e030321b77099b56b1701dcf9ec998d1ddb7e5b80e576993b46329ba0bd8d",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "5a0a22316a089a1cb9c0b3530c03b98b0221c0d2cb673a7bdb5fcd72a4da26b6",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "14f3ea9ac41cd007986d9176a7c080e27413c47788e156a01b669d415ce82c92",
      "byte_length": 2049
    }
  }
}
```
