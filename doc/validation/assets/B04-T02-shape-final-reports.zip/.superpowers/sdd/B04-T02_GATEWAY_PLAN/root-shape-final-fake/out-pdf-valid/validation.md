# 离线 fake 候选验证

状态：candidates_validated

请求：ed98275d-6121-4b5c-9f66-9d0fa475d5d9
来源版本：24db56fd-b2f8-4214-81a9-608dee34a077
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "ed98275d-6121-4b5c-9f66-9d0fa475d5d9",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "0d789a54-ace3-4bd1-961c-439e95819342",
    "source_id": "05f00d57-88a8-41f4-a6ea-7f3c7ec0702f",
    "version_id": "24db56fd-b2f8-4214-81a9-608dee34a077",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "69ea18cb-3c11-45ad-888b-71c88e2cb3dd",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "f435f3d989794439c40ace330b8ce09a25586da6f92a7044cedba679aed68793",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "3d0600352f2dff6f06df2c53e6e38ef67e1f0cd5dad2605151b140a64bf8d703",
      "byte_length": 2061
    },
    "request.json": {
      "sha256": "74dea805e9b57eefb08b2bf725339c8ac53cdfc70cdd6e215350fbd72ee913d0",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "fe5a70bdb5d0e7f428e3f732ee2dc3ece0f4661fcdc115fb30e1789e0d8eb514",
      "byte_length": 1935
    }
  }
}
```
