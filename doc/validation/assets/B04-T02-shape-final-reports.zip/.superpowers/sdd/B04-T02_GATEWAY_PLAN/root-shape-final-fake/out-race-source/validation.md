# 离线 fake 候选验证

状态：failed

请求：e6532ebf-0bc0-4e51-8e6c-b8ac3c1d4139
来源版本：242712c0-31c8-4949-ba90-3c1e9fd0ce8a
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_SOURCE_CHANGED: EXTRACT_SOURCE_CHANGED：来源身份、mtime或递归清单发生变化。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "e6532ebf-0bc0-4e51-8e6c-b8ac3c1d4139",
  "binding": {
    "project_id": "7216e850-207b-42d0-a6f9-ee6e1c762f2a",
    "import_id": "c9dbe714-37a7-4eb5-b5f0-650c659b5fb5",
    "source_id": "c30b0302-51ce-43fe-84d4-dc45a47054c8",
    "version_id": "242712c0-31c8-4949-ba90-3c1e9fd0ce8a",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_SOURCE_CHANGED",
      "message": "EXTRACT_SOURCE_CHANGED：来源身份、mtime或递归清单发生变化。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "1ea3daa587b531c2c61f707279bee35af3f8e79e30f3f02fb27f1c4d343d8e2b",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "b38f2a8f6bf350ee6871737a951889281ab7f66d32517351d44ad5a48b20f851",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "a3a6806629957c384ec3b1914ed33fe50ce29beedffa00c60d36fce6455d3851",
      "byte_length": 2050
    }
  }
}
```
