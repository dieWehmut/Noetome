# 单请求文本 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："deepseek-flash"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 174,
      "sha256": "0a303b169efe54dad4ea2c84ddda4e881b0425d8f608cc8775510f369eceb447"
    },
    "request-body.json": {
      "byte_length": 7133,
      "sha256": "a51b6e634c447da28d5dde3fef86cc6532b1f05ec90e3b35fe4aa9b79e44fb03"
    },
    "request.json": {
      "byte_length": 2207,
      "sha256": "18736e6273e359a9f9cd0513d874dde5240dc853c7a31276672a4614be19e077"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "9f0abe91-99c5-44d0-8e15-2e9ea48da551",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2c9dd41b-e63a-4858-bc56-18039ca25f33",
    "source_id": "50cf1923-ffea-432e-b37c-199a5223a141",
    "version_id": "d944ab9b-0eaa-4d17-a9df-53bb4a8fba1b"
  },
  "configured_model": "deepseek-flash",
  "endpoint": "https://ai.1343263.xyz/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_BUDGET_STOP",
      "message": "EXTRACT_BUDGET_STOP：单次请求次数或预留总量超过明确预算；未调用。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "06637f67-0276-490d-b0fa-a0aad8e2e1c3",
  "request_strategy": "tangmao-deepseek-chat-nested-atoms-v4",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "live",
  "usage": {
    "input_reserved_tokens": 8157,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7133,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 16349
  },
  "validated_atoms": 0
}
```
