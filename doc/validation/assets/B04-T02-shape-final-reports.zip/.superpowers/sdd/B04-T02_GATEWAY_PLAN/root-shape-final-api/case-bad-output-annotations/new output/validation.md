# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "5989b1ec9f9371130dde9bdf60f5f27d16fee4cad8934a181e69a04bca8c08bb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "0f441646679d660364dc712aa38186966bc2484aa2146430b5fd1043d66abb30"
    },
    "request.json": {
      "byte_length": 2208,
      "sha256": "e79e248d13e794ef40d93415aef279798aac54cfe63611bbf2cc0b9e105c4464"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "fdbbc02fa3cf4e11faa555fcc208dd6e1bde3d37578bc9357dd45c1004475438"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fc7c0d23-c4b3-4b7a-ab29-0784b48c95a4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76081807-38aa-4ca4-b7ca-f7837eed9dc0",
    "source_id": "adc8dd2a-e275-4643-8bb0-19ad60bfe07e",
    "version_id": "fb953b1d-593d-4ce7-b6df-56a43761b65c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63988/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_RESPONSE",
      "message": "EXTRACT_API_RESPONSE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f1914a24-a138-4da3-ae41-180e642f722a",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "fdbbc02fa3cf4e11faa555fcc208dd6e1bde3d37578bc9357dd45c1004475438"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
