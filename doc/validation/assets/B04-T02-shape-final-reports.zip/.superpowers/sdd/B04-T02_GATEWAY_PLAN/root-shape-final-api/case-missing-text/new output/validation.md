# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：null；完整响应：false。

实际网络尝试：0。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "fe41fe489231019bfc0f1e2b09594f55276db1b1c11a55be07ff567bca6fa5bf"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "e491f3e2338fa0641072e243914e6395130dd1061e40edb8b7b1c07ba17f44f0"
    },
    "request.json": {
      "byte_length": 2198,
      "sha256": "7e1d476710241edcc97e9b042cb45489e0d650c944434551f75e648d58620b32"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fc7c0d23-c4b3-4b7a-ab29-0784b48c95a4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76081807-38aa-4ca4-b7ca-f7837eed9dc0",
    "source_id": "adc8dd2a-e275-4643-8bb0-19ad60bfe07e",
    "version_id": "fb953b1d-593d-4ce7-b6df-56a43761b65c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:53036/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_CAPABILITY",
      "message": "EXTRACT_API_CAPABILITY：文本或结构化输出能力不足，或请求需要视觉输入；未调用。"
    }
  ],
  "http_request_id": null,
  "http_status": null,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "ba5436a3-eda5-44a8-942f-2301f5fb044f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": false,
  "response_id": null,
  "response_receipt": null,
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 0,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
