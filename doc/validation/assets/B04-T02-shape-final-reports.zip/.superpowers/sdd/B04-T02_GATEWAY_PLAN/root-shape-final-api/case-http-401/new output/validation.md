# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：401；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f8526be1aa9fb6dcc6dc5e2166fe1647c58c2175c71fd83486bf7d5bacf6b11e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "4f1cb328a54e0d6ac6f5442f872d582f6abb353340b373fbb1a5437b132b9b97"
    },
    "request.json": {
      "byte_length": 2194,
      "sha256": "02f91cf251b2f56ee9694c8ceb7e8a6d43c1e3cd87e4badcee7edd6b83a4e8a9"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "f59d3f7d72a2c6c41d3f888e15b5bf93696b3e7aae1c6b35a9a6035eaa8be7df"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fc7c0d23-c4b3-4b7a-ab29-0784b48c95a4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76081807-38aa-4ca4-b7ca-f7837eed9dc0",
    "source_id": "adc8dd2a-e275-4643-8bb0-19ad60bfe07e",
    "version_id": "fb953b1d-593d-4ce7-b6df-56a43761b65c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63860/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_AUTH",
      "message": "EXTRACT_API_HTTP_AUTH：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 401,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "f52d9c77-5719-49de-928c-157a81a7ba07",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "f59d3f7d72a2c6c41d3f888e15b5bf93696b3e7aae1c6b35a9a6035eaa8be7df"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
