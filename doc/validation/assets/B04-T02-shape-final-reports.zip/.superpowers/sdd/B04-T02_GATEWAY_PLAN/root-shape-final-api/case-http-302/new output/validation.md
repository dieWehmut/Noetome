# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：302；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "ca4401bb0204c11b7b6541e59328b53a89d26b3561533bf29adb43e0bc0a2fe0"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f1395089685bdec693657287574ba94890a3799d4e8b0d68e855b3e1bcd5f4b1"
    },
    "request.json": {
      "byte_length": 2194,
      "sha256": "fb5c2eb4dd9dbde4d4004ebe2f8ad6ce83b2db4715a79a324894a92013222b3d"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "9670865f421727b1e102f5dabf0b6f8c4371f6525a3424969b7ef8074fba9575"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "fc7c0d23-c4b3-4b7a-ab29-0784b48c95a4",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "76081807-38aa-4ca4-b7ca-f7837eed9dc0",
    "source_id": "adc8dd2a-e275-4643-8bb0-19ad60bfe07e",
    "version_id": "fb953b1d-593d-4ce7-b6df-56a43761b65c"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63882/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_STATUS",
      "message": "EXTRACT_API_HTTP_STATUS：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 302,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "b5372332-9476-4260-9101-481001a9591f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "9670865f421727b1e102f5dabf0b6f8c4371f6525a3424969b7ef8074fba9575"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
