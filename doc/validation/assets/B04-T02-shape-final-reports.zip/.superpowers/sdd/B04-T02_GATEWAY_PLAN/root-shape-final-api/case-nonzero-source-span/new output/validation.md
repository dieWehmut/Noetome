# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "a2e34689766476dd8e73d23b80c923a11a8360f6112533e1617e0b90e449b04e"
    },
    "candidates.json": {
      "byte_length": 2755,
      "sha256": "356619f0f2f0f8b3a68c2033a89587ae3dcc5a1f755e13bf5d4a0bca5f5296aa"
    },
    "request-body.json": {
      "byte_length": 5144,
      "sha256": "c53917260a6e23cdcf130f4d0b0e1704aa417c2010bdd63acdd46251f2a13a8b"
    },
    "request.json": {
      "byte_length": 2159,
      "sha256": "1cf667611e10eb632ce6ef24d65fc23d979cf4d0e46d42c639b1d991aa6aa9ff"
    },
    "response.bin": {
      "byte_length": 2110,
      "sha256": "645fe6005f6cfecf8e7c6866b1bd792b736eb5e280c059fc903173453a74e2b9"
    }
  },
  "binding": {
    "content_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "import_id": "3e39a439-e652-460d-b227-5b6d69b9ebe9",
    "manifest_sha256": null,
    "normalized_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "parse_id": null,
    "project_id": "6fae952d-10ae-46f7-88ef-25d6bb973f60",
    "source_id": "ea402487-9e4f-429e-9e12-be60df8c7c4d",
    "version_id": "63bd007b-175d-45bc-9598-57b66d2c40a9"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63852/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "52872572-04c4-4296-b788-7d2d35fdcb8d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2110,
    "omission_reason": null,
    "sha256": "645fe6005f6cfecf8e7c6866b1bd792b736eb5e280c059fc903173453a74e2b9"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6168,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5144,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8216
  },
  "validated_atoms": 1
}
```
