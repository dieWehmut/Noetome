# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6a7da5acdb68fadd3ac553700c0671c572026dbaca241687312a5b65c9a48819"
    },
    "request-body.json": {
      "byte_length": 7137,
      "sha256": "936ae7bc6f78b6d38a2d63e90314e05b51a78e6a490f9fd5636340041d8505bd"
    },
    "request.json": {
      "byte_length": 2219,
      "sha256": "efbdfe6d0c19b093dff025dbbd4d5756e1c0f164c661b4f2804d4af71d024e12"
    },
    "response.bin": {
      "byte_length": 1982,
      "sha256": "317b4f02c8f64fc6a122614ef6edbbcc76b60074599fcc75a0ae5fbbc46dca5c"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2f840497-759c-4235-ba02-6023af9826ca",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ff1a78b-c0e9-42d7-b966-909b166819f1",
    "source_id": "619acd34-4494-42a6-bdc9-42c6af9de229",
    "version_id": "d5a8fc14-b1b5-4bae-9d90-7c26ce021d9f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63925/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_RESPONSE",
      "message": "EXTRACT_API_RESPONSE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "7a7e1c7e-9cd2-47b9-917b-94e8d1d0d2f6",
  "request_strategy": "tangmao-deepseek-chat-nested-atoms-v4",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 1982,
    "omission_reason": null,
    "sha256": "317b4f02c8f64fc6a122614ef6edbbcc76b60074599fcc75a0ae5fbbc46dca5c"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8161,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7137,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10209
  },
  "validated_atoms": 0
}
```
