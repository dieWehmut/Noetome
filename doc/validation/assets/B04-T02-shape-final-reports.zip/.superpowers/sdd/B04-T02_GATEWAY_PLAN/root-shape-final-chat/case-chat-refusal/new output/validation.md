# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "33d34195199a257920be6cb697c6458ccca9a342983d300eacfcc746eb83f8a3"
    },
    "request-body.json": {
      "byte_length": 7137,
      "sha256": "a85dee72aa28bb53727b376fe7b7613aee70aa7d07f308db3d2e82edb924ed87"
    },
    "request.json": {
      "byte_length": 2213,
      "sha256": "7c691103525305057a649ce1dbfd651c5d4452ff54e89d987dd1018033753b8f"
    },
    "response.bin": {
      "byte_length": 1999,
      "sha256": "3f98db6bd5818d182f303f6780ccd7d4209803e82e0cdf2d52b042df277f94f8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "2f840497-759c-4235-ba02-6023af9826ca",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "6ff1a78b-c0e9-42d7-b966-909b166819f1",
    "source_id": "619acd34-4494-42a6-bdc9-42c6af9de229",
    "version_id": "d5a8fc14-b1b5-4bae-9d90-7c26ce021d9f"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:63855/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_REFUSAL",
      "message": "EXTRACT_API_REFUSAL：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "8b37b6b6-81fa-4de8-80ed-bdae324e58a7",
  "request_strategy": "tangmao-deepseek-chat-nested-atoms-v4",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1999,
    "omission_reason": null,
    "sha256": "3f98db6bd5818d182f303f6780ccd7d4209803e82e0cdf2d52b042df277f94f8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8161,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 7137,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10209
  },
  "validated_atoms": 0
}
```
