import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const [modulePath,inputPath]=process.argv.slice(2);
const {chromium}=await import(pathToFileURL(modulePath));
const input=JSON.parse(fs.readFileSync(inputPath,'utf8')),work=path.dirname(inputPath);
const browser=await chromium.connectOverCDP('http://localhost:'+input.port);
const obs=browser.contexts()[0].pages()[0], scripts=[];
const debug=await obs.context().newCDPSession(obs);
debug.on('Debugger.scriptParsed',x=>scripts.push(x));
await debug.send('Debugger.enable');
const result={scope:input.spec.scope,status:'running',notes:[]};let owned=false;
const norm=s=>s.replace(/\\/g,'/').toLowerCase();
try{
 await obs.waitForFunction(()=>window.app?.workspace?.layoutReady,{timeout:30000});
 result.identity=await obs.evaluate(()=>({appVersion:require('@electron/remote').app.getVersion(),userData:require('@electron/remote').app.getPath('userData'),vaultPath:window.app.vault.adapter.basePath,communityPlugins:Object.keys(window.app.plugins.plugins),electron:process.versions.electron,chromium:process.versions.chrome}));
 assert.equal(norm(result.identity.userData),norm(input.profile));assert.equal(norm(result.identity.vaultPath),norm(input.vault));owned=true;
 assert.equal(result.identity.appVersion,input.spec.runtime.app_version);assert.deepEqual(result.identity.communityPlugins,[]);
 for(const file of input.spec.notes){
  await obs.waitForFunction(p=>window.app.vault.getAbstractFileByPath(p),file);
  await obs.evaluate(async p=>window.app.workspace.getLeaf(false).openFile(window.app.vault.getAbstractFileByPath(p),{active:true,state:{mode:'preview'}}),file);
  await obs.waitForTimeout(1800);
  const data=await obs.evaluate(()=>{const v=document.querySelector('.workspace-leaf.mod-active .markdown-preview-view');return {file:window.app.workspace.getActiveFile()?.path,html:v.outerHTML,mathjaxVersion:window.MathJax?.version??null,math:Array.from(v.querySelectorAll('mjx-container')).map(e=>e.outerHTML),svg:v.querySelector('.mermaid svg')?.outerHTML??null,text:v.innerText};});
  fs.writeFileSync(path.join(work,'note-'+result.notes.length+'.html'),data.html,{flag:'wx'});result.notes.push(data);
  await obs.bringToFront();await obs.screenshot({path:path.join(work,'note-'+(result.notes.length-1)+'.png'),fullPage:true,timeout:60000});
 }
 result.runtime=await obs.evaluate(async()=>{const mermaid=window.mermaid??(await require('obsidian').loadMermaid());return {mathjaxVersion:window.MathJax?.version??null,mermaidExposedVersion:mermaid?.version??null,mermaidKeys:Object.keys(mermaid??{}),renderFunction:String(mermaid?.render).slice(0,400),loadedResources:performance.getEntriesByType('resource').map(r=>r.name),appPath:require('@electron/remote').app.getAppPath()};});
 result.executedScripts=[];
 for(const script of scripts.filter(s=>/app\.js|mathjax|pele|mermaid/.test(s.url))){
  const {scriptSource}=await debug.send('Debugger.getScriptSource',{scriptId:script.scriptId});
  result.executedScripts.push({url:script.url,sha256:crypto.createHash('sha256').update(scriptSource).digest('hex'),byte_length:Buffer.byteLength(scriptSource),sourcePrefix:scriptSource.slice(0,140),sourceSuffix:scriptSource.slice(-150)});
 }
 result.status='passed_identity_and_runtime_observation';
}catch(e){result.status='failed';result.error={message:String(e),stack:e.stack};process.exitCode=1;}
finally{fs.writeFileSync(path.join(work,'result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});if(owned){await obs.evaluate(()=>setTimeout(()=>require('@electron/remote').app.quit(),100)).catch(()=>{});await new Promise(r=>setTimeout(r,350));}await browser.close();}
console.log(JSON.stringify({status:result.status,identity:result.identity,runtime:result.runtime,scripts:result.executedScripts}));
