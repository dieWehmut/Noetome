import pathlib,json,hashlib,subprocess,os,sys,time
root=pathlib.Path(sys.argv[1]);cfg=json.loads((root/'root.json').read_bytes());manifest=json.loads((root/'snapshot.json').read_bytes());repo=pathlib.Path(cfg['repo_native']);target=pathlib.Path(cfg['target_native']);temp=root/'runtime-temp';temp.mkdir()
assert sys.platform=='win32' and sys.version_info[:3]==(3,12,14)
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
before={n:pin(repo/n) for n in manifest['files']};assert before==manifest['files'];sentinel=pin(root/'external-sentinel.txt')
env=os.environ.copy();env.update(NOETOME_TEST_PYTHON=cfg['fake_python_native'],NOETOME_PDF_PYTHON=cfg['python_native'],NOETOME_TEST_BINARY=str(target/'debug/noetome.exe'),CARGO_TARGET_DIR=str(target),PYTHONUTF8='1',TEMP=str(temp),TMP=str(temp))
for key in ['NOETOME_TANGMAO_API_KEY','NOETOME_TEST_SCAN_CREDENTIAL']:env.pop(key,None)
ps=['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(repo/'scripts/cargo_local.ps1')]
commands=[('cache-invalidate',ps+['clean','-p','noetome-cli']),('fmt',ps+['fmt','--all','--check']),('fixed-four-cache-tests',ps+['test','-p','noetome-cli','--lib','--locked','--offline','pdf_source_model::tests::source_cache_races','--','--test-threads=4','--nocapture'])]
records=[]
for name,argv in commands:
 print('START '+name,flush=True);start=time.monotonic();run=subprocess.run(argv,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=1800)
 out=root/(name+'.stdout.bin');err=root/(name+'.stderr.bin');out.write_bytes(run.stdout);err.write_bytes(run.stderr)
 r={'name':name,'argv':argv,'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':pin(out),'stderr':pin(err),'source_before_after_equal':{n:pin(repo/n) for n in manifest['files']}==before,'external_sentinel_unchanged':pin(root/'external-sentinel.txt')==sentinel};records.append(r)
 assert r['source_before_after_equal'] and r['external_sentinel_unchanged'];(root/'fixed-cache-commands.json').write_text(json.dumps(records,indent=2)+'\n');print('END '+name+' '+str(run.returncode),flush=True)
 if run.returncode:sys.exit(run.returncode)
observed=(root/'fixed-four-cache-tests.stderr.bin').read_text(encoding='utf8');assert all('Observed live raw sharing violation; mode='+str(i)+', outcome=' in observed for i in range(4))
(root/'fixed-cache-result.json').write_text(json.dumps({'status':'passed','actual_windows_guard_observed_modes':[0,1,2,3],'test_threads':4,'source_unchanged':True,'external_sentinel_unchanged':True,'commands':records},indent=2)+'\n')
