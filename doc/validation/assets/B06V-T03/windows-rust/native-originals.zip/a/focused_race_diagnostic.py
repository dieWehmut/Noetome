import pathlib,json,hashlib,subprocess,os,sys,shutil,datetime
root=pathlib.Path(sys.argv[1]);cfg=json.loads((root/'root.json').read_bytes());manifest=json.loads((root/'snapshot.json').read_bytes());repo=pathlib.Path(cfg['repo_native'])
def pin(p):
 b=pathlib.Path(p).read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
before={n:pin(repo/n) for n in manifest['files']};assert before==manifest['files']
unit=pathlib.Path(cfg['target_native'])/'debug/deps/noetome_cli-7f8b8bb98aad8247.exe';selected=root/'noetome-cli-unit-selected.exe';assert not selected.exists();shutil.copyfile(unit,selected);assert pin(unit)==pin(selected)
env=os.environ.copy();env.update(json.loads((root/'native-runtime.json').read_bytes())['selected_env']);env['PYTHONUTF8']='1'
for key in ['NOETOME_TANGMAO_API_KEY','NOETOME_TEST_SCAN_CREDENTIAL']:env.pop(key,None)
records=[]
for i in range(1,4):
 argv=[str(selected),'--exact','pdf_source_model::tests::source_cache_races::unknown_source_cache_entry_added_during_raw_read_is_rejected','--nocapture','--test-threads=1']
 result=subprocess.run(argv,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45)
 out=root/('focused-race-'+str(i)+'.stdout.bin');err=root/('focused-race-'+str(i)+'.stderr.bin');out.write_bytes(result.stdout);err.write_bytes(result.stderr)
 records.append({'attempt':i,'argv':argv,'exit_code':result.returncode,'stdout':pin(out),'stderr':pin(err),'actual_guard_observed':'Observed live raw sharing violation; mode=0, outcome=Applied' in result.stderr.decode('utf8','replace'),'source_before_after_equal':{n:pin(repo/n) for n in manifest['files']}==before})
 assert records[-1]['source_before_after_equal'];(root/'focused-race-diagnostic.json').write_text(json.dumps({'status':'running' if result.returncode==0 else 'failed','selected_unit_binary':pin(selected),'diagnostic_only':True,'records':records},indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True)
 if result.returncode:sys.exit(result.returncode)
(root/'focused-race-diagnostic.json').write_text(json.dumps({'status':'passed','selected_unit_binary':pin(selected),'diagnostic_only':True,'full_workspace_failure_not_erased':True,'records':records},indent=2)+'\n')
