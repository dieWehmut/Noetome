# 视觉目标能力与运行时证据

目标 profile 是用户选定的渲染环境声明。它不能独立证明环境已验收，`verified` 或 `supported` 为真也不能放宽来源语义和资源检查。Rust 的精确允许表位于 `visual_capabilities.rs`；独立 Python 校验器另维护自己的精确允许表，不读取 Rust 判断或报告的通过标志。

公式和扫描公式使用同一 Obsidian / MathJax 精确组合判断，随后分别检查原始表达、识别表达、未知符号、前提、单位和兼容策略。图像另检查本地附件、SVG 配置、颜色与几何。流程另检查完整来源图、方向、关系符号、判定分支及标签编码。未测版本或引擎混配触发有据回退；关键语义未知继续阻断。

## 流程目标版本

旧 Schema1 的必填字段和序列化保持原状：`schema_version=1`、`producer=flow_render_profile`、`profile_id`、`app`、`app_version`、`mermaid_version:string`、`flowchart_support`、`label_encoding=decimal_ascii_punctuation_v1`、`html_labels`。Schema1 完全禁止 `renderer` 字段，传入 null 也拒绝。

新 Schema2 保留这些字段，但要求 `mermaid_version:null`，并必填 `renderer={name,version,source_sha256}`。这三个字段分别表示实际引擎名称、可知版本和执行脚本的原字节 SHA256；SHA 必须是64个小写十六进制字符。拒绝缺失、额外字段、null renderer、旧新字段混配及不支持的 Schema。有效的 Schema2 输入不自动获得原生能力，未知组合仍回退。

Obsidian 1.15.0 实際加载 Pele 的 Mermaid 兼容接口，执行脚本头声明 Pele 1.8.0。它没有可报告的 Mermaid 运行时版本，因此不能把上游声明的 Mermaid 语法版本写成实际引擎版本。Pele 的 SVG 文本标签使用 `html_labels=false`；旧 Mermaid 原生组合的该字段仍为 true。

## 原生验收

兼容矩阵在明确的新测试 Vault 与隔离配置中执行，分别保留最低支持版和执行时官方稳定版的浅色、深色结果。安装可执行文件、两个 ASAR、实际应用版本及主题、MathJax window 版本、执行脚本 SHA、源文件和附件字节独立核对。

数学树、负号、脚标、分式与关系运算符，流程的实际节点形状、标签、线端点与箭头三角形，以及图片自然尺寸、本地附件点击和同实例栅格证据均须通过。Properties、Callout 和标题/块链接的手写阅读探针另行标明，不能作为产品已实现对应生成能力的证据。

运行时探测、输入准备、截图存在、成功报告及 Git 提交都不能代替上述验收。原始失败、冻结包勘误和检查器适配必须保存；勘误不能改变来源、独立语义预期或消除真实不兼容。

当前任务的完整通过组合在 B06V-T03 实际收束时登记；已验收最低组合保持 Obsidian1.6.7 / MathJax3.2.2、Mermaid10.6.1 及该版 SVG。本文件的 Schema2 定义本身不批准当前稳定版能力。
