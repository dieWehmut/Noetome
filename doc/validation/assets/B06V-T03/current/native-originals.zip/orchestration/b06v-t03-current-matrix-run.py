"""Run the explicitly frozen current-version test matrix, one owned app at a time."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(sys.argv[1])
source = (Path(sys.argv[2]) if len(sys.argv) > 2 else base / 'source').absolute()
manifest = json.loads((base / 'source-before.json').read_bytes())
python = Path('/tmp/noetome-ui-venv/bin/python')
native = Path('/mnt/c/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
exe = Path('/mnt/d/Noetome/.artifacts/b06v-t03-runtime-20261106/win-x64/Obsidian.exe')
ps = Path('/mnt/c/WINDOWS/System32/WindowsPowerShell/v1.0/powershell.exe')
playwright = Path('/home/lyinn/.npm/_npx/314abffa6aaf2cd1/node_modules/playwright-core/index.mjs')
runtime = source / 'doc/validation/assets/B06V-T03/runtime/current-runtime-observed.json'
runtime_sha = hashlib.sha256(runtime.read_bytes()).hexdigest()
env = {key: value for key, value in os.environ.items() if not key.lower().endswith('_proxy')}
env.update({'NO_PROXY': 'localhost,127.0.0.1', 'no_proxy': 'localhost,127.0.0.1'})
packs = [('visual-compatibility-corrected-v2', 'c174f543947b6e72c7ef7e786624c4d2fa870342df79abcd9d0fc7fbb90cc60d'),
         ('visual-compatibility-flow-extensions', 'e9f6a8b0e86718a38dba5cbf5073c25ffb0a6e39ca0c1d8c43a3648f4952339e')]
rows = []
prior_path = base / 'prior-passed-events.jsonl'
prior_rows = [json.loads(line) for line in prior_path.read_text().splitlines()] if prior_path.exists() else []
assert all(row['status'] == 'passed' for row in prior_rows)
prior_keys = {(row['case_id'], row['theme']) for row in prior_rows}
for pack, anchor in packs:
    fixture = source / 'fixtures' / pack
    cases = json.loads((fixture / 'cases.json').read_bytes())['cases']
    # Test the changed math engine and renderer before the less complex formats.
    priority = {'formula-native': 0, 'formula-native-relational': 1, 'image-signed-arrows': 2,
                'flow-branch': 3, 'hand-authored-format-probe': 9}
    cases.sort(key=lambda row: priority.get(row['case_id'], 5))
    for case in cases:
        for theme in ['light', 'dark']:
            if (case['case_id'], theme) in prior_keys:
                continue
            name = case['case_id'] + '-' + theme
            prepared = base / ('prepared-' + name)
            captured = base / ('capture-' + name)
            row = {'case_id': case['case_id'], 'theme': theme, 'pack': pack,
                   'fixture_sha256': anchor, 'runtime_sha256': runtime_sha, 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
            prepare = [str(python), str(source / 'scripts/prepare_visual_compatibility.py'),
                       '--fixture-root', str(fixture), '--fixture-sha256', anchor,
                       '--runtime-record', str(runtime), '--runtime-sha256', runtime_sha,
                       '--case-id', case['case_id'], '--theme', theme, '--new-root', str(prepared)]
            jobs = [('prepare', prepare)]
            for stage, argv in jobs:
                run = subprocess.run(argv, env=env, cwd=source, capture_output=True)
                (base / (name + '-' + stage + '.stdout.bin')).write_bytes(run.stdout)
                (base / (name + '-' + stage + '.stderr.bin')).write_bytes(run.stderr)
                row[stage] = {'argv': argv, 'exit_code': run.returncode}
            if row['prepare']['exit_code'] == 0:
                argv = [str(python), str(source / 'doc/validation/assets/B06V-T01/native/launch_capture.py'),
                        str(prepared / 'selected-output'), str(prepared / 'capture-spec.json'), str(captured),
                        str(native), str(exe), str(ps), str(playwright), '--capture-script', str(prepared / 'capture_visual.mjs')]
                run = subprocess.run(argv, env=env, cwd=source, capture_output=True)
                (base / (name + '-capture.stdout.bin')).write_bytes(run.stdout)
                (base / (name + '-capture.stderr.bin')).write_bytes(run.stderr)
                row['capture'] = {'argv': argv, 'exit_code': run.returncode}
                if (captured / 'result.json').exists():
                    actual = json.loads((captured / 'result.json').read_bytes())
                    row['native_status'] = actual['status']
                    row['native_error'] = actual.get('error')
                if (captured / 'protection-cleanup.json').exists():
                    row['protection_cleanup'] = json.loads((captured / 'protection-cleanup.json').read_bytes())
            row['status'] = 'passed' if row.get('capture', {}).get('exit_code') == 0 and row.get('native_status') == 'passed' else 'failed'
            rows.append(row)
            with (base / 'events.jsonl').open('a', encoding='utf8') as out:
                out.write(json.dumps(row, ensure_ascii=False) + '\n')
                out.flush()
            print(json.dumps({'case': name, 'status': row['status'], 'error': row.get('native_error')}, ensure_ascii=False), flush=True)
            if row['prepare']['exit_code'] != 0:
                raise RuntimeError('Preparation failed; resolve its recorded stderr before more cases')
            # Every launcher must finish its owned process cleanup before another
            # instance is allowed, including cases with a semantic failure.
            clean = row.get('protection_cleanup', {}).get('cleanup')
            if 'capture' in row and not (clean and clean['ownedPidAbsent'] and clean['ownedListenerAbsent'] and clean['profileProcessCount'] == 0):
                raise RuntimeError('Owned process cleanup is unconfirmed; do not restart this stream')
after = {}
for name in manifest:
    raw = (source / name).read_bytes()
    after[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'byte_length': len(raw)}
assert manifest == after
summary = {'status': 'passed' if all(row['status'] == 'passed' for row in rows) else 'failed',
           'rows': rows, 'case_count': len(rows), 'passed': sum(row['status'] == 'passed' for row in rows),
           'source_snapshot_unchanged': True, 'model_requests': 0, 'scientific_quality': 'not_run', 'published': False}
summary['previously_passed_rows'] = prior_rows
summary['combined_case_count'] = len(rows) + len(prior_rows)
(base / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({key: value for key, value in summary.items() if key not in ('rows', 'previously_passed_rows')}), flush=True)
sys.exit(0 if summary['status'] == 'passed' else 1)
