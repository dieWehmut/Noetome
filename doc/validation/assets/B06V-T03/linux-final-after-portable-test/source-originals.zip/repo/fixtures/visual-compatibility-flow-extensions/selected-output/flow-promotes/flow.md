# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "5bd11f2c-d77e-4b63-82e1-00d9a69669db",
  "binding": {
    "project_id": "656cad9e-cb1b-43d5-a565-63f5a402a686",
    "import_id": "289967e4-095e-42b4-b8db-26ccc1857f48",
    "source_id": "ac06fba6-8037-4fb5-aa74-6cefa974122b",
    "version_id": "2b168b97-41c2-4230-8889-8250cccafd85",
    "content_sha256": "7d126802e02e30cfcdd11139a963a3006d9643940b70b5fdc103ec6991b6352b",
    "normalized_sha256": "7d126802e02e30cfcdd11139a963a3006d9643940b70b5fdc103ec6991b6352b",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "issues": [],
  "process_document": {
    "process": {
      "title": "演示提示促进规则",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "启用演示优先控制",
        "description": "把演示优先控制设为启用",
        "criterion": null,
        "inputs": [
          "优先控制命令"
        ],
        "outputs": [
          "已启用优先控制"
        ],
        "conditions": [
          "演示模式开启"
        ],
        "exceptions": [
          "控制器断开时不生效"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "提示被选择的倾向",
        "description": "表示被促进的选择倾向，不提供比例或概率数值",
        "criterion": null,
        "inputs": [
          "提示候选"
        ],
        "outputs": [
          "选择倾向"
        ],
        "conditions": [
          "演示筛选器可用"
        ],
        "exceptions": [
          "筛选器不可用时未知"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "promotes",
        "branch_outcome": null,
        "conditions": [
          "演示优先通道接通"
        ],
        "exceptions": [
          "旁路开启时该促进不成立"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 144,
        "quote": "过程：\"演示提示促进规则\"。入口：s1。目标：[\"s2\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 637,
        "end_byte": 753,
        "quote": "关系 r1：s1 促进 s2。条件：[\"演示优先通道接通\"]。例外：[\"旁路开启时该促进不成立\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 145,
        "end_byte": 381,
        "quote": "步骤 s1：\"启用演示优先控制\"。说明：\"把演示优先控制设为启用\"。输入：[\"优先控制命令\"]。输出：[\"已启用优先控制\"]。条件：[\"演示模式开启\"]。例外：[\"控制器断开时不生效\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 382,
        "end_byte": 636,
        "quote": "步骤 s2：\"提示被选择的倾向\"。说明：\"表示被促进的选择倾向，不提供比例或概率数值\"。输入：[\"提示候选\"]。输出：[\"选择倾向\"]。条件：[\"演示筛选器可用\"]。例外：[\"筛选器不可用时未知\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": "flowchart",
  "decision": {
    "rule_id": "verified_directed_acyclic_flow_v1",
    "reason": "来源明确给出完整有向无环关系，且所选目标的当前图形及标签配置已有实测依据。",
    "fallback_reasons": []
  },
  "review_ir_fingerprint": {
    "sha256": "c955bcb6c02d47f24cf9023ecc00b2ee168d3b4b52890d57a42d01ef95e72830",
    "byte_length": 5303
  },
  "plan_fingerprint": {
    "sha256": "a25adb4b732f4da49c85b7aeb0763eec549b1e5a73867475eb1f91bfb3886ec2",
    "byte_length": 10042
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 9,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "flow_edges": 1,
    "flow_nodes": 2,
    "inhibits_relations": 0,
    "links": 5,
    "node_conditions": 2,
    "node_exceptions": 2,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 1,
    "relation_conditions": 1,
    "relation_exceptions": 1,
    "relations": 1,
    "rendered_notes": 2,
    "sequence_relations": 0,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "b278082970933d3c42f13bb6c0771ecd26bad8faa51ee78d5a867d8617cefe70",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "6b75b0c978a95e14814eaaf5d4f6a5a7b19883a033139641914f2c9e4abf3967",
      "byte_length": 2775
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "b278082970933d3c42f13bb6c0771ecd26bad8faa51ee78d5a867d8617cefe70",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "6b75b0c978a95e14814eaaf5d4f6a5a7b19883a033139641914f2c9e4abf3967",
      "byte_length": 2775
    },
    ".review-.owner.json": {
      "sha256": "730d9f3d541959b6e088fe6a7f8637c6b982f35720ad5350c6a332cf5d67e079",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "ec23fdfe6f28f560dc110bbabef5d31ad17eecac0842333480cd8b0e366f7d0c",
      "byte_length": 1682
    },
    ".review-process-ir.json": {
      "sha256": "c955bcb6c02d47f24cf9023ecc00b2ee168d3b4b52890d57a42d01ef95e72830",
      "byte_length": 5303
    },
    ".review-review.json": {
      "sha256": "ba687c4231c1a1bfb148fbd1e7ef0fec08d8d0c8e1b55f56550d0fd642340d36",
      "byte_length": 6483
    },
    ".review-review.md": {
      "sha256": "5b492d5d7a4832794b68d856489bb6d64205a29e94bdfacf09bec484d9df87c3",
      "byte_length": 6666
    },
    ".source.json": {
      "sha256": "ec23fdfe6f28f560dc110bbabef5d31ad17eecac0842333480cd8b0e366f7d0c",
      "byte_length": 1682
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "6761d663e4ec906102056909b2ee3f10eab9814cb9962abfa1035c73d66bcda0",
      "byte_length": 679,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 80
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 94,
          "end_byte": 355
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n0",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 385,
          "end_byte": 417
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_node",
          "item_id": "n1",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 418,
          "end_byte": 450
        },
        {
          "section_id": "flow",
          "block_id": "process_diagram",
          "kind": "diagram_edge",
          "item_id": "e0",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 451,
          "end_byte": 479
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 485,
          "end_byte": 539
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 540,
          "end_byte": 585
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 586,
          "end_byte": 631
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 632,
          "end_byte": 677
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "1c96e6b112a1135727673ca709b8627772293badce972a8e0c85d9a295e8cbbc",
      "byte_length": 1135,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 178
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 206,
          "end_byte": 487
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 515,
          "end_byte": 814
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 842,
          "end_byte": 1062
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 1085,
          "end_byte": 1133
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "b278082970933d3c42f13bb6c0771ecd26bad8faa51ee78d5a867d8617cefe70",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "6b75b0c978a95e14814eaaf5d4f6a5a7b19883a033139641914f2c9e4abf3967",
      "byte_length": 2775
    },
    ".owner.json": {
      "sha256": "a37413b500aa46c29af2e8c170079f1e14bd948c946576bdb1c29e7062c3afb7",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "b278082970933d3c42f13bb6c0771ecd26bad8faa51ee78d5a867d8617cefe70",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "6b75b0c978a95e14814eaaf5d4f6a5a7b19883a033139641914f2c9e4abf3967",
      "byte_length": 2775
    },
    ".review-.owner.json": {
      "sha256": "730d9f3d541959b6e088fe6a7f8637c6b982f35720ad5350c6a332cf5d67e079",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "ec23fdfe6f28f560dc110bbabef5d31ad17eecac0842333480cd8b0e366f7d0c",
      "byte_length": 1682
    },
    ".review-process-ir.json": {
      "sha256": "c955bcb6c02d47f24cf9023ecc00b2ee168d3b4b52890d57a42d01ef95e72830",
      "byte_length": 5303
    },
    ".review-review.json": {
      "sha256": "ba687c4231c1a1bfb148fbd1e7ef0fec08d8d0c8e1b55f56550d0fd642340d36",
      "byte_length": 6483
    },
    ".review-review.md": {
      "sha256": "5b492d5d7a4832794b68d856489bb6d64205a29e94bdfacf09bec484d9df87c3",
      "byte_length": 6666
    },
    ".source.json": {
      "sha256": "ec23fdfe6f28f560dc110bbabef5d31ad17eecac0842333480cd8b0e366f7d0c",
      "byte_length": 1682
    },
    "plan.json": {
      "sha256": "a25adb4b732f4da49c85b7aeb0763eec549b1e5a73867475eb1f91bfb3886ec2",
      "byte_length": 10042
    },
    "流程总览.md": {
      "sha256": "6761d663e4ec906102056909b2ee3f10eab9814cb9962abfa1035c73d66bcda0",
      "byte_length": 679
    },
    "过程明细.md": {
      "sha256": "1c96e6b112a1135727673ca709b8627772293badce972a8e0c85d9a295e8cbbc",
      "byte_length": 1135
    }
  }
}
```
