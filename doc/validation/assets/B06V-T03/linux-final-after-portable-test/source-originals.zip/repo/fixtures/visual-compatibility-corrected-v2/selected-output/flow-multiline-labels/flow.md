# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "d2de1076-731e-4942-8b08-fff0a7fce114",
  "binding": {
    "project_id": "1b6729da-2c47-40ab-bd5e-9803b51fde04",
    "import_id": "63c9c26c-2ddb-4aca-9dbb-b158576daace",
    "source_id": "9e2e7268-fec1-4705-aa22-98baccaf13f3",
    "version_id": "650b31ab-0de4-4cc8-89e8-9c45f4aec8c3",
    "content_sha256": "07ffaee58e8b3f349addf15fd2eb7df5a49357fa808c65fc5728bb2c1bd7d076",
    "normalized_sha256": "07ffaee58e8b3f349addf15fd2eb7df5a49357fa808c65fc5728bb2c1bd7d076",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_LABEL_WHITESPACE_FALLBACK"
  ],
  "issues": [],
  "process_document": {
    "process": {
      "title": "多行标签的保真流程",
      "entry": "s1",
      "goals": [
        "s2"
      ],
      "conditions": [],
      "exceptions": [
        "不可读资料需复核"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "检查\n卡片\t[α]",
        "description": "完整保留来源标签中的换行和制表符",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "检查结果"
        ],
        "conditions": [],
        "exceptions": [
          "卡片缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "记录检查结果",
        "description": "记录来源明示的检查结果",
        "criterion": null,
        "inputs": [
          "检查结果"
        ],
        "outputs": [
          "检查记录"
        ],
        "conditions": [
          "检查完成"
        ],
        "exceptions": []
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [],
        "exceptions": [
          "检查未完成时不得登记"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 127,
        "quote": "过程：\"多行标签的保真流程\"。入口：s1。目标：[\"s2\"]。条件：[]。例外：[\"不可读资料需复核\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 513,
        "end_byte": 609,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[]。例外：[\"检查未完成时不得登记\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 128,
        "end_byte": 331,
        "quote": "步骤 s1：\"检查\\n卡片\\t[α]\"。说明：\"完整保留来源标签中的换行和制表符\"。输入：[\"样例卡\"]。输出：[\"检查结果\"]。条件：[]。例外：[\"卡片缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 332,
        "end_byte": 512,
        "quote": "步骤 s2：\"记录检查结果\"。说明：\"记录来源明示的检查结果\"。输入：[\"检查结果\"]。输出：[\"检查记录\"]。条件：[\"检查完成\"]。例外：[]。"
      }
    ]
  },
  "profile": {
    "schema_version": 1,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_6_7_flowchart",
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mermaid_version": "10.6.1",
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": true
  },
  "representation": "ordered_list",
  "decision": {
    "rule_id": "verified_relations_text_fallback_v1",
    "reason": "来源关系已通过流程语义检查；当前显示条件采用有据文字回退。",
    "fallback_reasons": [
      {
        "code": "FLOW_LABEL_WHITESPACE_FALLBACK",
        "object_ids": [
          "s1"
        ],
        "message": "图标签含当前显示契约未确认可保真的空白，改用预格式文字保留原字符。"
      }
    ]
  },
  "review_ir_fingerprint": {
    "sha256": "8aa5f79722f6fe5d3ad35db0bbd005579429adc8ab8ca6ce9249a399408fdd37",
    "byte_length": 4773
  },
  "plan_fingerprint": {
    "sha256": "dfb5585d5d695be4af1bf840fa5a5fa46fe586924a2bc108c33329260f4580a4",
    "byte_length": 12440
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "content_mappings": 10,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 4,
    "flow_edges": 1,
    "flow_nodes": 2,
    "inhibits_relations": 0,
    "links": 8,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 2,
    "node_outputs": 2,
    "parsed_statements": 4,
    "process_conditions": 0,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 1,
    "relations": 1,
    "rendered_notes": 2,
    "sequence_relations": 1,
    "source_statements": 4,
    "steps": 2,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "6c7d6ac8240be7f390a0148304eee70e5657cfb8203e5c337e795dd612f60adb",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "6c7d6ac8240be7f390a0148304eee70e5657cfb8203e5c337e795dd612f60adb",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".review-.owner.json": {
      "sha256": "80fee289fabd7b9d7efe4c87d62f07e670951691f8385ab90e49f895abea199e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "a55730a94b7674d64e1b6176ccce45dc584791214f08f0001154838f63f7db33",
      "byte_length": 1532
    },
    ".review-process-ir.json": {
      "sha256": "8aa5f79722f6fe5d3ad35db0bbd005579429adc8ab8ca6ce9249a399408fdd37",
      "byte_length": 4773
    },
    ".review-review.json": {
      "sha256": "7db25b743a1730369663c4b41e28e34c4dc6f4b879c383f816384a99844d6158",
      "byte_length": 6104
    },
    ".review-review.md": {
      "sha256": "5ecc102854b02dd6de5f1a715a577e7de0167181f7927e671938205d32835bb5",
      "byte_length": 6287
    },
    ".source.json": {
      "sha256": "a55730a94b7674d64e1b6176ccce45dc584791214f08f0001154838f63f7db33",
      "byte_length": 1532
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "bfb79aaeaea155c3c1e1c22390aca69c33a131fff600108f471bc41147c53861",
      "byte_length": 1738,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 83
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 97,
          "end_byte": 358
        },
        {
          "section_id": "flow",
          "block_id": "fallback_reason",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 372,
          "end_byte": 471
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s1",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 702,
          "end_byte": 1006
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s2",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1079,
          "end_byte": 1359
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r1",
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 1455,
          "end_byte": 1679
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 477,
          "end_byte": 531
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 532,
          "end_byte": 577
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 578,
          "end_byte": 623
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 624,
          "end_byte": 669
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s1",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 1018,
          "end_byte": 1063
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s2",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1371,
          "end_byte": 1416
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r1",
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 1691,
          "end_byte": 1736
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "d9f133b91f0db5c51fa403ec3a95bae2611e7a73da75878eefc5f5d77c72b2d1",
      "byte_length": 1040,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 180
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 208,
          "end_byte": 473
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 501,
          "end_byte": 745
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "r1",
            "s1",
            "s2"
          ],
          "start_byte": 773,
          "end_byte": 967
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 990,
          "end_byte": 1038
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "6c7d6ac8240be7f390a0148304eee70e5657cfb8203e5c337e795dd612f60adb",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".owner.json": {
      "sha256": "0e8fa157a9d8e8c2bb151e238d00e3b4890dd005aadbd4f619217e1540da07fc",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "8db17e503ee448a58114f175dc6d38aae00424422b0c11d88a4e26d210c23c04",
      "byte_length": 296
    },
    ".review-.case.json": {
      "sha256": "6c7d6ac8240be7f390a0148304eee70e5657cfb8203e5c337e795dd612f60adb",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "79999b21da68b9e80f4313cfce72821163a965540950acc631a9b9ba98d288c4",
      "byte_length": 2412
    },
    ".review-.owner.json": {
      "sha256": "80fee289fabd7b9d7efe4c87d62f07e670951691f8385ab90e49f895abea199e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "a55730a94b7674d64e1b6176ccce45dc584791214f08f0001154838f63f7db33",
      "byte_length": 1532
    },
    ".review-process-ir.json": {
      "sha256": "8aa5f79722f6fe5d3ad35db0bbd005579429adc8ab8ca6ce9249a399408fdd37",
      "byte_length": 4773
    },
    ".review-review.json": {
      "sha256": "7db25b743a1730369663c4b41e28e34c4dc6f4b879c383f816384a99844d6158",
      "byte_length": 6104
    },
    ".review-review.md": {
      "sha256": "5ecc102854b02dd6de5f1a715a577e7de0167181f7927e671938205d32835bb5",
      "byte_length": 6287
    },
    ".source.json": {
      "sha256": "a55730a94b7674d64e1b6176ccce45dc584791214f08f0001154838f63f7db33",
      "byte_length": 1532
    },
    "plan.json": {
      "sha256": "dfb5585d5d695be4af1bf840fa5a5fa46fe586924a2bc108c33329260f4580a4",
      "byte_length": 12440
    },
    "流程总览.md": {
      "sha256": "bfb79aaeaea155c3c1e1c22390aca69c33a131fff600108f471bc41147c53861",
      "byte_length": 1738
    },
    "过程明细.md": {
      "sha256": "d9f133b91f0db5c51fa403ec3a95bae2611e7a73da75878eefc5f5d77c72b2d1",
      "byte_length": 1040
    }
  }
}
```
