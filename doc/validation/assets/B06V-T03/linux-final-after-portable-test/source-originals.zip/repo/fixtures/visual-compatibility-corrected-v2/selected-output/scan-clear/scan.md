# 选定扫描公式重建预览报告

状态：preview_ready；预览：saved；知识：pending；科学质量：not_run；发布：false。

识别模式：live；实际网络尝试：1。价格、Token tokenizer 和账单未知；原始 TeX 未知。

选定原扫描区域、单请求正文、实际 HTTP 原响应、已核实用量与语义核对分开保存；本地人工 HTTP 服务只验证工程契约。

```json
{
  "schema_version": 1,
  "producer": "knowledge_scan_formula",
  "scope": "selected_scan_formula_v1",
  "request_id": "a6fb319d-e6a9-4a0e-b60a-f084fb0e9d45",
  "status": "preview_ready",
  "preview_status": "saved",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "published": false,
  "network_calls": 1,
  "paid_calls": null,
  "case": {
    "schema_version": 1,
    "purpose": "scan_formula",
    "selection_id": "scan_scalar_clear",
    "title": "单页扫描公式清晰",
    "source_kind": "scanned_page",
    "pdf": {
      "file": "page.pdf",
      "sha256": "147a454d1814793df52120417cca2172daa8dd81bfb6e242cbb64935ad911803"
    },
    "page": {
      "file": "page.png",
      "sha256": "b416f4d3aea278bb3a1d05682183b7ad56a4c9bfb6bbb7bde61b9185343028c5",
      "page": 1,
      "canvas": [
        800,
        1000
      ]
    },
    "region": {
      "file": "region.png",
      "sha256": "8b84103383f6d4a6fc4054f2221c3ff0e41bf355b4db09a3b085e0af0ec2d4bc",
      "bounds": [
        120,
        175,
        560,
        200
      ],
      "legibility": "clear"
    },
    "semantics": {
      "file": "semantics.json",
      "sha256": "83be529ba9430eb748ae185553718607e0c61e0d417519b3c66697c8d44e8547"
    }
  },
  "semantics": {
    "schema_version": 1,
    "producer": "author_scan_declaration",
    "expression": "x_i = -\\frac{a_i}{b_i}",
    "symbols": [
      {
        "symbol": "x",
        "definition": "Reported displacement.",
        "unit": "mg"
      },
      {
        "symbol": "a",
        "definition": "Input amount.",
        "unit": "mg"
      },
      {
        "symbol": "b",
        "definition": "Positive scale.",
        "unit": "dimensionless"
      },
      {
        "symbol": "i",
        "definition": "Sample index.",
        "unit": "dimensionless"
      }
    ],
    "conditions": [
      "a_i >= 0.",
      "b_i > 0."
    ],
    "ranges": [
      "i in {1, 2}.",
      "x_i <= 0."
    ],
    "exceptions": [
      "If b_i = 0, the expression is undefined."
    ],
    "uncertainties": []
  },
  "profile": {
    "schema_version": 1,
    "app": "Obsidian",
    "app_version": "1.6.7",
    "mathjax_version": "3.2.2",
    "native_math": true,
    "compatibility_dfrac": true,
    "local_images": true,
    "verified": true
  },
  "checks": {
    "source_preservation": "passed",
    "region_match": "passed",
    "recognition": "passed",
    "expression_match": "passed",
    "symbol_definitions": "passed",
    "semantic_review": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "decision": {
    "representation": "native_math",
    "fallback_reasons": [],
    "compatibility_rewrites": [],
    "issue_codes": []
  },
  "recognition": {
    "schema_version": 1,
    "recognized_tex": "x_i = -\\frac{a_i}{b_i}",
    "uncertainties": []
  },
  "api": {
    "actual_model": "deepseek-flash",
    "confidence": null,
    "configured_model": "deepseek-flash",
    "endpoint": "https://ai.1343263.xyz/v1/chat/completions",
    "errors": [],
    "finish_reason": "stop",
    "http_request_id": "20be346a-fc58-4136-a1a1-501ea859c2f2",
    "http_status": 200,
    "provider": "openai_chat_completions",
    "request_strategy": "tangmao-vision-scan-v1",
    "response_complete": true,
    "response_id": "chatcmpl-1793960728",
    "response_receipt": {
      "byte_length": 1063,
      "omission_reason": null,
      "sha256": "a313a86a99ef3c7b797040c746e4c52a7256fdf4d48129304ffc2e88de2502f0"
    },
    "service_tier": null,
    "transport_mode": "live",
    "usage": {
      "input_reserved_tokens": 8178,
      "model_tokenizer": null,
      "model_usage": {
        "input_tokens": 444,
        "input_tokens_details": {
          "cached_tokens": 0
        },
        "output_tokens": 210,
        "total_tokens": 654
      },
      "model_usage_status": "validated",
      "network_attempts": 1,
      "paid_calls": null,
      "price_usd": null,
      "raw_model_usage": {
        "completion_tokens": 210,
        "prompt_tokens": 444,
        "prompt_tokens_details": {
          "cached_tokens": 0
        },
        "total_tokens": 654
      },
      "real_model_calls": 1,
      "request_utf8_bytes": 7154,
      "reservation_policy": "request_utf8_bytes_plus_1024_v1",
      "reserved_tokens": 16370
    }
  },
  "recognition_request_fingerprint": {
    "sha256": "43de160131c6b2a11416ee8c4446a442f859e27e673f489dc575998174856855",
    "byte_length": 7154
  },
  "recognition_response_fingerprint": {
    "sha256": "a313a86a99ef3c7b797040c746e4c52a7256fdf4d48129304ffc2e88de2502f0",
    "byte_length": 1063
  },
  "tokens": [
    "x",
    "_",
    "i",
    "=",
    "-",
    "\\frac",
    "{",
    "a",
    "_",
    "i",
    "}",
    "{",
    "b",
    "_",
    "i",
    "}"
  ],
  "plan_fingerprint": {
    "sha256": "e5b1bd52adac36b1c7529b3a6949e4fd0a3bea8ae7bade463a55a935f35c6dfb",
    "byte_length": 2290
  },
  "inputs": {
    "original.pdf": {
      "sha256": "147a454d1814793df52120417cca2172daa8dd81bfb6e242cbb64935ad911803",
      "byte_length": 37603
    },
    "original.png": {
      "sha256": "8b84103383f6d4a6fc4054f2221c3ff0e41bf355b4db09a3b085e0af0ec2d4bc",
      "byte_length": 4292
    },
    "page.png": {
      "sha256": "b416f4d3aea278bb3a1d05682183b7ad56a4c9bfb6bbb7bde61b9185343028c5",
      "byte_length": 45594
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "source-api-config.json": {
      "sha256": "ac225b10685fbd6afb80fe4298787b6c44a11078c874697473becc8f3c54ed3a",
      "byte_length": 590
    },
    "source-case.json": {
      "sha256": "0ca6d59df807c4b9811b2c17e69bc5b4be7a245b9df586c15a95c1299e3c9e83",
      "byte_length": 821
    },
    "source-semantics.json": {
      "sha256": "83be529ba9430eb748ae185553718607e0c61e0d417519b3c66697c8d44e8547",
      "byte_length": 725
    }
  },
  "files": [
    {
      "relative_path": "扫描公式预览.md",
      "content_sha256": "c341037053a1f88fe3678ea1bec78efd93e47917808de683b8174d84b5dd9b50",
      "byte_length": 1095,
      "mappings": [
        {
          "kind": "title",
          "source_field": "case.title",
          "start_byte": 41,
          "end_byte": 65
        },
        {
          "kind": "expression",
          "source_field": "compiled_expression",
          "start_byte": 85,
          "end_byte": 105
        },
        {
          "kind": "recognized_expression",
          "source_field": "recognition.recognized_tex",
          "start_byte": 235,
          "end_byte": 257
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[0].symbol",
          "start_byte": 313,
          "end_byte": 314
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[0].definition",
          "start_byte": 339,
          "end_byte": 361
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[0].unit",
          "start_byte": 386,
          "end_byte": 388
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[1].symbol",
          "start_byte": 427,
          "end_byte": 428
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[1].definition",
          "start_byte": 453,
          "end_byte": 466
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[1].unit",
          "start_byte": 491,
          "end_byte": 493
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[2].symbol",
          "start_byte": 532,
          "end_byte": 533
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[2].definition",
          "start_byte": 558,
          "end_byte": 573
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[2].unit",
          "start_byte": 598,
          "end_byte": 611
        },
        {
          "kind": "symbol",
          "source_field": "semantics.symbols[3].symbol",
          "start_byte": 650,
          "end_byte": 651
        },
        {
          "kind": "definition",
          "source_field": "semantics.symbols[3].definition",
          "start_byte": 676,
          "end_byte": 689
        },
        {
          "kind": "unit",
          "source_field": "semantics.symbols[3].unit",
          "start_byte": 714,
          "end_byte": 727
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[0]",
          "start_byte": 758,
          "end_byte": 767
        },
        {
          "kind": "condition",
          "source_field": "semantics.conditions[1]",
          "start_byte": 781,
          "end_byte": 789
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[0]",
          "start_byte": 814,
          "end_byte": 826
        },
        {
          "kind": "range",
          "source_field": "semantics.ranges[1]",
          "start_byte": 840,
          "end_byte": 849
        },
        {
          "kind": "exception",
          "source_field": "semantics.exceptions[0]",
          "start_byte": 874,
          "end_byte": 914
        },
        {
          "kind": "attachment_link",
          "source_field": "case.region",
          "start_byte": 937,
          "end_byte": 971
        },
        {
          "kind": "attachment_link",
          "source_field": "case.page",
          "start_byte": 973,
          "end_byte": 1000
        },
        {
          "kind": "attachment_link",
          "source_field": "recognition",
          "start_byte": 1002,
          "end_byte": 1033
        },
        {
          "kind": "attachment_link",
          "source_field": "recognition.recognized_tex",
          "start_byte": 1035,
          "end_byte": 1065
        },
        {
          "kind": "attachment_link",
          "source_field": "case.pdf",
          "start_byte": 1067,
          "end_byte": 1093
        }
      ]
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "d2a09400b9fe92ec4e720cfc41e433d3703c564d3cd76f65a179d8420c0424f1",
      "byte_length": 162
    },
    "compiled.tex": {
      "sha256": "10d4289783c1ae5b281008f169ccad7a8c961d7f178b47c38d09e4279bb2abf2",
      "byte_length": 20
    },
    "original.pdf": {
      "sha256": "147a454d1814793df52120417cca2172daa8dd81bfb6e242cbb64935ad911803",
      "byte_length": 37603
    },
    "original.png": {
      "sha256": "8b84103383f6d4a6fc4054f2221c3ff0e41bf355b4db09a3b085e0af0ec2d4bc",
      "byte_length": 4292
    },
    "page.png": {
      "sha256": "b416f4d3aea278bb3a1d05682183b7ad56a4c9bfb6bbb7bde61b9185343028c5",
      "byte_length": 45594
    },
    "plan.json": {
      "sha256": "e5b1bd52adac36b1c7529b3a6949e4fd0a3bea8ae7bade463a55a935f35c6dfb",
      "byte_length": 2290
    },
    "profile.json": {
      "sha256": "2025dadc2bd5d6a3ab508ff3b3d10e62330d3f1ad0e5571841ae29e86c00b553",
      "byte_length": 201
    },
    "recognition.json": {
      "sha256": "85e5843f23f0b34487898aeeef56390f6989c4b65950b7da574a3a42455f69ef",
      "byte_length": 95
    },
    "recognized.tex": {
      "sha256": "02184791e0b11cff2797c0772f014919fe392fe862b82c295cd77b3c451e537e",
      "byte_length": 22
    },
    "request-body.json": {
      "sha256": "43de160131c6b2a11416ee8c4446a442f859e27e673f489dc575998174856855",
      "byte_length": 7154
    },
    "request.json": {
      "sha256": "61c8fc0bd89452e19af6d62b8cf882887a158998670999a6b91a9f28a2b11d43",
      "byte_length": 1425
    },
    "response.bin": {
      "sha256": "a313a86a99ef3c7b797040c746e4c52a7256fdf4d48129304ffc2e88de2502f0",
      "byte_length": 1063
    },
    "source-api-config.json": {
      "sha256": "ac225b10685fbd6afb80fe4298787b6c44a11078c874697473becc8f3c54ed3a",
      "byte_length": 590
    },
    "source-case.json": {
      "sha256": "0ca6d59df807c4b9811b2c17e69bc5b4be7a245b9df586c15a95c1299e3c9e83",
      "byte_length": 821
    },
    "source-semantics.json": {
      "sha256": "83be529ba9430eb748ae185553718607e0c61e0d417519b3c66697c8d44e8547",
      "byte_length": 725
    },
    "扫描公式预览.md": {
      "sha256": "c341037053a1f88fe3678ea1bec78efd93e47917808de683b8174d84b5dd9b50",
      "byte_length": 1095
    }
  }
}
```
