"""Task-local offline validation orchestrator; never changes worktree inputs."""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time

WORKTREE = Path('/home/lyinn/project/Noetome')
ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'repo'
PYTHON = Path('/tmp/noetome-b05-t03-python/bin/python')
ELF = WORKTREE / '.artifacts/b06v-t03-knowledge-final-build/noetome'
ELF_SHA = '038f106a483945b31594009598decec882bc19d53c73ffc1b462c778b793bfe4'

def pin(raw):
    return dict(sha256=hashlib.sha256(raw).hexdigest(), byte_length=len(raw))

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def pins(base, names):
    return {name:pin((base/name).read_bytes()) for name in sorted(names)}

def snapshot():
    assert not REPO.exists(), 'only a fresh snapshot is allowed'
    base = json.loads((WORKTREE/'.artifacts/b06v-t02-continuation-linux-final-03-20261106/source-before.json').read_text())
    names = set(base)
    for folder in ('scripts','tests','fixtures','dev-log','crates/noetome-cli/src'):
        names.update(p.relative_to(WORKTREE).as_posix() for p in (WORKTREE/folder).rglob('*')
                     if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
    for folder in ('doc/technical','doc/requirements','doc/execution','doc/standards','doc/templates'):
        names.update(p.relative_to(WORKTREE).as_posix() for p in (WORKTREE/folder).rglob('*') if p.is_file())
    names.add('doc/README.md')
    collectors = [
        'doc/validation/assets/B06-T01/obsidian/capture_obsidian.mjs',
        'doc/validation/assets/B06-T02/obsidian/capture_obsidian.mjs',
        'doc/validation/assets/B06-T03/native/capture_formula.mjs',
        'doc/validation/assets/B06V-T01/native/capture_image.mjs',
    ]
    names.update(collectors)
    fixed = json.loads((WORKTREE/'doc/validation/assets/B06V-T03/review/flow-target-test-portable/new-source-pins.json').read_text())
    # This receipt is a plain path-to-pin map, independent of runtime outputs.
    if 'files' in fixed:
        fixed = fixed['files']
    for name, wanted in fixed.items():
        assert pin((WORKTREE/name).read_bytes()) == wanted, 'fixed Python source changed: '+name
    for name, sha in {
        'scripts/prepare_visual_compatibility.py':'9c28fd119634c14d2c28d24451799175fe3fa9aceaeae10566f000e52767c83f',
        'tests/test_prepare_visual_compatibility.py':'324fa89215b147da96284f3e6d8a39cadc7ebceeef0bf10a25003449d2e1c796',
    }.items():
        assert pin((WORKTREE/name).read_bytes())['sha256'] == sha, 'preparer source not fixed'
    selected_before = pins(WORKTREE, names)
    for name in sorted(names):
        source, target = WORKTREE/name, REPO/name
        assert source.is_file() and not source.is_symlink(), 'public source must be ordinary: '+name
        raw = source.read_bytes()
        assert pin(raw) == selected_before[name], 'source changed during snapshot: '+name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        target.chmod(0o644)
    raw = ELF.read_bytes()
    assert pin(raw)['sha256'] == ELF_SHA, 'final CLI fingerprint mismatch'
    (REPO/'target/debug').mkdir(parents=True)
    (REPO/'target/compiler-temp').mkdir()
    for name in ('target/debug/noetome','target/debug/noetome.exe'):
        target = REPO/name
        target.write_bytes(raw)
        target.chmod(0o555)
        names.add(name)
    # Copied inputs remain ordinary files because adversarial tests copy their
    # modes into new writable mutation roots. Before/after SHA pins establish
    # immutable input bytes; permissions are not counted as validation.
    before = pins(REPO, names)
    relevant = {name for name in names if name.startswith(('scripts/','tests/','crates/noetome-cli/src/'))}
    save(ROOT/'source-before.json', before)
    save(ROOT/'worktree-related-before.json', pins(WORKTREE, relevant))
    save(ROOT/'snapshot-receipt.json', dict(status='prepared',source_worktree=str(WORKTREE),snapshot=str(REPO),
        baseline_source_manifest=str(WORKTREE/'.artifacts/b06v-t02-continuation-linux-final-03-20261106/source-before.json'),
        baseline_files=len(base),source_files=len(names)-2,total_pinned_files=len(names),source_bytes=sum(v['byte_length'] for k,v in before.items() if not k.startswith('target/')),
        source_pin=pin((ROOT/'source-before.json').read_bytes()),python=str(PYTHON),python_version=subprocess.check_output([str(PYTHON),'--version'],text=True).strip(),
        final_binary_source=str(ELF),binary=pin(raw),aliases=['target/debug/noetome','target/debug/noetome.exe'],
        aliases_are_regular_files=True,compiler_temp_is_regular_directory=True,collectors=collectors,
        scope='copied public author/source inputs, fixed Python and final CLI production subset; actively edited Rust test helpers are excluded from worktree equality',
        real_model_calls=0,paid_calls=0,real_ledger_access='not_requested_not_read_not_modified'))
    return names, relevant

def environment():
    # Only operating-system execution settings are inherited. No API keys,
    # proxy, credential selector, service ledger or app settings are inherited.
    allowed = ('PATH','LANG','LC_ALL','TZ','USER','LOGNAME')
    result = {name:os.environ[name] for name in allowed if name in os.environ}
    result.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',NOETOME_TEST_BINARY=str(REPO/'target/debug/noetome'),TMPDIR=str(ROOT/'temp'))
    return result

def run(label, argv):
    folder = ROOT/'runs'/label
    folder.mkdir(parents=True)
    started = time.time()
    with (folder/'stdout.bin').open('wb') as out, (folder/'stderr.bin').open('wb') as err:
        child = subprocess.Popen(argv,cwd=REPO,env=environment(),stdout=out,stderr=err)
        save(folder/'launch.json',dict(argv=argv,cwd=str(REPO),pid=child.pid,started_unix=started,
            environment_names=sorted(environment()),inherited_key_env_count=0,selected_binary=str(REPO/'target/debug/noetome')))
        code=child.wait()
    receipt=dict(label=label,argv=argv,cwd=str(REPO),exit_code=code,started_unix=started,ended_unix=time.time(),elapsed_seconds=time.time()-started,
        stdout=pin((folder/'stdout.bin').read_bytes()),stderr=pin((folder/'stderr.bin').read_bytes()),real_model_calls=0,paid_calls=0)
    if label=='full-python':
        output=(folder/'stderr.bin').read_text(errors='replace')
        matched=re.search(r'^Ran (\d+) tests? in ([0-9.]+)s$',output,re.M)
        receipt.update(tests_run=int(matched[1]) if matched else None,
            skipped_tests=re.findall(r'^(.+?) \.\.\. skipped (.+)$',output,re.M),
            result_line=next((line for line in reversed(output.splitlines()) if line.startswith(('OK','FAILED'))),None))
    else:
        auditroot=ROOT/'audits'/label
        summary_path=auditroot/('summary.json' if label=='scan' else 'audit.json')
        if label=='table': summary_path=folder/'stdout.bin'
        if summary_path.exists():
            data=json.loads(summary_path.read_text())
            receipt.update(audit_summary_file=str(summary_path),audit_summary_pin=pin(summary_path.read_bytes()),audit_status=data.get('status'),
                ordinary_cli_calls=data.get('ordinary_cli_calls',len(data['commands']) if isinstance(data.get('commands'),list) else None),
                scenarios=len(data['scenarios']) if isinstance(data.get('scenarios'),list) else data.get('scenarios'))
    save(folder/'receipt.json',receipt)
    print(json.dumps({k:receipt[k] for k in ('label','exit_code','elapsed_seconds')},ensure_ascii=False),flush=True)
    return receipt

def main():
    assert sys.executable==str(PYTHON), 'selected absolute interpreter required'
    names,relevant=snapshot()
    (ROOT/'temp').mkdir()
    (ROOT/'audits').mkdir()
    cli=str(REPO/'target/debug/noetome')
    commands={
        'full-python':[str(PYTHON),'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],
    }
    save(ROOT/'run-plan.json',dict(commands=commands,real_model_calls=0,paid_calls=0,concurrency='independent copied inputs; separate generated roots'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        receipts=list(executor.map(lambda label:run(label,commands[label]),commands))
    after=pins(REPO,names)
    save(ROOT/'source-after.json',after)
    related_after=pins(WORKTREE,relevant)
    save(ROOT/'worktree-related-after.json',related_after)
    before=json.loads((ROOT/'source-before.json').read_text())
    related_before=json.loads((ROOT/'worktree-related-before.json').read_text())
    status='passed' if all(r['exit_code']==0 for r in receipts) and before==after and related_before==related_after else 'failed'
    save(ROOT/'actual-checks.json',dict(status=status,runs=receipts,snapshot_inputs_unchanged=before==after,worktree_related_subset_unchanged=related_before==related_after,
        copied_final_cli_unchanged=after['target/debug/noetome']['sha256']==ELF_SHA and after['target/debug/noetome.exe']['sha256']==ELF_SHA,
        real_model_calls=0,paid_calls=0,scientific_quality='not_run',native_app_capture='not_run',real_ledger_access='not_requested_not_read_not_modified'))
    return 0 if status=='passed' else 1

if __name__=='__main__':
    raise SystemExit(main())
