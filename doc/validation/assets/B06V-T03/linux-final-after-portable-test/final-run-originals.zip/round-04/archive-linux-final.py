"""Archive explicit public task snapshots and actual offline run originals."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import zipfile

WORKTREE=Path('/home/lyinn/project/Noetome')
FINAL=Path(__file__).resolve().parent
DEST=WORKTREE/'doc/validation/assets/B06V-T03/linux-final-after-portable-test'

def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def walk(root):
    for folder,directories,names in os.walk(root,followlinks=False):
        for name in list(directories):
            p=Path(folder)/name
            if p.is_symlink():
                directories.remove(name)
                yield p
        for name in names:yield Path(folder)/name

def archive(name,selected):
    DEST.mkdir(parents=True,exist_ok=True)
    target=DEST/(name+'.zip')
    assert not target.exists(),'archive original is never overwritten'
    manifest={}
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as output:
        for arcname,path in selected:
            assert arcname not in manifest,'duplicate member'
            mode=path.lstat().st_mode
            if stat.S_ISLNK(mode):
                raw=os.readlink(path).encode('utf-8')
                info=zipfile.ZipInfo(arcname)
                info.create_system=3
                info.external_attr=(stat.S_IFLNK|stat.S_IMODE(mode))<<16
                output.writestr(info,raw)
                kind='symlink-target-text-preserved-without-following'
            else:
                assert stat.S_ISREG(mode),'only ordinary files or explicit links are archived'
                raw=path.read_bytes()
                output.write(path,arcname)
                kind='ordinary-file'
            manifest[arcname]=dict(**pin(raw),kind=kind,unix_mode=stat.S_IMODE(mode))
    with zipfile.ZipFile(target) as held:
        assert held.testzip() is None,'ZIP CRC check failed'
        assert set(held.namelist())==set(manifest),'ZIP inventory differs'
        for member,wanted in manifest.items():
            assert pin(held.read(member))=={k:wanted[k] for k in ('sha256','byte_length')},'ZIP member byte readback failed: '+member
    result=dict(schema_version=1,producer='independent_linux_validation_originals',archive=target.name,
        archive_pin=pin(target.read_bytes()),members=len(manifest),ordinary_files=sum(v['kind']=='ordinary-file' for v in manifest.values()),
        uncompressed_bytes=sum(v['byte_length'] for v in manifest.values()),zip_crc='passed',all_member_sha256_length_readback='passed',files=manifest)
    save(DEST/(name+'-manifest.json'),result)
    print(json.dumps({k:result[k] for k in ('archive','archive_pin','members','uncompressed_bytes','zip_crc','all_member_sha256_length_readback')}),flush=True)

def source():
    names=json.loads((FINAL/'source-before.json').read_text())
    selected=[('repo/'+name,FINAL/'repo'/name) for name in sorted(names)]
    for name in ('source-before.json','snapshot-receipt.json','worktree-related-before.json','run-final-linux-validation.py'):
        selected.append(('metadata/'+name,FINAL/name))
    selected.append(('metadata/final-binary-receipt.json',WORKTREE/'.artifacts/b06v-t03-knowledge-final-build/binary-receipt.json'))
    selected.append(('earlier-snapshot-source/tests/test_verify_process_flow.py',WORKTREE/'.artifacts/b06v-t03-linux-final-03-20261106/repo/tests/test_verify_process_flow.py'))
    archive('source-originals',selected)

def run_originals(rounds,name):
    selected=[]
    for label in rounds:
        root=WORKTREE/f'.artifacts/b06v-t03-linux-final-{label}-20261106'
        for path in walk(root):
            relative=path.relative_to(root)
            if relative.as_posix() in ('archive-final.stdout.bin','archive-final.stderr.bin'):
                continue
            if relative.parts[0]=='repo':
                if len(relative.parts)<3 or relative.parts[1]!='target' or relative.as_posix() in ('repo/target/debug/noetome','repo/target/debug/noetome.exe'):
                    continue
            selected.append(('round-'+label+'/'+relative.as_posix(),path))
    archive(name,sorted(selected,key=lambda item:item[0]))

if __name__=='__main__':
    if sys.argv[1]=='source':source()
    elif sys.argv[1]=='earlier':run_originals(('01','02'),'earlier-run-originals')
    elif sys.argv[1]=='final':run_originals(('04',),'final-run-originals')
    else:raise SystemExit('explicit source/earlier/final mode required')
