import pathlib,json,subprocess,sys,datetime
source=pathlib.Path(__file__).resolve().parent
work=pathlib.Path('/mnt/d/Noetome/.artifacts/b06v-t03-minimum-20261106-h')
records=[]
for theme in ['light','dark']:
 for case in ['hand-authored-format-probe']:
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  print(json.dumps({'case':case,'theme':theme,'state':'starting'}),flush=True)
  args=[sys.executable,str(source/'run_case.py'),case,theme,'visual-compatibility']
  run=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=600)
  (work/(case+'-'+theme+'-runner.stdout.bin')).write_bytes(run.stdout)
  (work/(case+'-'+theme+'-runner.stderr.bin')).write_bytes(run.stderr)
  records.append({'case':case,'theme':theme,'command':args,'exit_code':run.returncode,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  (work/'format-identity-suite.json').write_text(json.dumps({'status':'running' if run.returncode==0 else 'failed','records':records,'model_calls':0},indent=2)+'\n')
  print(json.dumps({'case':case,'theme':theme,'exit_code':run.returncode,'completed':len(records)}),flush=True)
  if run.returncode:sys.exit(run.returncode)
(work/'format-identity-suite.json').write_text(json.dumps({'status':'passed','records':records,'actual_native_captures':len(records),'model_calls':0},indent=2)+'\n')
