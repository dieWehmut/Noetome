"""One explicitly selected minimum native case with preserved original outputs."""
import datetime,hashlib,json,pathlib,subprocess,sys,os
repo=pathlib.Path('/home/lyinn/project/Noetome')
source=repo/'.artifacts/b06v-t03-minimum-capture-20261106-a'
snapshot=source/'repo'
work=pathlib.Path('/mnt/d/Noetome/.artifacts/b06v-t03-minimum-20261106-b')
case,theme,pack=sys.argv[1:]
tag=case+'-'+theme
record_root=work/(tag+'-execution');record_root.mkdir(exist_ok=False)
fixture=snapshot/'fixtures'/pack
fixture_sha=hashlib.sha256((fixture/'frozen-sha256.json').read_bytes()).hexdigest()
runtime=repo/'doc/validation/assets/B06V-T03/runtime/minimum-runtime-observed.json'
runtime_sha=hashlib.sha256(runtime.read_bytes()).hexdigest()
prepared=work/'prepared'/tag
capture=work/'captures'/tag
commands=[]
def run(name,args,timeout):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 child_env=os.environ.copy()
 for key in ['HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy']: child_env.pop(key,None)
 child_env['NO_PROXY']=child_env['no_proxy']='localhost,127.0.0.1,::1'
 result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,env=child_env)
 (record_root/(name+'.stdout.bin')).write_bytes(result.stdout)
 (record_root/(name+'.stderr.bin')).write_bytes(result.stderr)
 record={'name':name,'command':args,'exit_code':result.returncode,'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':{'sha256':hashlib.sha256(result.stdout).hexdigest(),'byte_length':len(result.stdout)},'stderr':{'sha256':hashlib.sha256(result.stderr).hexdigest(),'byte_length':len(result.stderr)}}
 commands.append(record)
 (record_root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print(json.dumps({'case':case,'theme':theme,'stage':name,'exit_code':result.returncode}),flush=True)
 return result
result=run('prepare',[sys.executable,str(snapshot/'scripts/prepare_visual_compatibility.py'),'--fixture-root',str(fixture),'--fixture-sha256',fixture_sha,'--runtime-record',str(runtime),'--runtime-sha256',runtime_sha,'--case-id',case,'--theme',theme,'--new-root',str(prepared)],120)
if result.returncode==0:
 result=run('native',[sys.executable,str(source/'launch_capture.py'),str(prepared/'selected-output'),str(prepared/'capture-spec.json'),str(capture),'/mnt/c/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','/mnt/c/Program Files/Obsidian/Obsidian.exe','/mnt/c/WINDOWS/System32/WindowsPowerShell/v1.0/powershell.exe','/home/lyinn/.npm/_npx/314abffa6aaf2cd1/node_modules/playwright-core/index.mjs','--capture-script',str(prepared/'capture_visual.mjs')],400)
status='passed' if result.returncode==0 else 'failed'
record={'status':status,'case':case,'theme':theme,'fixture_pack':pack,'fixture_sha256':fixture_sha,'runtime_sha256':runtime_sha,'commands':commands,'prepared':str(prepared),'capture':str(capture),'model_calls':0,'scientific_quality':'not_run'}
(record_root/'result.json').write_text(json.dumps(record,indent=2)+'\n')
sys.exit(result.returncode)
