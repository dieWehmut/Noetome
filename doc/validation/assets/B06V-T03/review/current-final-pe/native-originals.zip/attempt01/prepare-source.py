from pathlib import Path
import hashlib
import json
import shutil
import zipfile

WORKTREE=Path('/home/lyinn/project/Noetome')
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'repo'
AUTH=ROOT/'authority';AUTH.mkdir()
pin=lambda raw:dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
source=WORKTREE/'doc/validation/assets/B06V-T03/windows-rust/source-originals.zip'
native=WORKTREE/'doc/validation/assets/B06V-T03/windows-rust/native-originals.zip'
assert pin(source.read_bytes())==dict(sha256='a83d9c0ee111344ba8c45433dcc70021897b3ae1bb9256fd3a6a43f9440a0370',byte_length=22092329)
assert pin(native.read_bytes())==dict(sha256='058fed0632bcfc69f43764ad1893cebad831c48e0d99b3b6a49c1bd1923329e0',byte_length=38490577)
with zipfile.ZipFile(source) as z:
    snapshot=json.loads(z.read('c/snapshot.json'));deps=json.loads(z.read('c/rust-dependency-subset.json'))
    for name,wanted in snapshot['files'].items():
        raw=z.read('c/repo/'+name);assert pin(raw)==wanted,name
        p=REPO/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    for name in ('snapshot.json','rust-dependency-subset.json'):(AUTH/name).write_bytes(z.read('c/'+name))
with zipfile.ZipFile(native) as z:
    raw=z.read('c/noetome-selected.exe')
    assert pin(raw)==dict(sha256='e42c534d07f66662411fc52f22561510b79ba1c63f14f8b6f419db7c4e0e3274',byte_length=25939968)
    p=REPO/'target/debug/noetome.exe';p.parent.mkdir(parents=True);p.write_bytes(raw)
    for name in ('cli-build-attempt-1.json','cli-build-attempt-1.stdout.bin','cli-build-attempt-1.stderr.bin','native-rust-final.json','native-commands.json','native-runtime.json'):
        (AUTH/name).write_bytes(z.read('c/'+name))
build=json.loads((AUTH/'cli-build-attempt-1.json').read_bytes());final=json.loads((AUTH/'native-rust-final.json').read_bytes())
assert build['exit_code']==0 and not build['timed_out'] and build['source_before_after_equal'] and build['external_sentinel_before_after_equal']
assert build['snapshot_fingerprint']==pin((AUTH/'snapshot.json').read_bytes())
assert build['cli_after']==pin(raw)==final['cli']
for stream in ('stdout','stderr'):
    assert pin((AUTH/('cli-build-attempt-1.'+stream+'.bin')).read_bytes())=={k:build[stream][k] for k in ('sha256','byte_length')}
assert final['source_before_after_equal'] and all(v==0 for v in final['required_latest_exits'].values())
for name,wanted in deps['files'].items():assert pin((REPO/name).read_bytes())==wanted
overlays={}
for folder in ('scripts','tests'):
    for p in (WORKTREE/folder).glob('*'):
        if p.is_file():
            name=p.relative_to(WORKTREE).as_posix();body=p.read_bytes()
            if name in deps['files']:assert pin(body)==deps['files'][name]
            (REPO/name).write_bytes(body);overlays[name]=pin(body)
for name in ('doc/validation/assets/B06-T01/obsidian/capture_obsidian.mjs','doc/validation/assets/B06-T02/obsidian/capture_obsidian.mjs','doc/validation/assets/B06-T03/native/capture_formula.mjs','doc/validation/assets/B06V-T01/native/capture_image.mjs'):
    target=REPO/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((WORKTREE/name).read_bytes());overlays[name]=pin(target.read_bytes())
save(AUTH/'build-source-binding.json',dict(status='passed',source_archive=pin(source.read_bytes()),native_archive=pin(native.read_bytes()),
    selected_original_member='c/noetome-selected.exe',selected_pe=pin(raw),compiled_snapshot_pin=pin((AUTH/'snapshot.json').read_bytes()),compiled_snapshot_files=len(snapshot['files']),
    compiled_rust_dependencies=len(deps['files']),all_compiled_source_originals_readback='passed',all_rust_dependencies_equal_in_runtime_repo=True,
    actual_build_receipt=build,current_independent_python_and_collectors=overlays,
    scope='Actual WindowsC final build original sources and receipt bind this exact PE. Current independent Python is selected separately; no inference is made about old ELF build sources.'))
OLD=WORKTREE/'doc/validation/assets/B06V-T03/review/python-current-capability'
for origin,target in ((OLD/'current-target-cli/profiles',ROOT/'profiles/math-flow'),(OLD/'current-image-cli/profiles',ROOT/'profiles/image')):
    shutil.copytree(origin,target)
scan=ROOT/'profiles/scan';scan.mkdir()
for case in ('scan-clear','scan-fallback','scan-sign','scan-subscript'):
    shutil.copyfile(OLD/'current-scan-replay'/case/'profile.json',scan/(case+'.json'))
    shutil.copyfile(OLD/'current-scan-replay'/case/'synthetic-api.json',scan/(case+'-api-template.json'))
save(ROOT/'prepared-source.json',dict(status='passed',compiled_source_files=len(snapshot['files']),rust_dependencies=len(deps['files']),overlays=overlays,
    source_archive=pin(source.read_bytes()),native_archive=pin(native.read_bytes()),pe=pin(raw),real_model_calls=0,paid_calls=0))
