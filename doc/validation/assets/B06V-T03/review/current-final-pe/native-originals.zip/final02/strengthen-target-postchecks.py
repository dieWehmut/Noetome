from pathlib import Path
import hashlib
import json
import shutil
import sys
ROOT=Path(__file__).resolve().parent;REPO=ROOT/'repo';sys.path.insert(0,str(REPO/'scripts'))
import verify_formula as F
import verify_image as I
def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def load(p):return F.strict_json(p.read_bytes())
def save(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
data=load(ROOT/'actual-checks.json')
preliminary=[row for row in data['synchronized_forgery_rejections'] if row['name'] in ('formula-target-forgery','image-target-forgery')]
assert len(preliminary)==2 and all(row['reason'].startswith('schema fields:') for row in preliminary)
data['preliminary_schema_rejections']=preliminary
data['synchronized_forgery_rejections']=[row for row in data['synchronized_forgery_rejections'] if row not in preliminary]
def reject(domain,baseline,action,checker):
    target=ROOT/'mutations'/(domain+'-target-forgery-semantic');shutil.copytree(baseline,target);action(target)
    try:checker(target)
    except (AssertionError,ValueError,KeyError,OSError) as error:
        reason=str(error);assert 'source-grounded' in reason and 'representation' in reason,reason
        data['synchronized_forgery_rejections'].append(dict(name=domain+'-target-forgery-semantic',status='rejected',reason=reason,
            fields_kept_exact=True,actual_decision_representation_changed=True,ordinary_hashes_and_dual_reports_synchronized=True,
            files={p.relative_to(target).as_posix():pin(p.read_bytes()) for p in target.rglob('*') if p.is_file()}));return
    raise AssertionError('semantic target forgery accepted')
def formula(target):
    r=load(target/'formula.json');r['decision']['representation']='native_math';F.save(target/'formula.json',r);F.resynchronize_result(target)
reject('formula',ROOT/'cases/math-unknown',formula,lambda target:F.verify_output(F.FIXTURE/'native',F.FIXTURE/'profile-native.json',target,F.FIXTURE/'expected-native.json',target_profile=ROOT/'profiles/math-flow/math-unknown.json'))
def image(target):
    r=load(target/'image.json');r['decision']['representation']='svg_redraw';I.save(target/'image.json',r);I.resynchronize_result(target)
reject('image',ROOT/'cases/image-unknown-version',image,lambda target:I.verify_output(I.FIXTURE/'signed_arrows',I.FIXTURE/'profile-native.json',target,I.FIXTURE/'expected-signed_arrows.json',target_profile=ROOT/'profiles/image/unknown-version.json'))
assert len(data['synchronized_forgery_rejections'])==7
before=load(ROOT/'source-before.json');assert before=={name:pin((REPO/name).read_bytes()) for name in before}
data['all_synchronized_target_checks_semantic']=True
data['total_actual_forgery_attempts']=9
data['postcheck_strengthening']='Two initial counterfeit top-level fields were rejected by exact schema. Retained originals; repeated with actual decision.representation and all ordinary hashes/dual reports synchronized. Both now reject the independently derived target representation. No additional CLI, HTTP or model calls.'
save(ROOT/'actual-checks.json',data)
print(json.dumps({'status':'passed','primary_cli':30,'additional_setup':15,'semantic_forgery_categories':7,'preliminary_schema_rejections':2,'additional_cli':0,'additional_http':0}))
