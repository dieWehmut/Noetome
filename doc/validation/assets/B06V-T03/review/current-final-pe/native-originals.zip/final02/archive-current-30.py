from pathlib import Path
import hashlib
import json
import os
import stat
import zipfile

WORKTREE=Path('/home/lyinn/project/Noetome')
ROOT=Path(__file__).resolve().parent
DEST=WORKTREE/'doc/validation/assets/B06V-T03/review/current-final-pe'
DEST.mkdir(parents=True,exist_ok=True)
def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def load(p):return json.loads(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
runtime=load(ROOT/'source-before.json');snapshot=load(ROOT/'authority/snapshot.json')['files']
variants={}
with zipfile.ZipFile(WORKTREE/'doc/validation/assets/B06V-T03/windows-rust/source-originals.zip') as original:
    for name,wanted in snapshot.items():
        if runtime[name]!=wanted:
            raw=original.read('c/repo/'+name);assert pin(raw)==wanted
            p=ROOT/'compiled-source-variants'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);variants[name]=p
assert set(variants)=={'scripts/prepare_visual_compatibility.py','tests/test_verify_process_flow.py'}
for name,wanted in snapshot.items():assert pin((variants.get(name) or ROOT/'repo'/name).read_bytes())==wanted
save(ROOT/'authority/complete-compiled-source-reconstruction.json',dict(status='passed',compiled_source_files=len(snapshot),
    compiler_originals=dict((name,pin(path.read_bytes())) for name,path in variants.items()),
    basis='1915 actual C compiler snapshot originals are byte-reconstructed from unchanged runtime source members and two original non-Rust Python variants extracted from the frozen C source ZIP. Every snapshot SHA/length is checked. All 1825 conservative Rust dependencies equal runtime source. Current independent Python is explicitly selected separately.'))

for name in ('actual-checks.json','source-before.json','source-after.json','postcheck.stdout.bin','postcheck.stderr.bin','semantic-postcheck.stdout.bin','semantic-postcheck.stderr.bin'):
    (DEST/name).write_bytes((ROOT/name).read_bytes())
for name in ('build-source-binding.json','complete-compiled-source-reconstruction.json','snapshot.json','rust-dependency-subset.json','cli-build-attempt-1.json','native-rust-final.json'):
    (DEST/name).write_bytes((ROOT/'authority'/name).read_bytes())

def archive(name,selected):
    path=DEST/(name+'.zip');assert not path.exists();manifest={}
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for member,p in selected:
            mode=p.lstat().st_mode
            if stat.S_ISLNK(mode):
                raw=os.readlink(p).encode();info=zipfile.ZipInfo(member);info.create_system=3;info.external_attr=(stat.S_IFLNK|stat.S_IMODE(mode))<<16;z.writestr(info,raw);kind='symlink-target-text-without-following'
            else:
                assert stat.S_ISREG(mode);raw=p.read_bytes();z.write(p,member);kind='ordinary-file'
            manifest[member]=dict(**pin(raw),kind=kind)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(manifest)
        for member,wanted in manifest.items():assert pin(z.read(member))=={k:wanted[k] for k in ('sha256','byte_length')}
    result=dict(status='passed',archive=path.name,archive_pin=pin(path.read_bytes()),members=len(manifest),uncompressed_bytes=sum(v['byte_length'] for v in manifest.values()),files=manifest,
        zip_crc='passed',every_member_sha256_length_readback='passed')
    save(DEST/(name+'-manifest.json'),result);print(json.dumps({k:result[k] for k in ('archive','archive_pin','members','uncompressed_bytes')}),flush=True)

source=[('runtime-repo/'+name,ROOT/'repo'/name) for name in sorted(runtime)]
source += [('compiled-source-variants/'+name,path) for name,path in variants.items()]
source += [('authority/'+p.name,p) for p in sorted((ROOT/'authority').iterdir()) if p.is_file()]
source += [('control/'+name,ROOT/name) for name in ('run-current-30.py','finish-postchecks.py','strengthen-target-postchecks.py','source-before.json','prepared-source.json','prepare-source.py')]
archive('source-originals',source)
selected=[]
for label,root in (('attempt01',ROOT.parent/'b06v-t03-c30-01'),('final02',ROOT)):
    for p in root.rglob('*'):
        rel=p.relative_to(root)
        if rel.parts[0] in ('repo','authority','compiled-source-variants'):continue
        if rel.as_posix() in ('archive-current-30.stdout.bin','archive-current-30.stderr.bin'):continue
        if p.is_file() or p.is_symlink():selected.append((label+'/'+rel.as_posix(),p))
archive('native-originals',sorted(selected,key=lambda x:x[0]))
print(json.dumps(dict(status='passed',actual_check_pin=pin((DEST/'actual-checks.json').read_bytes()),primary_cli=30,additional_setup_cli=15,real_model_calls=0,paid_calls=0)))
