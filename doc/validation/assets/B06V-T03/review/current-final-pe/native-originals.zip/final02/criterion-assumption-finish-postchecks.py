from pathlib import Path
import hashlib
import json
import os
import shutil
import sys

ROOT=Path(__file__).resolve().parent;REPO=ROOT/'repo';sys.path.insert(0,str(REPO/'scripts'))
import verify_formula as F
import verify_process_flow as P
import verify_image as I
def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def load(p):return F.strict_json(p.read_bytes())
def save(p,v):p.write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
data=load(ROOT/'actual-checks.json')
assert data['primary_count']==30 and data['additional_setup_count']==15 and len(data['rows'])==27
def reject(name,action,checker):
    target=ROOT/'mutations'/name;action(target)
    try:checker(target)
    except (AssertionError,ValueError,KeyError,OSError) as error:
        data['synchronized_forgery_rejections'].append(dict(name=name,status='rejected',reason=str(error),files={p.relative_to(target).as_posix():pin(p.read_bytes()) for p in target.rglob('*') if p.is_file()}));save(ROOT/'actual-checks.json',data);return
    raise AssertionError('accepted synchronized forgery '+name)
def flow_check(profile,target):
    base=ROOT/'inputs/branch'
    return P.verify_flow(base/'project',base/'case',base/'review',base/'profile.json',target,P.FIXTURE/'expected-branch.json',target_profile=ROOT/'profiles/math-flow'/(profile+'.json'))
def condition(target):
    shutil.copytree(ROOT/'cases/flow-branch',target);p=target/'流程总览.md';raw=p.read_bytes();old='签名区域可读'.encode();assert old in raw;p.write_bytes(raw.replace(old,'签名区域不可读'.encode(),1));P.refresh_flow(target)
reject('flow-condition-loss',condition,lambda target:flow_check('flow-current',target))
def renderer(target):
    shutil.copytree(ROOT/'cases/flow-unknown-version',target);r=load(target/'flow.json');r['representation']='flowchart';r['issue_codes']=[];P.save(target/'flow.json',r);P.refresh_flow(target)
reject('flow-renderer-forgery',renderer,lambda target:flow_check('flow-unknown-version',target))
def image_check(name,target,profile):return I.verify_output(I.FIXTURE/name,I.FIXTURE/'profile-native.json',target,I.FIXTURE/('expected-'+name+'.json'),target_profile=ROOT/'profiles/image'/(profile+'.json'))
def head(target):
    shutil.copytree(ROOT/'cases/image-signed-arrows',target);I.mutate_svg(target,'relation-gain-head',lambda raw:b'');I.resynchronize_result(target)
reject('image-arrowhead-loss',head,lambda target:image_check('signed_arrows',target,'current'))
def target_profile(target):
    shutil.copytree(ROOT/'cases/image-unknown-version',target);r=load(target/'image.json');r['representation']='svg_redraw';I.save(target/'image.json',r);I.resynchronize_result(target)
reject('image-target-forgery',target_profile,lambda target:image_check('signed_arrows',target,'unknown-version'))
def curve(target):
    shutil.copytree(ROOT/'cases/image-curve-no-data',target);(target/'invented-curve.csv').write_bytes(b'x,y\n0,0\n1,1\n');I.resynchronize_result(target)
reject('image-invented-curve-data',curve,lambda target:image_check('curve_no_data',target,'current'))
assert len(data['synchronized_forgery_rejections'])==7
before=load(ROOT/'source-before.json');after={name:pin((REPO/name).read_bytes()) for name in before};save(ROOT/'source-after.json',after);assert before==after
deps=load(ROOT/'authority/rust-dependency-subset.json')['files'];assert all(after[name]==wanted for name,wanted in deps.items())
data.update(status='passed',selected_pe=pin((REPO/'target/debug/noetome.exe').read_bytes()),build_source_authority=pin((ROOT/'authority/build-source-binding.json').read_bytes()),
    source_inputs_unchanged=True,source_file_count=len(before),compiled_rust_dependencies_readback=len(deps),synthetic_numeric_loopback_requests=4,python=sys.executable,
    all_display_bindings_bytes_equal=all(item['all_bytes_equal'] for item in data['display_bindings']),byte_binding_case_count=len(data['display_bindings']),
    product_markdown_count=sum(row['file'].endswith('.md') for item in data['display_bindings'] for row in item['files']),
    postcheck_resume='retained actual 45 CLI outputs; corrected harness filename only; no additional CLI, HTTP or model calls')
save(ROOT/'actual-checks.json',data)
print(json.dumps({k:data[k] for k in ('status','primary_count','additional_setup_count','total_actual_cli_calls','all_display_bindings_bytes_equal','product_markdown_count','synthetic_numeric_loopback_requests')}))
