# 有据流程表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "40fd9cf7-4958-4d46-8654-99c8e4dd3e07",
  "binding": {
    "project_id": "66259a8d-5205-4160-9b2e-351baf7d191c",
    "import_id": "24972c71-2cd1-4529-a393-2f2a95343439",
    "source_id": "a4e9633b-015d-4758-9912-6329bb546719",
    "version_id": "f71faa4d-8fb6-4d89-86aa-c110014dc39d",
    "content_sha256": "ed70d6507618841afffdedd6bd28a0ab0df4e8ce91f5a30006fbec45d09d41cd",
    "normalized_sha256": "ed70d6507618841afffdedd6bd28a0ab0df4e8ce91f5a30006fbec45d09d41cd",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_UNKNOWN_CRITERION"
  ],
  "issues": [
    {
      "code": "FLOW_UNKNOWN_CRITERION",
      "object_ids": [
        "d1"
      ],
      "message": "判定缺少明确判据，不能生成真假分支表达。"
    }
  ],
  "process_document": {
    "process": {
      "title": "未知判据的分流说明",
      "entry": "d1",
      "goals": [
        "s1",
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": []
    },
    "steps": [
      {
        "id": "d1",
        "kind": "decision",
        "label": "执行待明确的判定",
        "description": "来源未列明实际判据",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "未知"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "判据未确认前不能执行"
        ]
      },
      {
        "id": "s1",
        "kind": "step",
        "label": "真支处理",
        "description": "只记录真支去向",
        "criterion": null,
        "inputs": [
          "真支卡片"
        ],
        "outputs": [
          "真支结果"
        ],
        "conditions": [],
        "exceptions": []
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "假支处理",
        "description": "只记录假支去向",
        "criterion": null,
        "inputs": [
          "假支卡片"
        ],
        "outputs": [
          "假支结果"
        ],
        "conditions": [],
        "exceptions": []
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "d1",
        "right": "s1",
        "kind": "branch",
        "branch_outcome": true,
        "conditions": [],
        "exceptions": []
      },
      {
        "id": "r2",
        "left": "d1",
        "right": "s2",
        "kind": "branch",
        "branch_outcome": false,
        "conditions": [],
        "exceptions": []
      }
    ],
    "evidence": [
      {
        "object_id": "d1",
        "start_byte": 127,
        "end_byte": 346,
        "quote": "判定 d1：\"执行待明确的判定\"。判据：null。说明：\"来源未列明实际判据\"。输入：[\"样例卡\"]。输出：[\"未知\"]。条件：[\"卡片可读\"]。例外：[\"判据未确认前不能执行\"]。"
      },
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 126,
        "quote": "过程：\"未知判据的分流说明\"。入口：d1。目标：[\"s1\",\"s2\"]。条件：[\"演示模式开启\"]。例外：[]。"
      },
      {
        "object_id": "r1",
        "start_byte": 645,
        "end_byte": 718,
        "quote": "关系 r1：d1 的判据为真时执行 s1。条件：[]。例外：[]。"
      },
      {
        "object_id": "r2",
        "start_byte": 719,
        "end_byte": 792,
        "quote": "关系 r2：d1 的判据为假时执行 s2。条件：[]。例外：[]。"
      },
      {
        "object_id": "s1",
        "start_byte": 347,
        "end_byte": 495,
        "quote": "步骤 s1：\"真支处理\"。说明：\"只记录真支去向\"。输入：[\"真支卡片\"]。输出：[\"真支结果\"]。条件：[]。例外：[]。"
      },
      {
        "object_id": "s2",
        "start_byte": 496,
        "end_byte": 644,
        "quote": "步骤 s2：\"假支处理\"。说明：\"只记录假支去向\"。输入：[\"假支卡片\"]。输出：[\"假支结果\"]。条件：[]。例外：[]。"
      }
    ]
  },
  "profile": {
    "schema_version": 2,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_15_0_pele_flowchart",
    "app": "Obsidian",
    "app_version": "1.15.0",
    "mermaid_version": null,
    "renderer": {
      "name": "pele",
      "version": "1.8.0",
      "source_sha256": "9bf34b3a9a19351dc69d0d238e365560331a8ae392c41656df7f5090653253d0"
    },
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": false
  },
  "representation": null,
  "decision": null,
  "review_ir_fingerprint": {
    "sha256": "540dcd11f73c59f39689f3b20d7d8b908c637e935d93950280b39c03e3796b4c",
    "byte_length": 6089
  },
  "plan_fingerprint": null,
  "totals": {
    "branch_relations": 2,
    "causes_relations": 0,
    "content_mappings": 0,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 6,
    "flow_edges": 0,
    "flow_nodes": 0,
    "inhibits_relations": 0,
    "links": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 0,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 2,
    "rendered_notes": 0,
    "sequence_relations": 0,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "cf5d10245b304ff1d979dd5d8429e9a70a1fed0347520544e299089812fe4ace",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".profile.json": {
      "sha256": "6d2051f224d92b93fc25ddefa34f22ebd706d6a80027ec01cf09a99c21213469",
      "byte_length": 453
    },
    ".review-.case.json": {
      "sha256": "cf5d10245b304ff1d979dd5d8429e9a70a1fed0347520544e299089812fe4ace",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".review-.owner.json": {
      "sha256": "085c0be17e1b06aff68f03b7d4c471c9b44847f2724fe00350fb44411df2615e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "149eed1ded19384dfa61d01c047a2dc1fbf7cb512d31bd4ca588a25a30eafe01",
      "byte_length": 1723
    },
    ".review-process-ir.json": {
      "sha256": "540dcd11f73c59f39689f3b20d7d8b908c637e935d93950280b39c03e3796b4c",
      "byte_length": 6089
    },
    ".review-review.json": {
      "sha256": "e958f1a9ac5e36a43bd15b8f38d01c049e66c14488a75ffda8ff815d6264ce1c",
      "byte_length": 6974
    },
    ".review-review.md": {
      "sha256": "e1757a28e3727bd443413b4e17ba512760de25a718bb0862e91be5d653d4c6d8",
      "byte_length": 7157
    },
    ".source.json": {
      "sha256": "149eed1ded19384dfa61d01c047a2dc1fbf7cb512d31bd4ca588a25a30eafe01",
      "byte_length": 1723
    }
  },
  "files": [],
  "artifacts": {
    ".case.json": {
      "sha256": "cf5d10245b304ff1d979dd5d8429e9a70a1fed0347520544e299089812fe4ace",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".owner.json": {
      "sha256": "59e163af460801ba2426f024f1b4fe469091a19e8d47e7d541ad34aa6f7bedee",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "6d2051f224d92b93fc25ddefa34f22ebd706d6a80027ec01cf09a99c21213469",
      "byte_length": 453
    },
    ".review-.case.json": {
      "sha256": "cf5d10245b304ff1d979dd5d8429e9a70a1fed0347520544e299089812fe4ace",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".review-.owner.json": {
      "sha256": "085c0be17e1b06aff68f03b7d4c471c9b44847f2724fe00350fb44411df2615e",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "149eed1ded19384dfa61d01c047a2dc1fbf7cb512d31bd4ca588a25a30eafe01",
      "byte_length": 1723
    },
    ".review-process-ir.json": {
      "sha256": "540dcd11f73c59f39689f3b20d7d8b908c637e935d93950280b39c03e3796b4c",
      "byte_length": 6089
    },
    ".review-review.json": {
      "sha256": "e958f1a9ac5e36a43bd15b8f38d01c049e66c14488a75ffda8ff815d6264ce1c",
      "byte_length": 6974
    },
    ".review-review.md": {
      "sha256": "e1757a28e3727bd443413b4e17ba512760de25a718bb0862e91be5d653d4c6d8",
      "byte_length": 7157
    },
    ".source.json": {
      "sha256": "149eed1ded19384dfa61d01c047a2dc1fbf7cb512d31bd4ca588a25a30eafe01",
      "byte_length": 1723
    }
  }
}
```
