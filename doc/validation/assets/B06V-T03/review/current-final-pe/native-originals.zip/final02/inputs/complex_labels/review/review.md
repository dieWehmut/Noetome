# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "0780a519-226c-4c40-950d-276dba76fff7",
  "binding": {
    "project_id": "cae4a068-94e9-4509-868c-0166d6e0fbe7",
    "import_id": "95dc9bab-f0e0-4b3f-b926-b21c54b2e62e",
    "source_id": "5c6b3d9a-7434-4888-8819-d93a5b75649b",
    "version_id": "a2c5637d-6d42-4b97-9ea0-8be35eaecab6",
    "content_sha256": "177afc927146f332cf9db8159d0ca7032bfcd443c286a0cadb50b77884a77b4c",
    "normalized_sha256": "177afc927146f332cf9db8159d0ca7032bfcd443c286a0cadb50b77884a77b4c",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "特殊名称的卡片流程",
      "entry": "s1",
      "goals": [
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "s1",
        "kind": "step",
        "label": "预检 [α] | \"卡片\"",
        "description": "先做预检；本步骤在文字中后声明，不改变明确关系顺序",
        "criterion": null,
        "inputs": [
          "卡片 A\\B"
        ],
        "outputs": [
          "预检结果"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "卡片缺失时停止"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "复核 #2 / x < 3",
        "description": "保留复核名称中的符号，不解释为指令",
        "criterion": null,
        "inputs": [
          "预检结果"
        ],
        "outputs": [
          "复核结果"
        ],
        "conditions": [
          "字段包含竖线 | 和双引号 \""
        ],
        "exceptions": [
          "不得删除名称符号"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "归档入口 & 保留",
        "description": "保留标签中的连接符",
        "criterion": null,
        "inputs": [
          "复核结果"
        ],
        "outputs": [
          "归档结果"
        ],
        "conditions": [
          "复核完成"
        ],
        "exceptions": [
          "存储不可用时暂停"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "s2",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "预检完成"
        ],
        "exceptions": [
          "缺卡时停止"
        ]
      },
      {
        "id": "r2",
        "left": "s2",
        "right": "s3",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "复核完成"
        ],
        "exceptions": [
          "存储不可用时暂停"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 147,
        "quote": "过程：\"特殊名称的卡片流程\"。入口：s1。目标：[\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 956,
        "end_byte": 1051,
        "quote": "关系 r1：s1 完成后执行 s2。条件：[\"预检完成\"]。例外：[\"缺卡时停止\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 851,
        "end_byte": 955,
        "quote": "关系 r2：s2 完成后执行 s3。条件：[\"复核完成\"]。例外：[\"存储不可用时暂停\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 396,
        "end_byte": 646,
        "quote": "步骤 s1：\"预检 [α] | \\\"卡片\\\"\"。说明：\"先做预检；本步骤在文字中后声明，不改变明确关系顺序\"。输入：[\"卡片 A\\\\B\"]。输出：[\"预检结果\"]。条件：[\"卡片可读\"]。例外：[\"卡片缺失时停止\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 148,
        "end_byte": 395,
        "quote": "步骤 s2：\"复核 #2 / x < 3\"。说明：\"保留复核名称中的符号，不解释为指令\"。输入：[\"预检结果\"]。输出：[\"复核结果\"]。条件：[\"字段包含竖线 | 和双引号 \\\"\"]。例外：[\"不得删除名称符号\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 647,
        "end_byte": 850,
        "quote": "步骤 s3：\"归档入口 & 保留\"。说明：\"保留标签中的连接符\"。输入：[\"复核结果\"]。输出：[\"归档结果\"]。条件：[\"复核完成\"]。例外：[\"存储不可用时暂停\"]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 2,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 0,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 0,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 3,
    "node_exceptions": 3,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 2,
    "relation_exceptions": 2,
    "relations": 2,
    "sequence_relations": 2,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "8d4b585b625dc3c6ae3434ceb7d0778893c56b35ee40026bd4901ec62e93a99a",
  "ir_fingerprint": {
    "sha256": "853e9f69923d3d5d9b16894de5eab47f39bd7d8ccdeaa38abc0507ce1f085614",
    "byte_length": 7117
  },
  "inputs": {
    ".case.json": {
      "sha256": "4763ef8fa91cdcfef01e62cc3541190f79bf7bbb5328d83ad043eb1a350345e1",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "8d4b585b625dc3c6ae3434ceb7d0778893c56b35ee40026bd4901ec62e93a99a",
      "byte_length": 3921
    },
    ".source.json": {
      "sha256": "7262d8e695b52c1a01b0cc5be6c0e063205d3b1f5cf73683b6613300076619ae",
      "byte_length": 2007
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "4763ef8fa91cdcfef01e62cc3541190f79bf7bbb5328d83ad043eb1a350345e1",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "8d4b585b625dc3c6ae3434ceb7d0778893c56b35ee40026bd4901ec62e93a99a",
      "byte_length": 3921
    },
    ".owner.json": {
      "sha256": "b269c5b4c83680d68009853d84fcb691b0908477ad3aac500714124fab31e5fb",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "7262d8e695b52c1a01b0cc5be6c0e063205d3b1f5cf73683b6613300076619ae",
      "byte_length": 2007
    },
    "process-ir.json": {
      "sha256": "853e9f69923d3d5d9b16894de5eab47f39bd7d8ccdeaa38abc0507ce1f085614",
      "byte_length": 7117
    }
  }
}
```
