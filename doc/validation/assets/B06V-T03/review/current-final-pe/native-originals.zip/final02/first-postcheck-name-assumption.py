from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
REPO=ROOT/'repo'
CLI=REPO/'target/debug/noetome.exe'
allowed={name:value for name,value in os.environ.items() if name.upper() in ('PATH','SYSTEMROOT','WINDIR','TEMP','TMP','COMSPEC','PATHEXT')}
os.environ.clear();os.environ.update(allowed)
sys.path.insert(0,str(REPO/'scripts'))
import verify_formula as F
import verify_process_flow as P
import verify_image as I
import verify_scan_formula as S

def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode())
def load(path):return F.strict_json(path.read_bytes())
def inventory(root):return {p.relative_to(root).as_posix():pin(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
source_names=[p.relative_to(REPO).as_posix() for p in REPO.rglob('*') if p.is_file() and ('target' not in p.relative_to(REPO).parts or p==CLI)]
before={name:pin((REPO/name).read_bytes()) for name in source_names}
save(ROOT/'source-before.json',before)
assert pin(CLI.read_bytes())==dict(sha256='e42c534d07f66662411fc52f22561510b79ba1c63f14f8b6f419db7c4e0e3274',byte_length=25939968)
(ROOT/'cases').mkdir()
commands=[];setup_commands=[];rows=[];bindings=[];rejections=[]
def record(status='running'):
    save(ROOT/'actual-checks.json',dict(status=status,primary_commands=commands,additional_setup_commands=setup_commands,rows=rows,
        display_bindings=bindings,synchronized_forgery_rejections=rejections,primary_count=len(commands),additional_setup_count=len(setup_commands),
        total_actual_cli_calls=len(commands)+len(setup_commands),real_model_calls=0,paid_calls=0,external_33185_ledger='not_read_not_modified',
        native_capture='not_run',scientific_quality='not_run',confidence='unknown_no_score_added'))
def command(label,args,codes=(0,),setup=False,credential=None):
    argv=[str(CLI),*map(str,args)];env=dict(allowed)
    if credential is not None:env['NOETOME_TEST_SCAN_CREDENTIAL']=credential
    started=time.monotonic();result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=60)
    dest=ROOT/('setup-commands' if setup else 'commands');dest.mkdir(exist_ok=True)
    collection=setup_commands if setup else commands;prefix=dest/f'{len(collection):02d}-{label}'
    prefix.with_suffix('.stdout.bin').write_bytes(result.stdout);prefix.with_suffix('.stderr.bin').write_bytes(result.stderr)
    receipt=dict(label=label,argv=argv,command=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,
        stdout=pin(result.stdout),stderr=pin(result.stderr),inherited_real_credential_environment=False)
    save(prefix.with_suffix('.receipt.json'),receipt);collection.append(receipt);record()
    assert result.returncode in codes,(label,result.returncode,result.stderr.decode(errors='replace'))
    return result,receipt
def bind(case_id,vault,domain):
    pack=REPO/'fixtures/visual-compatibility-flow-extensions' if case_id in ('flow-complex-labels','flow-promotes','flow-inhibits') else REPO/'fixtures/visual-compatibility'
    old=pack/'selected-output'/case_id;report=load(old/(domain+'.json'))
    names={entry['relative_path'] for entry in report.get('files',[]) if entry['relative_path'].endswith('.md')}
    names.update(name for name in ('original.tex','compiled.tex','recognized.tex','redrawn.svg','original.png','page.png','original.pdf') if (old/name).is_file())
    result=[]
    for name in sorted(names):
        actual=(vault/name).read_bytes();original=(old/name).read_bytes()
        result.append(dict(file=name,current=pin(actual),captured_frozen_original=pin(original),bytes_equal=actual==original))
    bindings.append(dict(case_id=case_id,domain=domain,files=result,all_bytes_equal=all(row['bytes_equal'] for row in result)))
    record()
def reject(name,action,checker):
    target=ROOT/'mutations'/name;target.parent.mkdir(exist_ok=True);action(target)
    try:checker(target)
    except (AssertionError,ValueError,KeyError,OSError) as error:
        rejections.append(dict(name=name,status='rejected',reason=str(error),files=inventory(target)));record();return
    raise AssertionError('synchronized forgery accepted: '+name)

math=ROOT/'profiles/math-flow'
formula_inputs={}
for case_id,case_name,target_name in (('formula-native','native','math-current'),('formula-native-relational','native_relational','math-current'),
        ('math-mixed-engine','native','math-mixed-engine'),('math-mixed-app','native','math-mixed-app'),('math-unknown','native','math-unknown'),
        ('formula-unknown-symbol','unknown_symbol','math-current')):
    case=REPO/'fixtures/formula-fidelity'/case_name;baseline=REPO/'fixtures/formula-fidelity/profile-native.json'
    expected=REPO/'fixtures/formula-fidelity'/('expected-'+case_name+'.json');profile=math/(target_name+'.json');vault=ROOT/'cases'/case_id
    command(case_id,['knowledge','formula',case,profile,vault],(3,) if case_name=='unknown_symbol' else (0,))
    checked=F.verify_output(case,baseline,vault,expected,target_profile=profile)
    formula_inputs[case_id]=(case,baseline,vault,expected,profile)
    rows.append(dict(case_id=case_id,domain='formula',target=target_name,independent=checked));record()
    if case_id in ('formula-native','formula-native-relational'):bind(case_id,vault,'formula')

authors=P.verify_fixture()['cases']
flow_inputs={}
def flow_setup(case_name,primary=False):
    author=next(case for case in authors if case['name']==case_name)
    folder=ROOT/'inputs'/case_name;folder.mkdir(parents=True)
    source=folder/'source.txt';source.write_bytes(P.read(P.FIXTURE/author['source_file']))
    project=folder/'project';case=folder/'case';case.mkdir();review=folder/'review'
    command('flow-'+case_name+'-project',['project','init',project],setup=not primary)
    imported,_=command('flow-'+case_name+'-import',['source','import',project,source],setup=not primary)
    import_id=P.strict_json(imported.stdout)['import_id'];actual=P.actual_source(project,import_id,dict(kind='text',ordinal=0))
    P.exact(actual['units'][0]['text'].encode(),source.read_bytes(),'actual local imported author bytes')
    gold=P.read(P.FIXTURE/author['gold_file']);(case/'gold.json').write_bytes(gold)
    P.save(case/'process-review.json',dict(schema_version=1,purpose='process_source_review',project_id=actual['binding']['project_id'],
        import_id=import_id,selection=[dict(kind='text',ordinal=0)],gold_file='gold.json',gold_sha256=P.fingerprint(gold)['sha256']))
    expected=P.FIXTURE/author['expected_file'];baseline=folder/'profile.json';baseline.write_bytes(P.read(P.FIXTURE/author['profile_file']))
    command('flow-'+case_name+'-review',['knowledge','process-review',project,case,review],setup=not primary)
    P.verify_review(project,case,review,expected)
    flow_inputs[case_name]=(project,case,review,baseline,expected)
    return flow_inputs[case_name]
for case_name in ('branch','multiline_labels','complex_labels','promotes','inhibits'):
    project,case,review,baseline,expected=flow_setup(case_name)
    case_id='flow-'+case_name.replace('_','-');vault=ROOT/'cases'/case_id;profile=math/'flow-current.json'
    command(case_id,['knowledge','flow',project,case,review,profile,vault])
    checked=P.verify_flow(project,case,review,baseline,vault,expected,target_profile=profile)
    rows.append(dict(case_id=case_id,domain='flow',target='flow-current',representation=checked['representation'],issues=checked['issue_codes'],independent='passed'));record();bind(case_id,vault,'flow')
for name in ('flow-unknown-version','flow-forged-sha','flow-mixed-app','flow-mixed-legacy'):
    project,case,review,baseline,expected=flow_inputs['branch'];profile=math/(name+'.json');vault=ROOT/'cases'/name
    command(name,['knowledge','flow',project,case,review,profile,vault])
    checked=P.verify_flow(project,case,review,baseline,vault,expected,target_profile=profile)
    rows.append(dict(case_id=name,domain='flow',representation=checked['representation'],issues=checked['issue_codes'],independent='passed'));record()
project,case,review,baseline,expected=flow_setup('unknown_criterion',primary=True)
profile=math/'flow-current.json';vault=ROOT/'cases/flow-unknown-criterion'
command('flow-unknown-criterion',['knowledge','flow',project,case,review,profile,vault],(3,))
checked=P.verify_flow(project,case,review,baseline,vault,expected,target_profile=profile)
rows.append(dict(case_id='flow-unknown-criterion',domain='flow',representation=checked['representation'],issues=checked['issue_codes'],independent='passed'));record()

images=ROOT/'profiles/image';image_inputs={}
for case_id,case_name,target_name in (('image-signed-arrows','signed_arrows','current'),('image-curve-no-data','curve_no_data','current'),
        ('image-unknown-version','signed_arrows','unknown-version'),('image-unverified','signed_arrows','unverified'),
        ('image-no-svg','signed_arrows','no-svg'),('image-unverified-no-svg','signed_arrows','unverified-no-svg'),('image-unknown-relation','unknown_relation','current')):
    case=I.FIXTURE/case_name;profile=images/(target_name+'.json');baseline=I.FIXTURE/'profile-native.json';expected=I.FIXTURE/('expected-'+case_name+'.json');vault=ROOT/'cases'/case_id
    command(case_id,['knowledge','image',case,profile,vault],(3,) if case_name=='unknown_relation' else (0,))
    checked=I.verify_output(case,baseline,vault,expected,target_profile=profile)
    image_inputs[case_id]=(case,baseline,vault,expected,profile)
    rows.append(dict(case_id=case_id,domain='image',independent=checked));record()
    if case_id in ('image-signed-arrows','image-curve-no-data'):bind(case_id,vault,'image')

for case_id,source_state in (('scan-clear','clear'),('scan-fallback','clear'),('scan-sign','unreadable_sign'),('scan-subscript','unreadable_subscript')):
    folder=ROOT/'scan'/case_id;folder.mkdir(parents=True)
    case=S.FIXTURE/'cases'/source_state;profile=ROOT/'profiles/scan'/(case_id+'.json');config=load(ROOT/'profiles/scan'/(case_id+'-api-template.json'))
    old=REPO/'fixtures/visual-compatibility/selected-output'/case_id;raw=(old/'response.bin').read_bytes();vault=folder/'Vault'
    with S.ArtificialHttp(raw,headers={'X-Request-Id':'noetome-synthetic-original-replay'}) as server:
        config['endpoint']=server.endpoint;api=folder/'synthetic-api.json';save(api,config)
        _,receipt=command(case_id,['knowledge','scan-formula',case,api,profile,vault],(3,) if source_state!='clear' else (0,),credential=S.ArtificialHttp.KEY)
    assert len(server.requests)==1 and server.requests[0]['synthetic_authorization']
    request=server.requests[0];(folder/'actual-http-request.bin').write_bytes(request['body'])
    transport=dict(network_attempts=1,http_status=200,response_complete=True,response_sha256=pin(raw)['sha256'])
    save(folder/'transport.json',transport)
    checked=S.verify_output(case,api,profile,vault,S.FIXTURE/('expected-'+source_state+'.json'),transport_receipt=transport,invocation_receipt=receipt)
    assert (vault/'response.bin').read_bytes()==raw
    assert load(vault/'recognition.json')==load(old/'recognition.json')
    rows.append(dict(case_id=case_id,domain='scan',independent=checked,synthetic_http_requests=1,original_response=pin(raw),original_recognition_semantics_equal=True));record();bind(case_id,vault,'scan')

def formula_check(key,target):
    case,baseline,_,expected,profile=formula_inputs[key];return F.verify_output(case,baseline,target,expected,target_profile=profile)
def negative(target):
    shutil.copytree(formula_inputs['formula-native'][2],target);p=target/'公式预览.md';raw=p.read_bytes();assert b' = -' in raw;p.write_bytes(raw.replace(b' = -',b' = ',1));F.resynchronize_result(target)
reject('formula-negative',negative,lambda target:formula_check('formula-native',target))
def formula_target(target):
    shutil.copytree(formula_inputs['math-unknown'][2],target);r=load(target/'formula.json');r['representation']='native_math';F.save(target/'formula.json',r);F.resynchronize_result(target)
reject('formula-target-forgery',formula_target,lambda target:formula_check('math-unknown',target))
def flow_check(profile_name,target):
    project,case,review,baseline,expected=flow_inputs['branch'];return P.verify_flow(project,case,review,baseline,target,expected,target_profile=math/(profile_name+'.json'))
def condition(target):
    shutil.copytree(ROOT/'cases/flow-branch',target);p=target/'流程预览.md';raw=p.read_bytes();old='签名区域可读'.encode();assert old in raw;p.write_bytes(raw.replace(old,'签名区域不可读'.encode(),1));P.refresh_flow(target)
reject('flow-condition-loss',condition,lambda target:flow_check('flow-current',target))
def renderer(target):
    shutil.copytree(ROOT/'cases/flow-unknown-version',target);r=load(target/'flow.json');r['representation']='flowchart';r['issue_codes']=[];P.save(target/'flow.json',r);P.refresh_flow(target)
reject('flow-renderer-forgery',renderer,lambda target:flow_check('flow-unknown-version',target))
def image_check(key,target):
    case,baseline,_,expected,profile=image_inputs[key];return I.verify_output(case,baseline,target,expected,target_profile=profile)
def head(target):
    shutil.copytree(image_inputs['image-signed-arrows'][2],target);I.mutate_svg(target,'relation-gain-head',lambda raw:b'');I.resynchronize_result(target)
reject('image-arrowhead-loss',head,lambda target:image_check('image-signed-arrows',target))
def image_target(target):
    shutil.copytree(image_inputs['image-unknown-version'][2],target);r=load(target/'image.json');r['representation']='svg_redraw';I.save(target/'image.json',r);I.resynchronize_result(target)
reject('image-target-forgery',image_target,lambda target:image_check('image-unknown-version',target))
def curve(target):
    shutil.copytree(image_inputs['image-curve-no-data'][2],target);(target/'invented-curve.csv').write_bytes(b'x,y\n0,0\n1,1\n');I.resynchronize_result(target)
reject('image-invented-curve-data',curve,lambda target:image_check('image-curve-no-data',target))
assert len(commands)==30 and len(setup_commands)==15 and len(rows)==27 and len(rejections)==7
after={name:pin((REPO/name).read_bytes()) for name in source_names};save(ROOT/'source-after.json',after);assert before==after
assert all(pin((REPO/name).read_bytes())==wanted for name,wanted in load(ROOT/'authority/rust-dependency-subset.json')['files'].items())
record('passed')
final=load(ROOT/'actual-checks.json');final.update(selected_pe=pin(CLI.read_bytes()),build_source_authority=pin((ROOT/'authority/build-source-binding.json').read_bytes()),
    source_inputs_unchanged=True,source_file_count=len(before),synthetic_numeric_loopback_requests=4,python=sys.executable,
    all_display_bindings_bytes_equal=all(item['all_bytes_equal'] for item in bindings),byte_binding_case_count=len(bindings),
    product_markdown_count=sum(row['file'].endswith('.md') for item in bindings for row in item['files']))
save(ROOT/'actual-checks.json',final)
print(json.dumps({k:final[k] for k in ('status','primary_count','additional_setup_count','total_actual_cli_calls','all_display_bindings_bytes_equal','product_markdown_count','synthetic_numeric_loopback_requests')}))
