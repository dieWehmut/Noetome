# 有据流程表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_flow",
  "scope": "active_flow_v1",
  "request_id": "0ecda5e7-5b30-4ba5-8fbb-c000140a62df",
  "binding": {
    "project_id": "5a5e0bba-0bdc-4544-b8fa-b659aefdc44d",
    "import_id": "ce9408a3-c744-47cc-bebd-b3ec6b0adb72",
    "source_id": "be3e5794-612a-4d4d-969f-32a6eaa11110",
    "version_id": "1b5995f6-2982-4257-963d-66b18bb8237d",
    "content_sha256": "1a662ed525031a2b69b8c72db6e88965eea4c3b9c61bd1348dd8f87d654f9491",
    "normalized_sha256": "1a662ed525031a2b69b8c72db6e88965eea4c3b9c61bd1348dd8f87d654f9491",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "model_support": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [
    "FLOW_TARGET_UNVERIFIED"
  ],
  "issues": [],
  "process_document": {
    "process": {
      "title": "样例签名分流",
      "entry": "s1",
      "goals": [
        "s2",
        "s3"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": [
        "资料不可读时暂停"
      ]
    },
    "steps": [
      {
        "id": "d1",
        "kind": "decision",
        "label": "检查签名",
        "description": "只判断签名是否完整",
        "criterion": "签名完整",
        "inputs": [
          "已接收卡"
        ],
        "outputs": [
          "签名判定结果"
        ],
        "conditions": [
          "卡片已接收"
        ],
        "exceptions": [
          "签名区域不可读时暂停判定"
        ]
      },
      {
        "id": "s1",
        "kind": "step",
        "label": "接收卡片",
        "description": "接收待判断的样例卡",
        "criterion": null,
        "inputs": [
          "待判断卡"
        ],
        "outputs": [
          "已接收卡"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "卡片破损时暂停"
        ]
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "进入归档队列",
        "description": "将真分支卡片加入归档队列",
        "criterion": null,
        "inputs": [
          "判据为真的卡片"
        ],
        "outputs": [
          "待归档卡"
        ],
        "conditions": [
          "签名完整"
        ],
        "exceptions": [
          "队列不可用时保留卡片"
        ]
      },
      {
        "id": "s3",
        "kind": "step",
        "label": "进入补签队列",
        "description": "将假分支卡片加入补签队列",
        "criterion": null,
        "inputs": [
          "判据为假的卡片"
        ],
        "outputs": [
          "待补签卡"
        ],
        "conditions": [
          "签名完整这一判据为假"
        ],
        "exceptions": [
          "队列不可用时保留卡片"
        ]
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "s1",
        "right": "d1",
        "kind": "sequence",
        "branch_outcome": null,
        "conditions": [
          "接收完成"
        ],
        "exceptions": [
          "破损卡不进入判定"
        ]
      },
      {
        "id": "r2",
        "left": "d1",
        "right": "s2",
        "kind": "branch",
        "branch_outcome": true,
        "conditions": [
          "签名区域可读"
        ],
        "exceptions": [
          "归档队列不可用时暂停"
        ]
      },
      {
        "id": "r3",
        "left": "d1",
        "right": "s3",
        "kind": "branch",
        "branch_outcome": false,
        "conditions": [
          "签名区域可读"
        ],
        "exceptions": [
          "补签队列不可用时暂停"
        ]
      }
    ],
    "evidence": [
      {
        "object_id": "d1",
        "start_byte": 336,
        "end_byte": 577,
        "quote": "判定 d1：\"检查签名\"。判据：\"签名完整\"。说明：\"只判断签名是否完整\"。输入：[\"已接收卡\"]。输出：[\"签名判定结果\"]。条件：[\"卡片已接收\"]。例外：[\"签名区域不可读时暂停判定\"]。"
      },
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 143,
        "quote": "过程：\"样例签名分流\"。入口：s1。目标：[\"s2\",\"s3\"]。条件：[\"演示模式开启\"]。例外：[\"资料不可读时暂停\"]。"
      },
      {
        "object_id": "r1",
        "start_byte": 1046,
        "end_byte": 1150,
        "quote": "关系 r1：s1 完成后执行 d1。条件：[\"接收完成\"]。例外：[\"破损卡不进入判定\"]。"
      },
      {
        "object_id": "r2",
        "start_byte": 1151,
        "end_byte": 1276,
        "quote": "关系 r2：d1 的判据为真时执行 s2。条件：[\"签名区域可读\"]。例外：[\"归档队列不可用时暂停\"]。"
      },
      {
        "object_id": "r3",
        "start_byte": 1277,
        "end_byte": 1402,
        "quote": "关系 r3：d1 的判据为假时执行 s3。条件：[\"签名区域可读\"]。例外：[\"补签队列不可用时暂停\"]。"
      },
      {
        "object_id": "s1",
        "start_byte": 144,
        "end_byte": 335,
        "quote": "步骤 s1：\"接收卡片\"。说明：\"接收待判断的样例卡\"。输入：[\"待判断卡\"]。输出：[\"已接收卡\"]。条件：[\"卡片可读\"]。例外：[\"卡片破损时暂停\"]。"
      },
      {
        "object_id": "s2",
        "start_byte": 578,
        "end_byte": 802,
        "quote": "步骤 s2：\"进入归档队列\"。说明：\"将真分支卡片加入归档队列\"。输入：[\"判据为真的卡片\"]。输出：[\"待归档卡\"]。条件：[\"签名完整\"]。例外：[\"队列不可用时保留卡片\"]。"
      },
      {
        "object_id": "s3",
        "start_byte": 803,
        "end_byte": 1045,
        "quote": "步骤 s3：\"进入补签队列\"。说明：\"将假分支卡片加入补签队列\"。输入：[\"判据为假的卡片\"]。输出：[\"待补签卡\"]。条件：[\"签名完整这一判据为假\"]。例外：[\"队列不可用时保留卡片\"]。"
      }
    ]
  },
  "profile": {
    "schema_version": 2,
    "producer": "flow_render_profile",
    "profile_id": "obsidian_1_15_0_pele_flowchart",
    "app": "Obsidian",
    "app_version": "1.15.0",
    "mermaid_version": null,
    "renderer": {
      "name": "pele",
      "version": "1.8.0",
      "source_sha256": "0000000000000000000000000000000000000000000000000000000000000000"
    },
    "flowchart_support": "supported",
    "label_encoding": "decimal_ascii_punctuation_v1",
    "html_labels": false
  },
  "representation": "ordered_list",
  "decision": {
    "rule_id": "verified_relations_text_fallback_v1",
    "reason": "来源关系已通过流程语义检查；当前显示条件采用有据文字回退。",
    "fallback_reasons": [
      {
        "code": "FLOW_TARGET_UNVERIFIED",
        "object_ids": [],
        "message": "所选目标版本或标签配置尚无本版实测依据，使用保留完整关系的文字表达。"
      }
    ]
  },
  "review_ir_fingerprint": {
    "sha256": "d04a0063831319cebf3d527c6b16e7f86037932e8cb61ab22eeb4ac4cba8faec",
    "byte_length": 9057
  },
  "plan_fingerprint": {
    "sha256": "37e21b7dcac8e3e7755c5f4874c1b9c451e2f5d802d7f8545597ae37a6d54081",
    "byte_length": 22447
  },
  "totals": {
    "branch_relations": 2,
    "causes_relations": 0,
    "content_mappings": 18,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 8,
    "flow_edges": 3,
    "flow_nodes": 4,
    "inhibits_relations": 0,
    "links": 16,
    "node_conditions": 4,
    "node_exceptions": 4,
    "node_inputs": 4,
    "node_outputs": 4,
    "parsed_statements": 8,
    "process_conditions": 1,
    "process_exceptions": 1,
    "promotes_relations": 0,
    "relation_conditions": 3,
    "relation_exceptions": 3,
    "relations": 3,
    "rendered_notes": 2,
    "sequence_relations": 1,
    "source_statements": 8,
    "steps": 4,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "inputs": {
    ".case.json": {
      "sha256": "e5ab7326532bfe1cd8729d3fa7c902a67882692799736ac05a157eae84dbec6a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "3a89a171a1113973694d785813fe40f63f294154294cdee5dc049721c326bfaa",
      "byte_length": 5149
    },
    ".profile.json": {
      "sha256": "c8668c833efe0b0ece96ee2eacea49407e0badff86da9d453b10ee1b56341f7a",
      "byte_length": 453
    },
    ".review-.case.json": {
      "sha256": "e5ab7326532bfe1cd8729d3fa7c902a67882692799736ac05a157eae84dbec6a",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "3a89a171a1113973694d785813fe40f63f294154294cdee5dc049721c326bfaa",
      "byte_length": 5149
    },
    ".review-.owner.json": {
      "sha256": "b6f6d7ac0c5ffd2613b18d79af4bddbcd5fa76816d12a7e82d06e174723db1b1",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "b766e95efc7a0da1005511b913a9b49d582c435689a6666a41883fff7d955a42",
      "byte_length": 2372
    },
    ".review-process-ir.json": {
      "sha256": "d04a0063831319cebf3d527c6b16e7f86037932e8cb61ab22eeb4ac4cba8faec",
      "byte_length": 9057
    },
    ".review-review.json": {
      "sha256": "4fc96e30cb89354f68a1b601d755b1c1592d1c1271f476c8c2b2db8e343a7720",
      "byte_length": 9035
    },
    ".review-review.md": {
      "sha256": "c085797ca9afb5becbc8ec10ebc8c24fc80ad4fb35043286144c5c53f7ac1299",
      "byte_length": 9218
    },
    ".source.json": {
      "sha256": "b766e95efc7a0da1005511b913a9b49d582c435689a6666a41883fff7d955a42",
      "byte_length": 2372
    }
  },
  "files": [
    {
      "relative_path": "流程总览.md",
      "note_id": "flow_overview",
      "plan_revision": 1,
      "content_sha256": "1722cab8e739fed35c27e434bd7007550a516c67a3ecd378dca7ab32f682821a",
      "byte_length": 3274,
      "content_mappings": [
        {
          "section_id": "flow",
          "block_id": "process_title",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 74
        },
        {
          "section_id": "flow",
          "block_id": "reading_scope",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 88,
          "end_byte": 349
        },
        {
          "section_id": "flow",
          "block_id": "fallback_reason",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [],
          "start_byte": 363,
          "end_byte": 465
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s1",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 880,
          "end_byte": 1155
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "d1",
          "source_object_ids": [
            "d1"
          ],
          "start_byte": 1228,
          "end_byte": 1512
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s2",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1585,
          "end_byte": 1893
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "kind": "list_item",
          "item_id": "s3",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 1966,
          "end_byte": 2292
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r1",
          "source_object_ids": [
            "d1",
            "r1",
            "s1"
          ],
          "start_byte": 2388,
          "end_byte": 2589
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r2",
          "source_object_ids": [
            "d1",
            "r2",
            "s2"
          ],
          "start_byte": 2662,
          "end_byte": 2902
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "kind": "list_item",
          "item_id": "r3",
          "source_object_ids": [
            "d1",
            "r3",
            "s3"
          ],
          "start_byte": 2975,
          "end_byte": 3215
        }
      ],
      "links": [
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "过程说明",
          "display_text": "查看完整过程说明",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 471,
          "end_byte": 525
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-d1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "d1"
          ],
          "start_byte": 526,
          "end_byte": 571
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 572,
          "end_byte": 617
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 618,
          "end_byte": 663
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "步骤-s3",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 664,
          "end_byte": 709
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 710,
          "end_byte": 755
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r2",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 756,
          "end_byte": 801
        },
        {
          "section_id": "flow",
          "block_id": "detail_links",
          "item_id": null,
          "target_path": "过程明细.md",
          "target_heading": "关系-r3",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r3"
          ],
          "start_byte": 802,
          "end_byte": 847
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s1",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 1167,
          "end_byte": 1212
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "d1",
          "target_path": "过程明细.md",
          "target_heading": "步骤-d1",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "d1"
          ],
          "start_byte": 1524,
          "end_byte": 1569
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s2",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s2",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 1905,
          "end_byte": 1950
        },
        {
          "section_id": "step_list",
          "block_id": "steps",
          "item_id": "s3",
          "target_path": "过程明细.md",
          "target_heading": "步骤-s3",
          "display_text": "查看步骤明细",
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 2304,
          "end_byte": 2349
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r1",
          "target_path": "过程明细.md",
          "target_heading": "关系-r1",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r1"
          ],
          "start_byte": 2601,
          "end_byte": 2646
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r2",
          "target_path": "过程明细.md",
          "target_heading": "关系-r2",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r2"
          ],
          "start_byte": 2914,
          "end_byte": 2959
        },
        {
          "section_id": "relation_list",
          "block_id": "relations",
          "item_id": "r3",
          "target_path": "过程明细.md",
          "target_heading": "关系-r3",
          "display_text": "查看关系明细",
          "source_object_ids": [
            "r3"
          ],
          "start_byte": 3227,
          "end_byte": 3272
        }
      ]
    },
    {
      "relative_path": "过程明细.md",
      "note_id": "process_details",
      "plan_revision": 1,
      "content_sha256": "914613316b45141927bec71f4168e7dd38e7abd8cd65b16867224b749f8a54b9",
      "byte_length": 2075,
      "content_mappings": [
        {
          "section_id": "process_detail",
          "block_id": "process",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "process"
          ],
          "start_byte": 41,
          "end_byte": 178
        },
        {
          "section_id": "step_d1",
          "block_id": "d1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "d1"
          ],
          "start_byte": 206,
          "end_byte": 451
        },
        {
          "section_id": "step_s1",
          "block_id": "s1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s1"
          ],
          "start_byte": 479,
          "end_byte": 715
        },
        {
          "section_id": "step_s2",
          "block_id": "s2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s2"
          ],
          "start_byte": 743,
          "end_byte": 1012
        },
        {
          "section_id": "step_s3",
          "block_id": "s3",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "s3"
          ],
          "start_byte": 1040,
          "end_byte": 1327
        },
        {
          "section_id": "relation_r1",
          "block_id": "r1",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "d1",
            "r1",
            "s1"
          ],
          "start_byte": 1355,
          "end_byte": 1526
        },
        {
          "section_id": "relation_r2",
          "block_id": "r2",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "d1",
            "r2",
            "s2"
          ],
          "start_byte": 1554,
          "end_byte": 1764
        },
        {
          "section_id": "relation_r3",
          "block_id": "r3",
          "kind": "text",
          "item_id": null,
          "source_object_ids": [
            "d1",
            "r3",
            "s3"
          ],
          "start_byte": 1792,
          "end_byte": 2002
        }
      ],
      "links": [
        {
          "section_id": "return",
          "block_id": "return_link",
          "item_id": null,
          "target_path": "流程总览.md",
          "target_heading": "流程表达",
          "display_text": "返回流程总览",
          "source_object_ids": [
            "process"
          ],
          "start_byte": 2025,
          "end_byte": 2073
        }
      ]
    }
  ],
  "artifacts": {
    ".case.json": {
      "sha256": "e5ab7326532bfe1cd8729d3fa7c902a67882692799736ac05a157eae84dbec6a",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "3a89a171a1113973694d785813fe40f63f294154294cdee5dc049721c326bfaa",
      "byte_length": 5149
    },
    ".owner.json": {
      "sha256": "c1f4ab7a966b612645154d622012fcff4196a8a7e3ecd566632f00a42e17f826",
      "byte_length": 146
    },
    ".profile.json": {
      "sha256": "c8668c833efe0b0ece96ee2eacea49407e0badff86da9d453b10ee1b56341f7a",
      "byte_length": 453
    },
    ".review-.case.json": {
      "sha256": "e5ab7326532bfe1cd8729d3fa7c902a67882692799736ac05a157eae84dbec6a",
      "byte_length": 363
    },
    ".review-.gold.json": {
      "sha256": "3a89a171a1113973694d785813fe40f63f294154294cdee5dc049721c326bfaa",
      "byte_length": 5149
    },
    ".review-.owner.json": {
      "sha256": "b6f6d7ac0c5ffd2613b18d79af4bddbcd5fa76816d12a7e82d06e174723db1b1",
      "byte_length": 170
    },
    ".review-.source.json": {
      "sha256": "b766e95efc7a0da1005511b913a9b49d582c435689a6666a41883fff7d955a42",
      "byte_length": 2372
    },
    ".review-process-ir.json": {
      "sha256": "d04a0063831319cebf3d527c6b16e7f86037932e8cb61ab22eeb4ac4cba8faec",
      "byte_length": 9057
    },
    ".review-review.json": {
      "sha256": "4fc96e30cb89354f68a1b601d755b1c1592d1c1271f476c8c2b2db8e343a7720",
      "byte_length": 9035
    },
    ".review-review.md": {
      "sha256": "c085797ca9afb5becbc8ec10ebc8c24fc80ad4fb35043286144c5c53f7ac1299",
      "byte_length": 9218
    },
    ".source.json": {
      "sha256": "b766e95efc7a0da1005511b913a9b49d582c435689a6666a41883fff7d955a42",
      "byte_length": 2372
    },
    "plan.json": {
      "sha256": "37e21b7dcac8e3e7755c5f4874c1b9c451e2f5d802d7f8545597ae37a6d54081",
      "byte_length": 22447
    },
    "流程总览.md": {
      "sha256": "1722cab8e739fed35c27e434bd7007550a516c67a3ecd378dca7ab32f682821a",
      "byte_length": 3274
    },
    "过程明细.md": {
      "sha256": "914613316b45141927bec71f4168e7dd38e7abd8cd65b16867224b749f8a54b9",
      "byte_length": 2075
    }
  }
}
```
