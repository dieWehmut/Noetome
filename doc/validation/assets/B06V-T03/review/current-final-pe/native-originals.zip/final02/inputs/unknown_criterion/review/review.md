# 有界过程来源核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "process_source_review",
  "scope": "bounded_process_text_v1",
  "request_id": "42561930-d6ee-4f57-8bfb-e6693b633e61",
  "binding": {
    "project_id": "66259a8d-5205-4160-9b2e-351baf7d191c",
    "import_id": "24972c71-2cd1-4529-a393-2f2a95343439",
    "source_id": "a4e9633b-015d-4758-9912-6329bb546719",
    "version_id": "f71faa4d-8fb6-4d89-86aa-c110014dc39d",
    "content_sha256": "ed70d6507618841afffdedd6bd28a0ab0df4e8ce91f5a30006fbec45d09d41cd",
    "normalized_sha256": "ed70d6507618841afffdedd6bd28a0ab0df4e8ce91f5a30006fbec45d09d41cd",
    "parse_id": null,
    "manifest_sha256": null
  },
  "selection": [
    {
      "kind": "text",
      "ordinal": 0
    }
  ],
  "status": "passed",
  "knowledge_status": "pending",
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "published": false,
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_parsing": "passed",
    "gold_match": "passed",
    "saved_output": "passed"
  },
  "issue_codes": [],
  "unparsed_statements": 0,
  "parsed_document": {
    "process": {
      "title": "未知判据的分流说明",
      "entry": "d1",
      "goals": [
        "s1",
        "s2"
      ],
      "conditions": [
        "演示模式开启"
      ],
      "exceptions": []
    },
    "steps": [
      {
        "id": "d1",
        "kind": "decision",
        "label": "执行待明确的判定",
        "description": "来源未列明实际判据",
        "criterion": null,
        "inputs": [
          "样例卡"
        ],
        "outputs": [
          "未知"
        ],
        "conditions": [
          "卡片可读"
        ],
        "exceptions": [
          "判据未确认前不能执行"
        ]
      },
      {
        "id": "s1",
        "kind": "step",
        "label": "真支处理",
        "description": "只记录真支去向",
        "criterion": null,
        "inputs": [
          "真支卡片"
        ],
        "outputs": [
          "真支结果"
        ],
        "conditions": [],
        "exceptions": []
      },
      {
        "id": "s2",
        "kind": "step",
        "label": "假支处理",
        "description": "只记录假支去向",
        "criterion": null,
        "inputs": [
          "假支卡片"
        ],
        "outputs": [
          "假支结果"
        ],
        "conditions": [],
        "exceptions": []
      }
    ],
    "relations": [
      {
        "id": "r1",
        "left": "d1",
        "right": "s1",
        "kind": "branch",
        "branch_outcome": true,
        "conditions": [],
        "exceptions": []
      },
      {
        "id": "r2",
        "left": "d1",
        "right": "s2",
        "kind": "branch",
        "branch_outcome": false,
        "conditions": [],
        "exceptions": []
      }
    ],
    "evidence": [
      {
        "object_id": "d1",
        "start_byte": 127,
        "end_byte": 346,
        "quote": "判定 d1：\"执行待明确的判定\"。判据：null。说明：\"来源未列明实际判据\"。输入：[\"样例卡\"]。输出：[\"未知\"]。条件：[\"卡片可读\"]。例外：[\"判据未确认前不能执行\"]。"
      },
      {
        "object_id": "process",
        "start_byte": 0,
        "end_byte": 126,
        "quote": "过程：\"未知判据的分流说明\"。入口：d1。目标：[\"s1\",\"s2\"]。条件：[\"演示模式开启\"]。例外：[]。"
      },
      {
        "object_id": "r1",
        "start_byte": 645,
        "end_byte": 718,
        "quote": "关系 r1：d1 的判据为真时执行 s1。条件：[]。例外：[]。"
      },
      {
        "object_id": "r2",
        "start_byte": 719,
        "end_byte": 792,
        "quote": "关系 r2：d1 的判据为假时执行 s2。条件：[]。例外：[]。"
      },
      {
        "object_id": "s1",
        "start_byte": 347,
        "end_byte": 495,
        "quote": "步骤 s1：\"真支处理\"。说明：\"只记录真支去向\"。输入：[\"真支卡片\"]。输出：[\"真支结果\"]。条件：[]。例外：[]。"
      },
      {
        "object_id": "s2",
        "start_byte": 496,
        "end_byte": 644,
        "quote": "步骤 s2：\"假支处理\"。说明：\"只记录假支去向\"。输入：[\"假支卡片\"]。输出：[\"假支结果\"]。条件：[]。例外：[]。"
      }
    ]
  },
  "totals": {
    "branch_relations": 2,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 0,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 2,
    "sequence_relations": 0,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "expected_totals": {
    "branch_relations": 2,
    "causes_relations": 0,
    "correlates_relations": 0,
    "decision_steps": 1,
    "evidence_records": 6,
    "inhibits_relations": 0,
    "node_conditions": 1,
    "node_exceptions": 1,
    "node_inputs": 3,
    "node_outputs": 3,
    "parsed_statements": 6,
    "process_conditions": 1,
    "process_exceptions": 0,
    "promotes_relations": 0,
    "relation_conditions": 0,
    "relation_exceptions": 0,
    "relations": 2,
    "sequence_relations": 0,
    "source_statements": 6,
    "steps": 3,
    "unknown_relations": 0,
    "unparsed_statements": 0
  },
  "gold_sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
  "ir_fingerprint": {
    "sha256": "540dcd11f73c59f39689f3b20d7d8b908c637e935d93950280b39c03e3796b4c",
    "byte_length": 6089
  },
  "inputs": {
    ".case.json": {
      "sha256": "cf5d10245b304ff1d979dd5d8429e9a70a1fed0347520544e299089812fe4ace",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".source.json": {
      "sha256": "149eed1ded19384dfa61d01c047a2dc1fbf7cb512d31bd4ca588a25a30eafe01",
      "byte_length": 1723
    }
  },
  "artifacts": {
    ".case.json": {
      "sha256": "cf5d10245b304ff1d979dd5d8429e9a70a1fed0347520544e299089812fe4ace",
      "byte_length": 363
    },
    ".gold.json": {
      "sha256": "a09214fe74630677143c32788eb135e2a9d7ca04bb41a78a8d69bcfb739aae65",
      "byte_length": 3212
    },
    ".owner.json": {
      "sha256": "085c0be17e1b06aff68f03b7d4c471c9b44847f2724fe00350fb44411df2615e",
      "byte_length": 170
    },
    ".source.json": {
      "sha256": "149eed1ded19384dfa61d01c047a2dc1fbf7cb512d31bd4ca588a25a30eafe01",
      "byte_length": 1723
    },
    "process-ir.json": {
      "sha256": "540dcd11f73c59f39689f3b20d7d8b908c637e935d93950280b39c03e3796b4c",
      "byte_length": 6089
    }
  }
}
```
