import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
const [modulePath,inputPath]=process.argv.slice(2);
const {chromium}=await import(pathToFileURL(modulePath));
const input=JSON.parse(fs.readFileSync(inputPath,'utf8'));
const work=path.dirname(inputPath);
const browser=await chromium.connectOverCDP('http://127.0.0.1:'+input.port);
const obs=browser.contexts()[0].pages()[0];
const result={status:'running',notes:[],clicks:[]};

const compatibilityInput = input.spec;
assert(compatibilityInput && compatibilityInput.runtime && ['light','dark'].includes(compatibilityInput.theme));
const compatibilityCdp = await obs.context().newCDPSession(obs);
const compatibilityScripts = new Map();
compatibilityCdp.on('Debugger.scriptParsed', e => compatibilityScripts.set(e.scriptId, {id:e.scriptId,url:e.url}));
await compatibilityCdp.send('Debugger.enable');
const compatibilityIdentity = async () => {
  const expected = compatibilityInput.runtime;
  const actual = await obs.evaluate(runtime => {
    const fs = require('fs'), rawFs = require('original-fs'), path = require('path'), crypto = require('crypto');
    const pin = file => {const raw=rawFs.readFileSync(file); return {sha256:crypto.createHash('sha256').update(raw).digest('hex'),byte_length:raw.length};};
    const files = {};
    for (const key of ['executable','app_asar','obsidian_asar']) files[key] = pin(runtime[key].path);
    return {appVersion:require('@electron/remote').app.getVersion(),execPath:process.execPath,files,
      appPackageVersion:JSON.parse(fs.readFileSync(path.join(runtime.app_asar.path,'package.json'),'utf8')).version,
      obsidianPackageVersion:JSON.parse(fs.readFileSync(path.join(runtime.obsidian_asar.path,'package.json'),'utf8')).version,
      themeClass:document.body.className};
  }, expected);
  const norm = p => p.replace(/\\+/g,'/').toLowerCase();
  assert.equal(norm(actual.execPath),norm(expected.executable.path),'actual native executable path');
  assert.equal(actual.appVersion,expected.app_version,'actual application version from independent installation');
  assert.equal(actual.appPackageVersion,expected.app_version);
  assert.equal(actual.obsidianPackageVersion,expected.app_version);
  for (const key of ['executable','app_asar','obsidian_asar'])
    assert.deepEqual(actual.files[key],{sha256:expected[key].sha256,byte_length:expected[key].byte_length},'actual selected installation bytes');
  await obs.waitForFunction(theme => document.body.classList.contains('theme-'+theme),compatibilityInput.theme,{timeout:15000});
  actual.themeClass = await obs.evaluate(() => document.body.className);
  assert(actual.themeClass.split(/\s+/).includes('theme-'+compatibilityInput.theme),'actual selected theme');
  const copied = await obs.evaluate(({root,pins}) => {
    const fs=require('fs'),path=require('path'),crypto=require('crypto');
    return Object.fromEntries(Object.keys(pins).map(name => {
      const raw=fs.readFileSync(path.join(root,name));
      return [name,{sha256:crypto.createHash('sha256').update(raw).digest('hex'),byte_length:raw.length}];
    }));
  },{root:input.vault,pins:input.source_pins});
  assert.deepEqual(copied,input.source_pins,'native collector reads all exact frozen output files');
  return actual;
};
const compatibilityLoaded = async () => {
  const globals = await obs.evaluate(() => ({mathjaxVersion:window.MathJax?.version ?? null,
    mermaidVersion:window.mermaid?.version ?? null,mermaidPresent:!!window.mermaid,
    pelePresent:typeof pele!=='undefined',peleVersion:typeof pele!=='undefined'?pele.version??null:null,
    resourceUrls:performance.getEntriesByType('resource').map(e=>e.name)}));
  const evidence = {globals,modules:{}};
  const crypto = await import('node:crypto');
  const checks = [['mathjax',compatibilityInput.require_mathjax_runtime],['mermaid',compatibilityInput.require_mermaid_runtime]];
  if (compatibilityInput.runtime.app_bundle) checks.push(['app_bundle',true]);
  for (const [key,required] of checks) {
    const expected = compatibilityInput.runtime[key], wanted = expected.member;
    if (!required) {evidence.modules[key]={status:'not_loaded_or_not_required',declaredVersion:expected.version};continue;}
    if (key==='mathjax') assert.equal(globals.mathjaxVersion,expected.version,'actual MathJax runtime version');
    else if (key==='mermaid') {
      const engine=typeof expected.engine==='object'?expected.engine.name:expected.engine;
      if (engine!=='pele' && engine!=='pele_compatibility_shim')
        assert(globals.mermaidPresent,'actual standard Mermaid API is present');
      if (globals.mermaidVersion!==null && expected.version!==null && expected.version!=='unknown')
        assert.equal(globals.mermaidVersion,expected.version,'actual exposed Mermaid version');
      if (expected.version!==null && expected.version!=='unknown' && globals.mermaidVersion===null)
        assert.equal(expected.version_binding?.version,expected.version,'unknown global version still requires installed source literal and executed member bytes');
    }
    const basename = wanted.path.split('/').pop();
    const candidates = [...compatibilityScripts.values()].filter(e => e.url.split(/[?#]/)[0].endsWith('/'+basename));
    let bound = null;
    for (const candidate of candidates) {
      const response = await compatibilityCdp.send('Debugger.getScriptSource',{scriptId:candidate.id});
      const raw = Buffer.from(response.scriptSource,'utf8'), prefix = raw.subarray(0,wanted.byte_length);
      const digest = crypto.createHash('sha256').update(prefix).digest('hex');
      const suffix = raw.subarray(wanted.byte_length).toString('utf8');
      // Obsidian may append an explicit sourceURL comment to evaluated library
      // bytes. Do not discard code, select another answer, or normalize syntax.
      const allowedSuffix = suffix==='' || suffix==='\n//# sourceURL='+candidate.url || suffix==='\n//# sourceURL='+candidate.url+'\n';
      if (prefix.length===wanted.byte_length && digest===wanted.sha256 && allowedSuffix) {
        bound={status:'passed',url:candidate.url,member:wanted,rawSha256:crypto.createHash('sha256').update(raw).digest('hex'),
          rawByteLength:raw.length,sourceUrlComment:suffix,declaredVersion:expected.version??null,backend:expected.engine??expected.backend??null,
          observedVersion:key==='mathjax'?globals.mathjaxVersion:key==='mermaid'?globals.mermaidVersion:null,
          versionBinding:expected.version_binding??null,
          method:'actual CDP executed script source bound to installed ASAR member bytes'};
        break;
      }
    }
    assert(bound,'actual executed '+key+' resource must match the independently pinned installed member');
    evidence.modules[key]=bound;
  }
  return evidence;
};


const compatibilityParagraphText=(raw,terminalBreak)=>({paragraphText:raw,
  comparisonText:terminalBreak && raw.endsWith('\n')?raw.slice(0,-1):raw,
  removedOneTerminalLf:terminalBreak && raw.endsWith('\n')});

const readFormatTarget = wanted => {
  const view=document.querySelector('.workspace-leaf.mod-active .markdown-preview-view');
  const matches=Array.from(view.querySelectorAll(wanted.blockId?'p':'h2')).map(element=>{
    const finalElement=element.lastElementChild;
    const terminalBreak=element.tagName==='P' && finalElement?.tagName==='BR' &&
      Array.from(element.childNodes).slice(Array.from(element.childNodes).indexOf(finalElement)+1).every(n=>n.nodeType===Node.TEXT_NODE && n.textContent==='\n');
    const raw=element.innerText;
    const comparison={paragraphText:raw,comparisonText:terminalBreak && raw.endsWith('\n')?raw.slice(0,-1):raw,
      removedOneTerminalLf:terminalBreak && raw.endsWith('\n')};
    const a=element.getBoundingClientRect(),b=view.getBoundingClientRect();
    return {...comparison,terminalBreak,dom:element.outerHTML,rect:{x:a.x,y:a.y,width:a.width,height:a.height},
      previewRect:{x:b.x,y:b.y,width:b.width,height:b.height},
      visible:a.width>0 && a.height>0 && a.top>=b.top-1 && a.bottom<=b.bottom+1};
  }).filter(element=>element.comparisonText===wanted.text);
  const cache=window.app.metadataCache.getFileCache(window.app.vault.getAbstractFileByPath(wanted.file));
  return {activeFile:window.app.workspace.getActiveFile()?.path,activeState:window.app.workspace.activeLeaf.view.getState(),
    blockId:wanted.blockId??null,cachedBlock:wanted.blockId?cache?.blocks?.[wanted.blockId]??null:null,
    targetCount:matches.length,targets:matches,visible:matches.length===1 && matches[0].visible &&
      window.app.workspace.getActiveFile()?.path===wanted.file && (!wanted.blockId || cache?.blocks?.[wanted.blockId]?.id===wanted.blockId),dom:view.outerHTML};
};
let owned=false;
try {
  await obs.waitForFunction(()=>window.app?.workspace?.layoutReady,{timeout:30000});
  const identity=await obs.evaluate(()=>({userData:require('@electron/remote').app.getPath('userData'),
    vaultPath:window.app.vault.adapter.basePath,communityPlugins:Object.keys(window.app.plugins.plugins)}));
  const norm=p=>p.replace(/\\+/g,'/').toLowerCase();
  assert.equal(norm(identity.userData),norm(input.profile));assert.equal(norm(identity.vaultPath),norm(input.vault));
  owned=true;assert.deepEqual(identity.communityPlugins,[]);
  result.compatibilityIdentity=await compatibilityIdentity();
  const name=input.spec.notes[0],expected=input.spec.format_expected;
  await obs.waitForFunction(p=>window.app.vault.getAbstractFileByPath(p),name);
  await obs.evaluate(async p=>window.app.workspace.getLeaf(false).openFile(window.app.vault.getAbstractFileByPath(p),{active:true,state:{mode:'preview'}}),name);
  await obs.waitForFunction(p=>window.app.workspace.getActiveFile()?.path===p&&window.app.workspace.activeLeaf?.view?.getState()?.mode==='preview',name);
  await obs.locator('.workspace-leaf.mod-active .markdown-preview-view').waitFor({state:'visible'});
  const actual=await obs.evaluate(async name=>{
    const view=document.querySelector('.workspace-leaf.mod-active .markdown-preview-view'),cache=window.app.metadataCache.getFileCache(window.app.vault.getAbstractFileByPath(name));
    return {frontmatter:cache?.frontmatter,blocks:cache?.blocks,rawSource:await window.app.vault.cachedRead(window.app.vault.getAbstractFileByPath(name)),properties:Array.from(view.querySelectorAll('.metadata-property')).map(e=>{
      const value=e.querySelector('.metadata-property-value'),r=e.getBoundingClientRect(),style=getComputedStyle(e);
      return {key:e.getAttribute('data-property-key'),parentType:e.getAttribute('data-property-type'),valueType:value?.getAttribute('data-property-type')??null,
        parentAttributes:Object.fromEntries(Array.from(e.attributes).map(a=>[a.name,a.value])),valueAttributes:value?Object.fromEntries(Array.from(value.attributes).map(a=>[a.name,a.value])):null,
        fieldLabel:e.querySelector('.metadata-property-key-input')?.value??null,titleValue:e.querySelector('.metadata-input-longtext')?.innerText??null,
        checkboxChecked:e.querySelector('.metadata-input-checkbox')?.checked??null,chips:Array.from(e.querySelectorAll('.multi-select-pill-content')).map(n=>n.innerText),
        rect:{width:r.width,height:r.height},display:style.display,visibility:style.visibility,text:e.innerText};}),
      callouts:Array.from(view.querySelectorAll('[data-callout]')).map(e=>({type:e.getAttribute('data-callout'),title:e.querySelector('.callout-title-inner')?.innerText,body:e.querySelector('.callout-content')?.innerText})),
      headings:Array.from(view.querySelectorAll('h2')).map(e=>e.innerText),links:Array.from(view.querySelectorAll('a.internal-link')).map(e=>({href:e.getAttribute('data-href'),text:e.innerText})),dom:view.outerHTML};
  },name);
  const record={file:name,actual,status:'checking'};result.notes.push(record);
  fs.writeFileSync(path.join(work,'note-0.html'),actual.dom,{flag:'wx'});
  await obs.screenshot({path:path.join(work,'note-0.png'),fullPage:true});
  for (const [key,value] of Object.entries(expected.semantic_source.frontmatter)) assert.deepEqual(actual.frontmatter[key],value,'native YAML/Properties type and value');
  for (const [key,type] of Object.entries(expected.collector.properties_types)) {
    const property=actual.properties.find(p=>p.key===key);assert(property,'actual visible Properties row '+key);
    // Native Obsidian calls its aliases/list widget "multitext". Keep the
    // author's YAML array expectation and preserve the observed native enum.
    const current=input.spec.runtime.app_version==='1.15.0';
    const nativeType={text:'text',checkbox:'checkbox',list:current?'aliases':'multitext'}[type];
    assert(nativeType,'explicit supported conceptual Properties type');
    property.typeSource=current?'actual value child data-property-type':'actual property row data-property-type';
    property.type=current?property.valueType:property.parentType;
    property.expectedSemanticType=type;property.expectedNativeType=nativeType;
    assert.equal(property.type,nativeType,'actual Properties renderer type');
    assert(property.rect.width>0 && property.rect.height>0 && property.display!=='none' && property.visibility!=='hidden','actual Properties control has visible area');
    assert.equal(property.fieldLabel,key,'actual visible Properties field label');
    const authoredValue=expected.semantic_source.frontmatter[key];
    if(type==='text')assert.equal(property.titleValue,authoredValue,'actual visible text control preserves the authored value');
    else if(type==='checkbox')assert.equal(property.checkboxChecked,authoredValue,'actual native checkbox preserves the authored boolean');
    else assert.deepEqual(property.chips,authoredValue,'actual native aliases/list chips preserve the authored array');
  }
  const wanted=expected.collector.callout;
  assert(actual.callouts.some(c=>c.type===expected.semantic_source.callout.type&&c.title===wanted.title&&c.body===wanted.body),'native Callout type/title/body');
  const authoredBlock=expected.semantic_source.block,cachedBlock=actual.blocks?.[authoredBlock.id];
  assert(cachedBlock && cachedBlock.id===authoredBlock.id,'actual metadata cache retains the exact authored block ID');
  const sourceLines=actual.rawSource.split('\n'),line=cachedBlock.position.start.line;
  assert.equal(sourceLines[line],authoredBlock.text,'actual cached block source start identifies the exact authored paragraph');
  assert.equal(sourceLines[line+1],'^'+authoredBlock.id,'actual block marker is attached to that exact source paragraph');
  record.status='passed';
  for (const link of expected.collector.real_click_links) {
    const locator=obs.locator('.workspace-leaf.mod-active .markdown-preview-view a.internal-link').filter({hasText:link.label});
    assert.equal(await locator.count(),1);assert.equal(await locator.getAttribute('data-href'),link.target,'actual clicked source fragment');await locator.click();
    await obs.waitForFunction(p=>window.app.workspace.getActiveFile()?.path===p,link.destination);
    const target=link.target_heading??link.target_text;
    const args={text:target,file:link.destination,blockId:link.target_block_id??null};
    const clicked={target:link.target,destination:link.destination,actualClick:true,status:'checking',beforeWait:await obs.evaluate(readFormatTarget,args)};
    result.clicks.push(clicked);const number=result.clicks.length;
    fs.writeFileSync(path.join(work,'click-'+number+'-before-wait.html'),clicked.beforeWait.dom,{flag:'wx'});
    await obs.screenshot({path:path.join(work,'click-'+number+'-before-wait.png'),fullPage:true});
    try {
      await obs.waitForFunction('wanted => ('+readFormatTarget.toString()+')(wanted).visible',args,{timeout:10000});
      clicked.afterWait=await obs.evaluate(readFormatTarget,args);
      assert.equal(clicked.afterWait.targetCount,1);assert(clicked.afterWait.visible,'actual clicked fragment target is visible without corrective scrolling');
      if(link.target_block_id){assert.equal(clicked.afterWait.cachedBlock.id,link.target_block_id);
        const p=clicked.afterWait.targets[0],comparison=compatibilityParagraphText(p.paragraphText,p.terminalBreak);
        assert.equal(comparison.comparisonText,target,'only the observed single terminal BR newline may differ');
        clicked.paragraphComparison=comparison;}
      clicked.visibleTarget=target;clicked.status='passed';
    } finally {
      clicked.finalObservation=await obs.evaluate(readFormatTarget,args);
      fs.writeFileSync(path.join(work,'click-'+number+'.html'),clicked.finalObservation.dom,{flag:'wx'});
      await obs.screenshot({path:path.join(work,'click-'+number+'.png'),fullPage:true});
    }
  }
  result.compatibilityRuntime=await compatibilityLoaded();result.status='passed';
}catch(error){result.status='failed';result.error={message:String(error),stack:error.stack};process.exitCode=1;
}finally{
  fs.writeFileSync(path.join(work,'result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
  if(owned)await obs.evaluate(()=>setTimeout(()=>require('@electron/remote').app.quit(),100)).catch(()=>{});
  await browser.close();
}
console.log(JSON.stringify({status:result.status,notes:result.notes.length,clicks:result.clicks.length}));
