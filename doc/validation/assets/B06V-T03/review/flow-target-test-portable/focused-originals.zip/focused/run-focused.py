from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time
import unittest

REPO=Path('/home/lyinn/project/Noetome')
OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(REPO/'tests'),str(REPO/'scripts')]
import test_verify_process_flow as T
import test_visual_capability_registry as R

def pin(raw):return dict(sha256=hashlib.sha256(raw).hexdigest(),byte_length=len(raw))
def save(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
names=['tests/test_verify_process_flow.py','tests/test_visual_capability_registry.py','scripts/verify_process_flow.py','scripts/visual_capability_registry.py']
before={name:pin((REPO/name).read_bytes()) for name in names}
save(OUT/'source-before.json',before)
real_run=subprocess.run
commands=[]
def captured_run(argv,*args,**kwargs):
    started=time.monotonic();result=real_run(argv,*args,**kwargs)
    prefix=OUT/f'command-{len(commands):02d}'
    prefix.with_suffix('.stdout.bin').write_bytes(result.stdout)
    prefix.with_suffix('.stderr.bin').write_bytes(result.stderr)
    receipt=dict(argv=list(map(str,argv)),exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,
        stdout=pin(result.stdout),stderr=pin(result.stderr))
    save(prefix.with_suffix('.receipt.json'),receipt);commands.append(receipt)
    return result
subprocess.run=captured_run
setup=T.FlowTargetCliTests.setUpClass.__func__
def retained_setup(cls):
    setup(cls)
    # Retain only this new public test root; test assertions and ordinary
    # subprocess behavior are unchanged. It is archived after the suite.
    cls.temp._finalizer.detach()
    cls.temp.cleanup=lambda:None
    save(OUT/'selected-test-root.json',dict(path=str(cls.root),purpose='preserved public fixture and actual ordinary CLI target tests'))
T.FlowTargetCliTests.setUpClass=classmethod(retained_setup)
suite=unittest.TestSuite()
for cls in (T.FlowTargetCliTests,T.FlowRendererProfileTests,R.IndependentCapabilityTests):
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(cls))
with (OUT/'unittest.stderr.bin').open('w',encoding='utf-8') as stream:
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
after={name:pin((REPO/name).read_bytes()) for name in names}
save(OUT/'source-after.json',after)
save(OUT/'actual-checks.json',dict(status='passed' if result.wasSuccessful() and before==after else 'failed',
    tests_run=result.testsRun,skipped=len(result.skipped),failures=len(result.failures),errors=len(result.errors),
    commands=commands,source_unchanged=before==after,real_model_calls=0,paid_calls=0))
raise SystemExit(0 if result.wasSuccessful() and before==after else 1)
