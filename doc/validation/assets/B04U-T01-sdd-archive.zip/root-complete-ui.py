import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path.cwd()
workspace = root/'.superpowers/sdd/B04U-T01_HEADER_PLAN'
assets = root/'doc/validation/assets'
for name in ('final-review.md','final-review-evidence.json'):
    data = (workspace/name).read_bytes()
    if name.endswith('.md'):
        data = data.replace(b'\r\n',b'\n').rstrip(b'\n')+b'\n'
    (assets/('B04U-T01-'+name)).write_bytes(data)
shutil.copyfile(Path(r'C:\Users\Lyinn\AppData\Local\Temp\codex-clipboard-e4731cc6-a8e0-4f9f-a719-f6aa619c2330.png'), assets/'B04U-T01-reference-breadcrumb.png')
shutil.copyfile(Path(r'C:\Users\Lyinn\AppData\Local\Temp\codex-clipboard-26bddc82-98be-422a-8942-7a42e843be4e.png'), assets/'B04U-T01-reference-codex.png')
path = root/'doc/validation/B04U-T01.md'
data = path.read_text(encoding='utf-8')
old = '最终文档与证据的独立整分支审查和完成状态由后续真实记录补齐。'
assert old in data
data = data.replace(old, '[最终整分支审查](assets/B04U-T01-final-review.md)核对25bcff5..4969f88，Ready yes，无Critical/Important/可行动Minor问题；[75项证据断言](assets/B04U-T01-final-review-evidence.json)核对该范围的32份资产指纹、原命令输出、实际浏览器/native结果和设置/安装一致性。原审查连接中断后同一审查者恢复完成，没有重跑产品测试。')
data += '\n本轮按已授权普通提交/推送和本机应用更新执行，界面提交只包含当前顶部栏及证据。为保留进行中的模型修复，安装与Rust检查使用共享工作树；其CLI源指纹已明确记录，若需该UI提交的另一份干净后端快照，应另行重建，不把本轮模型任务记为完成。测试专用CDP进程已结束，新版Noetome已以普通方式重新启动。用户参考图另保存在[Codex顶部](assets/B04U-T01-reference-codex.png)和[原面包屑](assets/B04U-T01-reference-breadcrumb.png)。\n'
path.write_bytes(data.encode())
with (workspace/'progress.md').open('ab') as file:
    file.write(b'\nFinal review: Ready yes for25bcff5..4969f88;75 evidence assertions,0 Critical/Important/Minor. UI task completion and ordinary feature-branch push authorized; source/behavior unchanged after final review.\n')
print('Final review integrated; original reviewed manifest retained unchanged.')
