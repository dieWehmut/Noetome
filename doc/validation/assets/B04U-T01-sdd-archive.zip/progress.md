# SDD ledger — plan: D:/Noetome/doc/execution/B04U-T01_HEADER_PLAN.md

| Task | Produces/consumes | Preflight finding |
| --- | --- | --- |
| 1 | App.tsx, styles.css and optional AppMenuBar.tsx produce screenshot-based top bar; controller consumes it through browser and native app | Existing settings component and IPC remain the authority; actual preview failures are not native validation |
| 1 self | Removal, actual history/sidebar, menu behavior; TypeScript/build and browser actions | Coherent; no synthetic model call or production Vault operation is needed |

Ruling: use the existing task branch with preserved dirty API work — root owns unrelated paths; UI implementer commits only its frontend paths. This avoids losing current work and keeps UI review scope explicit.

Ruling: ordinary frontend/native installation and feature-branch commits/push are already authorized by user instructions. Do not request them again.

Task 1: in progress. Plan base 25bcff5b474611fdb2b1c1f96eb0a33caae42e4d; branch codex/b04u-t01-codex-header. Browser preimplementation RED recorded in doc/validation/assets/B04U-T01-browser-red.json; screenshot B04U-T01-before.png.

Task 1: complete (commits 25bcff5..8d7f2c6, task and style reviews clean). Root browser13/native9 plus actual runtime/get-settings passed; Rust499/fmt/check and full Tauri/NSIS build/install passed. Archive formatting check failure8f39c87 was preserved and corrected4969f88 without product edits. Final branch review pending against25bcff5..4969f88.
Ruling cost: shared dirty API work means the installed executable and Rust499 evidence include its current sources; the UI report explicitly identifies them instead of attributing API acceptance to this task. Rebuilding from a clean UI commit would be required if that different backend snapshot were wanted.
Authorization context: ordinary UI install, feature-branch commits and push follow the user's explicit project instructions; no new external service or secret entry is involved.

Final review: Ready yes for25bcff5..4969f88;75 evidence assertions,0 Critical/Important/Minor. UI task completion and ordinary feature-branch push authorized; source/behavior unchanged after final review.
