"""Stage only UI work and preserve unrelated API changes and user deletions."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
owned = ['dev-log/tasks.json','dev-log/STATUS.md','dev-log/TODO.md','dev-log/DONE.md',
         'doc/execution/NEXT_STEPS.md','doc/execution/B04U-T01_HEADER_PLAN.md',
         'doc/standards/DESIGN.md','doc/standards/TESTING.md',
         'doc/requirements/MODEL_SERVICE.md','doc/validation/B04U-T01.md']
source = root/'.superpowers/sdd/B04U-T01_HEADER_PLAN/root-header-browser-first-source.mjs'
(root/'doc/validation/assets/B04U-T01-browser-first-source.mjs').write_bytes(source.read_bytes())
assets = sorted((root/'doc/validation/assets').glob('B04U-T01-*'))
for name in owned:
    if name.endswith('.md') and not name.startswith('dev-log/'):
        p = root/name
        p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
for p in assets:
    if p.suffix == '.md':
        p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
manifest = {str(p.relative_to(root)).replace('\\','/'): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
            for p in assets if p.name != 'B04U-T01-assets.json'}
(root/'doc/validation/assets/B04U-T01-assets.json').write_bytes((json.dumps(manifest, indent=2)+'\n').encode())
ui_attributes = (
    '# Keep this task\'s original command output and executable verification source.\n'
    'doc/validation/assets/B04U-T01-*.json -text whitespace=cr-at-eol\n'
    'doc/validation/assets/B04U-T01-*.mjs -text whitespace=cr-at-eol\n'
    'doc/validation/assets/B04U-T01-*.py -text whitespace=cr-at-eol\n'
).encode()
original = subprocess.check_output(['git','show','HEAD:.gitattributes'])
assert ui_attributes in (root/'.gitattributes').read_bytes().replace(b'\r\n',b'\n')
digest = subprocess.check_output(['git','hash-object','-w','--stdin'], input=original+ui_attributes).decode().strip()
subprocess.run(['git','update-index','--add','--cacheinfo','100644',digest,'.gitattributes'], check=True)
assets = sorted((root/'doc/validation/assets').glob('B04U-T01-*'))
subprocess.run(['git','add','--',*owned,*[str(p.relative_to(root)) for p in assets]], check=True)
staged = subprocess.check_output(['git','diff','--cached','--name-only']).decode().splitlines()
allowed = set(owned)|{'.gitattributes'}|{str(p.relative_to(root)).replace('\\','/') for p in assets}
assert set(staged) <= allowed, staged
assert not any(name.startswith('docs/') or name.startswith('crates/') or 'B04-T02-' in name for name in staged), staged
for p in assets:
    name = str(p.relative_to(root)).replace('\\','/')
    blob = subprocess.check_output(['git','show',':'+name])
    assert blob == p.read_bytes(), name
print(json.dumps({'staged_files':len(staged),'exact_ui_assets':len(assets),'unrelated_paths_staged':False}))
