import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
first = subprocess.run(['git','diff','HEAD^','HEAD','--check'], capture_output=True)
assert first.returncode != 0
record = {'command':['git','diff','8d7f2c6','8f39c87','--check'], 'exit_code':first.returncode,
          'stdout':first.stdout.decode(), 'stderr':first.stderr.decode(),
          'reason':'Review Markdown archive ended with an extra blank line. UI implementation and behavior unchanged.'}
(root/'doc/validation/assets/B04U-T01-archive-first-diff-check.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
p = root/'doc/validation/assets/B04U-T01-task-review.md'
p.write_bytes(p.read_bytes().rstrip(b'\n')+b'\n')
doc = root/'doc/validation/B04U-T01.md'
text = doc.read_text(encoding='utf-8')
text += '\n归档初次暂存差异检查发现审查Markdown末尾多余空行，记录于[原检查](assets/B04U-T01-archive-first-diff-check.json)。该归档提交已保留，后续只修正末尾空行并更新资产指纹；产品代码和已执行行为检查不变，最终差异检查重新运行。\n'
doc.write_bytes(text.encode())
assets = sorted((root/'doc/validation/assets').glob('B04U-T01-*'))
manifest = {str(p.relative_to(root)).replace('\\','/'): {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes':p.stat().st_size}
            for p in assets if p.name != 'B04U-T01-assets.json'}
(root/'doc/validation/assets/B04U-T01-assets.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
subprocess.run(['git','add','--','doc/validation/B04U-T01.md','doc/validation/assets/B04U-T01-task-review.md',
                'doc/validation/assets/B04U-T01-archive-first-diff-check.json','doc/validation/assets/B04U-T01-assets.json'], check=True)
subprocess.run(['git','diff','--cached','--check'], check=True)
print('Archive whitespace repaired; exact staged diff check passed.')
