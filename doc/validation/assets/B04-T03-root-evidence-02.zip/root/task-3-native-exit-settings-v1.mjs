import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.NOETOME_PLAYWRIGHT_PACKAGE);
const phase = process.argv[2];
assert(['exit', 'restore'].includes(phase));
const sdk = path.resolve('.superpowers/sdd/B04-T03_REVIEW_PLAN');
const destination = path.join(sdk, `task-3-native-exit-settings-${phase}.json`);
assert(!existsSync(destination));
const old = JSON.parse(readFileSync(path.join(sdk, 'task-3-native-actions-01.json')));
const launch = JSON.parse(readFileSync(path.join(sdk, `task-3-native-debug-0${phase === 'exit' ? 1 : 2}-launch.json`)));
const prefPath = path.join(process.env.LOCALAPPDATA, 'com.noetome.desktop', 'desktop-preferences.json');
const hash = data => createHash('sha256').update(data).digest('hex');
const prefReceipt = () => existsSync(prefPath) ? { path: prefPath, sha256: hash(readFileSync(prefPath)), value: JSON.parse(readFileSync(prefPath)) } : { path: prefPath, sha256: null, value: null };
const result = { schema_version: 1, phase, started_at: new Date().toISOString(), original_close_behavior: old.original_close_behavior, launch, preferences_before: prefReceipt(), checks: [], verifier_sha256: hash(readFileSync(new URL(import.meta.url))), physical_os_inputs: 0 };
let page;
async function check(name, fn) { try { const detail = await fn(); result.checks.push({ name, passed: true, detail }); } catch (e) { result.checks.push({ name, passed: false, error: String(e.stack || e) }); throw e; } }
async function settings() {
  await page.locator('#app-menu-file').click();
  await page.locator('#app-menu-dropdown').getByRole('menuitem', { name: '窗口设置', exact: true }).click();
  await page.locator('#close-behavior:not(:disabled)').waitFor();
}
async function choose(value) {
  if (await page.locator('#close-behavior').inputValue() !== value) {
    await page.locator('#close-behavior').selectOption(value); await page.getByRole('button', { name: '保存设置', exact: true }).click();
    await page.waitForFunction(() => document.querySelector('#window-settings-status').textContent.includes('已保存：'));
  }
  assert.equal(await page.locator('#close-behavior').inputValue(), value);
  assert.equal(prefReceipt().value.close_behavior, value);
}
try {
  assert.equal(hash(readFileSync(launch.executable)), launch.executable_sha256);
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9243');
  const pages = browser.contexts().flatMap(c => c.pages()).filter(p => p.url() === 'http://tauri.localhost/');
  assert.equal(pages.length, 1); page = pages[0];
  await settings();
  if (phase === 'exit') {
    await check('user_restored_window_and_original_preference_and_no_error', async () => {
      const observed = JSON.parse(readFileSync(path.join(sdk, 'task-3-native-manual-after-user.json')));
      assert(observed.passed && observed.windows[0].visible && !observed.windows[0].minimized && !observed.windows[0].maximized);
      assert.equal(await page.locator('#close-behavior').inputValue(), old.original_close_behavior);
      assert.deepEqual(await page.locator('[role="alert"]').allTextContents(), []);
      return { selected_window_visible: true, human_confirmation: 'task-3-native-user-confirmation.json', original_close_behavior: old.original_close_behavior };
    });
    await check('save_exit_and_fresh_settings_read_confirms_persistence', async () => {
      await choose('exit');
      await page.locator('#app-menu-file').click(); await page.locator('#app-menu-dropdown').getByRole('menuitem', { name: '工作台', exact: true }).click();
      await settings(); assert.equal(await page.locator('#close-behavior').inputValue(), 'exit');
      const receipt = prefReceipt(); result.exit_saved_preferences = receipt;
      return receipt;
    });
    await check('actual_close_button_with_exit_preference_terminates_selected_process', async () => {
      const watcher = spawn(process.env.NOETOME_TEST_PYTHON, ['-X', 'utf8', path.join(sdk, 'task-3-native-process-watch.py'), '--pid', String(launch.pid), '--exe', launch.executable, '--label', 'actual-close-exit'], { cwd: process.cwd(), stdio: ['ignore', 'pipe', 'pipe'] });
      let output = '', errors = '';
      const ready = new Promise((resolve, reject) => { watcher.stdout.on('data', data => { output += data; if (output.includes('ready\n')) resolve(); }); watcher.on('error', reject); });
      watcher.stderr.on('data', data => { errors += data; });
      const done = new Promise(resolve => watcher.on('close', resolve));
      await ready;
      try { await page.getByRole('button', { name: '关闭窗口', exact: true }).click({ timeout: 5000 }); }
      catch (e) { result.close_click_observation = String(e); }
      const exit = await done; assert.equal(exit, 0, errors || output);
      const receipt = JSON.parse(readFileSync(path.join(sdk, 'task-3-native-process-actual-close-exit.json')));
      assert(receipt.passed && receipt.exited && receipt.exit_code === 0);
      return receipt;
    });
  } else {
    const original = JSON.parse(readFileSync(path.join(sdk, 'task-3-native-exit-settings-exit.json')));
    await check('restarted_installed_app_reads_persisted_exit_preference', async () => {
      assert.equal(await page.locator('#close-behavior').inputValue(), 'exit');
      assert.equal(result.preferences_before.sha256, original.exit_saved_preferences.sha256);
      return { persisted_exit: true, preference_sha256: result.preferences_before.sha256 };
    });
    await check('restore_original_close_preference_and_verify_actual_file_and_dom', async () => {
      await choose(old.original_close_behavior); const restored = prefReceipt();
      if (original.preferences_before.sha256) assert.equal(restored.sha256, original.preferences_before.sha256);
      result.restored_preferences = restored;
      assert.deepEqual(await page.locator('[role="alert"]').allTextContents(), []);
      await page.locator('#app-menu-file').click(); await page.locator('#app-menu-dropdown').getByRole('menuitem', { name: '工作台', exact: true }).click();
      await page.screenshot({ path: path.join(sdk, 'task-3-native-exit-settings-restored-client.png') });
      return { restored, original_existing_bytes_restored: original.preferences_before.sha256 ? true : null, native_errors: [] };
    });
  }
} catch (e) { result.failure = String(e.stack || e); }
result.finished_at = new Date().toISOString(); result.preferences_after = prefReceipt();
result.passed = !result.failure && result.checks.every(c => c.passed);
writeFileSync(destination, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ evidence: destination, phase, passed: result.passed, checks: result.checks.map(c => ({ name: c.name, passed: c.passed })), failure: result.failure || null }));
process.exit(result.passed ? 0 : 1);
