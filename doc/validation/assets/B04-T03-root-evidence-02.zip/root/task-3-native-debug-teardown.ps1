$ErrorActionPreference = 'Stop'
$taskSdk = $PSScriptRoot
$taskLaunch = Get-Content -LiteralPath (Join-Path $taskSdk 'task-3-native-debug-02-launch.json') -Raw | ConvertFrom-Json
$taskProcess = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $taskLaunch.pid)
if ($null -eq $taskProcess -or [IO.Path]::GetFullPath($taskProcess.ExecutablePath) -ne [IO.Path]::GetFullPath($taskLaunch.executable)) { throw 'Owned debug process path mismatch' }
$taskExeHash = (Get-FileHash -LiteralPath $taskProcess.ExecutablePath -Algorithm SHA256).Hash.ToLowerInvariant()
if ($taskExeHash -ne $taskLaunch.executable_sha256) { throw 'Owned debug executable fingerprint mismatch' }
$taskReceiptPath = Join-Path $taskSdk 'task-3-native-debug-teardown.json'
if (Test-Path -LiteralPath $taskReceiptPath) { throw 'Teardown receipt exists' }
Stop-Process -Id $taskProcess.ProcessId -ErrorAction Stop
Wait-Process -Id $taskProcess.ProcessId -Timeout 10 -ErrorAction SilentlyContinue
$taskReceipt = [ordered]@{ schema_version=1; stopped_owned_debug_pid=$taskProcess.ProcessId; executable=$taskProcess.ExecutablePath; executable_sha256=$taskExeHash; original_close_behavior_restored='hide_to_tray'; unrelated_processes_stopped=0; reason='Native checks finished; replace the test-only debug launch with a normal installed launch'; source_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant() }
$taskReceipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $taskReceiptPath -Encoding utf8
$taskReceipt | ConvertTo-Json -Compress
