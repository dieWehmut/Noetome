"""Read-only process exit observation, bound to an exact selected executable."""
import argparse
import ctypes
from ctypes import wintypes as w
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--pid", type=int, required=True)
parser.add_argument("--exe", type=Path, required=True)
parser.add_argument("--label", required=True)
args = parser.parse_args()
assert args.label and all(c.isalnum() or c in "-_" for c in args.label)
sdk = Path(__file__).resolve().parent
destination = sdk / f"task-3-native-process-{args.label}.json"
assert not destination.exists()
kernel = ctypes.WinDLL("kernel32", use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
kernel.OpenProcess.restype = w.HANDLE
kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
kernel.QueryFullProcessImageNameW.restype = w.BOOL
kernel.WaitForSingleObject.argtypes = [w.HANDLE, w.DWORD]
kernel.WaitForSingleObject.restype = w.DWORD
kernel.GetExitCodeProcess.argtypes = [w.HANDLE, ctypes.POINTER(w.DWORD)]
kernel.GetExitCodeProcess.restype = w.BOOL
kernel.CloseHandle.argtypes = [w.HANDLE]
kernel.CloseHandle.restype = w.BOOL
handle = kernel.OpenProcess(0x100000 | 0x1000, False, args.pid)
assert handle, ctypes.get_last_error()
try:
    buffer, size = ctypes.create_unicode_buffer(32768), w.DWORD(32768)
    assert kernel.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size))
    assert Path(buffer.value).resolve() == args.exe.resolve(strict=True)
    result = {"pid": args.pid, "executable": buffer.value, "executable_sha256": hashlib.sha256(args.exe.read_bytes()).hexdigest(), "handle_bound_before_close": True, "started_at": datetime.now(timezone.utc).isoformat(), "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "process_mutations": 0}
    print("ready", flush=True)
    waited = kernel.WaitForSingleObject(handle, 10000)
    code = w.DWORD()
    assert kernel.GetExitCodeProcess(handle, ctypes.byref(code))
    result.update({"wait_result": waited, "exited": waited == 0, "exit_code": code.value, "finished_at": datetime.now(timezone.utc).isoformat()})
    result["passed"] = result["exited"] and result["exit_code"] == 0
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps(result, ensure_ascii=False), flush=True)
finally:
    assert kernel.CloseHandle(handle)
raise SystemExit(0 if result["passed"] else 1)
