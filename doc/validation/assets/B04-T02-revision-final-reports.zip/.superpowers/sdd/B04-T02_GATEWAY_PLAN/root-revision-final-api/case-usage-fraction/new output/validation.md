# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "6dde0783bd4d2e40e8937006bec22d42142b434c523ff3e6da320ae62e4d3ddb"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "abb0ae186d8a43094b4d0c57100715925e447e85c96de0b6ed418f7fef9e4805"
    },
    "request.json": {
      "byte_length": 2203,
      "sha256": "1c21db3fc49b67207245b6110ab12a536434077663d13a4a8398a9d1826525fe"
    },
    "response.bin": {
      "byte_length": 2110,
      "sha256": "edd2efafeb5939a70a9dc855a6be0bb33b5a4843e561b848cbcfa5d9646d375d"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e4b7238a-c823-4208-8004-78e50aa7a0d7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2bf1cd12-79d1-4655-b933-5d7e5bc991fa",
    "source_id": "557e9e5c-f2f6-4813-9b18-6b4805720dab",
    "version_id": "d34eda03-7ccf-49f6-86c6-a341aca5ed61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:64198/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_USAGE",
      "message": "EXTRACT_API_USAGE：文本 API 响应未通过严格契约校验。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "423ca23b-3c41-4f7b-a083-34b2c7c5c36f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2110,
    "omission_reason": null,
    "sha256": "edd2efafeb5939a70a9dc855a6be0bb33b5a4843e561b848cbcfa5d9646d375d"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
