# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "1f106339d979e86314074ec5b7b60c9431b1d2c2e3d1f5cfc6680487b1fc8021"
    },
    "request-body.json": {
      "byte_length": 5236,
      "sha256": "ee07308f21f7a40646df433990467be599af721ad573a048b06e4e3bde68b6c9"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "806312e54180cf2614e7fa57f151e5864a50122cd3fd0f9c38271d61473baec4"
    },
    "response.bin": {
      "byte_length": 2107,
      "sha256": "31bca6fa6c5d4d39d53f0b4b0d06a0e3b28c01f096b9b886f68fc8d0d8b2e2f7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e4b7238a-c823-4208-8004-78e50aa7a0d7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2bf1cd12-79d1-4655-b933-5d7e5bc991fa",
    "source_id": "557e9e5c-f2f6-4813-9b18-6b4805720dab",
    "version_id": "d34eda03-7ccf-49f6-86c6-a341aca5ed61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:64209/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_BUDGET_STOP",
      "message": "EXTRACT_BUDGET_STOP：已验证的实际模型用量超过输入预留、输出限制或总预算；不再调用。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d1aa9d78-cc74-4f40-a3ed-c71437e2de3c",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2107,
    "omission_reason": null,
    "sha256": "31bca6fa6c5d4d39d53f0b4b0d06a0e3b28c01f096b9b886f68fc8d0d8b2e2f7"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6260,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 17,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 117
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5236,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 6276
  },
  "validated_atoms": 0
}
```
