# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：429；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "7ccecfb06e118cc60d2299f2e2c3e8c44319ad5e675e100431718e744ced9c41"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "97b25e45226603c34a2bdd3d90d1c80a9dde2446d3e4bd9039e7b0cbad441905"
    },
    "request.json": {
      "byte_length": 2205,
      "sha256": "0d5381c6319b1d7edb0c295aee5bb279de0fa79abfb3986637d2c884608f831f"
    },
    "response.bin": {
      "byte_length": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e4b7238a-c823-4208-8004-78e50aa7a0d7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2bf1cd12-79d1-4655-b933-5d7e5bc991fa",
    "source_id": "557e9e5c-f2f6-4813-9b18-6b4805720dab",
    "version_id": "d34eda03-7ccf-49f6-86c6-a341aca5ed61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62723/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_RATE_LIMIT",
      "message": "EXTRACT_API_HTTP_RATE_LIMIT：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 429,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "fa21c3b1-26cc-4ee4-abec-b2c78ed7d08f",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 0,
    "omission_reason": null,
    "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
