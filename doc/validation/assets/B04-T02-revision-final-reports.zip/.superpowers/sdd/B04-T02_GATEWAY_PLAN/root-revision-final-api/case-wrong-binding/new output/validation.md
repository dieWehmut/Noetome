# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "859e6b2598f98b1bb194fd7c58de275bccb6d356b5eec73bc20099395693793e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "f904d784a65e4bda99eee495dc00a47b1170028f551cf6f5a7948e69fcec7a28"
    },
    "request.json": {
      "byte_length": 2202,
      "sha256": "dc5172ce4907b4d58898b3770374e9dc9a026c2782ce034b059c891b983663c2"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "b8e1c5709171cdf5a0b93086dc33dfdfb5d6238ab3761356d7cf5ed6298932f8"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e4b7238a-c823-4208-8004-78e50aa7a0d7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2bf1cd12-79d1-4655-b933-5d7e5bc991fa",
    "source_id": "557e9e5c-f2f6-4813-9b18-6b4805720dab",
    "version_id": "d34eda03-7ccf-49f6-86c6-a341aca5ed61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62775/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_SOURCE_BINDING",
      "message": "EXTRACT_SOURCE_BINDING：API候选请求ID或实际来源绑定不一致。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "48126b70-5576-476f-b5e9-8436d8297b6d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "b8e1c5709171cdf5a0b93086dc33dfdfb5d6238ab3761356d7cf5ed6298932f8"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
