# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：401；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "f7ad3a28d74700e2f3fe70d5d3d48d7352a89d4573aacedba88d4d53b4fc498e"
    },
    "request-body.json": {
      "byte_length": 5238,
      "sha256": "27e0af3e91e3c9fa5ea6316b6facac698fb483a8003036f077826d0f830a43c3"
    },
    "request.json": {
      "byte_length": 2197,
      "sha256": "552ebf1b6d510627b5428cb87d34d08b5cec37adc3d068fc9cd1844e0cca6473"
    },
    "response.bin": {
      "byte_length": 2108,
      "sha256": "d313d6be6d21a57302be8d5545718b3e5b50ac22256e6af49094d5bf38b6a5e7"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "e4b7238a-c823-4208-8004-78e50aa7a0d7",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "2bf1cd12-79d1-4655-b933-5d7e5bc991fa",
    "source_id": "557e9e5c-f2f6-4813-9b18-6b4805720dab",
    "version_id": "d34eda03-7ccf-49f6-86c6-a341aca5ed61"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62689/v1/responses",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_AUTH",
      "message": "EXTRACT_API_HTTP_AUTH：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_test",
  "http_status": 401,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "41bd099b-fe1b-4076-a815-f35d76b4f7cf",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2108,
    "omission_reason": null,
    "sha256": "d313d6be6d21a57302be8d5545718b3e5b50ac22256e6af49094d5bf38b6a5e7"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6262,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5238,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8310
  },
  "validated_atoms": 0
}
```
