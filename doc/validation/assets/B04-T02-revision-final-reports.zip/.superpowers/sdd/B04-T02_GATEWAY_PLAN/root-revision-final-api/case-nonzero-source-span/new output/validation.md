# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "3d3bfe36f6a77feb2998f48d12bf8bf6435ba02a936ac73d8b47157e1e5817c7"
    },
    "candidates.json": {
      "byte_length": 2755,
      "sha256": "db5f4aa7f055bce684c0bd30d9c1480978e003b79b6c3ab6baac2103701476c9"
    },
    "request-body.json": {
      "byte_length": 5144,
      "sha256": "4a7668996de002279c9065aa92d0c0df7cbbb694a72d9aecf280b1bc0c93faaf"
    },
    "request.json": {
      "byte_length": 2162,
      "sha256": "50ea3ee59698cae08066444bd0d610e74974c19adccafbc7d7d55ed6728f6265"
    },
    "response.bin": {
      "byte_length": 2110,
      "sha256": "9477616530df2915a8b2b823f0892e3171e738a5cdfdb29d2bcbed7b9a6250b6"
    }
  },
  "binding": {
    "content_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "import_id": "dab515fb-b330-4de5-ab3a-4ffb56157647",
    "manifest_sha256": null,
    "normalized_sha256": "ba817dd09ed935cd8bd550117f33f8f381ed8e24292140ee7c6b83ab467f05ee",
    "parse_id": null,
    "project_id": "4acc5b95-c1e0-401c-b90a-c98ff97b413a",
    "source_id": "51e83a90-e095-4e24-af89-03c63d45af36",
    "version_id": "279d6701-b1eb-4c02-a9fd-48f6392e04f4"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62682/v1/responses",
  "errors": [],
  "http_request_id": "req_noetome_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_responses",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "2584068f-745e-4e3b-af23-8412ea04b41d",
  "request_strategy": "openai-responses-strict-json-schema-v1",
  "response_complete": true,
  "response_id": "resp_noetome_test",
  "response_receipt": {
    "byte_length": 2110,
    "omission_reason": null,
    "sha256": "9477616530df2915a8b2b823f0892e3171e738a5cdfdb29d2bcbed7b9a6250b6"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": "default",
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 6168,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cache_write_tokens": 0,
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 5144,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 8216
  },
  "validated_atoms": 1
}
```
