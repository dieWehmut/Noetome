# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "13001d87105e146483305744a72b351ab78d24a7bf6f328695f78a281551d470"
    },
    "request-body.json": {
      "byte_length": 7509,
      "sha256": "d355085877168b7ff5feaa61ac9e1d6210b2a926851393beb7e7626dd02e7dd4"
    },
    "request.json": {
      "byte_length": 2228,
      "sha256": "b06c76a691ac1657110a3456df1c673d557f3ee8a79216b26c373303b0f63e68"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "15d80adf-643b-4ffa-bffd-94be3b3a0038",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "79beee34-c3c7-44ae-aacd-a15db3f73c64",
    "source_id": "d9bf2828-923c-494a-aa52-4320c01fd44a",
    "version_id": "5f10dadd-f983-41b1-bac1-cd49ddeb362a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:59877/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_CREDENTIAL_ECHO",
      "message": "EXTRACT_API_CREDENTIAL_ECHO：检测到所选外部凭据回显；未保存泄密原文或候选。"
    }
  ],
  "http_request_id": null,
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "a68998ea-6682-4a9d-8029-299029a31e3a",
  "request_strategy": "tangmao-deepseek-chat-positive-revision-v6",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 2018,
    "omission_reason": "omitted_credential_echo",
    "sha256": "eb3adec0bfdfc1a3af829f12492f86c9be1a70a25bd0cedec4295c9eb9bcb9a0"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8533,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7509,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10581
  },
  "validated_atoms": 0
}
```
