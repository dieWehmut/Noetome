# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型：null；HTTP状态：503；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": null,
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "8b7a844a66f462c9e4bfd0224de3b64941397367126c90c5422b2d58824f5aac"
    },
    "request-body.json": {
      "byte_length": 7509,
      "sha256": "6aae8249c326a32f3564097345a1bcb20b142bde6a552a8c97ce1801cc471f84"
    },
    "request.json": {
      "byte_length": 2221,
      "sha256": "2bccff5929154a9e45316cc3e5cd0b155398c85d88fe5d4303e87789fe437653"
    },
    "response.bin": {
      "byte_length": 1979,
      "sha256": "9814fdd9051c3cfad9d5d800d8c2eafd0cd89964e59c1d9570dd99d3bed313c2"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "15d80adf-643b-4ffa-bffd-94be3b3a0038",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "79beee34-c3c7-44ae-aacd-a15db3f73c64",
    "source_id": "d9bf2828-923c-494a-aa52-4320c01fd44a",
    "version_id": "5f10dadd-f983-41b1-bac1-cd49ddeb362a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62776/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_API_HTTP_SERVER",
      "message": "EXTRACT_API_HTTP_SERVER：文本 API 请求失败；仅保留已实际接收的有界字节。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 503,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d18046cb-de3e-452e-8ec6-349ebc9a452d",
  "request_strategy": "tangmao-deepseek-chat-positive-revision-v6",
  "response_complete": true,
  "response_id": null,
  "response_receipt": {
    "byte_length": 1979,
    "omission_reason": null,
    "sha256": "9814fdd9051c3cfad9d5d800d8c2eafd0cd89964e59c1d9570dd99d3bed313c2"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8533,
    "model_tokenizer": null,
    "model_usage": null,
    "model_usage_status": "not_validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "real_model_calls": 0,
    "request_utf8_bytes": 7509,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10581
  },
  "validated_atoms": 0
}
```
