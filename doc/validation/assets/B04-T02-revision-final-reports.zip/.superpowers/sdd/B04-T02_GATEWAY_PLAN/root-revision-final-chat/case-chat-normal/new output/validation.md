# 本地HTTP假服务 API 候选验证

状态："candidates_validated"；候选原子：1。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "b556bdcf4334fcef25ca4d61a8cc18bc90b3edfe7fe95056a5ff630501a775d7"
    },
    "candidates.json": {
      "byte_length": 2753,
      "sha256": "45922f626dde993fdba46fd9644f635896eedfba457d91e4a7b2672a99c31e40"
    },
    "request-body.json": {
      "byte_length": 7509,
      "sha256": "cb98e5bb320387ceef668b0c0e3d8c709525de16f2c217c24b58ac9ebdef45f2"
    },
    "request.json": {
      "byte_length": 2220,
      "sha256": "329b801f5f0a7d3c99c0bfe0841f789495f1968de3a8b37ee3d5962a7bb3e5cd"
    },
    "response.bin": {
      "byte_length": 1979,
      "sha256": "4dd6ca8b20d3b4c4cd767b6cbba950e3a72615a67a6d0ad5faa19e8aae206cff"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "15d80adf-643b-4ffa-bffd-94be3b3a0038",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "79beee34-c3c7-44ae-aacd-a15db3f73c64",
    "source_id": "d9bf2828-923c-494a-aa52-4320c01fd44a",
    "version_id": "5f10dadd-f983-41b1-bac1-cd49ddeb362a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62672/v1/chat/completions",
  "errors": [],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "137d54d7-8d0e-45e6-bc26-934a582f4e36",
  "request_strategy": "tangmao-deepseek-chat-positive-revision-v6",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1979,
    "omission_reason": null,
    "sha256": "4dd6ca8b20d3b4c4cd767b6cbba950e3a72615a67a6d0ad5faa19e8aae206cff"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "candidates_validated",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8533,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 7509,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10581
  },
  "validated_atoms": 1
}
```
