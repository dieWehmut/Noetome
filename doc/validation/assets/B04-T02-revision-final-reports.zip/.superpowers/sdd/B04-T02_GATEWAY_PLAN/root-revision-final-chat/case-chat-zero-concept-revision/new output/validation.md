# 本地HTTP假服务 API 候选验证

状态："failed"；候选原子：0。知识：pending；发布：false；科学质量：not_run。

配置模型："noetome-test-model"；实际返回模型："noetome-test-model"；HTTP状态：200；完整响应：true。

实际网络尝试：1。input_reserved_tokens 为实际请求UTF8字节加1024的工程预留；实际Token用量只记录已验证的原响应。价格、tokenizer及账单未知。

来源绑定、请求策略、用量、失败诊断及实际文件指纹如下，逐字段对应 validation.json。

```json
{
  "actual_model": "noetome-test-model",
  "artifacts": {
    ".owner.json": {
      "byte_length": 185,
      "sha256": "9f6a29bf0f3897a7d4ae8773b4d0ea395d7f5f14dceb84db609ac859035fa483"
    },
    "request-body.json": {
      "byte_length": 7509,
      "sha256": "713cfa9ffd8e459a7e6998475ae56f789ec56e72d245ce76d2ccc4390c2ff137"
    },
    "request.json": {
      "byte_length": 2235,
      "sha256": "d359a251a3260b0913e4d5ffc86129af27e946309c2368e8539248dea0afa88b"
    },
    "response.bin": {
      "byte_length": 1979,
      "sha256": "5af3a3b5045c88b7089bf384b7645302e5715bc052654d29f591fd57bf815330"
    }
  },
  "binding": {
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "import_id": "15d80adf-643b-4ffa-bffd-94be3b3a0038",
    "manifest_sha256": null,
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "project_id": "79beee34-c3c7-44ae-aacd-a15db3f73c64",
    "source_id": "d9bf2828-923c-494a-aa52-4320c01fd44a",
    "version_id": "5f10dadd-f983-41b1-bac1-cd49ddeb362a"
  },
  "configured_model": "noetome-test-model",
  "endpoint": "http://127.0.0.1:62681/v1/chat/completions",
  "errors": [
    {
      "code": "EXTRACT_KNOWLEDGE",
      "message": "EXTRACT_KNOWLEDGE：候选概念、原子、明文或唯一引用不符合共用严格IR规则。"
    }
  ],
  "http_request_id": "req_noetome_chat_test",
  "http_status": 200,
  "knowledge_status": "pending",
  "producer": "api",
  "provider": "openai_chat_completions",
  "published": false,
  "report_kind": "text_api_extraction",
  "request_id": "d7237720-175b-4df6-bcaf-ea1f4af66659",
  "request_strategy": "tangmao-deepseek-chat-positive-revision-v6",
  "response_complete": true,
  "response_id": "chatcmpl_noetome_test",
  "response_receipt": {
    "byte_length": 1979,
    "omission_reason": null,
    "sha256": "5af3a3b5045c88b7089bf384b7645302e5715bc052654d29f591fd57bf815330"
  },
  "schema_version": 1,
  "scientific_quality": "not_run",
  "service_tier": null,
  "source_statuses": [
    "parsed"
  ],
  "status": "failed",
  "transport_mode": "local_http_test",
  "usage": {
    "input_reserved_tokens": 8533,
    "model_tokenizer": null,
    "model_usage": {
      "input_tokens": 100,
      "input_tokens_details": {
        "cached_tokens": 0
      },
      "output_tokens": 600,
      "output_tokens_details": {
        "reasoning_tokens": 0
      },
      "total_tokens": 700
    },
    "model_usage_status": "validated",
    "network_attempts": 1,
    "paid_calls": 0,
    "price_usd": null,
    "raw_model_usage": {
      "completion_tokens": 600,
      "completion_tokens_details": {
        "reasoning_tokens": 0
      },
      "prompt_tokens": 100,
      "prompt_tokens_details": {
        "cached_tokens": 0
      },
      "total_tokens": 700
    },
    "real_model_calls": 0,
    "request_utf8_bytes": 7509,
    "reservation_policy": "request_utf8_bytes_plus_1024_v1",
    "reserved_tokens": 10581
  },
  "validated_atoms": 0
}
```
