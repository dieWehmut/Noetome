# 离线 fake 候选验证

状态：failed

请求：f139fa70-e58f-4b69-b982-a30949fae5c4
来源版本：5628ed8d-a59f-4a39-a6f6-4f81b70f216f
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2056 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_VERIFICATION: EXTRACT_VERIFICATION：候选必须保持unverified且required=false。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "f139fa70-e58f-4b69-b982-a30949fae5c4",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "560a7f02-8a29-4160-977d-58a8b95ec432",
    "source_id": "0dae0a5f-001c-4a2d-b84e-8424d12d51ed",
    "version_id": "5628ed8d-a59f-4a39-a6f6-4f81b70f216f",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2056,
    "output_bytes": 2056,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_VERIFICATION",
      "message": "EXTRACT_VERIFICATION：候选必须保持unverified且required=false。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "62b95dd653ba8b64f7d1c2cc2255ef6f223634725e8b32e1db13fd1790845ff7",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "833550e51cc61992df685363eb0c70b65a385dd24afefd225fcad87b61f444b5",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "596d77bc9854e5641998058295cb41e29602c4036742b90f4a9af476a9e5c01b",
      "byte_length": 2056
    }
  }
}
```
