# 离线 fake 候选验证

状态：failed

请求：7c1d1797-efbb-46da-aeb6-5dc76d32600e
来源版本：5628ed8d-a59f-4a39-a6f6-4f81b70f216f
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 unknown 计量单位；预留 8332 计量单位；实际 provider 调用 0 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_PRICE_UNKNOWN: EXTRACT_PRICE_UNKNOWN：价格未知，无法证明金额上限；未调用provider，未知费用没有记为0。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "7c1d1797-efbb-46da-aeb6-5dc76d32600e",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "560a7f02-8a29-4160-977d-58a8b95ec432",
    "source_id": "0dae0a5f-001c-4a2d-b84e-8424d12d51ed",
    "version_id": "5628ed8d-a59f-4a39-a6f6-4f81b70f216f",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": null,
    "output_bytes": null,
    "reserved_tokens": 8332,
    "provider_calls": 0,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_PRICE_UNKNOWN",
      "message": "EXTRACT_PRICE_UNKNOWN：价格未知，无法证明金额上限；未调用provider，未知费用没有记为0。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "49270b0afd09e29ad4f736487189f0e6e115ab5be5a74b6fc0715ac0d619dc0f",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "687cc8b41ff16d45636f122a9ee87bd0fe87f3c47aafd81a8d2f4451756b303e",
      "byte_length": 1362
    }
  }
}
```
