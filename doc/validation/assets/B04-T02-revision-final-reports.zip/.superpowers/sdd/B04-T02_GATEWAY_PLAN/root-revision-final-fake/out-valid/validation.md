# 离线 fake 候选验证

状态：candidates_validated

请求：0b85e40e-4f54-43a9-a5cc-529c85daf50f
来源版本：5628ed8d-a59f-4a39-a6f6-4f81b70f216f
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "0b85e40e-4f54-43a9-a5cc-529c85daf50f",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "560a7f02-8a29-4160-977d-58a8b95ec432",
    "source_id": "0dae0a5f-001c-4a2d-b84e-8424d12d51ed",
    "version_id": "5628ed8d-a59f-4a39-a6f6-4f81b70f216f",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "30eafc855e7b26a2e500792f5633a5aa697e6ba288c91be2269da3a35ede1d4e",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "0f4690b5192187e0a8b7e02bc3fac28de7e080032422ad28d2317853918e9a28",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "d0dc337ad9f1255d82ce858e5ddbeaea8145992b523eddb71569593ea06f5638",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "8557316ae8c5d2be405c4e8f163b580f398683f844e57c8934b449af098aa520",
      "byte_length": 2050
    }
  }
}
```
