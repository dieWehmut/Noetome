# 离线 fake 候选验证

状态：candidates_validated

请求：1a46336f-17fa-4b28-aeb8-e4aa8770cee3
来源版本：5628ed8d-a59f-4a39-a6f6-4f81b70f216f
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 2050 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "1a46336f-17fa-4b28-aeb8-e4aa8770cee3",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "560a7f02-8a29-4160-977d-58a8b95ec432",
    "source_id": "0dae0a5f-001c-4a2d-b84e-8424d12d51ed",
    "version_id": "5628ed8d-a59f-4a39-a6f6-4f81b70f216f",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": 2050,
    "output_bytes": 2050,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "94c60429e92dec78be4c6d05b56b3a2a61da7c1f2a70c3286048761fc73da859",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "e4e498f235024c3fc8f30779c0d713875da9cea14cd188ead042f837f890607d",
      "byte_length": 2178
    },
    "request.json": {
      "sha256": "be8396febf669e6a6a04a8228e475647f32320a98cfaac6f30b36e7003b2c643",
      "byte_length": 1360
    },
    "response.bin": {
      "sha256": "6e082c1e69a8c48839b653c32584826f278a0d338f78b87350325049aae0f5ca",
      "byte_length": 2050
    }
  }
}
```
