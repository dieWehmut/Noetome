# 离线 fake 候选验证

状态：failed

请求：da5fa16b-1cc6-40ad-b455-ff2848f5818b
来源版本：5628ed8d-a59f-4a39-a6f6-4f81b70f216f
来源状态：parsed
候选原子：0

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 140 字节；输出 unknown 计量单位；预留 8332 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。

- EXTRACT_RESPONSE_LIMIT: EXTRACT_RESPONSE_LIMIT：完整 fake 响应超过字节上限。

## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "da5fa16b-1cc6-40ad-b455-ff2848f5818b",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "560a7f02-8a29-4160-977d-58a8b95ec432",
    "source_id": "0dae0a5f-001c-4a2d-b84e-8424d12d51ed",
    "version_id": "5628ed8d-a59f-4a39-a6f6-4f81b70f216f",
    "content_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 0,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 140,
    "input_bytes": 140,
    "output_tokens": null,
    "output_bytes": null,
    "reserved_tokens": 8332,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [
    {
      "code": "EXTRACT_RESPONSE_LIMIT",
      "message": "EXTRACT_RESPONSE_LIMIT：完整 fake 响应超过字节上限。"
    }
  ],
  "artifacts": {
    ".owner.json": {
      "sha256": "1dc6c159cc20df10f6ae8475e8e8434a11e4ac44a4904ab8799dc076601a183e",
      "byte_length": 147
    },
    "request.json": {
      "sha256": "ffc782f42077ef69ff19c4a8afa96c788782af8c83c8034c49c0303cdffb1c8d",
      "byte_length": 1356
    }
  }
}
```
