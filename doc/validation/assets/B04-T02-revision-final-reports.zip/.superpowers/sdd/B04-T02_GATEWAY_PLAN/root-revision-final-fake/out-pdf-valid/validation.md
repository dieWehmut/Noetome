# 离线 fake 候选验证

状态：candidates_validated

请求：f32a951f-9e6e-4567-86fe-37a7ca94f119
来源版本：8afe2c9a-8f87-466e-a51d-928e6b2033ba
来源状态：parsed
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 48 字节；输出 1935 计量单位；预留 8240 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "f32a951f-9e6e-4567-86fe-37a7ca94f119",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "495d117b-eb3a-4249-bdc4-b755a4c182f5",
    "source_id": "c5327dd6-41cd-4fc1-bc8f-b59da4d5c939",
    "version_id": "8afe2c9a-8f87-466e-a51d-928e6b2033ba",
    "content_sha256": "1a8bbfe535892b74e2ec1e0fdb6f99320d98e3492441f5f8ae339a57644fc457",
    "normalized_sha256": null,
    "parse_id": "982ce468-df46-4f0b-ad25-f043f52db4c3",
    "manifest_sha256": "f3ff3555e5cde1bcf4e04289ac6d55ffefccd331a8547a605ce228e26fff7046"
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "parsed"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 48,
    "input_bytes": 48,
    "output_tokens": 1935,
    "output_bytes": 1935,
    "reserved_tokens": 8240,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "927668f34880fd273bdd89a2c75569a1206504f09de94b578f37b2bcf49cb7a2",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "95de1034b13e89e33bcfff538825c7d4045b8e5f2b79799419ecac72fe61b321",
      "byte_length": 2061
    },
    "request.json": {
      "sha256": "f1ca0bc0dd0952b7d81b06b95d17944d6ad65ab7bd1644b2a83f6ed2a3e77d4c",
      "byte_length": 1524
    },
    "response.bin": {
      "sha256": "8a33342e9829083c86c9e8969bfaa0de0e63990282cf5c460cbe1419270aa301",
      "byte_length": 1935
    }
  }
}
```
