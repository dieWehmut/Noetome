# 离线 fake 候选验证

状态：candidates_validated

请求：10668eaa-3600-4bc8-b911-193f02b105c1
来源版本：d393764d-5d3b-4b03-bb3d-379d6fdd43da
来源状态：needs_review
候选原子：1

知识状态：pending；发布：false；科学质量：not_run。

fake 计量：fake_utf8_bytes_v1；输入 56 字节；输出 1898 计量单位；预留 8248 计量单位；实际 provider 调用 1 次。价格、真实模型使用量与 tokenizer 未知；网络调用 0 次，付费调用 0 次。


## 实际验证快照

下列来源绑定、状态、计量、错误与文件指纹逐字段对应 validation.json。

```json
{
  "schema_version": 1,
  "producer": "fake",
  "request_id": "10668eaa-3600-4bc8-b911-193f02b105c1",
  "binding": {
    "project_id": "de21bc22-6f09-4653-a17f-394c04c7778a",
    "import_id": "6b31d03d-79ef-4880-96ee-a69fc6e5d313",
    "source_id": "97d2b4a7-9e39-4f94-877d-168c24b125af",
    "version_id": "d393764d-5d3b-4b03-bb3d-379d6fdd43da",
    "content_sha256": "0f930cfb984cb91754ebeb8dc245e57ed490cf7fb3d487d8cf384011cd2f3c92",
    "normalized_sha256": "036f70c8257857485962d54674813b42fe4fe1d05adbf57e0bc7ac4aa9023ec5",
    "parse_id": null,
    "manifest_sha256": null
  },
  "status": "candidates_validated",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "source_statuses": [
    "needs_review"
  ],
  "validated_atoms": 1,
  "usage": {
    "meter": "fake_utf8_bytes_v1",
    "input_tokens": 56,
    "input_bytes": 56,
    "output_tokens": 1898,
    "output_bytes": 1898,
    "reserved_tokens": 8248,
    "provider_calls": 1,
    "network_calls": 0,
    "paid_calls": 0,
    "price_usd": null,
    "model_tokenizer": null,
    "model_usage": null
  },
  "errors": [],
  "artifacts": {
    ".owner.json": {
      "sha256": "51b074cab8a46626df0e10ad0b0053a76a4578c3e25bef65617c5a484720c543",
      "byte_length": 147
    },
    "candidates.json": {
      "sha256": "ba4a680564a5f7f6370de8114421ed92add1acdc7be512212f296d43e4d7632d",
      "byte_length": 2024
    },
    "request.json": {
      "sha256": "a09159fbfa28fd49c56fb1f6410bd3061518f7afaae6b53f2fa3611a145b17ba",
      "byte_length": 1282
    },
    "response.bin": {
      "sha256": "28e0f39aa694e16f63c9c0ab12cdd6606b0e8f3850f07f962dd4f10e3092d75f",
      "byte_length": 1898
    }
  }
}
```
