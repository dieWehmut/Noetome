import hashlib
import json
from pathlib import Path
import subprocess

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]
BASE = "cccd784f607d506d0b6c8b0a12aea7973fadeb57"
HEAD = "02e8ab24d29814d427a45ac12aeb1fbffd001dd4"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)


def save(path, data):
    with path.open("xb") as stream:
        stream.write(data)


assert git("rev-parse", "HEAD").decode().strip() == HEAD
assert git("diff", "--cached", "--name-only") == b""
status = git("status", "--porcelain").decode().splitlines()
assert set(status) == {" D docs/Noetome-PRD-v1.0.html", " D docs/Noetome-PRD-v1.0.md"}
names = git("diff", "--name-only", BASE, HEAD).decode().splitlines()
sources = ["scripts/verify_extraction_knowledge.py", "tests/test_extraction_knowledge_verifier.py"]
assert len(names) == 8 and set(sources).issubset(names)
assert all(path in sources or path.startswith("doc/validation/assets/B04-T03-final-fix-1-") for path in names)
header = (
    f"Fix base: {BASE}\nHead: {HEAD}\n\nCommits:\n".encode()
    + git("log", "--oneline", f"{BASE}..{HEAD}")
    + b"\nAll eight changed files, stat:\n"
    + git("diff", "--stat", BASE, HEAD)
)
full = SDK / "final-fix-1-rereview-full.diff"
source = SDK / "final-fix-1-rereview-source.diff"
save(full, header + b"\nExact fix diff, binary evidence separately fingerprinted:\n" + git("diff", "--no-ext-diff", "-U10", BASE, HEAD))
save(source, header + b"\nExact production/test fix diff, raw six evidence assets audited separately:\n" + git("diff", "--no-ext-diff", "-U25", BASE, HEAD, "--", *sources))
files = []
for name in names:
    data = (REPO / name).read_bytes()
    assert data == git("show", f"{HEAD}:{name}")
    files.append({"path": name, "byte_length": len(data), "sha256": hashlib.sha256(data).hexdigest()})
metadata = {"base": BASE, "head": HEAD, "status": status, "files": files}
for key, path in (("full_package", full), ("source_package", source)):
    data = path.read_bytes()
    metadata[key] = {"path": path.name, "byte_length": len(data), "sha256": hashlib.sha256(data).hexdigest()}
save(SDK / "final-fix-1-rereview-package.json", (json.dumps(metadata, indent=2) + "\n").encode())
review = (SDK / "final-review.md").read_text(encoding="utf-8")
finding = review[review.index("### Important — R1"):review.index("### Minor — R2")].strip()
brief = f"""# Fresh scoped re-review of final fix wave 1

Read the unchanged implementer task brief `final-fix-1-brief.md`, the final fix report `final-fix-1-report.md`, and the supplied exact source/test fix package `final-fix-1-rereview-source.diff` once. The complete eight-file diff and immutable metadata are also saved as `final-fix-1-rereview-full.diff` / `final-fix-1-rereview-package.json`. The six new evidence assets are part of the fix scope and should be checked directly, rather than printing their large binary/manifest diff.

Fix base: `{BASE}`. Head: `{HEAD}`. Checkout D:/Noetome; branch codex/b04-t03-knowledge-verify. Root is running the final full Python regression against this fixed HEAD; root will not change HEAD or product files until that check and this review finish.

## Finding under verification, copied verbatim

{finding}

## Nonblocking deferral

R2 is outside this fix diff: successful window state recovery may leave its previous state-read alert. The final whole-branch reviewer and controller explicitly accepted deferral. No UI or native code was changed in this wave; retain that ruling without re-reviewing it.

## Read-only scope and actual evidence

Only verdict R1 ADDRESSED/NOT ADDRESSED and inspect this one-expression/two-file fix plus new evidence for breakage it introduces. No second whole-branch review, no new product task or subagents. Do not run Git commands: base/head/diff/current file fingerprints are supplied. No source/index/HEAD/task/history/standard mutation; write only your own new `final-fix-1-rereview.md`, `final-fix-1-rereview-evidence.json` and optional same-prefixed read-only audit helper in this plan's SDK. Never overwrite earlier review or implementer evidence.

Treat the implementer report as unverified claims. Parse actual retained RED/GREEN log bytes, new tests, exact original reviewer probes, new probe outcomes and the 884-member ZIP/manifest/readable copies. Verify missing/non-array remains unknown, genuine empty arrays remain zero, invalid-element arrays preserve actual length, fabricated coherent zero is rejected, and original saved final-original06 is still accepted with zero new CLI calls. Existing covering runs are 4 tests/7 real pre-fix behavior failures, focused4/4 and verifier module32/32; 43 actual CLI calls total are 13+13+17. Verify these claims from raw receipts, not report assertions alone. Do not rerun the module, suite, matrix, Rust CLI, cargo, build, installer, UI actions, network/model request, saved credential/config/budget read or unrelated private directory scan. A focused probe is allowed only if reading raises a specific doubt not answered by the retained run.

Use the official `superpowers/subagent-driven-development/re-review-prompt.md` output format: first finding verdict, new breakage with severity/file:line or None, out-of-scope observations or None, fix-round verdict. Save actual audit methods/fingerprints/counts and limitations, with no invented test execution. Return a concise report. The previously completed final whole-branch review stays historical WithFixes; this scoped review resolves its sole Important finding.
"""
save(SDK / "final-fix-1-rereview-brief.md", brief.encode())
print(json.dumps({"base": BASE, "head": HEAD, "changed_files": len(files), "source_package": metadata["source_package"], "full_package": metadata["full_package"]}))
