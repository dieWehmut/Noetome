# Fresh scoped re-review of final fix wave 1

Read the unchanged implementer task brief `final-fix-1-brief.md`, the final fix report `final-fix-1-report.md`, and the supplied exact source/test fix package `final-fix-1-rereview-source.diff` once. The complete eight-file diff and immutable metadata are also saved as `final-fix-1-rereview-full.diff` / `final-fix-1-rereview-package.json`. The six new evidence assets are part of the fix scope and should be checked directly, rather than printing their large binary/manifest diff.

Fix base: `cccd784f607d506d0b6c8b0a12aea7973fadeb57`. Head: `02e8ab24d29814d427a45ac12aeb1fbffd001dd4`. Checkout D:/Noetome; branch codex/b04-t03-knowledge-verify. Root is running the final full Python regression against this fixed HEAD; root will not change HEAD or product files until that check and this review finish.

## Finding under verification, copied verbatim

### Important — R1 / P2: Unknown raw candidate count is coerced to zero in the independent verifier

**File:** `scripts/verify_extraction_knowledge.py:510` (count calculation; assertion at line 513).

For syntactically valid JSON whose `payload.atoms` is missing or is not an array, `count = ... else (0 if syntax else None)` invents a count of zero. The Rust implementation correctly initializes `candidate_atoms`, `unexpected_atoms` and `duplicate_atoms` to null at `crates/noetome-cli/src/extraction_verify.rs:342` and only recovers the first two after finding an actual array. The source-review contract requires unknown quantities to remain unknown.

This causes both a false rejection and a false acceptance. A coherent negative report with candidate bytes `{}`, null candidate/unexpected counts and no recovered candidate results is rejected with `AssertionError: actual candidate count`. Changing only those two counts to zero, with the Markdown updated to match, makes `verify_report` accept the report and return `candidate_atoms: 0`. Thus the independent gate can approve fabricated known-zero counts and reject truthful Rust rejection reports for missing payload/atoms or a wrong array type. No false successful knowledge IR was observed; the affected gate is failure-accounting integrity, which is a stated acceptance requirement.

**Evidence/method:** One narrow in-memory artifact probe derived from the retained ordinary CLI `original06/out-candidate-extra` output in root evidence 01. The authentic baseline passed the current verifier before modification. Candidate bytes, copied candidate, both input/artifact fingerprints, count fields, recovered result list and Markdown were updated coherently; the virtual path adapter prevented filesystem writes. The truthful null-count variant failed, and the fabricated zero-count variant passed. This was not a new Rust execution. Exact candidate bytes, complete null-count file bytes, the zero-count report bytes, fingerprints and returned outcomes are embedded under `summaries.missing_array_probe` in `final-review-evidence.json`; the reproducible helper is `final-review-audit.py`.

**Fix:** Recover `len(raw_atoms)` only when `raw_atoms` is an actual list; otherwise use `None` regardless of whether JSON syntax parsed. Keep the genuine empty-array case as zero. Add focused coherent-artifact checks for missing payload, missing/non-array atoms, and real empty arrays so this distinction cannot regress. The fix should not change Rust behavior, source/gold/model inputs or the already-passed native implementation.

## Nonblocking deferral

R2 is outside this fix diff: successful window state recovery may leave its previous state-read alert. The final whole-branch reviewer and controller explicitly accepted deferral. No UI or native code was changed in this wave; retain that ruling without re-reviewing it.

## Read-only scope and actual evidence

Only verdict R1 ADDRESSED/NOT ADDRESSED and inspect this one-expression/two-file fix plus new evidence for breakage it introduces. No second whole-branch review, no new product task or subagents. Do not run Git commands: base/head/diff/current file fingerprints are supplied. No source/index/HEAD/task/history/standard mutation; write only your own new `final-fix-1-rereview.md`, `final-fix-1-rereview-evidence.json` and optional same-prefixed read-only audit helper in this plan's SDK. Never overwrite earlier review or implementer evidence.

Treat the implementer report as unverified claims. Parse actual retained RED/GREEN log bytes, new tests, exact original reviewer probes, new probe outcomes and the 884-member ZIP/manifest/readable copies. Verify missing/non-array remains unknown, genuine empty arrays remain zero, invalid-element arrays preserve actual length, fabricated coherent zero is rejected, and original saved final-original06 is still accepted with zero new CLI calls. Existing covering runs are 4 tests/7 real pre-fix behavior failures, focused4/4 and verifier module32/32; 43 actual CLI calls total are 13+13+17. Verify these claims from raw receipts, not report assertions alone. Do not rerun the module, suite, matrix, Rust CLI, cargo, build, installer, UI actions, network/model request, saved credential/config/budget read or unrelated private directory scan. A focused probe is allowed only if reading raises a specific doubt not answered by the retained run.

Use the official `superpowers/subagent-driven-development/re-review-prompt.md` output format: first finding verdict, new breakage with severity/file:line or None, out-of-scope observations or None, fix-round verdict. Save actual audit methods/fingerprints/counts and limitations, with no invented test execution. Return a concise report. The previously completed final whole-branch review stays historical WithFixes; this scoped review resolves its sole Important finding.
