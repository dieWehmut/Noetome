"""Capture actual root validation commands; never overwrite an earlier run."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SDK = Path(__file__).resolve().parent
REPO = SDK.parents[2]
BINARY = REPO / "target/debug/noetome.exe"


def fingerprint(path: Path) -> dict:
    data = path.read_bytes()
    stat = path.stat()
    return {"sha256": hashlib.sha256(data).hexdigest(), "byte_length": len(data), "mtime_ns": stat.st_mtime_ns}


def code_snapshot() -> dict:
    paths = sorted(REPO.glob("crates/**/*.rs"))
    paths.extend(REPO.glob("crates/**/Cargo.toml"))
    for pattern in ("apps/desktop/src/**/*.ts", "apps/desktop/src/**/*.tsx", "apps/desktop/src/**/*.css"):
        paths.extend(REPO.glob(pattern))
    paths.extend(REPO / name for name in (
        "Cargo.toml", "Cargo.lock", "scripts/cargo_local.ps1",
        "scripts/verify_extraction_knowledge.py",
        "tests/test_extraction_knowledge_verifier.py",
        "crates/noetome-desktop/tauri.conf.json",
        "crates/noetome-desktop/capabilities/main.json",
        "package.json", "package-lock.json", ".gitattributes",
    ))
    return {p.relative_to(REPO).as_posix(): fingerprint(p) for p in paths}


def save(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", required=True)
    parser.add_argument("--timeout", type=int, default=600)
    parser.add_argument("--temp-parent", type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    assert args.label and all(c.isalnum() or c in "-_" for c in args.label)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    assert command, "An explicit command is required"
    selected_temp = (args.temp_parent or REPO / "target/compiler-temp").resolve(strict=True)
    assert selected_temp.is_dir()
    report_path = SDK / f"root-{args.label}-command.json"
    stdout_path = SDK / f"root-{args.label}-stdout.log"
    stderr_path = SDK / f"root-{args.label}-stderr.log"
    assert all(not p.exists() for p in (report_path, stdout_path, stderr_path))
    before = code_snapshot()
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    result = {
        "schema_version": 1, "label": args.label, "command": command,
        "cwd": str(REPO), "timeout_seconds": args.timeout,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "head_before": head, "code_before": before,
        "binary_before": fingerprint(BINARY) if BINARY.exists() else None,
        "python": sys.executable,
        "effective_temp_parent": str(selected_temp),
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "stdout": stdout_path.name, "stderr": stderr_path.name,
    }
    with report_path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    environment = os.environ.copy()
    environment["NOETOME_PDF_PYTHON"] = sys.executable
    environment["NOETOME_TEST_PYTHON"] = sys.executable
    environment["TEMP"] = str(selected_temp)
    environment["TMP"] = str(selected_temp)
    start = time.monotonic()
    try:
        completed = subprocess.run(command, cwd=REPO, env=environment, capture_output=True, timeout=args.timeout, check=False)
        stdout, stderr = completed.stdout, completed.stderr
        result["exit_code"] = completed.returncode
        result["timed_out"] = False
    except subprocess.TimeoutExpired as failure:
        stdout, stderr = failure.stdout or b"", failure.stderr or b""
        result["exit_code"] = None
        result["timed_out"] = True
    for path, data in ((stdout_path, stdout), (stderr_path, stderr)):
        with path.open("xb") as stream:
            stream.write(data)
    result["elapsed_seconds"] = round(time.monotonic() - start, 3)
    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    result["head_after"] = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    result["code_after"] = code_snapshot()
    result["code_unchanged"] = result["code_after"] == before
    result["head_unchanged"] = result["head_after"] == head
    result["binary_after"] = fingerprint(BINARY) if BINARY.exists() else None
    result["log_fingerprints"] = {p.name: fingerprint(p) for p in (stdout_path, stderr_path)}
    result["passed"] = result["exit_code"] == 0 and result["code_unchanged"] and result["head_unchanged"]
    save(report_path, result)
    print(json.dumps({"label": args.label, "exit_code": result["exit_code"], "timed_out": result["timed_out"], "elapsed_seconds": result["elapsed_seconds"], "code_files": len(before), "code_unchanged": result["code_unchanged"], "head_unchanged": result["head_unchanged"], "binary_sha256": result["binary_after"]["sha256"] if result["binary_after"] else None, "report": str(report_path), "passed": result["passed"]}, ensure_ascii=False))
    return 0 if result["passed"] else result["exit_code"] or 1


if __name__ == "__main__":
    raise SystemExit(main())
