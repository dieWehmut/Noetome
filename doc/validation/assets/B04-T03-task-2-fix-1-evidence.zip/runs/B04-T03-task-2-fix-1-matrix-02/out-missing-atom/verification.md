# 有界来源知识核对

状态：unprocessed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-missing-atom",
  "status": "unprocessed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "504c4b03-2b7b-4dd8-b129-3a6220591304",
      "import_id": "be77716e-77f1-450c-b9ee-c8f1b9cf55b8",
      "source_id": "2cf7d405-b22c-4d1e-9924-06c4d646487c",
      "version_id": "c4c498c3-445a-44a0-a038-820d1e156940",
      "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "688c34b3-cf69-4668-be77-9054aa145312",
          "ordinal": 0,
          "resource_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 195,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。\n这是独立作者的工程例外测试，不是科学质量基准。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "504c4b03-2b7b-4dd8-b129-3a6220591304",
    "import_id": "be77716e-77f1-450c-b9ee-c8f1b9cf55b8",
    "source_id": "2cf7d405-b22c-4d1e-9924-06c4d646487c",
    "version_id": "c4c498c3-445a-44a0-a038-820d1e156940",
    "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "2481578f16c92eb67b7c6a026ac97dadc298d5d53d722ba12a78a83748e5e45e",
        "byte_length": 1844
      },
      "decision.json": {
        "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
        "byte_length": 144
      },
      "gold.json": {
        "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
        "byte_length": 704
      },
      "review.json": {
        "sha256": "acae59cea8be9488a4587417060cd694866663d0acf150ea6d708f8e4e09efd2",
        "byte_length": 547
      }
    },
    "gold_sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "unprocessed",
      "issue_codes": [
        "VERIFY_MISSING"
      ]
    }
  ],
  "candidate_results": [],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_MISSING",
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "import_id": "be77716e-77f1-450c-b9ee-c8f1b9cf55b8",
          "manifest_sha256": null,
          "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "parse_id": null,
          "project_id": "504c4b03-2b7b-4dd8-b129-3a6220591304",
          "source_id": "2cf7d405-b22c-4d1e-9924-06c4d646487c",
          "version_id": "c4c498c3-445a-44a0-a038-820d1e156940"
        },
        "request_id": "synthetic-missing-atom"
      },
      "actual": {
        "binding": {
          "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "import_id": "be77716e-77f1-450c-b9ee-c8f1b9cf55b8",
          "manifest_sha256": null,
          "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "parse_id": null,
          "project_id": "504c4b03-2b7b-4dd8-b129-3a6220591304",
          "source_id": "2cf7d405-b22c-4d1e-9924-06c4d646487c",
          "version_id": "c4c498c3-445a-44a0-a038-820d1e156940"
        },
        "request_id": "synthetic-missing-atom"
      }
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 1,
    "candidate_atoms": 0,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "condition": {
      "expected": 2,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 2,
      "status": "unprocessed"
    },
    "content": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "coverage": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "evidence": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "exception": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 1,
      "status": "unprocessed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "3df78d036afb0e11b444fe9ce79936ea69a7fa4c4dfa92ca2d994342643efdae",
      "byte_length": 140
    },
    "candidates-original.json": {
      "sha256": "2481578f16c92eb67b7c6a026ac97dadc298d5d53d722ba12a78a83748e5e45e",
      "byte_length": 1844
    },
    "decision-original.json": {
      "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
      "byte_length": 144
    },
    "gold-original.json": {
      "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
      "byte_length": 704
    },
    "review-original.json": {
      "sha256": "acae59cea8be9488a4587417060cd694866663d0acf150ea6d708f8e4e09efd2",
      "byte_length": 547
    },
    "source-snapshot.json": {
      "sha256": "7d3c563d0961aef834865009d26142677c7588dc9cf47fa8a2a459966910c164",
      "byte_length": 1085
    }
  }
}
```
