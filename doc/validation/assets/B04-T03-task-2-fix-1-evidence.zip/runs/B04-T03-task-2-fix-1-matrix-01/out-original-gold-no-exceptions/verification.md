# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-original-gold-no-exceptions",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
      "import_id": "92e209ce-1c0f-4b3f-9d23-3a2f7d6174b8",
      "source_id": "39336733-e396-404b-9fcd-00c3b9e816fe",
      "version_id": "8a46b58f-1977-45e5-83ce-7e24afc367f9",
      "content_sha256": "8d1352f35954958e9f0a508b61ee01d5683a9c4a9d36e2f8983e960198fca317",
      "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "af6fc545-f3eb-4956-b6a7-cd63ec27a3f1",
          "ordinal": 0,
          "resource_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 140,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A。此句是作者编写的工程测试数据。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
    "import_id": "92e209ce-1c0f-4b3f-9d23-3a2f7d6174b8",
    "source_id": "39336733-e396-404b-9fcd-00c3b9e816fe",
    "version_id": "8a46b58f-1977-45e5-83ce-7e24afc367f9",
    "content_sha256": "8d1352f35954958e9f0a508b61ee01d5683a9c4a9d36e2f8983e960198fca317",
    "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "ff495a70db44a8b72de0dd89f13cf38c78ec6a67b07c8a3b3b06f651f2259f1a",
        "byte_length": 2756
      },
      "decision.json": {
        "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
        "byte_length": 144
      },
      "gold.json": {
        "sha256": "7e6decaf0a137f089be668d251ace83fb7ea0f65019f5544cca26d6b1f4c489d",
        "byte_length": 566
      },
      "review.json": {
        "sha256": "c3895effcee0ad74583b1295d529b42494726acc5cea410d1ee35f82cc3759eb",
        "byte_length": 547
      }
    },
    "gold_sha256": "7e6decaf0a137f089be668d251ace83fb7ea0f65019f5544cca26d6b1f4c489d"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "atom-speed"
        ],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "8d1352f35954958e9f0a508b61ee01d5683a9c4a9d36e2f8983e960198fca317",
          "import_id": "92e209ce-1c0f-4b3f-9d23-3a2f7d6174b8",
          "manifest_sha256": null,
          "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
          "parse_id": null,
          "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
          "source_id": "39336733-e396-404b-9fcd-00c3b9e816fe",
          "version_id": "8a46b58f-1977-45e5-83ce-7e24afc367f9"
        },
        "request_id": "synthetic-original-gold-no-exceptions"
      },
      "actual": {
        "binding": {
          "content_sha256": "8d1352f35954958e9f0a508b61ee01d5683a9c4a9d36e2f8983e960198fca317",
          "import_id": "92e209ce-1c0f-4b3f-9d23-3a2f7d6174b8",
          "manifest_sha256": null,
          "normalized_sha256": "35b0a7f6589dacf32a149a947986dff17369ee165607fdf6a301c398519f860a",
          "parse_id": null,
          "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
          "source_id": "39336733-e396-404b-9fcd-00c3b9e816fe",
          "version_id": "8a46b58f-1977-45e5-83ce-7e24afc367f9"
        },
        "request_id": "synthetic-original-gold-no-exceptions"
      }
    },
    {
      "category": "duplicate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A。"
    },
    {
      "category": "evidence_identity",
      "object_id": "evidence-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 94,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 140,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "evidence-speed",
        "excerpt_end_byte": 94,
        "excerpt_sha256": "1f3a11c848a615d62df0535a344b02cc4688c1d7640dee13dd89b0928949362e",
        "excerpt_start_byte": 0,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 94,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "evidence-speed",
          "excerpt_end_byte": 94,
          "excerpt_sha256": "1f3a11c848a615d62df0535a344b02cc4688c1d7640dee13dd89b0928949362e",
          "excerpt_start_byte": 0,
          "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A 速度",
            "concept_id": "concept-speed",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A。"
    },
    {
      "category": "fact",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [
          "在本夹具的样例 A 中"
        ],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 140,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [
          "在本夹具的样例 A 中"
        ],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用样例 A"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "f1686d6533ead5379846cebfc9512d77b7ba2b13fea764d96a6ab6cc320df04d",
      "byte_length": 155
    },
    "candidates-original.json": {
      "sha256": "ff495a70db44a8b72de0dd89f13cf38c78ec6a67b07c8a3b3b06f651f2259f1a",
      "byte_length": 2756
    },
    "decision-original.json": {
      "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
      "byte_length": 144
    },
    "gold-original.json": {
      "sha256": "7e6decaf0a137f089be668d251ace83fb7ea0f65019f5544cca26d6b1f4c489d",
      "byte_length": 566
    },
    "knowledge-ir.json": {
      "sha256": "922cb491fa32e52da9fa317404854c0292988def368c85c14d35e278fb543add",
      "byte_length": 11023
    },
    "review-original.json": {
      "sha256": "c3895effcee0ad74583b1295d529b42494726acc5cea410d1ee35f82cc3759eb",
      "byte_length": 547
    },
    "source-snapshot.json": {
      "sha256": "85efaba9a028123058dfc70d2c43857d8aa50898a12ce3fd097e499c9d81eb39",
      "byte_length": 1029
    }
  }
}
```
