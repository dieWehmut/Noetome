# 有界来源知识核对

状态：failed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-pdf-wrong-parse",
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "pdf",
        "page_index": 0,
        "region_id": "region-000000-000000"
      }
    ],
    "binding": {
      "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
      "import_id": "f453fde0-6dcf-4760-ab50-61d02995313b",
      "source_id": "25ccfc4d-28d9-49f4-a199-a349be136140",
      "version_id": "e972b402-3a82-4b53-9269-2f54729bd1ce",
      "content_sha256": "39da594adb8486be9022c64f0c43f208860a985f0d6c97dda2e25de54d9f32a4",
      "normalized_sha256": null,
      "parse_id": "0a1c90a1-6408-4c20-a212-a75b1e4c7a4f",
      "manifest_sha256": "4442cdbcacbbcc482aa08bd9c003f69613952b1cf6adb39fea928c0f2d3ecc98"
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "pdf",
          "parse_id": "0a1c90a1-6408-4c20-a212-a75b1e4c7a4f",
          "page_index": 0,
          "region_id": "region-000000-000000",
          "resource_id": "page-text-000000",
          "resource_sha256": "0252f501be623f9d6dbfcc8e465100d2c4141ee8d36c87009f2c59cedc23bc09",
          "bbox": [
            40.0,
            49.79400000000001,
            240.15799999999996,
            63.79400000000001
          ]
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 37,
        "text": "A的速度为10m/s。条件是T20C。"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
    "import_id": "f453fde0-6dcf-4760-ab50-61d02995313b",
    "source_id": "25ccfc4d-28d9-49f4-a199-a349be136140",
    "version_id": "e972b402-3a82-4b53-9269-2f54729bd1ce",
    "content_sha256": "39da594adb8486be9022c64f0c43f208860a985f0d6c97dda2e25de54d9f32a4",
    "normalized_sha256": null,
    "parse_id": "0a1c90a1-6408-4c20-a212-a75b1e4c7a4f",
    "manifest_sha256": "4442cdbcacbbcc482aa08bd9c003f69613952b1cf6adb39fea928c0f2d3ecc98"
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "63e0c8ff103cb43366670410f4f654e79d8346f2fe2cf51761332024ba04e353",
        "byte_length": 2587
      },
      "decision.json": {
        "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
        "byte_length": 144
      },
      "gold.json": {
        "sha256": "8908642874b35a05d78545fc3975d3a545d256cb0855e2897a0a610a4c5de470",
        "byte_length": 495
      },
      "review.json": {
        "sha256": "24054d267022bf1fe3f1469f5c286c67e523dd85af7245e1eec7993744f6c97a",
        "byte_length": 548
      }
    },
    "gold_sha256": "8908642874b35a05d78545fc3975d3a545d256cb0855e2897a0a610a4c5de470"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "failed",
      "issue_codes": [
        "VERIFY_BINDING"
      ]
    }
  ],
  "candidate_results": [
    {
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "failed",
      "issue_codes": [
        "VERIFY_BINDING"
      ]
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "atom-speed"
        ],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "strict_candidate",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "failed",
      "code": "VERIFY_BINDING",
      "expected": "strict_candidates",
      "actual": "VERIFY_BINDING"
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "failed",
      "code": "VERIFY_BINDING",
      "expected": {
        "binding": {
          "content_sha256": "39da594adb8486be9022c64f0c43f208860a985f0d6c97dda2e25de54d9f32a4",
          "import_id": "f453fde0-6dcf-4760-ab50-61d02995313b",
          "manifest_sha256": "4442cdbcacbbcc482aa08bd9c003f69613952b1cf6adb39fea928c0f2d3ecc98",
          "normalized_sha256": null,
          "parse_id": "0a1c90a1-6408-4c20-a212-a75b1e4c7a4f",
          "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
          "source_id": "25ccfc4d-28d9-49f4-a199-a349be136140",
          "version_id": "e972b402-3a82-4b53-9269-2f54729bd1ce"
        },
        "request_id": "synthetic-pdf-wrong-parse"
      },
      "actual": {
        "binding": {
          "content_sha256": "39da594adb8486be9022c64f0c43f208860a985f0d6c97dda2e25de54d9f32a4",
          "import_id": "f453fde0-6dcf-4760-ab50-61d02995313b",
          "manifest_sha256": "4442cdbcacbbcc482aa08bd9c003f69613952b1cf6adb39fea928c0f2d3ecc98",
          "normalized_sha256": null,
          "parse_id": "wrong-parse",
          "project_id": "53fbe52f-34c7-4082-b2ff-2056087479c7",
          "source_id": "25ccfc4d-28d9-49f4-a199-a349be136140",
          "version_id": "e972b402-3a82-4b53-9269-2f54729bd1ce"
        },
        "request_id": "synthetic-pdf-wrong-parse"
      }
    },
    {
      "category": "strict_candidate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "failed",
      "code": "VERIFY_BINDING",
      "expected": "strict_candidates",
      "actual": "VERIFY_BINDING"
    },
    {
      "category": "duplicate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "A的速度为10m/s，条件为T20C。"
    },
    {
      "category": "evidence_identity",
      "object_id": "evidence-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 37,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "evidence-speed",
        "excerpt_end_byte": 37,
        "excerpt_sha256": "f4997583b1e440f3c355d3ddb18bf956bfcbe4041161b870c1b760b5ec29796f",
        "excerpt_start_byte": 0,
        "quote": "A的速度为10m/s。条件是T20C。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 37,
        "quote": "A的速度为10m/s。条件是T20C。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "evidence-speed",
          "excerpt_end_byte": 37,
          "excerpt_sha256": "f4997583b1e440f3c355d3ddb18bf956bfcbe4041161b870c1b760b5ec29796f",
          "excerpt_start_byte": 0,
          "quote": "A的速度为10m/s。条件是T20C。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "A",
          "速度"
        ],
        "compound": "A速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "A速度",
            "concept_id": "concept-speed",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "A的速度为10m/s，条件为T20C。",
      "actual": "A的速度为10m/s，条件为T20C。"
    },
    {
      "category": "fact",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "T20C"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "T20C"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": "T20C",
      "actual": {
        "body": [
          "T20C"
        ],
        "measurement": [
          "T20C"
        ],
        "qualifiers": [
          "m/s",
          "T20C"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "T20C"
        ]
      },
      "actual": {
        "body": [
          "T20C"
        ],
        "measurement": [
          "T20C"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 37,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "T20C"
        ],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "T20C"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 1,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "22c6fbae86e477f64e8fb22245602f4bf10d31ca39b8662126fa26f1e30923a7",
      "byte_length": 143
    },
    "candidates-original.json": {
      "sha256": "63e0c8ff103cb43366670410f4f654e79d8346f2fe2cf51761332024ba04e353",
      "byte_length": 2587
    },
    "decision-original.json": {
      "sha256": "99f859ba870f3e066416ce07a20af8507fcbc1e5e2acd7af8540887ed99e44e3",
      "byte_length": 144
    },
    "gold-original.json": {
      "sha256": "8908642874b35a05d78545fc3975d3a545d256cb0855e2897a0a610a4c5de470",
      "byte_length": 495
    },
    "review-original.json": {
      "sha256": "24054d267022bf1fe3f1469f5c286c67e523dd85af7245e1eec7993744f6c97a",
      "byte_length": 548
    },
    "source-snapshot.json": {
      "sha256": "85484fe3fb327e79c9bbd26be9a0d7647b00f74e41ae2bfef577725f65aed561",
      "byte_length": 1181
    }
  }
}
```
