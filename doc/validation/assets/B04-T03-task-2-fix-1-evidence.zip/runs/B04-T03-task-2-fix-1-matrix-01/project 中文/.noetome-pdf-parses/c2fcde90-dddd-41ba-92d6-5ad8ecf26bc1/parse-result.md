# PDF 单文件解析沙盒

| 字段 | 值 |
| --- | --- |
| schema_version | 1 |
| report_kind | pdf_parse_sandbox |
| status | needs_review |
| input_sha256 | 758c09cd50c8191618fd9c19aca94c0acff608b9292193111b63704bd206455c |
| input_byte_length | 1945 |
| parser | pdfplumber 0.11.9 / pdfminer.six 20251230 / noetome-pdf-text-v1 / crop-pt-lines-v1 / Python 3.12.14 |
| page_count | 1 |
| parsed_page_count | 0 |
| needs_review_page_count | 1 |
| failed_page_count | 0 |
| manifest_path | parser/pdf-manifest.json |
| manifest_sha256 | 79a40ccc70fd406168ad0f04d0ce29461b7bcb2959b396f6e97e649b66007463 |
| elapsed_ms | 176 |
| resource_bytes | 3946 |

物理索引从0开始；显示物理页为索引+1；印刷页码未确认。知识抽取、OCR与科学验证未运行。

| 物理索引 | 显示物理页 | 状态 |
| --- | --- | --- |
| 0 | 1 | needs_review |

| 问题 | 来源单元 | 原因 |
| --- | --- | --- |
| PDF_VISUAL_CONTENT | page-000000 | Raw image/vector/annotation evidence is retained; structure/association requires review. |
| PDF_NO_TEXT_LAYER | page-000000 | Raster page has no decoded text; review required; OCR unavailable. |
