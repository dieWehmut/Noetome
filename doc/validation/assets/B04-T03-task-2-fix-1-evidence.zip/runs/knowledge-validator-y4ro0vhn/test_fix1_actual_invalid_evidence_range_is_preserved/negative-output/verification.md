# 有界来源知识核对

状态：failed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-review-1",
  "status": "failed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "c996c1b1-e0de-4ca9-87fa-39d63494c6c3",
      "import_id": "82535eed-0cb3-401f-b72d-313f2e36341d",
      "source_id": "96099176-c6f9-4162-a494-29e4f5706fc1",
      "version_id": "810378bd-720b-4ead-8a8a-be2412044f6f",
      "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "2dbeb4b3-3753-488c-b818-3cf68f526057",
          "ordinal": 0,
          "resource_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 195,
        "text": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。\n这是独立作者的工程例外测试，不是科学质量基准。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "c996c1b1-e0de-4ca9-87fa-39d63494c6c3",
    "import_id": "82535eed-0cb3-401f-b72d-313f2e36341d",
    "source_id": "96099176-c6f9-4162-a494-29e4f5706fc1",
    "version_id": "810378bd-720b-4ead-8a8a-be2412044f6f",
    "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "f3bdf8120c9e00fe6020d9e0c3f49a541e69d94e439d1f2e03fdaefd63cf861c",
        "byte_length": 2813
      },
      "decision.json": {
        "sha256": "44d918d8c2817f4963d8c012dac1d7d2363a7de2cd467494b279395758376020",
        "byte_length": 115
      },
      "gold.json": {
        "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
        "byte_length": 704
      },
      "review.json": {
        "sha256": "22b01f767ee7da4a2b3426faba2eb6e1db59edaaef61ff923596c9165581c5ce",
        "byte_length": 486
      }
    },
    "gold_sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [
      "在本夹具的样例 A 中"
    ],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "issue_codes": [
        "EXTRACT_EVIDENCE_RANGE",
        "VERIFY_EVIDENCE"
      ]
    }
  ],
  "candidate_results": [
    {
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "issue_codes": [
        "EXTRACT_EVIDENCE_RANGE",
        "VERIFY_EVIDENCE"
      ]
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "atom-speed"
        ],
        "decision": {
          "atom_ids": [
            "atom-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "strict_candidate",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "EXTRACT_EVIDENCE_RANGE",
      "expected": "strict_candidates",
      "actual": "EXTRACT_EVIDENCE_RANGE"
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "import_id": "82535eed-0cb3-401f-b72d-313f2e36341d",
          "manifest_sha256": null,
          "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "parse_id": null,
          "project_id": "c996c1b1-e0de-4ca9-87fa-39d63494c6c3",
          "source_id": "96099176-c6f9-4162-a494-29e4f5706fc1",
          "version_id": "810378bd-720b-4ead-8a8a-be2412044f6f"
        },
        "request_id": "synthetic-review-1"
      },
      "actual": {
        "binding": {
          "content_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "import_id": "82535eed-0cb3-401f-b72d-313f2e36341d",
          "manifest_sha256": null,
          "normalized_sha256": "98590b07afe45507cd90ff63631a65996e005b57f19dd2a4670c205e2c117816",
          "parse_id": null,
          "project_id": "c996c1b1-e0de-4ca9-87fa-39d63494c6c3",
          "source_id": "96099176-c6f9-4162-a494-29e4f5706fc1",
          "version_id": "810378bd-720b-4ead-8a8a-be2412044f6f"
        },
        "request_id": "synthetic-review-1"
      }
    },
    {
      "category": "strict_candidate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "EXTRACT_EVIDENCE_RANGE",
      "expected": "strict_candidates",
      "actual": "EXTRACT_EVIDENCE_RANGE"
    },
    {
      "category": "duplicate",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "evidence-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 196,
      "status": "failed",
      "code": "VERIFY_EVIDENCE",
      "expected": {
        "end_byte": 195,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "evidence-speed",
        "excerpt_end_byte": 196,
        "excerpt_sha256": "8787abb6f05367771604433544ea4a73b7537e8182a3c9ea0e0420cf90c461f8",
        "excerpt_start_byte": 0,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "failed",
      "code": "VERIFY_EVIDENCE",
      "expected": {
        "end_byte": 124,
        "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "evidence-speed",
          "excerpt_end_byte": 196,
          "excerpt_sha256": "8787abb6f05367771604433544ea4a73b7537e8182a3c9ea0e0420cf90c461f8",
          "excerpt_start_byte": 0,
          "quote": "在本夹具的样例 A 中，速度为 10 m/s。条件是温度 20 ℃、仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A 速度",
            "concept_id": "concept-speed",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [
          "在本夹具的样例 A 中"
        ],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "atom-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 195,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [
          "在本夹具的样例 A 中"
        ],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 0,
    "failed": 1,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 0,
      "failed": 1,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "failed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "58ebe77ac2d8a176e62a33f52cc567011a1765f86b6d2cbcc66c9bf4f3958e26",
      "byte_length": 136
    },
    "candidates-original.json": {
      "sha256": "f3bdf8120c9e00fe6020d9e0c3f49a541e69d94e439d1f2e03fdaefd63cf861c",
      "byte_length": 2813
    },
    "decision-original.json": {
      "sha256": "44d918d8c2817f4963d8c012dac1d7d2363a7de2cd467494b279395758376020",
      "byte_length": 115
    },
    "gold-original.json": {
      "sha256": "51855d0161e2e8608206138d18c881380630201f155f990c0e149a80444a3b00",
      "byte_length": 704
    },
    "review-original.json": {
      "sha256": "22b01f767ee7da4a2b3426faba2eb6e1db59edaaef61ff923596c9165581c5ce",
      "byte_length": 486
    },
    "source-snapshot.json": {
      "sha256": "e676ad877359234f6fb77bfcebb4e04e56de722ecaf094d890236bfba9f12476",
      "byte_length": 1085
    }
  }
}
```
