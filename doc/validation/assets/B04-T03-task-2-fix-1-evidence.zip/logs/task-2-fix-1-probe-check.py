"""Re-evaluate preserved review probes without changing their actual bytes."""
import importlib.util
import json
from pathlib import Path

repo = Path("D:/Noetome")
sdk = repo / ".superpowers/sdd/B04-T03_REVIEW_PLAN"
spec = importlib.util.spec_from_file_location("fixed_verifier", repo / "scripts/verify_extraction_knowledge.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
matrix = repo / "target/compiler-temp/B04-T03-task-2-matrix-07"
result = []
for mode in ("strict-boolean", "diagnostic-identity"):
    output = sdk / ("task-2-review-probe-" + mode)
    before = {p.name: v.fingerprint(p.read_bytes()) for p in output.iterdir() if p.is_file()}
    inputs = {name: (output / copied).read_bytes() for name, copied in (("review.json", "review-original.json"), ("gold.json", "gold-original.json"), ("candidates.json", "candidates-original.json"), ("decision.json", "decision-original.json"))}
    review = v.strict_json(inputs["review.json"])
    candidate = v.strict_json(inputs["candidates.json"])
    source = v.actual_source(matrix / "project 中文", candidate["binding"]["import_id"], review["selection"][0])
    try:
        v.verify_report(output, inputs["candidates.json"], inputs["gold.json"], source, inputs)
    except AssertionError as error:
        result.append({"mode": mode, "rejected": True, "error": str(error), "fingerprints": before})
    else:
        raise AssertionError("coherent probe accepted: " + mode)
    assert {p.name: v.fingerprint(p.read_bytes()) for p in output.iterdir() if p.is_file()} == before
v.save(sdk / "task-2-fix-1-probe-check.json", {"production_cli_calls": 0, "network_calls": 0, "results": result})
print(json.dumps([{k: x for k, x in r.items() if k != "fingerprints"} for r in result]))
