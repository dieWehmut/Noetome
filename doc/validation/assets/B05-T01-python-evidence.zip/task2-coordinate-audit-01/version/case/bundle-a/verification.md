# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "2652f09d-47e5-4b41-aa77-7bda188408fa",
      "import_id": "d872d025-e14b-49f6-a74c-7c581aab32fa",
      "source_id": "f783612a-8bb6-49fe-aeee-84d341cd4ef4",
      "version_id": "c1540620-53fa-4e62-b664-14c603830443",
      "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
      "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "36455694-7b2d-46e9-bdbd-843dee17a0b1",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "2652f09d-47e5-4b41-aa77-7bda188408fa",
    "import_id": "d872d025-e14b-49f6-a74c-7c581aab32fa",
    "source_id": "f783612a-8bb6-49fe-aeee-84d341cd4ef4",
    "version_id": "c1540620-53fa-4e62-b664-14c603830443",
    "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
    "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "575ece71b6df6cb45a1963f9a18e2532e2275ee94ed33eebb18b0614c35322be",
        "byte_length": 2979
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
        "byte_length": 727
      },
      "review.json": {
        "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
        "byte_length": 510
      }
    },
    "gold_sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "import_id": "d872d025-e14b-49f6-a74c-7c581aab32fa",
          "manifest_sha256": null,
          "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "parse_id": null,
          "project_id": "2652f09d-47e5-4b41-aa77-7bda188408fa",
          "source_id": "f783612a-8bb6-49fe-aeee-84d341cd4ef4",
          "version_id": "c1540620-53fa-4e62-b664-14c603830443"
        },
        "request_id": "synthetic-coordination-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "import_id": "d872d025-e14b-49f6-a74c-7c581aab32fa",
          "manifest_sha256": null,
          "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
          "parse_id": null,
          "project_id": "2652f09d-47e5-4b41-aa77-7bda188408fa",
          "source_id": "f783612a-8bb6-49fe-aeee-84d341cd4ef4",
          "version_id": "c1540620-53fa-4e62-b664-14c603830443"
        },
        "request_id": "synthetic-coordination-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 106,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 107,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 106,
        "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
        "excerpt_start_byte": 0,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 106,
        "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
        "start_byte": 0
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "excerpt_start_byte": 0,
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "仅适用样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 107,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "575ece71b6df6cb45a1963f9a18e2532e2275ee94ed33eebb18b0614c35322be",
      "byte_length": 2979
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
      "byte_length": 727
    },
    "knowledge-ir.json": {
      "sha256": "0a3ba6f2cf69cd93b9a75f6fc6655bf2bef66b31f289fd2695553658c579087e",
      "byte_length": 12081
    },
    "review-original.json": {
      "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "cf8fec95b1f2515cf60704cbd1427b07018ea771d92c3afb07fcf4593b75faa8",
      "byte_length": 996
    }
  }
}
```
