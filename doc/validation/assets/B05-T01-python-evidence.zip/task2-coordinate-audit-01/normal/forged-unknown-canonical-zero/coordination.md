# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

显式身份重复／互补范围；完整来源、原对象、证据与分母见以下事实，与 coordination.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "10f0fc2e-d04f-45b9-b636-13b49d842fb6",
  "scope": "explicit_identity_duplicate_complement_v1",
  "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "display_name": "速度"
    },
    {
      "canonical_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "display_name": "质量"
    },
    {
      "canonical_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "display_name": "样例 A"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
        "import_id": "6b29d105-7b9f-48af-9c69-c85c7eaa2231",
        "source_id": "57d5b9b2-d9f3-43dc-879e-b495eeec3f55",
        "version_id": "a2af3db9-da37-4488-9b1b-9e9c599e80b0",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "6b29d105-7b9f-48af-9c69-c85c7eaa2231",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
              "source_id": "57d5b9b2-d9f3-43dc-879e-b495eeec3f55",
              "version_id": "a2af3db9-da37-4488-9b1b-9e9c599e80b0"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "6b29d105-7b9f-48af-9c69-c85c7eaa2231",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
              "source_id": "57d5b9b2-d9f3-43dc-879e-b495eeec3f55",
              "version_id": "a2af3db9-da37-4488-9b1b-9e9c599e80b0"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "0a81b6f291a65769b9ae3375e071aae515337e050be5db2d486458b33abaaa25",
          "byte_length": 2979
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
          "byte_length": 727
        },
        "knowledge-ir.json": {
          "sha256": "e257276799e223c554d9cc3febdfb38470414cebf33e6c7a85cb4f63cada307e",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "5c27c7f7c653c77f89b341b9ea42f649518406a1dff8828f65a7f4ac18b1b3b1",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "7044d9ac6050fe6ac070f6267c6db500c1463a7afb156f0ff76958df2f7a7e1c",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "802806b0f5c4b91ee19503e31710458f04ff7a7add868d6157ceece2914e7d74",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
        "import_id": "53580652-4186-43b0-87ac-7c0bb6ea5d8b",
        "source_id": "e2f3eb1f-3711-4a9d-9631-4b792370e4f6",
        "version_id": "364fb9b6-a257-455a-a182-7c80fe57ad02",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "53580652-4186-43b0-87ac-7c0bb6ea5d8b",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
              "source_id": "e2f3eb1f-3711-4a9d-9631-4b792370e4f6",
              "version_id": "364fb9b6-a257-455a-a182-7c80fe57ad02"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "import_id": "53580652-4186-43b0-87ac-7c0bb6ea5d8b",
              "manifest_sha256": null,
              "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
              "parse_id": null,
              "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
              "source_id": "e2f3eb1f-3711-4a9d-9631-4b792370e4f6",
              "version_id": "364fb9b6-a257-455a-a182-7c80fe57ad02"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 106,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 107,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 106,
            "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 106,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 106,
              "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 107,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "33f630ec78144c68d32372ef7dda64cfc31577ec0fe4bde054c1bf01c77c7dc3",
          "byte_length": 2979
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
          "byte_length": 727
        },
        "knowledge-ir.json": {
          "sha256": "9f4dc0f044fc26ccc87a93e05c50bf8f4d207ceb0fb4f51f83ab9bba571dd415",
          "byte_length": 12081
        },
        "review-original.json": {
          "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "1adb883f7ee1e520009448730f059744699a8cb58431f2dd400b6b26b184edfd",
          "byte_length": 996
        },
        "verification.json": {
          "sha256": "199c446537ef1f799f2081b40ba4d6911d5ad708b7c40042001852ce75f18dcd",
          "byte_length": 16573
        },
        "verification.md": {
          "sha256": "bcd380602b45826472ca5123762f21dd86062e585392d2bd7d04d832d38c78e9",
          "byte_length": 17007
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
        "import_id": "c1ff603c-317e-4b5d-a5b7-8bec94a156e7",
        "source_id": "b6602b39-76a4-4621-b2ab-d37c45e05754",
        "version_id": "b1d336e6-d48e-4d19-8ad3-553e58b9b9bc",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "c1ff603c-317e-4b5d-a5b7-8bec94a156e7",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
              "source_id": "b6602b39-76a4-4621-b2ab-d37c45e05754",
              "version_id": "b1d336e6-d48e-4d19-8ad3-553e58b9b9bc"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "import_id": "c1ff603c-317e-4b5d-a5b7-8bec94a156e7",
              "manifest_sha256": null,
              "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
              "parse_id": null,
              "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
              "source_id": "b6602b39-76a4-4621-b2ab-d37c45e05754",
              "version_id": "b1d336e6-d48e-4d19-8ad3-553e58b9b9bc"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 104,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 105,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 104,
            "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
            "excerpt_start_byte": 0,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 104,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
            "start_byte": 0
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 104,
              "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
              "excerpt_start_byte": 0,
              "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "仅适用样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 105,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "3c2810c7e50567607a37dd96025b1b7a2a32ad9c2d174860e2396b8c480b117e",
          "byte_length": 2971
        },
        "decision-original.json": {
          "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "470a34066224aa9c499ea0fa4be0ce66ce86a5be3efad7496037f4bdf4f2ae63",
          "byte_length": 721
        },
        "knowledge-ir.json": {
          "sha256": "1ff5fdcdf977f80a5839a8a9ee15af800ea5799a6baa12b3718e9be47d53524e",
          "byte_length": 12036
        },
        "review-original.json": {
          "sha256": "1ed0986c4e18951a7f1eb24ea315d841b99896d28b890bc69eda33aba47c1fe4",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "8ddee2fe7ee71397b9e32a5731ce4ead80d2496131a254e91f5c07b8a30cff9e",
          "byte_length": 994
        },
        "verification.json": {
          "sha256": "2cd5f55a517c3c6a254c43d7978d9c9d407d6142c26a7b45d7db152103bbff70",
          "byte_length": 16533
        },
        "verification.md": {
          "sha256": "00e78a648a92e66be64e14c3bfab816178635aee4a519cb3e6da376dcb34e3b8",
          "byte_length": 16967
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "occurrence_id": "occ-004de7325cc649f4468f9e347ec0a02111f6df665309a6acee018c8c2908dd4b",
      "input_id": "b",
      "binding": {
        "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
        "import_id": "53580652-4186-43b0-87ac-7c0bb6ea5d8b",
        "source_id": "e2f3eb1f-3711-4a9d-9631-4b792370e4f6",
        "version_id": "364fb9b6-a257-455a-a182-7c80fe57ad02",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "28dfa378-9e34-4840-a650-a0f7f92c5139",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-aaf23bd7c7b0e297af36b48a2df3a178e6cc566284c7153fc192e9436de01042",
      "input_id": "c",
      "binding": {
        "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
        "import_id": "c1ff603c-317e-4b5d-a5b7-8bec94a156e7",
        "source_id": "b6602b39-76a4-4621-b2ab-d37c45e05754",
        "version_id": "b1d336e6-d48e-4d19-8ad3-553e58b9b9bc",
        "content_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "normalized_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "881c5794-a66a-4d4e-9a0c-7ac033a0c2dc",
          "ordinal": 0,
          "resource_sha256": "e8b62c3dfe60918c0cf320b3cb2208b802180f3f48bceeb0a27dc4f6951bc920"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 105,
        "text": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 104,
          "excerpt_sha256": "78fbe48f80cd9b1f7084495aeac52e2ab7de515ba974eee80648acb4d19dfaa5",
          "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "51fa59a0-255f-4867-836c-aa39bdc01906",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "occurrence_id": "occ-e211f5c6f4834d25f04d620d9d052c24ae1833ea855d1a194cf484e4353bde01",
      "input_id": "a",
      "binding": {
        "project_id": "26b10a76-238a-4379-9f73-d15e19fb0e47",
        "import_id": "6b29d105-7b9f-48af-9c69-c85c7eaa2231",
        "source_id": "57d5b9b2-d9f3-43dc-879e-b495eeec3f55",
        "version_id": "a2af3db9-da37-4488-9b1b-9e9c599e80b0",
        "content_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "normalized_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "e0b45536-6b45-4fdf-a713-d8d4d733000f",
          "ordinal": 0,
          "resource_sha256": "2e41d82b0d66170ba814769f3a9dd55a03c47eedb413eda04adbf164a6c21944"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 107,
        "text": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 106,
          "excerpt_sha256": "5406801eddbb1fa19f5c3d97777e5f4f3ac798066289cad47b3dadae5b5fdd9b",
          "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "4b395f84-472a-4c37-88a6-8b93a40c3b04",
        "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002"
      ],
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "fact_id": "fact-2176d0ef755e6f1de61cf485f79a5805b933ddc9487e83fcd12064c305a175a4",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "4b395f84-472a-4c37-88a6-8b93a40c3b04",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-004de7325cc649f4468f9e347ec0a02111f6df665309a6acee018c8c2908dd4b",
        "occ-e211f5c6f4834d25f04d620d9d052c24ae1833ea855d1a194cf484e4353bde01"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "fact_id": "fact-6bc62067e5e15c97430ccb915d046434ef2b5edab41254cf60e7ef28f896d03b",
      "object_id": "a28c0e32-4a5e-4c6e-9b18-7b90f8b1a002",
      "property_id": "51fa59a0-255f-4867-836c-aa39bdc01906",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-aaf23bd7c7b0e297af36b48a2df3a178e6cc566284c7153fc192e9436de01042"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "left_occurrence_id": "occ-004de7325cc649f4468f9e347ec0a02111f6df665309a6acee018c8c2908dd4b",
      "right_occurrence_id": "occ-aaf23bd7c7b0e297af36b48a2df3a178e6cc566284c7153fc192e9436de01042",
      "relation": "complement",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-004de7325cc649f4468f9e347ec0a02111f6df665309a6acee018c8c2908dd4b",
      "right_occurrence_id": "occ-e211f5c6f4834d25f04d620d9d052c24ae1833ea855d1a194cf484e4353bde01",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "left_occurrence_id": "occ-aaf23bd7c7b0e297af36b48a2df3a178e6cc566284c7153fc192e9436de01042",
      "right_occurrence_id": "occ-e211f5c6f4834d25f04d620d9d052c24ae1833ea855d1a194cf484e4353bde01",
      "relation": "complement",
      "issue_code": null
    }
  ],
  "totals": {
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 0,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "3acebdfbcfdf2bc5f6a0d1ab7f8165b46ae01054def017c785250a45887d584b",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "ffabc487429d4d6c7450349842e76c4b1e69cf76109a8d729c9eb77cf8317392",
      "byte_length": 55920
    },
    "coordination-original.json": {
      "sha256": "1929b73f750917e20d73142a72824a98558d3c19abfe7a11d7dfce31093c66fd",
      "byte_length": 6404
    },
    "identity-original.json": {
      "sha256": "419d4155e834d9774b862516ffddc125a381c2c6cf36f35cc02cc1992d492048",
      "byte_length": 1616
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "0a81b6f291a65769b9ae3375e071aae515337e050be5db2d486458b33abaaa25",
      "byte_length": 2979
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
      "byte_length": 727
    },
    "input-a--knowledge-ir.json": {
      "sha256": "e257276799e223c554d9cc3febdfb38470414cebf33e6c7a85cb4f63cada307e",
      "byte_length": 12081
    },
    "input-a--review-original.json": {
      "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "5c27c7f7c653c77f89b341b9ea42f649518406a1dff8828f65a7f4ac18b1b3b1",
      "byte_length": 996
    },
    "input-a--verification.json": {
      "sha256": "7044d9ac6050fe6ac070f6267c6db500c1463a7afb156f0ff76958df2f7a7e1c",
      "byte_length": 16573
    },
    "input-a--verification.md": {
      "sha256": "802806b0f5c4b91ee19503e31710458f04ff7a7add868d6157ceece2914e7d74",
      "byte_length": 17007
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "33f630ec78144c68d32372ef7dda64cfc31577ec0fe4bde054c1bf01c77c7dc3",
      "byte_length": 2979
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "39a9ec601682c72b631b22949d98a68ba08098fbeb1b49d0ca0b618439b0b632",
      "byte_length": 727
    },
    "input-b--knowledge-ir.json": {
      "sha256": "9f4dc0f044fc26ccc87a93e05c50bf8f4d207ceb0fb4f51f83ab9bba571dd415",
      "byte_length": 12081
    },
    "input-b--review-original.json": {
      "sha256": "afb11d0ce0c0c1a3db3ec5033b6229e71d8849b9c116bb3a8696f8958d666cbb",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "1adb883f7ee1e520009448730f059744699a8cb58431f2dd400b6b26b184edfd",
      "byte_length": 996
    },
    "input-b--verification.json": {
      "sha256": "199c446537ef1f799f2081b40ba4d6911d5ad708b7c40042001852ce75f18dcd",
      "byte_length": 16573
    },
    "input-b--verification.md": {
      "sha256": "bcd380602b45826472ca5123762f21dd86062e585392d2bd7d04d832d38c78e9",
      "byte_length": 17007
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "3c2810c7e50567607a37dd96025b1b7a2a32ad9c2d174860e2396b8c480b117e",
      "byte_length": 2971
    },
    "input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    "input-c--gold-original.json": {
      "sha256": "470a34066224aa9c499ea0fa4be0ce66ce86a5be3efad7496037f4bdf4f2ae63",
      "byte_length": 721
    },
    "input-c--knowledge-ir.json": {
      "sha256": "1ff5fdcdf977f80a5839a8a9ee15af800ea5799a6baa12b3718e9be47d53524e",
      "byte_length": 12036
    },
    "input-c--review-original.json": {
      "sha256": "1ed0986c4e18951a7f1eb24ea315d841b99896d28b890bc69eda33aba47c1fe4",
      "byte_length": 510
    },
    "input-c--source-snapshot.json": {
      "sha256": "8ddee2fe7ee71397b9e32a5731ce4ead80d2496131a254e91f5c07b8a30cff9e",
      "byte_length": 994
    },
    "input-c--verification.json": {
      "sha256": "2cd5f55a517c3c6a254c43d7978d9c9d407d6142c26a7b45d7db152103bbff70",
      "byte_length": 16533
    },
    "input-c--verification.md": {
      "sha256": "00e78a648a92e66be64e14c3bfab816178635aee4a519cb3e6da376dcb34e3b8",
      "byte_length": 16967
    }
  }
}
```
