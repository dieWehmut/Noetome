"""Read-only fix review of retained public evidence; no CLI or suite replay."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import copy
import hashlib
import json
import subprocess

REPO = Path('D:/Noetome')
SDK = REPO / '.superpowers/sdd/B05-T01_COORDINATION_PLAN'
sys.path.insert(0, str(REPO / 'scripts'))
import verify_knowledge_coordination as v

result = {'range': 'c9df809..6146b98', 'receipts': [], 'probes': [], 'schema': []}
for label in ('task2-fix1-real-red', 'task2-fix1-focused-green', 'task2-fix1-module', 'task2-fix1-final-module', 'task2-fix1-audit', 'task2-fix1-check'):
    receipt = json.loads((SDK / (label + '-receipt.json')).read_bytes())
    for stream in ('stdout', 'stderr'):
        saved = receipt[stream]
        assert v.fingerprint(Path(saved['path']).read_bytes()) == {k: saved[k] for k in ('sha256', 'byte_length')}
    assert receipt['source_files_before'] == receipt['source_files_after']
    current = 0
    for path, fp in receipt['source_files_after'].items():
        if v.fingerprint((REPO / path).read_bytes()) == fp:
            current += 1
    result['receipts'].append({'label': label, 'exit': receipt['exit_code'], 'source_count': len(receipt['source_files_after']), 'current_matching': current})
    if label == 'task2-fix1-real-red':
        assert receipt['source_files_after']['scripts/verify_knowledge_coordination.py']['sha256'] == '50ed8b53c46fc15315dc85bb5d75d411b1ddd7c2598473c4181974591ebbf31c'
        stderr = Path(receipt['stderr']['path']).read_text(encoding='utf8')
        assert stderr.count('AssertionError: AssertionError not raised') == 13
        assert 'Ran 27 tests' in stderr and 'FAILED (failures=13)' in stderr
    if label in ('task2-fix1-final-module', 'task2-fix1-audit', 'task2-fix1-check'):
        assert current == len(receipt['source_files_after']) == 154

for path, expected in [('scripts/verify_knowledge_coordination.py', 'a896cadd16ebd05fc09b76ae8248c5e6c8d72b557b1bc65571fdcdb72bdeea7f'), ('tests/test_knowledge_coordination_verifier.py', 'b516cd4a15d9ed5344c3d25c478305d125812f8e398eabe4ccbfda2ffc5456b4')]:
    assert v.fingerprint((REPO / path).read_bytes())['sha256'] == expected
    committed = subprocess.check_output(['git', 'show', '6146b98:' + path], cwd=REPO)
    assert hashlib.sha256(committed).hexdigest() == expected

baseline = REPO / 'target/compiler-temp/task2-coordinate-audit-fix1-01/normal'
for name, root, refused in [('normal', baseline, False)] + [(name, SDK / 'task2-review-probes' / name, True) for name in ('source-visible-publication', 'coordination-trailing-publication', 'source-author-bool', 'source-reviewer-bool')]:
    before = v.inventory(root)
    try:
        summary = v.verify_report(root / 'project', root / 'case', root / 'output', (root / 'gold.json').read_bytes())
    except AssertionError as exc:
        assert refused, str(exc)
        row = {'name': name, 'refused': True, 'diagnostic': str(exc)}
    else:
        assert not refused, name + ' accepted'
        row = {'name': name, 'refused': False, 'summary': summary}
    assert before == v.inventory(root)
    row['read_only'] = True
    result['probes'].append(row)

roles = [json.loads((baseline / 'case/bundle-a' / (role + '-original.json')).read_bytes()) for role in ('review', 'gold', 'decision')]
v.source_roles_schema(*roles)
checks = 0
for index, names in [(0, 'purpose candidate_file gold_file decision_file gold_sha256 subject property reviewer interpretation_timing'), (1, 'author producer scientific_quality concept_name atom_content value unit quote verification knowledge_status value_status'), (2, 'unit_id disposition')]:
    for field in names.split():
        for value in (False, 17, None, '', '   ', {}, []):
            changed = copy.deepcopy(roles); changed[index][field] = value
            try:
                v.source_roles_schema(*changed)
            except AssertionError:
                checks += 1
            else:
                raise AssertionError((index, field, value))
result['schema'].append({'declared_text_invalid_cases_refused': checks})
for disposition in ('included', 'pending', 'needs_review', 'excluded'):
    changed = copy.deepcopy(roles)
    changed[0]['allowed_contexts'] = []
    changed[1].update(conditions=[], exceptions=[], value_status='unknown', value=None, unit=None)
    changed[2].update(disposition=disposition, atom_ids=[], exclusion_reason='documented reason' if disposition == 'excluded' else None)
    v.source_roles_schema(*changed)
result['schema'].append({'wire_valid_nullable_empty_cases': 4, 'coordinate_admission_claimed': False})

md = (baseline / 'output/coordination.md').read_bytes()
pre = md.split(b'```json\n', 1)[0].decode()
expected = json.loads((baseline / 'output/coordination.json').read_bytes())
v.verify_markdown(md, pre, expected, 'direct baseline')
for changed in (md + b'contradiction\n', md + b'\n', md[:-1], md + b'```json\n{}\n```\n', b'unexpected\n' + md, md.replace(b'\n```\n', b'\n```\n{}\n```\n')):
    try:
        v.verify_markdown(changed, pre, expected, 'complete envelope')
    except (AssertionError, ValueError):
        pass
    else:
        raise AssertionError('complete envelope mutation accepted')
result['markdown_direct_cases_refused'] = 6
result['status'] = 'passed'
path = SDK / 'task2-fix1-rereview-check.json'
with path.open('x', encoding='utf8', newline='\n') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
