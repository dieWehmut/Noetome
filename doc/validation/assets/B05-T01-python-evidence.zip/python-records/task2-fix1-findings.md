# Task 2 fix round 1 of 5

BASE: c9df8097501a19822c9d7545cfd1ea7c024d0c97. Fresh Task2 review: SPEC ❌ / quality needs fixes, three Important, no Critical. Exact full review task2-review.md; reproducible task2-review-probes.py and task2-review-probe-results.json; retained baseline/probe copies task2-review-probes/. Reviewer confirmed154 source hashes,23 passing module tests,24scenarios/48calls and all29protectedgroups; these authentic prior passes do not discharge the three defects.

## T2-R1: full source Markdown envelope

At scripts/verify_knowledge_coordination.py:279, source_bundle and the reused helper compare only fenced JSON. Original verification.md visible 发布：false → true, with current case fingerprints/output copies/artifact pins synchronized, was accepted as passed/independently_verified. Actual source, original author semantic gold/candidates/source JSON/IR remain independent and unchanged. Independently validate the complete source Markdown envelope, including all visible publication/scientific state and reviewer/timing provenance. Add the exact coherent regression before fixing it; only a real assertRaises failure is RED.

## T2-R2: complete coordination Markdown end

At line507, a valid coordination.md prefix/fenced JSON accepts appended 发布：true；科学质量：passed。 The closing fence/newline or explicitly permitted whitespace must exhaust the document. Validate the complete envelope, not just a prefix. Add a byte-preserving coherent appended-content regression before the repair; preserve an authentic saved baseline and all unrelated report/gold/source bytes.

## T2-R3: declared original-role field types

At source_bundle:226 and metadata:140, the limit walker is not a wire-type validator. gold-original.json.author=false and review-original.json.reviewer=false both pass after coherent original-role/report/case/output pins. Validate EVERY original review/gold/decision field's declared types, required nullable shape, applicable text constraints and enums before rebuilding expected reports, according to authoritative upstream SourceReview contract/DTOs and current coordinator Spec. Include bool,number,null,empty text regressions for the relevant text metadata and coverage for the other role's declared fields. Legitimate empty arrays or explicitly nullable values keep their documented semantics. Do not modify upstream Rust/old Python helpers or broaden the protocol; this is the existing Task2 strict boundary requirement.

## Scope and validation

Only the two original owned Python files. Preserve first complete implementation report and every old RED/setup failure/log/root; append fix findings/results to task-2-report.md. Read this finding, your same brief/full report and authoritative contracts, not other task/plan reports. First run new real regressions on c9 production behavior before edits, then minimal complete independent guards and affected tests. Once stable, run the final module and a fresh new-root ordinary audit because verifier semantics changed; retain case/gold/source/IR/fixture/sentinel fingerprints and current CLI/source SHA. No unchanged Rust/full Python suite repeat; controller owns full Python after review. Record precise actual commands/counts and limitations. Commit only owned files after checks, no push/ledger completion/later task/child agent. Controller will dispatch a fresh scoped re-review of T2-R1..R3 and new fix-diff breakage. No remaining Task1 readability or disproved output-limit changes.
