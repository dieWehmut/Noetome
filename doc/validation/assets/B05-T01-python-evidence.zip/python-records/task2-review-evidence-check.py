import sys, json, zipfile
from pathlib import Path
from collections import Counter
sys.path.insert(0,'D:/Noetome/scripts')
from verify_knowledge_coordination import fingerprint, inventory, verify_report
repo=Path('D:/Noetome'); sdk=Path(__file__).parent
rows=[]
for label in ['task2-first-real-red','task2-source-report-red','task2-source-report-real-red','task2-visible-md-red','task2-visible-md-real-red','task2-source-path-real-red','task2-source-path-green','task2-final-module','task2-stable-audit','task2-stable-check']:
    r=json.loads((sdk/(label+'-receipt.json')).read_bytes())
    logs={k: fingerprint(Path(r[k]['path']).read_bytes()) == {q:r[k][q] for q in ('sha256','byte_length')} for k in ('stdout','stderr')}
    current={n:fingerprint((repo/n).read_bytes()) for n in r['source_files_after']}
    rows.append(dict(label=label,exit_code=r['exit_code'],logs_match=logs,source_count=len(current),current_matches=sum(current[n]==p for n,p in r['source_files_after'].items()),before_after_same=r['source_files_before']==r['source_files_after']))
root=repo/'target/compiler-temp/task2-coordinate-audit-03'
a=json.loads((root/'audit.json').read_bytes())
commands=[]
for c in a['calls']:
    command_files=list(root.glob(f"command-{c['index']:03d}-*.json"))
    assert len(command_files)==1
    disk=json.loads(command_files[0].read_bytes())
    assert disk==c and c['exit_code']==c['expected_exit']
    for key in ('stdout','stderr'):
        assert fingerprint(Path(c[key]['path']).read_bytes()) == {q:c[key][q] for q in ('sha256','byte_length')}
    commands.append(dict(index=c['index'],name=c['name'],exit_code=c['exit_code']))
protected={n:inventory(Path(n)) if Path(n).is_dir() else fingerprint(Path(n).read_bytes()) for n in a['protected_before']}
assert protected==a['protected_before']==a['protected_after']
scenario_rows=[dict(name=s['name'],kind=s['kind'],call_index=s.get('call_index')) for s in a['scenarios']]
ordinary=[]
for s in a['scenarios']:
    if s['kind']=='ordinary_coordinate_and_independent_check':
        p,c,o=map(Path,(s['project'],s['case'],s['output']))
        if s['name']=='normal-two': g=root/'normal/two-authors/gold.json'
        else: g=p.parent/'gold.json'
        raw=g.read_bytes(); assert fingerprint(raw)==s['gold_fingerprint']
        checked=verify_report(p,c,o,raw)
        assert checked==s['check']
        ordinary.append(dict(name=s['name'],check=checked))
archive=repo/'doc/validation/assets/B05-T01-source-review-fixture.zip'
result=dict(receipts=rows,archive=dict(fingerprint=fingerprint(archive.read_bytes()),members=len(zipfile.ZipFile(archive).infolist())),cli=fingerprint((repo/'target/debug/noetome.exe').read_bytes()),scenario_count=len(scenario_rows),kinds=dict(Counter(s['kind'] for s in a['scenarios'])),scenarios=scenario_rows,commands=commands,protected_objects=len(protected),protected_match=True,independent_read_only_rechecks=ordinary)
(sdk/'task2-review-evidence-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
