# Global Constraints

- 当前唯一产品任务为 B05-T01；不启动 B05-T02/T03，不引入 GUI、模型调用、凭据读取、生产 Vault、完整实体图或冲突裁决。
- 普通入口为 `noetome knowledge coordinate <project> <coordination-case> <new-output>`，动词后可加 `--`；参数解析不读写文件。
- case 是同项目 2 至 3 份真实 extract verify 成功依据；严格 JSON schema_version=1，九文件精确清单、manifest 指纹、旧 IR/报告/源资源均需重新核验。
- manifest/映射各 64 KiB，映射数组各 1024 项，source_review 原限额保持，全部输入合计 96 MiB，总体 30000 ms；输入 ID、文件名、UUID 和文本规则按 Spec 原值。
- 完整同键才重复，键是 `[object_id,property_id,normalized_value,normalized_unit,sorted_normalized_conditions,sorted_normalized_exceptions]`；移除 Unicode 空白，不换算、不数值化、不删条件/例外。
- fact_id=`fact-`+紧凑 UTF-8 JSON 键 SHA256；occurrence_id=`occ-`+`[project_id,source_id,version_id,parse_id,unit_id,start_byte,end_byte,original_atom_id]` 紧凑 JSON SHA256。
- 名称与输入顺序不参与身份。每份原 IR 的概念、原子、支持证据、实际 binding 和 UTF8 定位保留；复制同一实际来源单位不能成为第二个独立来源。
- 不支持的同对象/属性语义差异或同来源不同版本/parse 身份为 needs_review/COORD_UNHANDLED_DIFFERENCE；canonical_facts=null，原组与证据保留，退出3且无协调IR。
- 知识 pending、published=false、科学 not_run、研究 not_requested、network_calls=paid_calls=0。作者样例不能证明真实教材或科学正确率。
- 新输出 root 独占、不得重叠；守卫贯穿保存之后，只撤去当前捕获的三个结果文件，不递归清理、不覆盖/删除未知内容。
- author gold/expected/map/source 在候选之前冻结；先普通 CLI 行为 RED，再生产代码；独立验证器先观察真实伪报告被错误接受的 RED，再实现检查。
- 任务小步提交，保留两项用户 docs 删除；普通推送已授权，检查通过后核对远端。任何失败原日志只追加、不抹去。


### Task 2: 独立 Python 来源/协调核验、伪造回归和CLI审计

**Files:** 新建 `scripts/verify_knowledge_coordination.py`、`tests/test_knowledge_coordination_verifier.py`。只读作者 fixture和Task1实际源码/证据；不改Rust、旧verifier或已有作者预期。控制器将Task1实际基线保留为 `doc/validation/assets/B05-T01-source-review-fixture.zip`，zip中的规范项目/case/output/gold均来自普通CLI，所有成员公开自造材料。

**Interfaces:**

```python
def verify_report(project, case, output, gold_bytes):
    """只读实际来源和全部保存结果；返回核验summary，假成功抛AssertionError。"""

def main(argv=None):
    # check <project> <case> <output> <gold>：只读核验，成功0，失败1
    # audit <cli> <new-test-root>：新根内实际CLI准备/运行/破坏/保护，成功0，失败1
    # --help 正常0；参数非法2
```

仅复用 `verify_extraction_knowledge.strict_json,fingerprint,actual_source,verify_report` 的独立只读来源算法，导入采用仓库scripts相对位置，不使用Rust协调函数/内嵌expected。源review.verify_report读取九件依据并按实际source解释；仍须补齐该旧函数不承诺的当前case九fingerprint、owner严格字段、严格类型/limits/路径、当前coordination schema、原角色边界及源IR的完整关系要求。

- [ ] **Step 1: 解包真实基线到新临时目录并先观察 verifier 行为 RED。** 一份临时初始verify_report仅返回保存JSON而不验证；它代表协调检查尚缺失，用下列测试证明可接受的结构伪造会导致真实AssertionError测试失败。初始普通 CLI基线已有Task1的GREEN，勿重新用“无法导入函数”当RED。

```python
# 临时RED骨架；GREEN实现必须替换它，不提交为完成验证器
def verify_report(project, case, output, gold_bytes):
    return json.loads((Path(output) / "coordination.json").read_text(encoding="utf-8"))

def test_missing_second_occurrence_is_rejected(self):
    self.remove_second_occurrence_and_rewrite_report_ir_md_fingerprints()
    with self.assertRaises(AssertionError):
        verify_report(self.project, self.case, self.output, self.gold_bytes)
```

unittest辅助从公开zip解包到新的临时根，解包前reject绝对/..路径。变异同步IR对应字段、coordinationJSON/MD事实及artifact指纹，保留case作者gold/实际源项目，避免只检查自洽性。测试基线必须通过；坏例包括删b全部出现/证据、把速度并入质量、伪值/单位/条件/例外、删除原对象、改源/版/UTF8边界/绑定、复制源却宣称3independent、改身份ID或角色、偷改原IR、虚假canonical/count/状态/published/scientific、漏原nullable/extra/duplicateJSON、错误或附加output清单。原firstRED日志必须保留。

- [ ] **Step 2: 实现完整独立重建。** 先读gold原字节并严格校验字段与预期，再读case、map、manifest九fp和SourceReview原件；source用只读immutable SQLite重新定位原资源/Unit/UTF8，调用旧独立verify_report证明全部来源依据实际passed。一份IR候选必须真有一个atom和每个支持证据，actualsource/原gold/原角色字节不可互换。

独立按原map建全概念及主体/属性角色，按原gold明确value/unit/conditions/exceptions建事实key/ID和实际occurrence ID，从实际原子而非报告建立出现、完整原字段和证据列表。按Spec对每对出现重建duplicate/complement/separate_object/needs_review和逐出现/fact状态；重建全部计数和原分区。

```python
def normalized(value):
    return "".join(value.split())

def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

key = [mapping["object_id"], mapping["property_id"], normalized(gold["value"]),
       normalized(gold["unit"]), sorted(map(normalized, gold["conditions"])),
       sorted(map(normalized, gold.get("exceptions", [])))]
fact_id = "fact-" + hashlib.sha256(compact(key)).hexdigest()
```

外部作者expected还独立约束真实速度/质量、条件例外、原ID/source成员和分母。报告/IR各严格字段、fixed值、bool/int/nullable类型、完整同事实Markdown、所有artifact副本fp、唯一output清单与实际所需IR存在关系逐一核对。需要复核时没有IR且canonical=null；known空值、unknown伪零、非整数/布尔count不可通过。输入/source/output只读inventory前后核对；失败抛明确AssertionError，CLI check诊断不含凭据。

- [ ] **Step 3: 实际普通CLI审计矩阵。** audit驱动先确保全新测试根，外部哨兵在该根外；保存作者gold/fixture指纹先于候选。准备普通三source/source_review/case并保存每个Command实际argv/stdout/stderr/exit/time，运行coordinate后调用独立verify_report。至少正常三源、两源、顺序/显示名变更、条件差异和单位差异needs_review、同source不同版本needs_review；派生作者expected在候选前保存，不从Rust报告反填。

对原/派生依据做binding同SHA偷换、IR/candidate+全部fingerprint同步伪造、第二证据丢失、原unknowncount、复制输入、未知/重复键和输出碰撞。每个场景使用新根或新case/output，不改前个原样例；拒绝路径检查真实非零和无成功IR。审计summary只汇总实际执行，不把内部assert数量称为产品测试数。

保存原source project/SQL/原IR/gold、作者fixture、外部哨兵的前后完整SHA；发生预期拒绝仍要核对保护。守卫 race 若已由Task1 cfg测试执行，记录其命令/结果，不把“驱动无法注入”称为再次CLI race通过。保留actual read-only check结果及CLI SHA；成功和失败原日志均不覆盖。

- [ ] **Step 4: 聚焦 GREEN、模块回归和提交自审。** 按新增unittest执行聚焦测试、完整新模块与audit；只在失败或新更改后重复受影响检查。控制器在最终源码上执行一次完整Python/Rust/log/Git回归和远端核对。git diff --check，小步提交授权两文件，写task-2-report.md完整TDD/实际审计/证据位置/局限，短答状态/提交/真实测试/concerns。控制器做Task2新鲜spec+quality审查，最终整分支审查只有一个席位。

## Dispatch clarification from the completed Task 1

- 普通 source import 对同字节内容默认复用已有来源。audit 的 B 必须先通过普通 CLI 登记一份唯一 seed，取得实际 B source_id，再用 `--source-id` 将冻结 source-b.txt 的同字节正文导入这个既有来源；三份选中的 final A/B/C 才是协调输入。seed 是保留的未选历史版本，不能计为第四输入。不要修改源子系统，不把三个自造来源 ID 宣称为三本真实独立教材。
- 严格保存包结构错误也属于 `COORD_SCHEMA`/2；有效类型的实际来源或语义不匹配仍属 `COORD_SOURCE_REVIEW`/3。Task1 七个真实普通 CLI schema RED/GREEN 已通过限定复查。
- 1 MiB 限额适用于实际 RequestUnit.text 原 UTF-8 正文；1024-byte 元数据限制不用于截断或否定合法正文。现有 Artifact::create 对输出每件 8 MiB 的 `EXTRACT_SAVE_LIMIT`/3 已由真实大输入探测确认，不另改 Rust 限额。
- 真实参考 ZIP 来自 Task1 的初次全量 GREEN（commit 8f033e25ffad9ef114bf3c603cbd7ad2089673b3）。fix1 只保留错误分类，没有改变参考的合法结果字节。ZIP SHA256=56226f12ff26f6e4199029e2c0230cfaecc5048b00272410b161bafc7e15682f，131 members；规范根为 `project/`、`case/`、`output/`、`authors/` 和 `gold.json`。保留 ZIP 不覆盖；当前 audit 使用实际新 CLI，不能把旧参考编译指纹冒充新验证。
- 只读原源码、此 brief、权威 Spec、公开参考与自己的工作。禁止阅读同一 .superpowers/sdd 目录的其他计划或其他任务 brief/report；本任务证据只写此 plan workspace。`controller.py run <unique-label> <PowerShell command>` 可保留实际原日志/源码指纹；它会设置 TEMP/TMP 为外部系统临时目录以及 NOETOME_TEST_PYTHON/NOETOME_PDF_PYTHON，不输出凭据。
- 选定 Python 为 `C:/Users/Lyinn/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`，命令加 `-X utf8`；这只是当前执行路径，不硬编码到生产脚本。当前 CLI 为 `D:/Noetome/target/debug/noetome.exe`，SHA256=97ebd64ec0a2fe84e08a64e5a126f5b61e81adb24deb43b65de7be7aef809203，17974784 bytes。Task1 full Rust gate 558 passed/0 failed/0 ignored across16 suites；Rust不变就不要重复它。


