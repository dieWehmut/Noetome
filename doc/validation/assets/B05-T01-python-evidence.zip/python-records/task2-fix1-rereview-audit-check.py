import sys
sys.dont_write_bytecode = True
from pathlib import Path
from collections import Counter
import json
sys.path.insert(0, 'D:/Noetome/scripts')
from verify_knowledge_coordination import fingerprint, inventory
root = Path('D:/Noetome/target/compiler-temp/task2-coordinate-audit-fix1-01')
audit = json.loads((root / 'audit.json').read_bytes())
assert len(audit['scenarios']) == audit['scenario_count'] == 33
assert len(audit['calls']) == audit['command_count'] == 56
for call in audit['calls']:
    saved = json.loads((root / ('command-%03d-%s.json' % (call['index'], call['name']))).read_bytes())
    assert saved == call
    assert call['expected_exit'] == call['exit_code']
    for stream in ('stdout', 'stderr'):
        receipt = call[stream]
        assert fingerprint(Path(receipt['path']).read_bytes()) == {k: receipt[k] for k in ('sha256', 'byte_length')}
assert audit['protected_before'] == audit['protected_after']
files = 0
for name, saved in audit['protected_before'].items():
    path = Path(name)
    if 'sha256' in saved:
        assert fingerprint(path.read_bytes()) == saved
        files += 1
    else:
        assert inventory(path) == saved
        files += sum('sha256' in entry for entry in saved.values())
result = dict(status='passed', calls=56, scenarios=33,
              scenario_kinds=dict(Counter(row['kind'] for row in audit['scenarios'])),
              exits=dict(Counter(str(row['exit_code']) for row in audit['calls'])),
              protected_groups=len(audit['protected_before']),
              protected_file_hash_entries_including_overlap=files)
out = Path('D:/Noetome/.superpowers/sdd/B05-T01_COORDINATION_PLAN/task2-fix1-rereview-audit-check.json')
with out.open('x', encoding='utf8', newline='\n') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
