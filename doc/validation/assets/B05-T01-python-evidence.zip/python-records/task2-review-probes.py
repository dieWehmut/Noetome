import sys, json, zipfile, hashlib
from pathlib import Path
sys.path.insert(0, 'D:/Noetome/tests')
from test_knowledge_coordination_verifier import CoordinationVerifierTests, encoded, fp
from verify_knowledge_coordination import verify_report, inventory

sdk = Path(__file__).parent
archive = Path('D:/Noetome/doc/validation/assets/B05-T01-source-review-fixture.zip')
roots = sdk / 'task2-review-probes'
roots.mkdir(exist_ok=False)
results = []
for scenario in ['source-visible-publication', 'coordination-trailing-publication', 'source-author-bool', 'source-reviewer-bool']:
    root = roots / scenario
    root.mkdir()
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            name = Path(info.filename)
            assert not name.is_absolute() and '..' not in name.parts and ':' not in info.filename and '\\' not in info.filename
            p = root / name
            if info.is_dir(): p.mkdir(parents=True, exist_ok=True)
            else:
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(z.read(info))
    t = CoordinationVerifierTests()
    t.project, t.case, t.output = (root / x for x in ('project', 'case', 'output'))
    t.gold_bytes = (root / 'gold.json').read_bytes()
    t.report = json.loads((t.output / 'coordination.json').read_bytes())
    baseline = verify_report(t.project,t.case,t.output,t.gold_bytes)
    bundle = t.case / 'bundle-a'
    if scenario == 'source-visible-publication':
        p = bundle / 'verification.md'
        raw = p.read_bytes()
        prefix, body = raw.split(b'```json\n', 1)
        print('source preamble:', prefix.decode())
        changed = prefix.replace('发布：false'.encode(), '发布：true'.encode(), 1)
        assert changed != prefix
        p.write_bytes(changed + b'```json\n' + body)
    elif scenario == 'coordination-trailing-publication':
        p = t.output / 'coordination.md'
        p.write_bytes(p.read_bytes() + '\n发布：true；科学质量：passed。\n'.encode())
    else:
        if scenario == 'source-author-bool':
            p = bundle / 'gold-original.json'
            g = json.loads(p.read_bytes()); g['author'] = False; p.write_bytes(encoded(g))
            review = json.loads((bundle / 'review-original.json').read_bytes())
            review['gold_sha256'] = fp(p.read_bytes())['sha256']
            (bundle / 'review-original.json').write_bytes(encoded(review))
        else:
            review = json.loads((bundle / 'review-original.json').read_bytes())
            review['reviewer'] = False
            (bundle / 'review-original.json').write_bytes(encoded(review))
        r = json.loads((bundle / 'verification.json').read_bytes())
        r['origin']['gold_sha256'] = review['gold_sha256']
        if scenario == 'source-reviewer-bool':
            r['origin']['reviewer'] = False; r['rules']['reviewer'] = False
        for role, copy in [('review.json','review-original.json'),(review['gold_file'],'gold-original.json')]:
            r['origin']['input_fingerprints'][role] = fp((bundle / copy).read_bytes())
        for name in r['artifacts']: r['artifacts'][name] = fp((bundle / name).read_bytes())
        (bundle / 'verification.json').write_bytes(encoded(r))
        p = bundle / 'verification.md'
        p.write_bytes(p.read_bytes().split(b'```json\n',1)[0]+b'```json\n'+encoded(r).rstrip()+b'\n```\n')
    if scenario != 'coordination-trailing-publication':
        t.repin_bundle()
        t.rewrite()
    before = [inventory(p) for p in (t.project,t.case,t.output)]
    try:
        result = verify_report(t.project,t.case,t.output,t.gold_bytes)
        outcome = {'accepted': True, 'result': result}
    except Exception as e:
        outcome = {'accepted': False, 'error_type': type(e).__name__, 'error': str(e)}
    outcome.update(scenario=scenario, baseline=baseline, read_only=before == [inventory(p) for p in (t.project,t.case,t.output)])
    results.append(outcome)
    print(json.dumps(outcome, ensure_ascii=False))
(sdk / 'task2-review-probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
