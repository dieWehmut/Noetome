from pathlib import Path
import hashlib,json,re,subprocess
root=Path('D:/Noetome')
plan=root/'.superpowers/sdd/B05-T02_VARIANTS_PLAN'
def digest(p):
    b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'byte_length':len(b)}
fixture=root/'fixtures/knowledge-coordination-v2'
frozen=json.loads((fixture/'frozen-sha256.json').read_text(encoding='utf-8'))['files']
for n,pin in frozen.items():assert digest(fixture/n)==pin,n
owned=['knowledge_coordinate.rs','knowledge_coordinate_input.rs','knowledge_coordinate_facts.rs','knowledge_coordination_v2_model.rs','knowledge_coordinate_context.rs','knowledge_coordinate_variants.rs','lib.rs']
files=[root/'crates/noetome-cli/src'/n for n in owned]+[root/'crates/noetome-cli/tests/knowledge_variants.rs',root/'crates/noetome-cli/tests/support/coordination_variants_case.rs']
receipt={'source_files':{str(p):digest(p) for p in files},'authors':{str(p):digest(p) for p in fixture.iterdir()},'cli':digest(root/'target/debug/noetome.exe'),'roots':[]}
log=(plan/'task-1-final-focused-green.txt').read_text(encoding='utf-8-sig')
for match in re.finditer(r'prepared_variants_root=(.+?) case=(\S+)',log):
    path=Path(match[1]);case=match[2]
    before=json.loads((path/'protection-before.json').read_text(encoding='utf-8'))
    after=json.loads((path/'protection-after.json').read_text(encoding='utf-8'))
    assert before==after,str(path)
    for p,pin in after.items():assert digest(Path(p))==pin,p
    commands={}
    for argv in sorted(path.glob('*-argv.json')):
        label=argv.name[:-10]
        commands[label]={'argv':json.loads(argv.read_text(encoding='utf-8')),'exit':int((path/f'{label}-exit.txt').read_text()),'files':{str(p):digest(p) for p in [argv,path/f'{label}-stdout.txt',path/f'{label}-stderr.txt',path/f'{label}-exit.txt']}}
    receipt['roots'].append({'root':str(path),'author_case':case,'commands':commands,'protected_files':len(after),'protection_fingerprints':{str(path/n):digest(path/n) for n in ['protection-before.json','protection-after.json']},'cli_sha256':(path/'cli-sha256.txt').read_text()})
receipt['root_count']=len(receipt['roots'])
receipt['coordinate_calls']=sum(sum(k.startswith('coordinate') for k in r['commands']) for r in receipt['roots'])
receipt['upstream_source_reviews']=sum(sum(k.startswith('verify-') for k in r['commands']) for r in receipt['roots'])
receipt['all_upstream_passed']=all(c['exit']==0 for r in receipt['roots'] for k,c in r['commands'].items() if k.startswith('verify-'))
receipt['all_protected_fingerprints_match']=True
(plan/'task-1-final-receipts.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print({k:receipt[k] for k in ['root_count','coordinate_calls','upstream_source_reviews','all_upstream_passed','all_protected_fingerprints_match']})
