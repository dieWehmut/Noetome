# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：3；条件未知：0；条件不适用：0；时间已知：0；时间未知：3；条件并列关系：2；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "602f6ced-c88a-4cfd-b882-e21f9045a821",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
        "import_id": "61ec0bf4-f803-4a89-9bfd-b8d6ead5d23e",
        "source_id": "e828dc57-598d-4380-a79a-63c696a32a7e",
        "version_id": "3d4934d7-ccde-4bf6-8235-88e54e2c5d2f",
        "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "import_id": "61ec0bf4-f803-4a89-9bfd-b8d6ead5d23e",
              "manifest_sha256": null,
              "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "parse_id": null,
              "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
              "source_id": "e828dc57-598d-4380-a79a-63c696a32a7e",
              "version_id": "3d4934d7-ccde-4bf6-8235-88e54e2c5d2f"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "import_id": "61ec0bf4-f803-4a89-9bfd-b8d6ead5d23e",
              "manifest_sha256": null,
              "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
              "parse_id": null,
              "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
              "source_id": "e828dc57-598d-4380-a79a-63c696a32a7e",
              "version_id": "3d4934d7-ccde-4bf6-8235-88e54e2c5d2f"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "83defc8d94cc7d4e1e3a0da40a8517cfac51dd0f1fb8cb20c9ef0131170ac3d9",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "83defc8d94cc7d4e1e3a0da40a8517cfac51dd0f1fb8cb20c9ef0131170ac3d9",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "f35682404e328cb529a157b76fd0d909483faef1d19041d5dbd8c5d3a4a9257f",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "c8fb464790be7385b92d73efedd99b347ddd05544b0a88ae0dba25cec7c0fa0e",
          "byte_length": 12751
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "2dac5208b9546354ec9476ca6b5e6b60e6ade6b604850e4f083abacb30dbb79f",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "b74279cf651d3d367d9005afebd5ca00f98ea77eda5fe4877a4a3dfa10ef6b6a",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "0e3df5f4d1b10d0cfb4ec2a87f34b6854e72f6e7bb124e92dfdaef21940da614",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
        "import_id": "0c35810e-0585-472e-a048-dc04cd3adc9b",
        "source_id": "64462df9-8aa6-4ed8-8c3f-1e3db59801df",
        "version_id": "ec0ea237-5f3a-42ff-8cc1-be8672889e08",
        "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "import_id": "0c35810e-0585-472e-a048-dc04cd3adc9b",
              "manifest_sha256": null,
              "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "parse_id": null,
              "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
              "source_id": "64462df9-8aa6-4ed8-8c3f-1e3db59801df",
              "version_id": "ec0ea237-5f3a-42ff-8cc1-be8672889e08"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "import_id": "0c35810e-0585-472e-a048-dc04cd3adc9b",
              "manifest_sha256": null,
              "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
              "parse_id": null,
              "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
              "source_id": "64462df9-8aa6-4ed8-8c3f-1e3db59801df",
              "version_id": "ec0ea237-5f3a-42ff-8cc1-be8672889e08"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "5f828c851399019d51fb59a567e958219d542c770634e6705d5a6375af1308d0",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "5f828c851399019d51fb59a567e958219d542c770634e6705d5a6375af1308d0",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "2a80c94e210eefbe4334c1e5006a4c9e87eba9cb004a1e0b6d75863c1ded8025",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "55c863ff60e24035f581195656ddca32e396c468f5be55e14a62ce3993abeda6",
          "byte_length": 12751
        },
        "review-original.json": {
          "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "9536b63de585b10f924754a40f79def709a45f1e3aa9f99116b8c3f232d69ca2",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "3edb38af918280c7f65024342527185c8219c20c600f483eb528b6ef77a1f604",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "3cf7526d5808dc25f3b965edf3364dfcddfb671c75c9edbdc14b7ca7f8b675b1",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
        "import_id": "0b359e07-c983-4ce3-b498-ba90d50e01bb",
        "source_id": "546aa8ad-07ad-4053-a4ea-88fe2e6aab5e",
        "version_id": "7312e412-53ab-41fb-80bd-bf47a1244123",
        "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-speed"
            ],
            "decision": {
              "atom_ids": [
                "c-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "import_id": "0b359e07-c983-4ce3-b498-ba90d50e01bb",
              "manifest_sha256": null,
              "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "parse_id": null,
              "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
              "source_id": "546aa8ad-07ad-4053-a4ea-88fe2e6aab5e",
              "version_id": "7312e412-53ab-41fb-80bd-bf47a1244123"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "import_id": "0b359e07-c983-4ce3-b498-ba90d50e01bb",
              "manifest_sha256": null,
              "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
              "parse_id": null,
              "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
              "source_id": "546aa8ad-07ad-4053-a4ea-88fe2e6aab5e",
              "version_id": "7312e412-53ab-41fb-80bd-bf47a1244123"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 282,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 283,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 282,
            "excerpt_sha256": "2754b0a31c97bba9a7ac62166898c287a30c9f6811eff7446b0a6db51f778599",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 203,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 91
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 282,
              "excerpt_sha256": "2754b0a31c97bba9a7ac62166898c287a30c9f6811eff7446b0a6db51f778599",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 283,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "4465de48420e6d2701fd17bfe36cbee5e8fd09ce06e9dcbf814d3a990901c64d",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "e8e28e18c51e21762ecdb9f91f637c2601ad1e0caca730d570fffd731dba0782",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "ac09950cb6565347fed7f202673b7ce40a12e6514a7c58e866d2a4ab46c560fa",
          "byte_length": 12751
        },
        "review-original.json": {
          "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "fcd9ef69df5f7f10de8c5878c0a4f1c1cdb57170180cea6abaee09a9b40b47a5",
          "byte_length": 1175
        },
        "verification.json": {
          "sha256": "f4878e7c7bc45b4afbe15884ac65ed411babb4a47ca72c0f4693269cd55271be",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "ce4c7acb1cb49b793f870f77dd50ec1e981282ce1db00096e8ef7db7146e7398",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "c-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-599e69ee1b2f52000d3dee1d205041fba30f512b8beebe95576d73d58ca086fe",
      "input_id": "c",
      "binding": {
        "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
        "import_id": "0b359e07-c983-4ce3-b498-ba90d50e01bb",
        "source_id": "546aa8ad-07ad-4053-a4ea-88fe2e6aab5e",
        "version_id": "7312e412-53ab-41fb-80bd-bf47a1244123",
        "content_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "normalized_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "c60e2704-98d9-48ea-ac0c-e3e412ce58b1",
          "ordinal": 0,
          "resource_sha256": "3023754ed27fc5cd3aa94daf7a4f383fa9e902c5c5895b8f55c1dd35531c74f4"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "2754b0a31c97bba9a7ac62166898c287a30c9f6811eff7446b0a6db51f778599",
          "quote": "公开自造资料 conditional/c。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "cbecd5de19d013b2f86072ed6fc2f4dff377bf6c6293c62d73f8a3205f40f288"
      },
      "occurrence_id": "occ-a300aa17a9b22667f45cfeee42ac11075ce069d2c5a83b84317cc0aff5057e23",
      "input_id": "b",
      "binding": {
        "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
        "import_id": "0c35810e-0585-472e-a048-dc04cd3adc9b",
        "source_id": "64462df9-8aa6-4ed8-8c3f-1e3db59801df",
        "version_id": "ec0ea237-5f3a-42ff-8cc1-be8672889e08",
        "content_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "normalized_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "b45dca84-8115-40dd-b9f0-ec84592a9cf6",
          "ordinal": 0,
          "resource_sha256": "5de1e66003afe0cbb87a789411c218dad85aa70df9562feeaa770f2aa57f2c6b"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "5f828c851399019d51fb59a567e958219d542c770634e6705d5a6375af1308d0",
          "quote": "公开自造资料 conditional/b。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "unknown",
          "precision": null,
          "value": null
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 36,
        "end_byte": 203,
        "quote": "适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "b359b8621975bca697dc5fd6470df7f1f2089a22790979392483e89cd83b902e"
      },
      "occurrence_id": "occ-c9f6410a040ba0b297952f8b319824605836139a596f26855f386ce807bcd569",
      "input_id": "a",
      "binding": {
        "project_id": "90fa6119-3d4c-4cac-b90c-128c3199e9a1",
        "import_id": "61ec0bf4-f803-4a89-9bfd-b8d6ead5d23e",
        "source_id": "e828dc57-598d-4380-a79a-63c696a32a7e",
        "version_id": "3d4934d7-ccde-4bf6-8235-88e54e2c5d2f",
        "content_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "normalized_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "7bbeda78-4460-413f-8f2c-05b43a555a77",
          "ordinal": 0,
          "resource_sha256": "5dc6d5f4a82c1933cd59252026baf782fe21f4b14ecfe0625990bf737b67966c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 283,
        "text": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 282,
          "excerpt_sha256": "83defc8d94cc7d4e1e3a0da40a8517cfac51dd0f1fb8cb20c9ef0131170ac3d9",
          "quote": "公开自造资料 conditional/a。\n适用条件：已列明；观点时间：未给出。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-37b85ca43695cab4ad15df81b37b0522781319aa80d8bfb70a34f7d38f961b87",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-a300aa17a9b22667f45cfeee42ac11075ce069d2c5a83b84317cc0aff5057e23"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "unknown",
        "precision": null,
        "value": null
      },
      "fact_id": "fact-v2-46095a1c44ebd5480c385ff9d5e1c33cbd087a5c7a75c76332d4f17b7b3a8db7",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-599e69ee1b2f52000d3dee1d205041fba30f512b8beebe95576d73d58ca086fe",
        "occ-c9f6410a040ba0b297952f8b319824605836139a596f26855f386ce807bcd569"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-599e69ee1b2f52000d3dee1d205041fba30f512b8beebe95576d73d58ca086fe",
      "right_occurrence_id": "occ-a300aa17a9b22667f45cfeee42ac11075ce069d2c5a83b84317cc0aff5057e23",
      "relation": "condition_variant",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-599e69ee1b2f52000d3dee1d205041fba30f512b8beebe95576d73d58ca086fe",
      "right_occurrence_id": "occ-c9f6410a040ba0b297952f8b319824605836139a596f26855f386ce807bcd569",
      "relation": "duplicate",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-a300aa17a9b22667f45cfeee42ac11075ce069d2c5a83b84317cc0aff5057e23",
      "right_occurrence_id": "occ-c9f6410a040ba0b297952f8b319824605836139a596f26855f386ce807bcd569",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 2,
    "historical_relations": 0,
    "known_condition_occurrences": 3,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 0,
    "undated_occurrences": 3,
    "context_evidence_links": 3,
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "c17846bd95a1c0a8fce8dd4f4a0b7be12295c6d30ceb73b56a0b4413bdd0c901",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "e28e22c5dd831e3fae4716b4ed1def51895f58b39d8ebe529f10fd1d33d23e61",
      "byte_length": 61019
    },
    "coordination-original.json": {
      "sha256": "cdea5b0458919e548c2a243d66c19a312606d3252b22374452d548370bb1e9c5",
      "byte_length": 6400
    },
    "identity-original.json": {
      "sha256": "bc3986a29b0fd84acef17474657fad1dd9c0975d8a4d54e1ab8cd62257cccda0",
      "byte_length": 2650
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "f35682404e328cb529a157b76fd0d909483faef1d19041d5dbd8c5d3a4a9257f",
      "byte_length": 3175
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-a--knowledge-ir.json": {
      "sha256": "c8fb464790be7385b92d73efedd99b347ddd05544b0a88ae0dba25cec7c0fa0e",
      "byte_length": 12751
    },
    "input-a--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "2dac5208b9546354ec9476ca6b5e6b60e6ade6b604850e4f083abacb30dbb79f",
      "byte_length": 1175
    },
    "input-a--verification.json": {
      "sha256": "b74279cf651d3d367d9005afebd5ca00f98ea77eda5fe4877a4a3dfa10ef6b6a",
      "byte_length": 17226
    },
    "input-a--verification.md": {
      "sha256": "0e3df5f4d1b10d0cfb4ec2a87f34b6854e72f6e7bb124e92dfdaef21940da614",
      "byte_length": 17660
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "2a80c94e210eefbe4334c1e5006a4c9e87eba9cb004a1e0b6d75863c1ded8025",
      "byte_length": 3175
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "55c863ff60e24035f581195656ddca32e396c468f5be55e14a62ce3993abeda6",
      "byte_length": 12751
    },
    "input-b--review-original.json": {
      "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "9536b63de585b10f924754a40f79def709a45f1e3aa9f99116b8c3f232d69ca2",
      "byte_length": 1175
    },
    "input-b--verification.json": {
      "sha256": "3edb38af918280c7f65024342527185c8219c20c600f483eb528b6ef77a1f604",
      "byte_length": 17226
    },
    "input-b--verification.md": {
      "sha256": "3cf7526d5808dc25f3b965edf3364dfcddfb671c75c9edbdc14b7ca7f8b675b1",
      "byte_length": 17660
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "4465de48420e6d2701fd17bfe36cbee5e8fd09ce06e9dcbf814d3a990901c64d",
      "byte_length": 3175
    },
    "input-c--decision-original.json": {
      "sha256": "e8e28e18c51e21762ecdb9f91f637c2601ad1e0caca730d570fffd731dba0782",
      "byte_length": 140
    },
    "input-c--gold-original.json": {
      "sha256": "715368835a2247e03d6eb5733db90259eef9581e65366d350145b86176784130",
      "byte_length": 746
    },
    "input-c--knowledge-ir.json": {
      "sha256": "ac09950cb6565347fed7f202673b7ce40a12e6514a7c58e866d2a4ab46c560fa",
      "byte_length": 12751
    },
    "input-c--review-original.json": {
      "sha256": "d2eb15d816e1ae246b2b60b683bf1132382263eb5f15297f7ecea45de559d048",
      "byte_length": 509
    },
    "input-c--source-snapshot.json": {
      "sha256": "fcd9ef69df5f7f10de8c5878c0a4f1c1cdb57170180cea6abaee09a9b40b47a5",
      "byte_length": 1175
    },
    "input-c--verification.json": {
      "sha256": "f4878e7c7bc45b4afbe15884ac65ed411babb4a47ca72c0f4693269cd55271be",
      "byte_length": 17226
    },
    "input-c--verification.md": {
      "sha256": "ce4c7acb1cb49b793f870f77dd50ec1e981282ce1db00096e8ef7db7146e7398",
      "byte_length": 17660
    }
  }
}
```
