# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
      "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
      "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
      "version_id": "62db1631-6f51-4875-8441-2ac652807d73",
      "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
      "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "2cd3a255-3140-4d19-8403-369b22d8ea6c",
          "ordinal": 0,
          "resource_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 286,
        "text": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
    "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
    "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
    "version_id": "62db1631-6f51-4875-8441-2ac652807d73",
    "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
    "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "762fb4d062876b5076e43b01507ef0d4dfbcb9cbd8db1dcb77c6e36fa6d4ea32",
        "byte_length": 3178
      },
      "decision.json": {
        "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
        "byte_length": 746
      },
      "review.json": {
        "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
        "byte_length": 509
      }
    },
    "gold_sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
          "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
          "manifest_sha256": null,
          "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
          "parse_id": null,
          "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
          "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
          "version_id": "62db1631-6f51-4875-8441-2ac652807d73"
        },
        "request_id": "synthetic-coordination-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
          "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
          "manifest_sha256": null,
          "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
          "parse_id": null,
          "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
          "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
          "version_id": "62db1631-6f51-4875-8441-2ac652807d73"
        },
        "request_id": "synthetic-coordination-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 285,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 286,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 285,
        "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
        "excerpt_start_byte": 0,
        "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 206,
        "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 94
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 285,
          "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
          "excerpt_start_byte": 0,
          "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "12",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "m/s",
        "value": "12",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "温度 30 ℃",
      "actual": {
        "body": [
          "温度30℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度30℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "m/s",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度30℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 30 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 286,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 30 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 30 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "762fb4d062876b5076e43b01507ef0d4dfbcb9cbd8db1dcb77c6e36fa6d4ea32",
      "byte_length": 3178
    },
    "decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
      "byte_length": 746
    },
    "knowledge-ir.json": {
      "sha256": "6b21d7862cda43f8b0ed45b420e8181fbdb346ccb77ff0e227a1df0a55c4a962",
      "byte_length": 12760
    },
    "review-original.json": {
      "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
      "byte_length": 509
    },
    "source-snapshot.json": {
      "sha256": "8c8e4f3fbaef68574491d3eca861b9c2d3fb7bd4edfee2fd9c54d9cb9f95cd0e",
      "byte_length": 1178
    }
  }
}
```
