# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：1；历史关系：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 2,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "1bc41cbf-66b9-417a-9b05-ffa3dd113845",
  "scope": "explicit_identity_condition_time_v2",
  "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "00000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "00000000-0000-4000-8000-000000000002",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
        "import_id": "8745afb4-a792-45e3-a4b9-059d8701b933",
        "source_id": "1be6e779-5276-4701-bedc-c71b2dbcceec",
        "version_id": "3e42ba28-5272-4938-9868-a02f9202365a",
        "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "import_id": "8745afb4-a792-45e3-a4b9-059d8701b933",
              "manifest_sha256": null,
              "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "parse_id": null,
              "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
              "source_id": "1be6e779-5276-4701-bedc-c71b2dbcceec",
              "version_id": "3e42ba28-5272-4938-9868-a02f9202365a"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "import_id": "8745afb4-a792-45e3-a4b9-059d8701b933",
              "manifest_sha256": null,
              "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
              "parse_id": null,
              "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
              "source_id": "1be6e779-5276-4701-bedc-c71b2dbcceec",
              "version_id": "3e42ba28-5272-4938-9868-a02f9202365a"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 284,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 285,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 284,
            "excerpt_sha256": "0f6603d227f82cc21db3984395af4897171a8045f038bfcdff3623cc1c741a04",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 205,
            "quote": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 284,
              "excerpt_sha256": "0f6603d227f82cc21db3984395af4897171a8045f038bfcdff3623cc1c741a04",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "8",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "8",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "d8c6780134af92945695c0660451be727c6b51d75d9c4e0320894209b43348b2",
          "byte_length": 3175
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
          "byte_length": 743
        },
        "knowledge-ir.json": {
          "sha256": "03a5bbb46388d36acbd85885f29e2a51f20700f9b5853b4887ea411ccf9763f6",
          "byte_length": 12749
        },
        "review-original.json": {
          "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "434151c1ec2e2cedee2fcb86e8566be86e37c2c061ab612b451c8a248d205066",
          "byte_length": 1177
        },
        "verification.json": {
          "sha256": "7474e11605ca9d5016e8d3fbbccddc11b1a5c062f241c634c4f6242a33e2b321",
          "byte_length": 17226
        },
        "verification.md": {
          "sha256": "3a26aa9305028a782fbd63d9fa30f2bb589353ac95f81ef7bcf6c9e2a4908352",
          "byte_length": 17660
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
        "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
        "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
        "version_id": "62db1631-6f51-4875-8441-2ac652807d73",
        "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
              "manifest_sha256": null,
              "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "parse_id": null,
              "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
              "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
              "version_id": "62db1631-6f51-4875-8441-2ac652807d73"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
              "manifest_sha256": null,
              "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
              "parse_id": null,
              "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
              "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
              "version_id": "62db1631-6f51-4875-8441-2ac652807d73"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 285,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 286,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 285,
            "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
            "excerpt_start_byte": 0,
            "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 206,
            "quote": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 94
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 285,
              "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
              "excerpt_start_byte": 0,
              "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "温度 30 ℃",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度30℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 30 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 286,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 30 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "762fb4d062876b5076e43b01507ef0d4dfbcb9cbd8db1dcb77c6e36fa6d4ea32",
          "byte_length": 3178
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "6b21d7862cda43f8b0ed45b420e8181fbdb346ccb77ff0e227a1df0a55c4a962",
          "byte_length": 12760
        },
        "review-original.json": {
          "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "8c8e4f3fbaef68574491d3eca861b9c2d3fb7bd4edfee2fd9c54d9cb9f95cd0e",
          "byte_length": 1178
        },
        "verification.json": {
          "sha256": "63854f20d0314c05330c52b091e6e000a8b30f22d66028838d93e862738413a9",
          "byte_length": 17235
        },
        "verification.md": {
          "sha256": "1525a8f0433809593b6bb63120355f32a16895926511ec58936e6ee14bf1fe40",
          "byte_length": 17669
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2024"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 206,
        "quote": "适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "1fe6dcc3588adb0a02e23dfb1b14cae10a4bc68518ccba7a1c59b92c5cb6f25d"
      },
      "occurrence_id": "occ-3e470c4e4c45bb2dbf54d6d7a0106cfe62666bf0c5f0e72ab6fe1905eb63dd38",
      "input_id": "b",
      "binding": {
        "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
        "import_id": "e5771d5c-e401-42cc-97c6-12a5e4e946e7",
        "source_id": "ec7895d6-ae3b-45c5-90e7-2a38bc791742",
        "version_id": "62db1631-6f51-4875-8441-2ac652807d73",
        "content_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "normalized_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "2cd3a255-3140-4d19-8403-369b22d8ea6c",
          "ordinal": 0,
          "resource_sha256": "711ee3937e38d1ae603c0ef4eb7d0e3967a20e9bb32d4b9fdc8adc2ec298b757"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 286,
        "text": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 30 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 30 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 285,
          "excerpt_sha256": "4fc9c08ad9a05362d8da309c9007e749f05289e9ddee6bd8be7af9f7ac69b393",
          "quote": "公开自造资料 combined_context/b。\n适用条件：已列明；观点时间：2024年。\n样例 A 的速度为 12 m/s，条件为温度 30 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 30 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 41,
        "end_byte": 205,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "8a89896e7152f7bffcb7e7e8bf725ba75e50066ac3d01889035e001ab5c64474"
      },
      "occurrence_id": "occ-cfe78c0d4713809fd485a807998df76c9ce7a1f92fef0cfb6dbb2392f40b9ae1",
      "input_id": "a",
      "binding": {
        "project_id": "2f87b851-d3c1-466e-b1e3-3f13b588346a",
        "import_id": "8745afb4-a792-45e3-a4b9-059d8701b933",
        "source_id": "1be6e779-5276-4701-bedc-c71b2dbcceec",
        "version_id": "3e42ba28-5272-4938-9868-a02f9202365a",
        "content_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "normalized_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "07254308-124b-4330-bc0e-09b98cfc853c",
          "ordinal": 0,
          "resource_sha256": "64db59c441e8212ba9804bc35c4cadcf0177b1cb0ed514043ea56378ea609515"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 285,
        "text": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "8",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 284,
          "excerpt_sha256": "0f6603d227f82cc21db3984395af4897171a8045f038bfcdff3623cc1c741a04",
          "quote": "公开自造资料 combined_context/a。\n适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 8 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n本材料只用于工程结构与出处核对，不代表真实科学结论。"
        }
      ],
      "canonical_concept_ids": [
        "00000000-0000-4000-8000-000000000001",
        "00000000-0000-4000-8000-000000000002"
      ],
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value": "8",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2024"
      },
      "fact_id": "fact-v2-08b51ab24bb2ec1be6823093943d2b7568cd7b139692e8f22bf79f8a263d7015",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度30℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-3e470c4e4c45bb2dbf54d6d7a0106cfe62666bf0c5f0e72ab6fe1905eb63dd38"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v2-ba35d67b14cfc1f61e6c887f9562d1e929e19fba5da58533a169a426236dc4aa",
      "object_id": "00000000-0000-4000-8000-000000000001",
      "property_id": "00000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "8",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-cfe78c0d4713809fd485a807998df76c9ce7a1f92fef0cfb6dbb2392f40b9ae1"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-3e470c4e4c45bb2dbf54d6d7a0106cfe62666bf0c5f0e72ab6fe1905eb63dd38",
      "right_occurrence_id": "occ-cfe78c0d4713809fd485a807998df76c9ce7a1f92fef0cfb6dbb2392f40b9ae1",
      "relation": "condition_variant",
      "issue_code": null
    }
  ],
  "totals": {
    "condition_variants": 1,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "2a50a09a3b9033209d4bf6f401a186e580ae642a29da399d8d666f07ca2d94be",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "14e4d640ed6efe06ab3ec8a48d2fcad74535efe9a55950ccae0600a5b520ca62",
      "byte_length": 41236
    },
    "coordination-original.json": {
      "sha256": "32ffd605ce4b033d6970011436584338f1f5880f022cde80547b2c4ea06a5e34",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "895a85645a1d0b1a27d10ca2ba23c33ee6228603c58a716335f847e2299294c6",
      "byte_length": 1908
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "d8c6780134af92945695c0660451be727c6b51d75d9c4e0320894209b43348b2",
      "byte_length": 3175
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "9b869a41134df7558b914dd69c3c54c65a77067f64617ebe39cab1e001716900",
      "byte_length": 743
    },
    "input-a--knowledge-ir.json": {
      "sha256": "03a5bbb46388d36acbd85885f29e2a51f20700f9b5853b4887ea411ccf9763f6",
      "byte_length": 12749
    },
    "input-a--review-original.json": {
      "sha256": "236a59d7ade6697b41edf5681f7be705236fc7874b2e36f956e03d280643a45c",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "434151c1ec2e2cedee2fcb86e8566be86e37c2c061ab612b451c8a248d205066",
      "byte_length": 1177
    },
    "input-a--verification.json": {
      "sha256": "7474e11605ca9d5016e8d3fbbccddc11b1a5c062f241c634c4f6242a33e2b321",
      "byte_length": 17226
    },
    "input-a--verification.md": {
      "sha256": "3a26aa9305028a782fbd63d9fa30f2bb589353ac95f81ef7bcf6c9e2a4908352",
      "byte_length": 17660
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "762fb4d062876b5076e43b01507ef0d4dfbcb9cbd8db1dcb77c6e36fa6d4ea32",
      "byte_length": 3178
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "8f3d4a90bbaab6135c15bf6daeb5e62ebda9ef1e0bb62245ca7ad6a3b690a3d2",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "6b21d7862cda43f8b0ed45b420e8181fbdb346ccb77ff0e227a1df0a55c4a962",
      "byte_length": 12760
    },
    "input-b--review-original.json": {
      "sha256": "f41622e14becfda0573129e666e0dac4d2a5ab0cf8100ebab2d085ec82659584",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "8c8e4f3fbaef68574491d3eca861b9c2d3fb7bd4edfee2fd9c54d9cb9f95cd0e",
      "byte_length": 1178
    },
    "input-b--verification.json": {
      "sha256": "63854f20d0314c05330c52b091e6e000a8b30f22d66028838d93e862738413a9",
      "byte_length": 17235
    },
    "input-b--verification.md": {
      "sha256": "1525a8f0433809593b6bb63120355f32a16895926511ec58936e6ee14bf1fe40",
      "byte_length": 17669
    }
  }
}
```
