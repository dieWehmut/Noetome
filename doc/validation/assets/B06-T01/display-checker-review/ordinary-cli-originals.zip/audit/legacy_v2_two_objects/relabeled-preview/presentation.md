# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "46e9ac35-419d-41cd-a842-e3933f5a4033",
  "project_id": "e01eb2a8-d3b5-4eeb-a23d-149d7bee4eba",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "b17145681b3c01c264dd43a950505d1207cfbde04e2bd71bafaa3924579a1549",
    "byte_length": 40517
  },
  "plan_fingerprint": {
    "sha256": "815355f7675f9ec689592a2adc968c5e3765685a6cf6de404bae038f53a00591",
    "byte_length": 17654
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "b17145681b3c01c264dd43a950505d1207cfbde04e2bd71bafaa3924579a1549",
      "byte_length": 40517
    },
    ".coordination-owner.json": {
      "sha256": "56a60be8959c970025bfff0adee61019edaeacca8755ba23fad947a5da029ae3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "963ab9a2cb54d4b00aeace5c98ca434383f7c40796de95c286c258ca8494bccf",
      "byte_length": 43988
    },
    ".coordination-report.md": {
      "sha256": "8a27224634364562c263a6729303ebf819cda687e07139ee5a2db94fca42cc0a",
      "byte_length": 44394
    },
    ".identity-original.json": {
      "sha256": "f0b8eea833ba5011cc6cdfc7851c863828ee9153267a97072894ce0a38257209",
      "byte_length": 2033
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e82ab1d4c106a09680dce5049b3172a1fec40913b986e0a164f34a65ad587e47",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "c03ad2f4fb89a5af73dfa20abe69021eb3599c4cc3423d65a617c1078168ad45",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f2178e5078b4788c18e5439f978bb4209005c7837c7e48c6f71827ca7d1a64fb",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "0f2f76a00c57b5316ae585a66b015689ac8a7e78b0dddb6da00d67baa0c207ea",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e470f2bfc8e34b7e16ee45c7f20f31a9442aabf2034027b0cf75199d10444cb5",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "bd1b1f20a8be5529baffd2a3740316bfe48d7870408a9788e320120fb78b8ff2",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "8aca8be0e7517baa58f51df6bb73c1bd24015c928f77d34a5a51ed67fba160d2",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9b014709341c0876015cade19bc339ffe6ec564b797534e434954e4d179883c2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "d0c07759e15b6d758e058efb0dfe6241b3001b2e1b3f5198f363dacf347d3a57",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "21c41636405e0849e9e8f29a31b9099bce590793f98508eed23fe3ac4c7ec740",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "4940c718e91ff775dee9f1696c5b9dfbe6b38b828f0f6c08b37fce3acdaa5f59",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c1eacd13b327675c2ad5d5340af6b854f184bfa4aa1bec8712db428ae4fc0813",
      "byte_length": 563,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2d153ff5ecec3a6ea8fb7465c7ff1875763398a114e9d9bb79f9e80afc306284",
            "occ-fc8d1d315b9832d0006cfe570f5386bcbc81cd14fdaed39af0da2bb6bac363d3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2d153ff5ecec3a6ea8fb7465c7ff1875763398a114e9d9bb79f9e80afc306284"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-2d153ff5ecec3a6ea8fb7465c7ff1875763398a114e9d9bb79f9e80afc306284"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 322
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-fc8d1d315b9832d0006cfe570f5386bcbc81cd14fdaed39af0da2bb6bac363d3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 327,
          "end_byte": 335
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-fc8d1d315b9832d0006cfe570f5386bcbc81cd14fdaed39af0da2bb6bac363d3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 413,
          "end_byte": 559
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 336,
          "end_byte": 410
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a3bf6c600a24263621766e312e354c3347575619485a53d788c03f1229f6fafc",
      "byte_length": 371,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-2d153ff5ecec3a6ea8fb7465c7ff1875763398a114e9d9bb79f9e80afc306284"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 369
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-fc8d1d315b9832d0006cfe570f5386bcbc81cd14fdaed39af0da2bb6bac363d3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "b17145681b3c01c264dd43a950505d1207cfbde04e2bd71bafaa3924579a1549",
      "byte_length": 40517
    },
    ".coordination-owner.json": {
      "sha256": "56a60be8959c970025bfff0adee61019edaeacca8755ba23fad947a5da029ae3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "963ab9a2cb54d4b00aeace5c98ca434383f7c40796de95c286c258ca8494bccf",
      "byte_length": 43988
    },
    ".coordination-report.md": {
      "sha256": "8a27224634364562c263a6729303ebf819cda687e07139ee5a2db94fca42cc0a",
      "byte_length": 44394
    },
    ".identity-original.json": {
      "sha256": "f0b8eea833ba5011cc6cdfc7851c863828ee9153267a97072894ce0a38257209",
      "byte_length": 2033
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e82ab1d4c106a09680dce5049b3172a1fec40913b986e0a164f34a65ad587e47",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "c03ad2f4fb89a5af73dfa20abe69021eb3599c4cc3423d65a617c1078168ad45",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f2178e5078b4788c18e5439f978bb4209005c7837c7e48c6f71827ca7d1a64fb",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "0f2f76a00c57b5316ae585a66b015689ac8a7e78b0dddb6da00d67baa0c207ea",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e470f2bfc8e34b7e16ee45c7f20f31a9442aabf2034027b0cf75199d10444cb5",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "bd1b1f20a8be5529baffd2a3740316bfe48d7870408a9788e320120fb78b8ff2",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "8aca8be0e7517baa58f51df6bb73c1bd24015c928f77d34a5a51ed67fba160d2",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9b014709341c0876015cade19bc339ffe6ec564b797534e434954e4d179883c2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "d0c07759e15b6d758e058efb0dfe6241b3001b2e1b3f5198f363dacf347d3a57",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "21c41636405e0849e9e8f29a31b9099bce590793f98508eed23fe3ac4c7ec740",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "759d5956525e9babe143642464da07b8c48bad113f6e6e6e153df86ae6b2f855",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "4940c718e91ff775dee9f1696c5b9dfbe6b38b828f0f6c08b37fce3acdaa5f59",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "815355f7675f9ec689592a2adc968c5e3765685a6cf6de404bae038f53a00591",
      "byte_length": 17654
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a3bf6c600a24263621766e312e354c3347575619485a53d788c03f1229f6fafc",
      "byte_length": 371
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "c1eacd13b327675c2ad5d5340af6b854f184bfa4aa1bec8712db428ae4fc0813",
      "byte_length": 563
    }
  }
}
```
