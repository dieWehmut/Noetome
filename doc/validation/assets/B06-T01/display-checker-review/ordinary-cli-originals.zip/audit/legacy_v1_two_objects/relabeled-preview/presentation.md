# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "82da9460-9d92-44db-98a6-669c66edd2d0",
  "project_id": "c6d53cf5-a3e1-4a9c-b874-f67687f42d2e",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "5989fcf9a20f3f5cc1c9ee6bdf06f020c054459da686f1b5982323295b9e66fc",
    "byte_length": 38377
  },
  "plan_fingerprint": {
    "sha256": "9ade010599ae59b22663548cda0838f251e1a9f86760856b41b1dd09a74881a2",
    "byte_length": 16870
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "5989fcf9a20f3f5cc1c9ee6bdf06f020c054459da686f1b5982323295b9e66fc",
      "byte_length": 38377
    },
    ".coordination-owner.json": {
      "sha256": "ec57280c2d7ebba8cc62e5b80b0524416da8fe1e737ed1211ea228d9b8b0fe5a",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "082d7f829d38fef9fda6622773c9aa893cc6c41d1ae06eb377180ab795339cd2",
      "byte_length": 41848
    },
    ".coordination-report.md": {
      "sha256": "60db22e9f3fb11dab87c5b27fc430a61162b7fbbb116dcf4e68d1655454b13b9",
      "byte_length": 42163
    },
    ".identity-original.json": {
      "sha256": "cdd45387e0195e65000d8489ebe51a86a7212350cd27f179a2ca6f4679d35dba",
      "byte_length": 1454
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "41b465718cb5408d78c55fc64241e3389d655d692cd90590a9c791ebf39daeac",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "bb919ed430d82db98fbef0ca651c1ca90fc94b33e9e41b2bce4bcfd3691a74ff",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "6be83b9f99f00507278551e4c47b66c6eac207c2ed098668e95fcaf23fcc5285",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "047ad6f31a0d206b901b3f949ea187cea1a47f865017d42b84e9b9a26e682dec",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "ac2a28bef410b9b1eca9ac8b8b3d3ac4390b9d210569769ef15a6be2d8a477d9",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "5f9e101f726adfeaa81d02fdbfd93da7463f4fb482b94ddef9335d73d7d4f26c",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "61ea47b80c9d267a104be620b587bb4df3cf09e434eaf8b3df4c70797363766e",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "51babc1eed108f413a45e47ff0abe91b0fe622c88728d22383f5c77de486427c",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "e30d87d4e51188d3a2a8598a2ebba37bea4cab6126d05eecd9014d3c5a5456f4",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "9e3d6a9254a2b157eed71117cee4e96404394952cef88a1da092cfa68cde2dab",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "1209a49c2ead90abe5568e35f324763f9b2d358d26ec8a756497479541a5bf90",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "2e384235aadf1ff97ce455dc5d9df0821175c60e1281721fa530753c90018fda",
      "byte_length": 615,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-28626ec31a347ab80a0bf4a4e5c62dfbd9202dc5a3f2c64054b065ead4978775",
            "occ-92cec50caf092ef34c16be816f854e97adc5110e1ab140b7c62e819ed0ab9516"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-28626ec31a347ab80a0bf4a4e5c62dfbd9202dc5a3f2c64054b065ead4978775"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-28626ec31a347ab80a0bf4a4e5c62dfbd9202dc5a3f2c64054b065ead4978775"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 348
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-92cec50caf092ef34c16be816f854e97adc5110e1ab140b7c62e819ed0ab9516"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 353,
          "end_byte": 361
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-92cec50caf092ef34c16be816f854e97adc5110e1ab140b7c62e819ed0ab9516"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 439,
          "end_byte": 611
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 362,
          "end_byte": 436
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "c4b9062a7faf7a6e233fb195f9e07ef1b94f6111743d2d19bf56f3ed53c10cda",
      "byte_length": 397,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-28626ec31a347ab80a0bf4a4e5c62dfbd9202dc5a3f2c64054b065ead4978775"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 395
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-92cec50caf092ef34c16be816f854e97adc5110e1ab140b7c62e819ed0ab9516"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "5989fcf9a20f3f5cc1c9ee6bdf06f020c054459da686f1b5982323295b9e66fc",
      "byte_length": 38377
    },
    ".coordination-owner.json": {
      "sha256": "ec57280c2d7ebba8cc62e5b80b0524416da8fe1e737ed1211ea228d9b8b0fe5a",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "082d7f829d38fef9fda6622773c9aa893cc6c41d1ae06eb377180ab795339cd2",
      "byte_length": 41848
    },
    ".coordination-report.md": {
      "sha256": "60db22e9f3fb11dab87c5b27fc430a61162b7fbbb116dcf4e68d1655454b13b9",
      "byte_length": 42163
    },
    ".identity-original.json": {
      "sha256": "cdd45387e0195e65000d8489ebe51a86a7212350cd27f179a2ca6f4679d35dba",
      "byte_length": 1454
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "41b465718cb5408d78c55fc64241e3389d655d692cd90590a9c791ebf39daeac",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "bb919ed430d82db98fbef0ca651c1ca90fc94b33e9e41b2bce4bcfd3691a74ff",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "6be83b9f99f00507278551e4c47b66c6eac207c2ed098668e95fcaf23fcc5285",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "047ad6f31a0d206b901b3f949ea187cea1a47f865017d42b84e9b9a26e682dec",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "ac2a28bef410b9b1eca9ac8b8b3d3ac4390b9d210569769ef15a6be2d8a477d9",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "5f9e101f726adfeaa81d02fdbfd93da7463f4fb482b94ddef9335d73d7d4f26c",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "61ea47b80c9d267a104be620b587bb4df3cf09e434eaf8b3df4c70797363766e",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "51babc1eed108f413a45e47ff0abe91b0fe622c88728d22383f5c77de486427c",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "e30d87d4e51188d3a2a8598a2ebba37bea4cab6126d05eecd9014d3c5a5456f4",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "9e3d6a9254a2b157eed71117cee4e96404394952cef88a1da092cfa68cde2dab",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "2c45a15fa2357396082904250b6c1fd80d960af50e79ba5188fe21ed3236c30a",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "1209a49c2ead90abe5568e35f324763f9b2d358d26ec8a756497479541a5bf90",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "9ade010599ae59b22663548cda0838f251e1a9f86760856b41b1dd09a74881a2",
      "byte_length": 16870
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "c4b9062a7faf7a6e233fb195f9e07ef1b94f6111743d2d19bf56f3ed53c10cda",
      "byte_length": 397
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "2e384235aadf1ff97ce455dc5d9df0821175c60e1281721fa530753c90018fda",
      "byte_length": 615
    }
  }
}
```
