# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "30f9c671-3481-4daa-bad0-e05b77ca95cd",
  "project_id": "d75aed50-9408-4acb-9b16-27d2ba4c7c7a",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "0d48bf3b6dc7ae546d0e0e5d83a91c4fe8b6826bb6a94b938c7c84cb18575d8e",
    "byte_length": 41337
  },
  "plan_fingerprint": {
    "sha256": "d4c29815ab838cf0861d71ad7eb84d91c388ae09f4cb133c917946adbe754bc9",
    "byte_length": 17223
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "0d48bf3b6dc7ae546d0e0e5d83a91c4fe8b6826bb6a94b938c7c84cb18575d8e",
      "byte_length": 41337
    },
    ".coordination-owner.json": {
      "sha256": "28accc982f0485a939f75c7aee66dd45c3b5e7d5a42ffa704edb884ac4e427f3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ac75eb38a203a740145b15cbda3bf94a2d76a34c4b5a1ded5ddb3223a642c535",
      "byte_length": 44808
    },
    ".coordination-report.md": {
      "sha256": "71c97522853d91f5ff8daa380ca16479e2011cccd88e13d016c3c688bcb80e44",
      "byte_length": 45283
    },
    ".identity-original.json": {
      "sha256": "fa53fd3df5076b17dc0c175e973142eba502e9ff2c8169e50bd562fb57d1a068",
      "byte_length": 2034
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "589c810329b579522996df58d47317b5d72608edb101337af7c64cba917b54d2",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a201e6d0e6ec7a7bb31dafa1ff67993f8867c413d199eba29a0d9889f43011d6",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "120bee9567c5c1990959cef6337ad9dea6c5c6bfd57f2906451e2efef0ad589a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "de636054ba12f1aa749e1d1282e5a56fd1653c693c91c5e3ef63f627678c6cb5",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "671fba96450d1a3383fb97afb0d18339f95d08fc55ab335298427570e436bd5e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "95b1e413e60cbd83b4733b5a1d6a2d267ce4a9c9b20123e52439d1c1066a6e53",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "778e75c3f40fa5fa577e10f45e3760885f16d9fdcb61dfeb77daec111b66fd36",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "db548ec5256ca53a0d599426fa96d57640f74aaf8bb555b152cc58fc83927a67",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "247303d247a410855f12e3f29b5a368cc7cf4124ccdf2220f69600c86a1e1980",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "47789a240155886cdbfd38985a58d1998342c22cc70bdb8d5b2332dc54b10cb0",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "6d202f0fed9c3767ce6e41e98a9facb184b683ee1f3001f68c285bd9f9d7aa9d",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "3cdc2920ec68a87212a059f8e232b8c25747629c72d4ad1f407fb31a4ed2c6dc",
      "byte_length": 563,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-a29ff310c89e02ddb285dc31d813beb6c1d7c3cbf901c40e59a95b16bb1da30d",
            "occ-dfe20bfa3f7e75281468e8357a9aa69d7c219ff3f5ebb51f25301f0d31da9cc1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-a29ff310c89e02ddb285dc31d813beb6c1d7c3cbf901c40e59a95b16bb1da30d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-a29ff310c89e02ddb285dc31d813beb6c1d7c3cbf901c40e59a95b16bb1da30d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 322
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-dfe20bfa3f7e75281468e8357a9aa69d7c219ff3f5ebb51f25301f0d31da9cc1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 327,
          "end_byte": 335
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-dfe20bfa3f7e75281468e8357a9aa69d7c219ff3f5ebb51f25301f0d31da9cc1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 413,
          "end_byte": 559
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 336,
          "end_byte": 410
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "dcc2166c25fcd28e00955c5bb43d8b7ca09dc384c136bbb55666dfda9b7a8a95",
      "byte_length": 371,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-a29ff310c89e02ddb285dc31d813beb6c1d7c3cbf901c40e59a95b16bb1da30d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 369
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-dfe20bfa3f7e75281468e8357a9aa69d7c219ff3f5ebb51f25301f0d31da9cc1"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "0d48bf3b6dc7ae546d0e0e5d83a91c4fe8b6826bb6a94b938c7c84cb18575d8e",
      "byte_length": 41337
    },
    ".coordination-owner.json": {
      "sha256": "28accc982f0485a939f75c7aee66dd45c3b5e7d5a42ffa704edb884ac4e427f3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ac75eb38a203a740145b15cbda3bf94a2d76a34c4b5a1ded5ddb3223a642c535",
      "byte_length": 44808
    },
    ".coordination-report.md": {
      "sha256": "71c97522853d91f5ff8daa380ca16479e2011cccd88e13d016c3c688bcb80e44",
      "byte_length": 45283
    },
    ".identity-original.json": {
      "sha256": "fa53fd3df5076b17dc0c175e973142eba502e9ff2c8169e50bd562fb57d1a068",
      "byte_length": 2034
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "589c810329b579522996df58d47317b5d72608edb101337af7c64cba917b54d2",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a201e6d0e6ec7a7bb31dafa1ff67993f8867c413d199eba29a0d9889f43011d6",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "120bee9567c5c1990959cef6337ad9dea6c5c6bfd57f2906451e2efef0ad589a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "de636054ba12f1aa749e1d1282e5a56fd1653c693c91c5e3ef63f627678c6cb5",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "671fba96450d1a3383fb97afb0d18339f95d08fc55ab335298427570e436bd5e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "95b1e413e60cbd83b4733b5a1d6a2d267ce4a9c9b20123e52439d1c1066a6e53",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "778e75c3f40fa5fa577e10f45e3760885f16d9fdcb61dfeb77daec111b66fd36",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "db548ec5256ca53a0d599426fa96d57640f74aaf8bb555b152cc58fc83927a67",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "247303d247a410855f12e3f29b5a368cc7cf4124ccdf2220f69600c86a1e1980",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "47789a240155886cdbfd38985a58d1998342c22cc70bdb8d5b2332dc54b10cb0",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "db65d3443922458c5ca236d60ccf6c5e4f5fddf5cfb0a5e17959a6b6acb6b7f2",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "6d202f0fed9c3767ce6e41e98a9facb184b683ee1f3001f68c285bd9f9d7aa9d",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "d4c29815ab838cf0861d71ad7eb84d91c388ae09f4cb133c917946adbe754bc9",
      "byte_length": 17223
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "dcc2166c25fcd28e00955c5bb43d8b7ca09dc384c136bbb55666dfda9b7a8a95",
      "byte_length": 371
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "3cdc2920ec68a87212a059f8e232b8c25747629c72d4ad1f407fb31a4ed2c6dc",
      "byte_length": 563
    }
  }
}
```
