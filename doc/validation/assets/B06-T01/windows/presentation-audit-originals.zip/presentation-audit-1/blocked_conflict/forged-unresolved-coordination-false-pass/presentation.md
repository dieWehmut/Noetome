# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "3afc4b51-9728-4ae9-952c-a2d0919bc05a",
  "project_id": "b8643bf0-461a-4f4a-a3eb-80c0fbae79f3",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 1,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "3f9c3e928ddb04e9de80bc730f7f8fa4f4c979e4dff99d48fdbaa1a63c8294b0",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3ff7443fc4040729daa12d63034c943c742906cda5dabb306cdec6926a0c6fac",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "f61e8d5695ac32bdb7995dbeb41d4a20d9780c245edd9e769c055db077e3592c",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "7599caf35010c456c17bf5c3d02008ceaa702d7b0660baa0afbcff8a51a85132",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "87a2f0ffbee20af8b34536c2291e42807ad25bf67f49a8e238e3344a83d73587",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "065f095a8ed4f330409c95210bcb7118fd2101660d576993f79dc9855d9951ae",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "28bd1444ae5888879f902f146199891e5808b37eead99c24729b37f525612862",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "60a891d950306f4353b7b2ad918ed5efa7f02647c773d149ecbc50786ae34291",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "ba3db7487a57fcd1c6527a1f20d8422c76399633c8ab44ad7e4c16e923325109",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "7a68a97ad1a4a13113c34cc82c9e9381689eed7cd053bc498fd1d09e10d5fd6a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "71d619a2add8fc2f865d2d90bfbf441aa3d728a658cebb1a4a682d3bbc37982f",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "e087221ee18060c11ea272edf52d67a38981954d7d70ffd2825eda1a17596b1f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "b56baa147246a47b3d3c29dcce1a0c543be7cad75296a67259fef92306503ad2",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "567db2365e6f9eddd4d8967b6fb0129defe41bd9ab5427f213f6fa59bfcc547c",
      "byte_length": 4330
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "3f9c3e928ddb04e9de80bc730f7f8fa4f4c979e4dff99d48fdbaa1a63c8294b0",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3ff7443fc4040729daa12d63034c943c742906cda5dabb306cdec6926a0c6fac",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "f61e8d5695ac32bdb7995dbeb41d4a20d9780c245edd9e769c055db077e3592c",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "7599caf35010c456c17bf5c3d02008ceaa702d7b0660baa0afbcff8a51a85132",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "87a2f0ffbee20af8b34536c2291e42807ad25bf67f49a8e238e3344a83d73587",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "065f095a8ed4f330409c95210bcb7118fd2101660d576993f79dc9855d9951ae",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "28bd1444ae5888879f902f146199891e5808b37eead99c24729b37f525612862",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "60a891d950306f4353b7b2ad918ed5efa7f02647c773d149ecbc50786ae34291",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "ba3db7487a57fcd1c6527a1f20d8422c76399633c8ab44ad7e4c16e923325109",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "7a68a97ad1a4a13113c34cc82c9e9381689eed7cd053bc498fd1d09e10d5fd6a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "71d619a2add8fc2f865d2d90bfbf441aa3d728a658cebb1a4a682d3bbc37982f",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "e087221ee18060c11ea272edf52d67a38981954d7d70ffd2825eda1a17596b1f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "b56baa147246a47b3d3c29dcce1a0c543be7cad75296a67259fef92306503ad2",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "b8f968bd0d1e4cadf5ad29a178666fb5b75b09f48f11c02372e0b832113851cd",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "567db2365e6f9eddd4d8967b6fb0129defe41bd9ab5427f213f6fa59bfcc547c",
      "byte_length": 4330
    }
  }
}
```
