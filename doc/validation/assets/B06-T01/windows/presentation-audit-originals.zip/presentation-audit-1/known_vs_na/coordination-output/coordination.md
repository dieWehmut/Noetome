# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：1；条件未知：0；条件不适用：1；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "0a0c0e4d-71f9-4e27-b1f4-939cf5ff8148",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
        "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
        "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
        "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e",
        "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
              "manifest_sha256": null,
              "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "parse_id": null,
              "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
              "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
              "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
              "manifest_sha256": null,
              "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "parse_id": null,
              "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
              "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
              "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "17589a7317c4344a0ab19a69b62046c19f69ef8187894dab4ab5d8f62a6cb5a0",
          "byte_length": 2714
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "50122f87d73d72be7f3adb04349d16f55229eea556b5c0a9109a74d38b019723",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "8de9148b15cc53d5964bcac27be7ca6fd71f509356c9cc2b10c6159d1709e6ca",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "e8e395a3b49f79f644e56d01aa01a9924c451bb7e8f9befbd6f6a71a1bb3dc37",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "e688d148ca645f62d4be187b5d5123860ba82977eb5fe1ed6b276ae99c8dae39",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
        "import_id": "530c7d5d-7281-43e6-9810-0189c92cfb2e",
        "source_id": "65263850-a1f3-44f5-8544-f0b08970c425",
        "version_id": "0c4e1113-5e23-408c-936d-4e54929e6df6",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "530c7d5d-7281-43e6-9810-0189c92cfb2e",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
              "source_id": "65263850-a1f3-44f5-8544-f0b08970c425",
              "version_id": "0c4e1113-5e23-408c-936d-4e54929e6df6"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "530c7d5d-7281-43e6-9810-0189c92cfb2e",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
              "source_id": "65263850-a1f3-44f5-8544-f0b08970c425",
              "version_id": "0c4e1113-5e23-408c-936d-4e54929e6df6"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 B",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "581b5c1c6cfb7dbc626f25cef25e84e02f6e286fa29252ed1b52ada88b6c3859",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "62eadbaa197412c1de5e849e94e6b906cf1598abca8924ad40f648777c1aa24b",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "32ebb0d809afb1864d685cc258ed2075cfe5b134be504bf9066e062d32406952",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "52251a5b21345c85fa1f603847d19f851cfefff2a5da3c4967f12d8ca17034e5",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "10855794ff838e73000b4c3637a621efa5b2aba7bae50cc87649ac10a7975761",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e"
      },
      "occurrence_id": "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931",
      "input_id": "a",
      "binding": {
        "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
        "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
        "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
        "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e",
        "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "554dc7d2-60ac-4350-99c1-bf9cbb434ad5",
          "ordinal": 0,
          "resource_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137"
      },
      "occurrence_id": "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0",
      "input_id": "b",
      "binding": {
        "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
        "import_id": "530c7d5d-7281-43e6-9810-0189c92cfb2e",
        "source_id": "65263850-a1f3-44f5-8544-f0b08970c425",
        "version_id": "0c4e1113-5e23-408c-936d-4e54929e6df6",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "54e5b449-bf61-4478-9ab3-736f3bf45288",
          "ordinal": 0,
          "resource_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 B"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 B"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例B",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931",
      "right_occurrence_id": "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 1,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "e267485630039514900bb70e3a77f3314ad05b308f9e3a9b327090e0ebd509f9",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "0c300e3d6abd1766839940e18b9a38f497945d01a1bba9710d9df2af0048aaa9",
      "byte_length": 37417
    },
    "coordination-original.json": {
      "sha256": "9f35b8f258c1c788f938e3d9a04200c8d24b90057996ff86e795a941b69dc6b6",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "17589a7317c4344a0ab19a69b62046c19f69ef8187894dab4ab5d8f62a6cb5a0",
      "byte_length": 2714
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "50122f87d73d72be7f3adb04349d16f55229eea556b5c0a9109a74d38b019723",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "8de9148b15cc53d5964bcac27be7ca6fd71f509356c9cc2b10c6159d1709e6ca",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "e8e395a3b49f79f644e56d01aa01a9924c451bb7e8f9befbd6f6a71a1bb3dc37",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "e688d148ca645f62d4be187b5d5123860ba82977eb5fe1ed6b276ae99c8dae39",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "581b5c1c6cfb7dbc626f25cef25e84e02f6e286fa29252ed1b52ada88b6c3859",
      "byte_length": 3057
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "62eadbaa197412c1de5e849e94e6b906cf1598abca8924ad40f648777c1aa24b",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "32ebb0d809afb1864d685cc258ed2075cfe5b134be504bf9066e062d32406952",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "52251a5b21345c85fa1f603847d19f851cfefff2a5da3c4967f12d8ca17034e5",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "10855794ff838e73000b4c3637a621efa5b2aba7bae50cc87649ac10a7975761",
      "byte_length": 17303
    }
  }
}
```
