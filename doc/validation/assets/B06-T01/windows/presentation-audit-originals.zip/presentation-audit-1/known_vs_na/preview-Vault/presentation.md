# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "7cf7ceac-fe6b-4542-8a21-a22ec7d44f8d",
  "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "0c300e3d6abd1766839940e18b9a38f497945d01a1bba9710d9df2af0048aaa9",
    "byte_length": 37417
  },
  "plan_fingerprint": {
    "sha256": "57e1f8eae7bd9f79f59ca47687ba3a59b6101573a105a332f3ef61479c7ead16",
    "byte_length": 16487
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "0c300e3d6abd1766839940e18b9a38f497945d01a1bba9710d9df2af0048aaa9",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "e267485630039514900bb70e3a77f3314ad05b308f9e3a9b327090e0ebd509f9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "b990b15bbeb6036dabf6376e623cca76915c32b50bcc2f2076be4eb252c2e2da",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "4e8127a7c6e308902743e236dd1a74cbf69fa19017527982d4e646f3aefd9fd1",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "17589a7317c4344a0ab19a69b62046c19f69ef8187894dab4ab5d8f62a6cb5a0",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "50122f87d73d72be7f3adb04349d16f55229eea556b5c0a9109a74d38b019723",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "8de9148b15cc53d5964bcac27be7ca6fd71f509356c9cc2b10c6159d1709e6ca",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "e8e395a3b49f79f644e56d01aa01a9924c451bb7e8f9befbd6f6a71a1bb3dc37",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "e688d148ca645f62d4be187b5d5123860ba82977eb5fe1ed6b276ae99c8dae39",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "581b5c1c6cfb7dbc626f25cef25e84e02f6e286fa29252ed1b52ada88b6c3859",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "62eadbaa197412c1de5e849e94e6b906cf1598abca8924ad40f648777c1aa24b",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "32ebb0d809afb1864d685cc258ed2075cfe5b134be504bf9066e062d32406952",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "52251a5b21345c85fa1f603847d19f851cfefff2a5da3c4967f12d8ca17034e5",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "10855794ff838e73000b4c3637a621efa5b2aba7bae50cc87649ac10a7975761",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "9f35b8f258c1c788f938e3d9a04200c8d24b90057996ff86e795a941b69dc6b6",
      "byte_length": 4328
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931",
            "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 262
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 267,
          "end_byte": 275
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 353,
          "end_byte": 499
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 276,
          "end_byte": 350
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-307d700f31b7a7a12e9aa9d198986815cf7892de714c5109d7e62d2174461931"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 207
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-7e7f3ba6efd667e26555906386a58b891caec0b8fa16828f888ec0ac5d6b1bc0"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "0c300e3d6abd1766839940e18b9a38f497945d01a1bba9710d9df2af0048aaa9",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "e267485630039514900bb70e3a77f3314ad05b308f9e3a9b327090e0ebd509f9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "b990b15bbeb6036dabf6376e623cca76915c32b50bcc2f2076be4eb252c2e2da",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "4e8127a7c6e308902743e236dd1a74cbf69fa19017527982d4e646f3aefd9fd1",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "17589a7317c4344a0ab19a69b62046c19f69ef8187894dab4ab5d8f62a6cb5a0",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "50122f87d73d72be7f3adb04349d16f55229eea556b5c0a9109a74d38b019723",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "8de9148b15cc53d5964bcac27be7ca6fd71f509356c9cc2b10c6159d1709e6ca",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "e8e395a3b49f79f644e56d01aa01a9924c451bb7e8f9befbd6f6a71a1bb3dc37",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "e688d148ca645f62d4be187b5d5123860ba82977eb5fe1ed6b276ae99c8dae39",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "581b5c1c6cfb7dbc626f25cef25e84e02f6e286fa29252ed1b52ada88b6c3859",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "62eadbaa197412c1de5e849e94e6b906cf1598abca8924ad40f648777c1aa24b",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "32ebb0d809afb1864d685cc258ed2075cfe5b134be504bf9066e062d32406952",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "52251a5b21345c85fa1f603847d19f851cfefff2a5da3c4967f12d8ca17034e5",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "10855794ff838e73000b4c3637a621efa5b2aba7bae50cc87649ac10a7975761",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "751189b4425734b0aaf40afe4d8bbf1cf1a9cfccca4b43f02060bef21c204ad0",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "9f35b8f258c1c788f938e3d9a04200c8d24b90057996ff86e795a941b69dc6b6",
      "byte_length": 4328
    },
    "plan.json": {
      "sha256": "57e1f8eae7bd9f79f59ca47687ba3a59b6101573a105a332f3ef61479c7ead16",
      "byte_length": 16487
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503
    }
  }
}
```
