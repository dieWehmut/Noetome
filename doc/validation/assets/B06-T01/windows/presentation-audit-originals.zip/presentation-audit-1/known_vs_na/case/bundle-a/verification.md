# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
      "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
      "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
      "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e",
      "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
      "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "554dc7d2-60ac-4350-99c1-bf9cbb434ad5",
          "ordinal": 0,
          "resource_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
    "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
    "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
    "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e",
    "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
    "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "17589a7317c4344a0ab19a69b62046c19f69ef8187894dab4ab5d8f62a6cb5a0",
        "byte_length": 2714
      },
      "decision.json": {
        "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
        "byte_length": 503
      },
      "review.json": {
        "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
        "byte_length": 510
      }
    },
    "gold_sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "a-speed"
        ],
        "decision": {
          "atom_ids": [
            "a-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
          "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
          "manifest_sha256": null,
          "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
          "parse_id": null,
          "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
          "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
          "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e"
        },
        "request_id": "synthetic-coordination-a"
      },
      "actual": {
        "binding": {
          "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
          "import_id": "166ec455-4f66-4627-8319-82ebfe10b41b",
          "manifest_sha256": null,
          "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
          "parse_id": null,
          "project_id": "1cd9892c-47cf-42ec-b3fe-ad52e72861d3",
          "source_id": "8f9af423-e0f5-4db6-b719-390326c62ba1",
          "version_id": "e34856f4-ab0c-48d9-aa6a-2d3a730a468e"
        },
        "request_id": "synthetic-coordination-a"
      }
    },
    {
      "category": "duplicate",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "a-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 84,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 85,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "a-support",
        "excerpt_end_byte": 84,
        "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
        "excerpt_start_byte": 0,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 84,
        "quote": "样例 A 的速度为 10 m/s。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "a-support",
          "excerpt_end_byte": 84,
          "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
          "excerpt_start_byte": 0,
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "速度"
        ],
        "compound": "样例 A 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "a-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "a-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的速度为 10 m/s。",
      "actual": "样例 A 的速度为 10 m/s。"
    },
    {
      "category": "fact",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "10",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "10",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "a-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "17589a7317c4344a0ab19a69b62046c19f69ef8187894dab4ab5d8f62a6cb5a0",
      "byte_length": 2714
    },
    "decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    "knowledge-ir.json": {
      "sha256": "50122f87d73d72be7f3adb04349d16f55229eea556b5c0a9109a74d38b019723",
      "byte_length": 9252
    },
    "review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "8de9148b15cc53d5964bcac27be7ca6fd71f509356c9cc2b10c6159d1709e6ca",
      "byte_length": 974
    }
  }
}
```
