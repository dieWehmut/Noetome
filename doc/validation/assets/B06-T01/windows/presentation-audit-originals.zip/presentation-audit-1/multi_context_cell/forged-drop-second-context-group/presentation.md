# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "c3f91ef1-783d-4b18-ac80-bf79cb002569",
  "project_id": "14f6c1dc-5e87-4a5d-ac82-681e54e6846d",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "fb0f98277cc324a8511acaf369f1d72889a4084ade33e1089a2b01518875b1c0",
    "byte_length": 61685
  },
  "plan_fingerprint": {
    "sha256": "c7f5d86627658c2f5ac011201624ce5ce3168aee5c2431088672e1997b08ffef",
    "byte_length": 22658
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "fb0f98277cc324a8511acaf369f1d72889a4084ade33e1089a2b01518875b1c0",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "179ae1e40e14d2298574f6c3e5ddce243bcfc25d24cd53cd44f2f5ff1c6f115f",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "76180d1026bf7254d4172672b9d3f84af23469f4033bbbd61d24fb1001d136f8",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "2db79f3718b5304ef11fc36dd403c546128d00210125f420f8e9cb2841d29c24",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "037592fe42cabf5c801a26bbd8334602197c8f9f7f46e1fbc50cb724684ebaae",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "74000b8cbb66e4c911605d21dd7945ff8ed125140e1891df9f677aff1c6e236c",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "ebfc77484a66bc42fd8396a0554a11fc655596165d42602f1f194dcdb0ebb0d3",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "323b5a1e665bd7b254019b1284bd829510cb03c7ee9b7e8f1b4d61f15d3fe592",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "0f57bd4c6dd5e22deeb922bc9680e7d24053fb73d5899f6c9add6402e7c81685",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6556fcd286ebd6741bb8139b5bcc4ff9dcc7037e3992ea002a383365be0ffba8",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "13f8ecb9c980d3982584be3d0848e9ec3b92d86d7092ef02cf6bea6cfbffc787",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c33e9c4ecf679121ff68e01a50d6708bad10bd00ae68ad41c63b59f6b049fc30",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "c160ecc29b8b539474e5d1becdd65098b6b1d236c87ff0712c52fe8cf6c05f45",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "a8202ad0b02374f5e5f013fa1c06e40e5740c002490edfa2fcf65fd125f68a9a",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "f701580382d04f140dba8cacba032452393517d1343a9e82aadc4c6e5c29779e",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "cff6772c828951fc5d41fc9dac7cb0ebc998c31bbd546d064a8b8b40712b424e",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "4dd8a3cd1d267d66f2583216598391887dfa146497526c9d9b69422502afe48f",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "a3881f00e1aa755b710d1bca3baea396b4bb4db266a2b170004bdd3dab1be15a",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "21cb55f2e3d329cac5c6fcd746952a8e8425198fb8b735b36b347f6dc582b072",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "91b3883e44bcd5cc4dd6814f4e973630f7e87494664a46320aba6b04a7044ced",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6fd68eef0ebc6f19c8112090ca224f58aa3561d36cb830b71660ce08b5e2dec3",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-3ace35dd6f212313021268c0e93d3c84cf9216a0d8a9a9de45b56280bbb4b391",
            "occ-5ff0083f2bb428bdf3adbfe2aa65104d3ae924f76a63a17e1da8e900217825a9",
            "occ-9048a967dc5630da86d480a3d251f2894c786e3981da1e6a95f44d752cd67e2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-5ff0083f2bb428bdf3adbfe2aa65104d3ae924f76a63a17e1da8e900217825a9",
            "occ-9048a967dc5630da86d480a3d251f2894c786e3981da1e6a95f44d752cd67e2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-9048a967dc5630da86d480a3d251f2894c786e3981da1e6a95f44d752cd67e2c",
            "occ-5ff0083f2bb428bdf3adbfe2aa65104d3ae924f76a63a17e1da8e900217825a9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-3ace35dd6f212313021268c0e93d3c84cf9216a0d8a9a9de45b56280bbb4b391"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-3ace35dd6f212313021268c0e93d3c84cf9216a0d8a9a9de45b56280bbb4b391"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-9048a967dc5630da86d480a3d251f2894c786e3981da1e6a95f44d752cd67e2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-5ff0083f2bb428bdf3adbfe2aa65104d3ae924f76a63a17e1da8e900217825a9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-3ace35dd6f212313021268c0e93d3c84cf9216a0d8a9a9de45b56280bbb4b391"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "fb0f98277cc324a8511acaf369f1d72889a4084ade33e1089a2b01518875b1c0",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "179ae1e40e14d2298574f6c3e5ddce243bcfc25d24cd53cd44f2f5ff1c6f115f",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "76180d1026bf7254d4172672b9d3f84af23469f4033bbbd61d24fb1001d136f8",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "2db79f3718b5304ef11fc36dd403c546128d00210125f420f8e9cb2841d29c24",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "037592fe42cabf5c801a26bbd8334602197c8f9f7f46e1fbc50cb724684ebaae",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "74000b8cbb66e4c911605d21dd7945ff8ed125140e1891df9f677aff1c6e236c",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "ebfc77484a66bc42fd8396a0554a11fc655596165d42602f1f194dcdb0ebb0d3",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "323b5a1e665bd7b254019b1284bd829510cb03c7ee9b7e8f1b4d61f15d3fe592",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "0f57bd4c6dd5e22deeb922bc9680e7d24053fb73d5899f6c9add6402e7c81685",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6556fcd286ebd6741bb8139b5bcc4ff9dcc7037e3992ea002a383365be0ffba8",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "13f8ecb9c980d3982584be3d0848e9ec3b92d86d7092ef02cf6bea6cfbffc787",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c33e9c4ecf679121ff68e01a50d6708bad10bd00ae68ad41c63b59f6b049fc30",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "c160ecc29b8b539474e5d1becdd65098b6b1d236c87ff0712c52fe8cf6c05f45",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "a8202ad0b02374f5e5f013fa1c06e40e5740c002490edfa2fcf65fd125f68a9a",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "f701580382d04f140dba8cacba032452393517d1343a9e82aadc4c6e5c29779e",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "cff6772c828951fc5d41fc9dac7cb0ebc998c31bbd546d064a8b8b40712b424e",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "4dd8a3cd1d267d66f2583216598391887dfa146497526c9d9b69422502afe48f",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "a3881f00e1aa755b710d1bca3baea396b4bb4db266a2b170004bdd3dab1be15a",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "21cb55f2e3d329cac5c6fcd746952a8e8425198fb8b735b36b347f6dc582b072",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "7b4912651adb2c58819735bb2fafc063152bad3f6e05ce2b817c7552e90fcf86",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "91b3883e44bcd5cc4dd6814f4e973630f7e87494664a46320aba6b04a7044ced",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "c7f5d86627658c2f5ac011201624ce5ce3168aee5c2431088672e1997b08ffef",
      "byte_length": 22658
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "6fd68eef0ebc6f19c8112090ca224f58aa3561d36cb830b71660ce08b5e2dec3",
      "byte_length": 542
    }
  }
}
```
