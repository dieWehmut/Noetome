# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "f7823371-0c07-45ab-97ca-b15e05467c67",
  "project_id": "e9d43aa0-60fd-4147-a85e-5e1def9a45c4",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 2,
    "source_occurrences": 3,
    "objects": 1,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 2,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SINGLE_OBJECT_TEXT",
    "reason": "选定事实仅涉及一个对象，以正文保留各属性、条件和原始表述。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "631c64c283b3fa9bef5dcc9c3dba710e6300b21c2fa5a845ec3d9de9a6056098",
    "byte_length": 60938
  },
  "plan_fingerprint": {
    "sha256": "c901b8504df73fe170ee10528f47c6397c45e64bed3805d76c2ccbd6f7682b88",
    "byte_length": 18202
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "631c64c283b3fa9bef5dcc9c3dba710e6300b21c2fa5a845ec3d9de9a6056098",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "28eb159d186afafb7970c4fcc74fc4ca5f0530f0a895d79d7f87c5fdefce83cf",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "b5188efc1793141a2661c8ec224b284ab34aa31178f7a99300547508f4c46ab5",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "768367c01b1bb020ec2dc2004154f859198e4e9b530a3a4b9b8794212d80c4ab",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "5c78185039b045774b10cbb66ea6cdbdbda3d30a62fd73abe20d50357664e410",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "07f5fd161a70cbe91b91dc41b4594d97ff3b3d211fbaad544947265dc2d010d4",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9dad98e6f138be61bd341d8c8b6af840e689dca1749fe040311481edbced2f3b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "5521c4dd352188604dd7fbe63c5f6f11d3cfa0d0750b1f2c96f03add50eb385e",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "b789de4b2b2c785f63e4b723c88289f88707856f9ffb5c15516dd33e729cb373",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "53c8bbbcbaa00ec4e8ccdb97a24fe7c4b9d381bfa91d947f0d619d81644eac3c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "cb2ad3e1e2a79b95dfe439a1b0560806a345da7c069d0a0f41d5471427741bb4",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "a24e159add37dad2748e1d0d22255f89caa0f9d12cc08166f6ba9feb131ba546",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b98591d399e1e5bac748e96876051ada77b5853d1f593a3f68f51e28ce0b6d83",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8f664e131a60c43fe88e4abdf8f3b927eb8395ddd670bf0b68ee96ee13ba8261",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "ba41a6078216aa4c1fce37972bdcdbb299a0f3049e078a5393d8c949324c6a09",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "010691718fa3056ce14f4254e64e1a8b687bd36345116dc923ebdd489850b6db",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "40faf081c3bc7de09b587814c1d6c77e70e8f8352d01d80c077364d4322882d2",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "56c349411eac8db474961789467ac2c999c7744d0e30c6edc6a43db72d4c0e26",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "830d2e2d67db25a83ed88dc273bb7a8b270ad39a792a1b58b77aece27fd36c80",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "8d1a575ae357750a8ef0d667b2cae6db913f1c8b742cf9a5fddda40c8da190a0",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-ade52e4df885b312cd69c6bc3c4b773f63ddd23f6dd4a4c60e91894caa40b28a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-cccf7be96c8e366f78d5ef66b4a713d20ec0026a70ffb6241efea9422156a228",
            "occ-e67d3ad8a628d0f49401feb25bc9fbcb341a69a33442dc01f762e9d0263ef54c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-ade52e4df885b312cd69c6bc3c4b773f63ddd23f6dd4a4c60e91894caa40b28a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-cccf7be96c8e366f78d5ef66b4a713d20ec0026a70ffb6241efea9422156a228",
            "occ-e67d3ad8a628d0f49401feb25bc9fbcb341a69a33442dc01f762e9d0263ef54c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "631c64c283b3fa9bef5dcc9c3dba710e6300b21c2fa5a845ec3d9de9a6056098",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "28eb159d186afafb7970c4fcc74fc4ca5f0530f0a895d79d7f87c5fdefce83cf",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "b5188efc1793141a2661c8ec224b284ab34aa31178f7a99300547508f4c46ab5",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "768367c01b1bb020ec2dc2004154f859198e4e9b530a3a4b9b8794212d80c4ab",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "5c78185039b045774b10cbb66ea6cdbdbda3d30a62fd73abe20d50357664e410",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "07f5fd161a70cbe91b91dc41b4594d97ff3b3d211fbaad544947265dc2d010d4",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9dad98e6f138be61bd341d8c8b6af840e689dca1749fe040311481edbced2f3b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "5521c4dd352188604dd7fbe63c5f6f11d3cfa0d0750b1f2c96f03add50eb385e",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "b789de4b2b2c785f63e4b723c88289f88707856f9ffb5c15516dd33e729cb373",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "53c8bbbcbaa00ec4e8ccdb97a24fe7c4b9d381bfa91d947f0d619d81644eac3c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "cb2ad3e1e2a79b95dfe439a1b0560806a345da7c069d0a0f41d5471427741bb4",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "a24e159add37dad2748e1d0d22255f89caa0f9d12cc08166f6ba9feb131ba546",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b98591d399e1e5bac748e96876051ada77b5853d1f593a3f68f51e28ce0b6d83",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8f664e131a60c43fe88e4abdf8f3b927eb8395ddd670bf0b68ee96ee13ba8261",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "ba41a6078216aa4c1fce37972bdcdbb299a0f3049e078a5393d8c949324c6a09",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "010691718fa3056ce14f4254e64e1a8b687bd36345116dc923ebdd489850b6db",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "40faf081c3bc7de09b587814c1d6c77e70e8f8352d01d80c077364d4322882d2",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "56c349411eac8db474961789467ac2c999c7744d0e30c6edc6a43db72d4c0e26",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "830d2e2d67db25a83ed88dc273bb7a8b270ad39a792a1b58b77aece27fd36c80",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "90c62022c0b9bec366af303d99766823e5785a2c1c51c8e762f75416533fb0f8",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "8d1a575ae357750a8ef0d667b2cae6db913f1c8b742cf9a5fddda40c8da190a0",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "c901b8504df73fe170ee10528f47c6397c45e64bed3805d76c2ccbd6f7682b88",
      "byte_length": 18202
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "知识比较.md": {
      "sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514
    }
  }
}
```
