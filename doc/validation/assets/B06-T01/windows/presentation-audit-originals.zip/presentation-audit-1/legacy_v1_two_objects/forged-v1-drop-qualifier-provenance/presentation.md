# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "05620f5c-6146-4a0a-b1e3-70aed0917320",
  "project_id": "43a4685f-2577-4e16-97ba-72b7a03701ba",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "2ea48b14ee4334f6fb5e40323a1c7cae1ef9b178e7f9a67e276104e66e7018a1",
    "byte_length": 38360
  },
  "plan_fingerprint": {
    "sha256": "e2eea6a59b18ed3eb6e0661cd3468bdedf6637adbbe35ad2dd3534365d7655c5",
    "byte_length": 16372
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "2ea48b14ee4334f6fb5e40323a1c7cae1ef9b178e7f9a67e276104e66e7018a1",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "8e0e4b6c9a66afb9fe44efde043f74910dc75dba5545f43ff41fbb1200a2e87a",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "a07f70a04d98aa6ba86e7dfe74152c47e12ed4d3e95b844de9e6ae369e857302",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "5ac747380695f71a82c3bc1f577a7f5dae04bca59aac12ad4591c1aae6f359b4",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f2e56407f31922b5f2d9a7c41f97d66129396f6656613b205e8b56bdc73edb5c",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "2d9337d9c7df99c4f0642e0e86499cf6e1b6caf6163b367cad5538600c1eb5b0",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "adb6735771e1b80303142a97809fa0e59fa8d306acc1c659144b3cc7786ad96a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "31383d7cb685a178d61a2631f3732f8ce8166bb1cf157b41aee0f8f338f5a78e",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "57dd843937cfe0a03ca2d4b79af06c0a57e959db8e6acae057dc1dfe4c83e193",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "23ce627a3e29871fdbe1e420bde450d93767ace9d86632e707e55e7687bb0422",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d395b2ce7058b74aea927e3bcb8e97ec3957f870cf731e64949d3605f71bd193",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0c1da88f44619d31a76232678dae3789c1c8113f0ffa65337700db9bec3b27e2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "adcc157e4eabd3a916ed8b7131958ef8581cf7e83a90d72d7edaf428fa6c11eb",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "700b3cb65504dd232e84320dd179b197c72e3655a341c89fa71d158599a37cf2",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "de240a1bebdcf380e2edbd970dba882558c464085764c3a4dbe949d53b24b8aa",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-1ef02dff92e8aeb0570e15feebf4d1b05b744dd61114b92a5ca91806e714d6fa",
            "occ-b33e3c8f4bf9cac10b69dc2b7c312c6e690eba9e64512c38437a31a8d8536a3f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-b33e3c8f4bf9cac10b69dc2b7c312c6e690eba9e64512c38437a31a8d8536a3f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-b33e3c8f4bf9cac10b69dc2b7c312c6e690eba9e64512c38437a31a8d8536a3f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-1ef02dff92e8aeb0570e15feebf4d1b05b744dd61114b92a5ca91806e714d6fa"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 332,
          "end_byte": 340
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-1ef02dff92e8aeb0570e15feebf4d1b05b744dd61114b92a5ca91806e714d6fa"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 418,
          "end_byte": 590
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 341,
          "end_byte": 415
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-b33e3c8f4bf9cac10b69dc2b7c312c6e690eba9e64512c38437a31a8d8536a3f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-1ef02dff92e8aeb0570e15feebf4d1b05b744dd61114b92a5ca91806e714d6fa"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "2ea48b14ee4334f6fb5e40323a1c7cae1ef9b178e7f9a67e276104e66e7018a1",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "8e0e4b6c9a66afb9fe44efde043f74910dc75dba5545f43ff41fbb1200a2e87a",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "a07f70a04d98aa6ba86e7dfe74152c47e12ed4d3e95b844de9e6ae369e857302",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "5ac747380695f71a82c3bc1f577a7f5dae04bca59aac12ad4591c1aae6f359b4",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f2e56407f31922b5f2d9a7c41f97d66129396f6656613b205e8b56bdc73edb5c",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "2d9337d9c7df99c4f0642e0e86499cf6e1b6caf6163b367cad5538600c1eb5b0",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "adb6735771e1b80303142a97809fa0e59fa8d306acc1c659144b3cc7786ad96a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "31383d7cb685a178d61a2631f3732f8ce8166bb1cf157b41aee0f8f338f5a78e",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "57dd843937cfe0a03ca2d4b79af06c0a57e959db8e6acae057dc1dfe4c83e193",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "23ce627a3e29871fdbe1e420bde450d93767ace9d86632e707e55e7687bb0422",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d395b2ce7058b74aea927e3bcb8e97ec3957f870cf731e64949d3605f71bd193",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0c1da88f44619d31a76232678dae3789c1c8113f0ffa65337700db9bec3b27e2",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "adcc157e4eabd3a916ed8b7131958ef8581cf7e83a90d72d7edaf428fa6c11eb",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "700b3cb65504dd232e84320dd179b197c72e3655a341c89fa71d158599a37cf2",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "efa90f15371c9b4ecc536388fac0d18f7a76c345df7396a1ae651de617464931",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "de240a1bebdcf380e2edbd970dba882558c464085764c3a4dbe949d53b24b8aa",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "e2eea6a59b18ed3eb6e0661cd3468bdedf6637adbbe35ad2dd3534365d7655c5",
      "byte_length": 16372
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594
    }
  }
}
```
