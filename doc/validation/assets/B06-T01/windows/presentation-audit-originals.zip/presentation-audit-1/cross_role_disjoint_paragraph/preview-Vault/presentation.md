# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "8799d49e-b2f6-4af5-b0d6-bdeaeb5eca78",
  "project_id": "a3eac2a6-e8e4-4d13-9627-da89945bfb18",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "dd48778679bf81a57d45e1f5e4e9fa70357c8993ef0992a900bd104d55d2b7bc",
    "byte_length": 41246
  },
  "plan_fingerprint": {
    "sha256": "265ee4f4ac9a2bf0a00ad436a634b33f8606fc39392883adae39d67ad4794710",
    "byte_length": 14692
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "dd48778679bf81a57d45e1f5e4e9fa70357c8993ef0992a900bd104d55d2b7bc",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "4bc2419bfea32bfca06390530b87bafd240b20d68db6eeed55469dc660eb14c0",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "df73d9624ae33f77f793065036880d45767743cb1b4a71834f557916f458b13d",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "c3a45bc8eab2d7795ae152e17ee34d159d27d82e3ed10fba9094da9da7cd07e8",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ccbc0cdf6ad134871c0f458f165973baaa26a130bf7111925555915b01b358bc",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "81688e450c61eb4dd2da3a3a72472a1e04e4bad391a2f27275908b599a2c2544",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "24b7b8553b01c9b7fe36c8a05303da7386c321589e78a12fa5827de0984e9b2c",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "03ee98c306fcb3c5980970fe5986c7891104a07feb2bc9981ea4873113dfd1ce",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "fff8bf3d8a1664e1f77be0999ab58bd84206f7f72b4afa4412fdc84c570db0c5",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2e3f1dc1facbbfb8dbbd772007ebf64c47a565fa2eeb19fc90ace48af64965ec",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "27c5730886cee1429235506091a08389e9b079f61e4f238644b16f022ad7bf9d",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "bd41246ef4b4427028bd254f814a2c7ae071f90dd4f6201c8960239225fcd113",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "6ee384104723cee9579d1f78968b0c5320026f6db66d44092e33c6322f6d1075",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "7a4cbc734e1084ed155ae528edfd00081f6c147222cea7f36cfef9be4daf3e84",
      "byte_length": 17255
    },
    ".selection-original.json": {
      "sha256": "f7154a0436db4c13ac3a9eed2760def664a3288998f2b6eb5fedccffd28fc270",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-ac3e089f2932f8904b926b1600b645f977346dfd5b798a7cbba264e4d61dcd8b"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 33,
          "end_byte": 197
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-2fe36ea4e615deafad3af34f3cba625ecf91454d4199a3711a46ee6f42214526"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 273,
          "end_byte": 437
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000001",
          "target_path": "对象-61000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 198,
          "end_byte": 271
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000003",
          "target_path": "对象-61000000-0000-4000-8000-000000000003.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 438,
          "end_byte": 511
        }
      ]
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000001.md",
      "note_id": "object-61000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-ac3e089f2932f8904b926b1600b645f977346dfd5b798a7cbba264e4d61dcd8b"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 27,
          "end_byte": 320
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000003.md",
      "note_id": "object-61000000-0000-4000-8000-000000000003",
      "plan_revision": 1,
      "content_sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-2fe36ea4e615deafad3af34f3cba625ecf91454d4199a3711a46ee6f42214526"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 29,
          "end_byte": 322
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "dd48778679bf81a57d45e1f5e4e9fa70357c8993ef0992a900bd104d55d2b7bc",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "4bc2419bfea32bfca06390530b87bafd240b20d68db6eeed55469dc660eb14c0",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "df73d9624ae33f77f793065036880d45767743cb1b4a71834f557916f458b13d",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "c3a45bc8eab2d7795ae152e17ee34d159d27d82e3ed10fba9094da9da7cd07e8",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ccbc0cdf6ad134871c0f458f165973baaa26a130bf7111925555915b01b358bc",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "81688e450c61eb4dd2da3a3a72472a1e04e4bad391a2f27275908b599a2c2544",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "24b7b8553b01c9b7fe36c8a05303da7386c321589e78a12fa5827de0984e9b2c",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "03ee98c306fcb3c5980970fe5986c7891104a07feb2bc9981ea4873113dfd1ce",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "fff8bf3d8a1664e1f77be0999ab58bd84206f7f72b4afa4412fdc84c570db0c5",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "2e3f1dc1facbbfb8dbbd772007ebf64c47a565fa2eeb19fc90ace48af64965ec",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "27c5730886cee1429235506091a08389e9b079f61e4f238644b16f022ad7bf9d",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "bd41246ef4b4427028bd254f814a2c7ae071f90dd4f6201c8960239225fcd113",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "6ee384104723cee9579d1f78968b0c5320026f6db66d44092e33c6322f6d1075",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "7a4cbc734e1084ed155ae528edfd00081f6c147222cea7f36cfef9be4daf3e84",
      "byte_length": 17255
    },
    ".owner.json": {
      "sha256": "f46ee4efecbec3947980201ed857e929cb45df7f6755228d5dca5cafcc648e04",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "f7154a0436db4c13ac3a9eed2760def664a3288998f2b6eb5fedccffd28fc270",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "265ee4f4ac9a2bf0a00ad436a634b33f8606fc39392883adae39d67ad4794710",
      "byte_length": 14692
    },
    "对象-61000000-0000-4000-8000-000000000001.md": {
      "sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322
    },
    "对象-61000000-0000-4000-8000-000000000003.md": {
      "sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324
    },
    "知识比较.md": {
      "sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513
    }
  }
}
```
