# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "1b6b886d-378c-4e69-a8d2-ac4a81c5988f",
  "project_id": "2b204f83-f2fd-4d7e-a37b-6ee591d119ba",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "7742cafc3484a8918a2ef7e758b0e922f350ae87a5eb0c0170f5ec4f62e1e8f8",
    "byte_length": 40500
  },
  "plan_fingerprint": {
    "sha256": "ffc69d63d6b176f5680a93dc95ebee8ed40c0e146c72496cefb61bcaef030fbd",
    "byte_length": 17156
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "7742cafc3484a8918a2ef7e758b0e922f350ae87a5eb0c0170f5ec4f62e1e8f8",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "2853368d65708ddc78d36e369766273fbe907c21c8438a04d5ed5b4650bfb3f6",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "82a3e411eb0158f5efa8deafa207b2b88505dacae37e8a96c526bd61f4a89a0d",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "31d4af0acb6fc73d85df503df94c96e0cf519b4080eed2b03abdbc086d74c2ca",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f0579a84f2ba2a4956ea585b1784fc5cd468ad81c44228ed98142aeea917741d",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "facf67288a54afdc0050769aacea7b19388a8d6e76b3e3e220f767a883dd1ead",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "63b753f3eea2ee8720781867656dbbc41b990263b2caf6fd3b03ed600917ed54",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "3007e080ccc3163efc7c9bc3687be37bc867b300dd41313bfb13b42153186f61",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "81fe480b25f9115fb656323d4f156712c1731f6226f45f9a60f3629836ebd775",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9762b07afe83e7664583ac8619882c7ab9d21922c6031199f436d587fbfe852c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "c91e23dd497b821c134286a5601b0ad00d5c5389f3254fb5f9168fa27b19e35d",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "09e2588a4ed665f4f9fadad149e668df2643d172d8950720065c7214a4477738",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "5216e77540c9452e7f2e49cc8cc62d55dc59240924314ce5efb951916955c637",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "0df43caed3e94e5f326d0ff64015c14df55502cbebef899179cd5f3dffe93a5f",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "0c9388300e322265925520c8852d42c1948c6e03eeb5b22b38fed825a5831ff4",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-45940377b654d0a1611a6c88cb9c886f82e53163ce5b898f9a03f0368ca66d4b",
            "occ-bc3ba736a8ffea89ac09718a0bf7c7af0a3b34ca11d99353d5ee56ae2f5b1a0e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-45940377b654d0a1611a6c88cb9c886f82e53163ce5b898f9a03f0368ca66d4b"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-45940377b654d0a1611a6c88cb9c886f82e53163ce5b898f9a03f0368ca66d4b"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-bc3ba736a8ffea89ac09718a0bf7c7af0a3b34ca11d99353d5ee56ae2f5b1a0e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-bc3ba736a8ffea89ac09718a0bf7c7af0a3b34ca11d99353d5ee56ae2f5b1a0e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-45940377b654d0a1611a6c88cb9c886f82e53163ce5b898f9a03f0368ca66d4b"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-bc3ba736a8ffea89ac09718a0bf7c7af0a3b34ca11d99353d5ee56ae2f5b1a0e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "7742cafc3484a8918a2ef7e758b0e922f350ae87a5eb0c0170f5ec4f62e1e8f8",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "2853368d65708ddc78d36e369766273fbe907c21c8438a04d5ed5b4650bfb3f6",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "82a3e411eb0158f5efa8deafa207b2b88505dacae37e8a96c526bd61f4a89a0d",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "31d4af0acb6fc73d85df503df94c96e0cf519b4080eed2b03abdbc086d74c2ca",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f0579a84f2ba2a4956ea585b1784fc5cd468ad81c44228ed98142aeea917741d",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "facf67288a54afdc0050769aacea7b19388a8d6e76b3e3e220f767a883dd1ead",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "63b753f3eea2ee8720781867656dbbc41b990263b2caf6fd3b03ed600917ed54",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "3007e080ccc3163efc7c9bc3687be37bc867b300dd41313bfb13b42153186f61",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "81fe480b25f9115fb656323d4f156712c1731f6226f45f9a60f3629836ebd775",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9762b07afe83e7664583ac8619882c7ab9d21922c6031199f436d587fbfe852c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "c91e23dd497b821c134286a5601b0ad00d5c5389f3254fb5f9168fa27b19e35d",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "09e2588a4ed665f4f9fadad149e668df2643d172d8950720065c7214a4477738",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "5216e77540c9452e7f2e49cc8cc62d55dc59240924314ce5efb951916955c637",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "0df43caed3e94e5f326d0ff64015c14df55502cbebef899179cd5f3dffe93a5f",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "a4719d093b252d1cf29d03cd1236896198675a1a39cf70d6cce5a0407f5c7d87",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "0c9388300e322265925520c8852d42c1948c6e03eeb5b22b38fed825a5831ff4",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "ffc69d63d6b176f5680a93dc95ebee8ed40c0e146c72496cefb61bcaef030fbd",
      "byte_length": 17156
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542
    }
  }
}
```
