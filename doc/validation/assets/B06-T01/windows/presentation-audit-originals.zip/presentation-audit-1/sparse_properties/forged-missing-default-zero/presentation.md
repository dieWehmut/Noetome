# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "6edab869-0862-4b94-810d-b83c1834846b",
  "project_id": "89d68bab-a535-41ab-a698-c0524a5f8506",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 2,
    "table_cells": 6,
    "missing_cells": 1,
    "rendered_notes": 3,
    "content_mappings": 12,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "58c0811f54ab060a54579c1661bc8b049720f4a5324b6ba4f49341e910f492a7",
    "byte_length": 61731
  },
  "plan_fingerprint": {
    "sha256": "7b3bda9bbd626a2bf5b29366dc6442ac3d9f91621c4dac7d8f890e3acbf8767e",
    "byte_length": 24165
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "58c0811f54ab060a54579c1661bc8b049720f4a5324b6ba4f49341e910f492a7",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "dc5661f29796151bc9755b017742e7853efe4c6b5214bdb9e53f52655a6d59ed",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "8aa03ebf4758b8278c488ad580088bc822017da7de1c404940817d802b89f6e5",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "eccad0a18207bd7241799e5a4142b961e7d91a8dac93b2a8a0553c6394498ad0",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "acbd9199becf24e5f67790de1b93b4b640e4ef701db24e81d40f40875fde62d2",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "367cc63315fabbdd7b610dc2ba51654dabbac9197632bf926b8f72d1061be879",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "6f72881d34ee89ae53e3abde0d23e7f0e4f2d5bb8c57597741c5bad99633980d",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "bd13d5f45f26b5d42bdd08e10b3886367660d0e5a779c8bee187be76c015b72f",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "d7fa355eede609c5f22325dbf0e9d74e94115ada502bf8aa9cccd4137f1d6629",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "f72adbc3a5273c422a7611ff9cb52287cd8d61c1ba04dc171122fd1aa04860bf",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9c87e12b53eacc6330cdf2c8b4e1795dbe7457bec9a58277ded6b9027c07defc",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2a570e2844efcf80d067e5770cdead9e29762110eaa5f032c71282c9edde50d4",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "53b6e67ff8ddc4ef45c65e62985b8b97422cdfd63f144a2cc2148ba75c0e024f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5b890ee04fcc2406ea20fa5ed65101fe63c123b7ad31f083e3685900dce412ec",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "2344aaed37ac575e5948c3f2830d7f6c0b75c97aba252b23443058aad9d9572a",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "720436826c114055a72edacdab1af9ba3f1205d86037a80b1343650518cf0204",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "eec79948b6710443448added4407d6121e4e5ebc7cda26f6c2eb8498bd395f7d",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "d278d2874548745917c8f9eb017b5cf2d7062d2dc0b8208a2401e00ccfff72b7",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "4ef9ba49f6c7ce22fed95fd903b717359a128c3096766def05342d8074fb2d9e",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "d75dca0c84106722311386a5036880624d89221e690159da1f838b9570bde717",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69343952552610a07f0664e8551617d665a33183039ca48dbebd72910aad9b48",
      "byte_length": 707,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-ad90c745fb75e8e636e69b485a3c14af902cce688ee4dd1c0c3b56e3f05e6b2f",
            "occ-efd3611537085e3a8cdd3e89c64bb7411b9c0131f1dbabb09b146e50cdb65d63"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-e721a240e4de2bb6d9ac8264f45b64c8476137f5e82b4b8ccc0b05211af57f34"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 53,
          "end_byte": 59
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-e721a240e4de2bb6d9ac8264f45b64c8476137f5e82b4b8ccc0b05211af57f34",
            "occ-efd3611537085e3a8cdd3e89c64bb7411b9c0131f1dbabb09b146e50cdb65d63"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 84,
          "end_byte": 92
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-efd3611537085e3a8cdd3e89c64bb7411b9c0131f1dbabb09b146e50cdb65d63"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 170,
          "end_byte": 316
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-e721a240e4de2bb6d9ac8264f45b64c8476137f5e82b4b8ccc0b05211af57f34"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 319,
          "end_byte": 462
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-ad90c745fb75e8e636e69b485a3c14af902cce688ee4dd1c0c3b56e3f05e6b2f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 467,
          "end_byte": 475
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-ad90c745fb75e8e636e69b485a3c14af902cce688ee4dd1c0c3b56e3f05e6b2f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 553,
          "end_byte": 699
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "missing",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 702,
          "end_byte": 703
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 93,
          "end_byte": 167
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 476,
          "end_byte": 550
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-e721a240e4de2bb6d9ac8264f45b64c8476137f5e82b4b8ccc0b05211af57f34"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-efd3611537085e3a8cdd3e89c64bb7411b9c0131f1dbabb09b146e50cdb65d63"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-ad90c745fb75e8e636e69b485a3c14af902cce688ee4dd1c0c3b56e3f05e6b2f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "58c0811f54ab060a54579c1661bc8b049720f4a5324b6ba4f49341e910f492a7",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "dc5661f29796151bc9755b017742e7853efe4c6b5214bdb9e53f52655a6d59ed",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "8aa03ebf4758b8278c488ad580088bc822017da7de1c404940817d802b89f6e5",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "eccad0a18207bd7241799e5a4142b961e7d91a8dac93b2a8a0553c6394498ad0",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "acbd9199becf24e5f67790de1b93b4b640e4ef701db24e81d40f40875fde62d2",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "367cc63315fabbdd7b610dc2ba51654dabbac9197632bf926b8f72d1061be879",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "6f72881d34ee89ae53e3abde0d23e7f0e4f2d5bb8c57597741c5bad99633980d",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "bd13d5f45f26b5d42bdd08e10b3886367660d0e5a779c8bee187be76c015b72f",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "d7fa355eede609c5f22325dbf0e9d74e94115ada502bf8aa9cccd4137f1d6629",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "f72adbc3a5273c422a7611ff9cb52287cd8d61c1ba04dc171122fd1aa04860bf",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9c87e12b53eacc6330cdf2c8b4e1795dbe7457bec9a58277ded6b9027c07defc",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2a570e2844efcf80d067e5770cdead9e29762110eaa5f032c71282c9edde50d4",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "53b6e67ff8ddc4ef45c65e62985b8b97422cdfd63f144a2cc2148ba75c0e024f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5b890ee04fcc2406ea20fa5ed65101fe63c123b7ad31f083e3685900dce412ec",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "2344aaed37ac575e5948c3f2830d7f6c0b75c97aba252b23443058aad9d9572a",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "720436826c114055a72edacdab1af9ba3f1205d86037a80b1343650518cf0204",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "eec79948b6710443448added4407d6121e4e5ebc7cda26f6c2eb8498bd395f7d",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "d278d2874548745917c8f9eb017b5cf2d7062d2dc0b8208a2401e00ccfff72b7",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "4ef9ba49f6c7ce22fed95fd903b717359a128c3096766def05342d8074fb2d9e",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "dcb9577a57de892cc6b0d3dd7c6fd0ce7f5d26c5b9fedbb30c2d4d24c60dc73a",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "d75dca0c84106722311386a5036880624d89221e690159da1f838b9570bde717",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "7b3bda9bbd626a2bf5b29366dc6442ac3d9f91621c4dac7d8f890e3acbf8767e",
      "byte_length": 24165
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69343952552610a07f0664e8551617d665a33183039ca48dbebd72910aad9b48",
      "byte_length": 707
    }
  }
}
```
