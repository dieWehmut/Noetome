# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "9bc0a162-d494-4b41-af96-e8db158cd05e",
  "project_id": "84980aa6-ff77-42b3-b0d9-7b0a9248611b",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "e3bd1d36b0f3817b888b6a0938490e6713efd11fb87ace1d09554d8f63c925cd",
    "byte_length": 41373
  },
  "plan_fingerprint": {
    "sha256": "661d417bfa591a416defb8de3a86fb014620daaa8672f65696a0d05f220de3b3",
    "byte_length": 14709
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "e3bd1d36b0f3817b888b6a0938490e6713efd11fb87ace1d09554d8f63c925cd",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "dc298e106f881047fefff678343cb5c06b4c8242d3cc56d6143a760c0f644c3c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3e75916644e83aa2a12a7360d0d1b6a930617c3a624c2ffb6234c961cbb6a23e",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "fe1cdda30f05fb942c0c6658d5bf7e5fa1267afc8159f226e30bdfde50692232",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "eeaa37de407118ff5f3b4779bdc830f7f37310600b82f4991d8be9309e99b8b8",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "cc41824888bb80f94d8e59d710d07d5f14e03bb4d47b6eefe5d5e36cd38c71e5",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "be76da98588ac838efb0ec8e2dbecd259b2a9c2e4de8f19577f0e9fc4ffba613",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "cbce302c45abdf7fcdb2553a13853c1cfd2d06874f58d4c230ac2ce1fe1966ca",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "1ca385dad09c7efe72f96efa4aa1bfcbd5722a7907fc8fb88ab4d6c1daa41ada",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "0d626af8f9f06f0b3ab024ebd6c2887037bf286e0e02cd75dadf4d60073be9f0",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d12c19ce26d64b64339a65ba7c1f7938a83df9725583f6bb1db73371f540aa77",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4bdd3e92eca74deb2e4f49a23f657550f781303ed236d0b9c1fff7a6a0929a5b",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "850c35b2187f322167a1aa0b0db797a71e9898458cb409937dbc57fd0f3b4b29",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "fa13ae5e10f68824fa440dda1381e8f4bad5979efb61ad1197a425ebdb0c60a8",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "3c51fe1f61e436320b10e9f7769e2581c297dc039d99ebd3617641efc727ac93",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-e92e56a956869a95b4041ac34666ddf0a3e1723fccb80a8d9a73fef364b69456"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-3c04952c10821fa909dd4c18bbfed57c1527643c45f232787311cd5dfb0114ae"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-3c04952c10821fa909dd4c18bbfed57c1527643c45f232787311cd5dfb0114ae"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-e92e56a956869a95b4041ac34666ddf0a3e1723fccb80a8d9a73fef364b69456"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "e3bd1d36b0f3817b888b6a0938490e6713efd11fb87ace1d09554d8f63c925cd",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "dc298e106f881047fefff678343cb5c06b4c8242d3cc56d6143a760c0f644c3c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3e75916644e83aa2a12a7360d0d1b6a930617c3a624c2ffb6234c961cbb6a23e",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "fe1cdda30f05fb942c0c6658d5bf7e5fa1267afc8159f226e30bdfde50692232",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "eeaa37de407118ff5f3b4779bdc830f7f37310600b82f4991d8be9309e99b8b8",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "cc41824888bb80f94d8e59d710d07d5f14e03bb4d47b6eefe5d5e36cd38c71e5",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "be76da98588ac838efb0ec8e2dbecd259b2a9c2e4de8f19577f0e9fc4ffba613",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "cbce302c45abdf7fcdb2553a13853c1cfd2d06874f58d4c230ac2ce1fe1966ca",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "1ca385dad09c7efe72f96efa4aa1bfcbd5722a7907fc8fb88ab4d6c1daa41ada",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "0d626af8f9f06f0b3ab024ebd6c2887037bf286e0e02cd75dadf4d60073be9f0",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d12c19ce26d64b64339a65ba7c1f7938a83df9725583f6bb1db73371f540aa77",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4bdd3e92eca74deb2e4f49a23f657550f781303ed236d0b9c1fff7a6a0929a5b",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "850c35b2187f322167a1aa0b0db797a71e9898458cb409937dbc57fd0f3b4b29",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "fa13ae5e10f68824fa440dda1381e8f4bad5979efb61ad1197a425ebdb0c60a8",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "05905b61a52c7719c9912ca90abeb1ae055c251b90fb3d39ad21705a5cfb956b",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "3c51fe1f61e436320b10e9f7769e2581c297dc039d99ebd3617641efc727ac93",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "661d417bfa591a416defb8de3a86fb014620daaa8672f65696a0d05f220de3b3",
      "byte_length": 14709
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323
    },
    "知识比较.md": {
      "sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514
    }
  }
}
```
