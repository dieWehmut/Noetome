# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "c3c2fb79-651c-412e-b5ee-3e4772c2138f",
  "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": true,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "31e8da12a72720b8a0ea98263afebb01aeceb62d183fab769ee9b2803086c6b7",
    "byte_length": 41320
  },
  "plan_fingerprint": {
    "sha256": "79939deb9156f9dab4e0db6573c97934321334bf2a0120673201c1bd9b3bbb05",
    "byte_length": 17155
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "31e8da12a72720b8a0ea98263afebb01aeceb62d183fab769ee9b2803086c6b7",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "e27919e05381b4bd07da1d91d065730f0b7663956b6c50e7cac45aa926b0a7be",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "efa5812b1d8c0120e98656bc6ab4b0528cc233640465c85818b12f1ae5022741",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "8278ff7c1411baad3916a4d61b5bd365259990f6be48544280eccc177d0991ce",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "81b5c9ba2ad28970bd536243c1dd231cbfe77d72afd41be6bd3bbb30ea1ed108",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e9f7861edbbe9711a1fc8c0ab65a508298bb32e0095ab4ae32e61fdd8db7e7ee",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "18f4270019e524a591c6b9dd7c12e903f974579fc779faf9d3202feca1d7d42f",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "c39a1d0b94fe97cbe4c10aa367b570db03d888d86ce286111962a428cc3588a1",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "78ac2f776ac8ec71ded86f44aebb064ab30ad47e32391fdf6c24eb774f62e58b",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "35430aae8921489972797e9b1bb167ee58a6d228bd96cf159abe102347750adb",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "3920cdbc144a81eea13285b89993b08392584ac89e2857ab7868febad9b10faf",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "23eb9c885e6788c65bd833c3c3a4e703ecca6256b6b74bb3b53e3405bdb7b99b",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "26cb4035554752c6ee868035fb47f9fa07c73f6e94b8969a549b938cd238c932",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "65ac432875377f5ef5ed603f73f3bcc3950b6b1f4ba24af6eeeec42c31203587",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "5a8245ace2be32ed10459a56bf36cf6d7d970d171b308f846b64ac482a4e4a4d",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee",
            "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "31e8da12a72720b8a0ea98263afebb01aeceb62d183fab769ee9b2803086c6b7",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "e27919e05381b4bd07da1d91d065730f0b7663956b6c50e7cac45aa926b0a7be",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "efa5812b1d8c0120e98656bc6ab4b0528cc233640465c85818b12f1ae5022741",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "8278ff7c1411baad3916a4d61b5bd365259990f6be48544280eccc177d0991ce",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "81b5c9ba2ad28970bd536243c1dd231cbfe77d72afd41be6bd3bbb30ea1ed108",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e9f7861edbbe9711a1fc8c0ab65a508298bb32e0095ab4ae32e61fdd8db7e7ee",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "18f4270019e524a591c6b9dd7c12e903f974579fc779faf9d3202feca1d7d42f",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "c39a1d0b94fe97cbe4c10aa367b570db03d888d86ce286111962a428cc3588a1",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "78ac2f776ac8ec71ded86f44aebb064ab30ad47e32391fdf6c24eb774f62e58b",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "35430aae8921489972797e9b1bb167ee58a6d228bd96cf159abe102347750adb",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "3920cdbc144a81eea13285b89993b08392584ac89e2857ab7868febad9b10faf",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "23eb9c885e6788c65bd833c3c3a4e703ecca6256b6b74bb3b53e3405bdb7b99b",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "26cb4035554752c6ee868035fb47f9fa07c73f6e94b8969a549b938cd238c932",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "65ac432875377f5ef5ed603f73f3bcc3950b6b1f4ba24af6eeeec42c31203587",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "a73f80d00bdb9219440b3fb9311d8468e2bda8a75813f35af12715f1a796362c",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "5a8245ace2be32ed10459a56bf36cf6d7d970d171b308f846b64ac482a4e4a4d",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "79939deb9156f9dab4e0db6573c97934321334bf2a0120673201c1bd9b3bbb05",
      "byte_length": 17155
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542
    }
  }
}
```
