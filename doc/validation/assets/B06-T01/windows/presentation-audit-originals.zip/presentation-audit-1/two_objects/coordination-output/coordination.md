# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "8e955f31-00b8-4818-bc6e-4d7fa3998de5",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
        "import_id": "239147b0-29c3-43d3-9973-7a6243ffa232",
        "source_id": "34854342-df77-4fcb-8d05-45e27b2dd066",
        "version_id": "9bf97d43-339a-4f67-9e3e-ce465438431d",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "239147b0-29c3-43d3-9973-7a6243ffa232",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
              "source_id": "34854342-df77-4fcb-8d05-45e27b2dd066",
              "version_id": "9bf97d43-339a-4f67-9e3e-ce465438431d"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "239147b0-29c3-43d3-9973-7a6243ffa232",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
              "source_id": "34854342-df77-4fcb-8d05-45e27b2dd066",
              "version_id": "9bf97d43-339a-4f67-9e3e-ce465438431d"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "81b5c9ba2ad28970bd536243c1dd231cbfe77d72afd41be6bd3bbb30ea1ed108",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "e9f7861edbbe9711a1fc8c0ab65a508298bb32e0095ab4ae32e61fdd8db7e7ee",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "18f4270019e524a591c6b9dd7c12e903f974579fc779faf9d3202feca1d7d42f",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "c39a1d0b94fe97cbe4c10aa367b570db03d888d86ce286111962a428cc3588a1",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "78ac2f776ac8ec71ded86f44aebb064ab30ad47e32391fdf6c24eb774f62e58b",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
        "import_id": "f0524d16-9afd-4995-8f94-ce4b49317657",
        "source_id": "f57a0af4-5fd7-42ca-94f5-d91fc633d22d",
        "version_id": "0d8d0454-cef9-42f8-bb50-0087de64e25f",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "f0524d16-9afd-4995-8f94-ce4b49317657",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
              "source_id": "f57a0af4-5fd7-42ca-94f5-d91fc633d22d",
              "version_id": "0d8d0454-cef9-42f8-bb50-0087de64e25f"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "f0524d16-9afd-4995-8f94-ce4b49317657",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
              "source_id": "f57a0af4-5fd7-42ca-94f5-d91fc633d22d",
              "version_id": "0d8d0454-cef9-42f8-bb50-0087de64e25f"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 B",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "35430aae8921489972797e9b1bb167ee58a6d228bd96cf159abe102347750adb",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "3920cdbc144a81eea13285b89993b08392584ac89e2857ab7868febad9b10faf",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "23eb9c885e6788c65bd833c3c3a4e703ecca6256b6b74bb3b53e3405bdb7b99b",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "26cb4035554752c6ee868035fb47f9fa07c73f6e94b8969a549b938cd238c932",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "65ac432875377f5ef5ed603f73f3bcc3950b6b1f4ba24af6eeeec42c31203587",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137"
      },
      "occurrence_id": "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee",
      "input_id": "b",
      "binding": {
        "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
        "import_id": "f0524d16-9afd-4995-8f94-ce4b49317657",
        "source_id": "f57a0af4-5fd7-42ca-94f5-d91fc633d22d",
        "version_id": "0d8d0454-cef9-42f8-bb50-0087de64e25f",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "c3c4540e-9319-495b-889f-6abdeef8ca10",
          "ordinal": 0,
          "resource_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 B"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 B"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d",
      "input_id": "a",
      "binding": {
        "project_id": "5aeca9aa-7225-4c90-b98c-0b66a29a4b38",
        "import_id": "239147b0-29c3-43d3-9973-7a6243ffa232",
        "source_id": "34854342-df77-4fcb-8d05-45e27b2dd066",
        "version_id": "9bf97d43-339a-4f67-9e3e-ce465438431d",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "85041f09-e91b-47de-8982-3a745c493b87",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例B",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee",
      "right_occurrence_id": "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-5cfb2ad31d172f42ad4f548efb5c5a42db1652d9111c8b1ee75f836c6905bfee",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-bf22c049c9eecd2d78446cac0fde7d0ce45e0a4846bb4c678224728260c61d8d",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "e27919e05381b4bd07da1d91d065730f0b7663956b6c50e7cac45aa926b0a7be",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "31e8da12a72720b8a0ea98263afebb01aeceb62d183fab769ee9b2803086c6b7",
      "byte_length": 41320
    },
    "coordination-original.json": {
      "sha256": "5a8245ace2be32ed10459a56bf36cf6d7d970d171b308f846b64ac482a4e4a4d",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "81b5c9ba2ad28970bd536243c1dd231cbfe77d72afd41be6bd3bbb30ea1ed108",
      "byte_length": 3057
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "e9f7861edbbe9711a1fc8c0ab65a508298bb32e0095ab4ae32e61fdd8db7e7ee",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "18f4270019e524a591c6b9dd7c12e903f974579fc779faf9d3202feca1d7d42f",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "c39a1d0b94fe97cbe4c10aa367b570db03d888d86ce286111962a428cc3588a1",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "78ac2f776ac8ec71ded86f44aebb064ab30ad47e32391fdf6c24eb774f62e58b",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "35430aae8921489972797e9b1bb167ee58a6d228bd96cf159abe102347750adb",
      "byte_length": 3057
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "3920cdbc144a81eea13285b89993b08392584ac89e2857ab7868febad9b10faf",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "23eb9c885e6788c65bd833c3c3a4e703ecca6256b6b74bb3b53e3405bdb7b99b",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "26cb4035554752c6ee868035fb47f9fa07c73f6e94b8969a549b938cd238c932",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "65ac432875377f5ef5ed603f73f3bcc3950b6b1f4ba24af6eeeec42c31203587",
      "byte_length": 17303
    }
  }
}
```
