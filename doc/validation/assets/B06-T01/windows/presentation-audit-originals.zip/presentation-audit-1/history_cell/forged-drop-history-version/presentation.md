# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "b2692c84-c54c-48d5-9a98-fe0e469aeeb8",
  "project_id": "f19829cf-9509-489c-bcbb-61c5e6ae17bc",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "21e017346dd3981a3e7b078162e2c5f0ab4fefca148aefde0116ec4f92196eb1",
    "byte_length": 61820
  },
  "plan_fingerprint": {
    "sha256": "35691616cdb4a15f06fc06df233997982d8b50b303bea35df5062d40c9a105e2",
    "byte_length": 22658
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "21e017346dd3981a3e7b078162e2c5f0ab4fefca148aefde0116ec4f92196eb1",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "b6277a7cc6bb9699487c5c93063446ae50827e1c7116f1f6e237e5469644883b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9d197a20c14a41940e4f637d8b2940cb89e5ee60e76796ee3e2801ac70084d3d",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "4852c8589620b6e0085d00a83c97a5235e424a00b1f88992c520f5c1d71be5ca",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "8b0678583969d1ee0e3af6b2c694fe05b42e0cb30d2ca51828c21b5669bfae2d",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "134b14c4b45879e01c2c3147a2cd5075a94b447657a25068b361739af2566c23",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "bbcc5d5894b27fa7f8ae75eddc6a276e4c1f55c370e12f792daad54367f7047a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "1f9d8e7cec58323a030019fab7aca4557eb1f6d92b5f7201507dbf90ada86e8f",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "98d3e0c17938490faaf5eb131bb58121f6bbe2833043340699a92cbb06cec223",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "84b1b8a90c696c4864ccaf5e370c229b8fcdb47ee2c8d1f8d88b62ff24530f2e",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "829386949221a0c7236cc06973a1d51c401afcf9854df297fb23bfd352d2757b",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "12f9ea987ed7a9b9387f72bb5185fe77655da697e26d6400e2926fde1a852bb8",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "72a6c2e347045a9b9278ff47a2a56b8f5b3b855005ce25614618659226adbce9",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8fba22b88dad28f6c617ba6441280761c76802d1e8923964dc58737166485dd5",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "9b8186adf26998d9f347f521d48a99c3a144b875502ddff8a1abe5616e05dafc",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "e6762170f82c9c28f62681d3d57e22bde387c0049b9b9a74748b162acfc26f05",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "4b1aecd98f420633914dc7d5afb2232143e290761b438e0664566d1d978e0e73",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "a100f645ede4d18bed42d05fc333f9e64497dab9daf8e570bb7c8808df2e1204",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "140debbc0ad8bc21a50c231063602b3bb328e20a7a3121beb45e1d2344ad3124",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "312df389f46042583b574db69dc847e7588ec7f43570d799a06de5fefbc242e0",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "211e25fe70e8827c0eef3c80cf1f756006e4024bc1d326fd9b24bffc25c8acdb",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-444659ed4cfe2acfe40591acbd4232bde126b6d70af11cf51b6bd994803f7447",
            "occ-8e8c52365027a86bddcd114d5cd7f7c37013eaffd1a03c3c60f83b354b4a9840",
            "occ-f65146f144ef8cba802d4a883eca38d8ebb1eda7ffa3bee2bc74eb8d6f1c7da9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-444659ed4cfe2acfe40591acbd4232bde126b6d70af11cf51b6bd994803f7447",
            "occ-f65146f144ef8cba802d4a883eca38d8ebb1eda7ffa3bee2bc74eb8d6f1c7da9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-444659ed4cfe2acfe40591acbd4232bde126b6d70af11cf51b6bd994803f7447",
            "occ-f65146f144ef8cba802d4a883eca38d8ebb1eda7ffa3bee2bc74eb8d6f1c7da9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-8e8c52365027a86bddcd114d5cd7f7c37013eaffd1a03c3c60f83b354b4a9840"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-8e8c52365027a86bddcd114d5cd7f7c37013eaffd1a03c3c60f83b354b4a9840"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-444659ed4cfe2acfe40591acbd4232bde126b6d70af11cf51b6bd994803f7447"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-f65146f144ef8cba802d4a883eca38d8ebb1eda7ffa3bee2bc74eb8d6f1c7da9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-8e8c52365027a86bddcd114d5cd7f7c37013eaffd1a03c3c60f83b354b4a9840"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "21e017346dd3981a3e7b078162e2c5f0ab4fefca148aefde0116ec4f92196eb1",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "b6277a7cc6bb9699487c5c93063446ae50827e1c7116f1f6e237e5469644883b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9d197a20c14a41940e4f637d8b2940cb89e5ee60e76796ee3e2801ac70084d3d",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "4852c8589620b6e0085d00a83c97a5235e424a00b1f88992c520f5c1d71be5ca",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "8b0678583969d1ee0e3af6b2c694fe05b42e0cb30d2ca51828c21b5669bfae2d",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "134b14c4b45879e01c2c3147a2cd5075a94b447657a25068b361739af2566c23",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "bbcc5d5894b27fa7f8ae75eddc6a276e4c1f55c370e12f792daad54367f7047a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "1f9d8e7cec58323a030019fab7aca4557eb1f6d92b5f7201507dbf90ada86e8f",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "98d3e0c17938490faaf5eb131bb58121f6bbe2833043340699a92cbb06cec223",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "84b1b8a90c696c4864ccaf5e370c229b8fcdb47ee2c8d1f8d88b62ff24530f2e",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "829386949221a0c7236cc06973a1d51c401afcf9854df297fb23bfd352d2757b",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "12f9ea987ed7a9b9387f72bb5185fe77655da697e26d6400e2926fde1a852bb8",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "72a6c2e347045a9b9278ff47a2a56b8f5b3b855005ce25614618659226adbce9",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8fba22b88dad28f6c617ba6441280761c76802d1e8923964dc58737166485dd5",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "9b8186adf26998d9f347f521d48a99c3a144b875502ddff8a1abe5616e05dafc",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "e6762170f82c9c28f62681d3d57e22bde387c0049b9b9a74748b162acfc26f05",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "4b1aecd98f420633914dc7d5afb2232143e290761b438e0664566d1d978e0e73",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "a100f645ede4d18bed42d05fc333f9e64497dab9daf8e570bb7c8808df2e1204",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "140debbc0ad8bc21a50c231063602b3bb328e20a7a3121beb45e1d2344ad3124",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "78f1c9358b5a1b4960e94b9535b85757a7a6ad493ae409fc12d6ce51cdf6411e",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "312df389f46042583b574db69dc847e7588ec7f43570d799a06de5fefbc242e0",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "35691616cdb4a15f06fc06df233997982d8b50b303bea35df5062d40c9a105e2",
      "byte_length": 22658
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "211e25fe70e8827c0eef3c80cf1f756006e4024bc1d326fd9b24bffc25c8acdb",
      "byte_length": 542
    }
  }
}
```
