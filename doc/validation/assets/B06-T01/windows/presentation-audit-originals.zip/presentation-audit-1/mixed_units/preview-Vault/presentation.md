# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "b5bed58f-6f3e-4ccf-8054-f542bff07f1e",
  "project_id": "534fa8e6-c336-4869-8184-bfe10380725a",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "8f568454ed635ec368c1820a71d27b3f2ff351e106da43c4221ca25040ec9f75",
    "byte_length": 41343
  },
  "plan_fingerprint": {
    "sha256": "0f33a9a63ef92089851c08646ebc974e21fa5b289532b4d031428622bc3012cb",
    "byte_length": 17164
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "8f568454ed635ec368c1820a71d27b3f2ff351e106da43c4221ca25040ec9f75",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "caa8d1226286fcac08ed812b46249bdf26b83849b355c1df21e2479777b1b627",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "5c73bb64901de29f679f9a4c463b76183476bef74b54e68d502eafde43f9b52d",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "448e71be4212a7f399029946a48bbd354bd8455a8355e6dfd29049f6aecbb9f6",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "90525256e3da51325d038c429736108b78bd78afd510123029f5c73ae266c59c",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "556e89b5a39bcfea8fc29b47a494bb40550bf5a595c1e1623dd39cab72f18196",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f43b8871b8e7aae0bf97d211b2c3a587bd89b0e123a2e6a39455bc3cc8e6d843",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8ff1fe332d08204477bff550707fd12315b9b614ee25cef1b75a5ba8e55e5a5b",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7632f1d821f847736fe768d140a8c565d8747fb21b284bd9b85af597b4ee5319",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "d246fa9b8594e2e199bf26594e23e2529802218415fa2e1e90a6afac07df31d1",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d8a26bc6e21efb785fb39d93434ab0ea7e9b5ebf354a67e5b3650cadd366f2dd",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "3a105d39d4408799d95520f6e9dc4d93e00b74fecb93a089033bb629b3eb75c0",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "b0990612ec11b75a8cff2e264a762d9d929edf3c036d4e8ed9866ed1b50ceb6d",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "395c6ac6fc86b2b48b1820cb9ffe4d089e49b202f73e97578b4a170ea302504e",
      "byte_length": 17319
    },
    ".selection-original.json": {
      "sha256": "6ea66d59615b59882edbf98c32495184599b731669aadf5e1b323a5cd668df7a",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-534bb4549eddc1a8cb82332156e371bd544b982559be5ed327a3a0ac0bf1fed4",
            "occ-c2cfae3fe001112862900e4706dcc070ae6cb2321253fbd7f2529da9250ec678"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-534bb4549eddc1a8cb82332156e371bd544b982559be5ed327a3a0ac0bf1fed4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-534bb4549eddc1a8cb82332156e371bd544b982559be5ed327a3a0ac0bf1fed4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-c2cfae3fe001112862900e4706dcc070ae6cb2321253fbd7f2529da9250ec678"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-c2cfae3fe001112862900e4706dcc070ae6cb2321253fbd7f2529da9250ec678"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 539
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-534bb4549eddc1a8cb82332156e371bd544b982559be5ed327a3a0ac0bf1fed4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-c2cfae3fe001112862900e4706dcc070ae6cb2321253fbd7f2529da9250ec678"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 329
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "8f568454ed635ec368c1820a71d27b3f2ff351e106da43c4221ca25040ec9f75",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "caa8d1226286fcac08ed812b46249bdf26b83849b355c1df21e2479777b1b627",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "5c73bb64901de29f679f9a4c463b76183476bef74b54e68d502eafde43f9b52d",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "448e71be4212a7f399029946a48bbd354bd8455a8355e6dfd29049f6aecbb9f6",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "90525256e3da51325d038c429736108b78bd78afd510123029f5c73ae266c59c",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "556e89b5a39bcfea8fc29b47a494bb40550bf5a595c1e1623dd39cab72f18196",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f43b8871b8e7aae0bf97d211b2c3a587bd89b0e123a2e6a39455bc3cc8e6d843",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8ff1fe332d08204477bff550707fd12315b9b614ee25cef1b75a5ba8e55e5a5b",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7632f1d821f847736fe768d140a8c565d8747fb21b284bd9b85af597b4ee5319",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "d246fa9b8594e2e199bf26594e23e2529802218415fa2e1e90a6afac07df31d1",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d8a26bc6e21efb785fb39d93434ab0ea7e9b5ebf354a67e5b3650cadd366f2dd",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "3a105d39d4408799d95520f6e9dc4d93e00b74fecb93a089033bb629b3eb75c0",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "b0990612ec11b75a8cff2e264a762d9d929edf3c036d4e8ed9866ed1b50ceb6d",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "395c6ac6fc86b2b48b1820cb9ffe4d089e49b202f73e97578b4a170ea302504e",
      "byte_length": 17319
    },
    ".owner.json": {
      "sha256": "96f97fbaab1ce248fa35a6c1fa10a346ea3d2fc806fe6836a4baa99698e3bc0c",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "6ea66d59615b59882edbf98c32495184599b731669aadf5e1b323a5cd668df7a",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "0f33a9a63ef92089851c08646ebc974e21fa5b289532b4d031428622bc3012cb",
      "byte_length": 17164
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331
    },
    "知识比较.md": {
      "sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543
    }
  }
}
```
