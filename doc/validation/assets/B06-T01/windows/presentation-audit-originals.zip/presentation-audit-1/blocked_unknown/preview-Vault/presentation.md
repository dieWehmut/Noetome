# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "4a995baf-1fcd-4e14-8cc1-44581502b9c6",
  "project_id": "5301a3f3-85c4-4944-89a5-65a928fa2936",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "57f45b6f943232b960435e31b237841a72da779ff96262b3468dee3b7ea71488",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ef586d367939a303833a94288c3c426d9a2cdccc327f25019bc6cc885798e7a5",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "e570578dde1fcbc1c169b7395bdd79b804796da0a8ba812ced3e0cfe3e66850e",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e532702b93b737e9edbf145878a703216977bea0467e669976a68fdbe8969d48",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "33f395690d087c5c90b2225041958c9ef11f13895e3b006ff9da4cfd3b9ef37c",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "0527838393c8ee4b4b9f029fe68210b103fc265dcff77695227c710eb26fafab",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "e4390a6d18774a6661ca92f2a4fc72f6d7773e9a3fc55ef64660253bc5951b85",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "4688d08d01730acb47eb9fd54d40056ee43da5fe6792e408165f9645c8d3404d",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "21035c4465018fecbfff037036589336e2b07ccc9c9930340af849800b879b10",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "c94c6d830c54fbbe37331e119751e5781c955b736d41ef5717a28eb723920155",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c2fc379596526308578b06f0f4865dfe507a8fd43e505f231910af1b5c7ac34d",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "d24c726ca40d69ff6cc4710784bb23bdef50c11a9a0db104f8bad31cc7da609d",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "e03af81d417261a9032c0f575f7f84f9edeac836782803a8d7a270c48192f44a",
      "byte_length": 14422
    },
    ".selection-original.json": {
      "sha256": "c2fe60d1a4b58e2203ca33856efc7a2da4836f766854b8ea4336b7bf733982a6",
      "byte_length": 4326
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "57f45b6f943232b960435e31b237841a72da779ff96262b3468dee3b7ea71488",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ef586d367939a303833a94288c3c426d9a2cdccc327f25019bc6cc885798e7a5",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "e570578dde1fcbc1c169b7395bdd79b804796da0a8ba812ced3e0cfe3e66850e",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e532702b93b737e9edbf145878a703216977bea0467e669976a68fdbe8969d48",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "33f395690d087c5c90b2225041958c9ef11f13895e3b006ff9da4cfd3b9ef37c",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "0527838393c8ee4b4b9f029fe68210b103fc265dcff77695227c710eb26fafab",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "e4390a6d18774a6661ca92f2a4fc72f6d7773e9a3fc55ef64660253bc5951b85",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "4688d08d01730acb47eb9fd54d40056ee43da5fe6792e408165f9645c8d3404d",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "21035c4465018fecbfff037036589336e2b07ccc9c9930340af849800b879b10",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "c94c6d830c54fbbe37331e119751e5781c955b736d41ef5717a28eb723920155",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c2fc379596526308578b06f0f4865dfe507a8fd43e505f231910af1b5c7ac34d",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "d24c726ca40d69ff6cc4710784bb23bdef50c11a9a0db104f8bad31cc7da609d",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "e03af81d417261a9032c0f575f7f84f9edeac836782803a8d7a270c48192f44a",
      "byte_length": 14422
    },
    ".owner.json": {
      "sha256": "fdf63d74583bac99f64ce73e4176c4568fc399dbb999f3791b248ce7f38c2b29",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "c2fe60d1a4b58e2203ca33856efc7a2da4836f766854b8ea4336b7bf733982a6",
      "byte_length": 4326
    }
  }
}
```
