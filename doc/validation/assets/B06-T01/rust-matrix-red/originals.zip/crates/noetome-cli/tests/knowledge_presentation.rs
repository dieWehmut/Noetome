use std::fs;
#[path = "support/presentation_case.rs"]
mod support;
use support::*;

// This catches a missing ordinary planner route after successful source review
// and coordination, rather than checking author-supplied rendered NotePlan.
#[test]
fn ordinary_present_chooses_table_after_source_review_and_successful_coordination() {
    let mut f = PresentationCase::prepare("two_objects");
    let coordinated = f.coordinate();
    assert_eq!(
        coordinated.status.code(),
        Some(0),
        "{}",
        String::from_utf8_lossy(&coordinated.stderr)
    );
    assert!(f.output.join("coordination-ir.json").is_file());
    f.freeze_coordination();
    let presented = f.present();
    f.assert_protected();
    assert_eq!(
        presented.status.code(),
        Some(0),
        "ordinary knowledge present should generate a preview; root={} stderr={}",
        f.root.display(),
        String::from_utf8_lossy(&presented.stderr)
    );
    assert!(f.preview.join("plan.json").is_file());
    assert!(f.preview.join("知识比较.md").is_file());
    let plan: serde_json::Value =
        serde_json::from_slice(&fs::read(f.preview.join("plan.json")).unwrap()).unwrap();
    assert_eq!(plan["representation"], "table");
}

#[test]
fn every_frozen_author_case_obeys_table_paragraph_or_unresolved_preview_rules() {
    let fixture = repo().join("fixtures/active-presentation-v1");
    let authors: serde_json::Value =
        serde_json::from_slice(&fs::read(fixture.join("authors.json")).unwrap()).unwrap();
    let matrix = repo()
        .join("target/compiler-temp")
        .join(format!("presentation-matrix-{}", uuid::Uuid::new_v4()));
    fs::create_dir(&matrix).unwrap();
    println!("presentation_matrix_root={}", matrix.display());
    let mut rows = vec![];
    let mut failures = vec![];
    for author in authors["cases"].as_array().unwrap() {
        let name = author["name"].as_str().unwrap();
        let expected: serde_json::Value = serde_json::from_slice(
            &fs::read(fixture.join(author["presentation_expected_file"].as_str().unwrap()))
                .unwrap(),
        )
        .unwrap();
        let mut prepared_root = None;
        // Retain evidence for every declared case, even while the new route is
        // absent. One observed failure must not suppress the remaining cases.
        let checked = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let mut f = PresentationCase::prepare(name);
            prepared_root = Some(f.root.clone());
            let coordinated = f.coordinate();
            let ready = expected["expect_successful_preview"].as_bool().unwrap();
            assert_eq!(
                coordinated.status.code(),
                Some(if ready { 0 } else { 3 }),
                "source-backed coordination for {name}: {}",
                String::from_utf8_lossy(&coordinated.stderr)
            );
            let report: serde_json::Value =
                serde_json::from_slice(&fs::read(f.output.join("coordination.json")).unwrap())
                    .unwrap();
            assert_eq!(report["totals"], author["coordination_expected"]["totals"]);
            assert_eq!(report["knowledge_status"], "pending");
            assert_eq!(report["scientific_quality"], "not_run");
            assert_eq!(report["published"], false);
            assert_eq!(f.output.join("coordination-ir.json").is_file(), ready);
            f.freeze_coordination();
            let presented = f.present();
            f.assert_protected();
            if ready {
                assert_eq!(
                    presented.status.code(),
                    Some(0),
                    "present {name}: {}",
                    String::from_utf8_lossy(&presented.stderr)
                );
                let plan: serde_json::Value =
                    serde_json::from_slice(&fs::read(f.preview.join("plan.json")).unwrap())
                        .unwrap();
                assert_eq!(plan["representation"], expected["representation"]);
                assert!(f.preview.join("知识比较.md").is_file());
            } else {
                assert_eq!(
                    presented.status.code(),
                    Some(3),
                    "unresolved {name} must remain blocked: {}",
                    String::from_utf8_lossy(&presented.stderr)
                );
                assert!(!f.preview.join("plan.json").exists());
                assert!(!f.preview.join("知识比较.md").exists());
            }
        }));
        let failure = checked.err().map(|p| {
            p.downcast_ref::<String>()
                .cloned()
                .or_else(|| p.downcast_ref::<&str>().map(|s| (*s).to_owned()))
                .unwrap_or_else(|| "unexpected panic payload".to_owned())
        });
        if let Some(reason) = &failure {
            failures.push(format!("{name}: {reason}"));
        }
        rows.push(serde_json::json!({
            "name":name,
            "expected_representation":expected["representation"],
            "expected_successful_preview":expected["expect_successful_preview"],
            "prepared_root":prepared_root,
            "test_passed":failure.is_none(),
            "failure":failure
        }));
        fs::write(matrix.join("cases.json"), encode(&serde_json::json!(rows))).unwrap();
    }
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}
