# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "9c739d71-3bc2-47e9-8711-a9e002cf449e",
  "project_id": "b3e42b86-2526-43c3-9f78-2aab4b58d253",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "1e90380c012a3382c048c811f4470a6a5d999be2f09347d570c2480fece1aa87",
    "byte_length": 41337
  },
  "plan_fingerprint": {
    "sha256": "67b3caa19c88e7090ae623d85069199453339e362ff179a871a2d498e6090ec4",
    "byte_length": 17223
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "1e90380c012a3382c048c811f4470a6a5d999be2f09347d570c2480fece1aa87",
      "byte_length": 41337
    },
    ".coordination-owner.json": {
      "sha256": "52096e0c0f6274c76e6ec084004e3f70001c75a7ecb8a3aa2d63a874a2b6e155",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "f185beed2e1887ad1da7297852514dd929ad279163d557cf808997d9c73c47af",
      "byte_length": 44808
    },
    ".coordination-report.md": {
      "sha256": "435c7b54cb1aa87ef27971a56e29b3a60d1297125e5dbebb740f0be57608694a",
      "byte_length": 45283
    },
    ".identity-original.json": {
      "sha256": "fa53fd3df5076b17dc0c175e973142eba502e9ff2c8169e50bd562fb57d1a068",
      "byte_length": 2034
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f7c74a998bf1f30119412ab9071b55f2fb772a3e8731d3d1491f8243f8d13f17",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "304e9f293e136674fdc15aed351ac3bdad048ce17ef9732ff799bb91fa96dec0",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "7ed50fa2dad75517842d34bfe7db63940ff4257004d182c0616ae688474aa46f",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "60a68247db77f87b4204b4d3b185653d0a4629786cfc193545b45b38de9e07ff",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e43bbc9cad7d5d7033f41cb717bf6dd6a2fb145cd3a6c6edcffddafd8e38236d",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c3bb686e4e458e4cdbe10ae699c228c59ff5843fd2c7b7010a8cf9b5ef73b29c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "44ab03d796a3ffe661eee89f36ef2411d3f8ee83e292d9c88cdb5ae6b92ec7eb",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "e99f2eb2ebb4639c3a8db6badfc798c18d9d95737d22b2ea8efb16317980ab45",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "9629dd34f62c9fde94942fe2ea0536df15f1a824db4e81a5f4cf23f1c6950c9d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "3a814cf0742ae1b4142f423129feeacdc5d28aa49c8b96dc53ca8f204b428516",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "6a746c0e128c26dcae78cc9363856f0a05d2df99c8ced6a915d2e85952021cea",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "3cdc2920ec68a87212a059f8e232b8c25747629c72d4ad1f407fb31a4ed2c6dc",
      "byte_length": 563,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0d9b6b7c8fb1037b43e8c1e86589a0f304009db5f8dbd3c1230f9b040162f0dc",
            "occ-c4407f204af3ee702924525d0cc73debb31d969ad3047883c5e9383e84afa582"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0d9b6b7c8fb1037b43e8c1e86589a0f304009db5f8dbd3c1230f9b040162f0dc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-0d9b6b7c8fb1037b43e8c1e86589a0f304009db5f8dbd3c1230f9b040162f0dc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 322
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-c4407f204af3ee702924525d0cc73debb31d969ad3047883c5e9383e84afa582"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 327,
          "end_byte": 335
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-c4407f204af3ee702924525d0cc73debb31d969ad3047883c5e9383e84afa582"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 413,
          "end_byte": 559
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 336,
          "end_byte": 410
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "dcc2166c25fcd28e00955c5bb43d8b7ca09dc384c136bbb55666dfda9b7a8a95",
      "byte_length": 371,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-0d9b6b7c8fb1037b43e8c1e86589a0f304009db5f8dbd3c1230f9b040162f0dc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 369
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-c4407f204af3ee702924525d0cc73debb31d969ad3047883c5e9383e84afa582"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "1e90380c012a3382c048c811f4470a6a5d999be2f09347d570c2480fece1aa87",
      "byte_length": 41337
    },
    ".coordination-owner.json": {
      "sha256": "52096e0c0f6274c76e6ec084004e3f70001c75a7ecb8a3aa2d63a874a2b6e155",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "f185beed2e1887ad1da7297852514dd929ad279163d557cf808997d9c73c47af",
      "byte_length": 44808
    },
    ".coordination-report.md": {
      "sha256": "435c7b54cb1aa87ef27971a56e29b3a60d1297125e5dbebb740f0be57608694a",
      "byte_length": 45283
    },
    ".identity-original.json": {
      "sha256": "fa53fd3df5076b17dc0c175e973142eba502e9ff2c8169e50bd562fb57d1a068",
      "byte_length": 2034
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f7c74a998bf1f30119412ab9071b55f2fb772a3e8731d3d1491f8243f8d13f17",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "304e9f293e136674fdc15aed351ac3bdad048ce17ef9732ff799bb91fa96dec0",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "7ed50fa2dad75517842d34bfe7db63940ff4257004d182c0616ae688474aa46f",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "60a68247db77f87b4204b4d3b185653d0a4629786cfc193545b45b38de9e07ff",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e43bbc9cad7d5d7033f41cb717bf6dd6a2fb145cd3a6c6edcffddafd8e38236d",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c3bb686e4e458e4cdbe10ae699c228c59ff5843fd2c7b7010a8cf9b5ef73b29c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "44ab03d796a3ffe661eee89f36ef2411d3f8ee83e292d9c88cdb5ae6b92ec7eb",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "e99f2eb2ebb4639c3a8db6badfc798c18d9d95737d22b2ea8efb16317980ab45",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "9629dd34f62c9fde94942fe2ea0536df15f1a824db4e81a5f4cf23f1c6950c9d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "3a814cf0742ae1b4142f423129feeacdc5d28aa49c8b96dc53ca8f204b428516",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "e89503e28e6779ad9dff3dff7351efa249df08691d011c44ce1dab0ef543fa88",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "6a746c0e128c26dcae78cc9363856f0a05d2df99c8ced6a915d2e85952021cea",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "67b3caa19c88e7090ae623d85069199453339e362ff179a871a2d498e6090ec4",
      "byte_length": 17223
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "dcc2166c25fcd28e00955c5bb43d8b7ca09dc384c136bbb55666dfda9b7a8a95",
      "byte_length": 371
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "3cdc2920ec68a87212a059f8e232b8c25747629c72d4ad1f407fb31a4ed2c6dc",
      "byte_length": 563
    }
  }
}
```
