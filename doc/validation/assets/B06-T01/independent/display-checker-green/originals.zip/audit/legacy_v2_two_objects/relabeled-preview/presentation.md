# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "8cd3e36f-e9f2-4a1b-b535-17e03c8d827e",
  "project_id": "f5045418-a596-459c-97cd-f4643950a4fc",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "da84d4d2d98eec3be4b56a6a05212642767a8d490fd54708d73b8326869eeb04",
    "byte_length": 40517
  },
  "plan_fingerprint": {
    "sha256": "59cb238498d27217a87f6bdd3963e2be2dc45a8f7c7193cdef02a928c09cfead",
    "byte_length": 17654
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "da84d4d2d98eec3be4b56a6a05212642767a8d490fd54708d73b8326869eeb04",
      "byte_length": 40517
    },
    ".coordination-owner.json": {
      "sha256": "be93131ec59625290f584f8b20cdeb954a483c55b289de6e89fecf49fa310f8c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "23f462578b2fee542ea25e40c59e859afc670369379084ef2adf7e2549207213",
      "byte_length": 43988
    },
    ".coordination-report.md": {
      "sha256": "790c036c8ef9c0840b441a17ee395ada2879a7dc9ca9fe9d3271b1031bc5955d",
      "byte_length": 44394
    },
    ".identity-original.json": {
      "sha256": "f0b8eea833ba5011cc6cdfc7851c863828ee9153267a97072894ce0a38257209",
      "byte_length": 2033
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "c06be4c78caad4ce11558a0831b52409881ab5d0983c0688f1a9ab9cd8f88206",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "c03cfe55d382631d3dfe3887819655686c48d07f5d8d98b387160fa1ecb45476",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "4588e67a3f9c41836889fb346318d65b1a1b1a3ae3aa66583c5b8274a2cb86bc",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "e3b31098a8d58b971985ea4545902d393c43509158128438899d73bde983b71d",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "3daaefdfce1a72ed98ffde84fb550e5ce77a3c1d1008fa73c4a193fc6747b82d",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "a54c2bac62e143b1fc6484c0e218b21cf6aea4698e253271a3e373770d97187c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "1f73b4bc7ca688a9fa7822a60b6dbb9249d38f6d537ec56d05090af887e4c9f6",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "1f0768dc9f664127d2857f755c4cd2beac7f25df3900afde818bf605ca485862",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "38cdcd15321a8429e250c3d8e0cc5c389179e4ea85992c4504f17fbc08c8015b",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "f55026b26d502029f75f0a83a8322d74d080af0dbdbb4cd35c08f3771fb2648a",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "744d9b046954bd696dd96d4dd72e330c5f5b8e231ea8691707bc3bc984edb1e7",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c1eacd13b327675c2ad5d5340af6b854f184bfa4aa1bec8712db428ae4fc0813",
      "byte_length": 563,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-4c8433f9dd68999ab3a005377808e1f4a374a828cc0634393cea91575c68c200",
            "occ-65d5fe374104fce5b65d2f8d9d578b12aa14f8d8872c4263be281e1d45e39834"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-4c8433f9dd68999ab3a005377808e1f4a374a828cc0634393cea91575c68c200"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-4c8433f9dd68999ab3a005377808e1f4a374a828cc0634393cea91575c68c200"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 322
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-65d5fe374104fce5b65d2f8d9d578b12aa14f8d8872c4263be281e1d45e39834"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 327,
          "end_byte": 335
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-65d5fe374104fce5b65d2f8d9d578b12aa14f8d8872c4263be281e1d45e39834"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 413,
          "end_byte": 559
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 336,
          "end_byte": 410
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a3bf6c600a24263621766e312e354c3347575619485a53d788c03f1229f6fafc",
      "byte_length": 371,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-4c8433f9dd68999ab3a005377808e1f4a374a828cc0634393cea91575c68c200"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 369
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-65d5fe374104fce5b65d2f8d9d578b12aa14f8d8872c4263be281e1d45e39834"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "da84d4d2d98eec3be4b56a6a05212642767a8d490fd54708d73b8326869eeb04",
      "byte_length": 40517
    },
    ".coordination-owner.json": {
      "sha256": "be93131ec59625290f584f8b20cdeb954a483c55b289de6e89fecf49fa310f8c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "23f462578b2fee542ea25e40c59e859afc670369379084ef2adf7e2549207213",
      "byte_length": 43988
    },
    ".coordination-report.md": {
      "sha256": "790c036c8ef9c0840b441a17ee395ada2879a7dc9ca9fe9d3271b1031bc5955d",
      "byte_length": 44394
    },
    ".identity-original.json": {
      "sha256": "f0b8eea833ba5011cc6cdfc7851c863828ee9153267a97072894ce0a38257209",
      "byte_length": 2033
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "c06be4c78caad4ce11558a0831b52409881ab5d0983c0688f1a9ab9cd8f88206",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "c03cfe55d382631d3dfe3887819655686c48d07f5d8d98b387160fa1ecb45476",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "4588e67a3f9c41836889fb346318d65b1a1b1a3ae3aa66583c5b8274a2cb86bc",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "e3b31098a8d58b971985ea4545902d393c43509158128438899d73bde983b71d",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "3daaefdfce1a72ed98ffde84fb550e5ce77a3c1d1008fa73c4a193fc6747b82d",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "a54c2bac62e143b1fc6484c0e218b21cf6aea4698e253271a3e373770d97187c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "1f73b4bc7ca688a9fa7822a60b6dbb9249d38f6d537ec56d05090af887e4c9f6",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "1f0768dc9f664127d2857f755c4cd2beac7f25df3900afde818bf605ca485862",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "38cdcd15321a8429e250c3d8e0cc5c389179e4ea85992c4504f17fbc08c8015b",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "f55026b26d502029f75f0a83a8322d74d080af0dbdbb4cd35c08f3771fb2648a",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "94925337b31864dfa9632ef3cb3c1deb25242f064292ffbdc5c79e64e1010ee2",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "744d9b046954bd696dd96d4dd72e330c5f5b8e231ea8691707bc3bc984edb1e7",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "59cb238498d27217a87f6bdd3963e2be2dc45a8f7c7193cdef02a928c09cfead",
      "byte_length": 17654
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a3bf6c600a24263621766e312e354c3347575619485a53d788c03f1229f6fafc",
      "byte_length": 371
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "c1eacd13b327675c2ad5d5340af6b854f184bfa4aa1bec8712db428ae4fc0813",
      "byte_length": 563
    }
  }
}
```
