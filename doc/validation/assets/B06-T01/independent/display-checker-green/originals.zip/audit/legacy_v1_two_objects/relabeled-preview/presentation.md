# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "09274dd1-5556-4c03-bef1-9db8ad58232d",
  "project_id": "f0994a28-eec6-45b4-b974-b569f11cfa8d",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "2eb154655954e4c12e0902a5f9b7b225f1732558533b589e15def5fe38382275",
    "byte_length": 38377
  },
  "plan_fingerprint": {
    "sha256": "e708107f409eb55ab5c0fc788d47aa60064b0151961a6178b3d80ca4f9eb047d",
    "byte_length": 16870
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "2eb154655954e4c12e0902a5f9b7b225f1732558533b589e15def5fe38382275",
      "byte_length": 38377
    },
    ".coordination-owner.json": {
      "sha256": "4f3c9802391d98adfca68e5c2cb71803cd22f3e63843dc0bf5c5542474603070",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "24fb6f5ecd21e71d75a764f597710cc709008c5ec142748986948641af6bfa3e",
      "byte_length": 41848
    },
    ".coordination-report.md": {
      "sha256": "64dd405abda3dcd3e5cba9d3a364f6e48b55f3413e729ed422c177b8a7a4d1f1",
      "byte_length": 42163
    },
    ".identity-original.json": {
      "sha256": "cdd45387e0195e65000d8489ebe51a86a7212350cd27f179a2ca6f4679d35dba",
      "byte_length": 1454
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f79e4d12e7c9c81b27cb7925459ebc2cf72eb7cf5ff41158ac20e3c679fc1f26",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "aecac606e7af71cf299c7c825800805da3ff089d7e20246bc3fb4b839cc84659",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "76a10f4cb1489af0e7a106a7c20721125d2045a4474427df37009ca78eae8e69",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "95690e3efd864f632618c836efca40034396a2439bfa72676b3d0a47611591d7",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "86d65c201225dee3deeb9e36b53fa28005510c319770d3f4c509723af8e041f1",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9895e9f73dba1b5b7c142f2ad984a3cd0bd43720063dbe50bd26d310d9f3f9b6",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "647d2e9b5c09fdf2ada5182a9c032772fd0ac72d768b88939938bba6e73078dd",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "159ec996cd8b8f2ac4e7d40afe29fc57540436410fcb5398609c3c626f83a6c8",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "7a3d6beaa7364a50139888fc8fb5d183c8929cea1e930d47387037eee22f52c7",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "33b35a27840af1a0dbcd8dc71e02f0251a8e0dd542ea97c129fc028508430d36",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "7334333f2e8393216256414e258570da15cfc9de0a23d6ce042d6a8ab96b7737",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "2e384235aadf1ff97ce455dc5d9df0821175c60e1281721fa530753c90018fda",
      "byte_length": 615,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-1e9d30a999cba4b177d8d8017ef528db8306b0c8f2f759f5035e41323ca5c1d7",
            "occ-a122c2092e5791e3c1c022aa80c1e904a16025ca7a17ffa595631ac0d412cff2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-a122c2092e5791e3c1c022aa80c1e904a16025ca7a17ffa595631ac0d412cff2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-a122c2092e5791e3c1c022aa80c1e904a16025ca7a17ffa595631ac0d412cff2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 348
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-1e9d30a999cba4b177d8d8017ef528db8306b0c8f2f759f5035e41323ca5c1d7"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 353,
          "end_byte": 361
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-1e9d30a999cba4b177d8d8017ef528db8306b0c8f2f759f5035e41323ca5c1d7"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 439,
          "end_byte": 611
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 362,
          "end_byte": 436
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "c4b9062a7faf7a6e233fb195f9e07ef1b94f6111743d2d19bf56f3ed53c10cda",
      "byte_length": 397,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-a122c2092e5791e3c1c022aa80c1e904a16025ca7a17ffa595631ac0d412cff2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 395
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-1e9d30a999cba4b177d8d8017ef528db8306b0c8f2f759f5035e41323ca5c1d7"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "2eb154655954e4c12e0902a5f9b7b225f1732558533b589e15def5fe38382275",
      "byte_length": 38377
    },
    ".coordination-owner.json": {
      "sha256": "4f3c9802391d98adfca68e5c2cb71803cd22f3e63843dc0bf5c5542474603070",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "24fb6f5ecd21e71d75a764f597710cc709008c5ec142748986948641af6bfa3e",
      "byte_length": 41848
    },
    ".coordination-report.md": {
      "sha256": "64dd405abda3dcd3e5cba9d3a364f6e48b55f3413e729ed422c177b8a7a4d1f1",
      "byte_length": 42163
    },
    ".identity-original.json": {
      "sha256": "cdd45387e0195e65000d8489ebe51a86a7212350cd27f179a2ca6f4679d35dba",
      "byte_length": 1454
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f79e4d12e7c9c81b27cb7925459ebc2cf72eb7cf5ff41158ac20e3c679fc1f26",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "aecac606e7af71cf299c7c825800805da3ff089d7e20246bc3fb4b839cc84659",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "76a10f4cb1489af0e7a106a7c20721125d2045a4474427df37009ca78eae8e69",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "95690e3efd864f632618c836efca40034396a2439bfa72676b3d0a47611591d7",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "86d65c201225dee3deeb9e36b53fa28005510c319770d3f4c509723af8e041f1",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9895e9f73dba1b5b7c142f2ad984a3cd0bd43720063dbe50bd26d310d9f3f9b6",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "647d2e9b5c09fdf2ada5182a9c032772fd0ac72d768b88939938bba6e73078dd",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "159ec996cd8b8f2ac4e7d40afe29fc57540436410fcb5398609c3c626f83a6c8",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "7a3d6beaa7364a50139888fc8fb5d183c8929cea1e930d47387037eee22f52c7",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "33b35a27840af1a0dbcd8dc71e02f0251a8e0dd542ea97c129fc028508430d36",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "7b41142c45aec105d5d6c24e1eb1ca946c2a67ea4145f810c95e27e44ac954db",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "7334333f2e8393216256414e258570da15cfc9de0a23d6ce042d6a8ab96b7737",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "e708107f409eb55ab5c0fc788d47aa60064b0151961a6178b3d80ca4f9eb047d",
      "byte_length": 16870
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "c4b9062a7faf7a6e233fb195f9e07ef1b94f6111743d2d19bf56f3ed53c10cda",
      "byte_length": 397
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "2e384235aadf1ff97ce455dc5d9df0821175c60e1281721fa530753c90018fda",
      "byte_length": 615
    }
  }
}
```
