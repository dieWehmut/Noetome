# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "ee96d2a0-d00f-43e8-a52c-9612dbc4b5ba",
  "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "b8658098cd19232533087fbde9dd7a4bc86a46e43f936f9759091ed8eb183c51",
    "byte_length": 41246
  },
  "plan_fingerprint": {
    "sha256": "ece871335d97d2e1650b084528440ff734614b34e687a27f36baed14f1c9b68a",
    "byte_length": 14692
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "b8658098cd19232533087fbde9dd7a4bc86a46e43f936f9759091ed8eb183c51",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "d23bd08dd173233614fcd610779322dd30cb0b0060c94ec46fc1c5870bd67571",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "bff9a008388d0a1678599aeb093a597655e61605303ac6cac9d2bee7fabb4781",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "5a4605626b8f66dddaea8629f5aae2d01b881446b2736afc704478aa823f7ea8",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "104cf315a47f2bc2a2510095d7f5da4e3b3ef8d3b77ef987a03f1762a7041091",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "7fd92699cba21027aac164089613c38ef277ae3c8142e96baa4961c0ecb61df1",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "c7eff311d197d85d421562ec9a7655b22356bbc4a8b650c0e0c30aa9e390b067",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "d2b19953e88319adbfb20bc565649cdadf44608a7f620b33953ee25d097e9652",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "09ebc0f4c8f0ade45450c0f7ef10137778002db7ffd354cafb4a4191c1ba0002",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "368d32187c0a77597eb5047b6ce473dc97a793595373667406d91aed46725567",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "96a05d1686e3cf20b0831e325ef58318e09a097619cba82f5bbdee55082ffdce",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2a62924b1886bb0999f98377ffa4af5730f51284cb0ed1a91c7bb5beeb37900d",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "5f5a2c7ab18c2f02931b4a41fefa9f46972f6ed5761f77ea1862c43438cf56b2",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "722d36b30ebdb90e5876ba15eca8c01b4cac8d0ff68418a431b1be7e23654a1f",
      "byte_length": 17255
    },
    ".selection-original.json": {
      "sha256": "5237ce1ef22f69e20bd231678d222420f11c589e287f0daebcd913fa981a2433",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-aac6885cdc031cce95675b978209b86622afd24ba286b3bc38fc1604d9c85891"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 33,
          "end_byte": 197
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-81160652500936ea98f8db674270b8466988bc83d82c7ed05d4b919b3477949b"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 273,
          "end_byte": 437
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000001",
          "target_path": "对象-61000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 198,
          "end_byte": 271
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000003",
          "target_path": "对象-61000000-0000-4000-8000-000000000003.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 438,
          "end_byte": 511
        }
      ]
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000001.md",
      "note_id": "object-61000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-aac6885cdc031cce95675b978209b86622afd24ba286b3bc38fc1604d9c85891"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 27,
          "end_byte": 320
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000003.md",
      "note_id": "object-61000000-0000-4000-8000-000000000003",
      "plan_revision": 1,
      "content_sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-81160652500936ea98f8db674270b8466988bc83d82c7ed05d4b919b3477949b"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 29,
          "end_byte": 322
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "b8658098cd19232533087fbde9dd7a4bc86a46e43f936f9759091ed8eb183c51",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "d23bd08dd173233614fcd610779322dd30cb0b0060c94ec46fc1c5870bd67571",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "bff9a008388d0a1678599aeb093a597655e61605303ac6cac9d2bee7fabb4781",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "5a4605626b8f66dddaea8629f5aae2d01b881446b2736afc704478aa823f7ea8",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "104cf315a47f2bc2a2510095d7f5da4e3b3ef8d3b77ef987a03f1762a7041091",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "7fd92699cba21027aac164089613c38ef277ae3c8142e96baa4961c0ecb61df1",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "c7eff311d197d85d421562ec9a7655b22356bbc4a8b650c0e0c30aa9e390b067",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "d2b19953e88319adbfb20bc565649cdadf44608a7f620b33953ee25d097e9652",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "09ebc0f4c8f0ade45450c0f7ef10137778002db7ffd354cafb4a4191c1ba0002",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "368d32187c0a77597eb5047b6ce473dc97a793595373667406d91aed46725567",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "96a05d1686e3cf20b0831e325ef58318e09a097619cba82f5bbdee55082ffdce",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "2a62924b1886bb0999f98377ffa4af5730f51284cb0ed1a91c7bb5beeb37900d",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "5f5a2c7ab18c2f02931b4a41fefa9f46972f6ed5761f77ea1862c43438cf56b2",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "722d36b30ebdb90e5876ba15eca8c01b4cac8d0ff68418a431b1be7e23654a1f",
      "byte_length": 17255
    },
    ".owner.json": {
      "sha256": "261a6c213fb1d9f2ed3f6186ef8f9605104a62f650ab51d47a28b095cbcee312",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "5237ce1ef22f69e20bd231678d222420f11c589e287f0daebcd913fa981a2433",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "ece871335d97d2e1650b084528440ff734614b34e687a27f36baed14f1c9b68a",
      "byte_length": 14692
    },
    "对象-61000000-0000-4000-8000-000000000001.md": {
      "sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322
    },
    "对象-61000000-0000-4000-8000-000000000003.md": {
      "sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324
    },
    "知识比较.md": {
      "sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513
    }
  }
}
```
