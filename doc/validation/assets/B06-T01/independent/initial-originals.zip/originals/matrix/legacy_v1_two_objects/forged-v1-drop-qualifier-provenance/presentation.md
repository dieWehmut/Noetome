# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "1a338682-d5e1-45d5-9e5c-935cc37239c3",
  "project_id": "c1fca462-b60e-4654-9caa-ffbdec8b0830",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "3332084a5f2be320d649b215713160c8cf579aac33efc87ea0988d78e68178a2",
    "byte_length": 38360
  },
  "plan_fingerprint": {
    "sha256": "4229e5e74689e01b8c5e53e4041fb34355a1f47bac2866d57a5bdab287992018",
    "byte_length": 16372
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "3332084a5f2be320d649b215713160c8cf579aac33efc87ea0988d78e68178a2",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "ceaf9f58d1ab76141c7c5e90d3b0802875195609c4df8a82b5277e37538cfb8b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "175eaf16a4a9349090912f71b9d54a4c4965026b3cb3c8c494e53bc4609b10b4",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "d46497ad98ba6abdab6792336d0646e1d106e2370485883556794f8e5bdf21f1",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a41dc3648f1c9b87cd25c8bf46906d581b389c581cd2f2ebf9b0e3713365653d",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "3e840efeaa81caa54c987316c51298cd7f7dad0ec783a2f49152cbb42e16466e",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "42705d06e453a67b548ca7e81a20b885c026d93e30bfe8c1a77c05c93c318ad4",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "10f624a6f98a0d56a4d110d0b5ddf35b5edd335f24598d6c306c3304dffb823f",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "4fef85b064fba9ed5abf946c1fff49382ee41a78720f29fa2da5c67b4e5c7df0",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "cdb4ffbfbd58f18db3645fe8b6bd1ee805ff428cee7ac3df6d03f74a53260867",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6a984281952ef20f5238764d77e5b3e3a76b5a862790ab311aecad0e8c2d0fa5",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9262b25f662033e15af867633cc70d64381c4d8161243faddd33f44d77088db3",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "0c8b897aa4c2d4fa4618dd0c14700c987ec8b943740e192389ace9c93ab6ab50",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "0b5083472fe565d8bf51bc4ff8e811355ebb27470febf768213f0b6b83f86ff1",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "fc549dc767c2b277cde0c571beab9d4ecf9e1e0e8671c1ecb04d6b527bb27d7d",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-8005cc71d2ce2d64991ab80672a835ec7ac11345eb86e472bbc6bc94bdf9120c",
            "occ-d1f8a75ac813b683c07a5c1328cae1b805bcc3913d027a80f2d00fdbff6fafe2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-d1f8a75ac813b683c07a5c1328cae1b805bcc3913d027a80f2d00fdbff6fafe2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-d1f8a75ac813b683c07a5c1328cae1b805bcc3913d027a80f2d00fdbff6fafe2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-8005cc71d2ce2d64991ab80672a835ec7ac11345eb86e472bbc6bc94bdf9120c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 332,
          "end_byte": 340
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-8005cc71d2ce2d64991ab80672a835ec7ac11345eb86e472bbc6bc94bdf9120c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 418,
          "end_byte": 590
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 341,
          "end_byte": 415
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-d1f8a75ac813b683c07a5c1328cae1b805bcc3913d027a80f2d00fdbff6fafe2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-8005cc71d2ce2d64991ab80672a835ec7ac11345eb86e472bbc6bc94bdf9120c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "3332084a5f2be320d649b215713160c8cf579aac33efc87ea0988d78e68178a2",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "ceaf9f58d1ab76141c7c5e90d3b0802875195609c4df8a82b5277e37538cfb8b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "175eaf16a4a9349090912f71b9d54a4c4965026b3cb3c8c494e53bc4609b10b4",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "d46497ad98ba6abdab6792336d0646e1d106e2370485883556794f8e5bdf21f1",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a41dc3648f1c9b87cd25c8bf46906d581b389c581cd2f2ebf9b0e3713365653d",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "3e840efeaa81caa54c987316c51298cd7f7dad0ec783a2f49152cbb42e16466e",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "42705d06e453a67b548ca7e81a20b885c026d93e30bfe8c1a77c05c93c318ad4",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "10f624a6f98a0d56a4d110d0b5ddf35b5edd335f24598d6c306c3304dffb823f",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "4fef85b064fba9ed5abf946c1fff49382ee41a78720f29fa2da5c67b4e5c7df0",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "cdb4ffbfbd58f18db3645fe8b6bd1ee805ff428cee7ac3df6d03f74a53260867",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6a984281952ef20f5238764d77e5b3e3a76b5a862790ab311aecad0e8c2d0fa5",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9262b25f662033e15af867633cc70d64381c4d8161243faddd33f44d77088db3",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "0c8b897aa4c2d4fa4618dd0c14700c987ec8b943740e192389ace9c93ab6ab50",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "0b5083472fe565d8bf51bc4ff8e811355ebb27470febf768213f0b6b83f86ff1",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "88491c0c6341a5ad4bd4367372fea5a7cdd70dffb35b5c9ee720a3db60263594",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "fc549dc767c2b277cde0c571beab9d4ecf9e1e0e8671c1ecb04d6b527bb27d7d",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "4229e5e74689e01b8c5e53e4041fb34355a1f47bac2866d57a5bdab287992018",
      "byte_length": 16372
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594
    }
  }
}
```
