# 有界多来源知识协调

状态：needs_review；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：0；条件未知：1；条件不适用：1；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "70a02cd8-a94d-46a5-b7b0-883d3c0bcbcd",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
  "status": "needs_review",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
        "import_id": "c575f23e-816c-43fb-aeae-5e42b5bf2474",
        "source_id": "03e8566a-d24e-43a8-93e9-8fdb0b5735b1",
        "version_id": "7603be7b-9da2-4121-81eb-3bd22784a038",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "c575f23e-816c-43fb-aeae-5e42b5bf2474",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
              "source_id": "03e8566a-d24e-43a8-93e9-8fdb0b5735b1",
              "version_id": "7603be7b-9da2-4121-81eb-3bd22784a038"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "import_id": "c575f23e-816c-43fb-aeae-5e42b5bf2474",
              "manifest_sha256": null,
              "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
              "parse_id": null,
              "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
              "source_id": "03e8566a-d24e-43a8-93e9-8fdb0b5735b1",
              "version_id": "7603be7b-9da2-4121-81eb-3bd22784a038"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
            "excerpt_start_byte": 0,
            "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
              "excerpt_start_byte": 0,
              "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "e34298f53021b72fa48f008d265084bd1f9f9edc6cdd9df7c3f5dcc854f2b2cc",
          "byte_length": 2714
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "6e2b0aa7a920346bf9ebc93a659d3a69b4447e705bb1ff2b1c6d1eb9c32c7ae3",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "3e764f741540b4963b4752b9aeaa57c380944030c619fbf8682237430e558fe6",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "f68a4e44a1594846f7afe0ed99aebb508a7844266fe0c00218cd2559c8c0eee4",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "72f57ccafcce8585f38f841d1edf67fdc1629df79cf084b31717bc90d739a452",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
        "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
        "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
        "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f",
        "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
              "manifest_sha256": null,
              "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "parse_id": null,
              "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
              "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
              "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
              "manifest_sha256": null,
              "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
              "parse_id": null,
              "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
              "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
              "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 12 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 B 的速度为 12 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 12 m/s。",
          "actual": "样例 B 的速度为 12 m/s。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "e8b4b2a3e4de8cddb6b2b3296e22320bf931a54a0f62a2d1b9ecd642346b09f2",
          "byte_length": 2714
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "e41d8072e1cc4cf84c0cf645f81ceb8b98dd8bbb9c8c4f54a18261aea3c97b5a",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "277fedd4365dde14e292407e60f4aa7321a3953ba84403173505a0da017d4167",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "30ca54751dab6ee8c245cd90611da4b6390c3d6295b19365173d92f379cb52ec",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "b895887fce9a7fd1d1e2601212699ea3f882ce6111ed98bc1191bcdd6cd742eb",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "unknown",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac"
      },
      "occurrence_id": "occ-5dc54fd28152625443399c8954745a977f646f0b6c757886cd4a7cc4147323d9",
      "input_id": "a",
      "binding": {
        "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
        "import_id": "c575f23e-816c-43fb-aeae-5e42b5bf2474",
        "source_id": "03e8566a-d24e-43a8-93e9-8fdb0b5735b1",
        "version_id": "7603be7b-9da2-4121-81eb-3bd22784a038",
        "content_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "normalized_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "40b57499-8a4d-4e33-b07b-95b6f265f1ea",
          "ordinal": 0,
          "resource_sha256": "9310cf19056a924dd47ed5ea11b5a71bfec42716f5c443592bcb768b0d687b1e"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "b69f5fa414bb66646ca7e17b3340a699b2e4cc6a3788d9d3908398c2aa5b21ac",
          "quote": "适用条件：未给出；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
        "sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee"
      },
      "occurrence_id": "occ-ff736e07ad773943eecfc346d317a131d2332815d6f74605f3b24f3b59ad9889",
      "input_id": "b",
      "binding": {
        "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
        "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
        "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
        "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f",
        "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "20499a09-2076-4b66-a24f-f7e4fc22cda0",
          "ordinal": 0,
          "resource_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的速度为 12 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-1cb6452246bd8530c319e5d336f11e2c966ec217796d57498133663bbc1a5e86",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-ff736e07ad773943eecfc346d317a131d2332815d6f74605f3b24f3b59ad9889"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "unknown",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-32cc0e1054ec94edb71045a817112ae79d14330462b9b2b62011bfb34375c8bd",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-5dc54fd28152625443399c8954745a977f646f0b6c757886cd4a7cc4147323d9"
      ],
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ]
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-5dc54fd28152625443399c8954745a977f646f0b6c757886cd4a7cc4147323d9",
      "right_occurrence_id": "occ-ff736e07ad773943eecfc346d317a131d2332815d6f74605f3b24f3b59ad9889",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-5dc54fd28152625443399c8954745a977f646f0b6c757886cd4a7cc4147323d9",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "needs_review",
      "issue_codes": [
        "COORD_UNKNOWN_CONDITION"
      ],
      "action": "retain_for_review",
      "reason": "COORD_UNKNOWN_CONDITION"
    },
    {
      "occurrence_id": "occ-ff736e07ad773943eecfc346d317a131d2332815d6f74605f3b24f3b59ad9889",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 1,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 0,
    "unknown_condition_occurrences": 1,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": null,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 1,
    "failed": 0,
    "needs_review": 1,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d930e56d485e6723b1d876fe3e4d997a357a49d63d09db1313afb94027d037dd",
      "byte_length": 162
    },
    "coordination-original.json": {
      "sha256": "fd624d11e534f38127acf17e4b5caf45312451f80a114bab18e3e97256b4fe16",
      "byte_length": 4326
    },
    "identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "e34298f53021b72fa48f008d265084bd1f9f9edc6cdd9df7c3f5dcc854f2b2cc",
      "byte_length": 2714
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "6e2b0aa7a920346bf9ebc93a659d3a69b4447e705bb1ff2b1c6d1eb9c32c7ae3",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "3e764f741540b4963b4752b9aeaa57c380944030c619fbf8682237430e558fe6",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "f68a4e44a1594846f7afe0ed99aebb508a7844266fe0c00218cd2559c8c0eee4",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "72f57ccafcce8585f38f841d1edf67fdc1629df79cf084b31717bc90d739a452",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "e8b4b2a3e4de8cddb6b2b3296e22320bf931a54a0f62a2d1b9ecd642346b09f2",
      "byte_length": 2714
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    "input-b--knowledge-ir.json": {
      "sha256": "e41d8072e1cc4cf84c0cf645f81ceb8b98dd8bbb9c8c4f54a18261aea3c97b5a",
      "byte_length": 9252
    },
    "input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "277fedd4365dde14e292407e60f4aa7321a3953ba84403173505a0da017d4167",
      "byte_length": 974
    },
    "input-b--verification.json": {
      "sha256": "30ca54751dab6ee8c245cd90611da4b6390c3d6295b19365173d92f379cb52ec",
      "byte_length": 13988
    },
    "input-b--verification.md": {
      "sha256": "b895887fce9a7fd1d1e2601212699ea3f882ce6111ed98bc1191bcdd6cd742eb",
      "byte_length": 14422
    }
  }
}
```
