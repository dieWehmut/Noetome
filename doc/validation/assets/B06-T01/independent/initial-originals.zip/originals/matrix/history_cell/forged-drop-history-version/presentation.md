# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "1f0ce382-7d00-439c-a049-fd6a0449ec02",
  "project_id": "a2eee180-0e81-454a-b11b-4eae7c952955",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "cdfdb76ec7ac7ae87256b70d70cdbd885544a88705da9c812a9813a463752886",
    "byte_length": 61820
  },
  "plan_fingerprint": {
    "sha256": "6f2301479d296260d886eda987c6ad1fb4b0e72d949359efbdbfd3887566bbab",
    "byte_length": 22658
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "cdfdb76ec7ac7ae87256b70d70cdbd885544a88705da9c812a9813a463752886",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "e63dee61478222aab223a8fbc0285bc02bc1706b5299c14f35714011930e11a6",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d9d350eae9ef68be2743a6676592c91b81125ef5317abe0a8801c9d28bc91f1b",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "2699050596ecba97c13696e43131b6c154b27d3a9c27c1cdc413a6a9df3d26c8",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "3ee6873d2ab8ae3e36fd72b6f41d1db24deed39e0f3d08237c62620ff59a5767",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "dcd2040e1b68dc020c01c998c05cab1f337ecf4d3179d7ee77708d684443ea24",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "5645a0e73ffe2fb201937a5d6b5b3e6c09b8a2bd4011dad7c53e3a851ef5521b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "5998566207135055bbd6cc362fcbef7fd80b6ddc1aa808a7fb713a398b0db114",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "61a4335a73db297ef6e7fe4ad56329fb60dc27ed9e2cd50169908a73b08ccdd7",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "64497db7a35f0a5e8949bb56837cba75c2ac08d0b68485a2775178119b762cb8",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "c8add5b54c50e5ad1da04e87b09b93b550abe51101621d6f18efbefc197a658a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4081b9064274f0ee3780cbbe43f99aa37b7bfd0137cb6ddf3ec84d99acd03ab8",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "9661820cd0cb2a016b38f8f715cfd0b644726160503122bc0514c2f009027266",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8b8ed261773537df44e37b588b093a5d1df9f4e9d1c1c888ad974aefd1d477cb",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "1f8c89c098df9f4b8e95d1c00d0f126e5adc4280520448a7758b9a81969fc938",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "00700cb2f0013a807c06781c67eee9315adedde3273c9476ef49bb533f548086",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "7190dafc5f711825d6428f29f08fd74c02dd04c5ee424bf6dfd18aac07060f85",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "596c1cff45aba984475f80238995544908e82df6516da8756e34c20142ba7e6f",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "a2b45534b521def791dd05b951416e542d4457bc460b281b721b12e4eda35441",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "7eb5784295064823a412b54366bf4a51ff9c2045ea4bed98aefa8c81f00dadf9",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "211e25fe70e8827c0eef3c80cf1f756006e4024bc1d326fd9b24bffc25c8acdb",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-170f46808886abb005b7d3963b234c637b1796e6d6060986ef0efe3a9c3ffe16",
            "occ-2b05eb34c12b8ab524e06cda371358a12a05d9b83a5dc44fdae3a5264a69a57c",
            "occ-6c216ab33b04174e14c91ccd8ae3bc0cc32873e83d296dd3ee01a89bf66660cc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2b05eb34c12b8ab524e06cda371358a12a05d9b83a5dc44fdae3a5264a69a57c",
            "occ-6c216ab33b04174e14c91ccd8ae3bc0cc32873e83d296dd3ee01a89bf66660cc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-2b05eb34c12b8ab524e06cda371358a12a05d9b83a5dc44fdae3a5264a69a57c",
            "occ-6c216ab33b04174e14c91ccd8ae3bc0cc32873e83d296dd3ee01a89bf66660cc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-170f46808886abb005b7d3963b234c637b1796e6d6060986ef0efe3a9c3ffe16"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-170f46808886abb005b7d3963b234c637b1796e6d6060986ef0efe3a9c3ffe16"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-2b05eb34c12b8ab524e06cda371358a12a05d9b83a5dc44fdae3a5264a69a57c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-6c216ab33b04174e14c91ccd8ae3bc0cc32873e83d296dd3ee01a89bf66660cc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-170f46808886abb005b7d3963b234c637b1796e6d6060986ef0efe3a9c3ffe16"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "cdfdb76ec7ac7ae87256b70d70cdbd885544a88705da9c812a9813a463752886",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "e63dee61478222aab223a8fbc0285bc02bc1706b5299c14f35714011930e11a6",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d9d350eae9ef68be2743a6676592c91b81125ef5317abe0a8801c9d28bc91f1b",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "2699050596ecba97c13696e43131b6c154b27d3a9c27c1cdc413a6a9df3d26c8",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "3ee6873d2ab8ae3e36fd72b6f41d1db24deed39e0f3d08237c62620ff59a5767",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "dcd2040e1b68dc020c01c998c05cab1f337ecf4d3179d7ee77708d684443ea24",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "5645a0e73ffe2fb201937a5d6b5b3e6c09b8a2bd4011dad7c53e3a851ef5521b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "5998566207135055bbd6cc362fcbef7fd80b6ddc1aa808a7fb713a398b0db114",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "61a4335a73db297ef6e7fe4ad56329fb60dc27ed9e2cd50169908a73b08ccdd7",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "64497db7a35f0a5e8949bb56837cba75c2ac08d0b68485a2775178119b762cb8",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "c8add5b54c50e5ad1da04e87b09b93b550abe51101621d6f18efbefc197a658a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4081b9064274f0ee3780cbbe43f99aa37b7bfd0137cb6ddf3ec84d99acd03ab8",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "9661820cd0cb2a016b38f8f715cfd0b644726160503122bc0514c2f009027266",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8b8ed261773537df44e37b588b093a5d1df9f4e9d1c1c888ad974aefd1d477cb",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "1f8c89c098df9f4b8e95d1c00d0f126e5adc4280520448a7758b9a81969fc938",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "00700cb2f0013a807c06781c67eee9315adedde3273c9476ef49bb533f548086",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "7190dafc5f711825d6428f29f08fd74c02dd04c5ee424bf6dfd18aac07060f85",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "596c1cff45aba984475f80238995544908e82df6516da8756e34c20142ba7e6f",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "a2b45534b521def791dd05b951416e542d4457bc460b281b721b12e4eda35441",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "5d68c39234bb908ed5f0645d30b9628f6fa911431584455ebac45dfacc4ac11d",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "7eb5784295064823a412b54366bf4a51ff9c2045ea4bed98aefa8c81f00dadf9",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "6f2301479d296260d886eda987c6ad1fb4b0e72d949359efbdbfd3887566bbab",
      "byte_length": 22658
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "211e25fe70e8827c0eef3c80cf1f756006e4024bc1d326fd9b24bffc25c8acdb",
      "byte_length": 542
    }
  }
}
```
