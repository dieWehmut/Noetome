# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "3f4d327b-f32c-4e2e-9f02-de683dbf9ccd",
  "project_id": "58235b12-7205-44e4-a3f7-78ae7789f5f6",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "299f10c1c90ed7cfdd98572085cf8e2ebdaadb5d679a9848b68185201ce8c833",
    "byte_length": 41373
  },
  "plan_fingerprint": {
    "sha256": "2198ad83b3b845f75ac3c27a61936ef9faf7ae49f900aaad272161487d6c957a",
    "byte_length": 14709
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "299f10c1c90ed7cfdd98572085cf8e2ebdaadb5d679a9848b68185201ce8c833",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "00afb55065722fa4b3e526227879978a9483736de9e7f4f072932d2dbefcf320",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "bb4d9c8d103ee0ca49482e9be1a121310b962b016fb7ad15e3041dc141b213f1",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "199c07e8e5ee0a642c2c46dc15a4a1f7ece24e6ad84ec375be48e8aa895254d6",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "87acf47471998f1521a26ed02d2478845fd471239c591e36e1671f65f4279f5c",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "63f3b7f366f001a982ea34bf5268064868422e45be66a4b65637b643295844cf",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9ac5bc24ed66343e506fbc7546b8b77b998c4a846488dc8e5b9051b6c1b7de21",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "df13d9dfe9eeffea1a988f1ac737ededffaca6d0ecc1f938e8f8e0504b5c58ac",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "564f3b8d0240757d30438323be43011ace42e49b987d62571b6d135097c15978",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "15baa364caab8620b83efa8c73e6be233c12487cdf9701e15c9fe3239ebc7f2e",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "cd06e4b6340a065ade670f6a78e521ad17ea86c5f53dbe7ee481694a6c639e0e",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "a1ea7a5b64bf0afee1d0e8ce5971f6508abeeaa080e8dac41f3e96f1ff17292b",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "138f64b4c0102d829f70dc149932ad6288f073d684d62d35a8b710e2561db064",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "aea8b18194348d3f048f8ccadb9b521f87643f78b815b3d70c3117844c6f64a6",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "522e042dfdf9e21ff54ec6e154bdf2e85ba36c9faa7afa0173aa8899cb2916d3",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-f055c585c34fb50592b674b91ebb946bc49e7fb2d660b0ad8541c70830f22242"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-61bf9b4c7b3ac9dba66bfa1cd78107d0e2e697effa6ec8ae84a496b3304df744"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-61bf9b4c7b3ac9dba66bfa1cd78107d0e2e697effa6ec8ae84a496b3304df744"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-f055c585c34fb50592b674b91ebb946bc49e7fb2d660b0ad8541c70830f22242"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "299f10c1c90ed7cfdd98572085cf8e2ebdaadb5d679a9848b68185201ce8c833",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "00afb55065722fa4b3e526227879978a9483736de9e7f4f072932d2dbefcf320",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "bb4d9c8d103ee0ca49482e9be1a121310b962b016fb7ad15e3041dc141b213f1",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "199c07e8e5ee0a642c2c46dc15a4a1f7ece24e6ad84ec375be48e8aa895254d6",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "87acf47471998f1521a26ed02d2478845fd471239c591e36e1671f65f4279f5c",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "63f3b7f366f001a982ea34bf5268064868422e45be66a4b65637b643295844cf",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9ac5bc24ed66343e506fbc7546b8b77b998c4a846488dc8e5b9051b6c1b7de21",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "df13d9dfe9eeffea1a988f1ac737ededffaca6d0ecc1f938e8f8e0504b5c58ac",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "564f3b8d0240757d30438323be43011ace42e49b987d62571b6d135097c15978",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "15baa364caab8620b83efa8c73e6be233c12487cdf9701e15c9fe3239ebc7f2e",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "cd06e4b6340a065ade670f6a78e521ad17ea86c5f53dbe7ee481694a6c639e0e",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "a1ea7a5b64bf0afee1d0e8ce5971f6508abeeaa080e8dac41f3e96f1ff17292b",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "138f64b4c0102d829f70dc149932ad6288f073d684d62d35a8b710e2561db064",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "aea8b18194348d3f048f8ccadb9b521f87643f78b815b3d70c3117844c6f64a6",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "0c5ebc131422b120097450e14098538820a7e4e8e82f24bcdaf6ea69f36b92bc",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "522e042dfdf9e21ff54ec6e154bdf2e85ba36c9faa7afa0173aa8899cb2916d3",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "2198ad83b3b845f75ac3c27a61936ef9faf7ae49f900aaad272161487d6c957a",
      "byte_length": 14709
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323
    },
    "知识比较.md": {
      "sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514
    }
  }
}
```
