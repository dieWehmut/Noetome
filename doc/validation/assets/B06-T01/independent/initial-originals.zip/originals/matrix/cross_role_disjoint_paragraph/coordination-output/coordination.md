# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "2d6e5768-6000-41fa-ba40-2133abef12be",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "61000000-0000-4000-8000-000000000001",
      "display_name": "速度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000002",
      "display_name": "密度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000003",
      "display_name": "样例 B"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
        "import_id": "0995d847-adb0-415d-9c76-ec08c1b9956d",
        "source_id": "7be545e9-07c5-4a1e-bb06-49506075ae10",
        "version_id": "ca2927bf-eb9a-4ce6-8c6f-9ef082befc4b",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-density"
            ],
            "decision": {
              "atom_ids": [
                "a-density"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "0995d847-adb0-415d-9c76-ec08c1b9956d",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
              "source_id": "7be545e9-07c5-4a1e-bb06-49506075ae10",
              "version_id": "ca2927bf-eb9a-4ce6-8c6f-9ef082befc4b"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "0995d847-adb0-415d-9c76-ec08c1b9956d",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
              "source_id": "7be545e9-07c5-4a1e-bb06-49506075ae10",
              "version_id": "ca2927bf-eb9a-4ce6-8c6f-9ef082befc4b"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "速度",
              "密度"
            ],
            "compound": "速度 密度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "密度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "kg/m³",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "kg/m³",
          "actual": {
            "measurement": "kg/m³",
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg/m³"
          },
          "actual": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "104cf315a47f2bc2a2510095d7f5da4e3b3ef8d3b77ef987a03f1762a7041091",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
          "byte_length": 143
        },
        "gold-original.json": {
          "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "7fd92699cba21027aac164089613c38ef277ae3c8142e96baa4961c0ecb61df1",
          "byte_length": 12391
        },
        "review-original.json": {
          "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
          "byte_length": 508
        },
        "source-snapshot.json": {
          "sha256": "c7eff311d197d85d421562ec9a7655b22356bbc4a8b650c0e0c30aa9e390b067",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "d2b19953e88319adbfb20bc565649cdadf44608a7f620b33953ee25d097e9652",
          "byte_length": 16868
        },
        "verification.md": {
          "sha256": "09ebc0f4c8f0ade45450c0f7ef10137778002db7ffd354cafb4a4191c1ba0002",
          "byte_length": 17302
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
        "import_id": "bbe9d2ef-c5f3-474a-86fa-4f443b1f2bf8",
        "source_id": "41f6ec7e-de2a-4392-98bf-ea61c245485c",
        "version_id": "928352ff-bbbd-4e9f-8c61-a91ed6f70630",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "bbe9d2ef-c5f3-474a-86fa-4f443b1f2bf8",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
              "source_id": "41f6ec7e-de2a-4392-98bf-ea61c245485c",
              "version_id": "928352ff-bbbd-4e9f-8c61-a91ed6f70630"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "bbe9d2ef-c5f3-474a-86fa-4f443b1f2bf8",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
              "source_id": "41f6ec7e-de2a-4392-98bf-ea61c245485c",
              "version_id": "928352ff-bbbd-4e9f-8c61-a91ed6f70630"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "368d32187c0a77597eb5047b6ce473dc97a793595373667406d91aed46725567",
          "byte_length": 3047
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "96a05d1686e3cf20b0831e325ef58318e09a097619cba82f5bbdee55082ffdce",
          "byte_length": 12339
        },
        "review-original.json": {
          "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "2a62924b1886bb0999f98377ffa4af5730f51284cb0ed1a91c7bb5beeb37900d",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "5f5a2c7ab18c2f02931b4a41fefa9f46972f6ed5761f77ea1862c43438cf56b2",
          "byte_length": 16821
        },
        "verification.md": {
          "sha256": "722d36b30ebdb90e5876ba15eca8c01b4cac8d0ff68418a431b1be7e23654a1f",
          "byte_length": 17255
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a"
      },
      "occurrence_id": "occ-81160652500936ea98f8db674270b8466988bc83d82c7ed05d4b919b3477949b",
      "input_id": "b",
      "binding": {
        "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
        "import_id": "bbe9d2ef-c5f3-474a-86fa-4f443b1f2bf8",
        "source_id": "41f6ec7e-de2a-4392-98bf-ea61c245485c",
        "version_id": "928352ff-bbbd-4e9f-8c61-a91ed6f70630",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "e66cd3b0-8bd9-4b77-b7b4-71ff77328bf0",
          "ordinal": 0,
          "resource_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000003"
      ],
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2"
      },
      "occurrence_id": "occ-aac6885cdc031cce95675b978209b86622afd24ba286b3bc38fc1604d9c85891",
      "input_id": "a",
      "binding": {
        "project_id": "6e20e32e-9a4a-45b4-847b-e8c1a9628107",
        "import_id": "0995d847-adb0-415d-9c76-ec08c1b9956d",
        "source_id": "7be545e9-07c5-4a1e-bb06-49506075ae10",
        "version_id": "ca2927bf-eb9a-4ce6-8c6f-9ef082befc4b",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "42b9c901-68c6-47d4-9dff-0a0a4cf62f54",
          "ordinal": 0,
          "resource_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "密度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-density",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg/m³",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
          "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000002"
      ],
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value": "2",
      "unit_value": "kg/m³",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "2",
      "unit": "kg/m³",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-aac6885cdc031cce95675b978209b86622afd24ba286b3bc38fc1604d9c85891"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-81160652500936ea98f8db674270b8466988bc83d82c7ed05d4b919b3477949b"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-81160652500936ea98f8db674270b8466988bc83d82c7ed05d4b919b3477949b",
      "right_occurrence_id": "occ-aac6885cdc031cce95675b978209b86622afd24ba286b3bc38fc1604d9c85891",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-81160652500936ea98f8db674270b8466988bc83d82c7ed05d4b919b3477949b",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-aac6885cdc031cce95675b978209b86622afd24ba286b3bc38fc1604d9c85891",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d23bd08dd173233614fcd610779322dd30cb0b0060c94ec46fc1c5870bd67571",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "b8658098cd19232533087fbde9dd7a4bc86a46e43f936f9759091ed8eb183c51",
      "byte_length": 41246
    },
    "coordination-original.json": {
      "sha256": "5237ce1ef22f69e20bd231678d222420f11c589e287f0daebcd913fa981a2433",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "104cf315a47f2bc2a2510095d7f5da4e3b3ef8d3b77ef987a03f1762a7041091",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    "input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "7fd92699cba21027aac164089613c38ef277ae3c8142e96baa4961c0ecb61df1",
      "byte_length": 12391
    },
    "input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    "input-a--source-snapshot.json": {
      "sha256": "c7eff311d197d85d421562ec9a7655b22356bbc4a8b650c0e0c30aa9e390b067",
      "byte_length": 1053
    },
    "input-a--verification.json": {
      "sha256": "d2b19953e88319adbfb20bc565649cdadf44608a7f620b33953ee25d097e9652",
      "byte_length": 16868
    },
    "input-a--verification.md": {
      "sha256": "09ebc0f4c8f0ade45450c0f7ef10137778002db7ffd354cafb4a4191c1ba0002",
      "byte_length": 17302
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "368d32187c0a77597eb5047b6ce473dc97a793595373667406d91aed46725567",
      "byte_length": 3047
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "96a05d1686e3cf20b0831e325ef58318e09a097619cba82f5bbdee55082ffdce",
      "byte_length": 12339
    },
    "input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "2a62924b1886bb0999f98377ffa4af5730f51284cb0ed1a91c7bb5beeb37900d",
      "byte_length": 1053
    },
    "input-b--verification.json": {
      "sha256": "5f5a2c7ab18c2f02931b4a41fefa9f46972f6ed5761f77ea1862c43438cf56b2",
      "byte_length": 16821
    },
    "input-b--verification.md": {
      "sha256": "722d36b30ebdb90e5876ba15eca8c01b4cac8d0ff68418a431b1be7e23654a1f",
      "byte_length": 17255
    }
  }
}
```
