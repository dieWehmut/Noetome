# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "6b25b26f-02d0-46cb-a5d6-55dcd98654df",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000005",
      "display_name": "甲容器 [α]"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000006",
      "display_name": "乙容器（β）"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000007",
      "display_name": "速率 | 测量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
        "import_id": "9433870e-f577-423d-be4e-1fcfe355311c",
        "source_id": "6282efed-a63f-43db-b977-96112281fccb",
        "version_id": "586aa48b-fc46-42a9-acb2-b2ea9060abaf",
        "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "import_id": "9433870e-f577-423d-be4e-1fcfe355311c",
              "manifest_sha256": null,
              "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "parse_id": null,
              "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
              "source_id": "6282efed-a63f-43db-b977-96112281fccb",
              "version_id": "586aa48b-fc46-42a9-acb2-b2ea9060abaf"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "import_id": "9433870e-f577-423d-be4e-1fcfe355311c",
              "manifest_sha256": null,
              "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
              "parse_id": null,
              "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
              "source_id": "6282efed-a63f-43db-b977-96112281fccb",
              "version_id": "586aa48b-fc46-42a9-acb2-b2ea9060abaf"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 176,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 177,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 176,
            "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 176,
            "quote": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 176,
              "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "甲容器 [α]",
              "速率 | 测量"
            ],
            "compound": "甲容器 [α] 速率 | 测量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "甲容器 [α]",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速率 | 测量",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "actual": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "x < 2",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "计数范围 [1,2]",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          },
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": "读数 * 异常时不适用",
          "actual": {
            "body": [
              "读数*异常时不适用"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": [
            "读数 * 异常时不适用"
          ],
          "actual": [
            "读数*异常时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 177,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "contexts": [],
            "exceptions": [
              "读数 * 异常时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "ed2cbc74d6967ba8fcc5295f14d394b3cbb092e1ca4470bd08a9e3ee9c5b5826",
          "byte_length": 3077
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
          "byte_length": 780
        },
        "knowledge-ir.json": {
          "sha256": "fcb0bb52f9ec696eb0b409b864786402dc682bc40abad20fbcf57b110df737fb",
          "byte_length": 12416
        },
        "review-original.json": {
          "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
          "byte_length": 525
        },
        "source-snapshot.json": {
          "sha256": "fd8f93d016daf5a558a2689a4c33f9f8b3aa647ac07bf44ca28953267aa3e255",
          "byte_length": 1067
        },
        "verification.json": {
          "sha256": "de051b969a7c9d20b2d4df9f809b72cb10716bf8a2c57c3a768c95eb4c3e5524",
          "byte_length": 16897
        },
        "verification.md": {
          "sha256": "56fd70203710aeb9035daac65aeaf5a38807643990d8beca8d0af89d2d86b32d",
          "byte_length": 17331
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
        "import_id": "6884db6a-fa95-4280-b35d-f32d2312188a",
        "source_id": "ace1cf3c-9b6b-403e-9da0-b28866fe967a",
        "version_id": "a40fb9fc-11c0-4329-af69-27651f3645e1",
        "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "import_id": "6884db6a-fa95-4280-b35d-f32d2312188a",
              "manifest_sha256": null,
              "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "parse_id": null,
              "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
              "source_id": "ace1cf3c-9b6b-403e-9da0-b28866fe967a",
              "version_id": "a40fb9fc-11c0-4329-af69-27651f3645e1"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "import_id": "6884db6a-fa95-4280-b35d-f32d2312188a",
              "manifest_sha256": null,
              "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
              "parse_id": null,
              "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
              "source_id": "ace1cf3c-9b6b-403e-9da0-b28866fe967a",
              "version_id": "a40fb9fc-11c0-4329-af69-27651f3645e1"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 179,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 180,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 179,
            "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 179,
            "quote": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 179,
              "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "乙容器（β）",
              "速率 | 测量"
            ],
            "compound": "乙容器（β） 速率 | 测量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "乙容器（β）",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速率 | 测量",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "actual": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "x < 2",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "计数范围 [1,2]",
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          },
          "actual": {
            "body": [
              "x<2",
              "计数范围[1,2]"
            ],
            "measurement": [
              "x < 2",
              "计数范围 [1,2]"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": "读数 * 异常时不适用",
          "actual": {
            "body": [
              "读数*异常时不适用"
            ],
            "qualifiers": [
              "m/s",
              "x < 2",
              "计数范围 [1,2]",
              "读数 * 异常时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": [
            "读数 * 异常时不适用"
          ],
          "actual": [
            "读数*异常时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 180,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "x < 2",
              "计数范围 [1,2]"
            ],
            "contexts": [],
            "exceptions": [
              "读数 * 异常时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "e3e3a1c62ad7b152daa5e6331ec90a1661d75bdfef8806a73ccea2a518ac78dc",
          "byte_length": 3086
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
          "byte_length": 789
        },
        "knowledge-ir.json": {
          "sha256": "8058dbc6fe39b5add89db3b2580898168ee06b3c26662ed5f8677a99846cd797",
          "byte_length": 12452
        },
        "review-original.json": {
          "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
          "byte_length": 528
        },
        "source-snapshot.json": {
          "sha256": "df7d3ef7ed9ed7e1b960b4483bc75992c9fcf6310ff63370fb9288292849cc02",
          "byte_length": 1070
        },
        "verification.json": {
          "sha256": "d793850bb65cb34314ab39807dd809025263042d7121ec5dc5d6e11bb28b9ed7",
          "byte_length": 16930
        },
        "verification.md": {
          "sha256": "99d60b376e105195a1f4936b3def057269d543e2a1bbdc3827964fbdc7c2d3f2",
          "byte_length": 17364
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 176,
        "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
        "sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42"
      },
      "occurrence_id": "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f",
      "input_id": "a",
      "binding": {
        "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
        "import_id": "9433870e-f577-423d-be4e-1fcfe355311c",
        "source_id": "6282efed-a63f-43db-b977-96112281fccb",
        "version_id": "586aa48b-fc46-42a9-acb2-b2ea9060abaf",
        "content_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "normalized_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "b207d017-2384-476e-ba0a-d650ab346f9d",
          "ordinal": 0,
          "resource_sha256": "c2a0447c053b2ccb076ee273568856828cc2d16fb713e2f324f9970d6bfdb0cf"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 177,
        "text": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "甲容器 [α]",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速率 | 测量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "qualifiers": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "x < 2",
            "计数范围 [1,2]"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 176,
          "excerpt_sha256": "b67360ce6cd96e91121b8af407bbe2e5bdf099336d4946be5505166b168d7d42",
          "quote": "适用条件：已列明；观点时间：2020年。\n甲容器 [α] 的速率 | 测量为 10 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000005",
        "60000000-0000-4000-8000-000000000007"
      ],
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "x < 2",
        "计数范围 [1,2]"
      ],
      "exceptions": [
        "读数 * 异常时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 179,
        "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
        "sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8"
      },
      "occurrence_id": "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3",
      "input_id": "b",
      "binding": {
        "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
        "import_id": "6884db6a-fa95-4280-b35d-f32d2312188a",
        "source_id": "ace1cf3c-9b6b-403e-9da0-b28866fe967a",
        "version_id": "a40fb9fc-11c0-4329-af69-27651f3645e1",
        "content_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "normalized_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "cc32033e-b405-465b-bdf1-8061ed67e0a2",
          "ordinal": 0,
          "resource_sha256": "4f1961d4828189ea71b8fa887bb7ca12dde10e7ec3e43c87e8fe8df4ec10bc72"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 180,
        "text": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "乙容器（β）",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速率 | 测量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。",
          "qualifiers": [
            "m/s",
            "x < 2",
            "计数范围 [1,2]",
            "读数 * 异常时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "x < 2",
            "计数范围 [1,2]"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 179,
          "excerpt_sha256": "b3b6dd354ea7c76f48b89b2d4e8ea5706ef9c146d12563edb8027ed961c356a8",
          "quote": "适用条件：已列明；观点时间：2020年。\n乙容器（β） 的速率 | 测量为 12 m/s，条件为x < 2且计数范围 [1,2]；例外为读数 * 异常时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000006",
        "60000000-0000-4000-8000-000000000007"
      ],
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "x < 2",
        "计数范围 [1,2]"
      ],
      "exceptions": [
        "读数 * 异常时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4",
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "x<2",
        "计数范围[1,2]"
      ],
      "exceptions": [
        "读数*异常时不适用"
      ],
      "occurrence_ids": [
        "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1",
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "x<2",
        "计数范围[1,2]"
      ],
      "exceptions": [
        "读数*异常时不适用"
      ],
      "occurrence_ids": [
        "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f",
      "right_occurrence_id": "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f",
      "object_id": "60000000-0000-4000-8000-000000000005",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3",
      "object_id": "60000000-0000-4000-8000-000000000006",
      "property_id": "60000000-0000-4000-8000-000000000007",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d853c7cc6c4effe062fde108e2ead9f7273175bc892be83af2ca3e5ed7058c2b",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "58d316704ff7992a3ce8c27d499697473a47b42e286340dd022d16b0c6b73f44",
      "byte_length": 41454
    },
    "coordination-original.json": {
      "sha256": "711230ee2036e63e278ab3e7f052755fd85feef4ade577e52053d17fe83b69b3",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "ed2cbc74d6967ba8fcc5295f14d394b3cbb092e1ca4470bd08a9e3ee9c5b5826",
      "byte_length": 3077
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    "input-a--knowledge-ir.json": {
      "sha256": "fcb0bb52f9ec696eb0b409b864786402dc682bc40abad20fbcf57b110df737fb",
      "byte_length": 12416
    },
    "input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    "input-a--source-snapshot.json": {
      "sha256": "fd8f93d016daf5a558a2689a4c33f9f8b3aa647ac07bf44ca28953267aa3e255",
      "byte_length": 1067
    },
    "input-a--verification.json": {
      "sha256": "de051b969a7c9d20b2d4df9f809b72cb10716bf8a2c57c3a768c95eb4c3e5524",
      "byte_length": 16897
    },
    "input-a--verification.md": {
      "sha256": "56fd70203710aeb9035daac65aeaf5a38807643990d8beca8d0af89d2d86b32d",
      "byte_length": 17331
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "e3e3a1c62ad7b152daa5e6331ec90a1661d75bdfef8806a73ccea2a518ac78dc",
      "byte_length": 3086
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    "input-b--knowledge-ir.json": {
      "sha256": "8058dbc6fe39b5add89db3b2580898168ee06b3c26662ed5f8677a99846cd797",
      "byte_length": 12452
    },
    "input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    "input-b--source-snapshot.json": {
      "sha256": "df7d3ef7ed9ed7e1b960b4483bc75992c9fcf6310ff63370fb9288292849cc02",
      "byte_length": 1070
    },
    "input-b--verification.json": {
      "sha256": "d793850bb65cb34314ab39807dd809025263042d7121ec5dc5d6e11bb28b9ed7",
      "byte_length": 16930
    },
    "input-b--verification.md": {
      "sha256": "99d60b376e105195a1f4936b3def057269d543e2a1bbdc3827964fbdc7c2d3f2",
      "byte_length": 17364
    }
  }
}
```
