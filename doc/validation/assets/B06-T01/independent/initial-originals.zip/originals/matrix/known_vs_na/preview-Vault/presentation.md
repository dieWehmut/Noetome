# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "be3960cf-75a5-452e-b2d8-e41eab5b4cef",
  "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "db560c589077f99b3070132276cf75722add6785b6b9771873fc8b312d7b966c",
    "byte_length": 37417
  },
  "plan_fingerprint": {
    "sha256": "e5f9c213184e35d94c6c9d38bf78130044a1fe52fa35d3b90f389fc58dea1ae3",
    "byte_length": 16487
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "db560c589077f99b3070132276cf75722add6785b6b9771873fc8b312d7b966c",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "73faad854cb2a0d5257aa152599ebb78eccb08442f5441e6eda85ea73f1293f9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d2db4cbaf4dcded5e0b2c02e52633a0868216667d3c216b46c7a67697281a6fa",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "f1c6ef74b0895668e5614d1bc271b646f860d9eb5c461f11f857c3d7c94b9a5e",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a5bcfb7e205d4db59acaa62751d317283b6ff7cafc7c6ae69c55d0705fc03ab8",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a40edc4537f27ccc2cdb39e3176264a9a4ecf188c275f6e8a8491cede01ee416",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "670cd8657908861e43378d96d1400db021b8d7ed05b98d204abc7112880eb2eb",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "5747a3708f924b6f93d27b93d433e1ae9726076ea401f41f6025c8a5000ed12c",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "4d4eba4486e11c9683d986b560535eeaf6cbc7c71a3c0b410b79facb163bbf63",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "da788fc24f2c59ec628cf115b1380dba81a38571a34f7a65f63c621dcbb72ddc",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d293fca2e4e4f31a3afb3deaf8f5245437c5eb5620a70a4dcef11251dc910f5a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "5539ea0e596bad449f3932a1100172292549c4f0a1db2f08dfb6d64efe783ca6",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "3b7a260041465b6af106ffb352f8124fef436906d5f01c2c508ec0bf894663ec",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "cbdb0bc6f8a3d059932f1540a314fad68cdcccf6d85cca841a26009635e33226",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "b751fe9b6fc0952aec5c340872b010e7dc1b7ba8b5b80872fbdc0e99759d2297",
      "byte_length": 4328
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2",
            "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 262
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 267,
          "end_byte": 275
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 353,
          "end_byte": 499
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 276,
          "end_byte": 350
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 207
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "db560c589077f99b3070132276cf75722add6785b6b9771873fc8b312d7b966c",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "73faad854cb2a0d5257aa152599ebb78eccb08442f5441e6eda85ea73f1293f9",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "d2db4cbaf4dcded5e0b2c02e52633a0868216667d3c216b46c7a67697281a6fa",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "f1c6ef74b0895668e5614d1bc271b646f860d9eb5c461f11f857c3d7c94b9a5e",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a5bcfb7e205d4db59acaa62751d317283b6ff7cafc7c6ae69c55d0705fc03ab8",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "a40edc4537f27ccc2cdb39e3176264a9a4ecf188c275f6e8a8491cede01ee416",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "670cd8657908861e43378d96d1400db021b8d7ed05b98d204abc7112880eb2eb",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "5747a3708f924b6f93d27b93d433e1ae9726076ea401f41f6025c8a5000ed12c",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "4d4eba4486e11c9683d986b560535eeaf6cbc7c71a3c0b410b79facb163bbf63",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "da788fc24f2c59ec628cf115b1380dba81a38571a34f7a65f63c621dcbb72ddc",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d293fca2e4e4f31a3afb3deaf8f5245437c5eb5620a70a4dcef11251dc910f5a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "5539ea0e596bad449f3932a1100172292549c4f0a1db2f08dfb6d64efe783ca6",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "3b7a260041465b6af106ffb352f8124fef436906d5f01c2c508ec0bf894663ec",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "cbdb0bc6f8a3d059932f1540a314fad68cdcccf6d85cca841a26009635e33226",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "e51b0c5ccea41ced1669a06604cf105ea2188136e7b266e0b40657e76372844c",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "b751fe9b6fc0952aec5c340872b010e7dc1b7ba8b5b80872fbdc0e99759d2297",
      "byte_length": 4328
    },
    "plan.json": {
      "sha256": "e5f9c213184e35d94c6c9d38bf78130044a1fe52fa35d3b90f389fc58dea1ae3",
      "byte_length": 16487
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503
    }
  }
}
```
