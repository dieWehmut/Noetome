# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "b3bd4dc3-46b5-4961-bc14-9046af9ded7e",
  "project_id": "e037b259-547c-43be-8924-85aca73d8d9b",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "74bba4b6c5bc080affb02a91320f5cc97cf98957a71f005e48944bf6e9cba181",
    "byte_length": 40500
  },
  "plan_fingerprint": {
    "sha256": "115507b897b059fd39db3b310d40f60fea7a84855fb2f136482848e124729d04",
    "byte_length": 17586
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "74bba4b6c5bc080affb02a91320f5cc97cf98957a71f005e48944bf6e9cba181",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "3d770c44b3205844172a13132a04fb1145b5a8abeaa0dd2963de6330c98624f0",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "2e9effef2dab5fbb06b111642a91632000ad77485efeb503ebf9971f95eb857a",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "1cee5e52f1fc2ff7c503ac44346bec028b5c362685c9f253d91754b4afe5fc5f",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "82b440a71b5db4e9468175b5d2a59e0c76721d7b38a69f133c925fc999aba7a9",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "9bbd3f5ddb5fe96dae57e92f8da258843c9def4475a9460fe98e646ed244289b",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "76e71304619e6f27519668d73feffdcdf79c04a04c34bb98629b695f983c3f98",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "a7dc83716d4888833bb76a1eaebec5a448603c02d2c4c2c9b3e6b898d61b06d8",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "2f7fd0312f471c208d8aa78272f9c563ec6f61387a955ac2db89148b6b2366f5",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "b43b6071c37c44f316dad476eb3c57d06987c6c49403b3b3c5bb1eea3e6869db",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "83bdfb572020fe24996f2981f62335f86f5a1b1705e62d283d5ad2e2cb43042c",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "d31a3a54acd8dbecc432b20630f5c3e7e68f7f0ad4f0349837c5ea6892c4886e",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "8727655b44010d4ec1f34e6ab629a6106a6c9685ee2ee3972d7bb838088b0882",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "22b73125032d441c69712d0a6c4efe8396068cf9b0266df4f120ab0aebbc1fc2",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "9281e1ab5c87aaaff8cc6e6f9ef06f3a4be22be0a4260000ed9dbcf49f5e1754",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-7d280418da29981d9911d983ddfdeffdab51b10632682bcd7d1590e0a229e362",
            "occ-bc2a2d1335f368f4fe523be2d45ee056772b48f34eb7ca599093eae4f8d13db6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-7d280418da29981d9911d983ddfdeffdab51b10632682bcd7d1590e0a229e362"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-7d280418da29981d9911d983ddfdeffdab51b10632682bcd7d1590e0a229e362"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-bc2a2d1335f368f4fe523be2d45ee056772b48f34eb7ca599093eae4f8d13db6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-bc2a2d1335f368f4fe523be2d45ee056772b48f34eb7ca599093eae4f8d13db6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-7d280418da29981d9911d983ddfdeffdab51b10632682bcd7d1590e0a229e362"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-bc2a2d1335f368f4fe523be2d45ee056772b48f34eb7ca599093eae4f8d13db6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "74bba4b6c5bc080affb02a91320f5cc97cf98957a71f005e48944bf6e9cba181",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "3d770c44b3205844172a13132a04fb1145b5a8abeaa0dd2963de6330c98624f0",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "2e9effef2dab5fbb06b111642a91632000ad77485efeb503ebf9971f95eb857a",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "1cee5e52f1fc2ff7c503ac44346bec028b5c362685c9f253d91754b4afe5fc5f",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "82b440a71b5db4e9468175b5d2a59e0c76721d7b38a69f133c925fc999aba7a9",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "9bbd3f5ddb5fe96dae57e92f8da258843c9def4475a9460fe98e646ed244289b",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "76e71304619e6f27519668d73feffdcdf79c04a04c34bb98629b695f983c3f98",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "a7dc83716d4888833bb76a1eaebec5a448603c02d2c4c2c9b3e6b898d61b06d8",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "2f7fd0312f471c208d8aa78272f9c563ec6f61387a955ac2db89148b6b2366f5",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "b43b6071c37c44f316dad476eb3c57d06987c6c49403b3b3c5bb1eea3e6869db",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "83bdfb572020fe24996f2981f62335f86f5a1b1705e62d283d5ad2e2cb43042c",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "d31a3a54acd8dbecc432b20630f5c3e7e68f7f0ad4f0349837c5ea6892c4886e",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "8727655b44010d4ec1f34e6ab629a6106a6c9685ee2ee3972d7bb838088b0882",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "22b73125032d441c69712d0a6c4efe8396068cf9b0266df4f120ab0aebbc1fc2",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "4622bba61d198501cef0bbebc90daa012a7fcc4dc0574701c26d9429cdec2ed6",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "9281e1ab5c87aaaff8cc6e6f9ef06f3a4be22be0a4260000ed9dbcf49f5e1754",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "115507b897b059fd39db3b310d40f60fea7a84855fb2f136482848e124729d04",
      "byte_length": 17586
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542
    }
  }
}
```
