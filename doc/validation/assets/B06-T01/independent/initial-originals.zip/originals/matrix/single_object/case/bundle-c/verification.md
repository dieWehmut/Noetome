# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-c",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "f3b9667e-6ae1-4b5c-b281-c510cea3062b",
      "import_id": "41d37680-1a9f-4b62-95d1-4454eb5f34b6",
      "source_id": "443f9cc5-f21c-4f2d-9fa4-e63dd2a0f15a",
      "version_id": "347c47ae-76c0-45a9-ab4c-b8eade5745fd",
      "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
      "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "960bf358-8e2c-4fb9-93d7-be6df94a2cbd",
          "ordinal": 0,
          "resource_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "f3b9667e-6ae1-4b5c-b281-c510cea3062b",
    "import_id": "41d37680-1a9f-4b62-95d1-4454eb5f34b6",
    "source_id": "443f9cc5-f21c-4f2d-9fa4-e63dd2a0f15a",
    "version_id": "347c47ae-76c0-45a9-ab4c-b8eade5745fd",
    "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
    "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "76623f30f6ec74235bc987e0187ddb6fdbfd2ff78606ad1a9eb7f9f6ff44e263",
        "byte_length": 3049
      },
      "decision.json": {
        "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
        "byte_length": 741
      },
      "review.json": {
        "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
        "byte_length": 510
      }
    },
    "gold_sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 A",
    "property": "质量",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "c-mass"
        ],
        "decision": {
          "atom_ids": [
            "c-mass"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
          "import_id": "41d37680-1a9f-4b62-95d1-4454eb5f34b6",
          "manifest_sha256": null,
          "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
          "parse_id": null,
          "project_id": "f3b9667e-6ae1-4b5c-b281-c510cea3062b",
          "source_id": "443f9cc5-f21c-4f2d-9fa4-e63dd2a0f15a",
          "version_id": "347c47ae-76c0-45a9-ab4c-b8eade5745fd"
        },
        "request_id": "synthetic-coordination-c"
      },
      "actual": {
        "binding": {
          "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
          "import_id": "41d37680-1a9f-4b62-95d1-4454eb5f34b6",
          "manifest_sha256": null,
          "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
          "parse_id": null,
          "project_id": "f3b9667e-6ae1-4b5c-b281-c510cea3062b",
          "source_id": "443f9cc5-f21c-4f2d-9fa4-e63dd2a0f15a",
          "version_id": "347c47ae-76c0-45a9-ab4c-b8eade5745fd"
        },
        "request_id": "synthetic-coordination-c"
      }
    },
    {
      "category": "duplicate",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "c-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 164,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "c-support",
        "excerpt_end_byte": 163,
        "excerpt_sha256": "9cadacee37d5646d0a233efc1ca201e23ea54368cfdb997de80a3888cd9c4ba6",
        "excerpt_start_byte": 0,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 163,
        "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "c-support",
          "excerpt_end_byte": 163,
          "excerpt_sha256": "9cadacee37d5646d0a233efc1ca201e23ea54368cfdb997de80a3888cd9c4ba6",
          "excerpt_start_byte": 0,
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 A",
          "质量"
        ],
        "compound": "样例 A 质量"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 A",
            "concept_id": "c-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "质量",
            "concept_id": "c-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
      "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "2",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "unit": "kg",
        "value": "2",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "kg",
      "actual": {
        "measurement": "kg",
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 A",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例A"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 A",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "c-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 A"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "kg"
      },
      "actual": [
        "kg",
        "温度 20 ℃",
        "仅适用成年样例 A",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "76623f30f6ec74235bc987e0187ddb6fdbfd2ff78606ad1a9eb7f9f6ff44e263",
      "byte_length": 3049
    },
    "decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    "knowledge-ir.json": {
      "sha256": "042440df99996a6a348f771f51d77cc5a908e07e9cb9348cc2682aab61f2f382",
      "byte_length": 12349
    },
    "review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "a0b6a34785fe47332cc241aa1df1a37ba9b0a234ded5ffb784f2c3abc9c995c1",
      "byte_length": 1054
    }
  }
}
```
