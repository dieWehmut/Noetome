# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "33d8d287-33f4-4cb1-9193-c9e661250ca0",
  "project_id": "a78c3d44-fc7b-4807-8b9c-7be71e25cac6",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "e717b47e55cd5ab5378825b82a22df97a59973f9acb56c1bd6c83e0d23a61de1",
    "byte_length": 41320
  },
  "plan_fingerprint": {
    "sha256": "349b1bbbbf2d906865cd74eaa431f6100fd14fb83d74a3f2aefed841a84ccd27",
    "byte_length": 17102
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "e717b47e55cd5ab5378825b82a22df97a59973f9acb56c1bd6c83e0d23a61de1",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "2edce96c3ca150ab9cb75c9f0f78fcf2683ba65dc717dc54bbbf2489f312addf",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9ebd193713a8ab6f81f308eb054d9eba0c93beb37d899e37481b3c275c613346",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "c78adc0945bf2d9b7fd6f15e3ea321bf535920778f2f520f91e679d4c3470527",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "31b92873331a50d0e7f4465f8178328e4a9f5126f2974acd6ad436ccd642ad17",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "6eda1e3a59e36421ee583eab0913ef699d60cdf8d948486a10a1b5fafa4ec429",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2d1c0fd59557e6172873087ba7c351bfd1d22a2f5d7d6a0d8ee18ddeaafc2921",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "e11a355c4b9c9b6cc3e4262beb2e6052ea43cf666832fcd8015dfaf75af52afa",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e7cf451a60a0239385cdcb4b1cc04a0b317eedb23d37f7cbf5c405ac6b7478f4",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "84f02af144e8c3ce834fa1731a45c8f7ec20ee997e5404eb23f1b8fd4dcf6f98",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "ef6c7e680b7fa530f41b0de14a882ecd689d6bc908078d21f8f730e0af0625ac",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "f9bf7c802e468671bc51694cbab5f444dac9c94fec16912ef3aa11a56f098f2a",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "2abb7c4e6faa9348c9ec70552b309ff597873dc83385a3bd231967798e6422d6",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "cb33d2c65c75d8f4ab84ef9fd9321ea01c46a942af0210a737d8b2359e71e815",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "39b8df74a1c73d503002c59ec05d9a07cffc5c60f5d26fb57492de13bff8315b",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "80ac8df889ba88f0d4e5d47616b080a282e820991359ef207574db1b477d0d7f",
      "byte_length": 533,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-5b0b723baa27a91b1cdf52e925680d45f1051093484e1a0c72ffadf39ba24eed",
            "occ-d4848e2f9da8a374201085b55b342ad4890790eb1461324369cf12a1d3449b81"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-5b0b723baa27a91b1cdf52e925680d45f1051093484e1a0c72ffadf39ba24eed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-5b0b723baa27a91b1cdf52e925680d45f1051093484e1a0c72ffadf39ba24eed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-d4848e2f9da8a374201085b55b342ad4890790eb1461324369cf12a1d3449b81"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-d4848e2f9da8a374201085b55b342ad4890790eb1461324369cf12a1d3449b81"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 529
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-5b0b723baa27a91b1cdf52e925680d45f1051093484e1a0c72ffadf39ba24eed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "70e5404516793b6fd7c6923319874891ff869333a792ba0612639251779cb20d",
      "byte_length": 320,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-d4848e2f9da8a374201085b55b342ad4890790eb1461324369cf12a1d3449b81"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 318
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "e717b47e55cd5ab5378825b82a22df97a59973f9acb56c1bd6c83e0d23a61de1",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "2edce96c3ca150ab9cb75c9f0f78fcf2683ba65dc717dc54bbbf2489f312addf",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "9ebd193713a8ab6f81f308eb054d9eba0c93beb37d899e37481b3c275c613346",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "c78adc0945bf2d9b7fd6f15e3ea321bf535920778f2f520f91e679d4c3470527",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "31b92873331a50d0e7f4465f8178328e4a9f5126f2974acd6ad436ccd642ad17",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "6eda1e3a59e36421ee583eab0913ef699d60cdf8d948486a10a1b5fafa4ec429",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "2d1c0fd59557e6172873087ba7c351bfd1d22a2f5d7d6a0d8ee18ddeaafc2921",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "e11a355c4b9c9b6cc3e4262beb2e6052ea43cf666832fcd8015dfaf75af52afa",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "e7cf451a60a0239385cdcb4b1cc04a0b317eedb23d37f7cbf5c405ac6b7478f4",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "84f02af144e8c3ce834fa1731a45c8f7ec20ee997e5404eb23f1b8fd4dcf6f98",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "ef6c7e680b7fa530f41b0de14a882ecd689d6bc908078d21f8f730e0af0625ac",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "f9bf7c802e468671bc51694cbab5f444dac9c94fec16912ef3aa11a56f098f2a",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "2abb7c4e6faa9348c9ec70552b309ff597873dc83385a3bd231967798e6422d6",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "cb33d2c65c75d8f4ab84ef9fd9321ea01c46a942af0210a737d8b2359e71e815",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "3638e4a6c7bdf95a295519dc01e0079cee3a1cf3eca6a26b1eab1e87746bff7d",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "39b8df74a1c73d503002c59ec05d9a07cffc5c60f5d26fb57492de13bff8315b",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "349b1bbbbf2d906865cd74eaa431f6100fd14fb83d74a3f2aefed841a84ccd27",
      "byte_length": 17102
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "70e5404516793b6fd7c6923319874891ff869333a792ba0612639251779cb20d",
      "byte_length": 320
    },
    "知识比较.md": {
      "sha256": "80ac8df889ba88f0d4e5d47616b080a282e820991359ef207574db1b477d0d7f",
      "byte_length": 533
    }
  }
}
```
