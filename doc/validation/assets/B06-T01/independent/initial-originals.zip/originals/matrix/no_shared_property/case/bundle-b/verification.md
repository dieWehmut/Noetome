# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "58235b12-7205-44e4-a3f7-78ae7789f5f6",
      "import_id": "eae810ef-6fe8-48ad-befd-27956668735a",
      "source_id": "2992e404-17d4-4819-9cfd-4ad6b9ca1d39",
      "version_id": "b3ed0b60-a79d-4766-a4c5-d8483494617f",
      "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
      "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f3bcf759-53e5-4df8-beb9-42521fb72011",
          "ordinal": 0,
          "resource_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "58235b12-7205-44e4-a3f7-78ae7789f5f6",
    "import_id": "eae810ef-6fe8-48ad-befd-27956668735a",
    "source_id": "2992e404-17d4-4819-9cfd-4ad6b9ca1d39",
    "version_id": "b3ed0b60-a79d-4766-a4c5-d8483494617f",
    "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
    "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "15baa364caab8620b83efa8c73e6be233c12487cdf9701e15c9fe3239ebc7f2e",
        "byte_length": 3049
      },
      "decision.json": {
        "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
        "byte_length": 140
      },
      "gold.json": {
        "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
        "byte_length": 741
      },
      "review.json": {
        "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
        "byte_length": 510
      }
    },
    "gold_sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 B",
    "property": "质量",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-mass"
        ],
        "decision": {
          "atom_ids": [
            "b-mass"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
          "import_id": "eae810ef-6fe8-48ad-befd-27956668735a",
          "manifest_sha256": null,
          "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
          "parse_id": null,
          "project_id": "58235b12-7205-44e4-a3f7-78ae7789f5f6",
          "source_id": "2992e404-17d4-4819-9cfd-4ad6b9ca1d39",
          "version_id": "b3ed0b60-a79d-4766-a4c5-d8483494617f"
        },
        "request_id": "synthetic-coordination-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
          "import_id": "eae810ef-6fe8-48ad-befd-27956668735a",
          "manifest_sha256": null,
          "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
          "parse_id": null,
          "project_id": "58235b12-7205-44e4-a3f7-78ae7789f5f6",
          "source_id": "2992e404-17d4-4819-9cfd-4ad6b9ca1d39",
          "version_id": "b3ed0b60-a79d-4766-a4c5-d8483494617f"
        },
        "request_id": "synthetic-coordination-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 163,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 164,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 163,
        "excerpt_sha256": "5806cc48446ac01e298ae5eef8daa4822f7c6c9c545999dc8d2d91472390b421",
        "excerpt_start_byte": 0,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 163,
        "quote": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 163,
          "excerpt_sha256": "5806cc48446ac01e298ae5eef8daa4822f7c6c9c545999dc8d2d91472390b421",
          "excerpt_start_byte": 0,
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 B",
          "质量"
        ],
        "compound": "样例 B 质量"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 B",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "质量",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
      "actual": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "2",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "unit": "kg",
        "value": "2",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "kg",
      "actual": {
        "measurement": "kg",
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例B"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 B",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例B"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例B"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "kg",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "b-mass",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 164,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "kg"
      },
      "actual": [
        "kg",
        "温度 20 ℃",
        "仅适用成年样例 B",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "15baa364caab8620b83efa8c73e6be233c12487cdf9701e15c9fe3239ebc7f2e",
      "byte_length": 3049
    },
    "decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    "gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    "knowledge-ir.json": {
      "sha256": "cd06e4b6340a065ade670f6a78e521ad17ea86c5f53dbe7ee481694a6c639e0e",
      "byte_length": 12349
    },
    "review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "a1ea7a5b64bf0afee1d0e8ce5971f6508abeeaa080e8dac41f3e96f1ff17292b",
      "byte_length": 1054
    }
  }
}
```
