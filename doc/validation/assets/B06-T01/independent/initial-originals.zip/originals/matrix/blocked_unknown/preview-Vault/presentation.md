# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "30733215-dcc4-47fe-a932-63ece6c61782",
  "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "d930e56d485e6723b1d876fe3e4d997a357a49d63d09db1313afb94027d037dd",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "75db756de530e78462583a0315fc8616578431797d2bf76c9b74598bc89d3dd9",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "1eaf57c292c252b61afade595b01d5ad5f6ebd34650af40835c80cd5a7947fc8",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e34298f53021b72fa48f008d265084bd1f9f9edc6cdd9df7c3f5dcc854f2b2cc",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "6e2b0aa7a920346bf9ebc93a659d3a69b4447e705bb1ff2b1c6d1eb9c32c7ae3",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "3e764f741540b4963b4752b9aeaa57c380944030c619fbf8682237430e558fe6",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "f68a4e44a1594846f7afe0ed99aebb508a7844266fe0c00218cd2559c8c0eee4",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "72f57ccafcce8585f38f841d1edf67fdc1629df79cf084b31717bc90d739a452",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "e8b4b2a3e4de8cddb6b2b3296e22320bf931a54a0f62a2d1b9ecd642346b09f2",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e41d8072e1cc4cf84c0cf645f81ceb8b98dd8bbb9c8c4f54a18261aea3c97b5a",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "277fedd4365dde14e292407e60f4aa7321a3953ba84403173505a0da017d4167",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "30ca54751dab6ee8c245cd90611da4b6390c3d6295b19365173d92f379cb52ec",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "b895887fce9a7fd1d1e2601212699ea3f882ce6111ed98bc1191bcdd6cd742eb",
      "byte_length": 14422
    },
    ".selection-original.json": {
      "sha256": "fd624d11e534f38127acf17e4b5caf45312451f80a114bab18e3e97256b4fe16",
      "byte_length": 4326
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "d930e56d485e6723b1d876fe3e4d997a357a49d63d09db1313afb94027d037dd",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "75db756de530e78462583a0315fc8616578431797d2bf76c9b74598bc89d3dd9",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "1eaf57c292c252b61afade595b01d5ad5f6ebd34650af40835c80cd5a7947fc8",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "e34298f53021b72fa48f008d265084bd1f9f9edc6cdd9df7c3f5dcc854f2b2cc",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "6e2b0aa7a920346bf9ebc93a659d3a69b4447e705bb1ff2b1c6d1eb9c32c7ae3",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "3e764f741540b4963b4752b9aeaa57c380944030c619fbf8682237430e558fe6",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "f68a4e44a1594846f7afe0ed99aebb508a7844266fe0c00218cd2559c8c0eee4",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "72f57ccafcce8585f38f841d1edf67fdc1629df79cf084b31717bc90d739a452",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "e8b4b2a3e4de8cddb6b2b3296e22320bf931a54a0f62a2d1b9ecd642346b09f2",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e41d8072e1cc4cf84c0cf645f81ceb8b98dd8bbb9c8c4f54a18261aea3c97b5a",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "277fedd4365dde14e292407e60f4aa7321a3953ba84403173505a0da017d4167",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "30ca54751dab6ee8c245cd90611da4b6390c3d6295b19365173d92f379cb52ec",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "b895887fce9a7fd1d1e2601212699ea3f882ce6111ed98bc1191bcdd6cd742eb",
      "byte_length": 14422
    },
    ".owner.json": {
      "sha256": "8f6b34ac82df1f01538ffb8b4446121b3b81aa90082f5c6fe5f7b967e4136b43",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "fd624d11e534f38127acf17e4b5caf45312451f80a114bab18e3e97256b4fe16",
      "byte_length": 4326
    }
  }
}
```
