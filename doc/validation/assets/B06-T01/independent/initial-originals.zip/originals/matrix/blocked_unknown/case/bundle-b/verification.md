# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-b",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
      "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
      "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
      "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f",
      "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
      "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "20499a09-2076-4b66-a24f-f7e4fc22cda0",
          "ordinal": 0,
          "resource_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
    "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
    "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
    "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f",
    "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
    "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "e8b4b2a3e4de8cddb6b2b3296e22320bf931a54a0f62a2d1b9ecd642346b09f2",
        "byte_length": 2714
      },
      "decision.json": {
        "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
        "byte_length": 503
      },
      "review.json": {
        "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
        "byte_length": 510
      }
    },
    "gold_sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 B",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "b-speed"
        ],
        "decision": {
          "atom_ids": [
            "b-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
          "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
          "manifest_sha256": null,
          "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
          "parse_id": null,
          "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
          "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
          "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f"
        },
        "request_id": "synthetic-coordination-b"
      },
      "actual": {
        "binding": {
          "content_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
          "import_id": "2f447ced-8ff9-42d8-895d-e6484f1786f4",
          "manifest_sha256": null,
          "normalized_sha256": "b7339941a3a3ab5f7494137a0ef7b9558e2ea1ddb936606ec797adda5c0fdede",
          "parse_id": null,
          "project_id": "8628d740-4e66-44ff-96d4-03a9ca24dcaf",
          "source_id": "1162fc4f-deab-48ac-99ed-3d61f554c951",
          "version_id": "decee06e-56cd-4b31-9e97-0ed03277b99f"
        },
        "request_id": "synthetic-coordination-b"
      }
    },
    {
      "category": "duplicate",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 B 的速度为 12 m/s。"
    },
    {
      "category": "evidence_identity",
      "object_id": "b-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 84,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 85,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "b-support",
        "excerpt_end_byte": 84,
        "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
        "excerpt_start_byte": 0,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 84,
        "quote": "样例 B 的速度为 12 m/s。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "b-support",
          "excerpt_end_byte": 84,
          "excerpt_sha256": "783c86820860d6b817daee9f749f284e63d050c4b2d8ac4ed34282ca8cead0ee",
          "excerpt_start_byte": 0,
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 B 的速度为 12 m/s。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 B",
          "速度"
        ],
        "compound": "样例 B 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 B",
            "concept_id": "b-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "b-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "样例 B 的速度为 12 m/s。",
      "actual": "样例 B 的速度为 12 m/s。"
    },
    {
      "category": "fact",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "12",
        "value_status": "known"
      },
      "actual": {
        "conditions": [],
        "unit": "m/s",
        "value": "12",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": []
      },
      "actual": {
        "body": [],
        "measurement": []
      }
    },
    {
      "category": "exception_set",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": [],
      "actual": []
    },
    {
      "category": "qualifiers",
      "object_id": "b-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 85,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [],
        "contexts": [],
        "exceptions": [],
        "unit": "m/s"
      },
      "actual": [
        "m/s"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 0,
      "passed": 0,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "not_applicable"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "e8b4b2a3e4de8cddb6b2b3296e22320bf931a54a0f62a2d1b9ecd642346b09f2",
      "byte_length": 2714
    },
    "decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    "knowledge-ir.json": {
      "sha256": "e41d8072e1cc4cf84c0cf645f81ceb8b98dd8bbb9c8c4f54a18261aea3c97b5a",
      "byte_length": 9252
    },
    "review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "277fedd4365dde14e292407e60f4aa7321a3953ba84403173505a0da017d4167",
      "byte_length": 974
    }
  }
}
```
