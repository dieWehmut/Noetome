# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "88f72514-9bd6-4262-abe4-a60a6d1888ce",
  "project_id": "b525cf25-5217-47ce-b681-c4d2aa94f4c8",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 1,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "eddfba1cdc48632de55dd920c6798a12d68d0e65f934ab3f903a337a1bd5979c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "e2da06b666f1f689998482e12942dc50551294d3df54e2d5bfd77f24408f0714",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "3508fac33e8e952e90d4d02bec0a2eab5b64260c2ba2b6e4912db399b6a1ab7d",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "2a35c1ecfd34383f02e689df6a49a7c489468dd33eb5fe6f75a80cfbe136c777",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e212476eb7bb98a98d604e708ed78a0f7e1153ad5b45971338d00584f2cf0a19",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "96fd0cd3271d00290e38f52c46ec3ce152c39ad5135a4908a75f6492f040acea",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "83cb5b4574a108be75219ef6666b94d027e08ea0277dc8ab78367425259019fd",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "f0c609d46965bf8fca88b0343d91760b1b75347bcca6b7c1aa00c094a821270f",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "25a7680a8ab1bd0645c1dcd47d93593b6f4f963a235579ea1d9f083423bc9241",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "f69c909a980cf42a8d67c2242202bbc9e835932e035fd078761543d3656bf39a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "8daae29a86d43161831bb9c3fe746420a3c241b7bacd622d1336459bc5698608",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "f4aaef649e0f913b770d31f423676448922391da2541745271a1382cd7777fba",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "7c24ebbf016ac719f90008c0393af28f8e49d2c89c0275d16fe85af4902a8b55",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "7ee192db0490810c61ebbbb751613ac03b46b1b44acd98a271f1f71cc46c64d6",
      "byte_length": 4330
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "eddfba1cdc48632de55dd920c6798a12d68d0e65f934ab3f903a337a1bd5979c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "e2da06b666f1f689998482e12942dc50551294d3df54e2d5bfd77f24408f0714",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "3508fac33e8e952e90d4d02bec0a2eab5b64260c2ba2b6e4912db399b6a1ab7d",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "2a35c1ecfd34383f02e689df6a49a7c489468dd33eb5fe6f75a80cfbe136c777",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e212476eb7bb98a98d604e708ed78a0f7e1153ad5b45971338d00584f2cf0a19",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "96fd0cd3271d00290e38f52c46ec3ce152c39ad5135a4908a75f6492f040acea",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "83cb5b4574a108be75219ef6666b94d027e08ea0277dc8ab78367425259019fd",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "f0c609d46965bf8fca88b0343d91760b1b75347bcca6b7c1aa00c094a821270f",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "25a7680a8ab1bd0645c1dcd47d93593b6f4f963a235579ea1d9f083423bc9241",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "f69c909a980cf42a8d67c2242202bbc9e835932e035fd078761543d3656bf39a",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "8daae29a86d43161831bb9c3fe746420a3c241b7bacd622d1336459bc5698608",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "f4aaef649e0f913b770d31f423676448922391da2541745271a1382cd7777fba",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "7c24ebbf016ac719f90008c0393af28f8e49d2c89c0275d16fe85af4902a8b55",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "c81103e2ced383a36551fae83abef4630c006e8a8722f4dc30c428b2b8521caa",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "7ee192db0490810c61ebbbb751613ac03b46b1b44acd98a271f1f71cc46c64d6",
      "byte_length": 4330
    }
  }
}
```
