# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "724f2f4d-48d8-41ed-b12f-3452ed67c3a9",
  "project_id": "900277bb-2187-4ba8-b383-bfae6e27a716",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000007"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "58d316704ff7992a3ce8c27d499697473a47b42e286340dd022d16b0c6b73f44",
    "byte_length": 41454
  },
  "plan_fingerprint": {
    "sha256": "6eb7be2768d05df4b6b5e08b5f7fdee73df9f2645496cb938fd02c82993a03ea",
    "byte_length": 17326
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "58d316704ff7992a3ce8c27d499697473a47b42e286340dd022d16b0c6b73f44",
      "byte_length": 41454
    },
    ".coordination-owner.json": {
      "sha256": "d853c7cc6c4effe062fde108e2ead9f7273175bc892be83af2ca3e5ed7058c2b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "52fe9066130dad0d5465420eccadfbe48d14cc0d8eddb9135739990d8b75b92b",
      "byte_length": 44925
    },
    ".coordination-report.md": {
      "sha256": "67a7a303a956700eeb60d0e797fd593791c985259e56ce95a68412e26f4818bd",
      "byte_length": 45400
    },
    ".identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ed2cbc74d6967ba8fcc5295f14d394b3cbb092e1ca4470bd08a9e3ee9c5b5826",
      "byte_length": 3077
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "fcb0bb52f9ec696eb0b409b864786402dc682bc40abad20fbcf57b110df737fb",
      "byte_length": 12416
    },
    ".input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    ".input-a--source-snapshot.json": {
      "sha256": "fd8f93d016daf5a558a2689a4c33f9f8b3aa647ac07bf44ca28953267aa3e255",
      "byte_length": 1067
    },
    ".input-a--verification.json": {
      "sha256": "de051b969a7c9d20b2d4df9f809b72cb10716bf8a2c57c3a768c95eb4c3e5524",
      "byte_length": 16897
    },
    ".input-a--verification.md": {
      "sha256": "56fd70203710aeb9035daac65aeaf5a38807643990d8beca8d0af89d2d86b32d",
      "byte_length": 17331
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "e3e3a1c62ad7b152daa5e6331ec90a1661d75bdfef8806a73ccea2a518ac78dc",
      "byte_length": 3086
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "8058dbc6fe39b5add89db3b2580898168ee06b3c26662ed5f8677a99846cd797",
      "byte_length": 12452
    },
    ".input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    ".input-b--source-snapshot.json": {
      "sha256": "df7d3ef7ed9ed7e1b960b4483bc75992c9fcf6310ff63370fb9288292849cc02",
      "byte_length": 1070
    },
    ".input-b--verification.json": {
      "sha256": "d793850bb65cb34314ab39807dd809025263042d7121ec5dc5d6e11bb28b9ed7",
      "byte_length": 16930
    },
    ".input-b--verification.md": {
      "sha256": "99d60b376e105195a1f4936b3def057269d543e2a1bbdc3827964fbdc7c2d3f2",
      "byte_length": 17364
    },
    ".selection-original.json": {
      "sha256": "711230ee2036e63e278ab3e7f052755fd85feef4ade577e52053d17fe83b69b3",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "4a4a6b90d1b1a40d8940f5a374c58770b541092feb21682a9bf080be167dd046",
      "byte_length": 571,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f",
            "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 44,
          "end_byte": 60
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005"
          ],
          "start_byte": 79,
          "end_byte": 95
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [
            "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1"
          ],
          "occurrence_ids": [
            "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 173,
          "end_byte": 320
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006"
          ],
          "start_byte": 325,
          "end_byte": 342
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "60000000-0000-4000-8000-000000000007"
          },
          "fact_ids": [
            "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4"
          ],
          "occurrence_ids": [
            "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 420,
          "end_byte": 567
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000005",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000005",
          "target_path": "对象-60000000-0000-4000-8000-000000000005.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 96,
          "end_byte": 170
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000006",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000006",
          "target_path": "对象-60000000-0000-4000-8000-000000000006.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 343,
          "end_byte": 417
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000005.md",
      "note_id": "object-60000000-0000-4000-8000-000000000005",
      "plan_revision": 1,
      "content_sha256": "c1d81677e3427713647012adadf77d97e2760151d89113f4339a6212f09674f5",
      "byte_length": 375,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-e3524c039cc467895fbe79851774e4896cf06a621783045c08e94161a4b247a1"
          ],
          "occurrence_ids": [
            "occ-465ff0c8c5c21865fc66a07cb8491671dcd4a50367ecf87591c7a13f47c2882f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000005",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 37,
          "end_byte": 373
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000006.md",
      "note_id": "object-60000000-0000-4000-8000-000000000006",
      "plan_revision": 1,
      "content_sha256": "0cf17e09e21f541849ee41cc70f8d2f0012d38126cad2ca41dcf8b41f216d615",
      "byte_length": 378,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-2885a04b0cfb7713bc1299548540a325eeaa21c2eb6f68f8e6ddc9123d0ed3f4"
          ],
          "occurrence_ids": [
            "occ-bdfb45161cb8eec9ae170e0ea3b1bf1771e9c558a2b396aca010476577cd64e3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000006",
            "60000000-0000-4000-8000-000000000007"
          ],
          "start_byte": 38,
          "end_byte": 376
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "58d316704ff7992a3ce8c27d499697473a47b42e286340dd022d16b0c6b73f44",
      "byte_length": 41454
    },
    ".coordination-owner.json": {
      "sha256": "d853c7cc6c4effe062fde108e2ead9f7273175bc892be83af2ca3e5ed7058c2b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "52fe9066130dad0d5465420eccadfbe48d14cc0d8eddb9135739990d8b75b92b",
      "byte_length": 44925
    },
    ".coordination-report.md": {
      "sha256": "67a7a303a956700eeb60d0e797fd593791c985259e56ce95a68412e26f4818bd",
      "byte_length": 45400
    },
    ".identity-original.json": {
      "sha256": "42bdb92a5c15573e9898b72f8ccf30843d3cdc0af3123587843b821592070736",
      "byte_length": 2041
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ed2cbc74d6967ba8fcc5295f14d394b3cbb092e1ca4470bd08a9e3ee9c5b5826",
      "byte_length": 3077
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "8abe7f78f9a127f7aad6eb66d0305a948079972a565212a355459553aa5e3dce",
      "byte_length": 780
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "fcb0bb52f9ec696eb0b409b864786402dc682bc40abad20fbcf57b110df737fb",
      "byte_length": 12416
    },
    ".input-a--review-original.json": {
      "sha256": "a2b8f337632d6bb1a12fa0991697fdd42dcbd8b2021b47ab4afba7906bc4c44c",
      "byte_length": 525
    },
    ".input-a--source-snapshot.json": {
      "sha256": "fd8f93d016daf5a558a2689a4c33f9f8b3aa647ac07bf44ca28953267aa3e255",
      "byte_length": 1067
    },
    ".input-a--verification.json": {
      "sha256": "de051b969a7c9d20b2d4df9f809b72cb10716bf8a2c57c3a768c95eb4c3e5524",
      "byte_length": 16897
    },
    ".input-a--verification.md": {
      "sha256": "56fd70203710aeb9035daac65aeaf5a38807643990d8beca8d0af89d2d86b32d",
      "byte_length": 17331
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "e3e3a1c62ad7b152daa5e6331ec90a1661d75bdfef8806a73ccea2a518ac78dc",
      "byte_length": 3086
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "e7f47d8049459854f8614f1381000ca6d2fe1612b5e924b7d642818ad8db7b96",
      "byte_length": 789
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "8058dbc6fe39b5add89db3b2580898168ee06b3c26662ed5f8677a99846cd797",
      "byte_length": 12452
    },
    ".input-b--review-original.json": {
      "sha256": "f077301cc5939e58f506c4c633ae681690dd3ad48ae250006c1d2e2b3b3dc7e2",
      "byte_length": 528
    },
    ".input-b--source-snapshot.json": {
      "sha256": "df7d3ef7ed9ed7e1b960b4483bc75992c9fcf6310ff63370fb9288292849cc02",
      "byte_length": 1070
    },
    ".input-b--verification.json": {
      "sha256": "d793850bb65cb34314ab39807dd809025263042d7121ec5dc5d6e11bb28b9ed7",
      "byte_length": 16930
    },
    ".input-b--verification.md": {
      "sha256": "99d60b376e105195a1f4936b3def057269d543e2a1bbdc3827964fbdc7c2d3f2",
      "byte_length": 17364
    },
    ".owner.json": {
      "sha256": "82ca733af669de4813c8ea39da5ce9cafe467f5492b18edccb8f438935afc85e",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "711230ee2036e63e278ab3e7f052755fd85feef4ade577e52053d17fe83b69b3",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "6eb7be2768d05df4b6b5e08b5f7fdee73df9f2645496cb938fd02c82993a03ea",
      "byte_length": 17326
    },
    "对象-60000000-0000-4000-8000-000000000005.md": {
      "sha256": "c1d81677e3427713647012adadf77d97e2760151d89113f4339a6212f09674f5",
      "byte_length": 375
    },
    "对象-60000000-0000-4000-8000-000000000006.md": {
      "sha256": "0cf17e09e21f541849ee41cc70f8d2f0012d38126cad2ca41dcf8b41f216d615",
      "byte_length": 378
    },
    "知识比较.md": {
      "sha256": "4a4a6b90d1b1a40d8940f5a374c58770b541092feb21682a9bf080be167dd046",
      "byte_length": 571
    }
  }
}
```
