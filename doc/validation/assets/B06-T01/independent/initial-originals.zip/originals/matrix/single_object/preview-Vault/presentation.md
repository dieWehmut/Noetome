# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "fa84c3f3-5172-46b5-bbd7-efe40d5e9070",
  "project_id": "f3b9667e-6ae1-4b5c-b281-c510cea3062b",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 2,
    "source_occurrences": 3,
    "objects": 1,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 2,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SINGLE_OBJECT_TEXT",
    "reason": "选定事实仅涉及一个对象，以正文保留各属性、条件和原始表述。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "1c064a14722d41ea9ead3cf7c1c382f31f41fadf6f66e04b1308d8b74c743e53",
    "byte_length": 60938
  },
  "plan_fingerprint": {
    "sha256": "edfcd62370978977d2a248d194444c24874b932a8ff5312bb9ace3a15d2a6550",
    "byte_length": 18202
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "1c064a14722d41ea9ead3cf7c1c382f31f41fadf6f66e04b1308d8b74c743e53",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "77df7715ef1d96021d5a307b929b6b5419f9a8dd8124102a4be546f1fa6300d3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ac1538b5c989b3756066ce76df8786a651d50007dd81555a19f2b7615e42124a",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "421c725623cfc196e4c30a8ce4a017f77af09ddefc892355bdd8df73ff396497",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "0495577e9f7a59bc93a736ed75f149b11e126be1300c54d6528df3f930f17b6e",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "3f4170b6359d3e8a3e932b37dbef54daac2af19c338a5010d06b33595c363b31",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "5852a2dd8b54cd55e898a654efc21bd03e191f9bcb3ecc94f1457e28617a598a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "98e2a0c1692098d7bc88d016290278f6321d68dea108675db4edd0cd4c8c6c69",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "57e38056149bb8be36d3090bbe075042a853d2173f7631fc6441b4ad57f88645",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "633acc57f4c76d7afa63ae5ad2d257c5c82755e092346ddb4ff05dbb480b83b8",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "1ccea82778669176c1b2c1d066f389c00137f7ddfc81d2844577c38f210ade3c",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "d3593748a4114d592fee3f3a8cded1b70a53331379f51a018d7f6a73568ca77a",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "d2ae11cb271b48629ee2b4a4387ea3e0639f23d0402078a5b4abb037afdf1473",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "aea0fda1f5dda35b399aee17ec22743882d425f0dd12f75edfdcc715c0f491a1",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "76623f30f6ec74235bc987e0187ddb6fdbfd2ff78606ad1a9eb7f9f6ff44e263",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "042440df99996a6a348f771f51d77cc5a908e07e9cb9348cc2682aab61f2f382",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "a0b6a34785fe47332cc241aa1df1a37ba9b0a234ded5ffb784f2c3abc9c995c1",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "a28adec5e90c16901d7f354e69e1f20dc11804a212a8a3873871f28e01a54f31",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "a715ee7283d6999d60a39cf64f385e24cb644db6154931e55146a5f02178973d",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "57bfd76ae491a7136523a9a8edd806eb71428e1543b279dfb2fdc162c22a4728",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-4e642f09cad58322356ba6df21dab7c307f7d4532f8967ef9b5a80e57658e8f6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2934b1dad8a1b33c59b25d2655190d95e707fabd3c2ab0f217c22ad4a1614a23",
            "occ-60201d3a3bdd4c27cb3eae6cbafd0994c3ed34800e2ace85ea246526272b2bfb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-4e642f09cad58322356ba6df21dab7c307f7d4532f8967ef9b5a80e57658e8f6"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2934b1dad8a1b33c59b25d2655190d95e707fabd3c2ab0f217c22ad4a1614a23",
            "occ-60201d3a3bdd4c27cb3eae6cbafd0994c3ed34800e2ace85ea246526272b2bfb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "1c064a14722d41ea9ead3cf7c1c382f31f41fadf6f66e04b1308d8b74c743e53",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "77df7715ef1d96021d5a307b929b6b5419f9a8dd8124102a4be546f1fa6300d3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "ac1538b5c989b3756066ce76df8786a651d50007dd81555a19f2b7615e42124a",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "421c725623cfc196e4c30a8ce4a017f77af09ddefc892355bdd8df73ff396497",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "0495577e9f7a59bc93a736ed75f149b11e126be1300c54d6528df3f930f17b6e",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "3f4170b6359d3e8a3e932b37dbef54daac2af19c338a5010d06b33595c363b31",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "5852a2dd8b54cd55e898a654efc21bd03e191f9bcb3ecc94f1457e28617a598a",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "98e2a0c1692098d7bc88d016290278f6321d68dea108675db4edd0cd4c8c6c69",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "57e38056149bb8be36d3090bbe075042a853d2173f7631fc6441b4ad57f88645",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "633acc57f4c76d7afa63ae5ad2d257c5c82755e092346ddb4ff05dbb480b83b8",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "1ccea82778669176c1b2c1d066f389c00137f7ddfc81d2844577c38f210ade3c",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "d3593748a4114d592fee3f3a8cded1b70a53331379f51a018d7f6a73568ca77a",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "d2ae11cb271b48629ee2b4a4387ea3e0639f23d0402078a5b4abb037afdf1473",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "aea0fda1f5dda35b399aee17ec22743882d425f0dd12f75edfdcc715c0f491a1",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "76623f30f6ec74235bc987e0187ddb6fdbfd2ff78606ad1a9eb7f9f6ff44e263",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "042440df99996a6a348f771f51d77cc5a908e07e9cb9348cc2682aab61f2f382",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "a0b6a34785fe47332cc241aa1df1a37ba9b0a234ded5ffb784f2c3abc9c995c1",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "a28adec5e90c16901d7f354e69e1f20dc11804a212a8a3873871f28e01a54f31",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "a715ee7283d6999d60a39cf64f385e24cb644db6154931e55146a5f02178973d",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "ee0bcee4382d4e56efe61e2a4714309fed4ddbc507d8d8a1a3d408741ce0ae85",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "57bfd76ae491a7136523a9a8edd806eb71428e1543b279dfb2fdc162c22a4728",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "edfcd62370978977d2a248d194444c24874b932a8ff5312bb9ace3a15d2a6550",
      "byte_length": 18202
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "知识比较.md": {
      "sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514
    }
  }
}
```
