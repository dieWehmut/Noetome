# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "d03508f9-a9a4-461c-9f3a-a237cd5c3021",
  "project_id": "2cfea4c5-39f6-4671-bd71-015bf33ee2b3",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "51c70def8ca4fda318922d203da10250469c883a13ea140dc54f5bed767dcf5c",
    "byte_length": 61685
  },
  "plan_fingerprint": {
    "sha256": "d3c626c44d4634310ee0a02d5b02628066cc039b75df6aa59ae314b3c0bf1beb",
    "byte_length": 22658
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "51c70def8ca4fda318922d203da10250469c883a13ea140dc54f5bed767dcf5c",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "7e26a831d4b3adbf2c0797b36c28b03d6cb96bd71197213e7ee5297c82318dfa",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "31455da13350469bce114439050c6b3e031e264f5e63b54a072b64c9064df2a6",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "ed5aea4fe5e1c6e7fc09df30877901728928b5d20205d000187032d60614c8e2",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "125cbdd47978e4a29cbe51ecdb83641d69af1a1a8b2349609fe1504ff3a6645b",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "41bd0ae5cbc09e3ea973da27ce68e8629b0838d66183c7cefce5076817cf70fc",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9f59ca781249a83b64ef7aac5df9ee4ae8289d6b5550b99ce44bb92edc05c747",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "527198a8483230a6ec1bf2a5a060aef1595c588b79b91f120b4cc01d959e2faf",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "31aa355321f9c0c10c536a83d1ac479520644adab91d7b9046bedbccaeddf970",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6bdfc1253fe9d6abb73028db9dc77c93b59bbc7a593c3b19710da88f8f524b88",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "5367e2aafa18ab350852b4ab32e7f4b05e15d3b01dd005889f2bcca41bace0de",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9ee013d31ef23ef8d7ed331604dec6d2ebe430c30dbf2a65922ae0fc348357e5",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "2dc0e7e551435a08818bf02c9854af691e20dd27fe92358471404823b32d72f3",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8b95086630bdb8c7a46365b4b3accf0b7ca878a9b60c5f8727b4710a506c434a",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "06844a37d1b3839178559b5a641b8014dbb33de868543072df067eb0aff001ec",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "32b427674689ac8b826ecba9763438c07da550cd8a654e8f9d418e1191f15a12",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "f84030ded6310c831b63ffd5018de8c4c15a84c4400f3e609c81c78b479af563",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "70e6a742b736d717a6ff150f2b3d37da4e8ca4bcf87524ac314f5bcfdfb7ddfd",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "0c53e57f2b191a6a8b30d23eb0c584df675775934352d02330f96103fa6a9091",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "264fcc41509910d10a4a7f73a15958dc851a4c939b2f308e4f8d3927caff9fe9",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6fd68eef0ebc6f19c8112090ca224f58aa3561d36cb830b71660ce08b5e2dec3",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-702a01dc08b4f5f1f8cb783d21b73f868d153787f4d23dbf290f8597f35d8055",
            "occ-e48d88a09992e86ea1dc39c3e231fc1e65ef4d7b9f2b1865a4b0e2a107e9ee97",
            "occ-f68363ecc807dd2420c0cef0815a30243bb9e6273bd3cc8c459d2e0cdcd7c6ba"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-702a01dc08b4f5f1f8cb783d21b73f868d153787f4d23dbf290f8597f35d8055",
            "occ-e48d88a09992e86ea1dc39c3e231fc1e65ef4d7b9f2b1865a4b0e2a107e9ee97"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-e48d88a09992e86ea1dc39c3e231fc1e65ef4d7b9f2b1865a4b0e2a107e9ee97",
            "occ-702a01dc08b4f5f1f8cb783d21b73f868d153787f4d23dbf290f8597f35d8055"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-f68363ecc807dd2420c0cef0815a30243bb9e6273bd3cc8c459d2e0cdcd7c6ba"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-f68363ecc807dd2420c0cef0815a30243bb9e6273bd3cc8c459d2e0cdcd7c6ba"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-e48d88a09992e86ea1dc39c3e231fc1e65ef4d7b9f2b1865a4b0e2a107e9ee97"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-702a01dc08b4f5f1f8cb783d21b73f868d153787f4d23dbf290f8597f35d8055"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-f68363ecc807dd2420c0cef0815a30243bb9e6273bd3cc8c459d2e0cdcd7c6ba"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "51c70def8ca4fda318922d203da10250469c883a13ea140dc54f5bed767dcf5c",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "7e26a831d4b3adbf2c0797b36c28b03d6cb96bd71197213e7ee5297c82318dfa",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "31455da13350469bce114439050c6b3e031e264f5e63b54a072b64c9064df2a6",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "ed5aea4fe5e1c6e7fc09df30877901728928b5d20205d000187032d60614c8e2",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "125cbdd47978e4a29cbe51ecdb83641d69af1a1a8b2349609fe1504ff3a6645b",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "41bd0ae5cbc09e3ea973da27ce68e8629b0838d66183c7cefce5076817cf70fc",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9f59ca781249a83b64ef7aac5df9ee4ae8289d6b5550b99ce44bb92edc05c747",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "527198a8483230a6ec1bf2a5a060aef1595c588b79b91f120b4cc01d959e2faf",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "31aa355321f9c0c10c536a83d1ac479520644adab91d7b9046bedbccaeddf970",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6bdfc1253fe9d6abb73028db9dc77c93b59bbc7a593c3b19710da88f8f524b88",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "5367e2aafa18ab350852b4ab32e7f4b05e15d3b01dd005889f2bcca41bace0de",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9ee013d31ef23ef8d7ed331604dec6d2ebe430c30dbf2a65922ae0fc348357e5",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "2dc0e7e551435a08818bf02c9854af691e20dd27fe92358471404823b32d72f3",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "8b95086630bdb8c7a46365b4b3accf0b7ca878a9b60c5f8727b4710a506c434a",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "06844a37d1b3839178559b5a641b8014dbb33de868543072df067eb0aff001ec",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "32b427674689ac8b826ecba9763438c07da550cd8a654e8f9d418e1191f15a12",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "f84030ded6310c831b63ffd5018de8c4c15a84c4400f3e609c81c78b479af563",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "70e6a742b736d717a6ff150f2b3d37da4e8ca4bcf87524ac314f5bcfdfb7ddfd",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "0c53e57f2b191a6a8b30d23eb0c584df675775934352d02330f96103fa6a9091",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "acc1fc6fb2fa3884b02b46ae5d75ad807972d4d6ce6375d0d16644761b413b3f",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "264fcc41509910d10a4a7f73a15958dc851a4c939b2f308e4f8d3927caff9fe9",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "d3c626c44d4634310ee0a02d5b02628066cc039b75df6aa59ae314b3c0bf1beb",
      "byte_length": 22658
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "6fd68eef0ebc6f19c8112090ca224f58aa3561d36cb830b71660ce08b5e2dec3",
      "byte_length": 542
    }
  }
}
```
