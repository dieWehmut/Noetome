# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "4d49a944-517f-4e83-be2e-fe0f52e0c6cd",
  "project_id": "aae2017b-b1b5-48fc-80ad-a2ac82e4e30f",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 2,
    "table_cells": 6,
    "missing_cells": 1,
    "rendered_notes": 3,
    "content_mappings": 12,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "fc3fa5d49f9c2d8219e80e3b001e7c6e041fdedbe86f52d46acf25d4b815cfe7",
    "byte_length": 61731
  },
  "plan_fingerprint": {
    "sha256": "7ddcbd71ace30868e1a0387695c98cf2718ca053112885d16f13f735bea1a36b",
    "byte_length": 24165
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "fc3fa5d49f9c2d8219e80e3b001e7c6e041fdedbe86f52d46acf25d4b815cfe7",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "2029e88611d43c7cdd66d36faf4f2e1b76f588433e90b40eac832be70412aba6",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "e82eb37890cb876fdc3f9ca49473f11f4fd608db151ce3f7925ed155e2a6c632",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "0186034ed068cd508de558f684980719c87d8475118afecc660c59d988074b4c",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "bf01fc5e329e64e56f462735f701e125c7373bf9fecbf6323e796c30e93e82cd",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b1859448734731f7150a4aecd10aa73579e1779a6e369bcbb1bf6bd999f46161",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "cc646a1a0d132dd20b9b484a9585fe64935d9448f8e959715949e4add1ba21ca",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "a48e72d8056b8926aea954814b4fc7bcd303399566d71f6f0af5395c8a601168",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "1a554d86c4d0f01c84f709c0af38cea3ceb9d82138ebee9fc95c756a9559adc5",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "ca56507993e12a9bb760854f126152e04404502a0b223017a13ba6d949f87419",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "1724fd4ac99d7d47c13650645695bb17c9bb3f73d0b96bd0242600842f794965",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0c845bb184fb24f8d2645cfeb246c67dac60f5820dd21122e935fe7731f41348",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "81bc9520a790c000941f86d12cbab196727538ca371e0ee853de55266c1389ae",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "86517cb3393de4fd429ec67c74af1a43040fac582e11dac17d603cc0986239b8",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "46bd16d4f794a2980fe5ebd8bfbea56931989b686afc649dfe6019597b259899",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "283c5868f866908e77e55f2acde1812fcc32a4bc5f7a5bc68a41c0c8e5874dc3",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "cd0a57b4a6c8bbc334d0f41186fe58959bc07e9482f921c2dcfe60aa19ed8ba9",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "f5b3a5487ed6f164a838752d669c2daca002783294f5c48dbe2a4e5f39902bbe",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "7e85fedd089114931a27b4f2084911a13b195fce0abe9bd6ed80f7967368d352",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "3ee77962cfd9c0f13300720afe9d442ec70affce495403802df32f603c599ed2",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69343952552610a07f0664e8551617d665a33183039ca48dbebd72910aad9b48",
      "byte_length": 707,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-9dc3da819ae7c26d508654f8a347ec5fe498a52f5b8e455de5f57c2503eb7d8c",
            "occ-c5cc47feec0857652f97deea79c41d3f49fe7328c74933ccba9fe0a4bb179c23"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-dc94e97694215e08499f2147bc3642da59af4bc0ad61a2666035ab8d930a9e59"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 53,
          "end_byte": 59
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-c5cc47feec0857652f97deea79c41d3f49fe7328c74933ccba9fe0a4bb179c23",
            "occ-dc94e97694215e08499f2147bc3642da59af4bc0ad61a2666035ab8d930a9e59"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 84,
          "end_byte": 92
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-c5cc47feec0857652f97deea79c41d3f49fe7328c74933ccba9fe0a4bb179c23"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 170,
          "end_byte": 316
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-dc94e97694215e08499f2147bc3642da59af4bc0ad61a2666035ab8d930a9e59"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 319,
          "end_byte": 462
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-9dc3da819ae7c26d508654f8a347ec5fe498a52f5b8e455de5f57c2503eb7d8c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 467,
          "end_byte": 475
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-9dc3da819ae7c26d508654f8a347ec5fe498a52f5b8e455de5f57c2503eb7d8c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 553,
          "end_byte": 699
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "missing",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 702,
          "end_byte": 703
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 93,
          "end_byte": 167
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 476,
          "end_byte": 550
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-dc94e97694215e08499f2147bc3642da59af4bc0ad61a2666035ab8d930a9e59"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-c5cc47feec0857652f97deea79c41d3f49fe7328c74933ccba9fe0a4bb179c23"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-9dc3da819ae7c26d508654f8a347ec5fe498a52f5b8e455de5f57c2503eb7d8c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "fc3fa5d49f9c2d8219e80e3b001e7c6e041fdedbe86f52d46acf25d4b815cfe7",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "2029e88611d43c7cdd66d36faf4f2e1b76f588433e90b40eac832be70412aba6",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "e82eb37890cb876fdc3f9ca49473f11f4fd608db151ce3f7925ed155e2a6c632",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "0186034ed068cd508de558f684980719c87d8475118afecc660c59d988074b4c",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "bf01fc5e329e64e56f462735f701e125c7373bf9fecbf6323e796c30e93e82cd",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b1859448734731f7150a4aecd10aa73579e1779a6e369bcbb1bf6bd999f46161",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "cc646a1a0d132dd20b9b484a9585fe64935d9448f8e959715949e4add1ba21ca",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "a48e72d8056b8926aea954814b4fc7bcd303399566d71f6f0af5395c8a601168",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "1a554d86c4d0f01c84f709c0af38cea3ceb9d82138ebee9fc95c756a9559adc5",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "ca56507993e12a9bb760854f126152e04404502a0b223017a13ba6d949f87419",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "1724fd4ac99d7d47c13650645695bb17c9bb3f73d0b96bd0242600842f794965",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "0c845bb184fb24f8d2645cfeb246c67dac60f5820dd21122e935fe7731f41348",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "81bc9520a790c000941f86d12cbab196727538ca371e0ee853de55266c1389ae",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "86517cb3393de4fd429ec67c74af1a43040fac582e11dac17d603cc0986239b8",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "46bd16d4f794a2980fe5ebd8bfbea56931989b686afc649dfe6019597b259899",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "283c5868f866908e77e55f2acde1812fcc32a4bc5f7a5bc68a41c0c8e5874dc3",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "cd0a57b4a6c8bbc334d0f41186fe58959bc07e9482f921c2dcfe60aa19ed8ba9",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "f5b3a5487ed6f164a838752d669c2daca002783294f5c48dbe2a4e5f39902bbe",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "7e85fedd089114931a27b4f2084911a13b195fce0abe9bd6ed80f7967368d352",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "ec559e2e4c933067731a15130af3e11546f4ac7e04e74599764704c6590226af",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "3ee77962cfd9c0f13300720afe9d442ec70affce495403802df32f603c599ed2",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "7ddcbd71ace30868e1a0387695c98cf2718ca053112885d16f13f735bea1a36b",
      "byte_length": 24165
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69343952552610a07f0664e8551617d665a33183039ca48dbebd72910aad9b48",
      "byte_length": 707
    }
  }
}
```
