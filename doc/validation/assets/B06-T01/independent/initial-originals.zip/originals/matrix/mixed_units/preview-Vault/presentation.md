# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "ed37754c-79c8-4da2-ac06-d3f862d653cc",
  "project_id": "8e33bd4c-2726-431b-ad47-5ec05094eaf8",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "73cccfc984b6247727b5db45b9112ffbe88476e10748b3c51a727aad834e9e05",
    "byte_length": 41343
  },
  "plan_fingerprint": {
    "sha256": "8db336daf2b1865a7221d0459e1a3fde9720d027af36cb408136bfcc3954b7cf",
    "byte_length": 17164
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "73cccfc984b6247727b5db45b9112ffbe88476e10748b3c51a727aad834e9e05",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "aa102952cff1b023bba56cd051a2596a3d9978aa83eec8a4c28113634ab97ebb",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "8670ec9e539e8ad1f491dc65f0d3f9ebb446be448bbad5fbf6261c8e3cc6854c",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "5f59f0c20a69a4acef9cb12e01a778aa80ef84bfbc34fd93a9c4d9df652b4a7d",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ade08e85529295333728dda69b0599f34240334076d3af9ec2158056e2f81f46",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e260b78f505995cf08693758ab424a064b29d3f43cc6dd09dc37da0d69273230",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "28c88814bdd7b838cf7b54dc70c955ef6b9bfdf837e739ccaecf88ddf94f9046",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "505c80bca42720e2b10fdc2217cb2ac4aab37532c32a147141be2b2d8fb98ebb",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "85ab7140268ac422e12be5ca76508fa431b582d7eeaeeca88c09a029ee25c9a4",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "a890f63ca5d71e37554253137eb4bfd007475b5ada2241fd96e627937c2ada6a",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e031f8c40d42d2caaef52017d9c8afbac0f404e33040ff7f2a27e904371d7094",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "b33dd1e6d959a3592e122a81885da56cb600c8d032326bf435b9a5777537caeb",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "35e21fae09c00774950f142041ed7f3548e9371b05cdfe944d5b138a39e07c6e",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "3c0b0a111385402725aac7e359c500c46fcbd93d4be46616d2c5937eec1a1d01",
      "byte_length": 17319
    },
    ".selection-original.json": {
      "sha256": "471bec90d48de1a43f2722ed576106f538df647dd2f0bddc59471f0cd247da31",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-13b4f3e6bb3a004503327dfa6904ab00d01164dd489784d993d3ec412755f547",
            "occ-f86b01e8e9ed2d74de2325c22b0ee88e158b9e012d6db094a90a71a3b15b534c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-f86b01e8e9ed2d74de2325c22b0ee88e158b9e012d6db094a90a71a3b15b534c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-f86b01e8e9ed2d74de2325c22b0ee88e158b9e012d6db094a90a71a3b15b534c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-13b4f3e6bb3a004503327dfa6904ab00d01164dd489784d993d3ec412755f547"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-13b4f3e6bb3a004503327dfa6904ab00d01164dd489784d993d3ec412755f547"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 539
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-f86b01e8e9ed2d74de2325c22b0ee88e158b9e012d6db094a90a71a3b15b534c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-13b4f3e6bb3a004503327dfa6904ab00d01164dd489784d993d3ec412755f547"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 329
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "73cccfc984b6247727b5db45b9112ffbe88476e10748b3c51a727aad834e9e05",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "aa102952cff1b023bba56cd051a2596a3d9978aa83eec8a4c28113634ab97ebb",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "8670ec9e539e8ad1f491dc65f0d3f9ebb446be448bbad5fbf6261c8e3cc6854c",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "5f59f0c20a69a4acef9cb12e01a778aa80ef84bfbc34fd93a9c4d9df652b4a7d",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ade08e85529295333728dda69b0599f34240334076d3af9ec2158056e2f81f46",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "e260b78f505995cf08693758ab424a064b29d3f43cc6dd09dc37da0d69273230",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "28c88814bdd7b838cf7b54dc70c955ef6b9bfdf837e739ccaecf88ddf94f9046",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "505c80bca42720e2b10fdc2217cb2ac4aab37532c32a147141be2b2d8fb98ebb",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "85ab7140268ac422e12be5ca76508fa431b582d7eeaeeca88c09a029ee25c9a4",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "a890f63ca5d71e37554253137eb4bfd007475b5ada2241fd96e627937c2ada6a",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e031f8c40d42d2caaef52017d9c8afbac0f404e33040ff7f2a27e904371d7094",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "b33dd1e6d959a3592e122a81885da56cb600c8d032326bf435b9a5777537caeb",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "35e21fae09c00774950f142041ed7f3548e9371b05cdfe944d5b138a39e07c6e",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "3c0b0a111385402725aac7e359c500c46fcbd93d4be46616d2c5937eec1a1d01",
      "byte_length": 17319
    },
    ".owner.json": {
      "sha256": "a6e3825bf168ee63c4095dd5d7a1c5e216ffbfd44fcfc4a9e51f01a317e2a694",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "471bec90d48de1a43f2722ed576106f538df647dd2f0bddc59471f0cd247da31",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "8db336daf2b1865a7221d0459e1a3fde9720d027af36cb408136bfcc3954b7cf",
      "byte_length": 17164
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331
    },
    "知识比较.md": {
      "sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543
    }
  }
}
```
