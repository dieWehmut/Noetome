# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：1；条件未知：0；条件不适用：1；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "abd39d50-0259-493f-ac38-73683eabc8fd",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
        "import_id": "34026c14-401d-4f1a-87b1-5cb4f74e86c6",
        "source_id": "4e853c41-06ef-412f-98db-37f7c17e6ce6",
        "version_id": "6f2c313a-a985-44fe-849c-de58032d1575",
        "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "import_id": "34026c14-401d-4f1a-87b1-5cb4f74e86c6",
              "manifest_sha256": null,
              "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "parse_id": null,
              "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
              "source_id": "4e853c41-06ef-412f-98db-37f7c17e6ce6",
              "version_id": "6f2c313a-a985-44fe-849c-de58032d1575"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "import_id": "34026c14-401d-4f1a-87b1-5cb4f74e86c6",
              "manifest_sha256": null,
              "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
              "parse_id": null,
              "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
              "source_id": "4e853c41-06ef-412f-98db-37f7c17e6ce6",
              "version_id": "6f2c313a-a985-44fe-849c-de58032d1575"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 84,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 85,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 84,
            "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
            "excerpt_start_byte": 0,
            "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 84,
            "quote": "样例 A 的速度为 10 m/s。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 84,
              "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
              "excerpt_start_byte": 0,
              "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s。",
          "actual": "样例 A 的速度为 10 m/s。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": []
          },
          "actual": {
            "body": [],
            "measurement": []
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": [],
          "actual": []
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 85,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [],
            "contexts": [],
            "exceptions": [],
            "unit": "m/s"
          },
          "actual": [
            "m/s"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "a5bcfb7e205d4db59acaa62751d317283b6ff7cafc7c6ae69c55d0705fc03ab8",
          "byte_length": 2714
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
          "byte_length": 503
        },
        "knowledge-ir.json": {
          "sha256": "a40edc4537f27ccc2cdb39e3176264a9a4ecf188c275f6e8a8491cede01ee416",
          "byte_length": 9252
        },
        "review-original.json": {
          "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "670cd8657908861e43378d96d1400db021b8d7ed05b98d204abc7112880eb2eb",
          "byte_length": 974
        },
        "verification.json": {
          "sha256": "5747a3708f924b6f93d27b93d433e1ae9726076ea401f41f6025c8a5000ed12c",
          "byte_length": 13988
        },
        "verification.md": {
          "sha256": "4d4eba4486e11c9683d986b560535eeaf6cbc7c71a3c0b410b79facb163bbf63",
          "byte_length": 14422
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
        "import_id": "8600ae89-239a-4320-b394-250b77c4a86f",
        "source_id": "ac94930d-33ed-4ddc-ac4a-712ef5f0f096",
        "version_id": "8f673fe1-bf85-4f00-bf63-69e6ab4b4419",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "8600ae89-239a-4320-b394-250b77c4a86f",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
              "source_id": "ac94930d-33ed-4ddc-ac4a-712ef5f0f096",
              "version_id": "8f673fe1-bf85-4f00-bf63-69e6ab4b4419"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "8600ae89-239a-4320-b394-250b77c4a86f",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
              "source_id": "ac94930d-33ed-4ddc-ac4a-712ef5f0f096",
              "version_id": "8f673fe1-bf85-4f00-bf63-69e6ab4b4419"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 B",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "da788fc24f2c59ec628cf115b1380dba81a38571a34f7a65f63c621dcbb72ddc",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "d293fca2e4e4f31a3afb3deaf8f5245437c5eb5620a70a4dcef11251dc910f5a",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "5539ea0e596bad449f3932a1100172292549c4f0a1db2f08dfb6d64efe783ca6",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "3b7a260041465b6af106ffb352f8124fef436906d5f01c2c508ec0bf894663ec",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "cbdb0bc6f8a3d059932f1540a314fad68cdcccf6d85cca841a26009635e33226",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137"
      },
      "occurrence_id": "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2",
      "input_id": "b",
      "binding": {
        "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
        "import_id": "8600ae89-239a-4320-b394-250b77c4a86f",
        "source_id": "ac94930d-33ed-4ddc-ac4a-712ef5f0f096",
        "version_id": "8f673fe1-bf85-4f00-bf63-69e6ab4b4419",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "6f464d8a-2861-4793-9725-248183a0ee25",
          "ordinal": 0,
          "resource_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 B"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 B"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "not_applicable",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 84,
        "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。",
        "sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e"
      },
      "occurrence_id": "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345",
      "input_id": "a",
      "binding": {
        "project_id": "f2aaa9b7-5887-4971-9232-77108e003d50",
        "import_id": "34026c14-401d-4f1a-87b1-5cb4f74e86c6",
        "source_id": "4e853c41-06ef-412f-98db-37f7c17e6ce6",
        "version_id": "6f2c313a-a985-44fe-849c-de58032d1575",
        "content_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "normalized_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "c999efa2-02fd-4916-8993-15b7b41a983b",
          "ordinal": 0,
          "resource_sha256": "3ab0a1dd650fc66fde2aa34b75428794d707e6a66d93aa90a4898c6879435c6c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 85,
        "text": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s。",
          "qualifiers": [
            "m/s"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": []
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 84,
          "excerpt_sha256": "9f6597358b877a1b79e57dab9fda0c31051dd45bc0a0ed870ff60652bc574f2e",
          "quote": "适用条件：不适用；观点时间：2020年。\n样例 A 的速度为 10 m/s。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [],
      "exceptions": [],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "not_applicable",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [],
      "exceptions": [],
      "occurrence_ids": [
        "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例B",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2",
      "right_occurrence_id": "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-2cf3b0711efc37ebdb0c13b1d06ca7eb8c417e21d576ba0393e4e5f6291510b2",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-cc5f2d67dbf0763a1a65357193efc531fca8406b60b59cd5cf530cb85ecb3345",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 1,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 1,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "73faad854cb2a0d5257aa152599ebb78eccb08442f5441e6eda85ea73f1293f9",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "db560c589077f99b3070132276cf75722add6785b6b9771873fc8b312d7b966c",
      "byte_length": 37417
    },
    "coordination-original.json": {
      "sha256": "b751fe9b6fc0952aec5c340872b010e7dc1b7ba8b5b80872fbdc0e99759d2297",
      "byte_length": 4328
    },
    "identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "a5bcfb7e205d4db59acaa62751d317283b6ff7cafc7c6ae69c55d0705fc03ab8",
      "byte_length": 2714
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    "input-a--knowledge-ir.json": {
      "sha256": "a40edc4537f27ccc2cdb39e3176264a9a4ecf188c275f6e8a8491cede01ee416",
      "byte_length": 9252
    },
    "input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "670cd8657908861e43378d96d1400db021b8d7ed05b98d204abc7112880eb2eb",
      "byte_length": 974
    },
    "input-a--verification.json": {
      "sha256": "5747a3708f924b6f93d27b93d433e1ae9726076ea401f41f6025c8a5000ed12c",
      "byte_length": 13988
    },
    "input-a--verification.md": {
      "sha256": "4d4eba4486e11c9683d986b560535eeaf6cbc7c71a3c0b410b79facb163bbf63",
      "byte_length": 14422
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "da788fc24f2c59ec628cf115b1380dba81a38571a34f7a65f63c621dcbb72ddc",
      "byte_length": 3057
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "d293fca2e4e4f31a3afb3deaf8f5245437c5eb5620a70a4dcef11251dc910f5a",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "5539ea0e596bad449f3932a1100172292549c4f0a1db2f08dfb6d64efe783ca6",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "3b7a260041465b6af106ffb352f8124fef436906d5f01c2c508ec0bf894663ec",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "cbdb0bc6f8a3d059932f1540a314fad68cdcccf6d85cca841a26009635e33226",
      "byte_length": 17303
    }
  }
}
```
