# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "c44c6671-5afd-479f-8d98-de4b7df52c22",
  "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 2,
    "source_occurrences": 3,
    "objects": 1,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 2,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SINGLE_OBJECT_TEXT",
    "reason": "选定事实仅涉及一个对象，以正文保留各属性、条件和原始表述。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "6b3e36d44b7732c2f232a319dd0620f458b7094e1d98c68d3e2acea3b7348d00",
    "byte_length": 60938
  },
  "plan_fingerprint": {
    "sha256": "b15cf023a450e5e595bfd8c700e01b807c77782692c22a89f72ca1b7bfa0e914",
    "byte_length": 18202
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "6b3e36d44b7732c2f232a319dd0620f458b7094e1d98c68d3e2acea3b7348d00",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "d897b932673caf5ed165f3dea7371a721aba34fd00cb642440f9829bd73bf934",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3b3b81a63bbcf9b8897093d53279e18359546a5e2209077af60d9df4a8a169ca",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "bff4fcb125923b511d91cd782d71c0f6c9306555968adc89dba90f86e8d7dc24",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "608fdb6e3801e916a9d38759a75334565f7176952f8bb25c042edc4a15c342d6",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b9f07a757ee52742cb6ac70bd0d85a77615b7d5144800078b3f96ecc70caf548",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "466d290a48090252ab08c796360eaaeb801ee16ad0d12398451bcef1c6d1ce42",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "ed9908e838b804eb17c280445aef96cf3a070f2984e1814f4253a0094c1388eb",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "c941b1aa2f3d3f29d1b84c7b449b54910d0c3e35ebf02eb7f21ad01a2d3baf8e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "d5a853fdfc5aaea10e7f2cb648307bcce49d74af40a888278eeec8e62dd9f83d",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "0f6f4dc5244af1cb5596b080062cabdfa1e8658ee7d9df223ff7feb73c2698b2",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "82456236ba951d02ba1f7089adfbf6b83abbfe4d0de8d3dcf991cc0df83a3d0b",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "94cc524491a3b283e20129bf8ff21623e432274a2d7e9bcab5deb9349154f17d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "97ec4873433f40cc2aeff419d370358cc3d244d8647679acc916baa15ea383b4",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "c5784bcdf34eb0ff46e8646f7160099dc68e584bbf0235b99afaa441f3769750",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "f4be924276b43538c8376d36e0abb555bd9c442e661366ca9d4486b60ff93893",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "7dbd37e649f70a8915251bcb3591ba7675f66d6432013f78f98199b33e8c1f54",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "4ebb91108062c06e636d49eedca07dfb934fa6b1c4252eae07d76e9366d41f43",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "ac0d0cc912b0dff88fb8ba92be97083be93d0df0a6dac26d39fdb85fe10ad5e5",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "b5980d1abc7ec208f35cd5910a3916e3606f02ed46697b70dbbb0021615f8f20",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
            "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
            "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "6b3e36d44b7732c2f232a319dd0620f458b7094e1d98c68d3e2acea3b7348d00",
      "byte_length": 60938
    },
    ".coordination-owner.json": {
      "sha256": "d897b932673caf5ed165f3dea7371a721aba34fd00cb642440f9829bd73bf934",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "3b3b81a63bbcf9b8897093d53279e18359546a5e2209077af60d9df4a8a169ca",
      "byte_length": 65796
    },
    ".coordination-report.md": {
      "sha256": "bff4fcb125923b511d91cd782d71c0f6c9306555968adc89dba90f86e8d7dc24",
      "byte_length": 66271
    },
    ".identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "608fdb6e3801e916a9d38759a75334565f7176952f8bb25c042edc4a15c342d6",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "b9f07a757ee52742cb6ac70bd0d85a77615b7d5144800078b3f96ecc70caf548",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "466d290a48090252ab08c796360eaaeb801ee16ad0d12398451bcef1c6d1ce42",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "ed9908e838b804eb17c280445aef96cf3a070f2984e1814f4253a0094c1388eb",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "c941b1aa2f3d3f29d1b84c7b449b54910d0c3e35ebf02eb7f21ad01a2d3baf8e",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "d5a853fdfc5aaea10e7f2cb648307bcce49d74af40a888278eeec8e62dd9f83d",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "0f6f4dc5244af1cb5596b080062cabdfa1e8658ee7d9df223ff7feb73c2698b2",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "82456236ba951d02ba1f7089adfbf6b83abbfe4d0de8d3dcf991cc0df83a3d0b",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "94cc524491a3b283e20129bf8ff21623e432274a2d7e9bcab5deb9349154f17d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "97ec4873433f40cc2aeff419d370358cc3d244d8647679acc916baa15ea383b4",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "c5784bcdf34eb0ff46e8646f7160099dc68e584bbf0235b99afaa441f3769750",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "f4be924276b43538c8376d36e0abb555bd9c442e661366ca9d4486b60ff93893",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "7dbd37e649f70a8915251bcb3591ba7675f66d6432013f78f98199b33e8c1f54",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "4ebb91108062c06e636d49eedca07dfb934fa6b1c4252eae07d76e9366d41f43",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "ac0d0cc912b0dff88fb8ba92be97083be93d0df0a6dac26d39fdb85fe10ad5e5",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "fb101ba8dc8a64763883bf8785e71c0b7e6726356e8400cc039502601fe893a7",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "b5980d1abc7ec208f35cd5910a3916e3606f02ed46697b70dbbb0021615f8f20",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "b15cf023a450e5e595bfd8c700e01b807c77782692c22a89f72ca1b7bfa0e914",
      "byte_length": 18202
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "知识比较.md": {
      "sha256": "e20bc9c3bd1930b45d2367e2752120ef4c591b6e613c08a1a1e818e4e1c4fed5",
      "byte_length": 514
    }
  }
}
```
