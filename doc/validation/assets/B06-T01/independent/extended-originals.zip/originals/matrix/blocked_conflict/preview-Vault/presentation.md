# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "de2f1aa8-394a-491f-a4d3-34a23686c171",
  "project_id": "a142f0b4-65b7-4492-9252-ed2439b57b42",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 1,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "7b472a676488c5506b43ebaa816668ce18419710762ff0a4cde1a85debe4292c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "716883f7677a9100ea61a6e47d25061501a4deefaf0263533e7c896c31277c82",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "3a25668946a6ff30f4c51c50d3308982caf252cb15a7353325d4421d8d4d8ef1",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "9d6d2b48ba4582b8e142fcd7abfea271de535d734238aba075b59366b4d19e28",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "71671db4f72edd6edb7630eaddc08907aeb0232c73e5ce7de113727bcbfbce56",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9e24107291f41167f0f7d44a36e60fbbc830b758e77e5b3fbc5f064b014f82a4",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "07c5fed8905f10a992e678bf5a4761b915d97188bbdbdc149cbecec9de228c52",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "b546b06db86b64bdaff16d5cbf38d29706f879d4a1c5a2cc052b2f9630bcaeb0",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "fe68ad15492896fa1565eed2fe40f06aa9f06f011feb3974cb9e3763f8584010",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "678481b1e8cfedaaa6efc5e45888d15acddbb82073915c70b7775deb3b192dfb",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "5c1ab0ff7501541f45ca911655baf5c06fece12e960975814abe48c8ffc64baf",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "5268d3cd79b9b992740fc8476b63084062b084c0cce420c9cf0ea35f640c11bc",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "ca80c351ca9ec34315ee13036c79743aa2348809a5781c7e1b85c4a06a24427e",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "97982a6463d7c1eec3d13d7122264a9f8e4ace4e62c63ce401a8fcd445d3d35a",
      "byte_length": 4330
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "7b472a676488c5506b43ebaa816668ce18419710762ff0a4cde1a85debe4292c",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "716883f7677a9100ea61a6e47d25061501a4deefaf0263533e7c896c31277c82",
      "byte_length": 44793
    },
    ".coordination-report.md": {
      "sha256": "3a25668946a6ff30f4c51c50d3308982caf252cb15a7353325d4421d8d4d8ef1",
      "byte_length": 45274
    },
    ".identity-original.json": {
      "sha256": "47a6458058ac6d25a5ddf022624aa5f6df888d052e4175bc3a38814f18027fc3",
      "byte_length": 1909
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "9d6d2b48ba4582b8e142fcd7abfea271de535d734238aba075b59366b4d19e28",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "71671db4f72edd6edb7630eaddc08907aeb0232c73e5ce7de113727bcbfbce56",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9e24107291f41167f0f7d44a36e60fbbc830b758e77e5b3fbc5f064b014f82a4",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "07c5fed8905f10a992e678bf5a4761b915d97188bbdbdc149cbecec9de228c52",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "b546b06db86b64bdaff16d5cbf38d29706f879d4a1c5a2cc052b2f9630bcaeb0",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "fe68ad15492896fa1565eed2fe40f06aa9f06f011feb3974cb9e3763f8584010",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "678481b1e8cfedaaa6efc5e45888d15acddbb82073915c70b7775deb3b192dfb",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "5c1ab0ff7501541f45ca911655baf5c06fece12e960975814abe48c8ffc64baf",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "5268d3cd79b9b992740fc8476b63084062b084c0cce420c9cf0ea35f640c11bc",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "ca80c351ca9ec34315ee13036c79743aa2348809a5781c7e1b85c4a06a24427e",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "788d411455eacb0d72733d85dc80e5107498d025f033f17554688bf6dda3dcad",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "97982a6463d7c1eec3d13d7122264a9f8e4ace4e62c63ce401a8fcd445d3d35a",
      "byte_length": 4330
    }
  }
}
```
