# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "8b488cae-7cb0-4990-9455-52dd0513424a",
  "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "e43ab6fb5820121330b21528781ec1000bb48c4d25d51957ecef43e69a310cac",
    "byte_length": 41246
  },
  "plan_fingerprint": {
    "sha256": "97c03009ef8e993009def899a13f5a36d0a1198a8b700f0062a9b9c371026c82",
    "byte_length": 14692
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "e43ab6fb5820121330b21528781ec1000bb48c4d25d51957ecef43e69a310cac",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "ef3f477660a6d43f912a5c7c4aba7b9e70ded6fa5b436c11f9f395e46b73de2d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "bce2f5d82911c7bc2870dca37c14fe2feb8af283b463a24d0fa3cf24cdf1ee47",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "582dae14ac78d4095477cd59d0573e464d614759c7207d6d1ca1e5d447fd733e",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ba454c47384cf6f30ef072ee05af224feafa6e7e4c9958bce45aeb42f18fdeb4",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "bf6eb9f9710e4da8ba77bb0d9fb32fceff9763f63f9fbe0145c72a63e1ef591c",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "900c450cc647bd67260ad4629fd793cf0230ce8fcd19e63e5864430daf54fc3a",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "51436f5000c9213386712572ed525f4e13cd8dac3bb309871cc6fa94f4694869",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "e1ce09095a4345405e012e6b2a189d0916d9064e8874547711e07bc5029bde9b",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "7e72f203d02daca14f89caaac8e5bb5e37836442d6653a0a45068475f7ef0ca7",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b416a2fb731343e5c127b313100b34e3a1c5d357cdf184913adc7863bf69f04a",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "e0cc4f71a28d5c193ddea86ecc06dc30a765bafc0096b9f198710eef9e4c9a2d",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "d846c12e16e43016efdcb8091318f27b5efd660f6e0afa730885582802546bbc",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "6c422d15a8790983170ecd6f0b6947c36a2669497ce87270c3f673cafce8803d",
      "byte_length": 17255
    },
    ".selection-original.json": {
      "sha256": "2b08eaff70e86fce5f71cb65055511a82302bcfe8f26ec77de658d6f2ccd0a43",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-2c85bb3b4fca0da77169f586ca8a0fe753932093e7773eef14c52697c4a0e4e4"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 33,
          "end_byte": 197
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-c796e31cc25bfdab692af5e396ea87a2479ff64c6e7629065a15ea700e55016e"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 273,
          "end_byte": 437
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000001",
          "target_path": "对象-61000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 198,
          "end_byte": 271
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "61000000-0000-4000-8000-000000000003",
          "target_path": "对象-61000000-0000-4000-8000-000000000003.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 438,
          "end_byte": 511
        }
      ]
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000001.md",
      "note_id": "object-61000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e"
          ],
          "occurrence_ids": [
            "occ-2c85bb3b4fca0da77169f586ca8a0fe753932093e7773eef14c52697c4a0e4e4"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000001",
            "61000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 27,
          "end_byte": 320
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-61000000-0000-4000-8000-000000000003.md",
      "note_id": "object-61000000-0000-4000-8000-000000000003",
      "plan_revision": 1,
      "content_sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2"
          ],
          "occurrence_ids": [
            "occ-c796e31cc25bfdab692af5e396ea87a2479ff64c6e7629065a15ea700e55016e"
          ],
          "concept_ids": [
            "61000000-0000-4000-8000-000000000003",
            "61000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 29,
          "end_byte": 322
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "e43ab6fb5820121330b21528781ec1000bb48c4d25d51957ecef43e69a310cac",
      "byte_length": 41246
    },
    ".coordination-owner.json": {
      "sha256": "ef3f477660a6d43f912a5c7c4aba7b9e70ded6fa5b436c11f9f395e46b73de2d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "bce2f5d82911c7bc2870dca37c14fe2feb8af283b463a24d0fa3cf24cdf1ee47",
      "byte_length": 44717
    },
    ".coordination-report.md": {
      "sha256": "582dae14ac78d4095477cd59d0573e464d614759c7207d6d1ca1e5d447fd733e",
      "byte_length": 45192
    },
    ".identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "ba454c47384cf6f30ef072ee05af224feafa6e7e4c9958bce45aeb42f18fdeb4",
      "byte_length": 3052
    },
    ".input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    ".input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "bf6eb9f9710e4da8ba77bb0d9fb32fceff9763f63f9fbe0145c72a63e1ef591c",
      "byte_length": 12391
    },
    ".input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    ".input-a--source-snapshot.json": {
      "sha256": "900c450cc647bd67260ad4629fd793cf0230ce8fcd19e63e5864430daf54fc3a",
      "byte_length": 1053
    },
    ".input-a--verification.json": {
      "sha256": "51436f5000c9213386712572ed525f4e13cd8dac3bb309871cc6fa94f4694869",
      "byte_length": 16868
    },
    ".input-a--verification.md": {
      "sha256": "e1ce09095a4345405e012e6b2a189d0916d9064e8874547711e07bc5029bde9b",
      "byte_length": 17302
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "7e72f203d02daca14f89caaac8e5bb5e37836442d6653a0a45068475f7ef0ca7",
      "byte_length": 3047
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "b416a2fb731343e5c127b313100b34e3a1c5d357cdf184913adc7863bf69f04a",
      "byte_length": 12339
    },
    ".input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "e0cc4f71a28d5c193ddea86ecc06dc30a765bafc0096b9f198710eef9e4c9a2d",
      "byte_length": 1053
    },
    ".input-b--verification.json": {
      "sha256": "d846c12e16e43016efdcb8091318f27b5efd660f6e0afa730885582802546bbc",
      "byte_length": 16821
    },
    ".input-b--verification.md": {
      "sha256": "6c422d15a8790983170ecd6f0b6947c36a2669497ce87270c3f673cafce8803d",
      "byte_length": 17255
    },
    ".owner.json": {
      "sha256": "36db9518bc3301d0c70e4097f1b432c0f1472b1bedf4f5dbf8924b37e9348ae5",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "2b08eaff70e86fce5f71cb65055511a82302bcfe8f26ec77de658d6f2ccd0a43",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "97c03009ef8e993009def899a13f5a36d0a1198a8b700f0062a9b9c371026c82",
      "byte_length": 14692
    },
    "对象-61000000-0000-4000-8000-000000000001.md": {
      "sha256": "94a33c60aa6f2570d4b093e245360a74fa8d3648919b803847cdd75b63a0f463",
      "byte_length": 322
    },
    "对象-61000000-0000-4000-8000-000000000003.md": {
      "sha256": "25660feb2b667cdf37866b6799291ea44165363aa7fa0c6e5fff5b8f1baf19cd",
      "byte_length": 324
    },
    "知识比较.md": {
      "sha256": "6df3180621adbdfc46b2b16805507019b089cc0ee6483abb10865f928c949fc9",
      "byte_length": 513
    }
  }
}
```
