# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "8db502a6-cb05-4cae-b21c-887ee7adf40d",
  "project_id": "c61b7bcc-f187-414e-ba52-1593fe3a26fe",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "72f003743a0e640f532a5e5d94a2c2f5b11feb8e988549511dbb1265dd94ea7c",
    "byte_length": 61820
  },
  "plan_fingerprint": {
    "sha256": "ad7ede41b781a50f79f09533173ed5ca2ac133ed52f68de5ded11aead527e1a9",
    "byte_length": 22900
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "72f003743a0e640f532a5e5d94a2c2f5b11feb8e988549511dbb1265dd94ea7c",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "5c329ed4266d218dc54ad1e0bf4a639dd0dc58e357fa05570d55fafeb2a28688",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "0ec74d38bd3d6e33ea51136d7ba542678c863a7cbf14956264d5c671b00176d6",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "ef43800a5396ce3e327b366061ec22e1dba425a6da440c60b5abe406ca2928ca",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "d6c060101a0c88d091171b57ec0d851ee73a2c34d17f614fc7087122bac6cc46",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "6a1b349a307351fc866dfb7ee8c58a5bec2e571dd4344e374a1891489606e5c4",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "b2fcf355f27d590bb1a283db4cd1a4b3fecbe4e855b38dde30795125383aa920",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "4bd2ab6b8a62e14d159d7eb018a6da51c4c406be6585ddf2ca72f27bf696a875",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7db2181615d336ce0d3b113f584a21f9ab8f94c6365f9d0583523d031808fd76",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "14fb1d32c9dd6c3f17ca4fe4bc485c9d3940d49d56942c52a8167730bc46c107",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "47005f50a441b5bab3b0f4fbddcb7a82206a13a2c8dc5de06f026cdd7ca1ee65",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "bdccc82076f71872d00ebd1e7ee902efff6a994fe67a697ef1e4ce3f67d0a023",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "83828e1c76bec2dab7a2147550858be4246a9c125a35015fb2458bcdc5733318",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "64cf9cf138aa906b7d927f408a3a52f5060c94fd33611c962a4b6f43785e4ae8",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "f283923fb9f95d6901bb66b395b6db306feac483d7a467d67104e3530cf55e38",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "997ca5f2fc8e7a48b42eec1c9272cee58a2419b99e80f10cae9b23732531b296",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "7758080654f0a7c2943927ec0346cd7dc352639fffc6b37e1fd942a8a52e89ee",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "3a1d7ed6468e319a7b7b42a30499ae18f82577e719ac8ca8a9fa0b88de398b7e",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "747f56ce011133f0f10f9552f79f1579526454905ec63610ba80f8ff7f8b6a19",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "9b39c57f90883e59242f64c3c4635121d5ac40c1cd1c526f237c959e2e62082c",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "02b9ac3e26c38da49252f068b0bae9ad4e340fe7233d7b7c39eaf2caa0bedacf",
      "byte_length": 692,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-250d0d5ac9838e4a6d4968d688a13bb394acbb98e0e8ae4f016ddb6c493c2c74",
            "occ-ab166c541186cfdb390a30ea7587bc6b38b5cf4e5f7286379e70b028bb1fccdb",
            "occ-bc7ab88fd088244fc410d4160b23c30fc73aa9d1337dc1bc1cc63a495bcbcc8e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-250d0d5ac9838e4a6d4968d688a13bb394acbb98e0e8ae4f016ddb6c493c2c74",
            "occ-bc7ab88fd088244fc410d4160b23c30fc73aa9d1337dc1bc1cc63a495bcbcc8e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-250d0d5ac9838e4a6d4968d688a13bb394acbb98e0e8ae4f016ddb6c493c2c74",
            "occ-bc7ab88fd088244fc410d4160b23c30fc73aa9d1337dc1bc1cc63a495bcbcc8e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 451
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-ab166c541186cfdb390a30ea7587bc6b38b5cf4e5f7286379e70b028bb1fccdb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 456,
          "end_byte": 464
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-ab166c541186cfdb390a30ea7587bc6b38b5cf4e5f7286379e70b028bb1fccdb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 542,
          "end_byte": 688
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 465,
          "end_byte": 539
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-7c791e173394c49e91d70ffd8fc76a2cc286ad394b4647c3bb8bc0325bc3536f"
          ],
          "occurrence_ids": [
            "occ-250d0d5ac9838e4a6d4968d688a13bb394acbb98e0e8ae4f016ddb6c493c2c74"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-bc7ab88fd088244fc410d4160b23c30fc73aa9d1337dc1bc1cc63a495bcbcc8e"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-ab166c541186cfdb390a30ea7587bc6b38b5cf4e5f7286379e70b028bb1fccdb"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "72f003743a0e640f532a5e5d94a2c2f5b11feb8e988549511dbb1265dd94ea7c",
      "byte_length": 61820
    },
    ".coordination-owner.json": {
      "sha256": "5c329ed4266d218dc54ad1e0bf4a639dd0dc58e357fa05570d55fafeb2a28688",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "0ec74d38bd3d6e33ea51136d7ba542678c863a7cbf14956264d5c671b00176d6",
      "byte_length": 66678
    },
    ".coordination-report.md": {
      "sha256": "ef43800a5396ce3e327b366061ec22e1dba425a6da440c60b5abe406ca2928ca",
      "byte_length": 67153
    },
    ".identity-original.json": {
      "sha256": "5aa66c56838bcfd0ec10173e2c01ff4a8d66cd06821650c02a75b0c5ad9ea4a3",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "d6c060101a0c88d091171b57ec0d851ee73a2c34d17f614fc7087122bac6cc46",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "6a1b349a307351fc866dfb7ee8c58a5bec2e571dd4344e374a1891489606e5c4",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "b2fcf355f27d590bb1a283db4cd1a4b3fecbe4e855b38dde30795125383aa920",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "4bd2ab6b8a62e14d159d7eb018a6da51c4c406be6585ddf2ca72f27bf696a875",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7db2181615d336ce0d3b113f584a21f9ab8f94c6365f9d0583523d031808fd76",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "14fb1d32c9dd6c3f17ca4fe4bc485c9d3940d49d56942c52a8167730bc46c107",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "271433fe9d11eebc4aaf356db2996ef7723206bd3091709b7ebf5e1c699479dd",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "47005f50a441b5bab3b0f4fbddcb7a82206a13a2c8dc5de06f026cdd7ca1ee65",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "797a5d7277dc5c306619f8de1777373b1508718c35762622ddecf3c3d41081f4",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "bdccc82076f71872d00ebd1e7ee902efff6a994fe67a697ef1e4ce3f67d0a023",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "83828e1c76bec2dab7a2147550858be4246a9c125a35015fb2458bcdc5733318",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "64cf9cf138aa906b7d927f408a3a52f5060c94fd33611c962a4b6f43785e4ae8",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "f283923fb9f95d6901bb66b395b6db306feac483d7a467d67104e3530cf55e38",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "997ca5f2fc8e7a48b42eec1c9272cee58a2419b99e80f10cae9b23732531b296",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "7758080654f0a7c2943927ec0346cd7dc352639fffc6b37e1fd942a8a52e89ee",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "3a1d7ed6468e319a7b7b42a30499ae18f82577e719ac8ca8a9fa0b88de398b7e",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "747f56ce011133f0f10f9552f79f1579526454905ec63610ba80f8ff7f8b6a19",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "2d31004f0df40005e39d059dda78385e4948e60094bbe67b2e8dffa0d473bd04",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "9b39c57f90883e59242f64c3c4635121d5ac40c1cd1c526f237c959e2e62082c",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "ad7ede41b781a50f79f09533173ed5ca2ac133ed52f68de5ded11aead527e1a9",
      "byte_length": 22900
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "b87df36cba338727e58d242cae281dd6f786a58cf8ca168569dd2f6b8112ffa3",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "02b9ac3e26c38da49252f068b0bae9ad4e340fe7233d7b7c39eaf2caa0bedacf",
      "byte_length": 692
    }
  }
}
```
