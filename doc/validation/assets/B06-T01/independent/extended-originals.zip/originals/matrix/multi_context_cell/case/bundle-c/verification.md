# 有界来源知识核对

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

规则：controlled_measurement_zh_v1；复核主体：automated_source_review；解释时间："before_synthetic_response"。

来源范围、对象、问题码、逐类别检查与分母见以下完整事实快照，与 verification.json 一致。

```json
{
  "schema_version": 1,
  "report_kind": "source_knowledge_verification",
  "producer": "source_review",
  "request_id": "synthetic-coordination-c",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "scope": {
    "purpose": "single_measurement_source_review",
    "selection": [
      {
        "kind": "text",
        "ordinal": 0
      }
    ],
    "binding": {
      "project_id": "8590b96e-7e49-48a1-9084-2dee247c5e26",
      "import_id": "53437429-4b07-438d-900c-5db8c04104ab",
      "source_id": "ff5de2a6-01ab-431b-87b5-cfd96eb827a3",
      "version_id": "40545cef-24c2-49ab-a115-8768cbbc79d0",
      "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
      "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
      "parse_id": null,
      "manifest_sha256": null
    },
    "units": [
      {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "41033114-41c8-4337-a9ee-bfdbefb04f4c",
          "ordinal": 0,
          "resource_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      }
    ],
    "expected_atoms": 1
  },
  "binding": {
    "project_id": "8590b96e-7e49-48a1-9084-2dee247c5e26",
    "import_id": "53437429-4b07-438d-900c-5db8c04104ab",
    "source_id": "ff5de2a6-01ab-431b-87b5-cfd96eb827a3",
    "version_id": "40545cef-24c2-49ab-a115-8768cbbc79d0",
    "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
    "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
    "parse_id": null,
    "manifest_sha256": null
  },
  "origin": {
    "producer": "api",
    "transport_mode": "local_http_test",
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response",
    "input_fingerprints": {
      "candidates.json": {
        "sha256": "4be72ee4ed20850aa9772131b9abaae0bfef5e184b0220d66dc3308c7a4a45cd",
        "byte_length": 3057
      },
      "decision.json": {
        "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
        "byte_length": 141
      },
      "gold.json": {
        "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
        "byte_length": 747
      },
      "review.json": {
        "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
        "byte_length": 510
      }
    },
    "gold_sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d"
  },
  "rules": {
    "grammar": "controlled_measurement_zh_v1",
    "subject": "样例 B",
    "property": "速度",
    "allowed_contexts": [],
    "reviewer": "automated_source_review",
    "interpretation_timing": "before_synthetic_response"
  },
  "expected_results": [
    {
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "candidate_results": [
    {
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "issue_codes": []
    }
  ],
  "checks": [
    {
      "category": "schema",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "strict_schema_1",
      "actual": null
    },
    {
      "category": "source",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "parsed",
      "actual": "parsed"
    },
    {
      "category": "exclusion",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "included",
      "actual": "included"
    },
    {
      "category": "coverage",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "atom_count": 1,
        "unit_id": "unit-0"
      },
      "actual": {
        "candidate_ids": [
          "c-speed"
        ],
        "decision": {
          "atom_ids": [
            "c-speed"
          ],
          "disposition": "included",
          "exclusion_reason": null,
          "schema_version": 1,
          "unit_id": "unit-0"
        }
      }
    },
    {
      "category": "binding",
      "object_id": "expected-0",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "binding": {
          "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
          "import_id": "53437429-4b07-438d-900c-5db8c04104ab",
          "manifest_sha256": null,
          "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
          "parse_id": null,
          "project_id": "8590b96e-7e49-48a1-9084-2dee247c5e26",
          "source_id": "ff5de2a6-01ab-431b-87b5-cfd96eb827a3",
          "version_id": "40545cef-24c2-49ab-a115-8768cbbc79d0"
        },
        "request_id": "synthetic-coordination-c"
      },
      "actual": {
        "binding": {
          "content_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
          "import_id": "53437429-4b07-438d-900c-5db8c04104ab",
          "manifest_sha256": null,
          "normalized_sha256": "dcaeb68a9a9685fd9144428482bc7f4270bca17263be4f48898039a603d64877",
          "parse_id": null,
          "project_id": "8590b96e-7e49-48a1-9084-2dee247c5e26",
          "source_id": "ff5de2a6-01ab-431b-87b5-cfd96eb827a3",
          "version_id": "40545cef-24c2-49ab-a115-8768cbbc79d0"
        },
        "request_id": "synthetic-coordination-c"
      }
    },
    {
      "category": "duplicate",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "unique_semantic_atom",
      "actual": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
    },
    {
      "category": "evidence_identity",
      "object_id": "c-support",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 165,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 166,
        "start_byte": 0,
        "unit_id": "unit-0"
      },
      "actual": {
        "evidence_id": "c-support",
        "excerpt_end_byte": 165,
        "excerpt_sha256": "befb0f8255b79a2ec7dee20cc69acaeb05e88ccbdd799be37af9635e537a75df",
        "excerpt_start_byte": 0,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "unit_id": "unit-0"
      }
    },
    {
      "category": "evidence",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "end_byte": 165,
        "quote": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "start_byte": 53
      },
      "actual": [
        {
          "evidence_id": "c-support",
          "excerpt_end_byte": 165,
          "excerpt_sha256": "befb0f8255b79a2ec7dee20cc69acaeb05e88ccbdd799be37af9635e537a75df",
          "excerpt_start_byte": 0,
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "unit_id": "unit-0"
        }
      ]
    },
    {
      "category": "concept",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "components": [
          "样例 B",
          "速度"
        ],
        "compound": "样例 B 速度"
      },
      "actual": {
        "additional_source_concepts": 0,
        "linked": [
          {
            "aliases": [],
            "canonical_name": "样例 B",
            "concept_id": "c-subject",
            "needs_full_explanation": true,
            "revision": 1
          },
          {
            "aliases": [],
            "canonical_name": "速度",
            "concept_id": "c-property",
            "needs_full_explanation": true,
            "revision": 1
          }
        ]
      }
    },
    {
      "category": "content",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
      "actual": "样例 B 的速度为 11 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
    },
    {
      "category": "fact",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "value": "11",
        "value_status": "known"
      },
      "actual": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "unit": "m/s",
        "value": "11",
        "value_status": "known"
      }
    },
    {
      "category": "unit",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "m/s",
      "actual": {
        "measurement": "m/s",
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "温度 20 ℃",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例B"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "仅适用成年样例 B",
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例B"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "condition_set",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "allowed_contexts": [],
        "required": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ]
      },
      "actual": {
        "body": [
          "温度20℃",
          "仅适用成年样例B"
        ],
        "measurement": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ]
      }
    },
    {
      "category": "exception",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": "结冰时不适用",
      "actual": {
        "body": [
          "结冰时不适用"
        ],
        "qualifiers": [
          "m/s",
          "温度 20 ℃",
          "仅适用成年样例 B",
          "结冰时不适用"
        ]
      }
    },
    {
      "category": "exception_set",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": [
        "结冰时不适用"
      ],
      "actual": [
        "结冰时不适用"
      ]
    },
    {
      "category": "qualifiers",
      "object_id": "c-speed",
      "unit_id": "unit-0",
      "start_byte": 0,
      "end_byte": 166,
      "status": "passed",
      "code": null,
      "expected": {
        "conditions": [
          "温度 20 ℃",
          "仅适用成年样例 B"
        ],
        "contexts": [],
        "exceptions": [
          "结冰时不适用"
        ],
        "unit": "m/s"
      },
      "actual": [
        "m/s",
        "温度 20 ℃",
        "仅适用成年样例 B",
        "结冰时不适用"
      ]
    }
  ],
  "totals": {
    "expected_atoms": 1,
    "passed": 1,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0,
    "candidate_atoms": 1,
    "unexpected_atoms": 0,
    "duplicate_atoms": 0,
    "required_concept_groups": 1,
    "additional_source_concepts": 0
  },
  "quality": {
    "binding": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "concept": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "condition": {
      "expected": 2,
      "passed": 2,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "content": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "coverage": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "evidence": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exception": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "exclusion": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "fact": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "schema": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "source": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    },
    "unit": {
      "expected": 1,
      "passed": 1,
      "failed": 0,
      "needs_review": 0,
      "unprocessed": 0,
      "status": "passed"
    }
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "candidates-original.json": {
      "sha256": "4be72ee4ed20850aa9772131b9abaae0bfef5e184b0220d66dc3308c7a4a45cd",
      "byte_length": 3057
    },
    "decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    "gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    "knowledge-ir.json": {
      "sha256": "83525b6f5092c57f1a5a53a506f1394043e5de1c6540a942b86c1d7b8514ef15",
      "byte_length": 12394
    },
    "review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    "source-snapshot.json": {
      "sha256": "a1fd1669bb862ab82644823c6eaca9a939eb0f7d8679620d4a4e29112816b9f2",
      "byte_length": 1056
    }
  }
}
```
