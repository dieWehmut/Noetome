# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "56a3dfd5-0bc3-4fca-bb0d-40393fb8af2a",
  "project_id": "922c78e5-f4f6-42d1-900e-6436878d004b",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "b5fa02cb8edbebe49c65df98a0cb731c1302e9612b9c2b76b6289e6f91848cc7",
    "byte_length": 40500
  },
  "plan_fingerprint": {
    "sha256": "7c6c60cb5a0829c41518ff3e141c41653f50b943f45a0f49e095e088115edc01",
    "byte_length": 17586
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "b5fa02cb8edbebe49c65df98a0cb731c1302e9612b9c2b76b6289e6f91848cc7",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "78b327285decb488ae00c60457064ae97fde61ce74e9cff31f6072abffa12e0d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "fcc6f557d767fd7beff4d210c05d0f0babb0dee322992fb61250dd657702e804",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "b8c542e4c8a037f0e6b5816e777d1b1fe49a092c63342c597671594b4a183c87",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "8dd42452f14b3f6c68ed2790a32e0ebcc81101c3695a3dd4b6996e293f146d07",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "cc58945cb3f6b1a88358e6dab3d6caa37c3f112e57222c26060fbc5f0ce53f9a",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "769082bb452cbf57b38165a877fa53035c8935d64f20f3209f60c7d9e781d3e2",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "772b4f895ceb250d8ea134e5ab9555e50a89cad26acab3c7e76c2919bbe3f11e",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "59459f1963e747e0ba948046a927e7d07a7a9350bbc3cb8f39f5605c5d5bbcbd",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "7e2dda8c4fceb87fcc179b6e7be6af37aef6dcccdc20434233b00963fb7e858c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e23b312e39c91a03d90076ed5f493ab828a1093fddd66f09411056796a7e9c99",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9be5c215e19b7e74ecb4b39bb6532af6a3be755caf47e6b66d1de1b1c5a43bba",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "0225bf1077d89e983d1a069481b3ff80139a16e12bdb696415c6d20e6405b2c5",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "a8785dcc94bb6bcb7fcb4c0347f2991032183a97d8ceb43e4b29046d97dbfcfc",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "d0174e90d28f53d637cdec37a85217cbf6ae775f20abc495c5542e1e035f46ae",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-98fe193ffeb36748f3443e486975e33758f544dda5f258ad67d034946cf674d4",
            "occ-ad07dd83fa26818a943b196e6eeebe68b4a740bc8932aa48b1b09e7e124b70f4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-ad07dd83fa26818a943b196e6eeebe68b4a740bc8932aa48b1b09e7e124b70f4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-ad07dd83fa26818a943b196e6eeebe68b4a740bc8932aa48b1b09e7e124b70f4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-98fe193ffeb36748f3443e486975e33758f544dda5f258ad67d034946cf674d4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-98fe193ffeb36748f3443e486975e33758f544dda5f258ad67d034946cf674d4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 538
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-ad07dd83fa26818a943b196e6eeebe68b4a740bc8932aa48b1b09e7e124b70f4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-98fe193ffeb36748f3443e486975e33758f544dda5f258ad67d034946cf674d4"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "b5fa02cb8edbebe49c65df98a0cb731c1302e9612b9c2b76b6289e6f91848cc7",
      "byte_length": 40500
    },
    ".coordination-owner.json": {
      "sha256": "78b327285decb488ae00c60457064ae97fde61ce74e9cff31f6072abffa12e0d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "fcc6f557d767fd7beff4d210c05d0f0babb0dee322992fb61250dd657702e804",
      "byte_length": 43971
    },
    ".coordination-report.md": {
      "sha256": "b8c542e4c8a037f0e6b5816e777d1b1fe49a092c63342c597671594b4a183c87",
      "byte_length": 44377
    },
    ".identity-original.json": {
      "sha256": "deb21a5f6ff4204bce2a2b0d3c688b6ae8192f642de8e3db9c56e343004b36c1",
      "byte_length": 2016
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "8dd42452f14b3f6c68ed2790a32e0ebcc81101c3695a3dd4b6996e293f146d07",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "cc58945cb3f6b1a88358e6dab3d6caa37c3f112e57222c26060fbc5f0ce53f9a",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "769082bb452cbf57b38165a877fa53035c8935d64f20f3209f60c7d9e781d3e2",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "772b4f895ceb250d8ea134e5ab9555e50a89cad26acab3c7e76c2919bbe3f11e",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "59459f1963e747e0ba948046a927e7d07a7a9350bbc3cb8f39f5605c5d5bbcbd",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "7e2dda8c4fceb87fcc179b6e7be6af37aef6dcccdc20434233b00963fb7e858c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "e23b312e39c91a03d90076ed5f493ab828a1093fddd66f09411056796a7e9c99",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9be5c215e19b7e74ecb4b39bb6532af6a3be755caf47e6b66d1de1b1c5a43bba",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "0225bf1077d89e983d1a069481b3ff80139a16e12bdb696415c6d20e6405b2c5",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "a8785dcc94bb6bcb7fcb4c0347f2991032183a97d8ceb43e4b29046d97dbfcfc",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "c07727aa61463612c0d55ee71120fb192b42280371b1a9f076cf574276a9da42",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "d0174e90d28f53d637cdec37a85217cbf6ae775f20abc495c5542e1e035f46ae",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "7c6c60cb5a0829c41518ff3e141c41653f50b943f45a0f49e095e088115edc01",
      "byte_length": 17586
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "69da9be6139060d33d813af1d2bf69f732d4cdbcc91a189e0a6b6edb90197e93",
      "byte_length": 542
    }
  }
}
```
