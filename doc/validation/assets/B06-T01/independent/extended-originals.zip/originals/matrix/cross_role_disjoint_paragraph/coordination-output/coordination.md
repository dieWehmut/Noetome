# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "d2a2bb87-9ac0-4031-9276-32b86e550536",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "61000000-0000-4000-8000-000000000001",
      "display_name": "速度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000002",
      "display_name": "密度"
    },
    {
      "canonical_id": "61000000-0000-4000-8000-000000000003",
      "display_name": "样例 B"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
        "import_id": "0d160b4f-6613-4f24-a3a4-79458c73c30d",
        "source_id": "16c08bf0-d6fc-4edf-a70d-f4dafe62565a",
        "version_id": "3efbf9b5-5013-474e-8883-7b261403d7ac",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-density"
            ],
            "decision": {
              "atom_ids": [
                "a-density"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "0d160b4f-6613-4f24-a3a4-79458c73c30d",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
              "source_id": "16c08bf0-d6fc-4edf-a70d-f4dafe62565a",
              "version_id": "3efbf9b5-5013-474e-8883-7b261403d7ac"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "import_id": "0d160b4f-6613-4f24-a3a4-79458c73c30d",
              "manifest_sha256": null,
              "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
              "parse_id": null,
              "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
              "source_id": "16c08bf0-d6fc-4edf-a70d-f4dafe62565a",
              "version_id": "3efbf9b5-5013-474e-8883-7b261403d7ac"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "速度",
              "密度"
            ],
            "compound": "速度 密度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "密度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "kg/m³",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "kg/m³",
          "actual": {
            "measurement": "kg/m³",
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg/m³",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-density",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg/m³"
          },
          "actual": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "ba454c47384cf6f30ef072ee05af224feafa6e7e4c9958bce45aeb42f18fdeb4",
          "byte_length": 3052
        },
        "decision-original.json": {
          "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
          "byte_length": 143
        },
        "gold-original.json": {
          "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "bf6eb9f9710e4da8ba77bb0d9fb32fceff9763f63f9fbe0145c72a63e1ef591c",
          "byte_length": 12391
        },
        "review-original.json": {
          "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
          "byte_length": 508
        },
        "source-snapshot.json": {
          "sha256": "900c450cc647bd67260ad4629fd793cf0230ce8fcd19e63e5864430daf54fc3a",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "51436f5000c9213386712572ed525f4e13cd8dac3bb309871cc6fa94f4694869",
          "byte_length": 16868
        },
        "verification.md": {
          "sha256": "e1ce09095a4345405e012e6b2a189d0916d9064e8874547711e07bc5029bde9b",
          "byte_length": 17302
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
        "import_id": "87168569-7db3-4361-9518-e3b217b84535",
        "source_id": "7764d2da-785a-470b-95b6-627339f96ebf",
        "version_id": "e1ef6668-a75d-49e3-b50b-e24cc3b3255e",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "87168569-7db3-4361-9518-e3b217b84535",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
              "source_id": "7764d2da-785a-470b-95b6-627339f96ebf",
              "version_id": "e1ef6668-a75d-49e3-b50b-e24cc3b3255e"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "import_id": "87168569-7db3-4361-9518-e3b217b84535",
              "manifest_sha256": null,
              "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
              "parse_id": null,
              "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
              "source_id": "7764d2da-785a-470b-95b6-627339f96ebf",
              "version_id": "e1ef6668-a75d-49e3-b50b-e24cc3b3255e"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 162,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 162,
            "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 162,
            "quote": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 162,
              "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "actual": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "仅适用所选样例",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用所选样例"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用所选样例"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用所选样例",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用所选样例"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "7e72f203d02daca14f89caaac8e5bb5e37836442d6653a0a45068475f7ef0ca7",
          "byte_length": 3047
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
          "byte_length": 735
        },
        "knowledge-ir.json": {
          "sha256": "b416a2fb731343e5c127b313100b34e3a1c5d357cdf184913adc7863bf69f04a",
          "byte_length": 12339
        },
        "review-original.json": {
          "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "e0cc4f71a28d5c193ddea86ecc06dc30a765bafc0096b9f198710eef9e4c9a2d",
          "byte_length": 1053
        },
        "verification.json": {
          "sha256": "d846c12e16e43016efdcb8091318f27b5efd660f6e0afa730885582802546bbc",
          "byte_length": 16821
        },
        "verification.md": {
          "sha256": "6c422d15a8790983170ecd6f0b6947c36a2669497ce87270c3f673cafce8803d",
          "byte_length": 17255
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2"
      },
      "occurrence_id": "occ-2c85bb3b4fca0da77169f586ca8a0fe753932093e7773eef14c52697c4a0e4e4",
      "input_id": "a",
      "binding": {
        "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
        "import_id": "0d160b4f-6613-4f24-a3a4-79458c73c30d",
        "source_id": "16c08bf0-d6fc-4edf-a70d-f4dafe62565a",
        "version_id": "3efbf9b5-5013-474e-8883-7b261403d7ac",
        "content_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "normalized_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a17291aa-3c73-4960-b28d-998b841bce6b",
          "ordinal": 0,
          "resource_sha256": "15547dc2fd7629b75b9f0059b44cbbe9db4a62074b35b7abe35196262ef7bb57"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "密度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-density",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "kg/m³",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg/m³",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "7906d552b75d2553333e5791d3e1c088b198b73d6d579d1086c831412f9d13c2",
          "quote": "适用条件：已列明；观点时间：2020年。\n速度的密度为 2 kg/m³，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000002"
      ],
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value": "2",
      "unit_value": "kg/m³",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 162,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
        "sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a"
      },
      "occurrence_id": "occ-c796e31cc25bfdab692af5e396ea87a2479ff64c6e7629065a15ea700e55016e",
      "input_id": "b",
      "binding": {
        "project_id": "bceb2b7f-7a37-4681-9db2-90f500faf90a",
        "import_id": "87168569-7db3-4361-9518-e3b217b84535",
        "source_id": "7764d2da-785a-470b-95b6-627339f96ebf",
        "version_id": "e1ef6668-a75d-49e3-b50b-e24cc3b3255e",
        "content_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "normalized_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "3957312b-a3a8-48ab-aa7f-6852546b7e95",
          "ordinal": 0,
          "resource_sha256": "672242b242bb0ec1c6dad05ec202e2231a423ae4594ac7303e1626deb96efa0c"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 163,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用所选样例",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用所选样例"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 162,
          "excerpt_sha256": "bfd5163212f0d5078689e2f0eeaabd55b92a3d9c56b050ecb396033a72a9221a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B的速度为 12 m/s，条件为温度 20 ℃且仅适用所选样例；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "61000000-0000-4000-8000-000000000001",
        "61000000-0000-4000-8000-000000000003"
      ],
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用所选样例"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c1c40591e2c22d5de81272dbe516ad6048213fe759765bbc5870dd5186bad07e",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "value_status": "known",
      "value": "2",
      "unit": "kg/m³",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-2c85bb3b4fca0da77169f586ca8a0fe753932093e7773eef14c52697c4a0e4e4"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-c79ac8bf87648134bd60174b6c26a8bcec4be97a06cf18b3843c69b63dc85fa2",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用所选样例",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-c796e31cc25bfdab692af5e396ea87a2479ff64c6e7629065a15ea700e55016e"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-2c85bb3b4fca0da77169f586ca8a0fe753932093e7773eef14c52697c4a0e4e4",
      "right_occurrence_id": "occ-c796e31cc25bfdab692af5e396ea87a2479ff64c6e7629065a15ea700e55016e",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-2c85bb3b4fca0da77169f586ca8a0fe753932093e7773eef14c52697c4a0e4e4",
      "object_id": "61000000-0000-4000-8000-000000000001",
      "property_id": "61000000-0000-4000-8000-000000000002",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-c796e31cc25bfdab692af5e396ea87a2479ff64c6e7629065a15ea700e55016e",
      "object_id": "61000000-0000-4000-8000-000000000003",
      "property_id": "61000000-0000-4000-8000-000000000001",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "ef3f477660a6d43f912a5c7c4aba7b9e70ded6fa5b436c11f9f395e46b73de2d",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "e43ab6fb5820121330b21528781ec1000bb48c4d25d51957ecef43e69a310cac",
      "byte_length": 41246
    },
    "coordination-original.json": {
      "sha256": "2b08eaff70e86fce5f71cb65055511a82302bcfe8f26ec77de658d6f2ccd0a43",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "092b241175aef975df1a5e20484b0dbb9f0efc6f46e88c34ce330e770b747d70",
      "byte_length": 2015
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "ba454c47384cf6f30ef072ee05af224feafa6e7e4c9958bce45aeb42f18fdeb4",
      "byte_length": 3052
    },
    "input-a--decision-original.json": {
      "sha256": "31ea0341d8431729a73a2de30a7ffedc681df746a3de30ddcd5c96dac45ce12e",
      "byte_length": 143
    },
    "input-a--gold-original.json": {
      "sha256": "d455c2b2910af29b82cb4aa1ce567170e9efff34e0ee5075fe7125e8b7dfb9ad",
      "byte_length": 735
    },
    "input-a--knowledge-ir.json": {
      "sha256": "bf6eb9f9710e4da8ba77bb0d9fb32fceff9763f63f9fbe0145c72a63e1ef591c",
      "byte_length": 12391
    },
    "input-a--review-original.json": {
      "sha256": "026a723af4fbb692740242b552d53bec5ab7d8ee7e657c99d2ab3f882d8e3014",
      "byte_length": 508
    },
    "input-a--source-snapshot.json": {
      "sha256": "900c450cc647bd67260ad4629fd793cf0230ce8fcd19e63e5864430daf54fc3a",
      "byte_length": 1053
    },
    "input-a--verification.json": {
      "sha256": "51436f5000c9213386712572ed525f4e13cd8dac3bb309871cc6fa94f4694869",
      "byte_length": 16868
    },
    "input-a--verification.md": {
      "sha256": "e1ce09095a4345405e012e6b2a189d0916d9064e8874547711e07bc5029bde9b",
      "byte_length": 17302
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "7e72f203d02daca14f89caaac8e5bb5e37836442d6653a0a45068475f7ef0ca7",
      "byte_length": 3047
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "fecf709f35e16eb034da868d75c6506eed331edaa628a10103ba73f9cc968023",
      "byte_length": 735
    },
    "input-b--knowledge-ir.json": {
      "sha256": "b416a2fb731343e5c127b313100b34e3a1c5d357cdf184913adc7863bf69f04a",
      "byte_length": 12339
    },
    "input-b--review-original.json": {
      "sha256": "1ef3a64598fcb6e6d05342ebff1eb1606bfabc025b36d48ac8b0117472ac6acd",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "e0cc4f71a28d5c193ddea86ecc06dc30a765bafc0096b9f198710eef9e4c9a2d",
      "byte_length": 1053
    },
    "input-b--verification.json": {
      "sha256": "d846c12e16e43016efdcb8091318f27b5efd660f6e0afa730885582802546bbc",
      "byte_length": 16821
    },
    "input-b--verification.md": {
      "sha256": "6c422d15a8790983170ecd6f0b6947c36a2669497ce87270c3f673cafce8803d",
      "byte_length": 17255
    }
  }
}
```
