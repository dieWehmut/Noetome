# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "1eb76c6c-17b5-4a87-be5b-ec5ce2820487",
  "project_id": "bfc4df60-8eab-49c5-aedb-da4c41b72df7",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "7bd05cdeaeba09e6c4183f1b67bc50eb15403572801d53307231d1755b26ff83",
    "byte_length": 41320
  },
  "plan_fingerprint": {
    "sha256": "1800088ea6c0c55dd14f4f7cec5f97c28e2dcb7881ed66852bc1c9603f7b8faf",
    "byte_length": 17030
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "7bd05cdeaeba09e6c4183f1b67bc50eb15403572801d53307231d1755b26ff83",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "80d6fa637c70d32fed36a3d9ed8a22eff7d0df822b0307bfc9fe817aa5a87bba",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "eb8b71ab59bae06603b084c30eee6d29d32a0f62c5df302a18b006bd788137f6",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "1d446a5baee697ef8fce482ea13fb33940af9b0f566f50a344661b269ff4887d",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f43b5a882c857cfb3f2c5c1719a8539ffdf53a933f35c3aa5d1e217ea4d1856e",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "1894e6e0c37ce1a91ef327008a91cff8495425411fdea64caed0368d03dbfef7",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f7dff6eed9f2605c45a924db6a5ebd089a3ddfd57bfd001c84b920a758933d5d",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "1bb594e16e61f0f24faa9c79fbf709d0c8fd412544d2e7e7244b5db54561e144",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "fa602acfc073d8c4649e0a0ccc2648f2acfc2ecf8f66fb7bfbf2cab5bf76c1fe",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c138ed10825403faca2aa398837c273b76ab932ce4a588bf4f1e3ed729e2d0fc",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "fd2dafb49192b1c26be763a43cffbf0664b7dae988625f4c23ff6d619d11c195",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "dda3db49bd37d687260b567da4e1ab5fe172f3744033c2fe077a05d5c73b445a",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "a3bdbd09fedfde0aef38f02e81817c75b1818e37b7572c1d1d1c3b299f8fdc8f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "61e74a151881f1c7cd7dcd1543eacd0aa9bbbde3fe3611cc85e9251ed11d6b50",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "eda6ce0e0c98b4bc6df6ae83dd2e419663bc754f33a9e632804a9d9256ae1cdd",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "53ec9cee7678cae316c01d296f9dce3e9bea6a11d62dd59f254f28b6e8fcaf97",
      "byte_length": 512,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2fe51a8ad002120e8e7cc73dc5e7575d60cf231f7a10c15fb5ed3f17fb5c7496",
            "occ-c6633265181a5a0a73b53a7e8e9bb9f7fedcc9e013bbdd80206213c49b376818"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-2fe51a8ad002120e8e7cc73dc5e7575d60cf231f7a10c15fb5ed3f17fb5c7496"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2fe51a8ad002120e8e7cc73dc5e7575d60cf231f7a10c15fb5ed3f17fb5c7496"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-c6633265181a5a0a73b53a7e8e9bb9f7fedcc9e013bbdd80206213c49b376818"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-c6633265181a5a0a73b53a7e8e9bb9f7fedcc9e013bbdd80206213c49b376818"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 508
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-2fe51a8ad002120e8e7cc73dc5e7575d60cf231f7a10c15fb5ed3f17fb5c7496"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "106b3677fe1925851d976f1144c84d715772f8feb1f9e98c18cc32f54f70684b",
      "byte_length": 299,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-c6633265181a5a0a73b53a7e8e9bb9f7fedcc9e013bbdd80206213c49b376818"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 297
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "7bd05cdeaeba09e6c4183f1b67bc50eb15403572801d53307231d1755b26ff83",
      "byte_length": 41320
    },
    ".coordination-owner.json": {
      "sha256": "80d6fa637c70d32fed36a3d9ed8a22eff7d0df822b0307bfc9fe817aa5a87bba",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "eb8b71ab59bae06603b084c30eee6d29d32a0f62c5df302a18b006bd788137f6",
      "byte_length": 44791
    },
    ".coordination-report.md": {
      "sha256": "1d446a5baee697ef8fce482ea13fb33940af9b0f566f50a344661b269ff4887d",
      "byte_length": 45266
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f43b5a882c857cfb3f2c5c1719a8539ffdf53a933f35c3aa5d1e217ea4d1856e",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "1894e6e0c37ce1a91ef327008a91cff8495425411fdea64caed0368d03dbfef7",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f7dff6eed9f2605c45a924db6a5ebd089a3ddfd57bfd001c84b920a758933d5d",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "1bb594e16e61f0f24faa9c79fbf709d0c8fd412544d2e7e7244b5db54561e144",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "fa602acfc073d8c4649e0a0ccc2648f2acfc2ecf8f66fb7bfbf2cab5bf76c1fe",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c138ed10825403faca2aa398837c273b76ab932ce4a588bf4f1e3ed729e2d0fc",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "fd2dafb49192b1c26be763a43cffbf0664b7dae988625f4c23ff6d619d11c195",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "dda3db49bd37d687260b567da4e1ab5fe172f3744033c2fe077a05d5c73b445a",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "a3bdbd09fedfde0aef38f02e81817c75b1818e37b7572c1d1d1c3b299f8fdc8f",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "61e74a151881f1c7cd7dcd1543eacd0aa9bbbde3fe3611cc85e9251ed11d6b50",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "4135c2299076d13f3df2bf7711853de219326d0dd70207a9dd64f0c2117d7e1e",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "eda6ce0e0c98b4bc6df6ae83dd2e419663bc754f33a9e632804a9d9256ae1cdd",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "1800088ea6c0c55dd14f4f7cec5f97c28e2dcb7881ed66852bc1c9603f7b8faf",
      "byte_length": 17030
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "106b3677fe1925851d976f1144c84d715772f8feb1f9e98c18cc32f54f70684b",
      "byte_length": 299
    },
    "知识比较.md": {
      "sha256": "53ec9cee7678cae316c01d296f9dce3e9bea6a11d62dd59f254f28b6e8fcaf97",
      "byte_length": 512
    }
  }
}
```
