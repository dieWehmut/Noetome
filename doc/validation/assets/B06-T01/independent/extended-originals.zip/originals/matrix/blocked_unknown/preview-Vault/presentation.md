# 有据主动表达预览

状态：needs_review；预览：not_run；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "d263302b-a95b-4664-8a36-8bccae49eff4",
  "project_id": "5312202c-dac9-4fc2-8654-3238aef3cf60",
  "coordination_schema_version": 3,
  "status": "needs_review",
  "preview_status": "not_run",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "needs_review",
    "note_plan": "not_run",
    "rendering": "not_run",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 0,
    "content_mappings": 0,
    "links": 0
  },
  "issue_codes": [
    "PRESENT_COORDINATION_UNRESOLVED"
  ],
  "decision": null,
  "coordination_ir_fingerprint": null,
  "plan_fingerprint": null,
  "inputs": {
    ".coordination-owner.json": {
      "sha256": "d6e189c1f121ae8dea956046bf97f65c632cb7b041f89b5ec1929861ed169cae",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "6ba084178dafefb788eda099021c91f62c1a27c43eb28a7dfc2fe78d054de924",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "260bea593fcf1fb0f44b583916d6d83f92521871f79c35e438d326291894f913",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a9ee05a8bf941e781cf3600eae67d21f530abbb31782faede473fd3a8c961e96",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "c3940fb4799328959f040cb28c74015f815f3e96a85a9a310dcfff140163a61e",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "30ce000c06d545fc3745ec71b4ce5f37c0c4075c9d054ff2f0e2dc504af1aeb3",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "15df0497bf9eded443fcc559fd434a4ee3cc2e61c69895d91a8f5c4aa1825f26",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "0eef685fee7338591e84d3331a816643bde7cb142ecde92ca322a768541e9921",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "024be79439c8459ad5105d7f0b3aa839ccc1136dc46e3a28c1a23c3be0ce7ab5",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "62fe470d46bee30e7019a897cdc3e39cd00705b24961de89ac664b8d1c4692e0",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c37a6fa26c51cb8b54cbfa6d2513ac8e400a5ce48f6b159571b1dd3cf4acf709",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "0c8900477fad9f7678320b7b9b4635042c8dce8e73fe321591cd58c266c723e4",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "47128259cafc450b8fe6618cc304b1b91d08e526bdbc66ae834f3618fd3db2a4",
      "byte_length": 14422
    },
    ".selection-original.json": {
      "sha256": "2b334f1b17a6282f37337810c3ef4cfc90716d9ccdb70f67ec04e06bafb6464b",
      "byte_length": 4326
    }
  },
  "files": [],
  "artifacts": {
    ".coordination-owner.json": {
      "sha256": "d6e189c1f121ae8dea956046bf97f65c632cb7b041f89b5ec1929861ed169cae",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "6ba084178dafefb788eda099021c91f62c1a27c43eb28a7dfc2fe78d054de924",
      "byte_length": 36961
    },
    ".coordination-report.md": {
      "sha256": "260bea593fcf1fb0f44b583916d6d83f92521871f79c35e438d326291894f913",
      "byte_length": 37442
    },
    ".identity-original.json": {
      "sha256": "a7fdca39a66949ba873ff3a64854fc37e4898ded43f2e3e6f934c7a21bdd3961",
      "byte_length": 2028
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a9ee05a8bf941e781cf3600eae67d21f530abbb31782faede473fd3a8c961e96",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "c3940fb4799328959f040cb28c74015f815f3e96a85a9a310dcfff140163a61e",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "30ce000c06d545fc3745ec71b4ce5f37c0c4075c9d054ff2f0e2dc504af1aeb3",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "15df0497bf9eded443fcc559fd434a4ee3cc2e61c69895d91a8f5c4aa1825f26",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "0eef685fee7338591e84d3331a816643bde7cb142ecde92ca322a768541e9921",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "024be79439c8459ad5105d7f0b3aa839ccc1136dc46e3a28c1a23c3be0ce7ab5",
      "byte_length": 2714
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "d4b2b2ba61a0813917225f6988d0c748738081348b92906da525739b1e1e8d3a",
      "byte_length": 503
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "62fe470d46bee30e7019a897cdc3e39cd00705b24961de89ac664b8d1c4692e0",
      "byte_length": 9252
    },
    ".input-b--review-original.json": {
      "sha256": "d7b206961a0d4cda21b317602f87961df8e9d3841c96440e1e0c2773217fc281",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c37a6fa26c51cb8b54cbfa6d2513ac8e400a5ce48f6b159571b1dd3cf4acf709",
      "byte_length": 974
    },
    ".input-b--verification.json": {
      "sha256": "0c8900477fad9f7678320b7b9b4635042c8dce8e73fe321591cd58c266c723e4",
      "byte_length": 13988
    },
    ".input-b--verification.md": {
      "sha256": "47128259cafc450b8fe6618cc304b1b91d08e526bdbc66ae834f3618fd3db2a4",
      "byte_length": 14422
    },
    ".owner.json": {
      "sha256": "3a49d6c2d6caf4750d37eff79977c860958721350a23652ef76a6eaec274c59b",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "2b334f1b17a6282f37337810c3ef4cfc90716d9ccdb70f67ec04e06bafb6464b",
      "byte_length": 4326
    }
  }
}
```
