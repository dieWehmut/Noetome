# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "e84597ee-bc5c-439f-800e-5d14cb6ef6d2",
  "project_id": "324d7536-4889-433c-a3fd-2872d567d8e5",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "596774363dc8414b94c611e2a249242eff63b6156d06da437d0640e8df51667d",
    "byte_length": 37417
  },
  "plan_fingerprint": {
    "sha256": "a5d85f40b08a03a85162ed47cbbec0b28f2526d7bb48eb2e75c7d01808c5daf3",
    "byte_length": 16487
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "596774363dc8414b94c611e2a249242eff63b6156d06da437d0640e8df51667d",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "f2262c7bd8b357886c199d8cdf63b7b8b66cc037146eb357ed49b2a8a907ab41",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "5b680337d593e1af91c5dbe5d31ad66afd6c15657b0429d110120867fdbb9120",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "1ebbe97d4b89e18ecb6f1f43c740df307232fe6b0322229d9cd53b023d93412e",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a6ac0707053ecf245199f1c10b1096ca981710a045ad2fc5d02dd6610fc44101",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "4b69946eacbe3f86ea394608c52acf72a94fd4ec248d253d383f98be5c4024d5",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f1368585aee98cfebca22ec43ce8be486486f6044117efcdcad097d3af1be7fd",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "783859e62eb942284afdefb9645a573066b1537b722610d00fa50aca215f610c",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "1cbe4dcbace7d0d9f2fac34ca12ef6ebf30095e61ed6fb3839ba6b66b9a286c0",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "68dfb4a85910efa3d655d922a7cbe7133cfa52aee39dfd5b05a96a6193511f8b",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "7670b4a9c0b83622025c139dafe9340e16dd5576e4da41df3216bb2ac5ccbcf7",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c34bdf799c0ad6aae29d0b664cab4432f75da9fccad492375a24cbaa6c2d591e",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "fbc2d041fa8fa499092bf2af68c1022caa1b6032d2a9a180000d520bd9c73d9d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5b52f692e8fbda5d5e3680c17b98c7c9858c303816bb3580bd332a2d811d40f1",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "566102d754961ac8fb561a538f36e80b0fd96fdbf529025695bac65d3f331071",
      "byte_length": 4328
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6b0fe8a60172128e9c8d2ab6ce9f4c5e12aa2ccf2827cca0d807e38f0905cc17",
            "occ-a7332ac67b4eb8e078a330ba520b9e5f8f4629d49727e9e31710b28fb6ee7fcc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-a7332ac67b4eb8e078a330ba520b9e5f8f4629d49727e9e31710b28fb6ee7fcc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-a7332ac67b4eb8e078a330ba520b9e5f8f4629d49727e9e31710b28fb6ee7fcc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 262
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6b0fe8a60172128e9c8d2ab6ce9f4c5e12aa2ccf2827cca0d807e38f0905cc17"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 267,
          "end_byte": 275
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-6b0fe8a60172128e9c8d2ab6ce9f4c5e12aa2ccf2827cca0d807e38f0905cc17"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 353,
          "end_byte": 499
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 276,
          "end_byte": 350
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-95e8db276f76bd15119bad7028219d48fc477e0c9514235cb1670fb20314e34a"
          ],
          "occurrence_ids": [
            "occ-a7332ac67b4eb8e078a330ba520b9e5f8f4629d49727e9e31710b28fb6ee7fcc"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 207
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-6b0fe8a60172128e9c8d2ab6ce9f4c5e12aa2ccf2827cca0d807e38f0905cc17"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "596774363dc8414b94c611e2a249242eff63b6156d06da437d0640e8df51667d",
      "byte_length": 37417
    },
    ".coordination-owner.json": {
      "sha256": "f2262c7bd8b357886c199d8cdf63b7b8b66cc037146eb357ed49b2a8a907ab41",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "5b680337d593e1af91c5dbe5d31ad66afd6c15657b0429d110120867fdbb9120",
      "byte_length": 40886
    },
    ".coordination-report.md": {
      "sha256": "1ebbe97d4b89e18ecb6f1f43c740df307232fe6b0322229d9cd53b023d93412e",
      "byte_length": 41361
    },
    ".identity-original.json": {
      "sha256": "f0d3f7038ea21bdab34f5b08437a7bc21dea371464fe84960e8c58a771c3a415",
      "byte_length": 2026
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "a6ac0707053ecf245199f1c10b1096ca981710a045ad2fc5d02dd6610fc44101",
      "byte_length": 2714
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "81b83b0378625c017ae838ca97fc42ef87dd1e76482169ea5941ba6d43730092",
      "byte_length": 503
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "4b69946eacbe3f86ea394608c52acf72a94fd4ec248d253d383f98be5c4024d5",
      "byte_length": 9252
    },
    ".input-a--review-original.json": {
      "sha256": "e5cb40bc7160b6d7ed133b4eedcc1863b7a8c683ea18d446a1eb2c06a651a9bd",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f1368585aee98cfebca22ec43ce8be486486f6044117efcdcad097d3af1be7fd",
      "byte_length": 974
    },
    ".input-a--verification.json": {
      "sha256": "783859e62eb942284afdefb9645a573066b1537b722610d00fa50aca215f610c",
      "byte_length": 13988
    },
    ".input-a--verification.md": {
      "sha256": "1cbe4dcbace7d0d9f2fac34ca12ef6ebf30095e61ed6fb3839ba6b66b9a286c0",
      "byte_length": 14422
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "68dfb4a85910efa3d655d922a7cbe7133cfa52aee39dfd5b05a96a6193511f8b",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "7670b4a9c0b83622025c139dafe9340e16dd5576e4da41df3216bb2ac5ccbcf7",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "c34bdf799c0ad6aae29d0b664cab4432f75da9fccad492375a24cbaa6c2d591e",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "fbc2d041fa8fa499092bf2af68c1022caa1b6032d2a9a180000d520bd9c73d9d",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "5b52f692e8fbda5d5e3680c17b98c7c9858c303816bb3580bd332a2d811d40f1",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "d6abd19b30f833b7f888a6b43ab238daab53d2f8252c1dc89eed69261d1eafe2",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "566102d754961ac8fb561a538f36e80b0fd96fdbf529025695bac65d3f331071",
      "byte_length": 4328
    },
    "plan.json": {
      "sha256": "a5d85f40b08a03a85162ed47cbbec0b28f2526d7bb48eb2e75c7d01808c5daf3",
      "byte_length": 16487
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a47bd72398e9e2edf02ce964fbf4d2e9652628ae9ba6292a5c4d4dd5b0c5942b",
      "byte_length": 209
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "d00c6c01885ae324dd627e4994eba1b453f4d92cc01dc6ec4b4a4b6f71e27477",
      "byte_length": 503
    }
  }
}
```
