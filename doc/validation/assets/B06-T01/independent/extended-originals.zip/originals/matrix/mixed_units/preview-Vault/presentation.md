# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "761c23db-5302-495a-87ca-cf9fe8a016cd",
  "project_id": "9f1425ba-e68b-47cc-a250-258d5777e298",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "22ade79856c6dfe752f96e97d6855f588188d4a0cc7b086b334341d268acc3c0",
    "byte_length": 41343
  },
  "plan_fingerprint": {
    "sha256": "568c36ace79308e64e6037d87de8fdd79ca8c8978009eab23aab25eaf0bdf6c1",
    "byte_length": 17164
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "22ade79856c6dfe752f96e97d6855f588188d4a0cc7b086b334341d268acc3c0",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "7369f2bef2b61703cd744a02b49d5e89001ae82e5eb3093574d5a521a1672a17",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "31c1334ff01ca17c45f94c6dca95997489b784c0d79a3d25f55a67690783d44e",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "96e6a9bd556175ca425bbfdd36d2a99f5bed5033120bd0b42a5ed3e2b7b7b9bc",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "99ef4a378de50b329ce3800def43f1b71b55f76830055ba7ec893dcf60b888dc",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "52dde88e9cd6004252bfa0e8e862bac92b1ce8f7d867a2cceab8b277069967f3",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "91eca20b87b51b366ad17d6a04254a7b4c582cf3a0d243876d0bc2233b73f23e",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "71e641569631486a94cf112c739efbcba92e75066d79b2b0a68c9bd0ca542ec0",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "03df1e61d7e1e3dce01ea8f208aa93464a8ab584bb41defaca86ab50609d582f",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "d6a342b37e363253bfcb2b81b1f71dadcdfa6483ef8610fdf56aa2413cf87629",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "12728d0ba90cc0f4cf1c9b31b3b2f0b62bb18b82769704da4241b64a3519846f",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9e0327c262aea84447267d653a6c1dc72899c5033430648e7516a3a162ebd770",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "51e355b56e66f804e97d95a314532378ff8bf2bc967f7881df3c4dc5b1889b1c",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "ab5d83cccd61bc84d83bc5395f0b31f569a5d2544e289dfadc647095c89eac9d",
      "byte_length": 17319
    },
    ".selection-original.json": {
      "sha256": "ab86ef3f60e6f84563d1427b662ef3e47af1bc5dbc793a8c471d12718c74c21c",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0eae328522f0b8d3bdee05302d19e2dde501bc9ca545ccb78d31cbe4a9c3cf78",
            "occ-8bbbdc018507ae504ce40fd781db8d75efc3f919f64c1aff4f42df43f4742c5f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-8bbbdc018507ae504ce40fd781db8d75efc3f919f64c1aff4f42df43f4742c5f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-8bbbdc018507ae504ce40fd781db8d75efc3f919f64c1aff4f42df43f4742c5f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 301
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0eae328522f0b8d3bdee05302d19e2dde501bc9ca545ccb78d31cbe4a9c3cf78"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 306,
          "end_byte": 314
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-0eae328522f0b8d3bdee05302d19e2dde501bc9ca545ccb78d31cbe4a9c3cf78"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 392,
          "end_byte": 539
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 315,
          "end_byte": 389
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-8bbbdc018507ae504ce40fd781db8d75efc3f919f64c1aff4f42df43f4742c5f"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d24e3d1d23da5c0e513b250f5bf42704e10cf6188b0314f0a80e3adb202a2d0b"
          ],
          "occurrence_ids": [
            "occ-0eae328522f0b8d3bdee05302d19e2dde501bc9ca545ccb78d31cbe4a9c3cf78"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 329
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "22ade79856c6dfe752f96e97d6855f588188d4a0cc7b086b334341d268acc3c0",
      "byte_length": 41343
    },
    ".coordination-owner.json": {
      "sha256": "7369f2bef2b61703cd744a02b49d5e89001ae82e5eb3093574d5a521a1672a17",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "31c1334ff01ca17c45f94c6dca95997489b784c0d79a3d25f55a67690783d44e",
      "byte_length": 44814
    },
    ".coordination-report.md": {
      "sha256": "96e6a9bd556175ca425bbfdd36d2a99f5bed5033120bd0b42a5ed3e2b7b7b9bc",
      "byte_length": 45289
    },
    ".identity-original.json": {
      "sha256": "ca6618e8dbdc2a97c701f0d61b52128843eeffc9d4419c91468b5ca6d080a405",
      "byte_length": 2017
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "99ef4a378de50b329ce3800def43f1b71b55f76830055ba7ec893dcf60b888dc",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "52dde88e9cd6004252bfa0e8e862bac92b1ce8f7d867a2cceab8b277069967f3",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "91eca20b87b51b366ad17d6a04254a7b4c582cf3a0d243876d0bc2233b73f23e",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "71e641569631486a94cf112c739efbcba92e75066d79b2b0a68c9bd0ca542ec0",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "03df1e61d7e1e3dce01ea8f208aa93464a8ab584bb41defaca86ab50609d582f",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "d6a342b37e363253bfcb2b81b1f71dadcdfa6483ef8610fdf56aa2413cf87629",
      "byte_length": 3061
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "c7d85457e109a8f026aca92c59edd2aac496673944904b5968a4e93d3a116f01",
      "byte_length": 750
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "12728d0ba90cc0f4cf1c9b31b3b2f0b62bb18b82769704da4241b64a3519846f",
      "byte_length": 12413
    },
    ".input-b--review-original.json": {
      "sha256": "5c4f17be361e0c8b42912db77d0c75b2e1b65e574e0b278f49db6f8bb8aacfff",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "9e0327c262aea84447267d653a6c1dc72899c5033430648e7516a3a162ebd770",
      "byte_length": 1057
    },
    ".input-b--verification.json": {
      "sha256": "51e355b56e66f804e97d95a314532378ff8bf2bc967f7881df3c4dc5b1889b1c",
      "byte_length": 16885
    },
    ".input-b--verification.md": {
      "sha256": "ab5d83cccd61bc84d83bc5395f0b31f569a5d2544e289dfadc647095c89eac9d",
      "byte_length": 17319
    },
    ".owner.json": {
      "sha256": "a1d5c01a2b0ed1559f6b50079751918b967682c35f55da506bb682f68638c51a",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "ab86ef3f60e6f84563d1427b662ef3e47af1bc5dbc793a8c471d12718c74c21c",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "568c36ace79308e64e6037d87de8fdd79ca8c8978009eab23aab25eaf0bdf6c1",
      "byte_length": 17164
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "f6c468881a5c68daf9940dd984987cff3dd924271e3840a6a60bc89043b98583",
      "byte_length": 331
    },
    "知识比较.md": {
      "sha256": "1a01d744ce3d5ae557bdf8600fa3312673f219ad10f2e251d341f52aa60ca265",
      "byte_length": 543
    }
  }
}
```
