# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：3；条件未知：0；条件不适用：0；时间已知：3；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "b6082d62-5bd3-4703-b093-f644e71efb9e",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000004",
      "display_name": "质量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
        "import_id": "3f7ef2b5-1a0e-4b40-abb3-3aca8eb84ad4",
        "source_id": "238dce6a-328b-40c7-b4aa-3166beb48316",
        "version_id": "855ac0e2-4b37-41b9-8acb-b0ec25a478b4",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "3f7ef2b5-1a0e-4b40-abb3-3aca8eb84ad4",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
              "source_id": "238dce6a-328b-40c7-b4aa-3166beb48316",
              "version_id": "855ac0e2-4b37-41b9-8acb-b0ec25a478b4"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "3f7ef2b5-1a0e-4b40-abb3-3aca8eb84ad4",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
              "source_id": "238dce6a-328b-40c7-b4aa-3166beb48316",
              "version_id": "855ac0e2-4b37-41b9-8acb-b0ec25a478b4"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "608fdb6e3801e916a9d38759a75334565f7176952f8bb25c042edc4a15c342d6",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "b9f07a757ee52742cb6ac70bd0d85a77615b7d5144800078b3f96ecc70caf548",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "466d290a48090252ab08c796360eaaeb801ee16ad0d12398451bcef1c6d1ce42",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "ed9908e838b804eb17c280445aef96cf3a070f2984e1814f4253a0094c1388eb",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "c941b1aa2f3d3f29d1b84c7b449b54910d0c3e35ebf02eb7f21ad01a2d3baf8e",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
        "import_id": "e1551689-e319-402b-9f97-f02f30873831",
        "source_id": "39b0e753-beb2-4d51-b156-334bbc71c9ba",
        "version_id": "2f27ba7f-1521-4b62-bfdb-869428d91062",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "e1551689-e319-402b-9f97-f02f30873831",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
              "source_id": "39b0e753-beb2-4d51-b156-334bbc71c9ba",
              "version_id": "2f27ba7f-1521-4b62-bfdb-869428d91062"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "e1551689-e319-402b-9f97-f02f30873831",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
              "source_id": "39b0e753-beb2-4d51-b156-334bbc71c9ba",
              "version_id": "2f27ba7f-1521-4b62-bfdb-869428d91062"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "d5a853fdfc5aaea10e7f2cb648307bcce49d74af40a888278eeec8e62dd9f83d",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "0f6f4dc5244af1cb5596b080062cabdfa1e8658ee7d9df223ff7feb73c2698b2",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "82456236ba951d02ba1f7089adfbf6b83abbfe4d0de8d3dcf991cc0df83a3d0b",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "94cc524491a3b283e20129bf8ff21623e432274a2d7e9bcab5deb9349154f17d",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "97ec4873433f40cc2aeff419d370358cc3d244d8647679acc916baa15ea383b4",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    },
    {
      "input_id": "c",
      "binding": {
        "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
        "import_id": "56ae2589-f3d3-44e3-a743-4f068f9962d9",
        "source_id": "7f42a39b-3deb-4266-93c9-e8673ee36ad6",
        "version_id": "f6029af5-9615-4ac6-97c7-9d98f9801ff5",
        "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
        "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-c",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "c-mass"
            ],
            "decision": {
              "atom_ids": [
                "c-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
              "import_id": "56ae2589-f3d3-44e3-a743-4f068f9962d9",
              "manifest_sha256": null,
              "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
              "parse_id": null,
              "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
              "source_id": "7f42a39b-3deb-4266-93c9-e8673ee36ad6",
              "version_id": "f6029af5-9615-4ac6-97c7-9d98f9801ff5"
            },
            "request_id": "synthetic-coordination-c"
          },
          "actual": {
            "binding": {
              "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
              "import_id": "56ae2589-f3d3-44e3-a743-4f068f9962d9",
              "manifest_sha256": null,
              "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
              "parse_id": null,
              "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
              "source_id": "7f42a39b-3deb-4266-93c9-e8673ee36ad6",
              "version_id": "f6029af5-9615-4ac6-97c7-9d98f9801ff5"
            },
            "request_id": "synthetic-coordination-c"
          }
        },
        {
          "category": "duplicate",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "c-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 164,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "c-support",
            "excerpt_end_byte": 163,
            "excerpt_sha256": "9cadacee37d5646d0a233efc1ca201e23ea54368cfdb997de80a3888cd9c4ba6",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "quote": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "c-support",
              "excerpt_end_byte": 163,
              "excerpt_sha256": "9cadacee37d5646d0a233efc1ca201e23ea54368cfdb997de80a3888cd9c4ba6",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "质量"
            ],
            "compound": "样例 A 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "c-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "c-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "c-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "c5784bcdf34eb0ff46e8646f7160099dc68e584bbf0235b99afaa441f3769750",
          "byte_length": 3049
        },
        "decision-original.json": {
          "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
          "byte_length": 741
        },
        "knowledge-ir.json": {
          "sha256": "f4be924276b43538c8376d36e0abb555bd9c442e661366ca9d4486b60ff93893",
          "byte_length": 12349
        },
        "review-original.json": {
          "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "7dbd37e649f70a8915251bcb3591ba7675f66d6432013f78f98199b33e8c1f54",
          "byte_length": 1054
        },
        "verification.json": {
          "sha256": "4ebb91108062c06e636d49eedca07dfb934fa6b1c4252eae07d76e9366d41f43",
          "byte_length": 16829
        },
        "verification.md": {
          "sha256": "ac0d0cc912b0dff88fb8ba92be97083be93d0df0a6dac26d39fdb85fe10ad5e5",
          "byte_length": 17263
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-c--.owner.json",
        "candidates-original.json": "input-c--candidates-original.json",
        "decision-original.json": "input-c--decision-original.json",
        "gold-original.json": "input-c--gold-original.json",
        "knowledge-ir.json": "input-c--knowledge-ir.json",
        "review-original.json": "input-c--review-original.json",
        "source-snapshot.json": "input-c--source-snapshot.json",
        "verification.json": "input-c--verification.json",
        "verification.md": "input-c--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "c-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 163,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "9cadacee37d5646d0a233efc1ca201e23ea54368cfdb997de80a3888cd9c4ba6"
      },
      "occurrence_id": "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db",
      "input_id": "c",
      "binding": {
        "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
        "import_id": "56ae2589-f3d3-44e3-a743-4f068f9962d9",
        "source_id": "7f42a39b-3deb-4266-93c9-e8673ee36ad6",
        "version_id": "f6029af5-9615-4ac6-97c7-9d98f9801ff5",
        "content_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
        "normalized_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "3d3a1116-bf1c-449a-843a-7273065086fd",
          "ordinal": 0,
          "resource_sha256": "fa563e77b5141b8de3a3af44a56d15e922d85f54802d224b41d2658a65b7b85a"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "c-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "c-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "c-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "c-subject",
            "c-property"
          ],
          "content": "样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "c-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "c-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 163,
          "excerpt_sha256": "9cadacee37d5646d0a233efc1ca201e23ea54368cfdb997de80a3888cd9c4ba6",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000004"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000004",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
      "input_id": "b",
      "binding": {
        "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
        "import_id": "e1551689-e319-402b-9f97-f02f30873831",
        "source_id": "39b0e753-beb2-4d51-b156-334bbc71c9ba",
        "version_id": "2f27ba7f-1521-4b62-bfdb-869428d91062",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "cc84bd32-6489-491d-9666-415887c2f3b7",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f",
      "input_id": "a",
      "binding": {
        "project_id": "9e15953e-33e9-4e1e-bdfa-4a9920509124",
        "import_id": "3f7ef2b5-1a0e-4b40-abb3-3aca8eb84ad4",
        "source_id": "238dce6a-328b-40c7-b4aa-3166beb48316",
        "version_id": "855ac0e2-4b37-41b9-8acb-b0ec25a478b4",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "21cff312-3171-4bc8-a534-1071aa0c3726",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000004",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
        "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db",
      "right_occurrence_id": "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
      "relation": "complement",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db",
      "right_occurrence_id": "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f",
      "relation": "complement",
      "issue_code": null
    },
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
      "right_occurrence_id": "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f",
      "relation": "duplicate",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-1374bdf380bad9b95b2ff48ecf1fd7dd74626b7fc8c6ec7029d2f5872d2d66db",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000004",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-2b796982429ad230b8d4f733da2a7a386a0a1dfd84e78ed544b88f66d38317a0",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-a9c12a39589aef8623e7db92c2de33cd1d947365d99cc105d76b11d7a2c5ef8f",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 3,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 3,
    "undated_occurrences": 0,
    "context_evidence_links": 3,
    "input_bundles": 3,
    "validated_input_bundles": 3,
    "input_atoms": 3,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 3,
    "evidence_links": 3,
    "independent_sources": 3,
    "duplicate_occurrences": 1,
    "passed": 3,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "d897b932673caf5ed165f3dea7371a721aba34fd00cb642440f9829bd73bf934",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "6b3e36d44b7732c2f232a319dd0620f458b7094e1d98c68d3e2acea3b7348d00",
      "byte_length": 60938
    },
    "coordination-original.json": {
      "sha256": "b5980d1abc7ec208f35cd5910a3916e3606f02ed46697b70dbbb0021615f8f20",
      "byte_length": 6402
    },
    "identity-original.json": {
      "sha256": "e6df143c93a3d3163ef2168757358a6a72dfcd4de92f7bbead3f2a0129b796d4",
      "byte_length": 2761
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "608fdb6e3801e916a9d38759a75334565f7176952f8bb25c042edc4a15c342d6",
      "byte_length": 3057
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "b9f07a757ee52742cb6ac70bd0d85a77615b7d5144800078b3f96ecc70caf548",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "466d290a48090252ab08c796360eaaeb801ee16ad0d12398451bcef1c6d1ce42",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "ed9908e838b804eb17c280445aef96cf3a070f2984e1814f4253a0094c1388eb",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "c941b1aa2f3d3f29d1b84c7b449b54910d0c3e35ebf02eb7f21ad01a2d3baf8e",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "d5a853fdfc5aaea10e7f2cb648307bcce49d74af40a888278eeec8e62dd9f83d",
      "byte_length": 3057
    },
    "input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    "input-b--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    "input-b--knowledge-ir.json": {
      "sha256": "0f6f4dc5244af1cb5596b080062cabdfa1e8658ee7d9df223ff7feb73c2698b2",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "82456236ba951d02ba1f7089adfbf6b83abbfe4d0de8d3dcf991cc0df83a3d0b",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "94cc524491a3b283e20129bf8ff21623e432274a2d7e9bcab5deb9349154f17d",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "97ec4873433f40cc2aeff419d370358cc3d244d8647679acc916baa15ea383b4",
      "byte_length": 17303
    },
    "input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    "input-c--candidates-original.json": {
      "sha256": "c5784bcdf34eb0ff46e8646f7160099dc68e584bbf0235b99afaa441f3769750",
      "byte_length": 3049
    },
    "input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    "input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    "input-c--knowledge-ir.json": {
      "sha256": "f4be924276b43538c8376d36e0abb555bd9c442e661366ca9d4486b60ff93893",
      "byte_length": 12349
    },
    "input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    "input-c--source-snapshot.json": {
      "sha256": "7dbd37e649f70a8915251bcb3591ba7675f66d6432013f78f98199b33e8c1f54",
      "byte_length": 1054
    },
    "input-c--verification.json": {
      "sha256": "4ebb91108062c06e636d49eedca07dfb934fa6b1c4252eae07d76e9366d41f43",
      "byte_length": 16829
    },
    "input-c--verification.md": {
      "sha256": "ac0d0cc912b0dff88fb8ba92be97083be93d0df0a6dac26d39fdb85fe10ad5e5",
      "byte_length": 17263
    }
  }
}
```
