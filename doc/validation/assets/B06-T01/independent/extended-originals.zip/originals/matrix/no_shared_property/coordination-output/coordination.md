# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "e5e9697a-cbc6-4645-b2ae-b59f4f0d9f7d",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例 A"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000004",
      "display_name": "质量"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
        "import_id": "776912c8-4858-405f-b4ac-3cdaf90c4c1d",
        "source_id": "ad0aafa4-70dc-4325-9db5-8b389f50f7a7",
        "version_id": "b156d747-cfad-4402-942d-81988ecdaf2c",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "776912c8-4858-405f-b4ac-3cdaf90c4c1d",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
              "source_id": "ad0aafa4-70dc-4325-9db5-8b389f50f7a7",
              "version_id": "b156d747-cfad-4402-942d-81988ecdaf2c"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "776912c8-4858-405f-b4ac-3cdaf90c4c1d",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
              "source_id": "ad0aafa4-70dc-4325-9db5-8b389f50f7a7",
              "version_id": "b156d747-cfad-4402-942d-81988ecdaf2c"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "2a710304efd4961e464cb98acd9268eb6e910cca527e0b0a575f5c95afcb3b64",
          "byte_length": 3057
        },
        "decision-original.json": {
          "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
          "byte_length": 141
        },
        "gold-original.json": {
          "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
          "byte_length": 747
        },
        "knowledge-ir.json": {
          "sha256": "27e21e6a765acc4a509bab3088171eddaa24eef7d2c308207333381be2893e82",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "f9b92c029791eb0392f21c66c64438c29f47c48ac64070ac2b79d4d76e12519c",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "d9e7b9fb14bc9e4532e92a847937ebfac1c71e2dce0f87033867362c7d1d99cd",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "66204659b8a3f2deb318dec52e7fbb48f88097f7709ad2047881ebb7d4996788",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
        "import_id": "76a54bff-5698-4358-b57c-7089c6fbe243",
        "source_id": "42763c47-6d40-4197-9658-54fdc18d817c",
        "version_id": "14fc2013-e6df-4f7d-95b9-63dcc3db1dc6",
        "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
        "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-mass"
            ],
            "decision": {
              "atom_ids": [
                "b-mass"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
              "import_id": "76a54bff-5698-4358-b57c-7089c6fbe243",
              "manifest_sha256": null,
              "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
              "parse_id": null,
              "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
              "source_id": "42763c47-6d40-4197-9658-54fdc18d817c",
              "version_id": "14fc2013-e6df-4f7d-95b9-63dcc3db1dc6"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
              "import_id": "76a54bff-5698-4358-b57c-7089c6fbe243",
              "manifest_sha256": null,
              "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
              "parse_id": null,
              "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
              "source_id": "42763c47-6d40-4197-9658-54fdc18d817c",
              "version_id": "14fc2013-e6df-4f7d-95b9-63dcc3db1dc6"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 163,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 164,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 163,
            "excerpt_sha256": "5806cc48446ac01e298ae5eef8daa4822f7c6c9c545999dc8d2d91472390b421",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 163,
            "quote": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 163,
              "excerpt_sha256": "5806cc48446ac01e298ae5eef8daa4822f7c6c9c545999dc8d2d91472390b421",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "质量"
            ],
            "compound": "样例 B 质量"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "质量",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "actual": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "2",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "unit": "kg",
            "value": "2",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "kg",
          "actual": {
            "measurement": "kg",
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 B",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "kg",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-mass",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 164,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "kg"
          },
          "actual": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "6568aad518b2bf56026df496888a7323836546fa586c1ebbb5657b4476ebbf31",
          "byte_length": 3049
        },
        "decision-original.json": {
          "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
          "byte_length": 741
        },
        "knowledge-ir.json": {
          "sha256": "6545d1f046cec1f4d5afce4589e21f3a6196b3b2141530fa11a5d2a310469877",
          "byte_length": 12349
        },
        "review-original.json": {
          "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
          "byte_length": 510
        },
        "source-snapshot.json": {
          "sha256": "4c7ec80c49e3575b764f5d415d7f1cb6795e25527ec1b606683ad815413ec1aa",
          "byte_length": 1054
        },
        "verification.json": {
          "sha256": "608b4af5c26ca4a32c1a0d5b2c24b1adaba7c104bc44e80a81c8a5475a849f8c",
          "byte_length": 16829
        },
        "verification.md": {
          "sha256": "b91fad588c0521edca3379ae6defc5de91184f8a9447ff11e99c514979c7c8ee",
          "byte_length": 17263
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-3161947db827f669b041d17efcf2d808f72c3a5a22c48765730126ebd7065456",
      "input_id": "a",
      "binding": {
        "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
        "import_id": "776912c8-4858-405f-b4ac-3cdaf90c4c1d",
        "source_id": "ad0aafa4-70dc-4325-9db5-8b389f50f7a7",
        "version_id": "b156d747-cfad-4402-942d-81988ecdaf2c",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "46861f67-4490-4533-acc7-2a5e9dc5a14a",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 163,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "sha256": "5806cc48446ac01e298ae5eef8daa4822f7c6c9c545999dc8d2d91472390b421"
      },
      "occurrence_id": "occ-44f00bf627f6ec3de8be8137ebb46d95db84f802e7b10c37b61a046bbc187056",
      "input_id": "b",
      "binding": {
        "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
        "import_id": "76a54bff-5698-4358-b57c-7089c6fbe243",
        "source_id": "42763c47-6d40-4197-9658-54fdc18d817c",
        "version_id": "14fc2013-e6df-4f7d-95b9-63dcc3db1dc6",
        "content_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
        "normalized_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "f26792b9-94f2-4a75-afc2-2bfa2a72d66d",
          "ordinal": 0,
          "resource_sha256": "0ea47be702ef59914d3dae99febf6cb3cb13e628bc71d3f590c9f20100906cf1"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 164,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "质量",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-mass",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "qualifiers": [
            "kg",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "2",
          "unit": "kg",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 B"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 163,
          "excerpt_sha256": "5806cc48446ac01e298ae5eef8daa4822f7c6c9c545999dc8d2d91472390b421",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的质量为 2 kg，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000004"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000004",
      "value": "2",
      "unit_value": "kg",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 B"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000004",
      "value_status": "known",
      "value": "2",
      "unit": "kg",
      "conditions": [
        "仅适用成年样例B",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-44f00bf627f6ec3de8be8137ebb46d95db84f802e7b10c37b61a046bbc187056"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-3161947db827f669b041d17efcf2d808f72c3a5a22c48765730126ebd7065456"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-3161947db827f669b041d17efcf2d808f72c3a5a22c48765730126ebd7065456",
      "right_occurrence_id": "occ-44f00bf627f6ec3de8be8137ebb46d95db84f802e7b10c37b61a046bbc187056",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-3161947db827f669b041d17efcf2d808f72c3a5a22c48765730126ebd7065456",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-44f00bf627f6ec3de8be8137ebb46d95db84f802e7b10c37b61a046bbc187056",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000004",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "ea6cb4702f075afa732c6befee5a211fc35bd50fe5bdc0cd8296878c7795c24b",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "7455dfd4a7f2c0fb2c435bc8435f3ac2cb8e9204c94c013353ec2f5bf8cbda0a",
      "byte_length": 41373
    },
    "coordination-original.json": {
      "sha256": "ef09fa86dbcea794e066e4ea3137a244c8912a8c3fa4fdbdacb47d0f119b749e",
      "byte_length": 4330
    },
    "identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "2a710304efd4961e464cb98acd9268eb6e910cca527e0b0a575f5c95afcb3b64",
      "byte_length": 3057
    },
    "input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    "input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    "input-a--knowledge-ir.json": {
      "sha256": "27e21e6a765acc4a509bab3088171eddaa24eef7d2c308207333381be2893e82",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    "input-a--source-snapshot.json": {
      "sha256": "f9b92c029791eb0392f21c66c64438c29f47c48ac64070ac2b79d4d76e12519c",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "d9e7b9fb14bc9e4532e92a847937ebfac1c71e2dce0f87033867362c7d1d99cd",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "66204659b8a3f2deb318dec52e7fbb48f88097f7709ad2047881ebb7d4996788",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "6568aad518b2bf56026df496888a7323836546fa586c1ebbb5657b4476ebbf31",
      "byte_length": 3049
    },
    "input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    "input-b--knowledge-ir.json": {
      "sha256": "6545d1f046cec1f4d5afce4589e21f3a6196b3b2141530fa11a5d2a310469877",
      "byte_length": 12349
    },
    "input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    "input-b--source-snapshot.json": {
      "sha256": "4c7ec80c49e3575b764f5d415d7f1cb6795e25527ec1b606683ad815413ec1aa",
      "byte_length": 1054
    },
    "input-b--verification.json": {
      "sha256": "608b4af5c26ca4a32c1a0d5b2c24b1adaba7c104bc44e80a81c8a5475a849f8c",
      "byte_length": 16829
    },
    "input-b--verification.md": {
      "sha256": "b91fad588c0521edca3379ae6defc5de91184f8a9447ff11e99c514979c7c8ee",
      "byte_length": 17263
    }
  }
}
```
