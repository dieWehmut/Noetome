# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "6083f909-2245-4734-90ef-2c528c85ce1f",
  "project_id": "e8c4cc4c-bf81-4ce7-aeb6-3260fe9ff4b7",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 2,
    "table_cells": 0,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 4,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_NO_SHARED_PROPERTY_TEXT",
    "reason": "选定对象没有共同的显式属性，以正文分别保留各自事实。",
    "shared_property_ids": []
  },
  "coordination_ir_fingerprint": {
    "sha256": "7455dfd4a7f2c0fb2c435bc8435f3ac2cb8e9204c94c013353ec2f5bf8cbda0a",
    "byte_length": 41373
  },
  "plan_fingerprint": {
    "sha256": "4e739de6b87bbef372e8fa89082c894cb548cc646b3e6e7224ad960397cbf4d0",
    "byte_length": 14709
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "7455dfd4a7f2c0fb2c435bc8435f3ac2cb8e9204c94c013353ec2f5bf8cbda0a",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "ea6cb4702f075afa732c6befee5a211fc35bd50fe5bdc0cd8296878c7795c24b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "8eec40c2235bcdd88f15139d9f978a9c2782c18fceb95987bc93ee9e576fb6d8",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "c024a5599ef9c19594de59aba79f0ddc8a3f9c4f9727efbbd6b17e12341a3d65",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "2a710304efd4961e464cb98acd9268eb6e910cca527e0b0a575f5c95afcb3b64",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "27e21e6a765acc4a509bab3088171eddaa24eef7d2c308207333381be2893e82",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f9b92c029791eb0392f21c66c64438c29f47c48ac64070ac2b79d4d76e12519c",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "d9e7b9fb14bc9e4532e92a847937ebfac1c71e2dce0f87033867362c7d1d99cd",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "66204659b8a3f2deb318dec52e7fbb48f88097f7709ad2047881ebb7d4996788",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6568aad518b2bf56026df496888a7323836546fa586c1ebbb5657b4476ebbf31",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6545d1f046cec1f4d5afce4589e21f3a6196b3b2141530fa11a5d2a310469877",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4c7ec80c49e3575b764f5d415d7f1cb6795e25527ec1b606683ad815413ec1aa",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "608b4af5c26ca4a32c1a0d5b2c24b1adaba7c104bc44e80a81c8a5475a849f8c",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "b91fad588c0521edca3379ae6defc5de91184f8a9447ff11e99c514979c7c8ee",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "ef09fa86dbcea794e066e4ea3137a244c8912a8c3fa4fdbdacb47d0f119b749e",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-44f00bf627f6ec3de8be8137ebb46d95db84f802e7b10c37b61a046bbc187056"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 33,
          "end_byte": 196
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-3161947db827f669b041d17efcf2d808f72c3a5a22c48765730126ebd7065456"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 272,
          "end_byte": 438
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 197,
          "end_byte": 270
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "overview-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 439,
          "end_byte": 512
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-3161947db827f669b041d17efcf2d808f72c3a5a22c48765730126ebd7065456"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b0f51a5984f153b1e26a75fd8d9b032ed89b51cc1a88d4c6556b48a13755750b"
          ],
          "occurrence_ids": [
            "occ-44f00bf627f6ec3de8be8137ebb46d95db84f802e7b10c37b61a046bbc187056"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "7455dfd4a7f2c0fb2c435bc8435f3ac2cb8e9204c94c013353ec2f5bf8cbda0a",
      "byte_length": 41373
    },
    ".coordination-owner.json": {
      "sha256": "ea6cb4702f075afa732c6befee5a211fc35bd50fe5bdc0cd8296878c7795c24b",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "8eec40c2235bcdd88f15139d9f978a9c2782c18fceb95987bc93ee9e576fb6d8",
      "byte_length": 44844
    },
    ".coordination-report.md": {
      "sha256": "c024a5599ef9c19594de59aba79f0ddc8a3f9c4f9727efbbd6b17e12341a3d65",
      "byte_length": 45319
    },
    ".identity-original.json": {
      "sha256": "7d1550b0e6e24b0c1c1d89ce3ed5d02202b25ca7ad16f40bc660ea118ee99360",
      "byte_length": 2121
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "2a710304efd4961e464cb98acd9268eb6e910cca527e0b0a575f5c95afcb3b64",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "27e21e6a765acc4a509bab3088171eddaa24eef7d2c308207333381be2893e82",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "f9b92c029791eb0392f21c66c64438c29f47c48ac64070ac2b79d4d76e12519c",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "d9e7b9fb14bc9e4532e92a847937ebfac1c71e2dce0f87033867362c7d1d99cd",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "66204659b8a3f2deb318dec52e7fbb48f88097f7709ad2047881ebb7d4996788",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "6568aad518b2bf56026df496888a7323836546fa586c1ebbb5657b4476ebbf31",
      "byte_length": 3049
    },
    ".input-b--decision-original.json": {
      "sha256": "593b08efd162ccc71b577b5319f16e1dbc98ee8cc11b5334c3e5605cacd189e2",
      "byte_length": 140
    },
    ".input-b--gold-original.json": {
      "sha256": "8e8a85d8816651a38793992fbda2937e659dd0921bb38c2da321d0575459ef2f",
      "byte_length": 741
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "6545d1f046cec1f4d5afce4589e21f3a6196b3b2141530fa11a5d2a310469877",
      "byte_length": 12349
    },
    ".input-b--review-original.json": {
      "sha256": "0e405ba0f28594dd78e7f3e05123898af7840c9bee23a5dca3250fc07cecd683",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4c7ec80c49e3575b764f5d415d7f1cb6795e25527ec1b606683ad815413ec1aa",
      "byte_length": 1054
    },
    ".input-b--verification.json": {
      "sha256": "608b4af5c26ca4a32c1a0d5b2c24b1adaba7c104bc44e80a81c8a5475a849f8c",
      "byte_length": 16829
    },
    ".input-b--verification.md": {
      "sha256": "b91fad588c0521edca3379ae6defc5de91184f8a9447ff11e99c514979c7c8ee",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "6fa7ffe051b349fc949d4d3fabf392df83d3f6addd372bac1903e979224df59e",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "ef09fa86dbcea794e066e4ea3137a244c8912a8c3fa4fdbdacb47d0f119b749e",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "4e739de6b87bbef372e8fa89082c894cb548cc646b3e6e7224ad960397cbf4d0",
      "byte_length": 14709
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "6b9ca30f5b92973624cecf2571b8a984b517b8d9de37e7e66ba3b8d7d0e78f58",
      "byte_length": 329
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "8b2e0944f82670f9cb2e47a734631e3509d6a40ab786ca22a2716b324d48c877",
      "byte_length": 323
    },
    "知识比较.md": {
      "sha256": "c6035579945c5f50b9e3730357e675bf55fe11df47ad3811d5381f2a7ed25206",
      "byte_length": 514
    }
  }
}
```
