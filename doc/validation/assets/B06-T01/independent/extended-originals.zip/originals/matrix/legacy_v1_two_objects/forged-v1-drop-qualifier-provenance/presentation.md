# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "6768ae5a-9075-4153-9486-e20fa161189d",
  "project_id": "6d7932d2-e74e-4736-97f2-e0a6291361de",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "9608eb3ddb5b25afc8de339a447bdc5d7b4653b0d5d6a84321e8b63d36437b7a",
    "byte_length": 38360
  },
  "plan_fingerprint": {
    "sha256": "84abf7f7b8d47b9a4b0a6b4941705afe1b0220a72faf9b80b158a3887607ecae",
    "byte_length": 16372
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "9608eb3ddb5b25afc8de339a447bdc5d7b4653b0d5d6a84321e8b63d36437b7a",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "507f417158f6162df54162238a5575174d10d84505b9149fcc324eccd5203ef7",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "94f1c980696cf041edcad3ee6b2a227cc0da0071a629204bccae09c2ca3af123",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "adf1e3cd4f3a38f16056df8b29732d2cd95690c7f3bd6e0bcf183dd65ed957bd",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "42091c65bdc88b26ccef0fd0e158534a3583e07c30f0c2d036baac1039787e5d",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "18aa24ba71f964398ee76bb88eac8879d5a6a0ff2cd218e57877de27cadb499c",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9cbbd7f061e7e2b7f7c08145f5bfdc7b1b2fcd4b5e7f7f961e74f4465f121b8b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "afa84600540fde6f3f3f2075daa85e36d11e321fcc2e24a0e0117126763d1b59",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "8e22aa8a0cd3ffb38cdcb411a347c0d292a37c8afc90ad05e1b5139d8c0e2be1",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9b8cbe78abf1b41b7bb10eed96cfbdae2a62a8a3618d332cc83c72f9788463ef",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "78f5f1c1d4907935d58cf4f6c451fa26741b8dc6be95b6d3a3c285e456d6c419",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "13004f59e91df1a8df9b26e4a283bbb2aec7a9db8766a6b0e70027ea0fc84998",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "e24bc8b3a2b77059d61fcab9d054d55c9946082710413624df5750922e23c17a",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "efc65df961be3ac5a753f3ae2ae449c6892ec7eef664cc9cf715e15e812d98ec",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "9ff7d2f442cf21a343dd161d6c6337192de4ac7bc1ba935f3c76347699795130",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-b661d339e3ba88af4b4b4805409b46b4b979dd0c2d783325b97634a299ea0538",
            "occ-dc51ce56eca58350930f0649c0fb0103f36a4b31dd2eab626f7efe33b71eabed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-dc51ce56eca58350930f0649c0fb0103f36a4b31dd2eab626f7efe33b71eabed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-dc51ce56eca58350930f0649c0fb0103f36a4b31dd2eab626f7efe33b71eabed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-b661d339e3ba88af4b4b4805409b46b4b979dd0c2d783325b97634a299ea0538"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 332,
          "end_byte": 340
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-b661d339e3ba88af4b4b4805409b46b4b979dd0c2d783325b97634a299ea0538"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 418,
          "end_byte": 590
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 341,
          "end_byte": 415
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-dc51ce56eca58350930f0649c0fb0103f36a4b31dd2eab626f7efe33b71eabed"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-b661d339e3ba88af4b4b4805409b46b4b979dd0c2d783325b97634a299ea0538"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "9608eb3ddb5b25afc8de339a447bdc5d7b4653b0d5d6a84321e8b63d36437b7a",
      "byte_length": 38360
    },
    ".coordination-owner.json": {
      "sha256": "507f417158f6162df54162238a5575174d10d84505b9149fcc324eccd5203ef7",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "94f1c980696cf041edcad3ee6b2a227cc0da0071a629204bccae09c2ca3af123",
      "byte_length": 41831
    },
    ".coordination-report.md": {
      "sha256": "adf1e3cd4f3a38f16056df8b29732d2cd95690c7f3bd6e0bcf183dd65ed957bd",
      "byte_length": 42146
    },
    ".identity-original.json": {
      "sha256": "cb94454381df325b3e4fa9c0d6860b3226c1352bffd48ee50d04c38e87d0189f",
      "byte_length": 1437
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "42091c65bdc88b26ccef0fd0e158534a3583e07c30f0c2d036baac1039787e5d",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "18aa24ba71f964398ee76bb88eac8879d5a6a0ff2cd218e57877de27cadb499c",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9cbbd7f061e7e2b7f7c08145f5bfdc7b1b2fcd4b5e7f7f961e74f4465f121b8b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "afa84600540fde6f3f3f2075daa85e36d11e321fcc2e24a0e0117126763d1b59",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "8e22aa8a0cd3ffb38cdcb411a347c0d292a37c8afc90ad05e1b5139d8c0e2be1",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "9b8cbe78abf1b41b7bb10eed96cfbdae2a62a8a3618d332cc83c72f9788463ef",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "78f5f1c1d4907935d58cf4f6c451fa26741b8dc6be95b6d3a3c285e456d6c419",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "13004f59e91df1a8df9b26e4a283bbb2aec7a9db8766a6b0e70027ea0fc84998",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "e24bc8b3a2b77059d61fcab9d054d55c9946082710413624df5750922e23c17a",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "efc65df961be3ac5a753f3ae2ae449c6892ec7eef664cc9cf715e15e812d98ec",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "e9b79078de95508e5474f6ba365c0391f7939193e6a0f915830af0a2e221c758",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "9ff7d2f442cf21a343dd161d6c6337192de4ac7bc1ba935f3c76347699795130",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "84abf7f7b8d47b9a4b0a6b4941705afe1b0220a72faf9b80b158a3887607ecae",
      "byte_length": 16372
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "7a773237f2f34ca832fa40aad1e225758c5dd30f18181c86f12f2bb133c12b16",
      "byte_length": 355
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "fdc894a03acbe8c52d94f6b43402096be97e75823926dcfc2f4a54a223b02bcf",
      "byte_length": 594
    }
  }
}
```
