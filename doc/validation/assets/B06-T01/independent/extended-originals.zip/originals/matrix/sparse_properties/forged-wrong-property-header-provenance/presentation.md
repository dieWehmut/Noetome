# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "9361f948-6254-4968-851f-9dccadccbec9",
  "project_id": "62ab47e0-1dfe-4bc8-89d3-d27e05572520",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 2,
    "table_cells": 6,
    "missing_cells": 1,
    "rendered_notes": 3,
    "content_mappings": 12,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "608682eb4e765e5ad0cf5d7900de228f3743946753384676ba3fcb60ad0dce0d",
    "byte_length": 61731
  },
  "plan_fingerprint": {
    "sha256": "5f29b632f775927f4ba3a1748b0cbf9996d4b3ad31fc93020984b9c8ec18528e",
    "byte_length": 24185
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "608682eb4e765e5ad0cf5d7900de228f3743946753384676ba3fcb60ad0dce0d",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "acd8ddb87e6682dcf892e922af5e0e2d1fb113ceebd2dfc8cf01d1c13afdd4ef",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c6bde439b8e46e7ddaa807c985018d49e318ff49a2b756df6f60a700677cf9ba",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "678c80e22e2447d9c02094fe3fbb0b2f123a103d4d10b63b5090c76ce2975b57",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "28a785f984cf133d6ab4ad2dd1cbc5f6c6d9fbd1613a8f0571b35c1d46325b39",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "0f69e1af426eb6520097900073861f0731ca5c52382b5f4ed668da176dee0833",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9f8bea68a8f125ffad0e3f97d0349005c6a6a8b913b23a17e02bdbf41ffdad41",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "52eb2bd93633bad3790e7f2ce3c5d5afa3d6366aab0ef90db43ae61b43392436",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7bc732272d261c47ac24941087bac536276b80566f6d30e8bf8697460cd11290",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "99cd1712c103873082c0157aa9f6b42f6b511742770c0f34cd1cc3b45c407110",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "05b1a1eebd75c64cbf793cd1557573b3ba4c940053eb20aaea90d6290fafe279",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4aee139822d123eeaa8e67072aa1b26f2802a1b9d532b08b74505fd566ecf255",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "dfb07b99d58642ab2333afad2ab8d40814ed3bc5676ba0c5d3c777635e15671c",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "23102743e4d89842e0d065b128738ac271e28528fdf3998766ef31c3363c7f4d",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "38852c0ebbade92f0be538c7813c8e590b4a5a21a517cbc9419866a972bb9f87",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "c9f053eb6791b3fec2566ca85db0c89cc1a7442946801b8657d128d9eaeab75c",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "f53de6c9f02e9cac03a4b06437cbdfd0beb7a1aba5133257c96313ff9559f432",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "87a069ca180c2bd23849eb5a8a39bd0c72e13dfee9e4b9f2bd016a6b31bd581f",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "77c2d0346b464f26629e040b6b50253822ad2d8ca7c95ee1b2d30267d54c8e92",
      "byte_length": 17263
    },
    ".selection-original.json": {
      "sha256": "7352f5b1a7a11bcd65c43147a1a8e0f777641223a958c468065bb5084efcd2a6",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "1f43fd9b6aa8c2048cf92ffefae9906f0e820abf857473bedbb47f162a2df2d1",
      "byte_length": 727,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-692122b3148e4d019116fdcbd2b292f0111cf042444f1a5b8dc7a1a46609ae2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-16b76464ca797732648ec53f92d7f8f30cf2f47f577d65e4fb4b96a22ee8a207",
            "occ-51d77934eb880d5c2cf5bfc460ae43956382d821efdc2d06cfc8fd299c151637"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 53,
          "end_byte": 59
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-16b76464ca797732648ec53f92d7f8f30cf2f47f577d65e4fb4b96a22ee8a207",
            "occ-692122b3148e4d019116fdcbd2b292f0111cf042444f1a5b8dc7a1a46609ae2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 84,
          "end_byte": 92
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-16b76464ca797732648ec53f92d7f8f30cf2f47f577d65e4fb4b96a22ee8a207"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 170,
          "end_byte": 316
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-692122b3148e4d019116fdcbd2b292f0111cf042444f1a5b8dc7a1a46609ae2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 319,
          "end_byte": 462
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-51d77934eb880d5c2cf5bfc460ae43956382d821efdc2d06cfc8fd299c151637"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 467,
          "end_byte": 475
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-51d77934eb880d5c2cf5bfc460ae43956382d821efdc2d06cfc8fd299c151637"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 553,
          "end_byte": 699
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "missing",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000004"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 702,
          "end_byte": 723
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 93,
          "end_byte": 167
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 476,
          "end_byte": 550
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-242a3b2e27c64fb47847a4a7c3b6ac29f7968a39317917012768912585feb493"
          ],
          "occurrence_ids": [
            "occ-692122b3148e4d019116fdcbd2b292f0111cf042444f1a5b8dc7a1a46609ae2c"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000004"
          ],
          "start_byte": 29,
          "end_byte": 321
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-16b76464ca797732648ec53f92d7f8f30cf2f47f577d65e4fb4b96a22ee8a207"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 323,
          "end_byte": 621
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-51d77934eb880d5c2cf5bfc460ae43956382d821efdc2d06cfc8fd299c151637"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "608682eb4e765e5ad0cf5d7900de228f3743946753384676ba3fcb60ad0dce0d",
      "byte_length": 61731
    },
    ".coordination-owner.json": {
      "sha256": "acd8ddb87e6682dcf892e922af5e0e2d1fb113ceebd2dfc8cf01d1c13afdd4ef",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c6bde439b8e46e7ddaa807c985018d49e318ff49a2b756df6f60a700677cf9ba",
      "byte_length": 66589
    },
    ".coordination-report.md": {
      "sha256": "678c80e22e2447d9c02094fe3fbb0b2f123a103d4d10b63b5090c76ce2975b57",
      "byte_length": 67064
    },
    ".identity-original.json": {
      "sha256": "43656950de20cd4cf22bdf7eb77a0ffd725d1ef910ce33f408f8d5e5a8fd4abc",
      "byte_length": 2869
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "28a785f984cf133d6ab4ad2dd1cbc5f6c6d9fbd1613a8f0571b35c1d46325b39",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "0f69e1af426eb6520097900073861f0731ca5c52382b5f4ed668da176dee0833",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "9f8bea68a8f125ffad0e3f97d0349005c6a6a8b913b23a17e02bdbf41ffdad41",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "52eb2bd93633bad3790e7f2ce3c5d5afa3d6366aab0ef90db43ae61b43392436",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "7bc732272d261c47ac24941087bac536276b80566f6d30e8bf8697460cd11290",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "99cd1712c103873082c0157aa9f6b42f6b511742770c0f34cd1cc3b45c407110",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "05b1a1eebd75c64cbf793cd1557573b3ba4c940053eb20aaea90d6290fafe279",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "4aee139822d123eeaa8e67072aa1b26f2802a1b9d532b08b74505fd566ecf255",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "dfb07b99d58642ab2333afad2ab8d40814ed3bc5676ba0c5d3c777635e15671c",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "23102743e4d89842e0d065b128738ac271e28528fdf3998766ef31c3363c7f4d",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "38852c0ebbade92f0be538c7813c8e590b4a5a21a517cbc9419866a972bb9f87",
      "byte_length": 3049
    },
    ".input-c--decision-original.json": {
      "sha256": "fa125f4f15b3c10a2de2f56479934fdf651c7b7e39423a382284ddd772eeeb75",
      "byte_length": 140
    },
    ".input-c--gold-original.json": {
      "sha256": "d3582c705e4e7534b162e89714ba4033fb1e1669b8257d59364f01489df16dfb",
      "byte_length": 741
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "c9f053eb6791b3fec2566ca85db0c89cc1a7442946801b8657d128d9eaeab75c",
      "byte_length": 12349
    },
    ".input-c--review-original.json": {
      "sha256": "66555621684c395ba3fece2d948a3a9d6829ce6190acd68cdcdd515b0cee813a",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "f53de6c9f02e9cac03a4b06437cbdfd0beb7a1aba5133257c96313ff9559f432",
      "byte_length": 1054
    },
    ".input-c--verification.json": {
      "sha256": "87a069ca180c2bd23849eb5a8a39bd0c72e13dfee9e4b9f2bd016a6b31bd581f",
      "byte_length": 16829
    },
    ".input-c--verification.md": {
      "sha256": "77c2d0346b464f26629e040b6b50253822ad2d8ca7c95ee1b2d30267d54c8e92",
      "byte_length": 17263
    },
    ".owner.json": {
      "sha256": "2d2f4b465164f982c0b20581defe75d1afea2e52311ccb711a6bd714182aa480",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "7352f5b1a7a11bcd65c43147a1a8e0f777641223a958c468065bb5084efcd2a6",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "5f29b632f775927f4ba3a1748b0cbf9996d4b3ad31fc93020984b9c8ec18528e",
      "byte_length": 24185
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "fa56e7906fcca562f5863214158aff758d4712cf74c206e895c4fa79b9bd9b5a",
      "byte_length": 623
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "1f43fd9b6aa8c2048cf92ffefae9906f0e820abf857473bedbb47f162a2df2d1",
      "byte_length": 727
    }
  }
}
```
