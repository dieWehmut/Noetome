# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "2015a963-6a5e-4b0a-87e9-cf8c042aa321",
  "project_id": "8590b96e-7e49-48a1-9084-2dee247c5e26",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 3,
    "facts": 3,
    "source_occurrences": 3,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 9,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "ae5e62576d7fe92b4fe1e55a7168ff6244932862317f8e6cae4fa8a5a7a7d330",
    "byte_length": 61685
  },
  "plan_fingerprint": {
    "sha256": "4bcb21c48674d222aae5f6c40c6126966232d5017d7a9303cdfa1a8bbca64a10",
    "byte_length": 22900
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "ae5e62576d7fe92b4fe1e55a7168ff6244932862317f8e6cae4fa8a5a7a7d330",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "a30f33e8f3624cbd125faf914c634615d47409fc20a0e030739fd2e025e1b7cb",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "dc77de2405f7b3b4bb599edbfdcb16d92b9adb3e75d06804291ea23162555808",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "cbfab33be987821b700edc04e1d48b9bbec64c196747f816f7fc62ad3c6b8f7e",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "21381c8656d81e43506e89112286a2c68378d46c894666778ae9f5207c77e497",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "678b50177ae0caae194fdc0328b5be34fd19ed172c1cd20dba12d824890a59f8",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "33a0e7652d8197b7d352cae859b1d888e00abf4d9cc2cb1523952ec31222760b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "9d54578c96fa7082874be403beb4274cb909e4c10f885f4cb6d438ebec73c681",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "682b4aa0ff977c05f9b49281e5e634dbf2597bfcb93d9209b6fef60e23e4b4ad",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "b316d34605314eaccb03393cb978fd4097e512fef9fdc7deac1de0502323744c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "70bb78d4d81758aebf1627ddde61d52a1c66ce286910ff56ec361378c0dd1b07",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "09ec364f1888e89a4abe93c5c8299b29facc338dd2389ac80264698b819a7d40",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "4fa816a2c215e17c766a001d987aa51e24e990c4b11974f0244777907e06e789",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "34ad8a3b9fd62ac71c3c59b171b466437a78171bdf8afc6b69f58d6bc8bd8c67",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "4be72ee4ed20850aa9772131b9abaae0bfef5e184b0220d66dc3308c7a4a45cd",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "83525b6f5092c57f1a5a53a506f1394043e5de1c6540a942b86c1d7b8514ef15",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "a1fd1669bb862ab82644823c6eaca9a939eb0f7d8679620d4a4e29112816b9f2",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "4ebea5cfa7a5db7521ddba42d39531e3bcf9a47d31b17a478bb68610b0416ccb",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "4fbeb87a3e8325a8fe68f9045510f8e64f55200bfb4510825df475f256ecf1a9",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "bd2cd20360ec34a3f03fb3f8081324e7ede6a39fdcfa8de6714927c791c75b3d",
      "byte_length": 6402
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "a9e926c2f96b3658138c1aa6b37312d11b2ac37907676de67f2dadebdc0f2ad6",
      "byte_length": 692,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-089f74e9aae2822364658cac888aedbc3efe15d7cd2c2a7b2c4c845bc1d509ff",
            "occ-344e7dbdbc5c009ac2687f526252803fb1b463c50c0dfe645bd3f8709d260d34",
            "occ-65e9181abf3c052d30e1dec800624f5051594e96090efcabc6eeeeca78c7e374"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-089f74e9aae2822364658cac888aedbc3efe15d7cd2c2a7b2c4c845bc1d509ff",
            "occ-344e7dbdbc5c009ac2687f526252803fb1b463c50c0dfe645bd3f8709d260d34"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 77
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0",
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-089f74e9aae2822364658cac888aedbc3efe15d7cd2c2a7b2c4c845bc1d509ff",
            "occ-344e7dbdbc5c009ac2687f526252803fb1b463c50c0dfe645bd3f8709d260d34"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 155,
          "end_byte": 451
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-65e9181abf3c052d30e1dec800624f5051594e96090efcabc6eeeeca78c7e374"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 456,
          "end_byte": 464
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-65e9181abf3c052d30e1dec800624f5051594e96090efcabc6eeeeca78c7e374"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 542,
          "end_byte": 688
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 78,
          "end_byte": 152
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 465,
          "end_byte": 539
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-b3b30aead99f7625774d2df41a44a30697c93f2f650b87b9cb4ca711c47caab0"
          ],
          "occurrence_ids": [
            "occ-089f74e9aae2822364658cac888aedbc3efe15d7cd2c2a7b2c4c845bc1d509ff"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        },
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-344e7dbdbc5c009ac2687f526252803fb1b463c50c0dfe645bd3f8709d260d34"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 329,
          "end_byte": 627
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-d048fc83687fc3c1fd51f02423d1e47eb63d005fcbcb0b39222c82ea296c69ad"
          ],
          "occurrence_ids": [
            "occ-65e9181abf3c052d30e1dec800624f5051594e96090efcabc6eeeeca78c7e374"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "ae5e62576d7fe92b4fe1e55a7168ff6244932862317f8e6cae4fa8a5a7a7d330",
      "byte_length": 61685
    },
    ".coordination-owner.json": {
      "sha256": "a30f33e8f3624cbd125faf914c634615d47409fc20a0e030739fd2e025e1b7cb",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "dc77de2405f7b3b4bb599edbfdcb16d92b9adb3e75d06804291ea23162555808",
      "byte_length": 66543
    },
    ".coordination-report.md": {
      "sha256": "cbfab33be987821b700edc04e1d48b9bbec64c196747f816f7fc62ad3c6b8f7e",
      "byte_length": 67018
    },
    ".identity-original.json": {
      "sha256": "808c303a3b610f1a5a650ecffed9854510ca3b387b74d737ac53960277de0559",
      "byte_length": 2765
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "21381c8656d81e43506e89112286a2c68378d46c894666778ae9f5207c77e497",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "678b50177ae0caae194fdc0328b5be34fd19ed172c1cd20dba12d824890a59f8",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "33a0e7652d8197b7d352cae859b1d888e00abf4d9cc2cb1523952ec31222760b",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "9d54578c96fa7082874be403beb4274cb909e4c10f885f4cb6d438ebec73c681",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "682b4aa0ff977c05f9b49281e5e634dbf2597bfcb93d9209b6fef60e23e4b4ad",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "b316d34605314eaccb03393cb978fd4097e512fef9fdc7deac1de0502323744c",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "96e4cb61d36da8cc2c851518b669984e1b5f950be3b7c11bdc585b43ef06c31d",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "70bb78d4d81758aebf1627ddde61d52a1c66ce286910ff56ec361378c0dd1b07",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "fbcc44cdf034d08201ad07b7a1fdfb1f70d5a71867c03b9b7a1b1f8ebe8cbdc6",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "09ec364f1888e89a4abe93c5c8299b29facc338dd2389ac80264698b819a7d40",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "4fa816a2c215e17c766a001d987aa51e24e990c4b11974f0244777907e06e789",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "34ad8a3b9fd62ac71c3c59b171b466437a78171bdf8afc6b69f58d6bc8bd8c67",
      "byte_length": 17303
    },
    ".input-c--.owner.json": {
      "sha256": "8003a484ab2de467d5d49955c1cc1a2fb3d4bff29ff4ce63886541ec9b3dbfd0",
      "byte_length": 142
    },
    ".input-c--candidates-original.json": {
      "sha256": "4be72ee4ed20850aa9772131b9abaae0bfef5e184b0220d66dc3308c7a4a45cd",
      "byte_length": 3057
    },
    ".input-c--decision-original.json": {
      "sha256": "88fd8cfb60c8bf29562b0a69f33f2b28a515dcfdac21cb9beba1f1cbc798027b",
      "byte_length": 141
    },
    ".input-c--gold-original.json": {
      "sha256": "950ca9bb726d2837dc8b08231764b0823fa6c532f5d061320b00f4cd75176c0d",
      "byte_length": 747
    },
    ".input-c--knowledge-ir.json": {
      "sha256": "83525b6f5092c57f1a5a53a506f1394043e5de1c6540a942b86c1d7b8514ef15",
      "byte_length": 12394
    },
    ".input-c--review-original.json": {
      "sha256": "160cee038b54472eacdb632453e211601fc5932f7da2bf64100a66f02b813d8c",
      "byte_length": 510
    },
    ".input-c--source-snapshot.json": {
      "sha256": "a1fd1669bb862ab82644823c6eaca9a939eb0f7d8679620d4a4e29112816b9f2",
      "byte_length": 1056
    },
    ".input-c--verification.json": {
      "sha256": "4ebea5cfa7a5db7521ddba42d39531e3bcf9a47d31b17a478bb68610b0416ccb",
      "byte_length": 16869
    },
    ".input-c--verification.md": {
      "sha256": "4fbeb87a3e8325a8fe68f9045510f8e64f55200bfb4510825df475f256ecf1a9",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "9d9a277a6c9169941600e57efc6884cc2f6385fd6dfa35836909fb70084d3821",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "bd2cd20360ec34a3f03fb3f8081324e7ede6a39fdcfa8de6714927c791c75b3d",
      "byte_length": 6402
    },
    "plan.json": {
      "sha256": "4bcb21c48674d222aae5f6c40c6126966232d5017d7a9303cdfa1a8bbca64a10",
      "byte_length": 22900
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "3328224ada8b6c2648d93e16f814f772f9b888fce58a87fcf5700cc8f4b46880",
      "byte_length": 629
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "793425087aca0535fd0d26035f7f6f2c7e3a7287d2fb954263db5f65c10b496e",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "a9e926c2f96b3658138c1aa6b37312d11b2ac37907676de67f2dadebdc0f2ad6",
      "byte_length": 692
    }
  }
}
```
