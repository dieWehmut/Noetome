# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "08f20e26-95ea-48a3-ae75-66e93c68dfda",
  "project_id": "a9204ebc-73c9-44c9-96f7-4d268ef96d45",
  "coordination_schema_version": 3,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "3197999b4c4c621b76677e24b271a41a7fbf555bd3cc18f844986d0352ec8eb6",
    "byte_length": 41337
  },
  "plan_fingerprint": {
    "sha256": "5e337b337903ff58fc67747eca554fda7fbd3927e02d59a743b89c8b3989e65e",
    "byte_length": 17223
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "3197999b4c4c621b76677e24b271a41a7fbf555bd3cc18f844986d0352ec8eb6",
      "byte_length": 41337
    },
    ".coordination-owner.json": {
      "sha256": "ad3e81d17b6c1cde9fea4957c8b56a974e515a877354e2f6d899ac8863f63a95",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "183bc6bc2ff282f15720bd942914bf4c60799ce26697b7e38f6bd7fcc3d78012",
      "byte_length": 44808
    },
    ".coordination-report.md": {
      "sha256": "6e5606dcfcc86b4cd7f2c02dcb75f0d0e26c0f302efd7eb2180792ed5eb6248f",
      "byte_length": 45283
    },
    ".identity-original.json": {
      "sha256": "fa53fd3df5076b17dc0c175e973142eba502e9ff2c8169e50bd562fb57d1a068",
      "byte_length": 2034
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "cbcbdb43f889ddb164e0e1495c88db179fd1969fddfc64ced9724cfd2d9da0e1",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "94d7e9728a6c88db65ed9704aab5809d0a62e90c3c10697c1e45586d26ce103c",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "7d6ee6e3fb7d140b490e55d17cb7c2f1f44786cdf2d60d4963a7c776530dea38",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "99fae830f516d301dfa26b7ef6a957584171ff9783f29de3009730655932c1db",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "d21cafd10c731dfffc8ecba32c8b348a3772c043a00fa36e3c8da2585da2f897",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "5c95973f57244f9e2a21f0b81a15e127d8f9a3dee4c79c7c9ef288d1b3cdd5f1",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "82a2cd43b0f2d389fb9f5c6c127d73b47e22ace96388b56c3d5b3986d58bf016",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "738a68f2d3e41fa859331c4d7fd4e52abd486181204ba3ced274dc70b35f3a64",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b775d1f2e82aad6f10a4ba03b1e73bc026e4093d652ad52041d80c7ef7bcd7d6",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "38c6ade5bed34cd7792cccd8922b71efb7e4c451602d0c981b6839ac511c65ff",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "bd15c1db326fdaec5e79c3429825253ce2b4d0652cc6ee139473c9d555005cbb",
      "byte_length": 4330
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "3cdc2920ec68a87212a059f8e232b8c25747629c72d4ad1f407fb31a4ed2c6dc",
      "byte_length": 563,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0156e22a80da6d2208ad1c161f2daf7338d6304f66e9d3408d5c8b695537679a",
            "occ-80a4a574a1f7e683b8aceb11e55b9df3940c41a3e7f16e486f1073a31e2d9bd3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-80a4a574a1f7e683b8aceb11e55b9df3940c41a3e7f16e486f1073a31e2d9bd3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-80a4a574a1f7e683b8aceb11e55b9df3940c41a3e7f16e486f1073a31e2d9bd3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 322
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-0156e22a80da6d2208ad1c161f2daf7338d6304f66e9d3408d5c8b695537679a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 327,
          "end_byte": 335
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-0156e22a80da6d2208ad1c161f2daf7338d6304f66e9d3408d5c8b695537679a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 413,
          "end_byte": 559
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 336,
          "end_byte": 410
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "dcc2166c25fcd28e00955c5bb43d8b7ca09dc384c136bbb55666dfda9b7a8a95",
      "byte_length": 371,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1"
          ],
          "occurrence_ids": [
            "occ-80a4a574a1f7e683b8aceb11e55b9df3940c41a3e7f16e486f1073a31e2d9bd3"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 369
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a"
          ],
          "occurrence_ids": [
            "occ-0156e22a80da6d2208ad1c161f2daf7338d6304f66e9d3408d5c8b695537679a"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "3197999b4c4c621b76677e24b271a41a7fbf555bd3cc18f844986d0352ec8eb6",
      "byte_length": 41337
    },
    ".coordination-owner.json": {
      "sha256": "ad3e81d17b6c1cde9fea4957c8b56a974e515a877354e2f6d899ac8863f63a95",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "183bc6bc2ff282f15720bd942914bf4c60799ce26697b7e38f6bd7fcc3d78012",
      "byte_length": 44808
    },
    ".coordination-report.md": {
      "sha256": "6e5606dcfcc86b4cd7f2c02dcb75f0d0e26c0f302efd7eb2180792ed5eb6248f",
      "byte_length": 45283
    },
    ".identity-original.json": {
      "sha256": "fa53fd3df5076b17dc0c175e973142eba502e9ff2c8169e50bd562fb57d1a068",
      "byte_length": 2034
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "cbcbdb43f889ddb164e0e1495c88db179fd1969fddfc64ced9724cfd2d9da0e1",
      "byte_length": 3057
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "4e3115ae0a97c5c7954c4ebef62c088913bbf8dea61616e4654a30b2e05e313f",
      "byte_length": 747
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "94d7e9728a6c88db65ed9704aab5809d0a62e90c3c10697c1e45586d26ce103c",
      "byte_length": 12394
    },
    ".input-a--review-original.json": {
      "sha256": "5e8cfdf9239a5ef2b95dfa45ad8c06459c05ef761f01334fdb51cff7e7630eb0",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "7d6ee6e3fb7d140b490e55d17cb7c2f1f44786cdf2d60d4963a7c776530dea38",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "99fae830f516d301dfa26b7ef6a957584171ff9783f29de3009730655932c1db",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "d21cafd10c731dfffc8ecba32c8b348a3772c043a00fa36e3c8da2585da2f897",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "5c95973f57244f9e2a21f0b81a15e127d8f9a3dee4c79c7c9ef288d1b3cdd5f1",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "316046e0100da4562f3c3b0bad4030487c207965e7cc9920705f4eb09b1d5cf0",
      "byte_length": 747
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "82a2cd43b0f2d389fb9f5c6c127d73b47e22ace96388b56c3d5b3986d58bf016",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "44076756850540a48dbfce79239403477531437382c0698cf9300572de699c80",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "738a68f2d3e41fa859331c4d7fd4e52abd486181204ba3ced274dc70b35f3a64",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "b775d1f2e82aad6f10a4ba03b1e73bc026e4093d652ad52041d80c7ef7bcd7d6",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "38c6ade5bed34cd7792cccd8922b71efb7e4c451602d0c981b6839ac511c65ff",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "e9578439d6393dafe2d7e7b3162c6aa9ef7a8df2a834ac6a4bbf3e3fc9e60a26",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "bd15c1db326fdaec5e79c3429825253ce2b4d0652cc6ee139473c9d555005cbb",
      "byte_length": 4330
    },
    "plan.json": {
      "sha256": "5e337b337903ff58fc67747eca554fda7fbd3927e02d59a743b89c8b3989e65e",
      "byte_length": 17223
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "dcc2166c25fcd28e00955c5bb43d8b7ca09dc384c136bbb55666dfda9b7a8a95",
      "byte_length": 371
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "3cdc2920ec68a87212a059f8e232b8c25747629c72d4ad1f407fb31a4ed2c6dc",
      "byte_length": 563
    }
  }
}
```
