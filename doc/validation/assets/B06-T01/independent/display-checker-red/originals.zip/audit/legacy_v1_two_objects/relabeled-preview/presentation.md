# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "6283d865-a0c4-45be-be3a-1d6bfc66e17b",
  "project_id": "fddac1bc-4466-464c-83e7-18d58a6dc1c7",
  "coordination_schema_version": 1,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "92c6429817ae226e28b7dba6cacbcde3b1502f9b90dee3ee933b83d0cbb6590e",
    "byte_length": 38377
  },
  "plan_fingerprint": {
    "sha256": "962a7ab9ce3cb2f2bc3138bbd5b47eac1bc63f84acaa4a8eab9014f42757fe6c",
    "byte_length": 16870
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "92c6429817ae226e28b7dba6cacbcde3b1502f9b90dee3ee933b83d0cbb6590e",
      "byte_length": 38377
    },
    ".coordination-owner.json": {
      "sha256": "fbab830f4e0a9ffe88f86c8488b427d70f0264cce38def0b17cb79fa284b611d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c55464c10c6bc85749d20855851c6f87be28fa3c296815a12d370bc1e72d9fc5",
      "byte_length": 41848
    },
    ".coordination-report.md": {
      "sha256": "a630f94cfea1ed12c3fb15734a3555e6df07f87fd0877b7f417534f9a78e3ad7",
      "byte_length": 42163
    },
    ".identity-original.json": {
      "sha256": "cdd45387e0195e65000d8489ebe51a86a7212350cd27f179a2ca6f4679d35dba",
      "byte_length": 1454
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f4525d8d025d5e2d9d41d75c9cbc8c9f5ac4fca0ec0a2a0a119e25f363eb1dc6",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "ec198b691a1b684522d5766f72e2146828af34a5d10becbe52fcc111b76fd2bb",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "1f3c7f1c1af663d938f606d54ad0815b535ae1560f9ca70ec4bb94f09cad54f5",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8753d96f98166c5d4f19b2ca723f0dcba7236f734a0159bd506b684250d4fe81",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "da66a1ed0c3d233958a3cf359edea9b06dd378efe646c6626ca176bce19f8db9",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c35d1da63447a2d0102055b565ccf1c11449b26bbbbb743ca9af41a822ef961a",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9abb04dfc71b04942e90f58ffa5c487a952a22bc5a3568c7b7e247c6d78558f8",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "da50ca5470b588fc7517c29f883991057fc051757164fac248d367741f949314",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "76ce31e755ac960fb8af5a034d632f6476e1dd815c36cf545458d36bed0f6154",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "d2c8bee766a41b04cc59446c7d61ec0c917e0b56cfe2316839c54816f8893fd4",
      "byte_length": 17198
    },
    ".selection-original.json": {
      "sha256": "9fff1640d72f4d562d0b6657fe38e0d9215fa8f6097ec71a41db5a16181f1c40",
      "byte_length": 4335
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "2e384235aadf1ff97ce455dc5d9df0821175c60e1281721fa530753c90018fda",
      "byte_length": 615,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-976994511018e617d968c368eabefa059d004f02082a2e57fef6d29785cc1805",
            "occ-cd10a3800b4655fe936940be45feb0ab075d92bf5cd99585f3e9852d0284eba8"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-cd10a3800b4655fe936940be45feb0ab075d92bf5cd99585f3e9852d0284eba8"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-cd10a3800b4655fe936940be45feb0ab075d92bf5cd99585f3e9852d0284eba8"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 348
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-976994511018e617d968c368eabefa059d004f02082a2e57fef6d29785cc1805"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 353,
          "end_byte": 361
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-976994511018e617d968c368eabefa059d004f02082a2e57fef6d29785cc1805"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 439,
          "end_byte": 611
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 362,
          "end_byte": 436
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "c4b9062a7faf7a6e233fb195f9e07ef1b94f6111743d2d19bf56f3ed53c10cda",
      "byte_length": 397,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-c8059aa40c13c94a1a27b3806716eb5261430c5febdbd5d80d7f1906e7ff36c8"
          ],
          "occurrence_ids": [
            "occ-cd10a3800b4655fe936940be45feb0ab075d92bf5cd99585f3e9852d0284eba8"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 395
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-8bd49679d95aca6384d49727368b61b53e21a249a57b8de3ffee15acb83ee8d8"
          ],
          "occurrence_ids": [
            "occ-976994511018e617d968c368eabefa059d004f02082a2e57fef6d29785cc1805"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 353
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "92c6429817ae226e28b7dba6cacbcde3b1502f9b90dee3ee933b83d0cbb6590e",
      "byte_length": 38377
    },
    ".coordination-owner.json": {
      "sha256": "fbab830f4e0a9ffe88f86c8488b427d70f0264cce38def0b17cb79fa284b611d",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "c55464c10c6bc85749d20855851c6f87be28fa3c296815a12d370bc1e72d9fc5",
      "byte_length": 41848
    },
    ".coordination-report.md": {
      "sha256": "a630f94cfea1ed12c3fb15734a3555e6df07f87fd0877b7f417534f9a78e3ad7",
      "byte_length": 42163
    },
    ".identity-original.json": {
      "sha256": "cdd45387e0195e65000d8489ebe51a86a7212350cd27f179a2ca6f4679d35dba",
      "byte_length": 1454
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "f4525d8d025d5e2d9d41d75c9cbc8c9f5ac4fca0ec0a2a0a119e25f363eb1dc6",
      "byte_length": 3419
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "ec198b691a1b684522d5766f72e2146828af34a5d10becbe52fcc111b76fd2bb",
      "byte_length": 12627
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "1f3c7f1c1af663d938f606d54ad0815b535ae1560f9ca70ec4bb94f09cad54f5",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "8753d96f98166c5d4f19b2ca723f0dcba7236f734a0159bd506b684250d4fe81",
      "byte_length": 16764
    },
    ".input-a--verification.md": {
      "sha256": "da66a1ed0c3d233958a3cf359edea9b06dd378efe646c6626ca176bce19f8db9",
      "byte_length": 17198
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "c35d1da63447a2d0102055b565ccf1c11449b26bbbbb743ca9af41a822ef961a",
      "byte_length": 3004
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "9abb04dfc71b04942e90f58ffa5c487a952a22bc5a3568c7b7e247c6d78558f8",
      "byte_length": 12236
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "da50ca5470b588fc7517c29f883991057fc051757164fac248d367741f949314",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "76ce31e755ac960fb8af5a034d632f6476e1dd815c36cf545458d36bed0f6154",
      "byte_length": 16764
    },
    ".input-b--verification.md": {
      "sha256": "d2c8bee766a41b04cc59446c7d61ec0c917e0b56cfe2316839c54816f8893fd4",
      "byte_length": 17198
    },
    ".owner.json": {
      "sha256": "f5c933489222dd19418c99a7d915a6ea7023377b7c9457c019ad8b8a84b5711c",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "9fff1640d72f4d562d0b6657fe38e0d9215fa8f6097ec71a41db5a16181f1c40",
      "byte_length": 4335
    },
    "plan.json": {
      "sha256": "962a7ab9ce3cb2f2bc3138bbd5b47eac1bc63f84acaa4a8eab9014f42757fe6c",
      "byte_length": 16870
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "c4b9062a7faf7a6e233fb195f9e07ef1b94f6111743d2d19bf56f3ed53c10cda",
      "byte_length": 397
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "4a017b382ba336a61ec46a653547a993f578dcc2b88f0c75c72d0955acf0f905",
      "byte_length": 355
    },
    "知识比较.md": {
      "sha256": "2e384235aadf1ff97ce455dc5d9df0821175c60e1281721fa530753c90018fda",
      "byte_length": 615
    }
  }
}
```
