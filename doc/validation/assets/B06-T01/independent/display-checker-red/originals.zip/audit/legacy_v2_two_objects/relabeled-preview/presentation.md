# 有据主动表达预览

状态：passed；预览：rendered；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

```json
{
  "schema_version": 1,
  "producer": "knowledge_presentation",
  "report_kind": "knowledge_presentation",
  "scope": "active_presentation_v1",
  "request_id": "9feca27d-67e6-4fa2-8ff8-a418746fe64d",
  "project_id": "a18af4ad-d20b-4888-b9a1-a0c8e8301053",
  "coordination_schema_version": 2,
  "status": "passed",
  "preview_status": "rendered",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "checks": {
    "source_review": "passed",
    "coordination": "passed",
    "note_plan": "passed",
    "rendering": "passed",
    "saved_output": "passed"
  },
  "totals": {
    "input_bundles": 2,
    "facts": 2,
    "source_occurrences": 2,
    "objects": 2,
    "properties": 1,
    "table_cells": 4,
    "missing_cells": 0,
    "rendered_notes": 3,
    "content_mappings": 8,
    "links": 2
  },
  "issue_codes": [],
  "decision": {
    "rule_id": "PRESENT_SHARED_PROPERTY_TABLE",
    "reason": "多个明确对象共享已核对属性，以比较表并列完整事实；单位与条件保留，不作数值裁决。",
    "shared_property_ids": [
      "60000000-0000-4000-8000-000000000003"
    ]
  },
  "coordination_ir_fingerprint": {
    "sha256": "f84b3537a1de9c416e2218185d510e0068fe7b503815c401ec0d893bb541123d",
    "byte_length": 40517
  },
  "plan_fingerprint": {
    "sha256": "abaf554a8306ff9f5ea21f31ef7aa5fe9dda26d3cbca54d811fd1c16ad62e7fc",
    "byte_length": 17654
  },
  "inputs": {
    ".coordination-ir.json": {
      "sha256": "f84b3537a1de9c416e2218185d510e0068fe7b503815c401ec0d893bb541123d",
      "byte_length": 40517
    },
    ".coordination-owner.json": {
      "sha256": "1b40257d74ce9f8a5ed87055fa301ea58994a9d1e7bc4e937279b54c7211f4c3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "55bcbe5a92cb197505f07a1d87b439e5450203d8ad014be0d9e30396792382e2",
      "byte_length": 43988
    },
    ".coordination-report.md": {
      "sha256": "b59e8086ddae9fc462d0a2f84efb4fc22417125f76e840bb24ac117caf9daa48",
      "byte_length": 44394
    },
    ".identity-original.json": {
      "sha256": "f0b8eea833ba5011cc6cdfc7851c863828ee9153267a97072894ce0a38257209",
      "byte_length": 2033
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "d974ee58bb390d5861b9bfc8b83c918a5f3a25c35c7d9d6a07046b456442bc14",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "fc7379f8b2f42125ec0bc2b2f08c350fa4edaf07e62312338bbd0f3536367e93",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "a9d637657a06fb70e80a796097ed268c14440285361efce0ab4c90b50ca76096",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "3c1c3ab33491e6688f255ee016c304460de2aed8ca905aa7f283793af486b2bc",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "d85aafe666a83dc20366998d5c06e65a3ca4ac54f54079c4b727bf29121e3833",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "fd486feff99711f95aa09da1a1f9024d439e166d899aa6933b561c4d5c16de8a",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d0024430f46aacc6ab3ed0e70da693501039c6ce33278d5ca1974fd58d6ed29c",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "97cd6ecc90d7ebdfeb9fd3b58debd20fa99247cb138e32125d3676bac7b403ce",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "79b7d630ba56ad9d8394a14825d1df113caed9f0009acd2e38bc3971138326be",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "82129a30e98319f96f9103c6118d59753f4ad834ce2321f8ac6d2e58c59627d3",
      "byte_length": 17303
    },
    ".selection-original.json": {
      "sha256": "2082dade846ab5d99d3c07ddeef6cd7d3442c845ee949f42a481b10fdfc3436c",
      "byte_length": 4329
    }
  },
  "files": [
    {
      "relative_path": "知识比较.md",
      "note_id": "overview",
      "plan_revision": 1,
      "content_sha256": "c1eacd13b327675c2ad5d5340af6b854f184bfa4aa1bec8712db428ae4fc0813",
      "byte_length": 563,
      "content_mappings": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [],
          "concept_ids": [],
          "start_byte": 35,
          "end_byte": 41
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "table_header",
            "row_id": null,
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-3c9d4523756763b94bd3af1c24ddb179b422184df3e4ce233aae3d3a3a264294",
            "occ-6aed458cb9a020ea19b724d66dcf212761efb302c59dbc6b65944cc438f808d9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 44,
          "end_byte": 50
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-6aed458cb9a020ea19b724d66dcf212761efb302c59dbc6b65944cc438f808d9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001"
          ],
          "start_byte": 69,
          "end_byte": 98
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-6aed458cb9a020ea19b724d66dcf212761efb302c59dbc6b65944cc438f808d9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 176,
          "end_byte": 322
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "fact_ids": [],
          "occurrence_ids": [
            "occ-3c9d4523756763b94bd3af1c24ddb179b422184df3e4ce233aae3d3a3a264294"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002"
          ],
          "start_byte": 327,
          "end_byte": 335
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "facts",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "60000000-0000-4000-8000-000000000003"
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-3c9d4523756763b94bd3af1c24ddb179b422184df3e4ce233aae3d3a3a264294"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 413,
          "end_byte": 559
        }
      ],
      "links": [
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000001",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000001",
          "target_path": "对象-60000000-0000-4000-8000-000000000001.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 99,
          "end_byte": 173
        },
        {
          "scope": {
            "section_id": "overview",
            "node_id": "comparison",
            "kind": "label",
            "row_id": "60000000-0000-4000-8000-000000000002",
            "column_id": "object"
          },
          "target_concept_id": "60000000-0000-4000-8000-000000000002",
          "target_path": "对象-60000000-0000-4000-8000-000000000002.md",
          "target_heading": "知识明细",
          "display_text": "查看详情",
          "start_byte": 336,
          "end_byte": 410
        }
      ]
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000001.md",
      "note_id": "object-60000000-0000-4000-8000-000000000001",
      "plan_revision": 1,
      "content_sha256": "a3bf6c600a24263621766e312e354c3347575619485a53d788c03f1229f6fafc",
      "byte_length": 371,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-684ab00816caadf3595021604d289e3d3e1aeddef500e779f0b55a8628006c79"
          ],
          "occurrence_ids": [
            "occ-6aed458cb9a020ea19b724d66dcf212761efb302c59dbc6b65944cc438f808d9"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000001",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 50,
          "end_byte": 369
        }
      ],
      "links": []
    },
    {
      "relative_path": "对象-60000000-0000-4000-8000-000000000002.md",
      "note_id": "object-60000000-0000-4000-8000-000000000002",
      "plan_revision": 1,
      "content_sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329,
      "content_mappings": [
        {
          "scope": {
            "section_id": "details",
            "node_id": "detail-fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad",
            "kind": "paragraph",
            "row_id": null,
            "column_id": null
          },
          "fact_ids": [
            "fact-v2-000be9df24f2d6ebbc6051e9877e6b0b31027b84ef88b2a97043a9a2b21773ad"
          ],
          "occurrence_ids": [
            "occ-3c9d4523756763b94bd3af1c24ddb179b422184df3e4ce233aae3d3a3a264294"
          ],
          "concept_ids": [
            "60000000-0000-4000-8000-000000000002",
            "60000000-0000-4000-8000-000000000003"
          ],
          "start_byte": 29,
          "end_byte": 327
        }
      ],
      "links": []
    }
  ],
  "artifacts": {
    ".coordination-ir.json": {
      "sha256": "f84b3537a1de9c416e2218185d510e0068fe7b503815c401ec0d893bb541123d",
      "byte_length": 40517
    },
    ".coordination-owner.json": {
      "sha256": "1b40257d74ce9f8a5ed87055fa301ea58994a9d1e7bc4e937279b54c7211f4c3",
      "byte_length": 162
    },
    ".coordination-report.json": {
      "sha256": "55bcbe5a92cb197505f07a1d87b439e5450203d8ad014be0d9e30396792382e2",
      "byte_length": 43988
    },
    ".coordination-report.md": {
      "sha256": "b59e8086ddae9fc462d0a2f84efb4fc22417125f76e840bb24ac117caf9daa48",
      "byte_length": 44394
    },
    ".identity-original.json": {
      "sha256": "f0b8eea833ba5011cc6cdfc7851c863828ee9153267a97072894ce0a38257209",
      "byte_length": 2033
    },
    ".input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    ".input-a--candidates-original.json": {
      "sha256": "d974ee58bb390d5861b9bfc8b83c918a5f3a25c35c7d9d6a07046b456442bc14",
      "byte_length": 3472
    },
    ".input-a--decision-original.json": {
      "sha256": "bc2eedda4d3f0964d31ece5ceb9cd2404922eca04beacf7eb48d15a573ec0582",
      "byte_length": 141
    },
    ".input-a--gold-original.json": {
      "sha256": "b171c23da976f5b99593e7020727350a048c71d7014549dfaf796d5d9e50b06d",
      "byte_length": 746
    },
    ".input-a--knowledge-ir.json": {
      "sha256": "fc7379f8b2f42125ec0bc2b2f08c350fa4edaf07e62312338bbd0f3536367e93",
      "byte_length": 12785
    },
    ".input-a--review-original.json": {
      "sha256": "9518ed521593fe80a3389fb6282f6358f78650c7fe6f89eb442bb62f09cf807d",
      "byte_length": 510
    },
    ".input-a--source-snapshot.json": {
      "sha256": "a9d637657a06fb70e80a796097ed268c14440285361efce0ab4c90b50ca76096",
      "byte_length": 1056
    },
    ".input-a--verification.json": {
      "sha256": "3c1c3ab33491e6688f255ee016c304460de2aed8ca905aa7f283793af486b2bc",
      "byte_length": 16869
    },
    ".input-a--verification.md": {
      "sha256": "d85aafe666a83dc20366998d5c06e65a3ca4ac54f54079c4b727bf29121e3833",
      "byte_length": 17303
    },
    ".input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    ".input-b--candidates-original.json": {
      "sha256": "fd486feff99711f95aa09da1a1f9024d439e166d899aa6933b561c4d5c16de8a",
      "byte_length": 3057
    },
    ".input-b--decision-original.json": {
      "sha256": "5cff0a8cad3a2d60ea5905aff1f5f7184fd9c28f6f02215b4c159a8458e87239",
      "byte_length": 141
    },
    ".input-b--gold-original.json": {
      "sha256": "0c5c59236d0ca046d036232e506235e95a103f64284917fb06f763e5fd46d440",
      "byte_length": 746
    },
    ".input-b--knowledge-ir.json": {
      "sha256": "d0024430f46aacc6ab3ed0e70da693501039c6ce33278d5ca1974fd58d6ed29c",
      "byte_length": 12394
    },
    ".input-b--review-original.json": {
      "sha256": "77e5757f13cb487767a1971d5efa4cb472404f781f2d118840d9d30a945604a2",
      "byte_length": 510
    },
    ".input-b--source-snapshot.json": {
      "sha256": "97cd6ecc90d7ebdfeb9fd3b58debd20fa99247cb138e32125d3676bac7b403ce",
      "byte_length": 1056
    },
    ".input-b--verification.json": {
      "sha256": "79b7d630ba56ad9d8394a14825d1df113caed9f0009acd2e38bc3971138326be",
      "byte_length": 16869
    },
    ".input-b--verification.md": {
      "sha256": "82129a30e98319f96f9103c6118d59753f4ad834ce2321f8ac6d2e58c59627d3",
      "byte_length": 17303
    },
    ".owner.json": {
      "sha256": "61171435296bcb2061238bbfc2265725248145f14662bb688b1a8cc6ee869aff",
      "byte_length": 162
    },
    ".selection-original.json": {
      "sha256": "2082dade846ab5d99d3c07ddeef6cd7d3442c845ee949f42a481b10fdfc3436c",
      "byte_length": 4329
    },
    "plan.json": {
      "sha256": "abaf554a8306ff9f5ea21f31ef7aa5fe9dda26d3cbca54d811fd1c16ad62e7fc",
      "byte_length": 17654
    },
    "对象-60000000-0000-4000-8000-000000000001.md": {
      "sha256": "a3bf6c600a24263621766e312e354c3347575619485a53d788c03f1229f6fafc",
      "byte_length": 371
    },
    "对象-60000000-0000-4000-8000-000000000002.md": {
      "sha256": "747babaf98960ee8e125e10516016a6d2ce3691996c51bf3064f8cfc4e97b1b9",
      "byte_length": 329
    },
    "知识比较.md": {
      "sha256": "c1eacd13b327675c2ad5d5340af6b854f184bfa4aa1bec8712db428ae4fc0813",
      "byte_length": 563
    }
  }
}
```
