# 有界多来源知识协调

状态：passed；知识状态：pending；发布：false。

科学质量：not_run；研究：not_requested；网络与付费调用：0。

条件已列明：2；条件未知：0；条件不适用：0；时间已知：2；时间未知：0；条件并列关系：0；历史关系：0；真实冲突关系：0；证据不足关系：0；反证链接：0。完整来源、原对象、证据与分母与 coordination.json 一致。

```json
{
  "schema_version": 3,
  "report_kind": "knowledge_coordination",
  "producer": "knowledge_coordination",
  "request_id": "b0d39848-a28d-402e-a9e5-46f2cfb46847",
  "scope": "explicit_identity_conflict_review_v3",
  "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
  "status": "passed",
  "knowledge_status": "pending",
  "published": false,
  "scientific_quality": "not_run",
  "research_status": "not_requested",
  "network_calls": 0,
  "paid_calls": 0,
  "canonical_concepts": [
    {
      "canonical_id": "60000000-0000-4000-8000-000000000001",
      "display_name": "样例\nA\t（两行标签）"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000002",
      "display_name": "样例 B"
    },
    {
      "canonical_id": "60000000-0000-4000-8000-000000000003",
      "display_name": "速度"
    }
  ],
  "inputs": [
    {
      "input_id": "a",
      "binding": {
        "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
        "import_id": "279a877e-c23c-469a-805f-c075f5f67b9c",
        "source_id": "0bb50cee-86ff-429c-be62-e1d3b1937843",
        "version_id": "a8a71e57-e1eb-4ac7-bb2b-6c0ab662e914",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-a",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "a-speed"
            ],
            "decision": {
              "atom_ids": [
                "a-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "279a877e-c23c-469a-805f-c075f5f67b9c",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
              "source_id": "0bb50cee-86ff-429c-be62-e1d3b1937843",
              "version_id": "a8a71e57-e1eb-4ac7-bb2b-6c0ab662e914"
            },
            "request_id": "synthetic-coordination-a"
          },
          "actual": {
            "binding": {
              "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "import_id": "279a877e-c23c-469a-805f-c075f5f67b9c",
              "manifest_sha256": null,
              "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
              "parse_id": null,
              "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
              "source_id": "0bb50cee-86ff-429c-be62-e1d3b1937843",
              "version_id": "a8a71e57-e1eb-4ac7-bb2b-6c0ab662e914"
            },
            "request_id": "synthetic-coordination-a"
          }
        },
        {
          "category": "duplicate",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "a-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "a-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "a-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 A",
              "速度"
            ],
            "compound": "样例 A 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 A",
                "concept_id": "a-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "a-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "actual": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "10",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "unit": "m/s",
            "value": "10",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 A",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例A"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 A",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "a-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 A"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "c792d5edf274e25eb7aed70d558fd09a8791c8550c8bd613b181ba6eb94122bf",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "0adf6d03903b530310f65e5a7dd32331c891ecceae3905bb9d3b1af8c5153715",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "d8ef7d8f0c5a291e2b3364e5686596bc8af795cbbe621f3ac580334435392db3",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "f09147ee37a7772941ef254ae5b4659dff541910f0f2be2df5cbd4c23c2e4ed1",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "bf9d86e8ecde5903365f355b5fd420bce03a298c13abc4b853dac371ead7f12a",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "c4cb64e2455c63fc2f915ac14cdd9fca2a996fdd0beaca9bb9dc6d9b3c52aa49",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "75380ec065f3c8aab35872ab71e16ce8068c2bcd52963e79c33bc3ac7a540848",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-a--.owner.json",
        "candidates-original.json": "input-a--candidates-original.json",
        "decision-original.json": "input-a--decision-original.json",
        "gold-original.json": "input-a--gold-original.json",
        "knowledge-ir.json": "input-a--knowledge-ir.json",
        "review-original.json": "input-a--review-original.json",
        "source-snapshot.json": "input-a--source-snapshot.json",
        "verification.json": "input-a--verification.json",
        "verification.md": "input-a--verification.md"
      }
    },
    {
      "input_id": "b",
      "binding": {
        "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
        "import_id": "4997bf4b-c86f-42a0-accb-d21884f80c6e",
        "source_id": "8a725271-8f13-4757-a02c-1e297e5997cb",
        "version_id": "9f232fb1-8465-4457-9c51-94c04e0dbd83",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "request_id": "synthetic-coordination-b",
      "source_review_status": "passed",
      "source_review_checks": [
        {
          "category": "schema",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "strict_schema_1",
          "actual": null
        },
        {
          "category": "source",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "parsed",
          "actual": "parsed"
        },
        {
          "category": "exclusion",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "included",
          "actual": "included"
        },
        {
          "category": "coverage",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "atom_count": 1,
            "unit_id": "unit-0"
          },
          "actual": {
            "candidate_ids": [
              "b-speed"
            ],
            "decision": {
              "atom_ids": [
                "b-speed"
              ],
              "disposition": "included",
              "exclusion_reason": null,
              "schema_version": 1,
              "unit_id": "unit-0"
            }
          }
        },
        {
          "category": "binding",
          "object_id": "expected-0",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "4997bf4b-c86f-42a0-accb-d21884f80c6e",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
              "source_id": "8a725271-8f13-4757-a02c-1e297e5997cb",
              "version_id": "9f232fb1-8465-4457-9c51-94c04e0dbd83"
            },
            "request_id": "synthetic-coordination-b"
          },
          "actual": {
            "binding": {
              "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "import_id": "4997bf4b-c86f-42a0-accb-d21884f80c6e",
              "manifest_sha256": null,
              "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
              "parse_id": null,
              "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
              "source_id": "8a725271-8f13-4757-a02c-1e297e5997cb",
              "version_id": "9f232fb1-8465-4457-9c51-94c04e0dbd83"
            },
            "request_id": "synthetic-coordination-b"
          }
        },
        {
          "category": "duplicate",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "unique_semantic_atom",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "evidence_identity",
          "object_id": "b-support",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 165,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 166,
            "start_byte": 0,
            "unit_id": "unit-0"
          },
          "actual": {
            "evidence_id": "b-support",
            "excerpt_end_byte": 165,
            "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
            "excerpt_start_byte": 0,
            "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "unit_id": "unit-0"
          }
        },
        {
          "category": "evidence",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "end_byte": 165,
            "quote": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
            "start_byte": 53
          },
          "actual": [
            {
              "evidence_id": "b-support",
              "excerpt_end_byte": 165,
              "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
              "excerpt_start_byte": 0,
              "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
              "unit_id": "unit-0"
            }
          ]
        },
        {
          "category": "concept",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "components": [
              "样例 B",
              "速度"
            ],
            "compound": "样例 B 速度"
          },
          "actual": {
            "additional_source_concepts": 0,
            "linked": [
              {
                "aliases": [],
                "canonical_name": "样例 B",
                "concept_id": "b-subject",
                "needs_full_explanation": true,
                "revision": 1
              },
              {
                "aliases": [],
                "canonical_name": "速度",
                "concept_id": "b-property",
                "needs_full_explanation": true,
                "revision": 1
              }
            ]
          }
        },
        {
          "category": "content",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "actual": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        },
        {
          "category": "fact",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "value": "12",
            "value_status": "known"
          },
          "actual": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "unit": "m/s",
            "value": "12",
            "value_status": "known"
          }
        },
        {
          "category": "unit",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "m/s",
          "actual": {
            "measurement": "m/s",
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "温度 20 ℃",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "仅适用成年样例 B",
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "condition_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "allowed_contexts": [],
            "required": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          },
          "actual": {
            "body": [
              "温度20℃",
              "仅适用成年样例B"
            ],
            "measurement": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ]
          }
        },
        {
          "category": "exception",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": "结冰时不适用",
          "actual": {
            "body": [
              "结冰时不适用"
            ],
            "qualifiers": [
              "m/s",
              "温度 20 ℃",
              "仅适用成年样例 B",
              "结冰时不适用"
            ]
          }
        },
        {
          "category": "exception_set",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": [
            "结冰时不适用"
          ],
          "actual": [
            "结冰时不适用"
          ]
        },
        {
          "category": "qualifiers",
          "object_id": "b-speed",
          "unit_id": "unit-0",
          "start_byte": 0,
          "end_byte": 166,
          "status": "passed",
          "code": null,
          "expected": {
            "conditions": [
              "温度 20 ℃",
              "仅适用成年样例 B"
            ],
            "contexts": [],
            "exceptions": [
              "结冰时不适用"
            ],
            "unit": "m/s"
          },
          "actual": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ]
        }
      ],
      "source_bundle_fingerprints": {
        ".owner.json": {
          "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
          "byte_length": 142
        },
        "candidates-original.json": {
          "sha256": "e3e43b74ccaeec27a0a7dc7e0abab68525940783be02f4354a50c0f51498eef5",
          "byte_length": 3056
        },
        "decision-original.json": {
          "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
          "byte_length": 140
        },
        "gold-original.json": {
          "sha256": "c85210429e4bc8f8df2f06b9e582f653bf789081f34088d06c76ef2dd4780f9b",
          "byte_length": 746
        },
        "knowledge-ir.json": {
          "sha256": "bbeb3775ce7e8d58e8af2aad444b98dcf0dd5147d96694dc2581d9305d7cab7c",
          "byte_length": 12394
        },
        "review-original.json": {
          "sha256": "4d7453b8c1e0767d3677c624857fb131d8ea4c4caabe8eddf2fecc397494b09f",
          "byte_length": 509
        },
        "source-snapshot.json": {
          "sha256": "1820e53f3f0b8795853b15a0c3c6aca2f6fe6846479c024831ac93e170f5aa2a",
          "byte_length": 1056
        },
        "verification.json": {
          "sha256": "b388c05446cc70dbeec703da3477211f99c97b2dabf65ed7557d9d3e03e53dc8",
          "byte_length": 16869
        },
        "verification.md": {
          "sha256": "e00e4aa1cf6d1ea7f0b46bff276ac481251557e488bbc04ff917a7dc8c9b0a28",
          "byte_length": 17303
        }
      },
      "copied_artifacts": {
        ".owner.json": "input-b--.owner.json",
        "candidates-original.json": "input-b--candidates-original.json",
        "decision-original.json": "input-b--decision-original.json",
        "gold-original.json": "input-b--gold-original.json",
        "knowledge-ir.json": "input-b--knowledge-ir.json",
        "review-original.json": "input-b--review-original.json",
        "source-snapshot.json": "input-b--source-snapshot.json",
        "verification.json": "input-b--verification.json",
        "verification.md": "input-b--verification.md"
      }
    }
  ],
  "occurrences": [
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "b-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
        "sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137"
      },
      "occurrence_id": "occ-57e02aec2e2d3745e0282a01cfc5918263ae9cbc4c77b478914b5c28823a94be",
      "input_id": "b",
      "binding": {
        "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
        "import_id": "4997bf4b-c86f-42a0-accb-d21884f80c6e",
        "source_id": "8a725271-8f13-4757-a02c-1e297e5997cb",
        "version_id": "9f232fb1-8465-4457-9c51-94c04e0dbd83",
        "content_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "normalized_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "a4b30478-bdeb-4c37-9dda-a5796721fd8a",
          "ordinal": 0,
          "resource_sha256": "fe75e09ae51ff92f525b2b8f28552f9af2260936b74e2729e2bd81bdac74ff66"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "b-subject",
          "revision": 1,
          "canonical_name": "样例 B",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "b-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "b-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "b-subject",
            "b-property"
          ],
          "content": "样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 B",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "b-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "12",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 B"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "b-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "5895c9e26c4e2c5a3bb68ad12a1e18f5e4bd6d919e39cee90888ba639feed137",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 B 的速度为 12 m/s，条件为温度 20 ℃且仅适用成年样例 B；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000002",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "12",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 B"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "context": {
        "applicability_status": "known",
        "time": {
          "status": "known",
          "precision": "year",
          "value": "2020"
        },
        "evidence_ids": [
          "a-support"
        ],
        "unit_id": "unit-0",
        "start_byte": 0,
        "end_byte": 165,
        "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
        "sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a"
      },
      "occurrence_id": "occ-9bb7efdd7599e3f285cc2840c790e9355c2aaa47ac24af573bc40ec556bcc908",
      "input_id": "a",
      "binding": {
        "project_id": "abc12038-b4c4-46ed-9552-30360b6867ee",
        "import_id": "279a877e-c23c-469a-805f-c075f5f67b9c",
        "source_id": "0bb50cee-86ff-429c-be62-e1d3b1937843",
        "version_id": "a8a71e57-e1eb-4ac7-bb2b-6c0ab662e914",
        "content_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "normalized_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f",
        "parse_id": null,
        "manifest_sha256": null
      },
      "unit": {
        "unit_id": "unit-0",
        "locator": {
          "kind": "text",
          "span_id": "cdb1cbbf-d344-4810-b2d9-8d648198e5a6",
          "ordinal": 0,
          "resource_sha256": "7fac919c869a65847db4c90ced8bcb17acbc19d472460103c36982dbd901286f"
        },
        "source_status": "parsed",
        "start_byte": 0,
        "end_byte": 166,
        "text": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。\n"
      },
      "original_concepts": [
        {
          "concept_id": "a-subject",
          "revision": 1,
          "canonical_name": "样例 A",
          "aliases": [],
          "needs_full_explanation": true
        },
        {
          "concept_id": "a-property",
          "revision": 1,
          "canonical_name": "速度",
          "aliases": [],
          "needs_full_explanation": true
        }
      ],
      "original_atom": {
        "atom": {
          "atom_id": "a-speed",
          "revision": 1,
          "kind": "comparison_value",
          "concept_ids": [
            "a-subject",
            "a-property"
          ],
          "content": "样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。",
          "qualifiers": [
            "m/s",
            "温度 20 ℃",
            "仅适用成年样例 A",
            "结冰时不适用"
          ],
          "evidence_links": [
            {
              "evidence_id": "a-support",
              "relation": "supports"
            }
          ],
          "required": false,
          "verification": "unverified",
          "value_status": "known"
        },
        "measurement": {
          "value_status": "known",
          "value": "10",
          "unit": "m/s",
          "conditions": [
            "温度 20 ℃",
            "仅适用成年样例 A"
          ]
        }
      },
      "original_evidence": [
        {
          "evidence_id": "a-support",
          "unit_id": "unit-0",
          "excerpt_start_byte": 0,
          "excerpt_end_byte": 165,
          "excerpt_sha256": "d04e43d2d0b367ec0f952fd509ad4359c0b1bd2587e92ab24e5d3b343248691a",
          "quote": "适用条件：已列明；观点时间：2020年。\n样例 A 的速度为 10 m/s，条件为温度 20 ℃且仅适用成年样例 A；例外为结冰时不适用。"
        }
      ],
      "canonical_concept_ids": [
        "60000000-0000-4000-8000-000000000001",
        "60000000-0000-4000-8000-000000000003"
      ],
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value": "10",
      "unit_value": "m/s",
      "conditions": [
        "温度 20 ℃",
        "仅适用成年样例 A"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "facts": [
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-bc42572483fd480f09b096be42b029674241b962c579720d3c2c1365699ce03a",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "12",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例B",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-57e02aec2e2d3745e0282a01cfc5918263ae9cbc4c77b478914b5c28823a94be"
      ],
      "status": "passed",
      "issue_codes": []
    },
    {
      "applicability_status": "known",
      "time": {
        "status": "known",
        "precision": "year",
        "value": "2020"
      },
      "fact_id": "fact-v3-db1e8d0199a1250dbc1e1c9332d65d258d7a6d826cce353586665fc554ef71c1",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "value_status": "known",
      "value": "10",
      "unit": "m/s",
      "conditions": [
        "仅适用成年样例A",
        "温度20℃"
      ],
      "exceptions": [
        "结冰时不适用"
      ],
      "occurrence_ids": [
        "occ-9bb7efdd7599e3f285cc2840c790e9355c2aaa47ac24af573bc40ec556bcc908"
      ],
      "status": "passed",
      "issue_codes": []
    }
  ],
  "relations": [
    {
      "earlier_occurrence_id": null,
      "later_occurrence_id": null,
      "left_occurrence_id": "occ-57e02aec2e2d3745e0282a01cfc5918263ae9cbc4c77b478914b5c28823a94be",
      "right_occurrence_id": "occ-9bb7efdd7599e3f285cc2840c790e9355c2aaa47ac24af573bc40ec556bcc908",
      "relation": "separate_object",
      "issue_code": null
    }
  ],
  "processing_records": [
    {
      "occurrence_id": "occ-57e02aec2e2d3745e0282a01cfc5918263ae9cbc4c77b478914b5c28823a94be",
      "object_id": "60000000-0000-4000-8000-000000000002",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    },
    {
      "occurrence_id": "occ-9bb7efdd7599e3f285cc2840c790e9355c2aaa47ac24af573bc40ec556bcc908",
      "object_id": "60000000-0000-4000-8000-000000000001",
      "property_id": "60000000-0000-4000-8000-000000000003",
      "status": "passed",
      "issue_codes": [],
      "action": "retained",
      "reason": "retained with complete source provenance"
    }
  ],
  "totals": {
    "true_conflicts": 0,
    "insufficient_evidence_relations": 0,
    "conflicting_occurrences": 0,
    "insufficient_evidence_occurrences": 0,
    "counter_evidence_links": 0,
    "condition_variants": 0,
    "historical_relations": 0,
    "known_condition_occurrences": 2,
    "unknown_condition_occurrences": 0,
    "not_applicable_condition_occurrences": 0,
    "dated_occurrences": 2,
    "undated_occurrences": 0,
    "context_evidence_links": 2,
    "input_bundles": 2,
    "validated_input_bundles": 2,
    "input_atoms": 2,
    "retained_fact_groups": 2,
    "canonical_facts": 2,
    "source_occurrences": 2,
    "evidence_links": 2,
    "independent_sources": 2,
    "duplicate_occurrences": 0,
    "passed": 2,
    "failed": 0,
    "needs_review": 0,
    "unprocessed": 0
  },
  "artifacts": {
    ".owner.json": {
      "sha256": "9af76af7959cc54196b051188a434f81d778aa1d58807f24a7cdcefdeba7913d",
      "byte_length": 162
    },
    "coordination-ir.json": {
      "sha256": "b56612de691e959716cb2ae2be31b9f8a4d51eba695de3bbca95d4be0eb95861",
      "byte_length": 41341
    },
    "coordination-original.json": {
      "sha256": "ef51c06bc59a1ea44ee44023d88ec0f7a68e5467d72850333d5c4d9662c00cd4",
      "byte_length": 4329
    },
    "identity-original.json": {
      "sha256": "939f5d45ac64dd5537c12d22d68184ffe9f5f4a6b528e4f98bae88bf3b7153b4",
      "byte_length": 2037
    },
    "input-a--.owner.json": {
      "sha256": "10839dfc05b0d0b9c6717fb73b14a15fad767739c3fc5e994aaf6d7d8e21891f",
      "byte_length": 142
    },
    "input-a--candidates-original.json": {
      "sha256": "c792d5edf274e25eb7aed70d558fd09a8791c8550c8bd613b181ba6eb94122bf",
      "byte_length": 3056
    },
    "input-a--decision-original.json": {
      "sha256": "c4978e5e0280871e4b354ee935f52c1a551174d3b3814d65d4030b093ab798b8",
      "byte_length": 140
    },
    "input-a--gold-original.json": {
      "sha256": "0adf6d03903b530310f65e5a7dd32331c891ecceae3905bb9d3b1af8c5153715",
      "byte_length": 746
    },
    "input-a--knowledge-ir.json": {
      "sha256": "d8ef7d8f0c5a291e2b3364e5686596bc8af795cbbe621f3ac580334435392db3",
      "byte_length": 12394
    },
    "input-a--review-original.json": {
      "sha256": "f09147ee37a7772941ef254ae5b4659dff541910f0f2be2df5cbd4c23c2e4ed1",
      "byte_length": 509
    },
    "input-a--source-snapshot.json": {
      "sha256": "bf9d86e8ecde5903365f355b5fd420bce03a298c13abc4b853dac371ead7f12a",
      "byte_length": 1056
    },
    "input-a--verification.json": {
      "sha256": "c4cb64e2455c63fc2f915ac14cdd9fca2a996fdd0beaca9bb9dc6d9b3c52aa49",
      "byte_length": 16869
    },
    "input-a--verification.md": {
      "sha256": "75380ec065f3c8aab35872ab71e16ce8068c2bcd52963e79c33bc3ac7a540848",
      "byte_length": 17303
    },
    "input-b--.owner.json": {
      "sha256": "88883829cc26da9d4966260b2ee12c11b389ff6eef4a6f2022c46eb65db1fd48",
      "byte_length": 142
    },
    "input-b--candidates-original.json": {
      "sha256": "e3e43b74ccaeec27a0a7dc7e0abab68525940783be02f4354a50c0f51498eef5",
      "byte_length": 3056
    },
    "input-b--decision-original.json": {
      "sha256": "bdd97a62d821b2f3e48c8556f57a3fed1ba496efbb4f0fa30d23080212b00b5d",
      "byte_length": 140
    },
    "input-b--gold-original.json": {
      "sha256": "c85210429e4bc8f8df2f06b9e582f653bf789081f34088d06c76ef2dd4780f9b",
      "byte_length": 746
    },
    "input-b--knowledge-ir.json": {
      "sha256": "bbeb3775ce7e8d58e8af2aad444b98dcf0dd5147d96694dc2581d9305d7cab7c",
      "byte_length": 12394
    },
    "input-b--review-original.json": {
      "sha256": "4d7453b8c1e0767d3677c624857fb131d8ea4c4caabe8eddf2fecc397494b09f",
      "byte_length": 509
    },
    "input-b--source-snapshot.json": {
      "sha256": "1820e53f3f0b8795853b15a0c3c6aca2f6fe6846479c024831ac93e170f5aa2a",
      "byte_length": 1056
    },
    "input-b--verification.json": {
      "sha256": "b388c05446cc70dbeec703da3477211f99c97b2dabf65ed7557d9d3e03e53dc8",
      "byte_length": 16869
    },
    "input-b--verification.md": {
      "sha256": "e00e4aa1cf6d1ea7f0b46bff276ac481251557e488bbc04ff917a7dc8c9b0a28",
      "byte_length": 17303
    }
  }
}
```
