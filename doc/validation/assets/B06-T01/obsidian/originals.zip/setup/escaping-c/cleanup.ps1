$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 25164 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 58736 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=25164;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=58736;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
