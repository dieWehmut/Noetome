$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 36724 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 53298 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=36724;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=53298;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
