$ErrorActionPreference='Stop'
$owned=Get-CimInstance Win32_Process -Filter "ProcessId=10772"
if($null -ne $owned){if($owned.Name -ne 'Obsidian.exe' -or -not $owned.CommandLine.Contains('b06-obsidian-escaping-20261105\profile')){throw 'own profile mismatch'}; Stop-Process -Id 10772 -Force}
Get-CimInstance Win32_Process -Filter "Name='Obsidian.exe'" | Where-Object {$_.CommandLine.Contains('b06-obsidian-escaping-20261105\profile')} | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress
