$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 69032 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 53550 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=69032;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=53550;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
