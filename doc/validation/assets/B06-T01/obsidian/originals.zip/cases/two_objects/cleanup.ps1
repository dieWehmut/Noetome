$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 51428 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 58824 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=51428;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=58824;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
