$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 14756 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 56191 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=14756;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=56191;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
