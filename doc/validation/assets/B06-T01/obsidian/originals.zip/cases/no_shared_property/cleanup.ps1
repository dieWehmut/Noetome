$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 23452 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 63809 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=23452;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=63809;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
