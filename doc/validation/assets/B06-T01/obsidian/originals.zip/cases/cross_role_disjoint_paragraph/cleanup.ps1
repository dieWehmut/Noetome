$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 61668 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 55478 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=61668;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=55478;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
