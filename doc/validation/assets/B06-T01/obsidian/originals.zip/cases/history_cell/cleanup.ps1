$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 16364 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 50480 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=16364;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=50480;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
