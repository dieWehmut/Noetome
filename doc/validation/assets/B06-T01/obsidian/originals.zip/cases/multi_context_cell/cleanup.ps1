$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 28780 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 63675 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=28780;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=63675;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
