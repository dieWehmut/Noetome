$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 2764 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 57459 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=2764;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=57459;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
