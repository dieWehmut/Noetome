$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 19356 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 54709 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=19356;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=54709;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
