$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 21896 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 56643 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=21896;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=56643;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
