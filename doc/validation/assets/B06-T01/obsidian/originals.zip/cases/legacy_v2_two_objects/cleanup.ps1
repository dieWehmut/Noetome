$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 71644 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 61055 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=71644;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=61055;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
