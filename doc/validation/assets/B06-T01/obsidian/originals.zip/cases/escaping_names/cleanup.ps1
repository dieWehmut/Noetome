$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 69092 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 50864 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=69092;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=50864;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
