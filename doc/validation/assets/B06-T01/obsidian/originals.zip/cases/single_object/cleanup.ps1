$ErrorActionPreference='Stop'
$ownedProcess=Get-Process -Id 51672 -ErrorAction SilentlyContinue
$ownedListener=Get-NetTCPConnection -LocalPort 49505 -State Listen -ErrorAction SilentlyContinue
@{ownedPid=51672;ownedPidAbsent=($null -eq $ownedProcess);ownedPort=49505;ownedListenerAbsent=($null -eq $ownedListener);checkedUtc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
