

// Independent re-review: both new Version and parse staged, both cache roots absent.
#[test]
fn independent_paired_writer_stage_absence_change_is_rejected() {
    let (sandbox, _connection, store) = large_host();
    let sources = sandbox.0.join(".noetome-sources");
    let parses = sandbox.0.join(".noetome-pdf-parses");
    let writer = sandbox.0.join(".noetome-writing");
    fs::create_dir(&writer).unwrap();
    let version_stage = writer.join("version");
    let parse_stage = writer.join("parse");
    fs::rename(sources.join(VERSION), &version_stage).unwrap();
    fs::rename(parses.join(PARSE), &parse_stage).unwrap();
    for cache in [&sources, &parses] {
        fs::remove_file(cache.join(".owner.json")).unwrap();
        fs::remove_dir(cache).unwrap();
    }
    store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).unwrap();
    let target = sources.join("paired-stage-human-review.txt");
    let worker = mutate_when_raw_is_guarded(version_stage.join("raw.pdf"), target.clone(), 1);
    let result = store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage)));
    assert_eq!(worker.join().unwrap(), Mutation::Applied);
    assert_eq!(fs::read(&target).unwrap(), b"unknown cache sentinel");
    eprintln!("Independent paired stages result={result:?}");
    assert!(result.is_err(), "source-root creation escaped with both new artifacts staged");
    assert!(store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).is_err());
}
