

// Independent review probes appended only to the temporary test copy.
// The synchronization observes an actual Windows raw-file sharing violation;
// there is no model/control hook and no arbitrary mutation of production code.
#[cfg(windows)]
fn audit_when_raw_guard_is_live(raw: PathBuf, target: PathBuf, mode: u8) -> std::thread::JoinHandle<()> {
    use std::os::windows::fs::OpenOptionsExt;
    std::thread::spawn(move || {
        std::thread::sleep(std::time::Duration::from_millis(5));
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
        loop {
            match std::fs::OpenOptions::new().write(true).share_mode(7).open(&raw) {
                Ok(file) => drop(file),
                Err(error) if error.raw_os_error() == Some(32) => {
                    match mode {
                        0 => std::fs::write(&target, b"independent unknown source-root sentinel").unwrap(),
                        1 => {
                            std::fs::create_dir(target.parent().unwrap()).unwrap();
                            std::fs::write(&target, b"independent unknown source-root sentinel").unwrap();
                        },
                        2 => std::fs::write(&target, b"{\"schema_version\":1,\"project_id\":\"foreign-project\"}").unwrap(),
                        3 => {
                            let bytes = std::fs::read(&target).unwrap();
                            let replacement = target.with_file_name(".owner.replacement");
                            std::fs::write(&replacement, bytes).unwrap();
                            std::fs::remove_file(&target).unwrap();
                            std::fs::rename(&replacement, &target).unwrap();
                        },
                        _ => unreachable!(),
                    }
                    eprintln!("Observed raw sharing violation, then injected source-root mode {mode}");
                    return;
                },
                Err(error) => panic!("audit setup unexpected raw-file error: {error}"),
            }
            assert!(std::time::Instant::now() < deadline, "audit setup did not observe a live raw guard");
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
    })
}
#[cfg(windows)]
fn audit_large_host() -> (Sandbox, Connection, crate::source_model::Store) {
    let sandbox = Sandbox::new();
    host_snapshots(&sandbox.0);
    let connection = host_database();
    let raw = vec![b'x'; 16 * 1024 * 1024];
    let hash = crate::text::sha256(&raw);
    let fingerprint = Fingerprint { sha256: hash.clone(), byte_length: raw.len() as u64 };
    let key = cache_key(&fingerprint, &ParserIdentity::pinned(), &"a".repeat(64), DEFAULT_IMPORT_OPTIONS).unwrap();
    connection.execute("UPDATE source_versions SET content_sha256=?1,byte_length=?2", params![hash, raw.len() as i64]).unwrap();
    connection.execute("UPDATE pdf_parses SET cache_key=?1", params![key]).unwrap();
    std::fs::write(sandbox.0.join(".noetome-sources").join(VERSION).join("raw.pdf"), raw).unwrap();
    let store = crate::source_model::Store::load(&connection, PROJECT).unwrap();
    store.validate_snapshots(&sandbox.0, PROJECT, None).unwrap();
    (sandbox, connection, store)
}
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_unknown_inventory() {
    let (sandbox, _connection, store) = audit_large_host();
    let cache = sandbox.0.join(".noetome-sources");
    let raw = cache.join(VERSION).join("raw.pdf");
    let target = cache.join("human-review.txt");
    let worker = audit_when_raw_guard_is_live(raw, target.clone(), 0);
    let result = store.validate_snapshots(&sandbox.0, PROJECT, None);
    worker.join().unwrap();
    assert_eq!(std::fs::read(&target).unwrap(), b"independent unknown source-root sentinel");
    let after = store.validate_snapshots(&sandbox.0, PROJECT, None);
    eprintln!("During injection result={result:?}; next read result={after:?}");
    assert!(after.is_err(), "offline unknown inventory must be rejected");
    assert!(result.is_err(), "BUG: final source-root inventory was not checked after an observed live raw guard");
}
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_absence_change() {
    let (sandbox, _connection, store) = audit_large_host();
    let cache = sandbox.0.join(".noetome-sources");
    let writer = sandbox.0.join(".noetome-writing");
    std::fs::create_dir(&writer).unwrap();
    let stage = writer.join("version");
    std::fs::rename(cache.join(VERSION), &stage).unwrap();
    std::fs::remove_file(cache.join(".owner.json")).unwrap();
    std::fs::remove_dir(&cache).unwrap();
    store.validate_snapshots(&sandbox.0, PROJECT, Some((VERSION, &stage))).unwrap();
    let target = cache.join("human-review.txt");
    let worker = audit_when_raw_guard_is_live(stage.join("raw.pdf"), target.clone(), 1);
    let result = store.validate_snapshots(&sandbox.0, PROJECT, Some((VERSION, &stage)));
    worker.join().unwrap();
    assert_eq!(std::fs::read(&target).unwrap(), b"independent unknown source-root sentinel");
    let after = store.validate_snapshots(&sandbox.0, PROJECT, Some((VERSION, &stage)));
    eprintln!("During injection result={result:?}; next read result={after:?}");
    assert!(after.is_err(), "offline new unknown source root must be rejected");
    assert!(result.is_err(), "BUG: final source-root absence was not rechecked after a live staged raw guard");
}
#[cfg(windows)]
fn audit_owner_trial(mode: u8) {
    let sandbox = Sandbox::new();
    let connection = host_database();
    connection.execute_batch("DELETE FROM pdf_imports; DELETE FROM pdf_resources; DELETE FROM pdf_parses;").unwrap();
    let raw = vec![b'x'; 16 * 1024 * 1024];
    let hash = crate::text::sha256(&raw);
    connection.execute("UPDATE source_versions SET media_type='text/plain',display_name='synthetic.txt',content_sha256=?1,byte_length=?2,normalized_sha256=?1,normalization_version='utf8-newlines-v1',ingest_status='ready',raw_snapshot=?3,normalized_snapshot=?4", params![hash, raw.len() as i64, format!(".noetome-sources/{VERSION}/raw.bin"), format!(".noetome-sources/{VERSION}/normalized.txt")]).unwrap();
    connection.execute("INSERT INTO source_spans VALUES('d4cc1111-0812-4bac-9fc1-c71782669045',?1,0,'text',0,?2,1,1,?3,'blocks-v1','parsed')", params![VERSION, raw.len() as i64, hash]).unwrap();
    connection.execute("INSERT INTO source_imports(rowid,import_id,imported_at,selected_path,source_id,version_id,status,reused,span_count,pending_extraction_count,knowledge_status,error_code,error_message) VALUES(1,?1,?2,'D:/selected/synthetic.txt',?3,?4,'ready',0,1,1,'pending',NULL,NULL)", params![IMPORT,TIME,SOURCE,VERSION]).unwrap();
    connection.execute("INSERT INTO pdf_imports(rowid,import_id,imported_at,selected_path,source_id,version_id,parse_id,status,reused,parse_reused,acquisition_status,error_code,error_message) VALUES(2,'12facf7a-4fbd-42a7-8c2f-f96208bf740e',?1,'D:/selected/missing.pdf',NULL,NULL,NULL,'failed',0,0,'failed','SOURCE_READ_ERROR','controlled unavailable selected PDF')", params![TIME]).unwrap();
    let cache = sandbox.0.join(".noetome-sources");
    std::fs::create_dir(&cache).unwrap();
    std::fs::write(cache.join(".owner.json"), format!("{{\"schema_version\":1,\"project_id\":\"{PROJECT}\"}}")).unwrap();
    let version = cache.join(VERSION);
    std::fs::create_dir(&version).unwrap();
    std::fs::write(version.join("raw.bin"), &raw).unwrap();
    std::fs::write(version.join("normalized.txt"), &raw).unwrap();
    let store = crate::source_model::Store::load(&connection, PROJECT).unwrap();
    store.validate_snapshots(&sandbox.0, PROJECT, None).unwrap();
    let owner = cache.join(".owner.json");
    let before = same_file::Handle::from_path(&owner).unwrap();
    let worker = audit_when_raw_guard_is_live(version.join("raw.bin"), owner.clone(), mode);
    let result = store.validate_snapshots(&sandbox.0, PROJECT, None);
    worker.join().unwrap();
    eprintln!("Owner mode {mode}; during injection result={result:?}");
    if mode == 2 {
        assert!(std::fs::read(&owner).unwrap().windows(b"foreign-project".len()).any(|part| part == b"foreign-project"));
        assert!(store.validate_snapshots(&sandbox.0, PROJECT, None).is_err());
    } else {
        assert_ne!(before, same_file::Handle::from_path(&owner).unwrap(), "owner replacement identity did not change");
        store.validate_snapshots(&sandbox.0, PROJECT, None).unwrap();
    }
    assert!(result.is_err(), "BUG: a source-root owner mutation escaped final verification in Schema3 with a failed unacquired PDF import");
}
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_owner_bytes() { audit_owner_trial(2); }
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_owner_identity() { audit_owner_trial(3); }
