import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

repo = Path(r'D:\Noetome')
audit = Path(sys.argv[1]).resolve()
base = '058a8b353dd41cff7840a2995dedde032a41db9a'
frozen = repo / '.artifacts/b03-t03-model-review'
expected = {
    'source_model.rs': 'f445fb4ba6dd62527428d1403d2827cccef5a8e1a0a6d2516c97a0d5ecbcd1b2',
    'pdf_source_model.rs': 'da7020d5c70c3cc134ba5511e3454b8482ae7332d44d0393891b0a3a3a98df45',
    'pdf_source_model_tests.rs': '7c22161bbbe9186f422c9d3f877c69c96c5d10ae20675ff7e95ffb43c7b93a10',
}
commands = []
results = []
def record(message):
    results.append(message)
    print(message, flush=True)
    (audit / 'results.txt').write_text('\n'.join(results) + '\n', encoding='utf-8')
def run(label, argv, cwd=None, env=None):
    value = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    (audit / (label + '.stdout.txt')).write_bytes(value.stdout)
    (audit / (label + '.stderr.txt')).write_bytes(value.stderr)
    commands.append({'label': label, 'argv': [str(a) for a in argv], 'cwd': str(cwd or repo), 'exit': value.returncode})
    (audit / 'commands.json').write_text(json.dumps(commands, ensure_ascii=False, indent=2), encoding='utf-8')
    record(f'{label}: exit {value.returncode}')
    return value
record('Audit root: ' + str(audit))
record('Scope: frozen production model with baseline native T02 dependencies; no Cargo, repository writes or production fault flags.')
inputs = {}
for name, digest in expected.items():
    raw = (frozen / name).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    assert actual == digest, (name, actual)
    inputs[name] = actual
record('All 3 frozen package hashes match supplied SHA256 values.')
base_model = subprocess.check_output(['git', 'show', base + ':crates/noetome-cli/src/source_model.rs'], cwd=repo).decode('utf-8')
new_model = (frozen / 'source_model.rs').read_text(encoding='utf-8')
for dto in ['SourceFailure', 'SourceVersion', 'SourceSpan', 'ImportReport']:
    pattern = r'pub\(crate\) struct ' + dto + r' \{.*?\n\}'
    assert re.search(pattern, base_model, re.S).group(0) == re.search(pattern, new_model, re.S).group(0), dto
record('Legacy SourceFailure/SourceVersion/SourceSpan/ImportReport declarations and nullable decoder annotations are unchanged from base.')
fmt = run('frozen-rustfmt', [r'C:\Users\Lyinn\.cargo\bin\rustfmt.exe', '--check', '--edition', '2024', '--config', 'skip_children=true', *[str(frozen / name) for name in expected]], cwd=repo)
assert fmt.returncode == 0
archive = run('baseline-archive', ['git', 'archive', '--format=zip', base], cwd=repo)
assert archive.returncode == 0
snapshot = audit / 'snapshot'
snapshot.mkdir()
with zipfile.ZipFile(io.BytesIO(archive.stdout)) as packed:
    for entry in packed.infolist():
        dest = (snapshot / entry.filename).resolve()
        assert dest.is_relative_to(snapshot), entry.filename
    packed.extractall(snapshot)
# Archive bytes are preserved as the actual git command output, with no current
# workspace source read except the explicitly fingerprinted Schema3 fixture.
crate = snapshot / 'crates/noetome-cli'
for name, relative in [('source_model.rs', 'src/source_model.rs'), ('pdf_source_model.rs', 'src/pdf_source_model.rs'), ('pdf_source_model_tests.rs', 'tests/support/pdf_source_model_tests.rs')]:
    (crate / relative).write_bytes((frozen / name).read_bytes())
schema = (repo / 'crates/noetome-cli/src/source_schema3.sql').read_bytes()
inputs['fixture_source_schema3.sql'] = hashlib.sha256(schema).hexdigest()
(crate / 'src/source_schema3.sql').write_bytes(schema)
lib = crate / 'src/lib.rs'
lib.write_text(lib.read_text(encoding='utf-8').replace('mod source_model;', 'mod source_model;\nmod pdf_source_model;'), encoding='utf-8')
source = crate / 'src/source.rs'
old = source.read_text(encoding='utf-8')
needle = '        reports: Vec::new(),\n    }'
assert old.count(needle) == 1
source.write_text(old.replace(needle, '        reports: Vec::new(),\n        pdf: crate::pdf_source_model::PdfStore::default(),\n        import_orders: BTreeMap::new(),\n    }'), encoding='utf-8')
record('Harness-only adaptation: declare new PDF model module and add new empty Store fields in baseline source.rs; frozen production files unchanged.')
probe = r'''

// Independent review probes appended only to the temporary test copy.
// The synchronization observes an actual Windows raw-file sharing violation;
// there is no model/control hook and no arbitrary mutation of production code.
#[cfg(windows)]
fn audit_when_raw_guard_is_live(raw: PathBuf, target: PathBuf, mode: u8) -> std::thread::JoinHandle<()> {
    use std::os::windows::fs::OpenOptionsExt;
    std::thread::spawn(move || {
        std::thread::sleep(std::time::Duration::from_millis(5));
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
        loop {
            match std::fs::OpenOptions::new().write(true).share_mode(7).open(&raw) {
                Ok(file) => drop(file),
                Err(error) if error.raw_os_error() == Some(32) => {
                    match mode {
                        0 => std::fs::write(&target, b"independent unknown source-root sentinel").unwrap(),
                        1 => {
                            std::fs::create_dir(target.parent().unwrap()).unwrap();
                            std::fs::write(&target, b"independent unknown source-root sentinel").unwrap();
                        },
                        2 => std::fs::write(&target, b"{\"schema_version\":1,\"project_id\":\"foreign-project\"}").unwrap(),
                        3 => {
                            let bytes = std::fs::read(&target).unwrap();
                            let replacement = target.with_file_name(".owner.replacement");
                            std::fs::write(&replacement, bytes).unwrap();
                            std::fs::remove_file(&target).unwrap();
                            std::fs::rename(&replacement, &target).unwrap();
                        },
                        _ => unreachable!(),
                    }
                    eprintln!("Observed raw sharing violation, then injected source-root mode {mode}");
                    return;
                },
                Err(error) => panic!("audit setup unexpected raw-file error: {error}"),
            }
            assert!(std::time::Instant::now() < deadline, "audit setup did not observe a live raw guard");
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
    })
}
#[cfg(windows)]
fn audit_large_host() -> (Sandbox, Connection, crate::source_model::Store) {
    let sandbox = Sandbox::new();
    host_snapshots(&sandbox.0);
    let connection = host_database();
    let raw = vec![b'x'; 16 * 1024 * 1024];
    let hash = crate::text::sha256(&raw);
    let fingerprint = Fingerprint { sha256: hash.clone(), byte_length: raw.len() as u64 };
    let key = cache_key(&fingerprint, &ParserIdentity::pinned(), &"a".repeat(64), DEFAULT_IMPORT_OPTIONS).unwrap();
    connection.execute("UPDATE source_versions SET content_sha256=?1,byte_length=?2", params![hash, raw.len() as i64]).unwrap();
    connection.execute("UPDATE pdf_parses SET cache_key=?1", params![key]).unwrap();
    std::fs::write(sandbox.0.join(".noetome-sources").join(VERSION).join("raw.pdf"), raw).unwrap();
    let store = crate::source_model::Store::load(&connection, PROJECT).unwrap();
    store.validate_snapshots(&sandbox.0, PROJECT, None).unwrap();
    (sandbox, connection, store)
}
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_unknown_inventory() {
    let (sandbox, _connection, store) = audit_large_host();
    let cache = sandbox.0.join(".noetome-sources");
    let raw = cache.join(VERSION).join("raw.pdf");
    let target = cache.join("human-review.txt");
    let worker = audit_when_raw_guard_is_live(raw, target.clone(), 0);
    let result = store.validate_snapshots(&sandbox.0, PROJECT, None);
    worker.join().unwrap();
    assert_eq!(std::fs::read(&target).unwrap(), b"independent unknown source-root sentinel");
    let after = store.validate_snapshots(&sandbox.0, PROJECT, None);
    eprintln!("During injection result={result:?}; next read result={after:?}");
    assert!(after.is_err(), "offline unknown inventory must be rejected");
    assert!(result.is_err(), "BUG: final source-root inventory was not checked after an observed live raw guard");
}
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_absence_change() {
    let (sandbox, _connection, store) = audit_large_host();
    let cache = sandbox.0.join(".noetome-sources");
    let writer = sandbox.0.join(".noetome-writing");
    std::fs::create_dir(&writer).unwrap();
    let stage = writer.join("version");
    std::fs::rename(cache.join(VERSION), &stage).unwrap();
    std::fs::remove_file(cache.join(".owner.json")).unwrap();
    std::fs::remove_dir(&cache).unwrap();
    store.validate_snapshots(&sandbox.0, PROJECT, Some((VERSION, &stage))).unwrap();
    let target = cache.join("human-review.txt");
    let worker = audit_when_raw_guard_is_live(stage.join("raw.pdf"), target.clone(), 1);
    let result = store.validate_snapshots(&sandbox.0, PROJECT, Some((VERSION, &stage)));
    worker.join().unwrap();
    assert_eq!(std::fs::read(&target).unwrap(), b"independent unknown source-root sentinel");
    let after = store.validate_snapshots(&sandbox.0, PROJECT, Some((VERSION, &stage)));
    eprintln!("During injection result={result:?}; next read result={after:?}");
    assert!(after.is_err(), "offline new unknown source root must be rejected");
    assert!(result.is_err(), "BUG: final source-root absence was not rechecked after a live staged raw guard");
}
#[cfg(windows)]
fn audit_owner_trial(mode: u8) {
    let sandbox = Sandbox::new();
    let connection = host_database();
    connection.execute_batch("DELETE FROM pdf_imports; DELETE FROM pdf_resources; DELETE FROM pdf_parses;").unwrap();
    let raw = vec![b'x'; 16 * 1024 * 1024];
    let hash = crate::text::sha256(&raw);
    connection.execute("UPDATE source_versions SET media_type='text/plain',display_name='synthetic.txt',content_sha256=?1,byte_length=?2,normalized_sha256=?1,normalization_version='utf8-newlines-v1',ingest_status='ready',raw_snapshot=?3,normalized_snapshot=?4", params![hash, raw.len() as i64, format!(".noetome-sources/{VERSION}/raw.bin"), format!(".noetome-sources/{VERSION}/normalized.txt")]).unwrap();
    connection.execute("INSERT INTO source_spans VALUES('d4cc1111-0812-4bac-9fc1-c71782669045',?1,0,'text',0,?2,1,1,?3,'blocks-v1','parsed')", params![VERSION, raw.len() as i64, hash]).unwrap();
    connection.execute("INSERT INTO source_imports(rowid,import_id,imported_at,selected_path,source_id,version_id,status,reused,span_count,pending_extraction_count,knowledge_status,error_code,error_message) VALUES(1,?1,?2,'D:/selected/synthetic.txt',?3,?4,'ready',0,1,1,'pending',NULL,NULL)", params![IMPORT,TIME,SOURCE,VERSION]).unwrap();
    connection.execute("INSERT INTO pdf_imports(rowid,import_id,imported_at,selected_path,source_id,version_id,parse_id,status,reused,parse_reused,acquisition_status,error_code,error_message) VALUES(2,'12facf7a-4fbd-42a7-8c2f-f96208bf740e',?1,'D:/selected/missing.pdf',NULL,NULL,NULL,'failed',0,0,'failed','SOURCE_READ_ERROR','controlled unavailable selected PDF')", params![TIME]).unwrap();
    let cache = sandbox.0.join(".noetome-sources");
    std::fs::create_dir(&cache).unwrap();
    std::fs::write(cache.join(".owner.json"), format!("{{\"schema_version\":1,\"project_id\":\"{PROJECT}\"}}")).unwrap();
    let version = cache.join(VERSION);
    std::fs::create_dir(&version).unwrap();
    std::fs::write(version.join("raw.bin"), &raw).unwrap();
    std::fs::write(version.join("normalized.txt"), &raw).unwrap();
    let store = crate::source_model::Store::load(&connection, PROJECT).unwrap();
    store.validate_snapshots(&sandbox.0, PROJECT, None).unwrap();
    let owner = cache.join(".owner.json");
    let before = same_file::Handle::from_path(&owner).unwrap();
    let worker = audit_when_raw_guard_is_live(version.join("raw.bin"), owner.clone(), mode);
    let result = store.validate_snapshots(&sandbox.0, PROJECT, None);
    worker.join().unwrap();
    eprintln!("Owner mode {mode}; during injection result={result:?}");
    if mode == 2 {
        assert!(std::fs::read(&owner).unwrap().windows(b"foreign-project".len()).any(|part| part == b"foreign-project"));
        assert!(store.validate_snapshots(&sandbox.0, PROJECT, None).is_err());
    } else {
        assert_ne!(before, same_file::Handle::from_path(&owner).unwrap(), "owner replacement identity did not change");
        store.validate_snapshots(&sandbox.0, PROJECT, None).unwrap();
    }
    assert!(result.is_err(), "BUG: a source-root owner mutation escaped final verification in Schema3 with a failed unacquired PDF import");
}
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_owner_bytes() { audit_owner_trial(2); }
#[cfg(windows)]
#[test]
fn audit_source_cache_concurrent_owner_identity() { audit_owner_trial(3); }
'''
(audit / 'probe-tests.rs').write_text(probe, encoding='utf-8')
tests = crate / 'tests/support/pdf_source_model_tests.rs'
tests.write_bytes(tests.read_bytes() + probe.encode('utf-8'))
for name, relative in [('source_model.rs', 'src/source_model.rs'), ('pdf_source_model.rs', 'src/pdf_source_model.rs')]:
    assert hashlib.sha256((crate / relative).read_bytes()).hexdigest() == expected[name]
fingerprint = json.loads((repo / 'target/debug/.fingerprint/noetome-cli-b3c381fa74716987/test-lib-noetome_cli.json').read_text(encoding='utf-8'))
externs = []
for _, name, _, wanted in fingerprint['deps']:
    candidates = []
    for folder in [*(repo / 'target/debug/.fingerprint').glob(name + '-*'), *(repo / 'target/debug/.fingerprint').glob(name.replace('_', '-') + '-*')]:
        marker = folder / ('lib-' + name)
        if not marker.exists():
            continue
        encoded = marker.read_text().strip()
        if len(encoded) != 16:
            continue
        values = [int.from_bytes(bytes.fromhex(encoded), order) for order in ['little', 'big']]
        artifact = repo / 'target/debug/deps' / ('lib' + name + '-' + folder.name.rsplit('-', 1)[1] + '.rlib')
        if wanted in values and artifact.exists():
            candidates.append(artifact)
    assert candidates, ('missing exact compiled dependency', name, wanted)
    chosen = candidates[0]
    inputs['dependency:' + chosen.name] = hashlib.sha256(chosen.read_bytes()).hexdigest()
    externs += ['--extern', name + '=' + str(chosen)]
(audit / 'input-hashes.json').write_text(json.dumps(inputs, indent=2), encoding='utf-8')
record('Exact direct dependencies resolved through the supplied model test fingerprint; dependency files are read only.')
probe_env = os.environ.copy()
probe_env['CARGO_MANIFEST_DIR'] = str(crate)
probe_env['CARGO_PKG_VERSION'] = '0.1.0'
probe_env['TEMP'] = str(audit)
probe_env['TMP'] = str(audit)
exe = audit / 'immutable-model-tests.exe'
compile_result = run('direct-rustc', [r'C:\Users\Lyinn\.cargo\bin\rustc.exe', '--crate-name', 'noetome_model_immutable_review', '--edition', '2024', '--test', '--cap-lints', 'allow', '-L', 'dependency=' + str(repo / 'target/debug/deps'), *externs, str(crate / 'src/lib.rs'), '-o', str(exe)], cwd=repo, env=probe_env)
if compile_result.returncode:
    print(compile_result.stderr.decode('utf-8', errors='replace'), flush=True)
    sys.exit(compile_result.returncode)
baseline = run('frozen-model-28', [str(exe), 'source_model::tests', '--skip', 'audit_source_cache', '--test-threads=1', '--nocapture'], cwd=repo, env=probe_env)
print(baseline.stdout.decode('utf-8', errors='replace'), flush=True)
print(baseline.stderr.decode('utf-8', errors='replace'), flush=True)
if baseline.returncode:
    sys.exit(baseline.returncode)
races = run('source-root-race-red', [str(exe), 'audit_source_cache', '--test-threads=1', '--nocapture'], cwd=repo, env=probe_env)
print(races.stdout.decode('utf-8', errors='replace'), flush=True)
print(races.stderr.decode('utf-8', errors='replace'), flush=True)
record('Audit preserves every command, stdout, stderr and exit code; RED is expected for confirmed boundary defects.')
sys.exit(0)