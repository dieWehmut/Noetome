import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

repo = Path(r'D:\Noetome')
audit = Path(sys.argv[1]).resolve()
base = '058a8b353dd41cff7840a2995dedde032a41db9a'
frozen = repo / '.artifacts/b03-t03-model-review-v2'
expected = {
    'source_model.rs': 'de0983ed9064a5a6a58b5d3c0af7f11de291d0403777fc08deb03d0af21cca25',
    'pdf_source_model.rs': 'da7020d5c70c3cc134ba5511e3454b8482ae7332d44d0393891b0a3a3a98df45',
    'pdf_source_model_tests.rs': 'c72cbddd210fc0db99310bf4ca44fbd14a692f024b1d5f889500264fd9c6a9d5',
    'source_cache_race_tests.rs': '45dc7f4309f445567ef72ffa75cfb1d1bd56c2f639bd36048513610fd995c3e0',
}
commands = []
results = []
def record(message):
    results.append(message)
    print(message, flush=True)
    (audit / 'results.txt').write_text('\n'.join(results) + '\n', encoding='utf-8')
def run(label, argv, cwd=None, env=None):
    value = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    (audit / (label + '.stdout.txt')).write_bytes(value.stdout)
    (audit / (label + '.stderr.txt')).write_bytes(value.stderr)
    commands.append({'label': label, 'argv': [str(a) for a in argv], 'cwd': str(cwd or repo), 'exit': value.returncode})
    (audit / 'commands.json').write_text(json.dumps(commands, ensure_ascii=False, indent=2), encoding='utf-8')
    record(f'{label}: exit {value.returncode}')
    return value
record('Audit root: ' + str(audit))
record('Scope: frozen production model with baseline native T02 dependencies; no Cargo, repository writes or production fault flags.')
inputs = {}
for name, digest in expected.items():
    raw = (frozen / name).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    assert actual == digest, (name, actual)
    inputs[name] = actual
record('All 4 frozen package hashes match supplied SHA256 values.')
base_model = subprocess.check_output(['git', 'show', base + ':crates/noetome-cli/src/source_model.rs'], cwd=repo).decode('utf-8')
new_model = (frozen / 'source_model.rs').read_text(encoding='utf-8')
for dto in ['SourceFailure', 'SourceVersion', 'SourceSpan', 'ImportReport']:
    pattern = r'pub\(crate\) struct ' + dto + r' \{.*?\n\}'
    assert re.search(pattern, base_model, re.S).group(0) == re.search(pattern, new_model, re.S).group(0), dto
record('Legacy SourceFailure/SourceVersion/SourceSpan/ImportReport declarations and nullable decoder annotations are unchanged from base.')
fmt = run('frozen-rustfmt', [r'C:\Users\Lyinn\.cargo\bin\rustfmt.exe', '--check', '--edition', '2024', '--config', 'skip_children=true', *[str(frozen / name) for name in list(expected)[:3]]], cwd=repo)
assert fmt.returncode == 0
archive = run('baseline-archive', ['git', 'archive', '--format=zip', base], cwd=repo)
assert archive.returncode == 0
snapshot = audit / 'snapshot'
snapshot.mkdir()
with zipfile.ZipFile(io.BytesIO(archive.stdout)) as packed:
    for entry in packed.infolist():
        dest = (snapshot / entry.filename).resolve()
        assert dest.is_relative_to(snapshot), entry.filename
    packed.extractall(snapshot)
# Archive bytes are preserved as the actual git command output, with no current
# workspace source read except the explicitly fingerprinted Schema3 fixture.
crate = snapshot / 'crates/noetome-cli'
for name, relative in [('source_model.rs', 'src/source_model.rs'), ('pdf_source_model.rs', 'src/pdf_source_model.rs'), ('pdf_source_model_tests.rs', 'tests/support/pdf_source_model_tests.rs'), ('source_cache_race_tests.rs', 'tests/support/source_cache_race_tests.rs')]:
    (crate / relative).write_bytes((frozen / name).read_bytes())
schema = (repo / 'crates/noetome-cli/src/source_schema3.sql').read_bytes()
inputs['fixture_source_schema3.sql'] = hashlib.sha256(schema).hexdigest()
(crate / 'src/source_schema3.sql').write_bytes(schema)
lib = crate / 'src/lib.rs'
lib.write_text(lib.read_text(encoding='utf-8').replace('mod source_model;', 'mod source_model;\nmod pdf_source_model;'), encoding='utf-8')
source = crate / 'src/source.rs'
old = source.read_text(encoding='utf-8')
needle = '        reports: Vec::new(),\n    }'
assert old.count(needle) == 1
source.write_text(old.replace(needle, '        reports: Vec::new(),\n        pdf: crate::pdf_source_model::PdfStore::default(),\n        import_orders: BTreeMap::new(),\n    }'), encoding='utf-8')
record('Harness-only adaptation: declare new PDF model module and add new empty Store fields in baseline source.rs; frozen production files unchanged.')
(audit / 'independent-paired-stage-probe.rs').write_text('\n\n// Independent re-review: both new Version and parse staged, both cache roots absent.\n#[test]\nfn independent_paired_writer_stage_absence_change_is_rejected() {\n    let (sandbox, _connection, store) = large_host();\n    let sources = sandbox.0.join(".noetome-sources");\n    let parses = sandbox.0.join(".noetome-pdf-parses");\n    let writer = sandbox.0.join(".noetome-writing");\n    fs::create_dir(&writer).unwrap();\n    let version_stage = writer.join("version");\n    let parse_stage = writer.join("parse");\n    fs::rename(sources.join(VERSION), &version_stage).unwrap();\n    fs::rename(parses.join(PARSE), &parse_stage).unwrap();\n    for cache in [&sources, &parses] {\n        fs::remove_file(cache.join(".owner.json")).unwrap();\n        fs::remove_dir(cache).unwrap();\n    }\n    store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).unwrap();\n    let target = sources.join("paired-stage-human-review.txt");\n    let worker = mutate_when_raw_is_guarded(version_stage.join("raw.pdf"), target.clone(), 1);\n    let result = store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage)));\n    assert_eq!(worker.join().unwrap(), Mutation::Applied);\n    assert_eq!(fs::read(&target).unwrap(), b"unknown cache sentinel");\n    eprintln!("Independent paired stages result={result:?}");\n    assert!(result.is_err(), "source-root creation escaped with both new artifacts staged");\n    assert!(store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).is_err());\n}\n', encoding='utf-8')
race_tests = crate / 'tests/support/source_cache_race_tests.rs'
assert hashlib.sha256(race_tests.read_bytes()).hexdigest() == expected['source_cache_race_tests.rs']
race_tests.write_bytes(race_tests.read_bytes() + b'\n\n// Independent re-review: both new Version and parse staged, both cache roots absent.\n#[test]\nfn independent_paired_writer_stage_absence_change_is_rejected() {\n    let (sandbox, _connection, store) = large_host();\n    let sources = sandbox.0.join(".noetome-sources");\n    let parses = sandbox.0.join(".noetome-pdf-parses");\n    let writer = sandbox.0.join(".noetome-writing");\n    fs::create_dir(&writer).unwrap();\n    let version_stage = writer.join("version");\n    let parse_stage = writer.join("parse");\n    fs::rename(sources.join(VERSION), &version_stage).unwrap();\n    fs::rename(parses.join(PARSE), &parse_stage).unwrap();\n    for cache in [&sources, &parses] {\n        fs::remove_file(cache.join(".owner.json")).unwrap();\n        fs::remove_dir(cache).unwrap();\n    }\n    store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).unwrap();\n    let target = sources.join("paired-stage-human-review.txt");\n    let worker = mutate_when_raw_is_guarded(version_stage.join("raw.pdf"), target.clone(), 1);\n    let result = store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage)));\n    assert_eq!(worker.join().unwrap(), Mutation::Applied);\n    assert_eq!(fs::read(&target).unwrap(), b"unknown cache sentinel");\n    eprintln!("Independent paired stages result={result:?}");\n    assert!(result.is_err(), "source-root creation escaped with both new artifacts staged");\n    assert!(store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).is_err());\n}\n')
record('Frozen race regressions unchanged as a prefix; one independent paired-writer-stage probe appended only in temporary copy.')
for name, relative in [('source_model.rs', 'src/source_model.rs'), ('pdf_source_model.rs', 'src/pdf_source_model.rs')]:
    assert hashlib.sha256((crate / relative).read_bytes()).hexdigest() == expected[name]
fingerprint = json.loads((repo / 'target/debug/.fingerprint/noetome-cli-b3c381fa74716987/test-lib-noetome_cli.json').read_text(encoding='utf-8'))
externs = []
for _, name, _, wanted in fingerprint['deps']:
    candidates = []
    for folder in [*(repo / 'target/debug/.fingerprint').glob(name + '-*'), *(repo / 'target/debug/.fingerprint').glob(name.replace('_', '-') + '-*')]:
        marker = folder / ('lib-' + name)
        if not marker.exists():
            continue
        encoded = marker.read_text().strip()
        if len(encoded) != 16:
            continue
        values = [int.from_bytes(bytes.fromhex(encoded), order) for order in ['little', 'big']]
        artifact = repo / 'target/debug/deps' / ('lib' + name + '-' + folder.name.rsplit('-', 1)[1] + '.rlib')
        if wanted in values and artifact.exists():
            candidates.append(artifact)
    assert candidates, ('missing exact compiled dependency', name, wanted)
    chosen = candidates[0]
    inputs['dependency:' + chosen.name] = hashlib.sha256(chosen.read_bytes()).hexdigest()
    externs += ['--extern', name + '=' + str(chosen)]
(audit / 'input-hashes.json').write_text(json.dumps(inputs, indent=2), encoding='utf-8')
record('Exact direct dependencies resolved through the supplied model test fingerprint; dependency files are read only.')
probe_env = os.environ.copy()
probe_env['CARGO_MANIFEST_DIR'] = str(crate)
probe_env['CARGO_PKG_VERSION'] = '0.1.0'
probe_env['TEMP'] = str(audit)
probe_env['TMP'] = str(audit)
exe = audit / 'immutable-model-tests.exe'
compile_result = run('direct-rustc', [r'C:\Users\Lyinn\.cargo\bin\rustc.exe', '--crate-name', 'noetome_model_immutable_review', '--edition', '2024', '--test', '--cap-lints', 'allow', '-L', 'dependency=' + str(repo / 'target/debug/deps'), *externs, str(crate / 'src/lib.rs'), '-o', str(exe)], cwd=repo, env=probe_env)
if compile_result.returncode:
    print(compile_result.stderr.decode('utf-8', errors='replace'), flush=True)
    sys.exit(compile_result.returncode)
baseline = run('frozen-model-28', [str(exe), 'source_model::tests', '--skip', 'source_cache_races', '--test-threads=1', '--nocapture'], cwd=repo, env=probe_env)
print(baseline.stdout.decode('utf-8', errors='replace'), flush=True)
print(baseline.stderr.decode('utf-8', errors='replace'), flush=True)
if baseline.returncode:
    sys.exit(baseline.returncode)
races = run('source-root-race-green', [str(exe), 'source_cache_races', '--test-threads=1', '--nocapture'], cwd=repo, env=probe_env)
print(races.stdout.decode('utf-8', errors='replace'), flush=True)
print(races.stderr.decode('utf-8', errors='replace'), flush=True)
assert races.returncode == 0, 're-review regression failed'
record('Re-review GREEN: four frozen production regressions plus independent paired-stage absence check; all stdout/stderr/exits preserved.')
sys.exit(0)