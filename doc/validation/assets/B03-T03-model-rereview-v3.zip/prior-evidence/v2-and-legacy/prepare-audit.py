from pathlib import Path
import sys

out = Path(sys.argv[1])
old = Path(r'C:\Users\Lyinn\AppData\Local\Temp\noetome-b03-t03-model-audit-5ba92cb23e364754b61fc7383aa9c8ae\audit.py').read_text(encoding='utf-8')
old = old.replace("frozen = repo / '.artifacts/b03-t03-model-review'", "frozen = repo / '.artifacts/b03-t03-model-review-v2'")
old = old.replace('f445fb4ba6dd62527428d1403d2827cccef5a8e1a0a6d2516c97a0d5ecbcd1b2', 'de0983ed9064a5a6a58b5d3c0af7f11de291d0403777fc08deb03d0af21cca25')
old = old.replace("    'pdf_source_model_tests.rs': '7c22161bbbe9186f422c9d3f877c69c96c5d10ae20675ff7e95ffb43c7b93a10',", "    'pdf_source_model_tests.rs': 'c72cbddd210fc0db99310bf4ca44fbd14a692f024b1d5f889500264fd9c6a9d5',\n    'source_cache_race_tests.rs': '45dc7f4309f445567ef72ffa75cfb1d1bd56c2f639bd36048513610fd995c3e0',")
old = old.replace('All 3 frozen package hashes', 'All 4 frozen package hashes')
old = old.replace('*[str(frozen / name) for name in expected]', '*[str(frozen / name) for name in list(expected)[:3]]')
old = old.replace("('pdf_source_model_tests.rs', 'tests/support/pdf_source_model_tests.rs')]:", "('pdf_source_model_tests.rs', 'tests/support/pdf_source_model_tests.rs'), ('source_cache_race_tests.rs', 'tests/support/source_cache_race_tests.rs')]:")
start = old.index("probe = r'''")
end = old.index("for name, relative in [('source_model.rs', 'src/source_model.rs'), ('pdf_source_model.rs', 'src/pdf_source_model.rs')]:", start)
probe = r'''

// Independent re-review: both new Version and parse staged, both cache roots absent.
#[test]
fn independent_paired_writer_stage_absence_change_is_rejected() {
    let (sandbox, _connection, store) = large_host();
    let sources = sandbox.0.join(".noetome-sources");
    let parses = sandbox.0.join(".noetome-pdf-parses");
    let writer = sandbox.0.join(".noetome-writing");
    fs::create_dir(&writer).unwrap();
    let version_stage = writer.join("version");
    let parse_stage = writer.join("parse");
    fs::rename(sources.join(VERSION), &version_stage).unwrap();
    fs::rename(parses.join(PARSE), &parse_stage).unwrap();
    for cache in [&sources, &parses] {
        fs::remove_file(cache.join(".owner.json")).unwrap();
        fs::remove_dir(cache).unwrap();
    }
    store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).unwrap();
    let target = sources.join("paired-stage-human-review.txt");
    let worker = mutate_when_raw_is_guarded(version_stage.join("raw.pdf"), target.clone(), 1);
    let result = store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage)));
    assert_eq!(worker.join().unwrap(), Mutation::Applied);
    assert_eq!(fs::read(&target).unwrap(), b"unknown cache sentinel");
    eprintln!("Independent paired stages result={result:?}");
    assert!(result.is_err(), "source-root creation escaped with both new artifacts staged");
    assert!(store.validate_snapshots_staged(&sandbox.0, PROJECT, Some((VERSION, &version_stage)), Some((PARSE, &parse_stage))).is_err());
}
'''
addition = "(audit / 'independent-paired-stage-probe.rs').write_text(" + repr(probe) + ", encoding='utf-8')\n"
addition += "race_tests = crate / 'tests/support/source_cache_race_tests.rs'\n"
addition += "assert hashlib.sha256(race_tests.read_bytes()).hexdigest() == expected['source_cache_race_tests.rs']\n"
addition += "race_tests.write_bytes(race_tests.read_bytes() + " + repr(probe.encode('utf-8')) + ")\n"
addition += "record('Frozen race regressions unchanged as a prefix; one independent paired-writer-stage probe appended only in temporary copy.')\n"
old = old[:start] + addition + old[end:]
old = old.replace("'--skip', 'audit_source_cache'", "'--skip', 'source_cache_races'")
old = old.replace("run('source-root-race-red', [str(exe), 'audit_source_cache'", "run('source-root-race-green', [str(exe), 'source_cache_races'")
old = old.replace("record('Audit preserves every command, stdout, stderr and exit code; RED is expected for confirmed boundary defects.')", "assert races.returncode == 0, 're-review regression failed'\nrecord('Re-review GREEN: four frozen production regressions plus independent paired-stage absence check; all stdout/stderr/exits preserved.')")
assert "'source_cache_race_tests.rs': '45dc7f4309f445567ef72ffa75cfb1d1bd56c2f639bd36048513610fd995c3e0'" in old
assert 'audit_source_cache' not in old
(out / 'audit.py').write_text(old, encoding='utf-8')
print('Prepared re-review script: ' + str(out / 'audit.py'), flush=True)