import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
repo = Path(r'D:\Noetome')
crate = root / 'snapshot/crates/noetome-cli'
source = crate / 'src/source_model.rs'
tests = crate / 'tests/support/source_cache_race_tests.rs'
assert source.resolve().is_relative_to(root)
assert tests.resolve().is_relative_to(root)
fixed = source.read_bytes()
assert hashlib.sha256(fixed).hexdigest() == 'de0983ed9064a5a6a58b5d3c0af7f11de291d0403777fc08deb03d0af21cca25'
old = (repo / '.artifacts/b03-t03-model-review/source_model.rs').read_bytes()
assert hashlib.sha256(old).hexdigest() == 'f445fb4ba6dd62527428d1403d2827cccef5a8e1a0a6d2516c97a0d5ecbcd1b2'
probe = r'''

// Legal legacy UTF-8 history: twelve distinct immutable 64 MiB revisions;
// Schema3 has only an unacquired PDF failure. No sleep or fault injection.
#[test]
fn independent_large_legacy_history_stays_readable_with_source_owner_receipt() {
    let sandbox = Sandbox::new();
    let connection = host_database();
    connection.execute_batch("DELETE FROM pdf_imports; DELETE FROM pdf_resources; DELETE FROM pdf_parses; DELETE FROM source_versions;").unwrap();
    let cache = sandbox.0.join(".noetome-sources");
    fs::create_dir(&cache).unwrap();
    fs::write(cache.join(".owner.json"), format!("{{\"schema_version\":1,\"project_id\":\"{PROJECT}\"}}")).unwrap();
    let mut raw = vec![b'x'; 64 * 1024 * 1024];
    for revision in 1..=12i64 {
        let suffix = format!("{revision:012}");
        let offset = raw.len() - suffix.len();
        raw[offset..].copy_from_slice(suffix.as_bytes());
        let hash = crate::text::sha256(&raw);
        let version = uuid::Uuid::new_v4().to_string();
        let span = uuid::Uuid::new_v4().to_string();
        let import = uuid::Uuid::new_v4().to_string();
        connection.execute("INSERT INTO source_versions VALUES(?1,?2,?3,?4,'text/plain','synthetic-legacy-history.txt',?5,?6,?5,'utf8-newlines-v1','ready',?7,?8,NULL,NULL)", params![version,SOURCE,revision,TIME,hash,raw.len() as i64,format!(".noetome-sources/{version}/raw.bin"),format!(".noetome-sources/{version}/normalized.txt")]).unwrap();
        connection.execute("INSERT INTO source_spans VALUES(?1,?2,0,'text',0,?3,1,1,?4,'blocks-v1','parsed')", params![span,version,raw.len() as i64,hash]).unwrap();
        connection.execute("INSERT INTO source_imports(rowid,import_id,imported_at,selected_path,source_id,version_id,status,reused,span_count,pending_extraction_count,knowledge_status,error_code,error_message) VALUES(?1,?2,?3,'D:/selected/legacy-history.txt',?4,?5,'ready',0,1,1,'pending',NULL,NULL)", params![revision,import,TIME,SOURCE,version]).unwrap();
        let directory = cache.join(&version);
        fs::create_dir(&directory).unwrap();
        fs::write(directory.join("raw.bin"), &raw).unwrap();
        fs::write(directory.join("normalized.txt"), &raw).unwrap();
    }
    connection.execute("INSERT INTO pdf_imports(rowid,import_id,imported_at,selected_path,source_id,version_id,parse_id,status,reused,parse_reused,acquisition_status,error_code,error_message) VALUES(13,'12facf7a-4fbd-42a7-8c2f-f96208bf740e',?1,'D:/selected/unavailable.pdf',NULL,NULL,NULL,'failed',0,0,'failed','SOURCE_READ_ERROR','controlled unavailable selected PDF')", params![TIME]).unwrap();
    let store = crate::source_model::Store::load(&connection, PROJECT).unwrap();
    assert_eq!(store.versions.len(), 12);
    let started = std::time::Instant::now();
    let result = store.validate_snapshots(&sandbox.0, PROJECT, None);
    eprintln!("Legal 12x64MiB legacy history; no acquired PDF; elapsed={:?}; result={result:?}", started.elapsed());
    assert!(result.is_ok(), "legal legacy history rejected by source-owner receipt");
}
'''
(root / 'independent-legacy-budget-probe.rs').write_text(probe, encoding='utf-8')
tests.write_bytes(tests.read_bytes() + probe.encode('utf-8'))
commands = json.loads((root / 'commands.json').read_text(encoding='utf-8'))
compile_template = next(row['argv'] for row in commands if row['label'] == 'direct-rustc')
env = os.environ.copy()
env.update({'CARGO_MANIFEST_DIR':str(crate),'CARGO_PKG_VERSION':'0.1.0','TEMP':str(root),'TMP':str(root),'PYTHONIOENCODING':'utf-8'})
def run(label, argv):
    print('Starting ' + label, flush=True)
    p = subprocess.run(argv, cwd=repo, env=env, capture_output=True)
    (root / (label + '.stdout.txt')).write_bytes(p.stdout)
    (root / (label + '.stderr.txt')).write_bytes(p.stderr)
    commands.append({'label':label,'argv':argv,'cwd':str(repo),'exit':p.returncode})
    (root / 'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'{label}: exit {p.returncode}', flush=True)
    if p.stdout:
        print(p.stdout.decode('utf-8',errors='replace'),flush=True)
    if p.stderr:
        print(p.stderr.decode('utf-8',errors='replace'),flush=True)
    return p.returncode
fixed_exe = root / 'legacy-budget-v2.exe'
fixed_command = compile_template[:-1] + [str(fixed_exe)]
assert run('legacy-budget-compile-v2', fixed_command) == 0
old_exe = root / 'legacy-budget-v1.exe'
old_command = compile_template[:-1] + [str(old_exe)]
try:
    source.write_bytes(old)
    assert run('legacy-budget-compile-v1', old_command) == 0
finally:
    source.write_bytes(fixed)
assert hashlib.sha256(source.read_bytes()).hexdigest() == 'de0983ed9064a5a6a58b5d3c0af7f11de291d0403777fc08deb03d0af21cca25'
filter_name = 'independent_large_legacy_history_stays_readable_with_source_owner_receipt'
run('legacy-budget-v1', [str(old_exe),filter_name,'--test-threads=1','--nocapture'])
run('legacy-budget-v2', [str(fixed_exe),filter_name,'--test-threads=1','--nocapture'])