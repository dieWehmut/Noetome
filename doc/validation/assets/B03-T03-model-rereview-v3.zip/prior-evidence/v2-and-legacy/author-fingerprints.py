import hashlib
import json
from pathlib import Path
import sys
root = Path(sys.argv[1]).resolve()
raw = bytearray(b'x' * (64 * 1024 * 1024))
rows = []
for revision in range(1, 13):
    raw[-12:] = f'{revision:012}'.encode('ascii')
    digest = hashlib.sha256(raw).hexdigest()
    rows.append({'revision':revision,'media_type':'text/plain','byte_length':len(raw),'content_sha256':digest,'normalized_sha256':digest,'span_count':1})
value = {'scope':'Independent authored raw-content fingerprints for the legal history probe; both executions generate these bytes. Per-run UUID audit identities vary and were validated separately.','schema_version':3,'source_count':1,'version_count':12,'acquired_pdf_versions':0,'pdf_acquisition_failures':1,'sleep_or_fault_injection':False,'content':rows,'model_v1_sha256':'f445fb4ba6dd62527428d1403d2827cccef5a8e1a0a6d2516c97a0d5ecbcd1b2','model_v2_sha256':'de0983ed9064a5a6a58b5d3c0af7f11de291d0403777fc08deb03d0af21cca25','observed_v1':{'test_exit':0,'snapshot_seconds':42.080302,'result':'Ok'},'observed_v2':{'test_exit':101,'snapshot_seconds':42.4671619,'result':'SOURCE_INVALID_SNAPSHOT / SIDECAR_TIMEOUT'}}
path = root / 'legacy-budget-authored-input-fingerprints.json'
path.write_text(json.dumps(value,indent=2),encoding='utf-8')
print(str(path))
print('Fingerprint count: ' + str(len(rows)))
print('Manifest SHA256: ' + hashlib.sha256(path.read_bytes()).hexdigest())