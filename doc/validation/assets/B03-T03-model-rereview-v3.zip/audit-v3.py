import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
repo = Path(r"D:\Noetome")
prior = Path(r"C:\Users\Lyinn\AppData\Local\Temp\noetome-b03-t03-model-rereview-4376859e0c17446cbc7e4027ca5465cb")
original = Path(r"C:\Users\Lyinn\AppData\Local\Temp\noetome-b03-t03-model-audit-5ba92cb23e364754b61fc7383aa9c8ae")
assert root != prior and root.parent == prior.parent
frozen = repo / ".artifacts/b03-t03-model-review-v3"
expected = {
    "source_model.rs":"77f7841e1b141af76719bfff29eb649c8d02eac3c4f80d9e1f94b474f653e31c",
    "pdf_source_model.rs":"da7020d5c70c3cc134ba5511e3454b8482ae7332d44d0393891b0a3a3a98df45",
    "pdf_source_model_tests.rs":"c72cbddd210fc0db99310bf4ca44fbd14a692f024b1d5f889500264fd9c6a9d5",
    "source_cache_race_tests.rs":"45dc7f4309f445567ef72ffa75cfb1d1bd56c2f639bd36048513610fd995c3e0",
}
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for name, wanted in expected.items():
    assert sha(frozen/name) == wanted, name
assert sha(prior/"snapshot/crates/noetome-cli/src/source_model.rs") == "de0983ed9064a5a6a58b5d3c0af7f11de291d0403777fc08deb03d0af21cca25"
snapshot = root/"snapshot"
shutil.copytree(prior/"snapshot", snapshot)
crate = snapshot/"crates/noetome-cli"
destinations = {
    "source_model.rs":crate/"src/source_model.rs",
    "pdf_source_model.rs":crate/"src/pdf_source_model.rs",
    "pdf_source_model_tests.rs":crate/"tests/support/pdf_source_model_tests.rs",
    "source_cache_race_tests.rs":crate/"tests/support/source_cache_race_tests.rs",
}
for name, target in destinations.items():
    assert target.resolve().is_relative_to(root)
    target.write_bytes((frozen/name).read_bytes())
for name in ["independent-paired-stage-probe.rs","independent-legacy-budget-probe.rs"]:
    shutil.copy2(prior/name, root/name)
race_target = destinations["source_cache_race_tests.rs"]
race_target.write_bytes(race_target.read_bytes() +
                        (root/"independent-paired-stage-probe.rs").read_bytes() +
                        (root/"independent-legacy-budget-probe.rs").read_bytes())
assert race_target.read_text(encoding="utf-8").count("fn independent_large_legacy_history_stays_readable_with_source_owner_receipt") == 1
assert race_target.read_text(encoding="utf-8").count("fn independent_paired_writer_stage_absence_change_is_rejected") == 1
inputs = root/"inputs"
for version in ["v1","v2","v3"]:
    source_dir = repo/(".artifacts/b03-t03-model-review" if version=="v1" else ".artifacts/b03-t03-model-review-"+version)
    destination = inputs/version
    destination.mkdir(parents=True)
    for path in source_dir.iterdir():
        if path.is_file() and (path.suffix == ".rs" or path.name == "manifest.json"):
            shutil.copy2(path, destination/path.name)
prior_evidence = root/"prior-evidence"
for label, directory in [("v1-races",original),("v2-and-legacy",prior)]:
    target = prior_evidence/label
    target.mkdir(parents=True)
    for path in directory.iterdir():
        if path.is_file() and path.suffix in [".py",".rs",".json",".txt"]:
            shutil.copy2(path,target/path.name)
shutil.copy2(prior/"legacy-budget-authored-input-fingerprints.json",root/"legacy-budget-authored-input-fingerprints-v1-v2.json")
old_commands = json.loads((prior/"commands.json").read_text(encoding="utf-8"))
template = next(row["argv"] for row in old_commands if row["label"]=="direct-rustc")
old_source = str(prior/"snapshot/crates/noetome-cli/src/lib.rs")
assert template.count(old_source)==1
command = [str(crate/"src/lib.rs") if arg==old_source else arg for arg in template]
exe = root/"immutable-model-v3-tests.exe"
command[-1] = str(exe)
env = os.environ.copy()
env.update({"CARGO_MANIFEST_DIR":str(crate),"CARGO_PKG_VERSION":"0.1.0","TEMP":str(root),"TMP":str(root),"PYTHONIOENCODING":"utf-8"})
commands = []
dependencies = []
for i, arg in enumerate(command):
    if arg=="--extern":
        name,path = command[i+1].split("=",1)
        dependencies.append({"name":name,"path":path,"sha256":sha(path)})
fingerprints = {
    "base_commit":"058a8b353dd41cff7840a2995dedde032a41db9a",
    "scope":"Read-only frozen-model direct-rustc review, baseline archived harness and native T02 code; no Cargo and no repository writes.",
    "frozen_model_sha256":expected,
    "harness_lib_sha256":sha(crate/"src/lib.rs"),
    "harness_source_sha256":sha(crate/"src/source.rs"),
    "combined_race_tests_sha256":sha(race_target),
    "extra_probes":[{"path":str(root/name),"sha256":sha(root/name)} for name in ["independent-paired-stage-probe.rs","independent-legacy-budget-probe.rs"]],
    "dependencies":dependencies,
    "prior_v1_v2_evidence":str(prior_evidence),
}
(root/"input-hashes.json").write_text(json.dumps(fingerprints,ensure_ascii=False,indent=2),encoding="utf-8")
def run(label, argv):
    print("Starting "+label,flush=True)
    start = time.monotonic()
    completed = subprocess.run(argv,cwd=repo,env=env,capture_output=True)
    elapsed = time.monotonic()-start
    (root/(label+".stdout.txt")).write_bytes(completed.stdout)
    (root/(label+".stderr.txt")).write_bytes(completed.stderr)
    commands.append({"label":label,"argv":argv,"cwd":str(repo),"exit":completed.returncode,"elapsed_seconds":elapsed})
    (root/"commands.json").write_text(json.dumps(commands,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"{label}: exit {completed.returncode}; wall {elapsed:.3f}s",flush=True)
    if completed.stdout: print(completed.stdout.decode("utf-8",errors="replace"),flush=True)
    if completed.stderr: print(completed.stderr.decode("utf-8",errors="replace"),flush=True)
    return completed
assert run("direct-rustc-v3",command).returncode == 0
filter_name = "independent_large_legacy_history_stays_readable_with_source_owner_receipt"
matrix = run("frozen-v3-model-33",[str(exe),"source_model::tests","--skip",filter_name,"--test-threads=1","--nocapture"])
assert matrix.returncode==0
assert b"test result: ok. 33 passed;" in matrix.stdout
legacy = run("legacy-budget-v3",[str(exe),filter_name,"--test-threads=1","--nocapture"])
observed = legacy.stderr.decode("utf-8",errors="replace")
duration = re.search(r"elapsed=([0-9.]+)s; result=Ok",observed)
corpus = json.loads((root/"legacy-budget-authored-input-fingerprints-v1-v2.json").read_text(encoding="utf-8"))
corpus["model_v3_sha256"] = expected["source_model.rs"]
corpus["observed_v3"] = {"test_exit":legacy.returncode,"snapshot_seconds":float(duration.group(1)) if duration else None,"result":observed.strip()}
corpus["same_input_qualification"] = "All three runs generated the same authored twelve raw/normalized byte payloads; per-run version/span/import UUIDs varied and Store::load validated them."
(root/"legacy-budget-authored-input-fingerprints-v1-v2-v3.json").write_text(json.dumps(corpus,ensure_ascii=False,indent=2),encoding="utf-8")
(root/"results.txt").write_text("\n".join(f"{row['label']}: exit {row['exit']}; wall {row['elapsed_seconds']:.6f}s" for row in commands)+"\n",encoding="utf-8")
assert legacy.returncode==0
assert b"test result: ok. 1 passed;" in legacy.stdout
assert duration is not None
for name,wanted in expected.items():
    assert sha(frozen/name)==wanted
for name in ["source_model.rs","pdf_source_model.rs","pdf_source_model_tests.rs"]:
    assert sha(destinations[name])==expected[name]
print("V3 review matrix 33/33 GREEN; same authored legal 12x64MiB legacy history GREEN.",flush=True)